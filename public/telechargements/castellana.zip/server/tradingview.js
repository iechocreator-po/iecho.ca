// Client MCP vers le sidecar Python tradingview-mcp (streamable-http).
// Le sidecar n'est PAS lancé par ce backend — voir README « Lancer le
// sidecar tradingview-mcp » dans le CLAUDE.md. Si injoignable, chaque
// fonction lève une erreur ; les routes qui les appellent doivent répondre
// 503 proprement (même patron que le GITHUB_TOKEN absent chez bilbao) —
// jamais planter le serveur Express pour une dépendance externe indisponible.

import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import { readFileSync } from 'node:fs';

const settings = JSON.parse(readFileSync(new URL('../settings.json', import.meta.url)));
const sidecarUrl = new URL(settings.tradingviewMcp.url);

// Le sidecar est OPTIONNEL et DÉSACTIVÉ PAR DÉFAUT depuis le 7/9/2026
// (décision de JP après l'audit). Tout ce que ce module fournissait — RSI,
// SMA50/200, Golden Cross, VIX, cotations — est désormais calculé maison
// depuis l'historique Yahoo que l'app télécharge de toute façon
// (server/indicators.js, server/quotes.js), et vérifié identique à la
// décimale sur les 19 titres que le sidecar sait traiter (les 2 autres,
// PLTR et XEQT.TO, il ne les résout pas du tout — c'est le taux d'échec de
// 14 % relevé par l'audit, tombé à 0 depuis).
//
// Ce module reste branchable (`"enabled": true` dans settings.json) pour
// comparer les deux sources, mais rien d'essentiel n'en dépend plus. Quand
// il est désactivé : aucune connexion tentée, aucune pastille de statut en
// erreur, aucun 503 — l'app ne doit jamais signaler comme « panne » un
// composant que l'utilisateur n'a pas installé.
export function isSidecarEnabled() {
  return settings.tradingviewMcp?.enabled === true;
}

let clientPromise = null;

function connect() {
  const transport = new StreamableHTTPClientTransport(sidecarUrl);
  const client = new Client({ name: 'castellana', version: '0.1.0' });
  return client.connect(transport).then(() => client);
}

// Connexion paresseuse — pas au boot du serveur, pour ne pas bloquer/planter
// tout Express si le sidecar Python n'est pas encore démarré. Une connexion
// ratée n'est pas mise en cache : le prochain appel retente.
function getClient() {
  if (!clientPromise) {
    clientPromise = connect().catch((err) => {
      clientPromise = null;
      throw err;
    });
  }
  return clientPromise;
}

// F1 (audit du 7/9/2026) — la session MCP est mise en cache dans
// `clientPromise` ; elle n'était jamais invalidée quand un appel échouait.
// Après un redémarrage du sidecar, l'ancien identifiant de session n'existe
// plus côté Python et TOUS les appels suivants échouaient sur « Session not
// found », indéfiniment, jusqu'à un redémarrage d'Express. Le CLAUDE.md
// affirmait l'inverse (« la connexion s'est rétablie automatiquement ») :
// c'était faux, l'audit l'a reproduit en 4 étapes.
//
// On jette donc la session au premier échec de TRANSPORT, pour que l'appel
// suivant en rétablisse une. Une erreur métier renvoyée par l'outil
// (`parsed.error`, ex. « No data found ») n'invalide rien : la session est
// saine, c'est la donnée qui manque.
async function callTool(name, args) {
  let result;
  try {
    const client = await getClient();
    result = await client.callTool({ name, arguments: args });
  } catch (err) {
    clientPromise = null;
    throw err;
  }
  const text = result.content?.[0]?.text;
  if (!text) throw new Error(`tradingview-mcp: réponse vide pour ${name}`);
  const parsed = JSON.parse(text);
  if (parsed.error) throw new Error(`tradingview-mcp (${name}): ${parsed.error}`);
  return parsed;
}

// Vérif de connectivité pour l'indicateur de statut du frontend —
// `listTools()` est une poignée de main du protocole MCP, elle n'appelle
// aucun outil et ne touche donc jamais le scanner TradingView rate-limité.
// Retourne le détail de l'erreur (30/8/2026, demande de JP d'être explicite
// sur la nature du problème technique) — distingue en particulier
// "ECONNREFUSED" (sidecar non démarré) d'une autre erreur MCP.
export async function checkSidecarConnection() {
  if (!isSidecarEnabled()) {
    // « Désactivé » n'est PAS « en panne » : le frontend doit afficher un
    // état neutre, jamais une pastille rouge pour un composant optionnel
    // que le testeur n'a délibérément pas installé.
    return { ok: false, disabled: true, detail: 'Sidecar tradingview-mcp désactivé (optionnel — tous les indicateurs sont calculés maison).' };
  }
  try {
    const client = await getClient();
    await client.listTools();
    return { ok: true, disabled: false, detail: null };
  } catch (err) {
    // `fetch` masque la vraie cause derrière "fetch failed" — le code
    // système (ECONNREFUSED, etc.) vit dans err.cause, pas err.message.
    const detail = err.cause?.code === 'ECONNREFUSED'
      ? `Sidecar non démarré ou injoignable sur ${sidecarUrl} (npm run sidecar)`
      : (err.cause?.message || err.message);
    return { ok: false, disabled: false, detail };
  }
}

// VIX (et autres indices/FX/crypto) — voir CLAUDE.md pour le mapping complet.
export async function getMarketSnapshot() {
  const snapshot = await callTool('market_snapshot', {});
  const vix = snapshot.indices?.find((i) => i.symbol === '^VIX');
  return { vix: vix?.price ?? null, raw: snapshot };
}

// RSI(14), ATR, SMA/EMA (Golden Cross), volume vs moyenne 20j — un seul
// appel `coin_analysis` couvre tout, voir CLAUDE.md pour le détail des
// champs (et la limite connue : ATR/volume_analysis peuvent revenir null
// selon le titre/timeframe, TradingView ne les fournit pas toujours).
export async function getTechnicalAnalysis(ticker, { exchange = 'NASDAQ', timeframe = '1D' } = {}) {
  return callTool('coin_analysis', { symbol: ticker, exchange, timeframe });
}

// Cotation simple — utile pour dériver la force relative vs indice
// (2 appels : titre + indice de référence, delta calculé côté appelant).
export async function getPrice(symbol) {
  return callTool('yahoo_price', { symbol });
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Screening d'une liste de titres — appels SÉQUENTIELS et espacés, jamais
// en parallèle (Promise.all). Constaté en test réel le 22/7/2026 : une
// rafale de ~5-6 appels rapprochés à `coin_analysis` suffit à déclencher un
// rate-limit non documenté côté API non officielle de TradingView (réponse
// vide, `JSON.parse` échoue) — persistant plus de 5 minutes en test. D'où
// l'espacement ci-dessous, et la tolérance : un titre en échec n'interrompt
// pas le reste du screening, il ressort avec `error` rempli.
//
// Résilience par source : `changePercent` (donc la force relative) vient de
// `yahoo_price`, PAS de `coin_analysis` — vérifié en test réel que
// `yahoo_price` continue de répondre normalement même quand `coin_analysis`
// est rate-limité (deux sources de données distinctes, Yahoo Finance vs
// scanner TradingView). Seuls RSI et Golden Cross dépendent de
// `coin_analysis` et peuvent donc tomber en panne indépendamment.
export async function screenWatchlist(watchlist, { delayMs = 1500 } = {}) {
  let benchmarkChange = null;
  try {
    const spy = await getPrice('SPY');
    benchmarkChange = spy.change_pct ?? null;
  } catch {
    // Le screening continue sans force relative si SPY est injoignable.
  }

  const results = [];
  for (const { ticker, exchange } of watchlist) {
    let changePercent = null;
    try {
      changePercent = (await getPrice(ticker)).change_pct ?? null;
    } catch {
      // Le titre reste dans le screening même sans cotation Yahoo.
    }

    try {
      const ta = await getTechnicalAnalysis(ticker, { exchange });
      results.push({
        ticker,
        exchange,
        rsi: ta.rsi?.value ?? null,
        changePercent,
        forceRelative:
          changePercent != null && benchmarkChange != null
            ? changePercent - benchmarkChange
            : null,
        goldenCross: ta.sma?.signals?.some((s) => s.startsWith('Golden Cross')) ?? null,
        error: null,
      });
    } catch (err) {
      results.push({
        ticker,
        exchange,
        rsi: null,
        changePercent,
        forceRelative:
          changePercent != null && benchmarkChange != null
            ? changePercent - benchmarkChange
            : null,
        goldenCross: null,
        error: err.message,
      });
    }
    await sleep(delayMs);
  }
  return results;
}
