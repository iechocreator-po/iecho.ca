import {
  LABO_SCHEMA, getAllOverrides, setStrategyParams, resetStrategyParams, resetAllStrategyParams,
} from '../db/labo-params.js';

// Paramètres des stratégies d'options de l'utilisateur connecté (session).
// Miroir de server/index.js (routes /api/labo/params*).
// ⚠️ Doit être enregistré AVANT registerMarketRoutes : `/api/labo/:ticker`
// (GET) prendrait sinon `params` pour un symbole.
export function registerLaboParamsRoutes(app) {
  app.get('/api/labo/params', async (c) => {
    const overrides = await getAllOverrides(c.env.DB, c.get('userId'));
    return c.json({ overrides, schemaVersion: LABO_SCHEMA.version });
  });

  app.put('/api/labo/params/:id', async (c) => {
    try {
      const body = await c.req.json().catch(() => ({}));
      const overrides = await setStrategyParams(c.env.DB, c.get('userId'), c.req.param('id'), (body && body.values) || {});
      return c.json({ overrides });
    } catch (err) {
      return c.json({ error: err.message, errors: err.errors }, err.code === 'INVALID_LABO_PARAMS' ? 400 : 500);
    }
  });

  app.post('/api/labo/params/reset', async (c) => {
    return c.json({ overrides: await resetAllStrategyParams(c.env.DB, c.get('userId')) });
  });

  app.post('/api/labo/params/:id/reset', async (c) => {
    try {
      return c.json({ overrides: await resetStrategyParams(c.env.DB, c.get('userId'), c.req.param('id')) });
    } catch (err) {
      return c.json({ error: err.message }, err.code === 'INVALID_LABO_PARAMS' ? 400 : 500);
    }
  });
}
