// Publication du balayage S&P 500 vers la version en ligne (17/10/2026) — LOCAL.
//
// Après un balayage réussi (server/sweep.js), si la case « Publier vers la version en ligne »
// est cochée (Réglages → TradingView, décochée par défaut), l'instantané compact
// (cloud/src/lib/snapshots.js, même module que le Worker) est envoyé à
// PUT <CASTELLANA_ADMIN_URL>/api/admin/snapshots/sp500_sweep avec le Basic Auth admin.
// Identifiants dans le .env LOCAL (CASTELLANA_ADMIN_URL / _USER / _PASSWORD), jamais dans
// settings.json ni renvoyés au navigateur (seul l'hôte cible est affiché).
//
// Un échec ne fait JAMAIS échouer le balayage : il est enregistré et affiché, c'est tout.

import { buildSweepSnapshot } from '../cloud/src/lib/snapshots.js';
import { readCacheRaw, writeCache } from './cache.js';
import { screeningCacheKey, SP500 } from './screening.js';
import { sectorBreakdown } from './sweep-sectors.js';
import { envValue } from './alert-email.js';

const LAST_KEY = 'snapshot:publish:last';
const KEEP = 30 * 24 * 3600;

/** Pure : configuration d'envoi à partir de valeurs brutes. Ne renvoie jamais le mot de passe au navigateur. */
export function parsePublishConfig({ url, user, password }) {
  if (!url || !user || !password) return { ok: false, reason: 'CASTELLANA_ADMIN_URL, CASTELLANA_ADMIN_USER et CASTELLANA_ADMIN_PASSWORD manquent dans le .env local.' };
  let u;
  try { u = new URL(url); } catch { return { ok: false, reason: 'CASTELLANA_ADMIN_URL n\'est pas une adresse valide.' }; }
  const local = ['localhost', '127.0.0.1', '[::1]'].includes(u.hostname);
  if (u.protocol !== 'https:' && !(u.protocol === 'http:' && local)) return { ok: false, reason: 'CASTELLANA_ADMIN_URL doit être en https (http seulement vers localhost, pour wrangler dev).' };
  return { ok: true, base: u.origin, host: u.host, auth: 'Basic ' + Buffer.from(`${user}:${password}`).toString('base64') };
}

export function publishConfig() {
  return parsePublishConfig({ url: envValue('CASTELLANA_ADMIN_URL'), user: envValue('CASTELLANA_ADMIN_USER'), password: envValue('CASTELLANA_ADMIN_PASSWORD') });
}

export function lastPublish() { const r = readCacheRaw(LAST_KEY); return r.found ? r.value : null; }

/** Ce que l'écran peut voir : configuré ou non, hôte cible, dernier envoi. Jamais d'identifiant. */
export function publishStatus() {
  const cfg = publishConfig();
  return { configured: cfg.ok, target: cfg.ok ? cfg.host : null, reason: cfg.ok ? null : cfg.reason, last: lastPublish() };
}

/** Construit l'instantané depuis le dernier balayage en cache. null si aucun balayage. */
export function currentSweepSnapshot() {
  const r = readCacheRaw(screeningCacheKey('sp500'));
  if (!r.found) return null;
  const payload = r.value;
  const news = readCacheRaw('sweep:news');
  const sectorOf = new Map(SP500.tickers.map((t) => [t.ticker, t.sector]));
  return buildSweepSnapshot({
    payload,
    news: news.found ? news.value : null,
    sectors: sectorBreakdown(payload.rows, SP500.tickers),
    sectorOf,
    computedAt: payload.generatedAt || new Date(Date.now() - r.ageSeconds * 1000),
    source: news.found ? news.value.source : null,
  });
}

/** Envoie le dernier balayage. Ne lève jamais : renvoie et mémorise le résultat. */
export async function publishSweepSnapshot({ trigger = 'auto', fetchImpl = fetch } = {}) {
  const at = Date.now();
  const record = (r) => { const v = { at, trigger, ...r }; writeCache(LAST_KEY, v, KEEP); return v; };
  const cfg = publishConfig();
  if (!cfg.ok) return record({ ok: false, error: cfg.reason });
  let snap;
  try { snap = currentSweepSnapshot(); } catch (err) { return record({ ok: false, error: `Instantané impossible : ${err.message}` }); }
  if (!snap) return record({ ok: false, error: 'Aucun balayage S&P 500 à publier.' });
  const body = JSON.stringify(snap);
  try {
    const res = await fetchImpl(`${cfg.base}/api/admin/snapshots/sp500_sweep`, {
      method: 'PUT',
      headers: { Authorization: cfg.auth, 'Content-Type': 'application/json' },
      body,
      signal: AbortSignal.timeout(20_000),
    });
    let detail = null;
    try { detail = await res.json(); } catch { /* corps non JSON (ex. 401 texte) */ }
    if (!res.ok) return record({ ok: false, target: cfg.host, date: snap.date, error: `HTTP ${res.status}${detail?.error ? ' — ' + detail.error : res.status === 401 ? ' — identifiants admin refusés' : ''}` });
    return record({ ok: true, target: cfg.host, date: snap.date, computedAt: snap.computedAt, rows: snap.rows.length, bytes: Buffer.byteLength(body) });
  } catch (err) {
    return record({ ok: false, target: cfg.host, date: snap.date, error: `Envoi impossible : ${err.message}` });
  }
}
