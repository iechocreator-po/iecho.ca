// js/list-alerts-tab.js — carte « Alertes sur les listes » de l'onglet Screener
// (30/9/2026). LOCAL UNIQUEMENT : l'évaluation tourne sur ce Mac, tant que
// castellana est lancé. Déclenchement sur TRANSITION ; le premier passage d'une
// règle enregistre l'état actuel sans alerter. Voir server/list-alerts.js.

const laEsc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let laState = { types: [], rules: [], emailConfigured: false, autoRunMinutes: 0 };

function laListLabel(ref) {
  if (ref === 'watchlist') return 'Ma watchlist';
  if (ref === 'mag7') return 'MAG7';
  const l = (typeof customLists !== 'undefined' ? customLists : []).find((x) => 'list:' + x.id === ref);
  return l ? l.nom : ref;
}

function laParamsText(r) {
  const p = r.params;
  if (r.type === 'rsi_seuil') return `${p.sens === 'above' ? '≥' : '<'} ${p.seuil}`;
  if (r.type === 'resultats_imminents') return `≤ ${p.jours} j`;
  if (r.type === 'prime_put') return `≥ ${p.rendementMin} %/an`;
  return '—';
}

function laMsg(text, kind) {
  const el = document.getElementById('la-msg');
  el.textContent = text || '';
  el.style.color = kind === 'err' ? 'var(--red)' : kind === 'ok' ? 'var(--green)' : 'var(--text-2)';
}

function laListOptions() {
  const lists = (typeof customLists !== 'undefined' ? customLists : []).map((l) => `<option value="list:${l.id}">${laEsc(l.nom)}</option>`);
  return `<option value="watchlist">Ma watchlist</option><option value="mag7">MAG7</option>${lists.join('')}`;
}

function laParamFields(type) {
  if (type === 'rsi_seuil') return `<div class="field"><label>Sens</label><select class="ds-select" id="la-p-sens"><option value="above">au-dessus</option><option value="below">en dessous</option></select></div><div class="field"><label>Seuil</label><input class="ds-input" id="la-p-seuil" type="number" value="70"></div>`;
  if (type === 'resultats_imminents') return `<div class="field"><label>Jours avant</label><input class="ds-input" id="la-p-jours" type="number" value="7"></div>`;
  if (type === 'prime_put') return `<div class="field"><label>Rendement min. (%/an)</label><input class="ds-input" id="la-p-rendement" type="number" value="25"></div>`;
  return '';
}

function laRenderForm() {
  const typeSel = document.getElementById('la-type');
  if (!typeSel.options.length) typeSel.innerHTML = laState.types.map((t) => `<option value="${t.id}">${laEsc(t.label)}</option>`).join('');
  document.getElementById('la-list').innerHTML = laListOptions();
  document.getElementById('la-params').innerHTML = laParamFields(typeSel.value);
}

function laRenderRules() {
  const host = document.getElementById('la-rules');
  if (!laState.rules.length) { host.innerHTML = '<p class="metric-sub" style="text-align:left;">Aucune règle. Crée-en une ci-dessus.</p>'; return; }
  host.innerHTML = `<table class="ds-table"><thead><tr><th>Liste</th><th>Condition</th><th>Seuil</th><th>Courriel</th><th></th></tr></thead><tbody>${laState.rules.map((r) => `
    <tr${r.enabled ? '' : ' style="opacity:.55"'}><td>${laEsc(laListLabel(r.listRef))}</td><td>${laEsc(r.typeLabel)}</td><td>${laEsc(laParamsText(r))}</td>
    <td>${laEsc(r.email || '—')}</td>
    <td style="white-space:nowrap"><button type="button" class="ds-btn ds-btn--sm" data-la-toggle="${r.id}" data-on="${r.enabled ? 0 : 1}">${r.enabled ? 'Suspendre' : 'Réactiver'}</button>
    <button type="button" class="ds-btn ds-btn--sm" data-la-del="${r.id}">Supprimer</button></td></tr>`).join('')}</tbody></table>`;
  host.querySelectorAll('[data-la-toggle]').forEach((b) => b.addEventListener('click', async () => {
    try { await fetchJSON(`/api/list-alerts/rules/${b.dataset.laToggle}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ enabled: b.dataset.on === '1' }) }); }
    catch (err) { laMsg(err.message, 'err'); return; } // avant : promesse rejetée sans message à l'écran
    laLoad();
  }));
  host.querySelectorAll('[data-la-del]').forEach((b) => b.addEventListener('click', async () => {
    if (!confirm('Supprimer cette règle et son historique d\'alertes ?')) return;
    try { await fetchJSON(`/api/list-alerts/rules/${b.dataset.laDel}`, { method: 'DELETE' }); }
    catch (err) { laMsg(err.message, 'err'); return; }
    laLoad();
  }));
}

async function laLoadEvents() {
  const { events } = await fetchJSON('/api/list-alerts/events');
  const host = document.getElementById('la-events');
  const unread = events.filter((e) => !e.readAt).length;
  document.getElementById('la-unread').textContent = unread ? `${unread} non lue(s)` : '';
  host.innerHTML = events.length
    ? `<ul style="margin:0; padding-left:18px; line-height:1.6;">${events.slice(0, 30).map((e) => `<li${e.readAt ? ' style="opacity:.6"' : ''}><span class="ds-text-muted">${laEsc(e.createdAt)}</span> — ${laEsc(e.message)}</li>`).join('')}</ul>`
    : '<p class="metric-sub" style="text-align:left;">Aucune alerte pour l\'instant.</p>';
}

async function laLoad() {
  try {
    laState = { ...laState, ...(await fetchJSON('/api/list-alerts/rules')) };
    laRenderForm(); laRenderRules(); await laLoadEvents();
    document.getElementById('la-info').textContent = laState.autoRunMinutes > 0
      ? `Évaluation automatique toutes les ${laState.autoRunMinutes} min, jours ouvrables de 9 h à 17 h (New York), tant que castellana tourne sur ton Mac.`
      : 'Évaluation automatique désactivée (settings.json → listAlerts.autoRunMinutes). Utilise « Évaluer maintenant ».';
    document.getElementById('la-email-note').textContent = laState.emailConfigured ? '' : 'Aucune clé Resend locale : les alertes s\'affichent ici mais aucun courriel ne part (RESEND_API_KEY dans le fichier .env).';
  } catch (err) { laMsg(err.message, 'err'); }
}

async function laCreate() {
  const type = document.getElementById('la-type').value;
  const params = {};
  if (type === 'rsi_seuil') { params.sens = document.getElementById('la-p-sens').value; params.seuil = Number(document.getElementById('la-p-seuil').value); }
  if (type === 'resultats_imminents') params.jours = Number(document.getElementById('la-p-jours').value);
  if (type === 'prime_put') params.rendementMin = Number(document.getElementById('la-p-rendement').value);
  try {
    await fetchJSON('/api/list-alerts/rules', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ listRef: document.getElementById('la-list').value, type, params, email: document.getElementById('la-email').value.trim() || null }) });
    laMsg('Règle créée. Le premier passage enregistre l\'état actuel sans alerter ; les alertes suivront aux changements.', 'ok');
    laLoad();
  } catch (err) { laMsg(err.message, 'err'); }
}

async function laRun(btn) {
  btn.disabled = true; laMsg('Évaluation en cours…');
  try {
    const s = await fetchJSON('/api/list-alerts/run', { method: 'POST' });
    const bits = [`${s.rules} règle(s) évaluée(s)`, `${s.newAlerts} nouvelle(s) alerte(s)`];
    if (s.email.sent) bits.push(`${s.email.sent} courriel(s) envoyé(s)`);
    if (s.email.skipped) bits.push(`courriel non envoyé : ${s.email.skipped}`);
    if (s.errors.length) bits.push(`erreurs : ${s.errors.join(' ; ')}`);
    laMsg(bits.join(' · '), s.errors.length ? 'err' : 'ok');
    laLoad();
  } catch (err) { laMsg(err.message, 'err'); }
  btn.disabled = false;
}

function initListAlertsTab() {
  if (!document.getElementById('la-card')) return;
  document.getElementById('la-type').addEventListener('change', laRenderForm);
  document.getElementById('la-create').addEventListener('click', laCreate);
  document.getElementById('la-run').addEventListener('click', (e) => laRun(e.target));
  document.getElementById('la-read').addEventListener('click', async () => {
    try { await fetchJSON('/api/list-alerts/events/read', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }); }
    catch (err) { laMsg(err.message, 'err'); return; }
    laLoadEvents();
  });
  laLoad();
}
