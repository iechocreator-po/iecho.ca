// Modifications de l'administrateur sur l'onglet Concepts (20/9/2026).
// Le texte D'ORIGINE vit dans js/concepts-data.js (copie ESM générée) : la
// base ne garde que les fiches modifiées, et « réinitialiser » supprime la
// ligne — l'original revient tel quel, sans jamais avoir été écrasé.

import { CONCEPTS_TRADING } from '../lib/concepts-data.js';

export const MAX_TITRE = 200;
export const MAX_CORPS = 20000;

const BY_ID = new Map(CONCEPTS_TRADING.map((c) => [c.id, c]));

function invalid(message) {
  return Object.assign(new Error(message), { code: 'INVALID_CONCEPT' });
}

// { ema: { titre, corps }, … } — ce que castellana superpose au contenu par
// défaut. Une ligne dont l'id n'existe plus dans le catalogue est écartée.
export async function getOverrides(db) {
  const { results } = await db.prepare('SELECT concept_id, titre, corps FROM concept_overrides').all();
  const out = {};
  for (const r of results) if (BY_ID.has(r.concept_id)) out[r.concept_id] = { titre: r.titre, corps: r.corps };
  return out;
}

// Vue d'administration : les 15 fiches, avec l'original ET la version modifiée.
export async function listConceptsAdmin(db) {
  const { results } = await db.prepare('SELECT concept_id, titre, corps, updated_at FROM concept_overrides').all();
  const stored = new Map(results.map((r) => [r.concept_id, r]));
  return CONCEPTS_TRADING.map((c) => {
    const o = stored.get(c.id);
    return {
      id: c.id,
      defaultTitre: c.titre,
      defaultCorps: c.corps,
      titre: o ? o.titre : c.titre,
      corps: o ? o.corps : c.corps,
      overridden: Boolean(o),
      updatedAt: o?.updated_at ?? null,
    };
  });
}

export async function saveConcept(db, id, { titre, corps }) {
  const def = BY_ID.get(id);
  if (!def) throw Object.assign(new Error(`Concept inconnu : ${id}`), { code: 'UNKNOWN_CONCEPT' });
  const t = typeof titre === 'string' ? titre.trim() : '';
  const c = typeof corps === 'string' ? corps.trim() : '';
  if (!t) throw invalid('Le titre ne peut pas être vide.');
  if (!c) throw invalid('Le texte ne peut pas être vide.');
  if (t.length > MAX_TITRE) throw invalid(`Titre trop long (${t.length} > ${MAX_TITRE} caractères).`);
  if (c.length > MAX_CORPS) throw invalid(`Texte trop long (${c.length} > ${MAX_CORPS} caractères).`);
  // Identique à l'original (à l'espace près) : ce n'est pas une modification.
  if (t === def.titre.trim() && c === def.corps.trim()) {
    await db.prepare('DELETE FROM concept_overrides WHERE concept_id = ?').bind(id).run();
  } else {
    await db.prepare(`
      INSERT INTO concept_overrides (concept_id, titre, corps, updated_at) VALUES (?, ?, ?, datetime('now'))
      ON CONFLICT(concept_id) DO UPDATE SET titre = excluded.titre, corps = excluded.corps, updated_at = excluded.updated_at
    `).bind(id, t, c).run();
  }
  return listConceptsAdmin(db);
}

export async function resetConcept(db, id) {
  if (!BY_ID.has(id)) throw Object.assign(new Error(`Concept inconnu : ${id}`), { code: 'UNKNOWN_CONCEPT' });
  await db.prepare('DELETE FROM concept_overrides WHERE concept_id = ?').bind(id).run();
  return listConceptsAdmin(db);
}
