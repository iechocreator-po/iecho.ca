// Tests des formules pures de js/options-analytics.js (rendement annualisé,
// capital requis, probabilité d'assignation, crédit net de roulement) —
// évaluées via server/options-analytics.js, même patron que labo-params.js.
import test from 'node:test';
import assert from 'node:assert/strict';
import { optExpectedMove, optStraddleMove, optEmPosition, optIdealStrike, optCushion, optRuleLimit, optPickForChain, optPickPutForChain, optBetterPick, optComparePicks, optAnnualizedYield, optCapitalRequired, optAssignmentProbabilityLabel, optRollNetCredit, optionDelta, optionMarketZone } from './options-analytics.js';

// optionDelta/optionMarketZone : déplacés depuis js/options-tab.js (22/9/2026,
// réutilisés côté serveur pour la grille de rendement annualisé et le
// screener de primes) — tests inchangés, migrés depuis options-tab.test.js.

test('delta call à la monnaie ≈ 0,5 (un peu plus avec le taux), put = call - 1', () => {
  const c = optionDelta('call', 100, 100, 30, 0.04, 0.3);
  const p = optionDelta('put', 100, 100, 30, 0.04, 0.3);
  assert.ok(c > 0.5 && c < 0.6, `call ${c}`);
  assert.ok(Math.abs(c - p - 1) < 1e-9);
});

test('delta : call très dans la monnaie → proche de 1, très hors → proche de 0', () => {
  assert.ok(optionDelta('call', 100, 50, 30, 0.04, 0.3) > 0.99);
  assert.ok(optionDelta('call', 100, 200, 30, 0.04, 0.3) < 0.01);
});

test('delta : entrées absentes ou peu fiables → null, jamais un chiffre inventé', () => {
  assert.equal(optionDelta('call', 100, 100, 30, 0.04, null), null);
  assert.equal(optionDelta('call', 100, 100, 30, 0.04, 0.00001), null); // IV de bruit
  assert.equal(optionDelta('call', 100, 100, 0, 0.04, 0.3), null);      // échéance du jour
  assert.equal(optionDelta('put', null, 100, 30, 0.04, 0.3), null);
});

test('zone de marché : strikes dont |delta| est dans la plage', () => {
  const cs = [{ strike: 90, delta: -0.1 }, { strike: 95, delta: -0.2 }, { strike: 98, delta: -0.24 }, { strike: 100, delta: -0.5 }, { strike: 80, delta: null }];
  assert.deepEqual(optionMarketZone(cs, 0.15, 0.25), { basse: 95, haute: 98, n: 2 });
  assert.equal(optionMarketZone(cs, 0.7, 0.9), null);
});

test('rendement annualisé : prime/strike × 365/DTE × 100', () => {
  // 1$ de prime sur un strike de 50$, 36.5 jours → (1/50) × 10 × 100 = 20%.
  assert.equal(optAnnualizedYield(1, 50, 36.5), 20);
  // DTE plus court, même prime/strike → rendement annualisé plus élevé.
  assert.ok(optAnnualizedYield(1, 50, 10) > optAnnualizedYield(1, 50, 30));
});

test('rendement annualisé : entrée manquante ou invalide → null, jamais 0', () => {
  assert.equal(optAnnualizedYield(null, 50, 30), null);
  assert.equal(optAnnualizedYield(0, 50, 30), null);
  assert.equal(optAnnualizedYield(1, 0, 30), null);
  assert.equal(optAnnualizedYield(1, 50, 0), null);
  assert.equal(optAnnualizedYield(1, 50, null), null);
});

test('capital requis : strike × contractSize × contrats', () => {
  assert.equal(optCapitalRequired(50, 100, 1), 5000);
  assert.equal(optCapitalRequired(50, 100, 3), 15000);
  assert.equal(optCapitalRequired(null, 100, 1), null);
  assert.equal(optCapitalRequired(50, 100, 0), null);
});

test('probabilité d\'assignation : |delta| → pct + repère verbal', () => {
  assert.deepEqual(optAssignmentProbabilityLabel(-0.20), { pct: 20, label: 'modérée' });
  assert.deepEqual(optAssignmentProbabilityLabel(0.10), { pct: 10, label: 'faible' });
  assert.deepEqual(optAssignmentProbabilityLabel(-0.45), { pct: 45, label: 'élevée' });
  assert.equal(optAssignmentProbabilityLabel(null), null);
  assert.equal(optAssignmentProbabilityLabel(NaN), null);
});

test('crédit net de roulement : (prime encaissée - prime de rachat) × taille × contrats', () => {
  // Encaisse 2$ en vendant le nouveau, rachète l'ancien pour 0.50$ → crédit net.
  assert.equal(optRollNetCredit(2, 0.5, 100, 1), 150);
  // Rachat plus cher que la nouvelle prime encaissée → débit net (négatif).
  assert.equal(optRollNetCredit(0.5, 2, 100, 1), -150);
  assert.equal(optRollNetCredit(null, 0.5, 100, 1), null);
  assert.equal(optRollNetCredit(2, 0.5, 100, 0), null);
});

test('règle de prime minimale : 0,5 % du strike par 5 jours, proportionnel à l\'échéance', async () => {
  const { optPremiumRule } = await import('./options-analytics.js');
  // Put OTM strike 100, 5 j : seuil 0,50 $. Bid 0,60 → respecte (1,2×).
  const a = optPremiumRule('put', 110, 100, 0.6, 5, 0.5, 5);
  assert.ok(Math.abs(a.required - 0.5) < 1e-9 && a.ok && Math.abs(a.ratio - 1.2) < 1e-9);
  // 10 j : seuil 1 $ (1 %). Même bid 0,60 → échoue.
  const b = optPremiumRule('put', 110, 100, 0.6, 10, 0.5, 5);
  assert.ok(Math.abs(b.required - 1) < 1e-9 && !b.ok && Math.abs(b.requiredPct - 1) < 1e-9);
  // Variante 1 % / 10 j à 10 j : même seuil de 1 $.
  assert.ok(Math.abs(optPremiumRule('put', 110, 100, 1, 10, 1, 10).required - 1) < 1e-9);
});

test('règle de prime minimale : un ITM profond est jugé sur sa valeur temps, pas le bid brut', async () => {
  const { optPremiumRule } = await import('./options-analytics.js');
  // Call strike 80 avec le sous-jacent à 100 : bid 20,30 dont 20 intrinsèques → 0,30 de temps.
  const r = optPremiumRule('call', 100, 80, 20.3, 5, 0.5, 5);
  assert.ok(Math.abs(r.premium - 0.3) < 1e-9 && !r.ok); // seuil 0,40
});

test('règle de prime minimale : intrant manquant → null, jamais un verdict inventé', async () => {
  const { optPremiumRule } = await import('./options-analytics.js');
  assert.equal(optPremiumRule('put', 100, 100, null, 5, 0.5, 5), null);
  assert.equal(optPremiumRule('put', 100, 100, 1, 0, 0.5, 5), null);
  assert.equal(optPremiumRule('put', 100, 100, 1, 5, 0, 5), null);
});

// ---- Marge, strike limite et choix du put (4/10/2026) ----
test('marge : distance en % du prix et en écarts-types attendus', () => {
  const c = optCushion('put', 100, 93, 0.5, 5);
  assert.ok(Math.abs(c.distancePct - 7) < 1e-9);
  assert.ok(Math.abs(c.sigmaMargin - 0.07 / (0.5 * Math.sqrt(5 / 365))) < 1e-9);
  // Call : distance vers le haut ; dans la monnaie → négative.
  assert.ok(Math.abs(optCushion('call', 100, 108, 0.4, 10).distancePct - 8) < 1e-9);
  assert.ok(optCushion('put', 100, 105, 0.4, 10).distancePct < 0);
  // IV de bruit, échéance du jour, prix absent → null, jamais une marge inventée.
  assert.equal(optCushion('put', 100, 93, 0.001, 5), null);
  assert.equal(optCushion('put', 100, 93, 0.5, 0), null);
  assert.equal(optCushion('put', null, 93, 0.5, 5), null);
});

const LIMIT_PUTS = [
  { strike: 99, bid: 2.0, iv: 0.5 }, { strike: 98, bid: null, iv: 0.5 }, { strike: 97, bid: 1.0, iv: 0.5 },
  { strike: 95, bid: 0.3, iv: 0.5 }, { strike: 90, bid: 0.6, iv: 0.5 }, // 90 : cotation isolée/périmée
];

test('strike limite (put) : le plus éloigné qui respecte la règle, sans se laisser tromper par une cotation isolée', () => {
  // Seuil à 5 j, 0,5 %/5 j : 0,495 $ à 99, 0,485 $ à 97, 0,475 $ à 95 (0,3 → échoue), 0,45 $ à 90 (0,6 passerait seul).
  assert.equal(optRuleLimit('put', 100, LIMIT_PUTS, 5, 0.5, 5).strike, 97);
});

test('strike limite : rien ne passe → null ; call = miroir ; contrats dans la monnaie ignorés', () => {
  assert.equal(optRuleLimit('put', 100, [{ strike: 99, bid: 0.1 }], 5, 0.5, 5), null);
  assert.equal(optRuleLimit('put', 100, [{ strike: 105, bid: 9 }], 5, 0.5, 5), null); // ITM
  const calls = [{ strike: 101, bid: 2 }, { strike: 103, bid: 1 }, { strike: 105, bid: 0.2 }];
  assert.equal(optRuleLimit('call', 100, calls, 5, 0.5, 5).strike, 103);
});

test('choix du put : « limite » prend le plus éloigné (delta max = plafond), « rendement » le meilleur rendement', () => {
  const chain = { ticker: 'T', price: 100, expiry: '2026-10-09', dte: 5, puts: LIMIT_PUTS };
  const base = { deltaMin: 0, deltaMax: 0.9, r: 0.04, rulePct: 0.5, rulePeriodDays: 5 };
  const lim = optPickPutForChain(chain, { ...base, mode: 'limite' });
  assert.equal(lim.strike, 97);
  assert.ok(lim.distancePct > 2.9 && lim.sigmaMargin > 0 && lim.ruleRatio >= 1);
  // Plafond de delta trop bas : aucun put ne convient → null (jamais un put au delta trop haut).
  assert.equal(optPickPutForChain(chain, { ...base, deltaMax: 0.0001, mode: 'limite' }), null);
  // Rendement : le plus gros bid/strike de la plage, donc le plus proche du prix.
  const rend = optPickPutForChain(chain, { ...base, mode: 'rendement' });
  assert.equal(rend.strike, 99);
});

test('entre deux échéances : « limite » compare les marges en σ, « rendement » les rendements', () => {
  const a = { sigmaMargin: 1.0, annualizedYield: 90 };
  const b = { sigmaMargin: 1.4, annualizedYield: 60 };
  assert.equal(optBetterPick('limite', a, b), b);
  assert.equal(optBetterPick('rendement', a, b), a);
  assert.equal(optBetterPick('limite', null, b), b);
});

test('repli « sous la règle » : sans strike qui la respecte sous le plafond de delta, on garde le put le plus proche du plafond', () => {
  // Puts trop maigres : aucun n'atteint 0,5 % / 5 j (seuil ≈ 0,5 $ à 5 jours pour un strike de 100).
  const chain = { ticker: 'T', price: 100, expiry: '2026-10-09', dte: 5, puts: [
    { strike: 99, bid: 0.3, iv: 0.35 }, { strike: 96, bid: 0.1, iv: 0.35 }, { strike: 92, bid: 0.02, iv: 0.35 },
  ] };
  const o = { mode: 'limite', deltaMin: 0, deltaMax: 0.9, r: 0.04, rulePct: 0.5, rulePeriodDays: 5 };
  const p = optPickPutForChain(chain, o);
  assert.equal(p.sousRegle, true);
  assert.equal(p.strike, 99); // le plus proche du prix = la plus grosse prime permise
  assert.ok(p.ruleRatio < 1 && p.premiumPct < p.requiredPct); // 0,30 % pour ≈ 0,5 % exigé : on voit où on en est
  // Un put qui respecte la règle n'est pas marqué.
  const ok = optPickPutForChain({ ...chain, puts: [{ strike: 99, bid: 2, iv: 0.5 }] }, o);
  assert.equal(ok.sousRegle, false);
});

test('tri « limite » : ceux qui respectent la règle d\'abord (par marge σ), puis les replis par proximité du seuil', () => {
  const rows = [
    { t: 'repli-loin', sousRegle: true, ruleRatio: 0.4 }, { t: 'ok-petit', sousRegle: false, sigmaMargin: 1.0 },
    { t: 'repli-proche', sousRegle: true, ruleRatio: 0.9 }, { t: 'ok-grand', sousRegle: false, sigmaMargin: 1.5 },
  ].sort(optComparePicks('limite')).map((r) => r.t);
  assert.deepEqual(rows, ['ok-grand', 'ok-petit', 'repli-proche', 'repli-loin']);
  // Entre deux échéances d'un même titre, un put conforme bat un repli.
  assert.equal(optBetterPick('limite', { sousRegle: true, ruleRatio: 0.95 }, { sousRegle: false, sigmaMargin: 0.5 }).sousRegle, false);
});

test('choix d\'un call : le plus éloigné AU-DESSUS du prix qui respecte la règle (miroir du put)', () => {
  const calls = [{ strike: 101, bid: 2.0, iv: 0.5 }, { strike: 103, bid: 1.0, iv: 0.5 }, { strike: 106, bid: 0.3, iv: 0.5 }];
  const chain = { ticker: 'T', price: 100, expiry: '2026-10-09', dte: 5, puts: [], calls };
  const o = { type: 'call', mode: 'limite', deltaMin: 0, deltaMax: 0.9, r: 0.04, rulePct: 0.5, rulePeriodDays: 5 };
  const c = optPickForChain(chain, o);
  assert.equal(c.strike, 103);
  assert.ok(c.distancePct > 2.9 && c.sousRegle === false);
  assert.equal(optPickForChain(chain, { ...o, mode: 'rendement' }).strike, 101);
  // Défaut = put : un appel sans `type` ne lit jamais les calls.
  assert.equal(optPickForChain({ ...chain, puts: [] }, { ...o, type: undefined }), null);
});

test('optExpectedMove : prix × IV × √(DTE/365) × k, null si entrée manquante', () => {
  const m = optExpectedMove(100, 0.5, 30, 1);
  assert.ok(Math.abs(m.em - 100 * 0.5 * Math.sqrt(30 / 365)) < 1e-9);
  assert.ok(Math.abs(m.low - (100 - m.em)) < 1e-9 && Math.abs(m.high - (100 + m.em)) < 1e-9);
  const m2 = optExpectedMove(100, 0.5, 30, 2);
  assert.ok(Math.abs(m2.em - 2 * m.em) < 1e-9);
  assert.equal(optExpectedMove(100, null, 30), null);
  assert.equal(optExpectedMove(100, 0.001, 30), null);
  assert.equal(optExpectedMove(100, 0.5, 0), null);
  assert.equal(optExpectedMove(null, 0.5, 30), null);
  assert.equal(optExpectedMove(100, 0.5, 30, 0), null);
});

test('optEmPosition : put hors plage sous la borne basse, call au-dessus de la haute', () => {
  const m = optExpectedMove(100, 0.5, 30, 1); // em ≈ 14,33
  assert.equal(optEmPosition('put', 80, m).outside, true);
  assert.equal(optEmPosition('put', 90, m).outside, false);
  assert.equal(optEmPosition('call', 120, m).outside, true);
  assert.equal(optEmPosition('call', 110, m).outside, false);
  assert.ok(optEmPosition('put', 80, m).emMargin > 0 && optEmPosition('put', 90, m).emMargin < 0);
  assert.equal(optEmPosition('put', 80, null), null);
});

test('optStraddleMove : (mid call + mid put) ÷ √(2/π), cohérent avec l\'EM par l\'IV', () => {
  const calls = [{ strike: 95, bid: 7, ask: 7.4 }, { strike: 100, bid: 4, ask: 4.2 }];
  const puts = [{ strike: 95, bid: 1.9, ask: 2.1 }, { strike: 100, bid: 3.8, ask: 4.0 }];
  const r = optStraddleMove(101, calls, puts);
  assert.equal(r.strike, 100);
  assert.ok(Math.abs(r.straddle - (4.1 + 3.9)) < 1e-9 && Math.abs(r.em - 8 / Math.sqrt(2 / Math.PI)) < 1e-9);
  assert.equal(optStraddleMove(101, [{ strike: 100, bid: 0, ask: 0 }], puts), null);
  // cohérence théorique : un straddle ATM idéal (0,8 × EM) redonne l'EM par l'IV
  const m = optExpectedMove(100, 0.5, 30, 1);
  const half = (m.em1 * Math.sqrt(2 / Math.PI)) / 2;
  const ideal = optStraddleMove(100, [{ strike: 100, bid: half, ask: half }], [{ strike: 100, bid: half, ask: half }]);
  assert.ok(Math.abs(ideal.em - m.em1) < 1e-9);
});

test('optIdealStrike : premier strike hors plage ; failsRule si la règle échoue ; null sans contrat', () => {
  const m = optExpectedMove(100, 0.5, 30, 1); // low ≈ 85,67
  const puts = [
    { strike: 90, bid: 3.0 }, { strike: 85, bid: 1.2 }, { strike: 80, bid: 0.6 }, { strike: 75, bid: 0.2 },
  ];
  // règle 0,5 %/5 j à 30 j → 3 % du strike : 85 → 2,55 $ requis, bid 1,2 → échoue
  const r = optIdealStrike('put', 100, puts, 30, 0.5, 5, m);
  assert.equal(r.contract.strike, 85);
  assert.equal(r.failsRule, true);
  // règle plus douce (0,1 %/5 j → 0,6 % du strike = 0,51 $) → 85 passe
  const r2 = optIdealStrike('put', 100, puts, 30, 0.1, 5, m);
  assert.equal(r2.contract.strike, 85);
  assert.equal(r2.failsRule, undefined);
  assert.equal(optIdealStrike('put', 100, [{ strike: 90, bid: 3 }], 30, 0.5, 5, m), null);
  assert.equal(optIdealStrike('put', 100, puts, 30, 0.5, 5, null), null);
});

test('optPickForChain expose atmIv (IV à la monnaie de l\'échéance) pour l\'expected move', () => {
  const mk = (strike, iv) => ({ strike, iv, bid: 1, ask: 1.2 });
  const chain = { price: 100, dte: 30, expiry: '2026-11-13',
    calls: [mk(95, 0.5), mk(100, 0.5), mk(105, 0.5)], puts: [mk(95, 0.5), mk(100, 0.5), mk(105, 0.5), mk(90, 0.5)] };
  const pick = optPickForChain(chain, { type: 'put', mode: 'rendement', deltaMin: 0.01, deltaMax: 0.9, r: 0.04, rulePct: 0.5, rulePeriodDays: 5 });
  assert.ok(pick && Math.abs(pick.atmIv - 0.5) < 1e-9);
  const m = optExpectedMove(pick.price, pick.atmIv, pick.dte, 1);
  assert.ok(Math.abs(m.em - 100 * 0.5 * Math.sqrt(30 / 365)) < 1e-9);
});
