// server/deal-scanner.js — Radar (22/9/2026) : screener multi-titres de
// meilleurs deals d'options, LOCAL UNIQUEMENT (décision explicite de JP —
// aucun plafond Cloudflare en local, seul le rythme prudent face à Yahoo
// reste nécessaire ; voir CLAUDE.md pour le raisonnement complet). Jamais
// de pendant cloud.
//
// Principe central : un seul fetch de chaîne par titre sert les DEUX modes
// (vente/achat) et les deux types (put/call) — optScoreDeal() est un calcul
// local bon marché sur des données déjà en mémoire, seul le fetch Yahoo est
// coûteux/limité.
import { SECTOR_TOP_CANDIDATES } from './sectors.js';
import { SP500 } from './screening.js';
import { getOptionChain } from './options.js';
import { getHomemadeIndicatorsBatch } from './indicators.js';
import { getFundamentalsBatch } from './fundamentals.js';
import { mapWithConcurrency } from './fetch-retry.js';
import { optionDelta, optScoreDeal, optAtmIv, optIvRank, optPickForChain, optBetterPick, optComparePicks } from './options-analytics.js';
import { getEffectiveParams } from './labo-params.js';
import { getIvHistories } from './iv-rank.js';
import { db } from './db.js';

const DTE_MIN = 25;
const DTE_MAX = 45;
// Deux fenêtres de scan (4/10/2026) : « standard » (historique d'IV, deals à
// 25-45 j) et « hebdo » (Roue à courte échéance, règle de prime). Un scan hebdo
// ne nourrit PAS l'historique d'IV (voir server/iv-rank.js).
export const SCAN_WINDOWS = { standard: { dteMin: 25, dteMax: 45 }, hebdo: { dteMin: 5, dteMax: 10 } };
const WEEKLY_TTL_DAYS = 7;
const CHAIN_CONCURRENCY = 2; // prudent — jamais testé à ce volume, ajusté après un vrai run

let scanEnCours = false;

export function isScanRunning() {
  return scanEnCours;
}

export function universeTickers(univers = 'elargi') {
  if (univers === 'sp500') return SP500.tickers.map((t) => t.ticker);
  return [...new Set(Object.values(SECTOR_TOP_CANDIDATES).flat())];
}

// Inversé depuis SECTOR_TOP_CANDIDATES (déjà groupé par secteur) — pour la
// diversification de la présentation, pas une nouvelle curation.
export function buildTickerToSector() {
  const m = new Map();
  for (const [sectorKey, tickers] of Object.entries(SECTOR_TOP_CANDIDATES)) {
    for (const t of tickers) if (!m.has(t)) m.set(t, sectorKey);
  }
  for (const t of SP500.tickers) if (!m.has(t.ticker)) m.set(t.ticker, t.sector); // S&P 500 : secteur GICS (anglais)
  return m;
}

// Pure, testable séparément du fetch réseau.
export function firstExpiryInWindow(expirations, dteMin, dteMax) {
  return (expirations || []).find((e) => e.dte >= dteMin && e.dte <= dteMax) || null;
}

// Un contrat dont l'échéance dépasse la date de résultats prévue est
// EXCLU (pas juste signalé) — un screener qui curate une liste doit
// trancher, contrairement à la vue Options A qui affiche tout et alerte.
export function isEarningsExcluded(daysToEarnings, dte) {
  return daysToEarnings != null && daysToEarnings >= 0 && daysToEarnings < dte;
}

// Pure : un titre a-t-il des échéances HEBDOMADAIRES ? Les titres à options
// mensuelles seulement ont des échéances espacées d'environ 4 semaines : au plus
// une tombe dans les 21 prochains jours. Un titre hebdo en a au moins deux.
export function hasWeeklyExpirations(expirations) {
  const near = (expirations || []).filter((e) => e.dte >= 1 && e.dte <= 21);
  return near.length >= 2;
}

const getWeeklyStmt = db.prepare("SELECT has_weekly, checked_at FROM weekly_support WHERE ticker = ?");
const setWeeklyStmt = db.prepare("INSERT INTO weekly_support (ticker, has_weekly, checked_at) VALUES (?, ?, datetime('now')) ON CONFLICT(ticker) DO UPDATE SET has_weekly = excluded.has_weekly, checked_at = excluded.checked_at");
// Vrai = connu SANS hebdo et vérifié il y a moins de WEEKLY_TTL_DAYS jours.
export function knownWithoutWeekly(ticker) {
  const r = getWeeklyStmt.get(ticker);
  if (!r || r.has_weekly) return false;
  const ageMs = Date.now() - new Date(`${r.checked_at.replace(' ', 'T')}Z`).getTime();
  return ageMs < WEEKLY_TTL_DAYS * 86400000;
}

// Au plus 2 appels Yahoo par titre : le fetch par défaut (échéance la plus
// proche) + un second SEULEMENT si l'échéance ciblée n'est pas déjà celle-là.
async function chainInWindow(ticker, { dteMin, dteMax, hebdo = false } = {}) {
  if (hebdo && knownWithoutWeekly(ticker)) return { sansHebdo: true }; // zéro appel réseau
  const first = await getOptionChain(ticker);
  if (hebdo) setWeeklyStmt.run(ticker, hasWeeklyExpirations(first.expirations) ? 1 : 0);
  const match = firstExpiryInWindow(first.expirations, dteMin, dteMax);
  if (!match) return null; // aucune échéance dans la fenêtre : titre ignoré, pas une erreur
  if (match.date === first.expiry) return first;
  return getOptionChain(ticker, { expiry: match.date });
}

// Pure : note tous les contrats d'une chaîne pour les 2 modes × 2 types.
// Un contrat sans marché exploitable (optScoreDeal → null) n'est JAMAIS
// persisté — même discipline que la vue chaîne d'Options A.
export function scoreChainContracts(chain, ctx) {
  const rows = [];
  // Première passe : delta de chaque contrat (nécessaire pour l'IV à la monnaie).
  const contracts = [];
  for (const [type, list] of [['put', chain.puts], ['call', chain.calls]]) {
    for (const c of list) {
      contracts.push({ ...c, type, delta: optionDelta(type, chain.price, c.strike, chain.dte, ctx.riskFreeRate, c.iv) });
    }
  }
  // IV Rank (#377) : IV à la monnaie d'AUJOURD'HUI vs l'historique accumulé du
  // Radar. null tant que l'historique est insuffisant → repli sur le proxy HV.
  const rankInfo = ctx.ivHistory ? optIvRank(ctx.ivHistory, optAtmIv(contracts)) : null;
  const ivRank = rankInfo ? rankInfo.rank : null;
  for (const contract of contracts) {
    const { type, delta } = contract;
    const c = contract;
    const scoreCtx = { dte: chain.dte, price: chain.price, historicalVolatility: ctx.historicalVolatility, ivRank };
    const excluMotif = ctx.earningsUnknown ? 'resultats_inconnus' : (isEarningsExcluded(ctx.daysToEarnings, chain.dte) ? 'resultats_avant_echeance' : null);
    for (const mode of ['vente', 'achat']) {
      const scored = optScoreDeal(mode, contract, scoreCtx);
      if (!scored) continue;
      rows.push({
        ticker: chain.ticker, secteur: ctx.secteur ?? null, type, mode,
        strike: c.strike, echeance: chain.expiry, dte: chain.dte,
        bid: c.bid, ask: c.ask, iv: c.iv, delta,
        historicalVolatility: ctx.historicalVolatility ?? null,
        liquidityScore: scored.liquidity.score,
        valuationScore: scored.valorisation ? scored.valorisation.score : null,
        returnScore: scored.rendement ? scored.rendement.score : null,
        totalScore: scored.total,
        verdict: scored.verdict,
        metric: scored.rendement ? scored.rendement.metric : null,
        daysToEarnings: ctx.daysToEarnings ?? null,
        ivRank,
        excluMotif,
        price: chain.price ?? null,
      });
    }
  }
  return rows;
}

// Diversification appliquée à la PRÉSENTATION, pas à la donnée — le
// classement brut reste entièrement consultable via includeExcluded/limite
// large. `rows` doit déjà être trié par score décroissant.
export function applyDiversityCap(rows, { maxPerSector = 2 } = {}) {
  const perSector = new Map();
  const out = [];
  for (const r of rows) {
    const key = r.secteur || '__inconnu__';
    const count = perSector.get(key) || 0;
    if (count >= maxPerSector) continue;
    perSector.set(key, count + 1);
    out.push(r);
  }
  return out;
}

const insertScanStmt = db.prepare('INSERT INTO deal_scans (total_tickers, fenetre, univers) VALUES (?, ?, ?)');
const setSansHebdoStmt = db.prepare('UPDATE deal_scans SET sans_hebdo = ? WHERE id = ?');
const updateProgressStmt = db.prepare('UPDATE deal_scans SET tickers_scannes = ? WHERE id = ?');
const finishScanStmt = db.prepare("UPDATE deal_scans SET statut = ?, completed_at = datetime('now'), erreurs_json = ? WHERE id = ?");
const insertResultStmt = db.prepare(`INSERT INTO deal_results
  (scan_id, ticker, secteur, type, mode, strike, echeance, dte, bid, ask, iv, delta, historical_volatility,
   liquidity_score, valuation_score, return_or_leverage_score, total_score, verdict, metric, days_to_earnings, exclu_motif, iv_rank, price)
  VALUES (@scanId, @ticker, @secteur, @type, @mode, @strike, @echeance, @dte, @bid, @ask, @iv, @delta, @historicalVolatility,
   @liquidityScore, @valuationScore, @returnScore, @totalScore, @verdict, @metric, @daysToEarnings, @excluMotif, @ivRank, @price)`);
const insertManyResults = db.transaction((scanId, rows) => {
  for (const r of rows) insertResultStmt.run({ scanId, ...r });
});

// Crée la ligne de scan SYNCHRONE (pour que la route puisse répondre
// immédiatement avec l'id) ; le scan lui-même tourne en tâche de fond via
// runDealScan(), appelée sans attendre depuis la route.
export function createScan(fenetre = 'standard', univers = 'elargi') {
  if (!SCAN_WINDOWS[fenetre]) throw new Error(`Fenêtre de scan inconnue : ${fenetre}`);
  if (univers === 'sp500' && fenetre !== 'hebdo') throw new Error('Le S&P 500 ne se scanne qu\'en fenêtre hebdo (5-10 j).');
  const tickers = universeTickers(univers);
  const info = insertScanStmt.run(tickers.length, fenetre, univers);
  return { scanId: info.lastInsertRowid, tickers };
}

// Enveloppe (audit onglets locaux, 21/10/2026) : toute exception hors de la boucle par titre laissait `scanEnCours` à vrai jusqu'au redémarrage
// (la route /start répondait 409 pour toujours) et la ligne 'en_cours' orpheline faisait boucler le suivi du navigateur.
export async function runDealScan(scanId, tickers, options = {}) {
  scanEnCours = true;
  try {
    return await runDealScanCore(scanId, tickers, options);
  } catch (err) {
    try { finishScanStmt.run('erreur', JSON.stringify([{ ticker: null, message: err.message }]), scanId); } catch { /* base indisponible : rien de plus à faire */ }
    throw err;
  } finally {
    scanEnCours = false;
  }
}

async function runDealScanCore(scanId, tickers, { dteMin = DTE_MIN, dteMax = DTE_MAX, fenetre = 'standard' } = {}) {
  const hebdo = fenetre === 'hebdo';
  let sansHebdo = 0;
  const tickerToSector = buildTickerToSector();
  const { riskFreePct } = getEffectiveParams('roue') || { riskFreePct: 4 };
  const riskFreeRate = riskFreePct / 100;

  const [indicRows, fundRows] = await Promise.all([
    getHomemadeIndicatorsBatch(tickers),
    getFundamentalsBatch(tickers, { withVwap: false }),
  ]);
  const indicByTicker = new Map(indicRows.map((x) => [x.ticker, x]));
  const fundByTicker = new Map(fundRows.map((x) => [x.ticker, x]));
  // Historique d'IV lu AVANT d'insérer les résultats de ce scan : le rang du jour
  // se compare à des jours PASSÉS, jamais à lui-même.
  const ivHistories = getIvHistories(tickers);

  const erreurs = [];
  let scanned = 0;
  let reussis = 0;
  // Un titre dont les fondamentaux ont échoué n'a pas de date de résultats connue : « inconnu » n'est pas « aucun résultat prévu ».
  for (const f of fundRows) if (f.error) erreurs.push({ ticker: f.ticker, message: 'fondamentaux indisponibles : ' + f.error });

  await mapWithConcurrency(tickers, async (ticker) => {
    try {
      const chain = await chainInWindow(ticker, { dteMin, dteMax, hebdo });
      if (chain?.sansHebdo) sansHebdo++;
      else if (chain) {
        const rows = scoreChainContracts(chain, {
          secteur: tickerToSector.get(ticker),
          riskFreeRate,
          historicalVolatility: indicByTicker.get(ticker)?.historicalVolatility ?? null,
          daysToEarnings: fundByTicker.get(ticker)?.daysToEarnings ?? null,
          earningsUnknown: !!fundByTicker.get(ticker)?.error,
          // Hebdo : pas d'IV Rank (l'historique est à 25-45 j, non comparable).
          ivHistory: hebdo ? null : (ivHistories.get(ticker) || []).map((h) => h.iv),
        });
        if (rows.length) insertManyResults(scanId, rows);
      }
      reussis++;
    } catch (err) {
      erreurs.push({ ticker, message: err.message });
    } finally {
      scanned++;
      updateProgressStmt.run(scanned, scanId);
    }
  }, { limit: CHAIN_CONCURRENCY });

  setSansHebdoStmt.run(sansHebdo, scanId);
  // 'erreur' si AUCUN titre n'a pu être lu (avant : `scanned > 0` était toujours vrai, un scan en panne s'affichait « terminé »).
  finishScanStmt.run(reussis > 0 ? 'termine' : 'erreur', JSON.stringify(erreurs), scanId);
  return getScan(scanId);
}

export function getScan(scanId) {
  return db.prepare('SELECT * FROM deal_scans WHERE id = ?').get(scanId);
}

export function listScans(limit = 20, univers = 'elargi') {
  return db.prepare('SELECT * FROM deal_scans WHERE univers = ? ORDER BY started_at DESC LIMIT ?').all(univers, limit);
}

export function getResults(scanId, { mode = 'vente', type, diversifie = false, maxPerSector = 2, limit = 20, includeExcluded = false } = {}) {
  let sql = 'SELECT * FROM deal_results WHERE scan_id = ? AND mode = ?';
  const params = [scanId, mode];
  if (!includeExcluded) sql += ' AND exclu_motif IS NULL';
  if (type) { sql += ' AND type = ?'; params.push(type); }
  sql += ' ORDER BY total_score DESC, metric DESC';
  let rows = db.prepare(sql).all(...params);
  if (diversifie) rows = applyDiversityCap(rows, { maxPerSector });
  return rows.slice(0, limit);
}

export function getLatestScan(fenetre = 'standard', univers = 'elargi') {
  return db.prepare("SELECT * FROM deal_scans WHERE statut = 'termine' AND fenetre = ? AND univers = ? ORDER BY id DESC LIMIT 1").get(fenetre, univers) || null;
}

// G2 sur l'univers élargi (local, 4/10/2026) : relit le dernier scan HEBDO terminé
// au lieu d'interroger 219 chaînes. Même forme de ligne que screenPremiums() et
// MÊME logique de choix (optPickPutForChain : « limite » ou « rendement »), appliquée
// aux contrats déjà stockés. Un scan d'avant l'ajout de la colonne `price` n'a pas
// le prix du sous-jacent : ses lignes sont comptées dans `sansPrix` et ignorées
// (la marge en serait fausse) — relancer un scan hebdo les remplace.
export function premiumRowsFromScan({ deltaMin, deltaMax, dteMin, dteMax, mode = 'rendement', rulePct = 0.5, rulePeriodDays = 5, type = 'put', univers = 'elargi' }) {
  type = type === 'call' ? 'call' : 'put';
  const scan = getLatestScan('hebdo', univers);
  if (!scan) return null;
  const rows = db.prepare(`SELECT ticker, echeance, dte, strike, bid, iv, price, historical_volatility, days_to_earnings
    FROM deal_results WHERE scan_id = ? AND mode = 'vente' AND type = ? AND bid > 0 AND strike > 0 AND dte BETWEEN ? AND ?`).all(scan.id, type, dteMin, dteMax);
  const { riskFreePct } = getEffectiveParams('roue') || { riskFreePct: 4 };
  const r = riskFreePct / 100;
  const byChain = new Map();
  let sansPrix = 0;
  for (const x of rows) {
    if (!(x.price > 0)) { sansPrix++; continue; }
    const k = `${x.ticker}|${x.echeance}`;
    if (!byChain.has(k)) byChain.set(k, { ticker: x.ticker, expiry: x.echeance, dte: x.dte, price: x.price, puts: [], calls: [], hv: x.historical_volatility, earnings: x.days_to_earnings });
    byChain.get(k)[type === 'put' ? 'puts' : 'calls'].push({ strike: x.strike, bid: x.bid, iv: x.iv });
  }
  const best = new Map();
  for (const ch of byChain.values()) {
    const pick = optPickForChain(ch, { type, mode, deltaMin, deltaMax, r, rulePct, rulePeriodDays });
    if (!pick) continue;
    const row = { ticker: ch.ticker, error: null, ...pick, historicalVolatility: ch.hv ?? null, daysToEarnings: ch.earnings ?? null };
    const cur = best.get(ch.ticker);
    best.set(ch.ticker, cur ? optBetterPick(mode, cur, row) : row);
  }
  const out = [...best.values()].sort(optComparePicks(mode));
  return {
    universe: univers, type, mode, rulePct, rulePeriodDays, deltaMin, deltaMax, dteMin, dteMax, total: scan.total_tickers, rows: out, skipped: [],
    scan: { id: scan.id, startedAt: scan.started_at, sansHebdo: scan.sans_hebdo, totalTickers: scan.total_tickers, sansPrix },
  };
}
