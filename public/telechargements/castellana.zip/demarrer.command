#!/bin/bash
# demarrer.command — lanceur self-install castellana (macOS)
#
# Révisé le 7/9/2026 après l'audit. Trois changements de fond :
#   1. PYTHON N'EST PLUS INSTALLÉ. Tous les indicateurs (RSI, SMA, Golden
#      Cross, ATR, OBV, VIX) sont désormais calculés depuis Yahoo Finance par
#      l'app elle-même — vérifiés identiques à la décimale contre l'ancien
#      sidecar. L'installation passe de ~223 Mo à ~53 Mo et d'un prérequis à
#      un seul. Qui veut quand même le sidecar lance installer-sidecar.command.
#   2. La VERSION de Node est vérifiée, pas seulement sa présence : une v12
#      traînant sur la machine passait le test puis plantait au démarrage.
#   3. Le navigateur s'ouvre sur le PORT RÉELLEMENT UTILISÉ (lu dans
#      data/runtime.json), pas sur 4700 en dur — le serveur se replie
#      automatiquement si ce port est déjà pris.
#
# ⚠️ Gatekeeper : un .command téléchargé depuis un navigateur porte
# l'attribut com.apple.quarantine, et macOS peut refuser de l'ouvrir au
# double-clic (« développeur non identifié »). Sans compte Apple Developer,
# il n'y a pas d'échappatoire pour CE fichier : clic droit → Ouvrir, une
# seule fois. Une fois lancé, il lève lui-même la quarantaine sur le reste
# du dossier, pour que rien d'autre ne rebute ensuite.

set -u
cd "$(dirname "$0")"

echo "=== castellana — installation et démarrage ==="
echo

# --- 0. Lever la quarantaine sur le reste du dossier --------------------
xattr -dr com.apple.quarantine . 2>/dev/null

# --- 1. Node.js (version comprise) --------------------------------------
NODE_MIN=20
if ! command -v node >/dev/null 2>&1; then
  echo "❌ Node.js est requis mais introuvable sur cette machine."
  echo "   Ouverture de la page de téléchargement officielle..."
  open "https://nodejs.org/"
  echo
  echo "Installe Node.js (version LTS), puis relance ce fichier."
  echo "Appuie sur Entrée pour fermer."
  read -r _
  exit 1
fi
NODE_VERSION="$(node --version)"
NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
if [ "$NODE_MAJOR" -lt "$NODE_MIN" ]; then
  echo "❌ Node.js $NODE_VERSION est trop ancien (castellana requiert la version $NODE_MIN ou plus)."
  echo "   Ouverture de la page de téléchargement officielle..."
  open "https://nodejs.org/"
  echo
  echo "Installe la version LTS, puis relance ce fichier. Appuie sur Entrée pour fermer."
  read -r _
  exit 1
fi
echo "✅ Node.js détecté ($NODE_VERSION)."

# --- 2. Dépendances Node -------------------------------------------------
if [ ! -d "node_modules" ]; then
  echo "📦 Installation des dépendances (première fois, peut prendre une minute)..."
  if ! npm install; then
    echo
    echo "❌ npm install a échoué."
    echo "   Lance « npm run doctor » dans ce dossier pour savoir exactement"
    echo "   ce qui manque, ou consulte SETUP.md (section Dépannage)."
    echo
    echo "Appuie sur Entrée pour fermer."
    read -r _
    exit 1
  fi
else
  echo "✅ Dépendances déjà installées."
fi
echo

# --- 3. Préflight --------------------------------------------------------
# Bloque AVANT de démarrer si quelque chose d'essentiel manque, plutôt que
# de laisser le testeur devant une page qui ne charge pas.
if ! npm run --silent doctor; then
  echo "Corrige les points ci-dessus, puis relance ce fichier."
  echo "Appuie sur Entrée pour fermer."
  read -r _
  exit 1
fi

# --- 4. Démarrage --------------------------------------------------------
echo "🚀 Démarrage de castellana..."
rm -f data/runtime.json
npm start &

# Le serveur écrit data/runtime.json une fois qu'il écoute réellement, avec
# le port retenu. On attend ce fichier plutôt que de dormir un temps fixe et
# d'espérer : sur une machine lente, l'ancien `sleep 2` ouvrait le navigateur
# avant que le serveur soit prêt, et le testeur voyait une page d'erreur.
URL=""
for _ in $(seq 1 30); do
  if [ -f data/runtime.json ]; then
    URL="$(node -p "require('./data/runtime.json').url" 2>/dev/null)"
    [ -n "$URL" ] && break
  fi
  sleep 0.5
done

if [ -n "$URL" ]; then
  open "$URL"
  echo
  echo "=== castellana tourne — $URL ==="
else
  echo
  echo "⚠️  Le serveur n'a pas confirmé son démarrage dans les 15 secondes."
  echo "   Regarde les messages ci-dessus, ou lance « npm run doctor »."
fi
echo "Ferme cette fenêtre (ou Ctrl+C) pour tout arrêter."
echo

wait
