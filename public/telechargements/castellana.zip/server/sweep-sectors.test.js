import test from 'node:test';
import assert from 'node:assert/strict';
import { sectorBreakdown } from './sweep-sectors.js';

const uni = [
  { ticker: 'A', sector: 'Energy' }, { ticker: 'B', sector: 'Energy' }, { ticker: 'C', sector: 'Energy' },
  { ticker: 'D', sector: 'Financials' }, { ticker: 'E', sector: 'Financials' },
];
test('compte prêt / à surveiller par secteur, total du secteur, tri par prêts', () => {
  const rows = [{ ticker: 'D', verdict: 'prêt' }, { ticker: 'E', verdict: 'prêt' }, { ticker: 'A', verdict: 'à surveiller' }, { ticker: 'B', verdict: 'trop tard' }];
  const r = sectorBreakdown(rows, uni);
  assert.equal(r[0].sector, 'Financials'); assert.equal(r[0].pretCount, 2); assert.equal(r[0].pretPct, 100);
  const e = r.find((x) => x.sector === 'Energy');
  assert.equal(e.total, 3); assert.equal(e.surveillerCount, 1); assert.equal(e.autres, 1); assert.equal(e.label, 'Énergie');
});
test('un titre hors S&P 500 est ignoré ; aucune ligne = tout à zéro', () => {
  const r = sectorBreakdown([{ ticker: 'ZZZ', verdict: 'prêt' }], uni);
  assert.equal(r.reduce((n, x) => n + x.pretCount, 0), 0);
  assert.equal(sectorBreakdown(null, uni).length, 2);
});
