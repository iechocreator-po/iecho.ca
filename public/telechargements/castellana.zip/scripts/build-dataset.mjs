// Génère le jeu de données de l'étape 2 (#399) : un trade simulé du signal d'alignement par ligne,
// avec les variables connues au signal et le résultat en R. Usage :
//   node scripts/build-dataset.mjs [univers=elargi] [années=5] [sortie=data/dataset-<univers>.csv]
import { writeFileSync, mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { fetchDailyHistory } from '../server/indicators.js';
import { simulateSignal } from '../server/backtest.js';
import { universeTickers, isValidUniverse } from '../server/screening.js';
import { getPreferences } from '../server/preferences.js';
import { SECTOR_TOP_CANDIDATES } from '../server/sectors.js';
import { mapWithConcurrency } from '../server/fetch-retry.js';
import { buildRows, rowsToCsv } from '../server/dataset.js';

const universe = process.argv[2] || 'elargi';
const years = Number(process.argv[3]) || 5;
const out = process.argv[4] || `data/dataset-${universe}.csv`;
if (!isValidUniverse(universe)) { console.error(`Univers invalide : ${universe}`); process.exit(1); }

const sectorOf = new Map();
for (const [sector, ts] of Object.entries(SECTOR_TOP_CANDIDATES)) for (const t of ts) if (!sectorOf.has(t)) sectorOf.set(t, sector);

const prefs = getPreferences();
const costPct = 0.1; // 0,05 % de frais + 0,05 % de glissement, par côté (défaut du backtest)
const lookback = Math.round(years * 365) + 120 + 400; // marge pour la SMA 200 et la force relative
const base = { fast: prefs.smaFast, medium: prefs.smaMedium, slow: prefs.smaSlow, atrMult: 1.5 };

const spy = await fetchDailyHistory('SPY', lookback);
const vixBars = await fetchDailyHistory('^VIX', lookback).catch(() => []);
const vixMap = new Map(vixBars.map((b) => [new Date(b.date).toISOString().slice(0, 10), b.close]));
const tickers = universeTickers(universe);
console.error(`${tickers.length} titres, ${years} ans…`);

const errors = [];
const parts = await mapWithConcurrency(tickers, async (ticker) => {
  try {
    const bars = await fetchDailyHistory(ticker, lookback);
    const gross = simulateSignal(bars, base).trades;
    const costed = simulateSignal(bars, { ...base, costPct }).trades;
    return buildRows(ticker, sectorOf.get(ticker) ?? 'Autre', bars, { costed, gross }, { spy, vixMap });
  } catch (e) { errors.push(`${ticker}: ${e.message}`); return []; }
}, { limit: 6 });

const rows = parts.flat().sort((a, b) => a.signal_date.localeCompare(b.signal_date));
mkdirSync(dirname(out), { recursive: true });
writeFileSync(out, rowsToCsv(rows));
console.error(`${rows.length} trades → ${out} (${errors.length} titre(s) en erreur)`);
if (errors.length) console.error(errors.slice(0, 10).join('\n'));
