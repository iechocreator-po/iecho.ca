// Tests unitaires sur les fonctions PURES de indicators.js (aucun appel
// réseau, aucun mock) — amélioration demandée par JP (31/8/2026) après que
// deux bugs réels aient été trouvés uniquement en testant à la main cette
// session (fetchJSON cassé, script sidecar cassé sur Windows). `node:test`
// natif (Node 22), zéro dépendance ajoutée — cohérent avec le reste du
// projet. Lancer avec `npm test`.
//
// Les fonctions qui appellent Yahoo Finance (getHomemadeIndicators,
// fetchDailyHistory, getHomemadeIndicatorsBatch, checkYahooConnection)
// restent hors périmètre : pas d'infrastructure de mock dans ce projet,
// testées manuellement en direct comme le reste de l'app.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { computeSMA, computeOBV, computeTrueRange, computeATR, computeVolumeVs20d } from './indicators.js';

test('computeSMA — fenêtre glissante sur une série connue', () => {
  const closes = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  assert.deepEqual(computeSMA(closes, 3), [null, null, 2, 3, 4, 5, 6, 7, 8, 9]);
});

test('computeSMA — historique plus court que la période retourne tout null', () => {
  assert.deepEqual(computeSMA([1, 2], 5), [null, null]);
});

test('computeOBV — cumul +volume/-volume/inchangé selon la clôture', () => {
  const bars = [
    { close: 10, volume: 100 },
    { close: 12, volume: 100 }, // hausse -> +100
    { close: 11, volume: 100 }, // baisse -> -100
    { close: 11, volume: 100 }, // inchangé -> +0
    { close: 13, volume: 100 }, // hausse -> +100
  ];
  assert.deepEqual(computeOBV(bars), [0, 100, 0, 0, 100]);
});

test('computeVolumeVs20d — le jour courant est exclu de sa propre moyenne', () => {
  const bars = [
    ...Array.from({ length: 20 }, () => ({ volume: 1000 })),
    { volume: 3000 }, // 21e barre, jour courant
  ];
  assert.deepEqual(computeVolumeVs20d(bars), { ratio: 3, volumeSMA20: 1000 });
});

test('computeVolumeVs20d — moins de 21 barres retourne null explicite (pas 0)', () => {
  const bars = Array.from({ length: 5 }, () => ({ volume: 1000 }));
  assert.deepEqual(computeVolumeVs20d(bars), { ratio: null, volumeSMA20: null });
});

test('computeTrueRange — max(high-low, |high-clôture veille|, |low-clôture veille|)', () => {
  const bars = [
    { high: 10, low: 8, close: 9 },
    { high: 12, low: 9, close: 11 },
    { high: 13, low: 11, close: 12 },
    { high: 15, low: 12, close: 14 },
  ];
  assert.deepEqual(computeTrueRange(bars), [2, 3, 2, 3]);
});

test('computeATR — lissage Wilder (RMA) appliqué au True Range, pas une SMA', () => {
  const bars = [
    { high: 10, low: 8, close: 9 },
    { high: 12, low: 9, close: 11 },
    { high: 13, low: 11, close: 12 },
    { high: 15, low: 12, close: 14 },
  ];
  // TR = [2,3,2,3] (vérifié par le test précédent). RMA(period=2) à la main :
  // out[1] = (2+3)/2 = 2.5 ; out[2] = (2.5*1+2)/2 = 2.25 ; out[3] = (2.25*1+3)/2 = 2.625
  assert.deepEqual(computeATR(bars, 2), [null, 2.5, 2.25, 2.625]);
});
