// js/app-journal.js — Journal de trades et statistiques post-trade
// Extrait de l'ancien script en ligne des index.html (découpage phase 2, 20/10/2026) : code déplacé tel quel, sans réécriture.
// Fichier COMMUN aux versions locale et cloud : source ici ; cloud/public/js/app-journal.js en est la copie (npm run sync:cloud).
// Script classique : ses noms de premier niveau sont globaux et partagés avec les autres scripts de la page.

// ---- Journal de trades (feature 323) ----
async function loadTrades() {
  const tbody = document.getElementById('journal-tbody');
  const empty = document.getElementById('journal-empty');
  try {
    const data = await fetchJSON('/api/trades');
    document.getElementById('trades-count').textContent = data.trades.length;
    empty.style.display = data.trades.length ? 'none' : 'block';
    tbody.innerHTML = data.trades.map(t => {
      const ouvert = t.date_sortie == null;
      const statut = ouvert ? '<span class="ds-badge ds-badge--warning">Ouvert</span>' : '<span class="ds-badge">Clôturé</span>';
      const resultat = t.resultat ? `<span class="ds-badge ${t.resultat === 'gagnant' ? 'ds-badge--success' : 'ds-badge--danger'}">${optEsc(t.resultat)}</span>` : '—';
      const actions = (ouvert ? `<button type="button" class="ds-btn" onclick="closeTrade(${t.id})">Clôturer</button> ` : '')
        + `<button type="button" class="ds-btn" onclick="editTrade(${t.id})">Modifier</button> `
        + `<button type="button" class="ds-btn" onclick="deleteTrade(${t.id})">Suppr.</button>`;
      return `<tr>
        <td>${optEsc(t.ticker)}${t.option_cycle_id ? ` <a href="#" class="roue-lien ds-text-hint" title="Action issue d'un cycle de la Roue" onclick="switchTab('roue'); return false;">Roue #${t.option_cycle_id}</a>` : ''}</td><td>${optEsc(t.date_entree)}</td><td>${optEsc(t.compte)}</td>
        <td class="is-num">$${t.prix_entree.toFixed(2)}</td><td class="is-num">${t.taille_position}</td>
        <td class="is-num">$${t.stop_initial.toFixed(2)}</td><td>${statut}</td>
        <td class="is-num">${t.r_realise != null ? t.r_realise.toFixed(2) + 'R' : '—'}</td>
        <td>${resultat}</td><td>${actions}</td>
      </tr>`;
    }).join('');
  } catch (err) { tbody.innerHTML = `<tr><td colspan="10" class="muted-empty">Erreur : ${optEsc(err.message)}</td></tr>`; }
}
// Trade en cours de modification (null = mode création). editTrade()
// le fixe, saveTrade() PUT au lieu de POST tant qu'il est non-null,
// cancelEditTrade()/une sauvegarde réussie le remet à null.
let editingTradeId = null;
async function saveTrade() {
  const status = document.getElementById('journal-form-status');
  const g = (id) => document.getElementById('j-' + id).value;
  const body = {
    date_entree: g('date_entree'), compte: g('compte'), ticker: g('ticker'),
    prix_entree: parseFloat(g('prix_entree')), taille_position: parseInt(g('taille_position'), 10),
    stop_initial: parseFloat(g('stop_initial')),
    vix_a_entree: g('vix_a_entree') ? parseFloat(g('vix_a_entree')) : undefined,
    rsi_a_entree: g('rsi_a_entree') ? parseFloat(g('rsi_a_entree')) : undefined,
    obv_a_entree: g('obv_a_entree') || undefined,
    correlation_flag: parseInt(g('correlation_flag'), 10),
    checklist_complete: parseInt(g('checklist_complete'), 10),
  };

  // Le raisonnement du screening n'est joint QUE s'il concerne bien le titre
  // saisi. Sans ce contrôle, préparer AMD puis changer le ticker à la main
  // enregistrerait le score d'AMD sur un autre trade — une donnée fausse et
  // parfaitement crédible, qui fausserait silencieusement toute analyse
  // ultérieure.
  // Et seulement à la CRÉATION : en édition, il écraserait les scores d'entrée d'origine (audit app-js, constat 2).
  if (!editingTradeId && contexteScreeningPrepare && contexteScreeningPrepare.ticker === body.ticker.toUpperCase()) {
    const { ticker: _ignore, ...scoresScreening } = contexteScreeningPrepare;
    Object.assign(body, scoresScreening);
  }
  const url = editingTradeId ? '/api/trades/' + editingTradeId : '/api/trades';
  const method = editingTradeId ? 'PUT' : 'POST';
  try {
    const resp = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const data = await resp.json();
    if (!resp.ok) { status.textContent = (data.errors || [data.error]).join(' · '); status.style.color = 'var(--red)'; return; }
    status.textContent = editingTradeId ? ('Trade #' + data.id + ' mis à jour.') : ('Trade #' + data.id + ' enregistré.');
    status.style.color = 'var(--green)';
    trackTickerSelected('journal', body.ticker, null);
    contexteScreeningPrepare = null; // consommé : il ne doit pas suivre un prochain trade du même symbole
    if (editingTradeId) cancelEditTrade();
    else ['prix_entree', 'taille_position', 'stop_initial', 'vix_a_entree', 'rsi_a_entree'].forEach(id => document.getElementById('j-' + id).value = '');
    loadTrades(); loadStats();
  } catch (err) { status.textContent = 'Erreur : ' + err.message; status.style.color = 'var(--red)'; }
}
// Pré-remplit le formulaire du haut avec un trade existant et bascule le
// bouton en mode « mise à jour » — corrige une saisie sans passer par
// suppression + recréation (le PUT partiel existe déjà côté API, seule la
// bascule d'état manquait côté frontend).
async function editTrade(id) {
  const t = await fetchJSON('/api/trades/' + id);
  const set = (id2, val) => { document.getElementById('j-' + id2).value = val ?? ''; };
  set('date_entree', t.date_entree); set('compte', t.compte); set('ticker', t.ticker);
  set('prix_entree', t.prix_entree); set('taille_position', t.taille_position); set('stop_initial', t.stop_initial);
  set('vix_a_entree', t.vix_a_entree); set('rsi_a_entree', t.rsi_a_entree); set('obv_a_entree', t.obv_a_entree || '');
  set('correlation_flag', t.correlation_flag); set('checklist_complete', t.checklist_complete);
  editingTradeId = id;
  document.getElementById('btn-save-trade').textContent = 'Mettre à jour le trade #' + id;
  document.getElementById('btn-cancel-edit').style.display = 'inline-flex';
  document.getElementById('journal-form-status').textContent = 'Modification du trade #' + id + ' — les champs de sortie (clôture) ne sont pas éditables ici, utilise « Clôturer ».';
  document.getElementById('journal-form-status').style.color = 'var(--text-2)';
  document.querySelector('#tab-journal .ds-card').scrollIntoView({ behavior: 'smooth', block: 'start' });
}
function cancelEditTrade() {
  editingTradeId = null;
  document.getElementById('btn-save-trade').textContent = 'Enregistrer le trade';
  document.getElementById('btn-cancel-edit').style.display = 'none';
  ['date_entree', 'compte', 'ticker', 'prix_entree', 'taille_position', 'stop_initial', 'vix_a_entree', 'rsi_a_entree', 'obv_a_entree', 'correlation_flag', 'checklist_complete']
    .forEach((id) => { const el = document.getElementById('j-' + id); if (el.tagName === 'SELECT') el.selectedIndex = 0; else el.value = ''; });
  document.getElementById('journal-form-status').textContent = '';
}
async function downloadTradesCSV() {
  try {
    const resp = await fetch('/api/trades.csv');
    const blob = await resp.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'journal-castellana.csv';
    a.click();
    URL.revokeObjectURL(url);
  } catch (err) {
    alert('Export impossible : ' + err.message);
  }
}
// Clôture d'un trade — demande prix de sortie, calcule le R réalisé
// ((sortie−entrée)/(entrée−stop)) et déduit gagnant/perdant.
async function closeTrade(id) {
  const trade = (await fetchJSON('/api/trades/' + id));
  // « 12,5 » (virgule décimale) valait 12 avec parseFloat : on la lit comme un point.
  const saisie = prompt('Prix de sortie pour ' + trade.ticker + ' :');
  if (saisie == null) return;
  const prixSortie = parseFloat(String(saisie).trim().replace(',', '.'));
  if (!prixSortie || isNaN(prixSortie) || prixSortie < 0) return;
  const risque = trade.prix_entree - trade.stop_initial;
  const rRealise = risque !== 0 ? (prixSortie - trade.prix_entree) / risque : null;
  const resultat = prixSortie >= trade.prix_entree ? 'gagnant' : 'perdant';
  const body = { date_sortie: new Date().toISOString().slice(0, 10), prix_sortie: prixSortie, r_realise: rRealise, resultat };
  try {
    await fetchJSON('/api/trades/' + id, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    loadTrades(); loadStats();
  } catch (err) { alert('Clôture impossible : ' + err.message); }
}
async function deleteTrade(id) {
  if (!confirm('Supprimer ce trade ?')) return;
  await fetch('/api/trades/' + id, { method: 'DELETE' });
  loadTrades(); loadStats();
}
// Pré-remplit le formulaire depuis la Fiche de trade (bonus ergonomie).
function prefillFromFiche() {
  const set = (id, val) => { if (val != null && val !== '' && !isNaN(val)) document.getElementById('j-' + id).value = val; };
  document.getElementById('j-ticker').value = document.getElementById('ticker').value || '';
  set('prix_entree', document.getElementById('entry')?.value);
  set('vix_a_entree', currentVix);
  set('rsi_a_entree', document.getElementById('rsi')?.value);
  const obv = document.getElementById('obv')?.value;
  if (obv) document.getElementById('j-obv_a_entree').value = obv;
  if (!document.getElementById('j-date_entree').value) document.getElementById('j-date_entree').value = new Date().toISOString().slice(0, 10);
  document.getElementById('journal-form-status').textContent = 'Pré-rempli depuis la Fiche — complète taille et stop.';
  document.getElementById('journal-form-status').style.color = 'var(--text-2)';
}
// ---- Statistiques post-trade (feature 323) ----
async function loadStats() {
  const grid = document.getElementById('stats-grid');
  const empty = document.getElementById('stats-empty');
  try {
    const s = await fetchJSON('/api/stats');
    if (s.global.clotures === 0) { grid.innerHTML = ''; empty.style.display = 'block'; return; }
    empty.style.display = 'none';
    const pct = (v) => v == null ? '—' : (v * 100).toFixed(0) + '%';
    const rfmt = (v) => v == null ? '—' : v.toFixed(2) + 'R';
    const winClass = (v) => v == null ? '' : (v >= 0.5 ? 'win-good' : 'win-bad');
    const block = (title, obj) => {
      const rows = Object.entries(obj).map(([label, m]) =>
        `<div class="stats-row"><span>${label} <span class="num-dim">(${m.n})</span></span><span class="sr-val ${winClass(m.tauxReussite)}">${pct(m.tauxReussite)} · ${rfmt(m.rMoyen)}</span></div>`
      ).join('');
      return `<div class="stats-block"><h4>${title}</h4>${rows}</div>`;
    };
    const g = s.global;
    grid.innerHTML =
      `<div class="stats-block"><h4>Global</h4>
        <div class="stats-row"><span>Trades clôturés</span><span class="sr-val">${g.clotures}</span></div>
        <div class="stats-row"><span>Taux de réussite</span><span class="sr-val ${winClass(g.tauxReussite)}">${pct(g.tauxReussite)}</span></div>
        <div class="stats-row"><span>R moyen</span><span class="sr-val">${rfmt(g.rMoyen)}</span></div>
        <div class="stats-row"><span>Ouverts</span><span class="sr-val">${g.ouverts}</span></div>
       </div>`
      + block('Par VIX', s.parVix) + block('Par RSI', s.parRsi) + block('Par OBV', s.parObv)
      + block('Par checklist', s.parChecklist) + block('Par corrélation', s.parCorrelation) + block('Par compte', s.parCompte)
      + `<div class="stats-block" style="grid-column:1/-1;"><h4>Le score prédit-il le R ?</h4>
          <p class="metric-sub" style="text-align:left;margin:0;">${s.avecScore === 0
            ? 'Aucun trade clôturé ne porte encore de score : prépare tes trades depuis le screening (bouton « Préparer ») pour que le score d\'entrée soit enregistré.'
            : `${s.avecScore} trade(s) clôturé(s) portent un score d'entrée. ${s.avecScore < s.echantillonMin ? `⚠️ Sous le seuil de ${s.echantillonMin} : trop peu pour conclure, lis ces chiffres comme une piste, pas une preuve.` : ''}`}</p></div>`
      + block('Par score Setup', s.parSetup) + block('Par score Contexte', s.parContexte)
      + block('Par alignement à l\'entrée', s.parAlignement) + block('Par âge du signal', s.parAgeSignal);
  } catch (err) { grid.innerHTML = '<span class="muted-empty">Erreur : ' + err.message + '</span>'; }
}
