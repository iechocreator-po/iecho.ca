// js/demo-mode.js — Mode démo (2/10/2026). VERSION CLOUD SEULEMENT.
//
// Pour une démonstration, on veut limiter les appels du serveur à Yahoo
// Finance (limites 429 sur les adresses de Cloudflare, plafond de
// sous-requêtes). Interrupteur dans Réglages → Technique, OFF par défaut,
// persisté en localStorage (comme les Repères d'interface). Quand il est ON :
//   - fetchJSON() ajoute l'en-tête `X-Demo-Mode: 1` à chaque appel ; le Worker
//     prolonge alors son cache à 4 h, sert la dernière valeur connue si Yahoo
//     échoue et ignore « Forcer » (voir cloud/src/db/cache.js) ;
//   - un bandeau rappelle que les prix sont FIGÉS : jamais des données
//     périmées présentées comme fraîches ;
//   - « Préparer la démo » parcourt à l'avance les écrans à montrer, pour que
//     la démo se joue depuis le cache.

const DEMO_KEY = 'castellana-demo-mode';
const DEMO_TICKERS_KEY = 'castellana-demo-tickers';
const DEMO_DEFAULT_TICKERS = 'AMD, NVDA, AAPL';
const DEMO_STEP_PAUSE_MS = 700; // politesse envers Yahoo entre deux étapes

function demoModeOn() {
  try { return localStorage.getItem(DEMO_KEY) === 'on'; } catch { return false; }
}

// En-têtes à ajouter à un appel API quand le mode démo est actif.
function demoHeaders() { return demoModeOn() ? { 'X-Demo-Mode': '1' } : {}; }

function setDemoMode(on) {
  try { localStorage.setItem(DEMO_KEY, on ? 'on' : 'off'); } catch { /* tant pis */ }
  const toggle = document.getElementById('demo-toggle');
  if (toggle) toggle.checked = on;
  const wrap = document.getElementById('demo-switch');
  if (wrap) wrap.classList.toggle('is-on', on);
  const state = document.getElementById('demo-state');
  if (state) state.textContent = on ? 'ON' : 'OFF';
  const panel = document.getElementById('demo-panel');
  if (panel) panel.style.display = on ? '' : 'none';
  const banner = document.getElementById('demo-banner');
  if (banner) banner.style.display = on ? '' : 'none';
}

function demoTickers() {
  const raw = (document.getElementById('demo-tickers') || {}).value || '';
  return [...new Set(raw.split(/[\s,;]+/).map((t) => t.trim().toUpperCase()).filter(Boolean))].slice(0, 6);
}

const demoSleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Écrans à parcourir, dans l'ordre. Chaque étape est indépendante : un échec
// n'arrête pas les suivantes et reste visible dans le journal.
function demoSteps(tickers) {
  const steps = [
    ['Secteurs (USD)', '/api/sectors?mode=usd'],
    ['Historique des secteurs', '/api/sectors/history?mode=usd'],
    ['Screener — watchlist', '/api/screening?universe=watchlist'],
    ['Screener — MAG7', '/api/screening?universe=mag7'],
  ];
  for (const t of tickers) {
    steps.push([`${t} — données de marché`, `/api/market-data/${encodeURIComponent(t)}`]);
    steps.push([`${t} — Labo`, `/api/labo/${encodeURIComponent(t)}`]);
    steps.push([`${t} — fondamentaux (FCF)`, `/api/fcf/${encodeURIComponent(t)}`]);
    steps.push([`${t} — chaîne d'options`, `/api/options/${encodeURIComponent(t)}`]);
    steps.push([`${t} — grille de rendement`, `/api/options/${encodeURIComponent(t)}/grid`]);
  }
  return steps;
}

async function warmDemo() {
  const btn = document.getElementById('demo-warm');
  const log = document.getElementById('demo-warm-log');
  const status = document.getElementById('demo-warm-status');
  if (!btn || btn.disabled) return;
  const tickers = demoTickers();
  try { localStorage.setItem(DEMO_TICKERS_KEY, tickers.join(', ')); } catch { /* tant pis */ }
  const steps = demoSteps(tickers);
  btn.disabled = true;
  log.innerHTML = '';
  let ok = 0;
  for (let i = 0; i < steps.length; i++) {
    const [label, url] = steps[i];
    status.textContent = `Étape ${i + 1}/${steps.length} — ${label}…`;
    const t0 = performance.now();
    let line;
    try {
      await fetchJSON(url); // l'en-tête de démo est ajouté par fetchJSON
      ok++;
      line = `✓ ${label} <span class="ds-text-hint">(${Math.round(performance.now() - t0)} ms)</span>`;
    } catch (err) {
      line = `<span style="color:var(--amber)">✗ ${label} — ${demoEsc(err.message)}</span>`;
    }
    log.insertAdjacentHTML('beforeend', `<div>${line}</div>`);
    if (i < steps.length - 1) await demoSleep(DEMO_STEP_PAUSE_MS);
  }
  const at = new Date().toLocaleTimeString('fr-CA', { hour: '2-digit', minute: '2-digit' });
  status.textContent = `Préparation terminée à ${at} : ${ok}/${steps.length} étapes réussies. Les données restent valides ~4 h.`;
  btn.disabled = false;
}

function demoEsc(s) {
  return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

function initDemoMode() {
  const input = document.getElementById('demo-tickers');
  if (input) {
    let saved = null;
    try { saved = localStorage.getItem(DEMO_TICKERS_KEY); } catch { /* tant pis */ }
    input.value = saved || DEMO_DEFAULT_TICKERS;
  }
  setDemoMode(demoModeOn());
}
