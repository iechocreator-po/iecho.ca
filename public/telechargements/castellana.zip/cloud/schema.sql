-- Schéma D1 — castellana cloud (portage 11/9/2026, voir CLAUDE.md du
-- produit). Reprend le schéma local (server/db.js, preferences.js,
-- cache.js) en ajoutant l'isolation par utilisateur sur les données
-- personnelles (trades, watchlist, preferences). Le cache et les alertes
-- restent globaux — voir les commentaires des modules correspondants
-- (src/db/cache.js, src/db/alerts.js) pour le raisonnement.

-- email/disabled ajoutés le 19/9/2026 (console CRUD bilbao + magic link) —
-- sur une base DÉJÀ déployée, ce CREATE TABLE ne suffit pas (IF NOT EXISTS
-- ne touche pas aux colonnes d'une table existante) : voir
-- scripts/migrate-users-email-magiclinks.mjs pour la vraie base de
-- production, ce fichier reste la source de vérité pour un déploiement
-- neuf.
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  password_salt TEXT NOT NULL,
  email TEXT,
  disabled INTEGER NOT NULL DEFAULT 0 CHECK (disabled IN (0,1)),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  -- 18/10/2026 : dernière connexion (mot de passe ou magic link) et dernière
  -- requête authentifiée (au plus une écriture par 10 min). Voir
  -- scripts/migrate-user-activity.mjs pour une base existante.
  last_login_at TEXT,
  last_seen_at TEXT
);

CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  expires_at INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  -- Origine de la session (17/10/2026) : 'password' ou 'magic_link'.
  -- Voir scripts/migrate-session-method.mjs pour une base existante.
  method TEXT NOT NULL DEFAULT 'password'
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

-- Connexion par magic link (19/9/2026) — token à usage unique, 15 minutes
-- de validité (voir src/db/magic-links.js). S'ajoute au mot de passe,
-- ne le remplace pas.
CREATE TABLE IF NOT EXISTS magic_links (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at INTEGER NOT NULL,
  used_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_magic_links_user ON magic_links(user_id);

CREATE TABLE IF NOT EXISTS trades (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  date_entree TEXT NOT NULL,
  date_sortie TEXT,
  compte TEXT NOT NULL CHECK (compte IN ('RRSP','margin','corporatif')),
  ticker TEXT NOT NULL,
  prix_entree REAL NOT NULL,
  prix_sortie REAL,
  taille_position INTEGER NOT NULL,
  stop_initial REAL NOT NULL,
  vix_a_entree REAL,
  rsi_a_entree REAL,
  obv_a_entree TEXT CHECK (obv_a_entree IN ('accumulation','neutre','distribution')),
  correlation_flag INTEGER NOT NULL DEFAULT 0 CHECK (correlation_flag IN (0,1)),
  checklist_complete INTEGER NOT NULL DEFAULT 0 CHECK (checklist_complete IN (0,1)),
  r_realise REAL,
  resultat TEXT CHECK (resultat IN ('gagnant','perdant')),
  setup_score INTEGER,
  contexte_score INTEGER,
  alignement_a_entree TEXT,
  signal_age_a_entree INTEGER,
  -- Traçabilité (22/9/2026) : ligne créée automatiquement par l'assignation
  -- d'un put d'un cycle d'options (voir option_cycles/option_trades plus bas).
  option_cycle_id INTEGER REFERENCES option_cycles(id),
  -- Journal de la Roue (13/10/2026) : voir scripts/migrate-roue.mjs.
  commission_entree REAL,
  commission_sortie REAL,
  source TEXT,
  date_creation TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_trades_user ON trades(user_id, date_entree DESC, id DESC);

CREATE TABLE IF NOT EXISTS watchlist (
  user_id INTEGER NOT NULL REFERENCES users(id),
  ticker TEXT NOT NULL,
  exchange TEXT NOT NULL DEFAULT 'NASDAQ',
  source TEXT NOT NULL DEFAULT 'user',
  date_ajout TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, ticker)
);

CREATE TABLE IF NOT EXISTS preferences (
  user_id INTEGER NOT NULL REFERENCES users(id),
  key TEXT NOT NULL,
  value TEXT NOT NULL,
  PRIMARY KEY (user_id, key)
);

-- Paramètres des stratégies d'options de l'onglet Labo (19/9/2026), par
-- utilisateur. Seules les SURCHARGES sont stockées (params_json = clé → valeur) :
-- un futur changement de défaut profite à qui n'a rien modifié. Défauts et
-- validation : js/labo-schema.js (copie ESM générée dans src/lib/).
-- `kind`/`definition_json` sont RÉSERVÉS aux futures stratégies
-- personnalisées (strategy_id 'custom:<uuid>') — rien ne les écrit encore.
CREATE TABLE IF NOT EXISTS strategy_params (
  user_id INTEGER NOT NULL REFERENCES users(id),
  strategy_id TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'builtin',
  params_json TEXT NOT NULL,
  definition_json TEXT,
  schema_version INTEGER NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, strategy_id)
);

-- Feature flags (20/9/2026) — GLOBAUX (pas par utilisateur), basculés depuis
-- bilbao via l'API d'administration. Une clé absente = son défaut (OFF pour
-- concepts_tab) : voir KNOWN_FLAGS dans src/db/flags.js, seule source des clés.
CREATE TABLE IF NOT EXISTS feature_flags (
  key TEXT PRIMARY KEY,
  enabled INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Surcharges PAR UTILISATEUR d'un sous-ensemble de flags (22/9/2026,
-- KNOWN_USER_FLAGS dans src/db/flags.js — aujourd'hui options_a_tab et
-- journal_a_tab) — permet d'activer un onglet avancé pour un testeur
-- précis sans toucher au réglage global des autres. Valeur effective =
-- surcharge si une ligne existe pour (user_id, key), sinon la valeur
-- globale de feature_flags (même principe « surcharge ⊕ défaut » que
-- strategy_params). Absence de ligne = hérite du global, jamais une
-- troisième valeur par défaut inventée ici.
CREATE TABLE IF NOT EXISTS user_feature_flags (
  user_id INTEGER NOT NULL REFERENCES users(id),
  key TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, key)
);

-- Modifications de l'administrateur sur l'onglet Concepts (20/9/2026) —
-- GLOBALES : ce que voient tous les testeurs. Seules les fiches modifiées ont
-- une ligne ; le texte d'origine reste dans js/concepts-data.js (copie ESM
-- src/lib/concepts-data.js), d'où la possibilité de « revenir à l'original ».
CREATE TABLE IF NOT EXISTS concept_overrides (
  concept_id TEXT PRIMARY KEY,
  titre TEXT NOT NULL,
  corps TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Listes personnalisées du Screener (12/9/2026, demande de JP) — en plus de
-- "Ma watchlist"/"Univers élargi"/"MAG7", isolées par utilisateur comme
-- watchlist/preferences ci-dessus. Cascade gérée à la main dans
-- src/db/lists.js (supprimer les tickers avant la liste), pas via
-- ON DELETE CASCADE — même choix que le reste de ce schéma.
CREATE TABLE IF NOT EXISTS custom_lists (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  nom TEXT NOT NULL,
  date_creation TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_custom_lists_user ON custom_lists(user_id);

CREATE TABLE IF NOT EXISTS custom_list_tickers (
  list_id INTEGER NOT NULL REFERENCES custom_lists(id),
  ticker TEXT NOT NULL,
  exchange TEXT NOT NULL DEFAULT 'NASDAQ',
  date_ajout TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (list_id, ticker)
);

-- Journal A — vente de primes / cycles de la Roue (22/9/2026). Isolées par
-- utilisateur comme custom_lists ci-dessus. Sur une base DÉJÀ déployée, ce
-- CREATE TABLE ne suffit pas (IF NOT EXISTS ne crée pas la colonne
-- trades.option_cycle_id sur une table existante) : voir
-- scripts/migrate-option-trades.mjs pour la vraie base de production, ce
-- fichier reste la source de vérité pour un déploiement neuf.
CREATE TABLE IF NOT EXISTS option_cycles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  ticker TEXT NOT NULL,
  compte TEXT NOT NULL CHECK (compte IN ('RRSP','margin','corporatif')),
  statut TEXT NOT NULL DEFAULT 'actif' CHECK (statut IN ('actif','clos')),
  notes TEXT,
  date_creation TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_option_cycles_user ON option_cycles(user_id);

CREATE TABLE IF NOT EXISTS option_trades (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  cycle_id INTEGER REFERENCES option_cycles(id),
  type TEXT NOT NULL CHECK (type IN ('put','call')),
  ticker TEXT NOT NULL,
  compte TEXT NOT NULL CHECK (compte IN ('RRSP','margin','corporatif')),
  strike REAL NOT NULL,
  echeance TEXT NOT NULL,
  contrats INTEGER NOT NULL DEFAULT 1,
  prime_recue REAL NOT NULL,
  date_ouverture TEXT NOT NULL,
  delta_ouverture REAL,
  iv_ouverture REAL,
  statut TEXT NOT NULL DEFAULT 'ouvert' CHECK (statut IN ('ouvert','expire','assigne','roule','rachete')),
  date_cloture TEXT,
  prime_cloture REAL,
  notes TEXT,
  -- Journal de la Roue (13/10/2026) : voir scripts/migrate-roue.mjs.
  commission_ouverture REAL,
  commission_cloture REAL,
  roule_vers_id INTEGER,
  source TEXT,
  date_creation TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_option_trades_user ON option_trades(user_id, statut);

-- Journal de la Roue (13/10/2026, bilbao #433) : flux de trésorerie datés par compte
-- (capital de départ, dépôts, retraits, dividendes, autres revenus).
CREATE TABLE IF NOT EXISTS cash_flows (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  compte TEXT NOT NULL CHECK (compte IN ('RRSP','margin','corporatif')),
  date TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('depart','depot','retrait','dividende','autre_revenu')),
  montant REAL NOT NULL,
  ticker TEXT,
  cycle_id INTEGER REFERENCES option_cycles(id),
  notes TEXT,
  source TEXT,
  date_creation TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_cash_flows_user ON cash_flows(user_id, compte, date);
CREATE INDEX IF NOT EXISTS idx_option_trades_cycle ON option_trades(cycle_id);

-- Global, PAS par utilisateur — une cotation ou un historique sont les
-- mêmes pour tout le monde.
CREATE TABLE IF NOT EXISTS cache (
  key TEXT PRIMARY KEY,
  payload TEXT NOT NULL,
  fetched_at INTEGER NOT NULL,
  ttl_seconds INTEGER NOT NULL
);

-- Global — voir src/db/alerts.js pour le raisonnement.
CREATE TABLE IF NOT EXISTS alerts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticker TEXT,
  message TEXT,
  payload TEXT,
  recu_le TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Connexion TradingView (30/9/2026, feature #367) — OAuth 2.1 (PKCE) vers le
-- serveur MCP officiel. Sur une base DÉJÀ déployée, voir
-- scripts/migrate-tradingview.mjs.
-- tv_oauth_clients : clients publics inscrits dynamiquement, un par adresse de
-- retour (production, wrangler dev…). Global : aucune donnée personnelle.
CREATE TABLE IF NOT EXISTS tv_oauth_clients (
  redirect_uri TEXT PRIMARY KEY,
  client_id TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
-- tv_oauth : jetons liés à la SESSION (jamais à `users`) — ils disparaissent
-- avec elle (déconnexion, expiration) via ON DELETE CASCADE. Tant que
-- access_token est NULL, la ligne est une autorisation EN COURS (state/PKCE).
CREATE TABLE IF NOT EXISTS tv_oauth (
  session_token TEXT PRIMARY KEY REFERENCES sessions(token) ON DELETE CASCADE,
  client_id TEXT NOT NULL,
  redirect_uri TEXT NOT NULL,
  state TEXT,
  code_verifier TEXT,
  access_token TEXT,
  refresh_token TEXT,
  expires_at INTEGER,
  connected_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
-- user_settings : réglages textuels par utilisateur (aujourd'hui : dataSource
-- = 'yahoo' | 'tradingview'). Distincte de `preferences`, dont le validateur
-- n'accepte que des entiers et que « Réinitialiser » vide entièrement.
CREATE TABLE IF NOT EXISTS user_settings (
  user_id INTEGER NOT NULL REFERENCES users(id),
  key TEXT NOT NULL,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, key)
);

-- IA étape 1 (#398, 10/10/2026) : analyses de contexte par Claude, PAR COMPTE (le plafond
-- mensuel se calcule sur la somme de cost_usd du mois pour user_id). Migration :
-- cloud/scripts/migrate-ai.mjs.
CREATE TABLE IF NOT EXISTS ai_analyses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  ticker TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  month TEXT NOT NULL,
  model TEXT NOT NULL,
  input_tokens INTEGER,
  output_tokens INTEGER,
  cost_usd REAL,
  result_json TEXT NOT NULL,
  sources_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ai_analyses_user ON ai_analyses (user_id, ticker, id);

-- Onglet « Anticipation » (12/10/2026, bilbao #418). Un vote = un compte + une carte (clé primaire :
-- pas de double vote). Les cartes elles-mêmes vivent dans anticipation/cards.json (versionné avec le
-- code), pas en base : seuls les choix des utilisateurs y sont. Migration : cloud/scripts/migrate-anticipation.mjs.
CREATE TABLE IF NOT EXISTS anticipation_votes (
  user_id INTEGER NOT NULL REFERENCES users(id),
  card_id TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, card_id)
);
CREATE TABLE IF NOT EXISTS anticipation_proposals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  titre TEXT NOT NULL,
  onglet TEXT NOT NULL,
  description TEXT NOT NULL,
  statut TEXT NOT NULL DEFAULT 'nouvelle',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_anticipation_proposals_user ON anticipation_proposals (user_id, id);

-- Instantanés quotidiens poussés par l'app LOCALE (17/10/2026) : balayage du S&P 500,
-- impossible à calculer sur le plan gratuit. Globaux (les mêmes pour tous les comptes),
-- une ligne par type et par jour à New York, ~30 jours conservés. Écrits seulement par
-- PUT /api/admin/snapshots/:kind (Basic Auth admin). Migration : scripts/migrate-snapshots.mjs.
CREATE TABLE IF NOT EXISTS daily_snapshots (
  kind TEXT NOT NULL,
  date TEXT NOT NULL,
  json TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (kind, date)
);
