// Tests des fonctions pures de cloud/src/lib/tv-symbols.js (import des
// watchlists TradingView). Format réel observé le 30/9/2026 : « BOURSE:SYMBOLE »,
// en-têtes « ###Section », crypto/forex/futures/indices mêlés aux actions.
import test from 'node:test';
import assert from 'node:assert/strict';
import { tvSymbolToTicker, normalizeWatchlists, mapWatchlistSymbols } from '../cloud/src/lib/tv-symbols.js';

test('actions US : symbole tel quel, bourse conservée', () => {
  assert.deepEqual(tvSymbolToTicker('NASDAQ:AAPL'), { ticker: 'AAPL', exchange: 'NASDAQ' });
  assert.deepEqual(tvSymbolToTicker('NYSE:IBM'), { ticker: 'IBM', exchange: 'NYSE' });
});

test('TSX/TSXV : suffixe Yahoo ; classes multiples avec tiret', () => {
  assert.deepEqual(tvSymbolToTicker('TSX:XEQT'), { ticker: 'XEQT.TO', exchange: 'TSX' });
  assert.deepEqual(tvSymbolToTicker('TSXV:ABC'), { ticker: 'ABC.V', exchange: 'TSX' });
  assert.equal(tvSymbolToTicker('NYSE:BRK.B').ticker, 'BRK-B');
  assert.equal(tvSymbolToTicker('TSX:RCI.B').ticker, 'RCI-B.TO');
});

test('crypto, forex, futures, indices et bourses inconnues sont refusés, jamais devinés', () => {
  for (const s of ['BINANCE:BTCUSDT', 'FX:EURUSD', 'NYMEX:MCL1!', 'TVC:DXY', 'CBOE:VIX', 'SPCFD:SPX', 'XETR:SAP']) {
    assert.ok(tvSymbolToTicker(s).skipped, s);
  }
  assert.ok(tvSymbolToTicker('AAPL').skipped);           // sans bourse
  assert.ok(tvSymbolToTicker(42).skipped);               // pas du texte
  assert.ok(tvSymbolToTicker('NASDAQ:A B').skipped);     // symbole invalide
});

test('normalizeWatchlists : forme réelle du MCP, nom vide → nom de secours, ids obligatoires', () => {
  const out = normalizeWatchlists({ watchlists: [
    { id: 1, name: 'HOLD', symbols: ['NYSE:IBM'], type: 'custom', active: false },
    { id: 2, name: '', color: 'red', type: 'colored', symbols: ['NASDAQ:ASML'] },
    { name: 'sans id', symbols: [] },
  ] });
  assert.equal(out.length, 2);
  assert.equal(out[0].id, '1');
  assert.equal(out[1].name, 'Liste red');
  assert.deepEqual(normalizeWatchlists(null), []);
});

test('mapWatchlistSymbols : sections ignorées sans bruit, doublons fusionnés, plafond respecté', () => {
  const m = mapWatchlistSymbols(['###Stocks', 'NASDAQ:AAPL', 'NASDAQ:AAPL', 'BINANCE:SOLUSDT', 'NYSE:IBM', 'NYSE:RBLX'], 2);
  assert.deepEqual(m.imported.map((t) => t.ticker), ['AAPL', 'IBM']);
  assert.equal(m.truncated, 1);
  assert.deepEqual(m.skipped.map((s) => s.symbol), ['BINANCE:SOLUSDT']);
});

import { yahooTickerToTvCandidates, tvBarsToDailyBars } from '../cloud/src/lib/tv-symbols.js';
import { dataSourceHeader } from '../cloud/src/lib/tv-provider.js';

test('ticker Yahoo → candidats TradingView : bourses à essayer, TSX direct, le reste refusé', () => {
  assert.deepEqual(yahooTickerToTvCandidates('AAPL'), ['NASDAQ:AAPL', 'NYSE:AAPL', 'AMEX:AAPL']);
  assert.deepEqual(yahooTickerToTvCandidates('BRK-B'), ['NASDAQ:BRK.B', 'NYSE:BRK.B', 'AMEX:BRK.B']);
  assert.deepEqual(yahooTickerToTvCandidates('XEQT.TO'), ['TSX:XEQT']);
  assert.deepEqual(yahooTickerToTvCandidates('RCI-B.TO'), ['TSX:RCI.B']);
  assert.deepEqual(yahooTickerToTvCandidates('ABC.V'), ['TSXV:ABC']);
  for (const t of ['^VIX', 'DX-Y.NYB', 'EURUSD=X', 'BP.L', 'NASDAQ:AAPL', '', null]) assert.equal(yahooTickerToTvCandidates(t), null, String(t));
});

test('barres TradingView → barres quotidiennes triées, sans clôture/volume manquant', () => {
  const bars = tvBarsToDailyBars([
    { t: 1790688600, o: 2, h: 3, l: 1, c: 2.5, v: 100 },
    { t: 1790602200, o: 1, h: 2, l: 1, c: 1.5, v: 50 },
    { t: 1790343000, o: 1, h: 1, l: 1, c: null, v: 10 },   // sans clôture : écartée
    { t: 1790343001, o: 1, h: 1, l: 1, c: 1, v: null },    // sans volume : écartée
  ]);
  assert.equal(bars.length, 2);
  assert.ok(bars[0].date < bars[1].date);
  assert.deepEqual([bars[1].open, bars[1].close, bars[1].volume], [2, 2.5, 100]);
  assert.ok(bars[0].date instanceof Date);
  assert.deepEqual(tvBarsToDailyBars(null), []);
});

test('en-tête de source : tradingview / mixed / yahoo-fallback / absent', () => {
  assert.equal(dataSourceHeader({ tv: 5, yahoo: 0 }), 'tradingview');
  assert.equal(dataSourceHeader({ tv: 5, yahoo: 2 }), 'mixed');
  assert.equal(dataSourceHeader({ tv: 0, yahoo: 3 }), 'yahoo-fallback');
  assert.equal(dataSourceHeader({ tv: 0, yahoo: 0 }), null);
});
