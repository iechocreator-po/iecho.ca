import { getEffectiveFlagsForUser } from '../db/flags.js';
import { getOverrides } from '../db/concepts.js';

// Lecture seule, pour l'utilisateur connecté (session). Les MODIFICATIONS
// passent par l'API d'administration (routes/admin.js), jamais par ici :
// un testeur ne bascule ni un flag ni un texte.
//
// getEffectiveFlagsForUser (22/9/2026) — global ⊕ surcharges PAR COMPTE
// (KNOWN_USER_FLAGS) : deux comptes peuvent désormais voir des valeurs
// différentes pour le même flag (ex. options_a_tab activé chez un testeur
// précis sans toucher au réglage global des autres).
export function registerFlagsRoutes(app) {
  app.get('/api/flags', async (c) => c.json({ flags: await getEffectiveFlagsForUser(c.env.DB, c.get('userId')) }));
  app.get('/api/concepts', async (c) => c.json({ overrides: await getOverrides(c.env.DB) }));
}
