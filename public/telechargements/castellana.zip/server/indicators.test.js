// Tests unitaires sur les fonctions PURES de indicators.js (aucun appel
// réseau, aucun mock) — amélioration demandée par JP (31/8/2026) après que
// deux bugs réels aient été trouvés uniquement en testant à la main cette
// session (fetchJSON cassé, script sidecar cassé sur Windows). `node:test`
// natif (Node 22), zéro dépendance ajoutée — cohérent avec le reste du
// projet. Lancer avec `npm test`.
//
// Les fonctions qui appellent Yahoo Finance (getHomemadeIndicators,
// fetchDailyHistory, getHomemadeIndicatorsBatch, checkYahooConnection)
// restent hors périmètre : pas d'infrastructure de mock dans ce projet,
// testées manuellement en direct comme le reste de l'app.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { computeSMA, computeOBV, computeTrueRange, computeATR, computeVolumeVs20d, computeRSI } from './indicators.js';

test('computeSMA — fenêtre glissante sur une série connue', () => {
  const closes = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  assert.deepEqual(computeSMA(closes, 3), [null, null, 2, 3, 4, 5, 6, 7, 8, 9]);
});

test('computeSMA — historique plus court que la période retourne tout null', () => {
  assert.deepEqual(computeSMA([1, 2], 5), [null, null]);
});

test('computeOBV — cumul +volume/-volume/inchangé selon la clôture', () => {
  const bars = [
    { close: 10, volume: 100 },
    { close: 12, volume: 100 }, // hausse -> +100
    { close: 11, volume: 100 }, // baisse -> -100
    { close: 11, volume: 100 }, // inchangé -> +0
    { close: 13, volume: 100 }, // hausse -> +100
  ];
  assert.deepEqual(computeOBV(bars), [0, 100, 0, 0, 100]);
});

test('computeVolumeVs20d — le jour courant est exclu de sa propre moyenne', () => {
  const bars = [
    ...Array.from({ length: 20 }, () => ({ volume: 1000 })),
    { volume: 3000 }, // 21e barre, jour courant
  ];
  assert.deepEqual(computeVolumeVs20d(bars), { ratio: 3, volumeSMA20: 1000 });
});

test('computeVolumeVs20d — moins de 21 barres retourne null explicite (pas 0)', () => {
  const bars = Array.from({ length: 5 }, () => ({ volume: 1000 }));
  assert.deepEqual(computeVolumeVs20d(bars), { ratio: null, volumeSMA20: null });
});

test('computeTrueRange — max(high-low, |high-clôture veille|, |low-clôture veille|)', () => {
  const bars = [
    { high: 10, low: 8, close: 9 },
    { high: 12, low: 9, close: 11 },
    { high: 13, low: 11, close: 12 },
    { high: 15, low: 12, close: 14 },
  ];
  assert.deepEqual(computeTrueRange(bars), [2, 3, 2, 3]);
});

test('computeATR — lissage Wilder (RMA) appliqué au True Range, pas une SMA', () => {
  const bars = [
    { high: 10, low: 8, close: 9 },
    { high: 12, low: 9, close: 11 },
    { high: 13, low: 11, close: 12 },
    { high: 15, low: 12, close: 14 },
  ];
  // TR = [2,3,2,3] (vérifié par le test précédent). RMA(period=2) à la main :
  // out[1] = (2+3)/2 = 2.5 ; out[2] = (2.5*1+2)/2 = 2.25 ; out[3] = (2.25*1+3)/2 = 2.625
  assert.deepEqual(computeATR(bars, 2), [null, 2.5, 2.25, 2.625]);
});

// --- RSI (ajouté le 7/9/2026, repris du sidecar tradingview-mcp) --------
// Les cas ci-dessous sont DÉRIVABLES à la main plutôt que recopiés d'une
// exécution : un test qui fige la sortie du code qu'il teste ne prouve rien.

test('computeRSI vaut 100 quand il n\'y a que des hausses', () => {
  // loss = 0 → RS infini → RSI = 100, par définition de Wilder.
  const closes = Array.from({ length: 30 }, (_, i) => 100 + i);
  assert.equal(computeRSI(closes, 14), 100);
});

test('computeRSI vaut exactement 50 sur l\'amorce quand gains et pertes se compensent', () => {
  // Exactement period+1 clôtures : seule l'amorce (moyenne simple sur 14
  // variations) est utilisée, la boucle de lissage ne s'exécute pas.
  // 7 hausses de +1 et 7 baisses de -1 → RS = 1 → RSI = 100 - 100/2 = 50.
  const closes = Array.from({ length: 15 }, (_, i) => (i % 2 === 0 ? 100 : 101));
  assert.ok(Math.abs(computeRSI(closes, 14) - 50) < 1e-9);
});

test('computeRSI reste proche de 50 sur une longue alternance', () => {
  // Au-delà de l'amorce, le lissage de Wilder OSCILLE autour de 50 sans
  // jamais y revenir exactement : la dernière variation penche d'un côté.
  // C'est le comportement correct de Wilder, pas une imprécision — d'où une
  // assertion d'encadrement plutôt que d'égalité.
  const closes = Array.from({ length: 41 }, (_, i) => (i % 2 === 0 ? 100 : 101));
  const rsi = computeRSI(closes, 14);
  assert.ok(Math.abs(rsi - 50) < 5, `RSI ${rsi} trop éloigné de 50`);
  assert.ok(rsi < 50, 'la série se termine sur une baisse, le RSI doit passer sous 50');
});

test('computeRSI tend vers 0 quand il n\'y a que des baisses', () => {
  const closes = Array.from({ length: 30 }, (_, i) => 100 - i);
  assert.ok(computeRSI(closes, 14) < 1e-9);
});

test('computeRSI reste borné entre 0 et 100 sur une série irrégulière', () => {
  const closes = [44, 44.3, 44.1, 44.6, 43.4, 44.1, 44.2, 44.5, 43.4, 43.6, 44.3, 44.8, 45.1, 45.6, 45.9, 46.2, 45.7, 46.4, 46.2, 45.6, 46.2];
  const rsi = computeRSI(closes, 14);
  assert.ok(rsi > 0 && rsi < 100, `RSI hors bornes : ${rsi}`);
});

test('computeRSI répond null plutôt que d\'inventer sur un historique trop court', () => {
  // « Pas calculable » doit rester distinct de « valeur neutre » : c'est
  // exactement la confusion que l'audit reprochait aux trous silencieux.
  assert.equal(computeRSI([1, 2, 3], 14), null);
  assert.equal(computeRSI(Array.from({ length: 14 }, (_, i) => i), 14), null);
  assert.ok(computeRSI(Array.from({ length: 15 }, (_, i) => i), 14) !== null);
});

test('computeRSI respecte réellement la période demandée', () => {
  // Le sidecar imposait 14 ; le calcul maison rend la période configurable.
  // Deux périodes différentes sur la même série doivent diverger.
  const closes = [44, 44.3, 44.1, 44.6, 43.4, 44.1, 44.2, 44.5, 43.4, 43.6, 44.3, 44.8, 45.1, 45.6, 45.9, 46.2, 45.7, 46.4, 46.2, 45.6, 46.2];
  assert.notEqual(computeRSI(closes, 7), computeRSI(closes, 14));
});
