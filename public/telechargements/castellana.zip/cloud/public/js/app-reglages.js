// js/app-reglages.js — Statut du backend, préférences, pondération du score, version et mise à jour
// Extrait de l'ancien script en ligne des index.html (découpage phase 2, 20/10/2026) : code déplacé tel quel, sans réécriture.
// Fichier COMMUN aux versions locale et cloud : source ici ; cloud/public/js/app-reglages.js en est la copie (npm run sync:cloud).
// Script classique : ses noms de premier niveau sont globaux et partagés avec les autres scripts de la page.

// ---- Réglages utilisateur (feature 351, point 4) ----
// Les périodes vivent en base (server/preferences.js) et pilotent
// réellement le calcul. Elles survivent aux mises à jour de l'app, qui ne
// touchent jamais à data/.
let PREF_DEFAULTS = null;
const PREF_FIELDS = {
  smaFast: 'pref-sma-fast',
  smaMedium: 'pref-sma-medium',
  smaSlow: 'pref-sma-slow',
  rsiPeriod: 'pref-rsi',
};
function prefStatus(message, ok) {
  const el = document.getElementById('pref-status');
  el.textContent = message;
  el.className = 'pref-status' + (message ? (ok ? ' is-ok' : ' is-bad') : '');
}
function fillPreferenceFields(prefs) {
  for (const [key, id] of Object.entries(PREF_FIELDS)) {
    const el = document.getElementById(id);
    if (el) el.value = prefs[key];
  }
  // Les libellés de l'app doivent suivre les vraies périodes, sinon la
  // checklist annoncerait « SMA 9 > 21 > 100 » pendant que le serveur
  // calcule sur autre chose — exactement l'incohérence que cette feature
  // supprime.
  CFG.indicateurs.smaRapide = prefs.smaFast;
  CFG.indicateurs.smaMoyenne = prefs.smaMedium;
  CFG.indicateurs.smaLente = prefs.smaSlow;
  CFG.indicateurs.rsiPeriode = prefs.rsiPeriod;
  const smaLbl = document.getElementById('lbl-sma');
  if (smaLbl) smaLbl.textContent = `SMA ${prefs.smaFast} > ${prefs.smaMedium} > ${prefs.smaSlow}`;
  const rsiLbl = document.getElementById('lbl-rsi-period');
  if (rsiLbl) rsiLbl.textContent = prefs.rsiPeriod;
  // Les 3 champs SMA de l'onglet Labo partent des mêmes valeurs : deux
  // écrans qui afficheraient des périodes différentes pour le même
  // indicateur seraient une source de confusion garantie.
  const labo = { 'labo-sma-fast': prefs.smaFast, 'labo-sma-medium': prefs.smaMedium, 'labo-sma-slow': prefs.smaSlow };
  for (const [id, value] of Object.entries(labo)) {
    const el = document.getElementById(id);
    if (el) el.value = value;
  }
}
async function loadPreferences() {
  try {
    const data = await fetchJSON('/api/preferences');
    PREF_DEFAULTS = data.defaults;
    fillPreferenceFields(data.preferences);
  } catch (err) {
    prefStatus(`Réglages non chargés : ${err.message}`, false);
  }
}
async function savePreferences() {
  const patch = {};
  for (const [key, id] of Object.entries(PREF_FIELDS)) {
    patch[key] = document.getElementById(id).value;
  }
  prefStatus('Enregistrement…', true);
  try {
    const data = await fetchJSON('/api/preferences', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch),
    });
    fillPreferenceFields(data.preferences);
    prefStatus('Enregistré. Le screening sera recalculé avec ces périodes.', true);
    // Le cache de screening a été vidé côté serveur : on rafraîchit ce qui
    // est déjà à l'écran plutôt que de laisser des chiffres périmés.
    refreshSelectionsPassively(['sec', 'scr']);
    calcFiche();
  } catch (err) {
    prefStatus(err.message, false);
  }
}
async function resetPreferencesToDefaults() {
  prefStatus('Réinitialisation…', true);
  try {
    const data = await fetchJSON('/api/preferences/reset', { method: 'POST' });
    fillPreferenceFields(data.preferences);
    const d = data.preferences;
    prefStatus(`Valeurs par défaut rétablies : SMA ${d.smaFast}/${d.smaMedium}/${d.smaSlow}, RSI ${d.rsiPeriod}.`, true);
    refreshSelectionsPassively(['sec', 'scr']);
    calcFiche();
  } catch (err) {
    prefStatus(err.message, false);
  }
}
// ---- Pondération du score fondamental (2/10/2026) ----
// Cinq poids entiers dont la somme fait 100 ; le serveur valide (même règle) et les stocke par utilisateur.
// js/fcf-card.js les applique au score de la carte « Fondamentaux » (setFcfWeights re-rend les cartes ouvertes).
const WEIGHT_FIELDS = {
  growth: 'fw-growth', consistency: 'fw-consistency', conversion: 'fw-conversion',
  dilution: 'fw-dilution', valuation: 'fw-valuation', balance: 'fw-balance',
};
function weightsStatus(message, ok) {
  const el = document.getElementById('fw-status');
  el.textContent = message;
  el.className = 'pref-status' + (message ? (ok ? ' is-ok' : ' is-bad') : '');
}
function updateWeightsTotal() {
  const total = Object.values(WEIGHT_FIELDS).reduce((acc, id) => acc + (Number.parseInt(document.getElementById(id).value, 10) || 0), 0);
  const el = document.getElementById('fw-total');
  el.textContent = total === 100 ? 'Total : 100 % ✓' : `Total : ${total} % — la pondération doit faire exactement 100 % (${total < 100 ? `il manque ${100 - total}` : `${total - 100} en trop`}).`;
  el.style.color = total === 100 ? 'var(--green)' : 'var(--red)';
}
function fillWeightFields(w) {
  for (const [key, id] of Object.entries(WEIGHT_FIELDS)) document.getElementById(id).value = w[key];
  updateWeightsTotal();
  if (typeof setFcfWeights === 'function') setFcfWeights(w);
}
async function loadWeights() {
  try {
    fillWeightFields((await fetchJSON('/api/fundamental-weights')).weights);
  } catch (err) {
    weightsStatus(`Pondération non chargée : ${err.message}`, false);
  }
}
async function saveWeights() {
  const patch = {};
  for (const [key, id] of Object.entries(WEIGHT_FIELDS)) patch[key] = document.getElementById(id).value;
  weightsStatus('Enregistrement…', true);
  try {
    const data = await fetchJSON('/api/fundamental-weights', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(patch) });
    fillWeightFields(data.weights);
    weightsStatus('Enregistré. La carte Fondamentaux utilise cette pondération.', true);
  } catch (err) {
    weightsStatus(err.message, false);
  }
}
async function resetWeights() {
  weightsStatus('Réinitialisation…', true);
  try {
    const data = await fetchJSON('/api/fundamental-weights/reset', { method: 'POST' });
    fillWeightFields(data.weights);
    weightsStatus('Pondération par défaut rétablie : 20 % pour chacun des cinq premiers critères, 0 % pour le bilan.', true);
  } catch (err) {
    weightsStatus(err.message, false);
  }
}
