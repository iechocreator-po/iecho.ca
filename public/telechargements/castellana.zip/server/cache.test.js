// Tests du cache persistant (server/cache.js). Utilise la vraie base SQLite
// — c'est le comportement qu'on veut vérifier — avec des clés préfixées
// `test:` nettoyées à la fin, pour ne jamais toucher aux vraies entrées.

import test from 'node:test';
import assert from 'node:assert/strict';
import { readCache, readCacheRaw, writeCache, cached, purgeExpiredCache } from './cache.js';
import { db } from './db.js';

const K = (n) => `test:cache:${n}`;
test.after(() => { db.prepare("DELETE FROM cache WHERE key LIKE 'test:cache:%'").run(); });

test('une valeur écrite est relue à l’identique', () => {
  writeCache(K('simple'), { a: 1, b: 'deux', c: [3] }, 60);
  const { hit, value } = readCache(K('simple'));
  assert.equal(hit, true);
  assert.deepEqual(value, { a: 1, b: 'deux', c: [3] });
});

test('une entrée expirée n’est pas servie', () => {
  writeCache(K('expire'), { v: 1 }, 0); // TTL nul = déjà périmée
  assert.equal(readCache(K('expire')).hit, false);
});

test('readCacheRaw sert une entrée expirée, avec son âge', () => {
  // C'est ce qui permet à l'export CSV et au « P/E industrie » de s'appuyer
  // sur le dernier screening connu, même vieux, plutôt que de répondre
  // « aucun screening » ou de relancer 21 appels à l'insu de l'utilisateur.
  writeCache(K('vieux'), { v: 42 }, 0);
  const raw = readCacheRaw(K('vieux'));
  assert.equal(raw.found, true);
  assert.deepEqual(raw.value, { v: 42 });
  assert.ok(raw.ageSeconds >= 0);
});

test('une clé absente ne prétend jamais avoir une valeur', () => {
  assert.equal(readCache(K('jamais-ecrite')).hit, false);
  assert.equal(readCacheRaw(K('jamais-ecrite')).found, false);
});

test('cached() n’appelle la source qu’une fois tant que l’entrée est fraîche', async () => {
  let appels = 0;
  const source = async () => { appels += 1; return { n: appels }; };
  assert.deepEqual(await cached(K('memo'), 60, source), { n: 1 });
  assert.deepEqual(await cached(K('memo'), 60, source), { n: 1 });
  assert.equal(appels, 1);
  // force:true contourne le cache — c'est ce que fait ?force=true côté API.
  assert.deepEqual(await cached(K('memo'), 60, source, { force: true }), { n: 2 });
});

test('cached() ne met JAMAIS un échec en cache', async () => {
  let appels = 0;
  const source = async () => { appels += 1; throw new Error('panne réseau'); };
  await assert.rejects(() => cached(K('echec'), 60, source));
  await assert.rejects(() => cached(K('echec'), 60, source));
  assert.equal(appels, 2, 'un échec réseau ne doit pas devenir un trou de données persistant');
  assert.equal(readCacheRaw(K('echec')).found, false);
});

test('revive reconstruit ce que JSON ne sait pas porter', async () => {
  // Sans `revive`, une valeur relue du cache n'aurait pas la même forme
  // qu'une valeur fraîche (les Date deviennent des chaînes) et le bug ne se
  // verrait qu'au DEUXIÈME appel.
  const revive = (rows) => rows.map((r) => ({ ...r, date: new Date(r.date) }));
  const source = async () => [{ date: new Date('2026-09-07T00:00:00Z'), close: 10 }];
  const frais = await cached(K('dates'), 60, source, { revive });
  const relu = await cached(K('dates'), 60, source, { revive });
  assert.ok(frais[0].date instanceof Date);
  assert.ok(relu[0].date instanceof Date, 'la valeur relue doit avoir la même forme que la fraîche');
  assert.equal(relu[0].date.toISOString(), frais[0].date.toISOString());
});

test('purgeExpiredCache retire les entrées périmées et garde les fraîches', () => {
  writeCache(K('purge-vieux'), { v: 1 }, 0);
  writeCache(K('purge-frais'), { v: 2 }, 3600);
  purgeExpiredCache();
  assert.equal(readCacheRaw(K('purge-vieux')).found, false);
  assert.equal(readCacheRaw(K('purge-frais')).found, true);
});
