// Journal de trades — portage Cloudflare de server/trades.js, DÉSORMAIS PAR
// UTILISATEUR (`user_id`, ajouté à chaque requête). Mêmes colonnes, mêmes
// règles de validation, même ordre d'export CSV que la version locale.

import { isValidTicker, TICKER_ERROR } from '../lib/ticker-format.js';
import { tradeNumberErrors } from '../lib/trade-rules.js';

export const COLUMNS = [
  'date_entree', 'date_sortie', 'compte', 'ticker', 'prix_entree', 'prix_sortie',
  'taille_position', 'stop_initial', 'vix_a_entree', 'rsi_a_entree', 'obv_a_entree',
  'correlation_flag', 'checklist_complete', 'r_realise', 'resultat',
  'setup_score', 'contexte_score', 'alignement_a_entree', 'signal_age_a_entree',
  // Traçabilité (22/9/2026) : ligne créée automatiquement par l'assignation
  // d'un put d'un cycle d'options — voir cloud/src/db/option-trades.js.
  'option_cycle_id',
  // Journal de la Roue (#433) : commissions d'achat et de vente des actions, provenance.
  'commission_entree', 'commission_sortie', 'source',
];

const REQUIRED_ON_CREATE = ['date_entree', 'compte', 'ticker', 'prix_entree', 'taille_position', 'stop_initial'];

const COMPTES = ['RRSP', 'margin', 'corporatif'];
const OBV_VALUES = ['accumulation', 'neutre', 'distribution'];
const RESULTATS = ['gagnant', 'perdant'];
const ALIGNEMENTS = ['haussier', 'neutre', 'baissier'];

export function validateTrade(data, { partial = false } = {}) {
  const errors = [];
  if (!partial) {
    for (const field of REQUIRED_ON_CREATE) {
      if (data[field] === undefined || data[field] === null || data[field] === '') {
        errors.push(`${field} est requis`);
      }
    }
  }
  if (data.compte != null && !COMPTES.includes(data.compte)) {
    errors.push(`compte doit être l'un de : ${COMPTES.join(', ')}`);
  }
  if (data.ticker != null && data.ticker !== '' && !isValidTicker(String(data.ticker))) errors.push(TICKER_ERROR);
  if (data.obv_a_entree != null && !OBV_VALUES.includes(data.obv_a_entree)) {
    errors.push(`obv_a_entree doit être l'un de : ${OBV_VALUES.join(', ')}`);
  }
  if (data.resultat != null && !RESULTATS.includes(data.resultat)) {
    errors.push(`resultat doit être l'un de : ${RESULTATS.join(', ')}`);
  }
  if (data.correlation_flag !== undefined && ![0, 1].includes(Number(data.correlation_flag))) {
    errors.push('correlation_flag doit être 0 ou 1');
  }
  if (data.checklist_complete !== undefined && ![0, 1].includes(Number(data.checklist_complete))) {
    errors.push('checklist_complete doit être 0 ou 1');
  }
  if (data.alignement_a_entree != null && !ALIGNEMENTS.includes(data.alignement_a_entree)) {
    errors.push(`alignement_a_entree doit être l'un de : ${ALIGNEMENTS.join(', ')}`);
  }
  for (const f of ['commission_entree', 'commission_sortie']) {
    if (data[f] != null && data[f] !== '' && !(Number(data[f]) >= 0)) errors.push(`${f} doit être ≥ 0`);
  }
  if (data.source != null && !['saisie', 'import_sheets'].includes(data.source)) errors.push('source doit être saisie ou import_sheets');
  errors.push(...tradeNumberErrors(data)); // nombres et dates (audit routes, 21/10/2026)
  // Une modification partielle ne peut pas VIDER un champ obligatoire (audit routes locales, 21/10/2026) : {ticker:'', date_entree:null}
  // était accepté et écrit tel quel (ticker vide envoyé ensuite aux cotations).
  if (partial) {
    for (const field of REQUIRED_ON_CREATE) {
      if (field in data && (data[field] === null || data[field] === '' || (typeof data[field] === 'string' && data[field].trim() === ''))) errors.push(`${field} ne peut pas être vide`);
    }
  }
  return errors;
}

function normalize(data) {
  return data.ticker !== undefined ? { ...data, ticker: String(data.ticker).trim().toUpperCase() } : data;
}

export async function createTrade(db, userId, rawData) {
  const data = normalize(rawData);
  const cols = COLUMNS.filter((c) => data[c] !== undefined);
  const result = await db.prepare(
    `INSERT INTO trades (user_id, ${cols.join(', ')}) VALUES (?, ${cols.map(() => '?').join(', ')})`,
  ).bind(userId, ...cols.map((c) => data[c])).run();
  return getTrade(db, userId, result.meta.last_row_id);
}

export async function listTrades(db, userId, { compte, ticker, open } = {}) {
  let sql = 'SELECT * FROM trades WHERE user_id = ?';
  const params = [userId];
  if (compte) { sql += ' AND compte = ?'; params.push(compte); }
  if (ticker) { sql += ' AND ticker = ?'; params.push(ticker.toUpperCase()); }
  if (open === true) sql += ' AND date_sortie IS NULL';
  if (open === false) sql += ' AND date_sortie IS NOT NULL';
  sql += ' ORDER BY date_entree DESC, id DESC';
  const { results } = await db.prepare(sql).bind(...params).all();
  return results;
}

export async function getTrade(db, userId, id) {
  return db.prepare('SELECT * FROM trades WHERE id = ? AND user_id = ?').bind(id, userId).first();
}

export async function updateTrade(db, userId, id, rawData) {
  const data = normalize(rawData);
  const cols = COLUMNS.filter((c) => data[c] !== undefined);
  if (cols.length > 0) {
    await db.prepare(
      `UPDATE trades SET ${cols.map((c) => `${c} = ?`).join(', ')} WHERE id = ? AND user_id = ?`,
    ).bind(...cols.map((c) => data[c]), id, userId).run();
  }
  return getTrade(db, userId, id);
}

export async function deleteTrade(db, userId, id) {
  const result = await db.prepare('DELETE FROM trades WHERE id = ? AND user_id = ?').bind(id, userId).run();
  return (result.meta?.changes ?? 0) > 0;
}
