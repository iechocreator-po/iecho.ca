#!/bin/bash
# installer-sidecar.command — installation OPTIONNELLE du sidecar Python
# (macOS, 7/9/2026).
#
# castellana n'a PAS besoin de ce composant. Depuis le 7/9/2026, RSI, SMA
# 50/200, Golden Cross, VIX et cotations sont calculés par l'app elle-même
# depuis Yahoo Finance — vérifiés identiques à la décimale contre ce sidecar
# sur 19 titres, et disponibles pour 2 titres de plus (PLTR, XEQT.TO) qu'il
# ne savait pas résoudre du tout.
#
# Ce script n'existe que pour qui veut COMPARER les deux sources. Il coûte
# ~170 Mo et un second processus à garder vivant. Pour revenir en arrière :
# remettre "enabled": false dans settings.json (aucune désinstallation
# nécessaire, le dossier .venv-mcp peut simplement être supprimé).

set -u
cd "$(dirname "$0")"

echo "=== castellana — sidecar tradingview-mcp (OPTIONNEL) ==="
echo
echo "⚠️  Ce composant n'est pas nécessaire au fonctionnement de castellana."
echo "    Il ajoute ~170 Mo et un second processus à maintenir en vie."
echo "    Il ne sert qu'à comparer les valeurs calculées par l'app avec"
echo "    celles de TradingView."
echo
printf "Installer quand même ? [o/N] "
read -r reponse
case "$reponse" in
  o|O|oui|Oui|y|Y) ;;
  *) echo "Annulé — rien n'a été modifié."; exit 0 ;;
esac
echo

if ! command -v python3 >/dev/null 2>&1; then
  echo "❌ Python 3 introuvable. Ouverture de la page de téléchargement..."
  open "https://www.python.org/downloads/"
  echo "Installe Python 3 puis relance ce fichier. Appuie sur Entrée pour fermer."
  read -r _
  exit 1
fi
echo "✅ Python 3 détecté ($(python3 --version 2>&1))."

if [ ! -f ".venv-mcp/bin/tradingview-mcp" ]; then
  echo "📦 Installation du sidecar (~170 Mo)..."
  python3 -m venv .venv-mcp && .venv-mcp/bin/pip install --quiet tradingview-mcp-server
fi

if [ ! -f ".venv-mcp/bin/tradingview-mcp" ]; then
  echo "❌ L'installation a échoué. castellana continue de fonctionner sans."
  read -r _
  exit 1
fi
echo "✅ Sidecar installé."

# Bascule "enabled" à true dans settings.json, sans dépendance externe :
# Node est déjà requis par castellana, autant s'en servir plutôt que
# d'imposer jq ou une édition manuelle au testeur.
node -e "
const fs=require('fs');
const s=JSON.parse(fs.readFileSync('settings.json','utf8'));
s.tradingviewMcp.enabled=true;
fs.writeFileSync('settings.json', JSON.stringify(s,null,2)+'\n');
console.log('✅ settings.json : sidecar activé.');
"
echo
echo "Il faut maintenant DEUX processus :"
echo "  1. npm start        (castellana)"
echo "  2. npm run sidecar  (ce sidecar, dans un second terminal)"
echo
echo "Appuie sur Entrée pour fermer."
read -r _
