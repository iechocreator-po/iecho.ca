import { getWatchlist, addToWatchlist, removeFromWatchlist } from '../db/watchlist.js';
import { screeningCacheKey } from '../lib/screening.js';

async function bustScreeningCache(db, userId) {
  await db.batch([
    db.prepare('DELETE FROM cache WHERE key = ?').bind(screeningCacheKey(userId, 'watchlist')),
    db.prepare('DELETE FROM cache WHERE key = ?').bind(screeningCacheKey(userId, 'elargi')),
  ]);
}

export function registerWatchlistRoutes(app) {
  app.get('/api/watchlist', async (c) => {
    return c.json({ watchlist: await getWatchlist(c.env.DB, c.get('userId')) });
  });

  app.post('/api/watchlist', async (c) => {
    const userId = c.get('userId');
    const body = await c.req.json().catch(() => ({}));
    const { ticker, exchange } = body;
    if (typeof ticker !== 'string' || !/^[A-Za-z.\-]{1,10}$/.test(ticker)) {
      return c.json({ error: 'ticker invalide' }, 400);
    }
    const watchlist = await addToWatchlist(c.env.DB, userId, ticker, exchange || 'NASDAQ');
    await bustScreeningCache(c.env.DB, userId);
    return c.json({ watchlist }, 201);
  });

  app.delete('/api/watchlist/:ticker', async (c) => {
    const userId = c.get('userId');
    if (!(await removeFromWatchlist(c.env.DB, userId, c.req.param('ticker')))) {
      return c.json({ error: 'ticker absent de la watchlist' }, 404);
    }
    await bustScreeningCache(c.env.DB, userId);
    return c.json({ watchlist: await getWatchlist(c.env.DB, userId) });
  });
}
