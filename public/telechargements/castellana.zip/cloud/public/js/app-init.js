// js/app-init.js — Branchements exécutés au chargement (écouteurs, thème, minuteries), regroupés APRÈS toutes les déclarations
// Extrait de l'ancien script en ligne des index.html (découpage phase 2, 20/10/2026) : code déplacé tel quel, sans réécriture.
// Fichier COMMUN aux versions locale et cloud : source ici ; cloud/public/js/app-init.js en est la copie (npm run sync:cloud).
// Script classique : ses noms de premier niveau sont globaux et partagés avec les autres scripts de la page.

document.querySelectorAll('.tab-btn').forEach(btn => btn.addEventListener('click', () => switchTab(btn.dataset.tab)));
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && document.getElementById('settings-overlay').style.display !== 'none') closeSettings();
  if (e.key === 'Escape' && document.getElementById('chart-overlay').style.display !== 'none') closeChartOverlay();
  if (e.key === 'Escape' && document.getElementById('table-overlay').style.display !== 'none') closeTableOverlay();
});
document.querySelectorAll('#theme-switch button').forEach(b =>
  b.addEventListener('click', () => appliquerTheme(b.dataset.themeChoice)));
let themeSauve = null;
try { themeSauve = localStorage.getItem('castellana-theme'); } catch { /* stockage bloqué : thème automatique */ }
appliquerTheme(themeSauve || 'auto');
setAppWidth(document.documentElement.getAttribute('data-app-width') || 'large');
document.addEventListener('click', (e) => {
  const pop = document.getElementById('glossaire-pop');
  if (pop.style.display === 'block' && !pop.contains(e.target) && !e.target.classList.contains('info-btn')) hideGlossaire();
});
document.addEventListener('DOMContentLoaded', () => {
  const sel = document.getElementById('correlated');
  if (sel) sel.addEventListener('change', () => {
    const note = document.getElementById('correlated-note');
    if (note && correlationComputedText) note.textContent = `Choix manuel. Valeur calculée : ${correlationComputedText}`;
  });
});
initSortableHeaders('screen-table', () => lastScreeningRows, (rows) => { lastScreeningRows = rows; }, renderScreeningRows);
initSortableHeaders('sector-top-table', () => lastSectorTopRows, (rows) => { lastSectorTopRows = rows; }, renderSectorTopRows);
document.querySelectorAll('.currency-btn').forEach((b) => b.addEventListener('click', () => setSectorCurrency(b.dataset.currency)));
document.querySelectorAll('.top-mode-btn').forEach((b) => b.addEventListener('click', () => setSectorTopMode(b.dataset.topmode)));
document.getElementById('sector-period-select').addEventListener('change', (e) => setSectorPeriod(+e.target.value));
document.querySelectorAll('.category-chk').forEach((chk) => {
  chk.addEventListener('change', () => {
    if (chk.checked) selectedCategories.add(chk.dataset.category); else selectedCategories.delete(chk.dataset.category);
    renderSectorChart();
  });
});
document.getElementById('screen-chart-period-select').addEventListener('change', (e) => setScreenChartPeriod(+e.target.value));
setInterval(() => { if (appDemarree) checkStatus(); }, 30000);
setInterval(() => { if (appDemarree) loadHeaderIndices(); }, 30000);
