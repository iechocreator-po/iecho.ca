import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeEmails, planAppSettingsWrites, normalizePositionAlerts, kindsReenabled, POSITION_ALERT_DEFAULTS } from './app-settings.js';

test('normalise : trim, minuscules, doublons, vides ignorés', () => {
  assert.deepEqual(normalizeEmails([' A@x.com ', 'a@x.com', '', 'b@y.ca']), ['a@x.com', 'b@y.ca']);
  assert.deepEqual(normalizeEmails([]), []);
});
test('refuse une adresse invalide ou une liste trop longue', () => {
  assert.throws(() => normalizeEmails(['pas-un-courriel']), /invalide/);
  assert.throws(() => normalizeEmails(Array.from({ length: 11 }, (_, i) => `u${i}@x.com`)), /Maximum/);
  assert.throws(() => normalizeEmails(42));
});
test('accepte une chaîne séparée par des virgules (point-virgule et sauts de ligne tolérés)', () => {
  assert.deepEqual(normalizeEmails('A@x.com, b@y.ca;c@z.org\n a@x.com ,'), ['a@x.com', 'b@y.ca', 'c@z.org']);
  assert.deepEqual(normalizeEmails(''), []);
  assert.throws(() => normalizeEmails('a@x.com, pas-un-courriel'), /invalide/);
  assert.throws(() => normalizeEmails(Array.from({ length: 11 }, (_, i) => `u${i}@x.com`).join(',')), /Maximum/);
});

// Alertes de positions : l'utilisateur décide (tout activé par défaut, comme avant la case).
test('alertes de positions : défauts = tout activé; un patch partiel ne touche que ce qu\'il nomme', () => {
  assert.deepEqual(POSITION_ALERT_DEFAULTS, { enabled: true, kinds: { echeance: true, profit: true, stop: true }, email: true });
  const r = normalizePositionAlerts({ kinds: { profit: false } });
  assert.deepEqual(r, { enabled: true, kinds: { echeance: true, profit: false, stop: true }, email: true });
  assert.deepEqual(normalizePositionAlerts({ enabled: false, email: false }, r), { enabled: false, kinds: { echeance: true, profit: false, stop: true }, email: false });
});
test('alertes de positions : seuls des booléens et des situations connues sont acceptés', () => {
  assert.throws(() => normalizePositionAlerts({ enabled: 'oui' }), /vrai ou faux/);
  assert.throws(() => normalizePositionAlerts({ kinds: { inconnue: true } }), /inconnue/);
  assert.throws(() => normalizePositionAlerts({ kinds: { profit: 1 } }), /vrai ou faux/);
  assert.throws(() => normalizePositionAlerts(null), /invalides/);
  assert.throws(() => normalizePositionAlerts([true]), /invalides/);
});
test('kindsReenabled : une situation qui redevient active repart d\'une page blanche', () => {
  const tout = POSITION_ALERT_DEFAULTS;
  const sansProfit = normalizePositionAlerts({ kinds: { profit: false } });
  const coupe = normalizePositionAlerts({ enabled: false });
  assert.deepEqual(kindsReenabled(sansProfit, tout), ['profit']);
  assert.deepEqual(kindsReenabled(coupe, tout), ['echeance', 'profit', 'stop'], 'réactiver le tout');
  assert.deepEqual(kindsReenabled(tout, sansProfit), [], 'couper une situation ne réinitialise rien');
  assert.deepEqual(kindsReenabled(tout, tout), []);
  assert.deepEqual(kindsReenabled(coupe, normalizePositionAlerts({ enabled: true, kinds: { echeance: false, profit: false } }, coupe)), ['stop'], 'seules les situations actives au retour');
});

// Audit routes locales (21/10/2026) : un patch invalide n'écrit RIEN (avant : le balayage automatique et la publication restaient activés).
test('planAppSettingsWrites : un courriel invalide fait échouer tout le patch avant la première écriture', () => {
  assert.throws(() => planAppSettingsWrites({ sweepAuto: true, publishCloud: true, alertEmails: 'pas-un-courriel' }), /invalide/);
  assert.throws(() => planAppSettingsWrites({ sweepAuto: true, positionAlerts: { enabled: 'oui' } }), /vrai ou faux/);
  assert.deepEqual(planAppSettingsWrites({ sweepAuto: true, publishCloud: false, alertEmails: 'a@x.com' }), [
    ['app_sweep_auto', '1'], ['app_publish_cloud', '0'], ['app_alert_emails', '["a@x.com"]'],
  ]);
  assert.deepEqual(planAppSettingsWrites({}), []);
  assert.deepEqual(planAppSettingsWrites(null), []);
});
