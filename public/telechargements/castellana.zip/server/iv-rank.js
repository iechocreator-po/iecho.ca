// IV Rank réel (feature bilbao #377, 30/9/2026) — à partir de l'historique
// d'IV que le Radar accumule (une ligne par contrat, par titre, par scan).
//
// Une observation = l'IV « à la monnaie » d'un titre pour un JOUR (médiane de
// l'IV des contrats dont |delta| ∈ [0,4 ; 0,6], optAtmIv — la MÊME définition
// que pour la valeur courante). Le rang lui-même est calculé par optIvRank()
// (js/options-analytics.js, source unique), qui renvoie null sous 20 jours
// d'historique : un rang sur 5 observations serait une fausse précision.
//
// Limite connue : l'échéance scannée (première dans la fenêtre 25-45 jours)
// change d'un jour à l'autre, donc la structure par terme introduit un peu de
// bruit dans la série. LOCAL uniquement : la version cloud n'a pas cet historique.

import { db } from './db.js';
import { optAtmIv, optIvRank } from './options-analytics.js';

const LOOKBACK_DAYS = 365;

// Map ticker → [{ date, iv }] trié par date, une valeur par jour.
export function getIvHistories(tickers) {
  if (!tickers.length) return new Map();
  const placeholders = tickers.map(() => '?').join(',');
  const rows = db.prepare(`
    -- Jour = date à New York (UTC-5 : un scan du soir passe minuit UTC, deux scans du même
    -- jour de marché ne doivent pas compter pour deux observations).
    SELECT r.ticker, date(s.started_at, '-5 hours') AS d, r.iv, r.delta
    FROM deal_results r JOIN deal_scans s ON s.id = r.scan_id
    WHERE s.statut = 'termine' AND s.fenetre = 'standard' AND r.iv IS NOT NULL AND r.delta IS NOT NULL
      AND abs(r.delta) BETWEEN 0.4 AND 0.6
      AND date(s.started_at, '-5 hours') >= date('now', ?)
      AND r.ticker IN (${placeholders})`).all(`-${LOOKBACK_DAYS} day`, ...tickers);

  const byKey = new Map();
  for (const r of rows) {
    const k = `${r.ticker}|${r.d}`;
    if (!byKey.has(k)) byKey.set(k, { ticker: r.ticker, date: r.d, contracts: [] });
    byKey.get(k).contracts.push({ iv: r.iv, delta: r.delta });
  }
  const out = new Map();
  for (const { ticker, date, contracts } of byKey.values()) {
    const iv = optAtmIv(contracts);
    if (iv == null) continue;
    if (!out.has(ticker)) out.set(ticker, []);
    out.get(ticker).push({ date, iv });
  }
  for (const list of out.values()) list.sort((a, b) => a.date.localeCompare(b.date));
  return out;
}

// Rang d'UN titre. `currentIv` absent : on utilise la dernière observation
// (utile pour interroger sans chaîne chargée) — précisé dans `basedOn`.
export function ivRankForTicker(ticker, currentIv = null) {
  const hist = getIvHistories([ticker]).get(ticker) || [];
  const series = hist.map((h) => h.iv);
  const usedLatest = !(Number.isFinite(currentIv) && currentIv > 0);
  const cur = usedLatest ? series[series.length - 1] : currentIv;
  // Quand on compare à la dernière observation, elle ne doit pas figurer dans sa propre référence.
  const reference = usedLatest ? series.slice(0, -1) : series;
  const result = optIvRank(reference, cur);
  return {
    ticker,
    days: hist.length,
    minDays: 20,
    basedOn: usedLatest ? 'dernière observation du Radar' : 'IV à la monnaie de la chaîne affichée',
    ...(result || {}),
    available: result != null,
  };
}
