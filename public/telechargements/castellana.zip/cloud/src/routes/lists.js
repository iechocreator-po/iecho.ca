import { getLists, getListById, createList, renameList, deleteList, addTickerToList, removeTickerFromList } from '../db/lists.js';
import { screeningCacheKey } from '../lib/screening.js';

export function registerListsRoutes(app) {
  app.get('/api/lists', async (c) => {
    return c.json({ lists: await getLists(c.env.DB, c.get('userId')) });
  });

  app.post('/api/lists', async (c) => {
    const userId = c.get('userId');
    const body = await c.req.json().catch(() => ({}));
    try {
      const list = await createList(c.env.DB, userId, String(body.nom || ''));
      return c.json({ list }, 201);
    } catch (err) {
      return c.json({ error: err.message }, 400);
    }
  });

  app.patch('/api/lists/:id', async (c) => {
    const userId = c.get('userId');
    const body = await c.req.json().catch(() => ({}));
    try {
      const list = await renameList(c.env.DB, userId, Number(c.req.param('id')), String(body.nom || ''));
      if (!list) return c.json({ error: 'liste introuvable' }, 404);
      return c.json({ list });
    } catch (err) {
      return c.json({ error: err.message }, 400);
    }
  });

  app.delete('/api/lists/:id', async (c) => {
    const userId = c.get('userId');
    const id = Number(c.req.param('id'));
    if (!(await deleteList(c.env.DB, userId, id))) return c.json({ error: 'liste introuvable' }, 404);
    await c.env.DB.prepare('DELETE FROM cache WHERE key = ?').bind(screeningCacheKey(userId, `list:${id}`)).run();
    return c.json({ ok: true });
  });

  app.post('/api/lists/:id/tickers', async (c) => {
    const userId = c.get('userId');
    const id = Number(c.req.param('id'));
    const body = await c.req.json().catch(() => ({}));
    const { ticker, exchange } = body;
    if (typeof ticker !== 'string' || !/^[A-Za-z.\-]{1,10}$/.test(ticker)) {
      return c.json({ error: 'ticker invalide' }, 400);
    }
    try {
      const list = await addTickerToList(c.env.DB, userId, id, ticker, exchange || 'NASDAQ');
      await c.env.DB.prepare('DELETE FROM cache WHERE key = ?').bind(screeningCacheKey(userId, `list:${id}`)).run();
      return c.json({ list }, 201);
    } catch (err) {
      return c.json({ error: err.message }, 400);
    }
  });

  app.delete('/api/lists/:id/tickers/:ticker', async (c) => {
    const userId = c.get('userId');
    const id = Number(c.req.param('id'));
    const list = await removeTickerFromList(c.env.DB, userId, id, c.req.param('ticker'));
    if (!list) return c.json({ error: 'liste introuvable' }, 404);
    await c.env.DB.prepare('DELETE FROM cache WHERE key = ?').bind(screeningCacheKey(userId, `list:${id}`)).run();
    return c.json({ list });
  });
}
