import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  estimateCost, checkBudget, validateSettings, sanitizePlan, normalizeNews, buildContext,
  validateAnalysis, extractToolInput, cacheKey, planHash, monthKey, DEFAULT_MODEL,
} from './ai-analyst-logic.js';

const news = [{ titre: 'AMD annonce X', date: '2026-10-09', source: 'Reuters', url: 'https://finance.yahoo.com/a' }];
const good = {
  resume: 'ok', actualites: [{ titre: 'inventé', date: '1999-01-01', source: 'moi', url: 'https://finance.yahoo.com/a', pertinence: 'haute' }],
  resultats: 'dans 12 jours', risques: [], contradictions_signal: [], critique_plan: [], non_disponible: [],
};

test('coût : haiku 1000 entrée + 500 sortie', () => {
  assert.ok(Math.abs(estimateCost(DEFAULT_MODEL, 1000, 500) - 0.0035) < 1e-9);
  assert.equal(estimateCost('inconnu', 1, 1), null);
});

test('plafond : refuse à budget atteint ou nul', () => {
  assert.equal(checkBudget(4.99, 5).ok, true);
  assert.equal(checkBudget(5, 5).ok, false);
  assert.equal(checkBudget(0, 0).ok, false);
});

test('réglages : modèle et budget validés', () => {
  assert.deepEqual(validateSettings({ model: 'claude-sonnet-5-5', budgetUsd: 10 }), { model: 'claude-sonnet-5-5', budgetUsd: 10 });
  assert.throws(() => validateSettings({ model: 'gpt' }));
  assert.throws(() => validateSettings({ budgetUsd: -1 }));
  assert.throws(() => validateSettings({ budgetUsd: 'abc' }));
});

test('plan : liste blanche, aucun montant', () => {
  const p = sanitizePlan({ stopPct: 5, riskPct: 1, capital: 50000, shares: 100, correlated: true, liquidity: 'bidon' });
  assert.equal(p.stopPct, 5);
  assert.equal(p.liquidity, null);
  assert.equal('capital' in p, false);
  assert.equal('shares' in p, false);
  assert.equal(sanitizePlan(null).stopPct, null);
  assert.equal(sanitizePlan({ stopPct: 500 }).stopPct, null);
});

test('actualités : exige https, date, titre', () => {
  const r = normalizeNews([
    { title: 'A', link: 'https://x/a', publisher: 'P', providerPublishTime: '2026-10-09T12:00:00Z' },
    { title: 'B', link: 'http://x/b', providerPublishTime: '2026-10-09T12:00:00Z' },
    { title: 'C', link: 'https://x/c' },
  ]);
  assert.equal(r.length, 1);
  assert.equal(r[0].date, '2026-10-09');
});

test('contexte : pas de plan inventé, valeurs absentes = null', () => {
  const c = buildContext({ ticker: 'X', today: '2026-10-09', fundamentals: {}, indicators: {}, scoring: {}, news: [], plan: sanitizePlan({}) });
  assert.equal(c.marche.pe, null);
  assert.equal(c.signal_technique.rsi, null);
  assert.deepEqual(c.actualites, []);
});

test('validation : actualité reprise de la SOURCE, pas du modèle', () => {
  const v = validateAnalysis(good, news);
  assert.equal(v.actualites[0].titre, 'AMD annonce X');
  assert.equal(v.actualites[0].date, '2026-10-09');
  assert.equal(v.actualites[0].pertinence, 'haute');
});

test('validation : rejette actualité inventée et formes invalides', () => {
  assert.throws(() => validateAnalysis({ ...good, actualites: [{ ...good.actualites[0], url: 'https://faux/z' }] }, news), /hors de la liste/);
  assert.throws(() => validateAnalysis({ ...good, resume: '' }, news));
  assert.throws(() => validateAnalysis({ ...good, risques: [1] }, news));
  assert.throws(() => validateAnalysis(null, news));
  assert.throws(() => validateAnalysis({ ...good, actualites: undefined }, news));
});

test('extraction de l\'appel d\'outil', () => {
  assert.deepEqual(extractToolInput({ content: [{ type: 'text', text: 'x' }, { type: 'tool_use', name: 'analyse_contexte', input: { a: 1 } }] }), { a: 1 });
  assert.throws(() => extractToolInput({ content: [{ type: 'text', text: 'x' }] }));
});

test('clé de cache : change avec le jour, les résultats et le modèle', () => {
  const a = cacheKey('AMD', '2026-10-09', 12, 'm');
  assert.notEqual(a, cacheKey('AMD', '2026-10-10', 12, 'm'));
  assert.notEqual(a, cacheKey('AMD', '2026-10-09', 11, 'm'));
  assert.notEqual(a, cacheKey('AMD', '2026-10-09', 12, 'n'));
  assert.match(monthKey(new Date('2026-10-09T12:00:00Z')), /^2026-10$/);
});

import { ollamaRequest, extractOllamaInput, PROVIDERS } from './ai-analyst-logic.js';

test('Ollama : requête contrainte par le schéma, déterministe, sans montants', () => {
  const r = ollamaRequest('qwen2.5:latest', { symbole: 'AMD' });
  assert.equal(r.stream, false);
  assert.equal(r.options.temperature, 0);
  assert.equal(r.format.required.includes('resume'), true);
  assert.match(r.messages[0].content, /UNIQUEMENT par un objet JSON/);
  assert.doesNotMatch(r.messages[0].content, /Appelle l'outil/);
});

test('Ollama : extraction JSON et rejet du texte libre', () => {
  assert.deepEqual(extractOllamaInput({ message: { content: '{"a":1}' } }), { a: 1 });
  assert.throws(() => extractOllamaInput({ message: { content: 'voici mon avis' } }), /JSON valide/);
  assert.throws(() => extractOllamaInput({ message: { content: '' } }));
});

test('réglages : fournisseur et modèle Ollama validés', () => {
  assert.deepEqual(validateSettings({ provider: 'ollama', ollamaModel: 'qwen2.5:latest' }), { provider: 'ollama', ollamaModel: 'qwen2.5:latest' });
  assert.throws(() => validateSettings({ provider: 'autre' }));
  assert.throws(() => validateSettings({ ollamaModel: 'a b; rm' }));
  assert.ok(PROVIDERS.claude && PROVIDERS.ollama);
});

test('la copie cloud de la logique pure est identique à la source', async () => {
  const { readFileSync } = await import('node:fs');
  const a = readFileSync(new URL('./ai-analyst-logic.js', import.meta.url), 'utf8');
  const b = readFileSync(new URL('../cloud/src/lib/ai-analyst-logic.js', import.meta.url), 'utf8');
  assert.equal(b, a, 'cloud/src/lib/ai-analyst-logic.js a dérivé de server/ai-analyst-logic.js');
});

test('cacheKey : changer le plan de trade change la clé (la critique du plan ne vient pas d\'un ancien plan)', () => {
  const p1 = { stopPct: 5, riskPct: 1 };
  const p2 = { stopPct: 7, riskPct: 1 };
  assert.notEqual(cacheKey('AMD', '2026-10-09', 12, 'm', p1), cacheKey('AMD', '2026-10-09', 12, 'm', p2));
  assert.equal(cacheKey('AMD', '2026-10-09', 12, 'm', p1), cacheKey('AMD', '2026-10-09', 12, 'm', { riskPct: 1, stopPct: 5 }), 'l\'ordre des champs ne compte pas');
  assert.equal(cacheKey('AMD', '2026-10-09', 12, 'm'), cacheKey('AMD', '2026-10-09', 12, 'm', null), 'sans plan : clé inchangée');
  assert.equal(typeof planHash(p1), 'string');
});
