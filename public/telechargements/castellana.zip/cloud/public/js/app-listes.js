// js/app-listes.js — Éditeur de watchlist et listes personnalisées du Screener
// Extrait de l'ancien script en ligne des index.html (découpage phase 2, 20/10/2026) : code déplacé tel quel, sans réécriture.
// Fichier COMMUN aux versions locale et cloud : source ici ; cloud/public/js/app-listes.js en est la copie (npm run sync:cloud).
// Script classique : ses noms de premier niveau sont globaux et partagés avec les autres scripts de la page.

// ---- Éditeur de watchlist (bonus) ----
// Tickers actuellement dans la watchlist (univers de screening) — tenu à
// jour par loadWatchlist(), utilisé pour activer/désactiver le bouton
// "+ Ajouter à la watchlist" du banner de l'écran de sélection.
let currentWatchlistTickers = new Set();
function toggleWatchlistEditor() {
  const el = document.getElementById('scr-watchlist-editor');
  const showing = el.style.display !== 'none';
  el.style.display = showing ? 'none' : 'block';
  if (!showing) loadWatchlist();
}
async function loadWatchlist() {
  const chips = document.getElementById('wl-chips');
  try {
    const data = await fetchJSON('/api/watchlist');
    currentWatchlistTickers = new Set(data.watchlist.map((w) => w.ticker));
    chips.innerHTML = data.watchlist.map(w =>
      `<span class="ds-badge">${optEsc(w.ticker)}<button type="button" onclick="removeWatchlist(${optEsc(JSON.stringify(w.ticker))})" style="margin-left:6px;border:none;background:none;color:var(--text-2);cursor:pointer;">×</button></span>`
    ).join('');
    // Rafraîchit l'état du bouton "+ Ajouter à la watchlist" des trois
    // bannières (Secteurs, Screener, Fiche) — il passe à "Déjà dans la
    // watchlist" dès que le titre y est.
    refreshSelectionsPassively(['sec', 'scr', 'fic', 'lab']);
  } catch (err) { chips.innerHTML = '<span class="muted-empty">Erreur : ' + optEsc(err.message) + '</span>'; }
}
async function addWatchlist() {
  const input = document.getElementById('wl-ticker');
  const ticker = input.value.trim();
  if (!ticker) return;
  try {
    await fetchJSON('/api/watchlist', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ticker, exchange: document.getElementById('wl-exchange').value }) });
    input.value = '';
    await loadWatchlist();
  } catch (err) { alert('Ajout impossible : ' + err.message); }
}
async function removeWatchlist(ticker) {
  try {
    await fetch('/api/watchlist/' + encodeURIComponent(ticker), { method: 'DELETE' });
    await loadWatchlist();
  } catch (err) { alert('Suppression impossible : ' + err.message); }
}
// ---- Listes personnalisées du Screener (12/9/2026, demande de JP) ----
// CRUD complet, en plus de « Ma watchlist »/« Univers élargi »/« MAG7 » qui
// restent inchangées — server/lists.js (local) / cloud/src/db/lists.js
// (cloud), plafond de 50 titres/liste. Chaque mutation confirmée est
// envoyée en télémétrie (trackListChanged, js/telemetry.js) pour que JP
// garde une trace de ce que les testeurs construisent.
let customLists = [];
async function loadCustomLists() {
  try {
    const data = await fetchJSON('/api/lists');
    customLists = data.lists;
  } catch {
    customLists = [];
  }
  renderCustomListPills();
}
function renderCustomListPills() {
  document.getElementById('custom-list-pills').innerHTML = customLists.map((l) => {
    const u = 'list:' + l.id;
    return `<button type="button" class="ds-btn${universCourant === u ? ' is-active' : ''}" data-univers="${u}" onclick="setUnivers('${u}')">${optEsc(l.nom)} (${l.tickers.length})</button>`;
  }).join('');
}
function openCreateListForm() {
  document.getElementById('list-create-form').style.display = 'block';
  document.getElementById('new-list-name').focus();
}
function cancelCreateList() {
  document.getElementById('list-create-form').style.display = 'none';
  document.getElementById('list-create-error').style.display = 'none';
  document.getElementById('new-list-name').value = '';
}
async function submitCreateList() {
  const input = document.getElementById('new-list-name');
  const errEl = document.getElementById('list-create-error');
  const nom = input.value.trim();
  if (!nom) {
    errEl.textContent = 'Entre un nom de liste.';
    errEl.style.display = 'block';
    return;
  }
  errEl.style.display = 'none';
  try {
    const data = await fetchJSON('/api/lists', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ nom }),
    });
    input.value = '';
    document.getElementById('list-create-form').style.display = 'none';
    await loadCustomLists();
    trackListChanged('create', data.list);
    setUnivers('list:' + data.list.id);
    listEditorOpen = true; // liste neuve : on ouvre l'édition pour y ajouter des titres
    renderListEditor();
    renderCustomListPills();
  } catch (err) {
    errEl.textContent = err.message;
    errEl.style.display = 'block';
  }
}
function currentListObj() {
  if (!universCourant.startsWith('list:')) return null;
  const id = Number(universCourant.slice('list:'.length));
  return customLists.find((l) => l.id === id) || null;
}
// Un seul bouton d'édition (« Éditer… ») pour l'univers actif : watchlist → ajout/retrait ;
// liste personnalisée → ajout/retrait, renommer, supprimer ; univers fixe → désactivé.
let listEditorOpen = false;
function updateEditButton() {
  const b = document.getElementById('btn-toggle-watchlist-editor');
  if (!b) return;
  const fixe = !(universCourant === 'watchlist' || universCourant.startsWith('list:'));
  b.textContent = 'Éditer la liste';
  b.disabled = fixe;
  b.title = fixe ? 'Cet univers est fixe : choisis « Ma watchlist » ou une liste personnalisée pour le modifier.' : '';
}
function toggleListManager() {
  if (universCourant === 'watchlist') { toggleWatchlistEditor(); return; }
  if (!universCourant.startsWith('list:')) return;
  listEditorOpen = !listEditorOpen;
  renderListEditor();
}
function renderListEditor() {
  const el = document.getElementById('list-editor');
  const list = currentListObj();
  updateEditButton();
  if (!list || !listEditorOpen) { el.style.display = 'none'; return; }
  el.style.display = 'block';
  document.getElementById('list-editor-name').textContent = list.nom;
  document.getElementById('list-editor-count').textContent = `${list.tickers.length}/50 titres`;
  document.getElementById('list-chips').innerHTML = list.tickers.map((t) =>
    `<span class="ds-badge">${optEsc(t.ticker)}<button type="button" onclick="removeTickerFromCurrentList(${optEsc(JSON.stringify(t.ticker))})" style="margin-left:6px;border:none;background:none;color:var(--text-2);cursor:pointer;">×</button></span>`,
  ).join('');
}
async function renameCurrentList() {
  const list = currentListObj();
  if (!list) return;
  const nom = prompt('Nouveau nom de la liste', list.nom);
  if (!nom || !nom.trim()) return;
  try {
    const data = await fetchJSON('/api/lists/' + list.id, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ nom: nom.trim() }),
    });
    await loadCustomLists();
    renderListEditor();
    trackListChanged('rename', data.list);
  } catch (err) { alert('Renommage impossible : ' + err.message); }
}
async function deleteCurrentList() {
  const list = currentListObj();
  if (!list) return;
  if (!confirm(`⚠️ Supprimer la liste « ${list.nom} » (${list.tickers.length} titre(s)) ?\n\nCette action est définitive et ne peut pas être annulée.`)) return;
  try {
    await fetch('/api/lists/' + list.id, { method: 'DELETE' });
    trackListChanged('delete', list);
    setUnivers('watchlist');
    await loadCustomLists();
  } catch (err) { alert('Suppression impossible : ' + err.message); }
}
async function addTickerToCurrentList() {
  const list = currentListObj();
  if (!list) return;
  const input = document.getElementById('list-ticker');
  const errEl = document.getElementById('list-editor-error');
  const ticker = input.value.trim();
  if (!ticker) return;
  errEl.style.display = 'none';
  try {
    const data = await fetchJSON(`/api/lists/${list.id}/tickers`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ticker, exchange: document.getElementById('list-exchange').value }),
    });
    input.value = '';
    await loadCustomLists();
    renderListEditor();
    trackListChanged('add_ticker', data.list);
  } catch (err) {
    errEl.textContent = err.message;
    errEl.style.display = 'block';
  }
}
async function removeTickerFromCurrentList(ticker) {
  const list = currentListObj();
  if (!list) return;
  try {
    const data = await fetchJSON(`/api/lists/${list.id}/tickers/${encodeURIComponent(ticker)}`, { method: 'DELETE' });
    await loadCustomLists();
    renderListEditor();
    trackListChanged('remove_ticker', data.list);
  } catch (err) { alert('Retrait impossible : ' + err.message); }
}
// Bouton "+ Ajouter à la watchlist" du banner (écran de sélection) — répond
// à la confusion de JP sur "ajouter à la liste de suivi active" : ce texte
// ne référençait aucune fonctionnalité réelle jusqu'ici, purement une
// intention à réaliser soi-même. Ce bouton l'ancre sur la VRAIE watchlist
// (univers de screening, server/watchlist.js) plutôt que de rester une
// formule en l'air.
// 11/9/2026 : paramétré par onglet — la bannière (et donc ce bouton) vit
// maintenant dans Secteurs, Screener ET Fiche de trade, chacun avec son
// propre champ de ticker.
async function addCurrentTickerToWatchlist(instanceKey = 'sec') {
  const t = BANNER_TARGETS[instanceKey] || BANNER_TARGETS.sec;
  const ticker = document.getElementById(t.ticker).value.trim().toUpperCase();
  if (!ticker) return;
  const btn = document.getElementById(t.btn);
  btn.disabled = true;
  btn.textContent = 'Ajout…';
  try {
    await fetchJSON('/api/watchlist', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ticker }) });
    await loadWatchlist();
  } catch (err) {
    btn.disabled = false;
    btn.textContent = 'Erreur : ' + err.message;
  }
}
