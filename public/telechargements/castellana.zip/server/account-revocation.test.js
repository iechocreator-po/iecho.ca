// Désactivation d'un compte et réinitialisation de son mot de passe : les sessions déjà ouvertes tombent
// (audit cloud-comptes, 20/10/2026, constat 1). On fait tourner les VRAIES fonctions contre le VRAI schéma SQL
// (cloud/schema.sql) dans une base SQLite en mémoire habillée en D1, clés étrangères actives comme sur D1.
// Ce fichier vit dans server/ (et non dans cloud/src/) : le better-sqlite3 installé sous cloud/node_modules plante
// (segmentation fault) sous Node ; celui de la racine fonctionne.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import Database from 'better-sqlite3';
import { findSession, createSession, revokeAllSessions } from '../cloud/src/db/sessions.js';
import { createMagicLink, findValidMagicLink } from '../cloud/src/db/magic-links.js';
import { disableUserAndRevoke, resetPasswordAndRevoke, setDisabled } from '../cloud/src/db/users.js';

// Faux D1 minimal : prepare(sql).bind(...).first() / .all() / .run(), asynchrones, avec meta.changes.
function d1(raw) {
  return {
    prepare(sql) {
      const make = (args) => ({
        async first() { return raw.prepare(sql).get(...args) ?? null; },
        async all() { return { results: raw.prepare(sql).all(...args) }; },
        async run() { const r = raw.prepare(sql).run(...args); return { meta: { changes: r.changes, last_row_id: Number(r.lastInsertRowid) } }; },
      });
      return { ...make([]), bind: (...args) => make(args) };
    },
  };
}
function freshDb() {
  const raw = new Database(':memory:');
  raw.pragma('foreign_keys = ON');
  raw.exec(readFileSync(new URL('../cloud/schema.sql', import.meta.url), 'utf8'));
  const addUser = (name) => Number(raw.prepare("INSERT INTO users (username, password_hash, password_salt, email) VALUES (?, 'h', 's', ?)").run(name, `${name}@example.test`).lastInsertRowid);
  return { raw, db: d1(raw), addUser };
}
const FUTUR = () => Date.now() + 3600_000;

test('findSession : un compte désactivé n\'a plus de session valide, un compte actif oui', async () => {
  const { db, addUser } = freshDb();
  const id = addUser('louis');
  await createSession(db, id, 'tok-louis', FUTUR());
  assert.equal((await findSession(db, 'tok-louis')).username, 'louis');
  await setDisabled(db, id, true); // même sans fermer les sessions, un compte désactivé ne passe plus
  assert.equal(await findSession(db, 'tok-louis'), null, 'une session ouverte doit tomber dès que le compte est désactivé');
});

test('findSession : repli propre si la colonne `disabled` n\'existe pas encore (base d\'avant la migration)', async () => {
  const { db, addUser } = freshDb();
  const id = addUser('jp');
  await createSession(db, id, 'tok-jp', FUTUR());
  const sansColonne = { prepare: (sql) => (/user_disabled/.test(sql) ? { bind: () => ({ first: async () => { throw new Error('no such column: u.disabled'); } }) } : db.prepare(sql)) };
  assert.equal((await findSession(sansColonne, 'tok-jp')).username, 'jp');
});

test('findSession : une erreur qui n\'est pas « colonne absente » remonte au lieu d\'être avalée', async () => {
  const cassee = { prepare: () => ({ bind: () => ({ first: async () => { throw new Error('D1 injoignable'); } }) }) };
  await assert.rejects(() => findSession(cassee, 'x'), /D1 injoignable/);
});

test('disableUserAndRevoke : ferme les sessions et liens magiques du compte, pas ceux des autres', async () => {
  const { raw, db, addUser } = freshDb();
  const louis = addUser('louis'); const guillaume = addUser('guillaume');
  await createSession(db, louis, 'tok-l1', FUTUR()); await createSession(db, louis, 'tok-l2', FUTUR(), 'magic_link');
  await createSession(db, guillaume, 'tok-g1', FUTUR());
  await createMagicLink(db, louis, 'lien-louis'); await createMagicLink(db, guillaume, 'lien-guillaume');

  const res = await disableUserAndRevoke(db, louis);
  assert.equal(res.user.disabled, 1);
  assert.equal(res.sessionsClosed, 2);
  assert.equal(raw.prepare('SELECT COUNT(*) AS n FROM sessions WHERE user_id = ?').get(louis).n, 0);
  assert.equal(await findSession(db, 'tok-l1'), null);
  assert.equal(await findValidMagicLink(db, 'lien-louis'), null, 'les liens de connexion encore valides doivent être invalidés');
  assert.ok(await findSession(db, 'tok-g1'), 'la session d\'un autre compte ne doit pas bouger');
  assert.ok(await findValidMagicLink(db, 'lien-guillaume'), 'le lien d\'un autre compte ne doit pas bouger');

  // Réactiver ne ressuscite pas les sessions fermées
  await setDisabled(db, louis, false);
  assert.equal(await findSession(db, 'tok-l1'), null);
});

test('disableUserAndRevoke : compte inconnu -> null, rien de fermé', async () => {
  const { raw, db, addUser } = freshDb();
  const id = addUser('jp'); await createSession(db, id, 'tok-jp', FUTUR());
  assert.equal(await disableUserAndRevoke(db, 999), null);
  assert.equal(raw.prepare('SELECT COUNT(*) AS n FROM sessions').get().n, 1);
});

test('resetPasswordAndRevoke : change le mot de passe, ferme les sessions et les liens du compte seulement', async () => {
  const { raw, db, addUser } = freshDb();
  const louis = addUser('louis'); const jp = addUser('jp');
  await createSession(db, louis, 'tok-l1', FUTUR()); await createSession(db, jp, 'tok-jp', FUTUR());
  await createMagicLink(db, louis, 'lien-louis');

  const closed = await resetPasswordAndRevoke(db, louis, 'nouveau-hash', 'nouveau-sel');
  assert.equal(closed, 1);
  assert.equal(raw.prepare('SELECT password_hash FROM users WHERE id = ?').get(louis).password_hash, 'nouveau-hash');
  assert.equal(await findSession(db, 'tok-l1'), null, 'la session ouverte avec l\'ancien mot de passe doit tomber');
  assert.equal(await findValidMagicLink(db, 'lien-louis'), null);
  assert.ok(await findSession(db, 'tok-jp'), 'les autres comptes ne sont pas touchés');
});

test('revokeAllSessions : emporte aussi les jetons TradingView liés (ON DELETE CASCADE)', async () => {
  const { raw, db, addUser } = freshDb();
  const id = addUser('louis');
  await createSession(db, id, 'tok-l1', FUTUR());
  const cols = raw.prepare('PRAGMA table_info(tv_oauth)').all().filter((c) => c.notnull && c.dflt_value == null && c.name !== 'session_token').map((c) => c.name);
  raw.prepare(`INSERT INTO tv_oauth (session_token${cols.map((c) => `, ${c}`).join('')}) VALUES ('tok-l1'${cols.map(() => ", 'x'").join('')})`).run();
  assert.equal(raw.prepare('SELECT COUNT(*) AS n FROM tv_oauth').get().n, 1);
  await revokeAllSessions(db, id);
  assert.equal(raw.prepare('SELECT COUNT(*) AS n FROM tv_oauth').get().n, 0);
});

test('les routes d\'administration passent par ces fonctions (et plus par setDisabled / resetPassword seuls)', () => {
  const src = readFileSync(new URL('../cloud/src/routes/admin.js', import.meta.url), 'utf8');
  const bloc = (debut) => src.slice(src.indexOf(debut), src.indexOf('\n  });', src.indexOf(debut)));
  assert.match(bloc("'/api/admin/users/:id/disable'"), /disableUserAndRevoke\(/, 'la route /disable doit fermer les sessions');
  assert.doesNotMatch(bloc("'/api/admin/users/:id/disable'"), /setDisabled\(/);
  assert.match(bloc("'/api/admin/users/:id/reset-password'"), /resetPasswordAndRevoke\(/, 'la route /reset-password doit fermer les sessions');
  assert.doesNotMatch(bloc("'/api/admin/users/:id/reset-password'"), /[^A-Za-z]resetPassword\(/);
});
