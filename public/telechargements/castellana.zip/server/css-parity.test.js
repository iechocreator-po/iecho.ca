// Les deux pages (local et cloud) partagent leurs feuilles de style : css/app.css est la SOURCE, cloud/public/css/app.css
// en est la copie octet pour octet (npm run sync:cloud). Ce test garde ce contrat (découpage des index.html, phase 1).
import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';

const ROOT = new URL('..', import.meta.url);
const read = (p) => readFileSync(new URL(p, ROOT), 'utf8');
const PAGES = [
  { page: 'index.html', base: '', attendus: ['css/app.css', 'css/mode-local.css'], interdits: ['css/mode-cloud.css'] },
  { page: 'cloud/public/index.html', base: 'cloud/public/', attendus: ['css/app.css', 'css/mode-cloud.css'], interdits: ['css/mode-local.css'] },
];

test('css/app.css (source) et cloud/public/css/app.css (copie) sont identiques', () => {
  assert.equal(read('cloud/public/css/app.css'), read('css/app.css'),
    'la copie cloud a dérivé : lance `npm run sync:cloud` (depuis trading-assistant/)');
});

for (const { page, base, attendus, interdits } of PAGES) {
  test(`${page} : charge les bonnes feuilles de style, toutes présentes, et plus aucun bloc <style>`, () => {
    const html = read(page);
    const liens = [...html.matchAll(/<link rel="stylesheet" href="(css\/[^"]+)">/g)].map((m) => m[1]);
    for (const f of attendus) assert.ok(liens.includes(f), `${page} ne charge pas ${f}`);
    for (const f of interdits) assert.ok(!liens.includes(f), `${page} ne doit pas charger ${f} (propre à l'autre mode)`);
    for (const f of liens) assert.ok(existsSync(new URL(base + f, ROOT)), `${base + f} est référencé mais introuvable`);
    assert.ok(liens.indexOf('css/app.css') === 0, 'css/app.css doit être chargée en premier (ordre de la cascade)');
    assert.ok(!/<style[\s>]/.test(html), `${page} contient un bloc <style> : mettre ces règles dans css/ (app.css, ou mode-*.css si propre à un mode)`);
  });
}
