// js/app-graphiques.js — Graphiques de performance, overlays « Agrandir », graphique du Screener
// Extrait de l'ancien script en ligne des index.html (découpage phase 2, 20/10/2026) : code déplacé tel quel, sans réécriture.
// Fichier COMMUN aux versions locale et cloud : source ici ; cloud/public/js/app-graphiques.js en est la copie (npm run sync:cloud).
// Script classique : ses noms de premier niveau sont globaux et partagés avec les autres scripts de la page.

// ---- Line graph de performance (%) — générique, réutilisé par le
// graphique sectoriel (écran Secteurs) ET par le graphique de performance
// des titres retenus (écran Screener, 21/9/2026). Un seul renderer plutôt
// que de copier ~150 lignes de SVG/légende/curseur une deuxième fois — même
// discipline que screeningRowHTML()/renderTickerSectionInto() ailleurs dans
// ce fichier. Chaque appelant construit ses propres séries
// {key,label,labelHtml?,tooltipLabel?,color,history,lineStyle,endLabel?,
// endSuffix?,endLabelItalic?} — le renderer ne connaît rien des secteurs ni
// du screening.

// Mapping ticker → variable CSS catégorielle, même ordre que
// server/sectors.js SECTOR_ETFS (--sc-1..--sc-11 définies dans css/app.css).
const SECTOR_COLORS = {
  XLK: 'var(--sc-1)', XLY: 'var(--sc-2)', XLI: 'var(--sc-3)', XLF: 'var(--sc-4)',
  XLU: 'var(--sc-5)', XLV: 'var(--sc-6)', XLRE: 'var(--sc-7)', XLP: 'var(--sc-8)',
  XLE: 'var(--sc-9)', XLC: 'var(--sc-10)', XLB: 'var(--sc-11)',
};
// Grands indices régionaux + USD (refonte 11/9/2026) — palette dédiée
// (--mkt-* définies dans css/app.css), indexée par le `key` de
// server/sectors.js MARKET_INDEX_DEFS.
const MARKET_COLORS = {
  DXY: 'var(--mkt-dxy)', WORLDEXUS: 'var(--mkt-world)', EUROPE: 'var(--mkt-europe)',
  JAPAN: 'var(--mkt-japan)', EM: 'var(--mkt-em)', CHINA: 'var(--mkt-china)',
  RSP: 'color-mix(in srgb, var(--text-2) 55%, var(--accent))',
};
function seriesColor(s) {
  if (s.isBenchmark) return 'var(--text-2)';
  if (s.isMarket || s.isEqual) return MARKET_COLORS[s.key] || 'var(--text-2)';
  return SECTOR_COLORS[s.key] || 'var(--text-2)';
}
let sectorHistoryData = null; // { sectors:[{ticker,label,history:[{date,close}]}], benchmark, markets:[{key,ticker,label,history,usedFallback}] }
let sectorChartPeriodDays = 365;
const sectorChartHidden = new Set(); // tickers masqués via un clic sur la légende
// Catégories affichées (refonte 11/9/2026) — 'gics' couvre les 11 secteurs
// d'un coup, 'sp500' le benchmark ; chaque grand indice a sa propre entrée
// (même valeur que MARKET_INDEX_DEFS[].key côté serveur). Décochage/cochage
// = filtre client pur sur sectorHistoryData déjà chargé, aucun refetch.
const selectedCategories = new Set(['gics', 'sp500']);
let chartExpanded = false; // vue agrandie (overlay plein écran) — pilote le viewBox du SVG

async function loadSectorHistory() {
  const status = document.getElementById('sector-chart-status');
  status.textContent = "Chargement de l'historique…";
  try {
    sectorHistoryData = await fetchJSON(`/api/sectors/history?mode=${sectorCurrencyMode}`);
    status.textContent = '';
    renderSectorChart();
  } catch (err) {
    status.textContent = 'Erreur : ' + err.message;
  }
}
// Les boutons de période du graphique Secteurs ET ceux du graphique Screener
// (21/9/2026) partagent la classe .period-btn — le sélecteur est donc scopé
// à son propre conteneur (#sector-period-toolbar / #screen-chart-period-toolbar),
// jamais `.period-btn` seul, pour ne pas câbler les deux graphiques ensemble.
function setSectorPeriod(days) {
  sectorChartPeriodDays = days;
  document.getElementById('sector-period-select').value = String(days);
  renderSectorChart();
}
// ---- Overlay "Agrandir le graphique" (refonte 11/9/2026) — déplace
// #sector-chart-block vers/depuis #chart-overlay-main (re-parenting DOM,
// aucune duplication d'état ni d'écouteurs). Même geste Échap/✕ que
// #settings-overlay (voir document.addEventListener('keydown', …)). ----
function openChartOverlay() {
  const block = document.getElementById('sector-chart-block');
  document.getElementById('chart-overlay-main').appendChild(block);
  document.getElementById('chart-overlay').style.display = 'flex';
  chartExpanded = true;
  renderSectorChart();
}
function closeChartOverlay() {
  const block = document.getElementById('sector-chart-block');
  const anchor = document.getElementById('sector-chart-anchor');
  anchor.parentNode.insertBefore(block, anchor.nextSibling);
  document.getElementById('chart-overlay').style.display = 'none';
  chartExpanded = false;
  renderSectorChart();
}
// ---- Overlay "Agrandir" générique pour les tableaux (12/9/2026) — T1.
// Même principe de re-parenting DOM que ci-dessus, paramétré par bloc/ancre
// puisque DEUX tableaux le réutilisent ("Titres les plus performants du
// secteur" et "Screening") : recopier open/closeChartOverlay() pour chacun
// aurait été une troisième quasi-duplication dans ce fichier. ----
let tableOverlayState = null; // { blockId, anchorId } — le bloc actuellement déplacé
function openTableOverlay(blockId, anchorId, title) {
  const block = document.getElementById(blockId);
  document.getElementById('table-overlay-main').appendChild(block);
  document.getElementById('table-overlay-title').textContent = title;
  // Cellules tronquées (Secteur, Industrie…) : le texte complet reste lisible au survol.
  block.querySelectorAll('td').forEach((td) => { if (!td.title && td.textContent.trim().length > 12) td.title = td.textContent.trim(); });
  document.getElementById('table-overlay').style.display = 'flex';
  tableOverlayState = { blockId, anchorId };
}
function closeTableOverlay() {
  if (!tableOverlayState) return;
  const { blockId, anchorId } = tableOverlayState;
  const block = document.getElementById(blockId);
  const anchor = document.getElementById(anchorId);
  anchor.parentNode.insertBefore(block, anchor.nextSibling);
  document.getElementById('table-overlay').style.display = 'none';
  tableOverlayState = null;
}
function fmtChartDate(iso) {
  return new Date(iso + 'T00:00:00').toLocaleDateString('fr-CA', { day: '2-digit', month: 'short' });
}
// Découpe l'historique sur la période choisie et normalise en % depuis le
// premier point de la fenêtre — pas de refetch, tout vient du batch complet
// déjà chargé (loadSectorHistory() pour les secteurs, loadScreeningPerformance()
// pour le screener).
function sliceAndNormalize(history, days) {
  if (!history || history.length === 0) return [];
  const cutoff = new Date(Date.now() - days * 24 * 3600 * 1000);
  const sliced = history.filter((h) => new Date(h.date + 'T00:00:00') >= cutoff);
  if (sliced.length < 2) return [];
  const base = sliced[0].close;
  return sliced.map((h) => ({ date: h.date, pct: ((h.close - base) / base) * 100 }));
}
// Indexé par `key` (toujours le ticker USD, stable) plutôt que `ticker`
// (qui change en mode CAD, ex. XLK → ZXLK.TO) — sinon basculer la devise
// réinitialiserait silencieusement les secteurs masqués/isolés.
function toggleSectorSeries(key) {
  if (sectorChartHidden.has(key)) sectorChartHidden.delete(key); else sectorChartHidden.add(key);
  renderSectorChart();
}
// ---- Renderer générique (21/9/2026) ----------------------------------

// Légende triée du plus performant (premier) au moins performant (dernier)
// sur la période affichée : cliquer de droite à gauche retire les pires.
// Les séries sans données suffisantes vont à la fin.
function renderPerfLegend(legendId, series, hiddenSet, onToggleName) {
  const lastPct = (s) => (s.points && s.points.length > 1 ? s.points[s.points.length - 1].pct : null);
  const sorted = [...series].sort((a, b) => {
    const pa = lastPct(a), pb = lastPct(b);
    if (pa == null && pb == null) return 0;
    if (pa == null) return 1;
    if (pb == null) return -1;
    return pb - pa;
  });
  document.getElementById(legendId).innerHTML = sorted.map((s) => {
    const off = hiddenSet.has(s.key);
    const p = lastPct(s);
    const pctHtml = p == null ? '' : ` <span class="sector-legend-pct" style="color:${p > 0 ? 'var(--green)' : p < 0 ? 'var(--red)' : 'var(--text-2)'}">${p > 0 ? '+' : ''}${p.toFixed(1)}%</span>`;
    return `<span class="sector-legend-item${off ? ' is-off' : ''}" onclick="${onToggleName}('${s.key}')">
      <span class="sector-legend-swatch" style="background:${s.color}"></span>${s.labelHtml ?? s.label}${pctHtml}
    </span>`;
  }).join('');
}
// `series` : déjà enrichies de `.color`/`.lineStyle` par l'appelant — ce
// renderer ne fait plus de choix de couleur ni de catégorisation, seulement
// du dessin. `lineStyle` ∈ 'solid' | 'benchmark' | 'market' (classes CSS
// .is-benchmark/.is-market déjà en place, réutilisées telles quelles).
// Aligne les séries sur un axe de DATES commun (union triée). Avant, la première série fixait l'axe et les autres étaient
// placées par indice : un titre introduit en cours de fenêtre ou un calendrier différent (jours fériés canadiens) étirait la
// courbe et décalait le survol (audit app-js). Chaque série garde `points` (les siens, avec `i` = position sur l'axe) et
// `byIdx` (le point en vigueur à chaque position de l'axe, report du dernier connu ; undefined avant son premier point).
function alignSeriesByDate(series) {
  const axis = [...new Set(series.flatMap((s) => s.points.map((p) => p.date)))].sort();
  const pos = new Map(axis.map((d, i) => [d, i]));
  const aligned = series.map((s) => {
    const points = s.points.map((p) => ({ ...p, i: pos.get(p.date) }));
    const byIdx = new Array(axis.length);
    let k = -1;
    for (let i = 0; i < axis.length; i++) {
      while (k + 1 < points.length && points[k + 1].i <= i) k++;
      byIdx[i] = k >= 0 ? points[k] : undefined;
    }
    return { ...s, points, byIdx };
  });
  return { axis, aligned };
}
function renderPerfChart({ svgId, legendId, tooltipId, series, periodDays, hiddenSet, onToggleName, W = 760, H = 320 }) {
  const padL = 40, padR = 58, padT = 14, padB = 24;
  const innerW = W - padL - padR, innerH = H - padT - padB;

  const withPoints = series.map((s) => ({ ...s, points: sliceAndNormalize(s.history, periodDays) }));
  renderPerfLegend(legendId, withPoints, hiddenSet, onToggleName);

  const visibleBrutes = withPoints.filter((s) => s.points.length > 1 && !hiddenSet.has(s.key));
  const svgEl = document.getElementById(svgId);
  if (visibleBrutes.length === 0) { svgEl.innerHTML = ''; return; }

  // Axe des dates commun à toutes les séries visibles (voir alignSeriesByDate).
  const { axis: allDates, aligned: visible } = alignSeriesByDate(visibleBrutes);
  const n = allDates.length;
  const allPct = visible.flatMap((s) => s.points.map((p) => p.pct));
  let yMin = Math.min(0, ...allPct), yMax = Math.max(0, ...allPct);
  const pad = (yMax - yMin) * 0.08 || 1;
  yMin -= pad; yMax += pad;

  const x = (i) => padL + (n <= 1 ? 0 : (i / (n - 1)) * innerW);
  const y = (v) => padT + innerH - ((v - yMin) / (yMax - yMin)) * innerH;

  let svg = '';
  const ticks = 4;
  for (let t = 0; t <= ticks; t++) {
    const v = yMin + (t / ticks) * (yMax - yMin);
    const yy = y(v);
    svg += `<line x1="${padL}" y1="${yy.toFixed(1)}" x2="${W - padR}" y2="${yy.toFixed(1)}" class="sector-chart-grid"/>`;
    svg += `<text x="${padL - 6}" y="${(yy + 3).toFixed(1)}" text-anchor="end" class="sector-chart-axis-label">${v.toFixed(0)}%</text>`;
  }
  [0, Math.floor((n - 1) / 2), n - 1].forEach((i) => {
    svg += `<text x="${x(i).toFixed(1)}" y="${H - 6}" text-anchor="middle" class="sector-chart-axis-label">${fmtChartDate(allDates[i])}</text>`;
  });

  visible.forEach((s) => {
    const d = s.points.map((p, k) => `${k === 0 ? 'M' : 'L'} ${x(p.i).toFixed(1)} ${y(p.pct).toFixed(1)}`).join(' ');
    const cls = 'sector-chart-line' + (s.lineStyle === 'benchmark' ? ' is-benchmark' : s.lineStyle === 'market' ? ' is-market' : s.lineStyle === 'equal' ? ' is-equal' : '');
    svg += `<path d="${d}" class="${cls}" style="stroke:${s.color}"/>`;
    const last = s.points[s.points.length - 1];
    const endLabel = (s.endLabel ?? s.label) + (s.endSuffix ?? '');
    svg += `<text x="${(x(last.i) + 4).toFixed(1)}" y="${(y(last.pct) + 3).toFixed(1)}" class="sector-chart-endlabel${s.endLabelItalic ? ' is-fallback' : ''}" style="fill:${s.color}">${endLabel}</text>`;
  });

  // Crosshair/rect de survol scopés à CET svg (classe, pas id) — deux
  // graphiques (Secteurs, Screener) coexistent dans le DOM en même temps
  // (onglets différents, tous deux montés), un `id` global collisionnerait.
  svg += `<line x1="0" y1="${padT}" x2="0" y2="${H - padB}" class="sector-chart-crosshair perf-crosshair" style="display:none;"/>`;
  svg += `<rect x="${padL}" y="${padT}" width="${innerW}" height="${innerH}" fill="transparent" class="perf-hit-rect"/>`;

  svgEl.setAttribute('viewBox', `0 0 ${W} ${H}`);
  svgEl.innerHTML = svg;
  svgEl._perfCtx = { visible, allDates, n, x, y, padL, innerW, W, H };
  attachPerfHover(svgEl, tooltipId);
}
function attachPerfHover(svgEl, tooltipId) {
  const hit = svgEl.querySelector('.perf-hit-rect');
  const crosshair = svgEl.querySelector('.perf-crosshair');
  const tooltip = document.getElementById(tooltipId);
  if (!hit) return;

  hit.addEventListener('pointermove', (e) => {
    const ctx = svgEl._perfCtx;
    const rect = svgEl.getBoundingClientRect();
    const scaleX = ctx.W / rect.width;
    const px = (e.clientX - rect.left) * scaleX;
    const relX = Math.min(Math.max(px - ctx.padL, 0), ctx.innerW);
    const idx = Math.round((relX / ctx.innerW) * (ctx.n - 1));
    const cx = ctx.x(idx).toFixed(1);
    crosshair.style.display = 'block';
    crosshair.setAttribute('x1', cx);
    crosshair.setAttribute('x2', cx);
    // Points actifs sur chaque ligne (style shadcn)
    svgEl.querySelectorAll('.perf-dot').forEach((d) => d.remove());
    ctx.visible.forEach((s) => {
      const pt = s.byIdx[idx];
      if (!pt) return;
      const c = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      c.setAttribute('class', 'perf-dot');
      c.setAttribute('cx', cx); c.setAttribute('cy', ctx.y(pt.pct).toFixed(1)); c.setAttribute('r', 4);
      c.style.fill = s.color;
      svgEl.insertBefore(c, hit);
    });

    const rows = ctx.visible.map((s) => ({
      label: s.tooltipLabel ?? s.label, pct: s.byIdx[idx]?.pct, color: s.color,
    })).filter((r) => r.pct != null).sort((a, b) => b.pct - a.pct);

    tooltip.innerHTML = `<div class="st-date">${fmtChartDate(ctx.allDates[idx])}</div>` + rows.map((r) => {
      const valColor = r.pct > 0 ? 'var(--green)' : r.pct < 0 ? 'var(--red)' : 'var(--text-2)';
      return `<div class="st-row"><span><span class="sector-legend-swatch" style="background:${r.color}"></span> ${r.label}</span><span class="st-val" style="color:${valColor}">${r.pct > 0 ? '+' : ''}${r.pct.toFixed(1)}%</span></div>`;
    }).join('');
    tooltip.style.display = 'block';

    const wrapRect = svgEl.parentElement.getBoundingClientRect();
    let left = e.clientX - wrapRect.left + 14;
    const top = e.clientY - wrapRect.top + 14;
    const maxLeft = wrapRect.width - tooltip.offsetWidth - 8;
    if (left > maxLeft) left = e.clientX - wrapRect.left - tooltip.offsetWidth - 14;
    tooltip.style.left = Math.max(4, left) + 'px';
    tooltip.style.top = Math.max(4, top) + 'px';
  });
  hit.addEventListener('pointerleave', () => {
    crosshair.style.display = 'none';
    tooltip.style.display = 'none';
    svgEl.querySelectorAll('.perf-dot').forEach((d) => d.remove());
  });
}
function renderSectorChart() {
  if (!sectorHistoryData) return;
  // Grands indices régionaux/USD (markets) — chacun porte son propre `group`
  // (son `key`), les secteurs partagent tous 'gics', le benchmark 'sp500' :
  // c'est ce `group` que le filtre "Catégories affichées" consulte.
  const allSeries = [
    ...sectorHistoryData.sectors.map((s) => ({ ...s, group: 'gics', isBenchmark: false })),
    { ...sectorHistoryData.benchmark, group: 'sp500', isBenchmark: true },
    ...(sectorHistoryData.equalWeight ? [{ ...sectorHistoryData.equalWeight, group: 'sp500', isBenchmark: false, isEqual: true }] : []),
    ...(sectorHistoryData.markets || []).map((s) => ({ ...s, group: s.key, isBenchmark: false, isMarket: true })),
  ];
  const byCategory = allSeries.filter((s) => selectedCategories.has(s.group)).map((s) => ({
    key: s.key,
    label: s.label,
    labelHtml: `${s.label}${s.usedFallback ? ' <em style="font-style:italic;">(US — pas d\'équivalent TSX)</em>' : ''}`,
    tooltipLabel: s.label + (s.usedFallback ? ' (US)' : ''),
    color: seriesColor(s),
    history: s.history,
    lineStyle: s.isBenchmark ? 'benchmark' : (s.isEqual ? 'equal' : (s.isMarket ? 'market' : 'solid')),
    endLabel: s.ticker,
    endSuffix: s.usedFallback ? ' *' : '',
    endLabelItalic: !!s.usedFallback,
  }));
  const W = chartExpanded ? 1400 : 760, H = chartExpanded ? 560 : 320;
  renderPerfChart({
    svgId: 'sector-chart', legendId: 'sector-legend', tooltipId: 'sector-chart-tooltip',
    series: byCategory, periodDays: sectorChartPeriodDays, hiddenSet: sectorChartHidden,
    onToggleName: 'toggleSectorSeries', W, H,
  });
}
// ---- Graphique de performance des titres retenus (Screener, 21/9/2026) --
// Réutilise l'idée du graphique sectoriel : mêmes classes CSS, même
// renderer générique (renderPerfChart). Généré automatiquement après
// chaque "Lancer le screening" — pas un onglet/bouton séparé — sur les
// tickers RETENUS par le screening en cours (déjà triés Setup puis
// Contexte par le serveur), plafonnés pour rester lisible. Le S&P 500
// (SPY) est ajouté comme repère, comme partout ailleurs dans l'app.
let screenChartSeries = [];        // dernière performance chargée (tickers + SPY)
// Défaut 3 mois (pas 12 comme les secteurs) : ces candidats sont des
// signaux de swing trading récents, pas des positions long terme — la
// fenêtre pertinente est plus courte. Le sélecteur complet (1 semaine à
// 12 mois) reste disponible.
let screenChartPeriodDays = 90;
const screenChartHidden = new Set();
const SCREEN_CHART_CAP = 20; // légende lisible ; au-delà, tronqué (note affichée)

function toggleScreenChartSeries(key) {
  if (screenChartHidden.has(key)) screenChartHidden.delete(key); else screenChartHidden.add(key);
  renderScreenChart();
}
function setScreenChartPeriod(days) {
  screenChartPeriodDays = days;
  document.getElementById('screen-chart-period-select').value = String(days);
  renderScreenChart();
}
function renderScreenChart() {
  const svgEl = document.getElementById('screen-chart-svg');
  if (!screenChartSeries.length) { svgEl.innerHTML = ''; document.getElementById('screen-chart-legend').innerHTML = ''; return; }
  renderPerfChart({
    svgId: 'screen-chart-svg', legendId: 'screen-chart-legend', tooltipId: 'screen-chart-tooltip',
    series: screenChartSeries, periodDays: screenChartPeriodDays, hiddenSet: screenChartHidden,
    onToggleName: 'toggleScreenChartSeries',
  });
}
// Cache/masque le bloc et réinitialise l'état — appelé quand l'univers
// change ou qu'un screening échoue, pour ne jamais laisser le graphique
// d'un ANCIEN résultat à l'écran sous un nouveau contexte.
function resetScreenChart() {
  screenChartSeries = [];
  screenChartHidden.clear();
  document.getElementById('screen-chart-card').style.display = 'none';
}
// `rows` = data.rows du dernier /api/screening (déjà triées Setup puis
// Contexte). Fire-and-forget côté appelant (runScreening) : la table et le
// bouton ne doivent pas attendre ce second appel réseau.
async function loadScreeningPerformance(rows) {
  const block = document.getElementById('screen-chart-card');
  const status = document.getElementById('screen-chart-status');
  const trunc = document.getElementById('screen-chart-truncated');
  if (!rows || rows.length === 0) { resetScreenChart(); return; }

  block.style.display = '';
  screenChartHidden.clear();
  const capped = rows.slice(0, SCREEN_CHART_CAP);
  const isTruncated = rows.length > capped.length;
  trunc.style.display = isTruncated ? '' : 'none';
  trunc.textContent = isTruncated
    ? `Graphique limité aux ${SCREEN_CHART_CAP} meilleurs candidats (Setup puis Contexte) sur ${rows.length}.`
    : '';
  status.textContent = "Chargement de l'historique…";
  try {
    // SPY en dernier : les couleurs --sc-1.. sont attribuées dans l'ordre
    // de la réponse, SPY reçoit sa propre couleur neutre plus bas — le
    // décalage d'index n'a donc pas d'importance ici.
    const tickers = [...capped.map((r) => r.ticker), 'SPY'];
    const data = await fetchJSON('/api/screening/history?tickers=' + encodeURIComponent(tickers.join(',')));
    screenChartSeries = data.series.map((s, i) => {
      const isSpy = s.ticker === 'SPY';
      return {
        key: s.ticker,
        label: s.ticker,
        labelHtml: s.ticker + (s.error ? ' <em style="font-style:italic;">(indisponible)</em>' : ''),
        tooltipLabel: isSpy ? 'S&P 500 (SPY)' : s.ticker,
        color: isSpy ? 'var(--text-2)' : `var(--sc-${(i % 11) + 1})`,
        history: s.history,
        lineStyle: isSpy ? 'benchmark' : 'solid',
        endLabel: s.ticker,
      };
    });
    status.textContent = '';
    renderScreenChart();
  } catch (err) {
    status.textContent = 'Erreur : ' + err.message;
  }
}
