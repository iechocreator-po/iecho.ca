// Évalue js/trade-rules.js pour le serveur local — même patron que server/ticker-format.js.
import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../js/trade-rules.js', import.meta.url), 'utf8');
export const { tradeIsNumber, tradeIsPositive, tradeIsNonNegative, tradeIsIsoDate, tradeNumberErrors } = new Function(
  `${source}; return { tradeIsNumber, tradeIsPositive, tradeIsNonNegative, tradeIsIsoDate, tradeNumberErrors };`)();
