// js/feedback-widget.js — popup "Partager une idée" (6/9/2026), repris tel
// quel du popup iecho.ca (src/components/FeedbackWidget.astro), avec une
// seule différence demandée par JP : "Produit concerné" est pré-sélectionné
// sur "castellana" dans index.html (au lieu de "Général / aucun en
// particulier") — le reste du comportement (dialogue natif, envoi
// Formspree, messages de statut) est identique.
//
// Même destination que iecho.ca : formulaire Formspree mwvdgqgy — les idées
// partagées depuis castellana atterrissent dans la même boîte de réception
// que celles envoyées depuis iecho.ca, distinguées par le champ "produit".
// Aucune dépendance à bilbao/feature-factory ici (même choix que iecho.ca —
// voir CLAUDE.md de iecho.ca, "envoi Formspree codé en dur").

function openFeedback() {
  const dialogue = document.getElementById('feedback-dialogue');
  const form = document.getElementById('feedback-form');
  const message = document.getElementById('feedback-message');
  // Contexte automatique : onglet actif au moment de l'ouverture (pas
  // window.location.pathname comme sur iecho.ca — castellana est une app à
  // page unique, l'onglet est l'information utile ici).
  const ongletActif = document.querySelector('.tab-btn.is-active');
  form.elements.page.value = ongletActif ? ongletActif.dataset.tab : '';
  message.textContent = '';
  message.className = 'feedback-message';
  dialogue.showModal();
}

function closeFeedback() {
  document.getElementById('feedback-dialogue').close();
}

// Point d'entrée — appelé depuis index.html une fois le DOM du dialogue en
// place (même moment que initTelemetry()).
function initFeedbackWidget() {
  const form = document.getElementById('feedback-form');
  const message = document.getElementById('feedback-message');
  const envoyer = document.getElementById('feedback-envoyer');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    envoyer.disabled = true;
    envoyer.textContent = 'Envoi…';
    try {
      const resp = await fetch(form.dataset.endpoint, {
        method: 'POST',
        headers: { Accept: 'application/json' },
        body: new FormData(form),
      });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      message.textContent = 'Merci ! Ton idée est bien partie.';
      message.className = 'feedback-message ok';
      form.elements.message.value = '';
      setTimeout(closeFeedback, 1800);
    } catch (err) {
      console.warn('Envoi feedback échoué :', err);
      message.textContent = "Oups, l'envoi a échoué. Réessaie dans un instant.";
      message.className = 'feedback-message erreur';
    } finally {
      envoyer.disabled = false;
      envoyer.textContent = 'Envoyer';
    }
  });
}
