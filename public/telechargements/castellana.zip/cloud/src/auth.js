// Authentification — hachage de mot de passe (PBKDF2 via Web Crypto) et
// gestion de session. Écrit avec les seules API Web Crypto standard
// (`crypto.subtle`, `crypto.getRandomValues`) — disponibles nativement à la
// fois dans les Workers et dans Node ≥ 20 (`globalThis.crypto`), pour que ce
// module serve TEL QUEL au Worker ET à scripts/create-user.mjs (exécuté en
// local par JP) sans dupliquer la logique de hachage.
//
// 3 utilisateurs connus (JP, Louis, Guillaume) — pas d'auto-inscription,
// pas de JWT sans état : une session en base (table `sessions`) est plus
// simple à révoquer/auditer qu'un token signé, largement suffisant à cette
// échelle (voir CLAUDE.md du produit, section « Portage Cloudflare »).

const PBKDF2_ITERATIONS = 100_000;
export const SESSION_TTL_MS = 30 * 24 * 3600 * 1000; // 30 jours

function toHex(bytes) {
  return [...bytes].map((b) => b.toString(16).padStart(2, '0')).join('');
}

function fromHex(hex) {
  const out = new Uint8Array(hex.length / 2);
  for (let i = 0; i < out.length; i++) out[i] = parseInt(hex.substr(i * 2, 2), 16);
  return out;
}

async function pbkdf2(password, saltBytes) {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt: saltBytes, iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' },
    keyMaterial,
    256,
  );
  return new Uint8Array(bits);
}

// Comparaison à temps constant — évite qu'une différence de timing sur la
// comparaison de hash ne fuite d'information (précaution standard, même à
// 3 utilisateurs connus).
function timingSafeEqual(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export async function hashPassword(password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const hash = await pbkdf2(password, salt);
  return { hash: toHex(hash), salt: toHex(salt) };
}

export async function verifyPassword(password, hashHex, saltHex) {
  const hash = await pbkdf2(password, fromHex(saltHex));
  return timingSafeEqual(toHex(hash), hashHex);
}

export function generateSessionToken() {
  return toHex(crypto.getRandomValues(new Uint8Array(32)));
}

const COOKIE_NAME = 'castellana_session';

export function sessionCookieHeader(token, maxAgeSeconds) {
  return `${COOKIE_NAME}=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAgeSeconds}`;
}

export function clearSessionCookieHeader() {
  return `${COOKIE_NAME}=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0`;
}

export function readSessionToken(cookieHeader) {
  if (!cookieHeader) return null;
  for (const part of cookieHeader.split(';')) {
    const idx = part.indexOf('=');
    if (idx === -1) continue;
    const key = part.slice(0, idx).trim();
    if (key === COOKIE_NAME) return decodeURIComponent(part.slice(idx + 1).trim());
  }
  return null;
}
