// server/premium-screener.js — Journal A (#8/#9, 22/9/2026) : screener de
// primes. Pour chaque titre d'un univers BORNÉ (watchlist / MAG7 / liste
// personnalisée — jamais « élargi », voir isPremiumUniverse), cherche le put
// dont le delta estimé tombe dans la plage demandée, sur la première
// échéance dans la fenêtre DTE voulue (jusqu'à `maxExpiriesPerTicker`
// essayées), calcule son rendement annualisé (#1, réutilisé), et compare son
// IV à la volatilité HISTORIQUE du titre (#9 — Yahoo n'expose pas l'IV
// passée, donc pas de vrai « IV rank »). #10 (jours avant résultats)
// réutilisé au passage, zéro appel réseau de plus (déjà dans le batch
// fondamentaux).
//
// Univers volontairement plafonné : un screener sur l'univers élargi (219
// titres) ferait 219 appels de chaîne d'options par clic — le bug de
// sous-requêtes Cloudflare déjà heurté le 12/9/2026 sur ce même univers
// (voir server/screening.js, universeTickers) serait quasi garanti de se
// reproduire. Décision de JP : non proposé comme choix (voir CLAUDE.md).
import { universeTickers, isValidUniverse } from './screening.js';
import { getOptionChain } from './options.js';
import { getHomemadeIndicatorsBatch } from './indicators.js';
import { getFundamentalsBatch } from './fundamentals.js';
import { mapWithConcurrency } from './fetch-retry.js';
import { optPickForChain, optBetterPick, optComparePicks } from './options-analytics.js';
import { getEffectiveParams } from './labo-params.js';

const MAX_UNIVERSE_SIZE = 60; // garde-fou dur, même pour une liste perso mal configurée

export function isPremiumUniverse(universe) {
  return universe !== 'elargi' && universe !== 'sp500' && isValidUniverse(universe);
}

async function bestPutForTicker(ticker, { deltaMin, deltaMax, dteMin, dteMax, r, maxExpiriesPerTicker, mode, rulePct, rulePeriodDays, type }) {
  let first;
  try {
    first = await getOptionChain(ticker);
  } catch (err) {
    return { ticker, error: err.message };
  }
  const candidates = (first.expirations || []).filter((e) => e.dte >= dteMin && e.dte <= dteMax).slice(0, maxExpiriesPerTicker);
  // Aucune échéance dans la fenêtre : on essaie quand même la plus proche
  // au-delà, plutôt que de renvoyer « rien » sans avoir vraiment cherché.
  const toTry = candidates.length ? candidates : (first.expirations || []).slice(0, maxExpiriesPerTicker);

  let best = null;
  for (const e of toTry) {
    const ch = e.date === first.expiry ? first : await getOptionChain(ticker, { expiry: e.date }).catch(() => null);
    if (!ch) continue;
    best = optBetterPick(mode, best, optPickForChain(ch, { type, mode, deltaMin, deltaMax, r, rulePct, rulePeriodDays }));
  }
  return { ticker, error: null, ...(best || { aucunContrat: true }) };
}

export async function screenPremiums(universe, {
  deltaMin = 0.15, deltaMax = 0.25, dteMin = 25, dteMax = 45, maxExpiriesPerTicker = 3, concurrency = 4,
  mode = 'rendement', rulePct = 0.5, rulePeriodDays = 5, type = 'put',
} = {}) {
  type = type === 'call' ? 'call' : 'put';
  if (!isPremiumUniverse(universe)) {
    throw Object.assign(new Error(`Univers invalide pour le screener de primes : ${universe}`), { status: 400 });
  }
  const tickers = universeTickers(universe).slice(0, MAX_UNIVERSE_SIZE);
  const { riskFreePct } = getEffectiveParams('roue') || { riskFreePct: 4 };
  const r = riskFreePct / 100;

  const [chainRows, indicRows, fundRows] = await Promise.all([
    mapWithConcurrency(tickers, (t) => bestPutForTicker(t, { deltaMin, deltaMax, dteMin, dteMax, r, maxExpiriesPerTicker, mode, rulePct, rulePeriodDays, type }), { limit: concurrency }),
    getHomemadeIndicatorsBatch(tickers),
    getFundamentalsBatch(tickers, { withVwap: false }),
  ]);
  const indicByTicker = new Map(indicRows.map((x) => [x.ticker, x]));
  const fundByTicker = new Map(fundRows.map((x) => [x.ticker, x]));

  const rows = chainRows
    .filter((row) => !row.error && !row.aucunContrat)
    .map((row) => {
      const indic = indicByTicker.get(row.ticker);
      const fund = fundByTicker.get(row.ticker);
      const hv = indic?.historicalVolatility ?? null;
      return {
        ...row,
        // #9 — comparaison à la volatilité HISTORIQUE, pas un IV rank réel.
        historicalVolatility: hv,
        ivVsHistorical: hv != null && row.iv != null ? row.iv - hv : null,
        daysToEarnings: fund?.daysToEarnings ?? null,
      };
    })
    .sort(optComparePicks(mode));

  const skipped = chainRows.filter((row) => row.error || row.aucunContrat).map((row) => ({ ticker: row.ticker, raison: row.error || (mode === 'limite' ? `Aucun ${type} ne respecte la règle ${rulePct} % / ${rulePeriodDays} j avec un delta ≤ ${deltaMax} sur les échéances testées.` : `Aucun ${type} dans la plage de delta ${deltaMin}–${deltaMax} sur les échéances testées.`) }));

  return { universe, type, mode, rulePct, rulePeriodDays, deltaMin, deltaMax, dteMin, dteMax, total: tickers.length, rows, skipped };
}
