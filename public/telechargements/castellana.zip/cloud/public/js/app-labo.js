// js/app-labo.js — Option Lab : stratégies, paramètres, séquence pas-à-pas, corrélation
// Extrait de l'ancien script en ligne des index.html (découpage phase 2, 20/10/2026) : code déplacé tel quel, sans réécriture.
// Fichier COMMUN aux versions locale et cloud : source ici ; cloud/public/js/app-labo.js en est la copie (npm run sync:cloud).
// Script classique : ses noms de premier niveau sont globaux et partagés avec les autres scripts de la page.

// ---- Onglet Labo (5/9/2026) — stratégies d'options, séquence pas-à-pas ----
// Le catalogue de stratégies (STRATEGIES_LABO) et la génération des étapes
// vivent dans js/strategies-labo.js — ce bloc ne fait que le pont avec le
// DOM (sélecteur, ticker, données en direct).
let laboTickerData = null;
// Paramètres des stratégies (feature « Options », 19/9/2026) : uniquement les
// SURCHARGES de l'utilisateur, { stratId: { cle: valeur } } — les défauts et
// les bornes viennent de js/labo-schema.js. L'état coché des étapes est
// gardé en mémoire pour survivre au re-rendu déclenché par chaque édition.
let laboParamOverrides = {};
const laboStepDone = {};
function laboParamsStatus(msg, ok) {
  const el = document.getElementById('labo-params-status');
  if (!el) return;
  el.textContent = msg || '';
  el.style.color = ok === false ? 'var(--red)' : 'var(--text-2)';
}
async function loadLaboParams() {
  try {
    const d = await fetchJSON('/api/labo/params');
    laboParamOverrides = d.overrides || {};
  } catch (err) {
    // Non bloquant : sans ces données, la séquence s'affiche avec les défauts.
    laboParamsStatus(`Paramètres enregistrés indisponibles : ${err.message}`, false);
  }
}
// Raccourci Symbole (7/10/2026) : #labo-ticker-quick ↔ #labo-ticker, et
// chargement automatique du symbole par défaut (CFG.labo.defaultTicker) à la
// première ouverture de l'onglet, pour que la séquence ne soit jamais vide.
let laboAutoLoaded = false;
function laboQuickLoad() {
  const q = document.getElementById('labo-ticker-quick');
  const t = document.getElementById('labo-ticker');
  t.value = q.value.trim().toUpperCase();
  q.value = t.value;
  loadLaboTicker().then(() => {
    document.getElementById('labo-quick-status').textContent = document.getElementById('lab-live-status').textContent;
  });
}
function laboAutoLoadOnce() {
  if (laboAutoLoaded) return;
  laboAutoLoaded = true;
  const t = document.getElementById('labo-ticker');
  const q = document.getElementById('labo-ticker-quick');
  if (!t.value) t.value = (CFG.labo && CFG.labo.defaultTicker) || '';
  q.value = t.value;
  if (t.value) laboQuickLoad();
}
function initLaboQuickTicker() {
  const q = document.getElementById('labo-ticker-quick');
  const t = document.getElementById('labo-ticker');
  if (!q || !t) return;
  q.addEventListener('keydown', (e) => { if (e.key === 'Enter') laboQuickLoad(); });
  q.addEventListener('input', () => { t.value = q.value.toUpperCase(); });
  t.addEventListener('input', () => { q.value = t.value.toUpperCase(); });
}
function initLaboDataWrap() {
  const w = document.getElementById('labo-data-wrap');
  if (!w) return;
  try { if (localStorage.getItem('castellana-labo-data-open') === '0') w.open = false; } catch (e) {}
  w.addEventListener('toggle', () => { try { localStorage.setItem('castellana-labo-data-open', w.open ? '1' : '0'); } catch (e) {} });
}
async function initLaboStrategies() {
  initLaboDataWrap();
  initLaboQuickTicker();
  const sel = document.getElementById('labo-strategie');
  sel.innerHTML = STRATEGIES_LABO.map((s) =>
    `<option value="${s.id}">${s.nom}${s.statut === 'a-venir' ? ' (bientôt disponible)' : ''}</option>`
  ).join('');
  document.getElementById('labo-export-list').innerHTML = STRATEGIES_LABO
    .filter((s) => s.statut === 'disponible')
    .map((s) => `<label><input type="checkbox" class="labo-export-chk" value="${s.id}"> ${s.nom}</label>`)
    .join('');
  // T3 — préremplit avec les valeurs de config.js, mais ce sont ensuite ces
  // champs (pas CFG) qui pilotent réellement le calcul, voir loadLaboTicker().
  document.getElementById('labo-sma-fast').value = CFG.indicateurs.smaRapide;
  document.getElementById('labo-sma-medium').value = CFG.indicateurs.smaMoyenne;
  document.getElementById('labo-sma-slow').value = CFG.indicateurs.smaLente;
  await loadLaboParams();
  renderLaboSequence();
}
function currentLaboStrategyId() {
  return document.getElementById('labo-strategie').value;
}
function renderLaboSequence() {
  const strat = STRATEGIES_LABO.find((s) => s.id === currentLaboStrategyId());
  document.getElementById('labo-strategie-titre').textContent = strat.nom;
  document.getElementById('labo-strategie-resume').textContent = strat.resume;
  document.getElementById('labo-strategie-source').textContent = strat.sourceNote || '';
  const seqEl = document.getElementById('labo-sequence');
  const analyseEl = document.getElementById('labo-analyse');
  const avenirEl = document.getElementById('labo-a-venir');
  const actionsEl = document.getElementById('labo-actions');
  laboRenderExplain(strat);
  if (strat.statut === 'a-venir') {
    avenirEl.style.display = 'flex';
    actionsEl.style.display = 'none';
    seqEl.innerHTML = '';
    analyseEl.innerHTML = '';
    const realEl = document.getElementById('labo-real'); if (realEl) realEl.innerHTML = '';
    return;
  }
  avenirEl.style.display = 'none';
  actionsEl.style.display = 'flex';
  const ticker = document.getElementById('labo-ticker').value.toUpperCase() || CFG.labo.defaultTicker;
  const params = laboEffectiveParams(strat.id, laboParamOverrides[strat.id]);
  // Les données ne valent que pour le symbole chargé : sinon la séquence mêle deux titres (audit app-js, constat 4).
  const dataOk = laboTickerData && laboTickerData.ticker === ticker ? laboTickerData : null;
  const { steps, legs } = strat.build({ ticker, data: dataOk, params });
  const done = laboStepDone[strat.id] || (laboStepDone[strat.id] = {});
  seqEl.innerHTML = steps.map((step, i) => `
    <div class="labo-step${step.points.length && step.points.every((_, j) => done[i + '.' + j]) ? ' is-done' : ''}" id="labo-step-${i}">
      <div class="labo-step-titre" style="cursor:default;">${step.titre}</div>
      <ul style="list-style:none; padding-left:0;">${step.points.map((p, j) => `<li><label class="labo-pt${done[i + '.' + j] ? ' is-done' : ''}"><input type="checkbox"${done[i + '.' + j] ? ' checked' : ''} onchange="laboStepToggled('${strat.id}', ${i}, ${j}, this.checked, this)"><span>${p}</span></label></li>`).join('')}</ul>
    </div>
  `).join('');
  analyseEl.innerHTML = laboRenderAnalyse(legs);
  laboRenderRealChain(strat.id, params, ticker); // vraie chaîne d'options (#396), asynchrone
  const n = Object.keys(laboParamOverrides[strat.id] || {}).length;
  laboParamsStatus(n ? `${n} valeur(s) modifiée(s) pour cette stratégie` : 'Valeurs d\'origine');
}
function laboStepToggled(stratId, i, j, checked, el) {
  const done = laboStepDone[stratId] || (laboStepDone[stratId] = {});
  done[i + '.' + j] = checked;
  if (el) el.closest('.labo-pt').classList.toggle('is-done', checked);
  const step = document.getElementById(`labo-step-${i}`);
  const boxes = step.querySelectorAll('input[type=checkbox]');
  step.classList.toggle('is-done', boxes.length > 0 && [...boxes].every((b) => b.checked));
}
// « En clair » (7/10/2026) : quand utiliser la stratégie et comment elle
// fonctionne, expliqué à quelqu'un de 15 ans (textes : enClair, strategies-labo.js).
function laboRenderExplain(strat) {
  const el = document.getElementById('labo-explain');
  if (!strat.enClair) { el.innerHTML = ''; return; }
  const ul = (l) => `<ul>${l.map((x) => `<li>${x}</li>`).join('')}</ul>`;
  el.innerHTML = `<details class="labo-explain" open><summary><strong>En clair — quand l'utiliser et comment ça marche</strong></summary>`
    + `<h4>Quand l'utiliser ?</h4>${ul(strat.enClair.quand)}`
    + `<h4>Comment ça fonctionne ?</h4>${strat.enClair.comment.map((x) => `<p>${x}</p>`).join('')}</details>`;
}
// Envoie une modification. En cas de refus (bornes, ordre d'une plage), le
// re-rendu remet la dernière valeur valide et le motif s'affiche en clair.
async function laboSaveParams(stratId, values) {
  try {
    const d = await fetchJSON(`/api/labo/params/${stratId}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ values }),
    });
    laboParamOverrides = d.overrides || {};
    renderLaboSequence();
  } catch (err) {
    renderLaboSequence();
    laboParamsStatus(err.message, false);
  }
}
function laboParamChanged(input) {
  laboSaveParams(input.dataset.strat, { [input.dataset.key]: input.value });
}
function laboResetParam(stratId, key) {
  laboSaveParams(stratId, { [key]: laboParamDef(stratId, key).default });
}
async function laboResetStrategy() {
  const id = currentLaboStrategyId();
  try {
    const d = await fetchJSON(`/api/labo/params/${id}/reset`, { method: 'POST' });
    laboParamOverrides = d.overrides || {};
    renderLaboSequence();
    laboParamsStatus('Stratégie réinitialisée aux valeurs d\'origine');
  } catch (err) { laboParamsStatus(err.message, false); }
}
async function laboResetAll() {
  if (!confirm('Remettre TOUTES les stratégies à leurs valeurs d\'origine ?')) return;
  try {
    const d = await fetchJSON('/api/labo/params/reset', { method: 'POST' });
    laboParamOverrides = d.overrides || {};
    renderLaboSequence();
    laboParamsStatus('Toutes les stratégies ont été réinitialisées');
  } catch (err) { laboParamsStatus(err.message, false); }
}
// Export JSON (même patron que downloadTradesCSV : Blob côté client, aucune
// route). Valeurs EFFECTIVES complètes — le fichier se lit seul, sans dépendre
// des défauts du moment — plus la liste des clés modifiées.
function exportLaboStrategies() {
  const ids = [...document.querySelectorAll('.labo-export-chk:checked')].map((c) => c.value);
  if (!ids.length) { laboParamsStatus('Coche au moins une stratégie à exporter.', false); return; }
  const strategies = ids.map((id) => {
    const overrides = laboParamOverrides[id] || {};
    return {
      id,
      nom: STRATEGIES_LABO.find((s) => s.id === id).nom,
      schemaVersion: LABO_SCHEMA.version,
      params: laboEffectiveParams(id, overrides),
      overridden: Object.keys(overrides),
    };
  });
  const payload = {
    format: 'castellana.options-strategies',
    version: 1,
    exportedAt: new Date().toISOString(),
    exportedBy: window.CASTELLANA_USERNAME || null,
    strategies,
  };
  const blob = new Blob([JSON.stringify(payload, null, 2) + '\n'], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `castellana-strategies-${ids.length === 1 ? ids[0] : 'selection'}-${payload.exportedAt.slice(0, 10)}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  laboParamsStatus(`${strategies.length} stratégie(s) exportée(s)`);
}
async function loadLaboTicker() {
  const ticker = document.getElementById('labo-ticker').value.toUpperCase();
  const status = document.getElementById('lab-live-status');
  if (!ticker) { status.textContent = "Entre un symbole d'abord."; return; }
  const smaFast = document.getElementById('labo-sma-fast').value || 9;
  const smaMedium = document.getElementById('labo-sma-medium').value || 21;
  const smaSlow = document.getElementById('labo-sma-slow').value || 100;
  status.textContent = 'Récupération en cours…';
  // Section « Symbole » standard (bannière, Force relative, Golden Cross,
  // fondamentaux) récupérée en parallèle des données propres au Labo.
  const selection = fetchLiveSelectionFor('lab', { quiet: true });
  try {
    const data = await fetchJSON(`/api/labo/${ticker}?smaFast=${smaFast}&smaMedium=${smaMedium}&smaSlow=${smaSlow}`);
    if (document.getElementById('labo-ticker').value.toUpperCase() !== ticker) { status.textContent = 'Symbole modifié pendant le chargement : relance « Charger ».'; return; } // le symbole a changé pendant l'attente
    laboTickerData = { ...data, ticker };
    const notes = [];
    if (data.fundamentalsError) notes.push('fondamentaux indisponibles');
    if (data.indicatorsError) notes.push('ATR/SMA/volatilité indisponibles');
    // 'lab' EST dans FCF_INSTANCES (js/fcf-card.js) : fetchLiveSelectionFor('lab', …)
    // charge déjà la carte FCF et joint sa propre note ici — pas de second
    // chargement séparé (28/9/2026 : ça référençait une variable `fcfPromise`
    // jamais déclarée dans cette fonction, ce qui faisait échouer tout
    // rafraîchissement du Labo avec « Erreur : fcfPromise is not defined »).
    notes.push(...((await selection) || []));
    status.textContent = notes.length ? ('Récupéré partiellement — ' + notes.join(', ') + '.') : 'Récupéré avec succès.';
    trackTickerSelected('labo', ticker, null);
    renderLaboSequence();
  } catch (err) {
    await selection;
    laboTickerData = null;
    status.textContent = 'Erreur : ' + err.message;
  }
}
// Corrélation réelle (#397, 8/10/2026) : remplace le choix « position corrélée ? » déclaré à la
// main par une valeur calculée — corrélation des rendements quotidiens du symbole avec chaque
// position OUVERTE du Journal (voir buildCorrelationReport, server/indicators.js). Le choix reste
// modifiable à la main ; la note garde alors la valeur calculée sous les yeux.
let correlationFetchedFor = null;
let correlationComputedText = '';
async function loadCorrelationFor(ticker) {
  const note = document.getElementById('correlated-note');
  const sel = document.getElementById('correlated');
  if (!note || !sel) return;
  const cfg = (typeof CFG !== 'undefined' && CFG.correlation) || { window: 60, threshold: 0.7 };
  note.textContent = 'Calcul de la corrélation avec tes positions ouvertes…';
  try {
    const d = await fetchJSON(`/api/correlation/${encodeURIComponent(ticker)}?window=${cfg.window}&threshold=${cfg.threshold}`);
    if (document.getElementById('ticker').value.trim().toUpperCase() !== ticker) return; // symbole changé entre-temps
    correlationFetchedFor = ticker;
    let text;
    if (d.openCount === 0) text = 'Aucune autre position ouverte dans le Journal → non corrélé.';
    else if (d.max) {
      const others = d.positions.filter((p) => p.correlation != null && p.ticker !== d.max.ticker).map((p) => `${p.ticker} ${p.correlation.toFixed(2)}`).join(', ');
      text = `Corrélation la plus forte : ${d.max.ticker} ${d.max.correlation.toFixed(2)} (${d.window} séances, seuil ${d.threshold}) → ${d.correlated ? 'corrélé' : 'non corrélé'}${others ? ` · autres : ${others}` : ''}.`;
    } else text = `Historique insuffisant pour calculer la corrélation avec ${d.positions.map((p) => p.ticker).join(', ')} — choix à faire à la main.`;
    if (d.correlated === true) sel.value = 'oui'; else if (d.correlated === false) sel.value = 'non';
    correlationComputedText = text;
    note.textContent = text;
    calcFiche();
  } catch (err) {
    note.textContent = `Corrélation indisponible (${err.message}) — choix à faire à la main.`;
  }
}
