// Étiquette de la tendance de l'OBV (audit donnees-marche, 20/10/2026, constat 1).
//
// Avant : « même signe pour le prix et l'OBV = accumulation, signes opposés = distribution ». Faux dans 2 cas sur 4 :
//   - prix qui BAISSE et OBV qui baisse -> « accumulation » (le glossaire dit : « OBV monte avec le prix ») ;
//   - prix qui baisse et OBV qui MONTE  -> « distribution » (la distribution est une divergence À LA HAUSSE).
// Le score de contexte, la réduction de taille et le contexte de l'analyse IA lisaient cette étiquette.
//
// Définition (document de design, section 4.4 ; glossaire) :
//   accumulation : le prix monte ET l'OBV monte — le volume soutient le mouvement ;
//   distribution : le prix monte mais l'OBV BAISSE — le volume ne suit pas (divergence baissière) ;
//   neutre       : tout le reste, y compris un prix qui baisse (l'OBV sert ici à juger une HAUSSE).
//
// UNE seule définition, importée par server/indicators.js, par sa version cloud (cloud/src/lib/indicators.js, copie
// octet pour octet de ce fichier : npm run sync:cloud) et par server/dataset.js (jeu de données du backtest).
export const OBV_EPSILON = 1e-9;

/** @param {number} priceChange variation du prix sur la fenêtre  @param {number} obvChange variation de l'OBV sur la même fenêtre */
export function obvTrendFrom(priceChange, obvChange) {
  if (!Number.isFinite(priceChange) || !Number.isFinite(obvChange)) return 'neutre';
  if (Math.abs(priceChange) < OBV_EPSILON || Math.abs(obvChange) < OBV_EPSILON) return 'neutre';
  if (priceChange > 0) return obvChange > 0 ? 'accumulation' : 'distribution';
  return 'neutre';
}
