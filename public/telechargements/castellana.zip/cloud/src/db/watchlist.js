// Univers de titres pour le screening — portage Cloudflare de
// server/watchlist.js, DÉSORMAIS PAR UTILISATEUR : `ticker` n'est plus
// unique globalement, la clé primaire devient (user_id, ticker) — chaque
// testeur a sa propre watchlist, seedée depuis SEED_WATCHLIST à sa création
// (au lieu d'une seule fois globalement comme dans la version locale).

export const SEED_WATCHLIST = [
  { ticker: 'MSFT', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'META', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'GOOG', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'AMZN', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'AMD', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'ADBE', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'PYPL', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'RDDT', exchange: 'NYSE', source: 'jp' },
  { ticker: 'JD', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'SMCI', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'ASML', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'CRWV', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'AAPL', exchange: 'NASDAQ', source: 'claude' },
  { ticker: 'NVDA', exchange: 'NASDAQ', source: 'claude' },
  { ticker: 'TSLA', exchange: 'NASDAQ', source: 'claude' },
  { ticker: 'AVGO', exchange: 'NASDAQ', source: 'claude' },
  { ticker: 'CRM', exchange: 'NYSE', source: 'claude' },
  { ticker: 'ORCL', exchange: 'NYSE', source: 'claude' },
  { ticker: 'PLTR', exchange: 'NASDAQ', source: 'claude' },
  { ticker: 'NFLX', exchange: 'NASDAQ', source: 'claude' },
  { ticker: 'XEQT.TO', exchange: 'TSX', source: 'jp' },
];

// « Déjà semée » est un FAIT mémorisé (user_settings), pas « la table est vide » : avant, supprimer son dernier titre remettait les 21 de départ
// (audit routes, 21/10/2026). INSERT OR IGNORE : deux premiers chargements simultanés ne se heurtent plus à la clé primaire.
async function markSeeded(db, userId) {
  await db.prepare("INSERT OR IGNORE INTO user_settings (user_id, key, value) VALUES (?, 'watchlistSeeded', '1')").bind(userId).run();
}
export async function seedWatchlistFor(db, userId) {
  await db.batch(SEED_WATCHLIST.map((r) =>
    db.prepare('INSERT OR IGNORE INTO watchlist (user_id, ticker, exchange, source) VALUES (?, ?, ?, ?)')
      .bind(userId, r.ticker, r.exchange, r.source)));
  await markSeeded(db, userId);
}

// Sème PARESSEUSEMENT au premier accès plutôt qu'exclusivement à la
// création du compte : un utilisateur créé directement en SQL (JP, via
// scripts/create-user.mjs, qui insère par `wrangler d1 execute` sans passer
// par db/users.js createUser()) n'aurait sinon jamais de watchlist. Idempotent
// (vérifie que la table est vide pour CET utilisateur avant de semer).
export async function getWatchlist(db, userId) {
  const { results } = await db.prepare(
    'SELECT ticker, exchange, source FROM watchlist WHERE user_id = ? ORDER BY source, ticker',
  ).bind(userId).all();
  if (results.length === 0) {
    const deja = await db.prepare("SELECT 1 AS ok FROM user_settings WHERE user_id = ? AND key = 'watchlistSeeded'").bind(userId).first();
    if (deja) return results; // vidée par l'utilisateur : elle le reste
    await seedWatchlistFor(db, userId);
    return getWatchlist(db, userId);
  }
  return results;
}

export async function addToWatchlist(db, userId, ticker, exchange = 'NASDAQ') {
  const t = ticker.toUpperCase();
  await db.prepare(
    `INSERT INTO watchlist (user_id, ticker, exchange, source) VALUES (?, ?, ?, 'user')
     ON CONFLICT(user_id, ticker) DO UPDATE SET exchange = excluded.exchange`,
  ).bind(userId, t, exchange).run();
  return getWatchlist(db, userId);
}

export async function removeFromWatchlist(db, userId, ticker) {
  await markSeeded(db, userId); // supprimer, c'est la gérer : plus de réensemencement si elle devient vide
  const result = await db.prepare('DELETE FROM watchlist WHERE user_id = ? AND ticker = ?')
    .bind(userId, ticker.toUpperCase()).run();
  return (result.meta?.changes ?? 0) > 0;
}
