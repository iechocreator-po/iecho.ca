// Génère les copies ESM des fichiers du navigateur que le Worker cloud doit
// connaître (le Worker ne peut pas lire un fichier — il lui faut un module) :
//   js/labo-schema.js        → cloud/src/lib/labo-schema.js        (paramètres des stratégies d'options)
//   js/concepts-data.js      → cloud/src/lib/concepts-data.js      (contenu par défaut des 15 concepts)
//   js/options-analytics.js  → cloud/src/lib/options-analytics.js  (rendement annualisé/capital/roulement — Options A/Journal A)
//
// Le navigateur charge ces fichiers tels quels (scripts classiques) et le
// serveur local évalue labo-schema.js ; plutôt que de maintenir deux textes à
// la main, on enveloppe le même source dans des exports. `--check` (utilisé
// par les tests de parité) ne réécrit rien et sort en 1 si une copie a dérivé.
//
// Usage : npm run sync:cloud   |   node scripts/sync-cloud-copies.mjs --check

import { copyFileSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const path = (rel) => fileURLToPath(new URL(`../${rel}`, import.meta.url));

export const COPIES = [
  {
    source: 'js/trade-rules.js',
    target: 'cloud/src/lib/trade-rules.js',
    exports: 'tradeIsNumber, tradeIsPositive, tradeIsNonNegative, tradeIsIsoDate, tradeNumberErrors',
  },
  {
    source: 'js/ticker-format.js',
    target: 'cloud/src/lib/ticker-format.js',
    exports: 'TICKER_PATTERN, TICKER_ERROR, isValidTicker',
  },
  {
    source: 'js/labo-schema.js',
    target: 'cloud/src/lib/labo-schema.js',
    exports: 'LABO_SCHEMA, laboResolveStrategy, laboDefaults, laboEffectiveParams, laboMergeOverrides',
  },
  {
    source: 'js/concepts-data.js',
    target: 'cloud/src/lib/concepts-data.js',
    exports: 'CONCEPTS_TRADING',
  },
  {
    // options-analytics.js utilise `laboNormCdf` (global défini dans
    // strategies-labo.js côté navigateur) — la copie générée doit donc
    // embarquer la même tranche laboErf→laboNormInv en préambule, sinon le
    // Worker plante en `laboNormCdf is not defined`. Même tranche que
    // server/options-analytics.js et server/options-tab.test.js.
    source: 'js/options-analytics.js',
    target: 'cloud/src/lib/options-analytics.js',
    exports: 'optAnnualizedYield, optCapitalRequired, optAssignmentProbabilityLabel, optRollNetCredit, optionDelta, optionMarketZone, optDealLiquidity, optDealValuation, optIntrinsicValue, optExtrinsicValue, optPremiumRule, optCushion, optRuleLimit, optPickForChain, optPickPutForChain, optBetterPick, optComparePicks, optDealReturnOrLeverage, optDealVerdict, optScoreDeal, optAtmIv, optExpectedMove, optStraddleMove, optEmPosition, optIdealStrike, optIvRank, optCloseOnOrBefore, optCycleBilan, optLegEnd, optLegPnl, optLegReturn, optLegIssues, optWeekStart, optWeekYear, optPeriodOf, optWeeklyReport, optAccountSnapshot, optAnnualDashboard, optMaxPricePerTicker, optRoueDeletionPlan, optStrikeDistance, optRouePositions, optLegOutcomes, optPremiumBreakdown, optValueSeries, optRoueActivity, optWeekLegs',
    preludeSource: 'js/strategies-labo.js',
    preludeStart: 'function laboErf',
    preludeEnd: 'function laboNormInv',
  },
];

// Copies OCTET POUR OCTET (feuilles de style communes) : la version cloud sert son propre dossier `cloud/public/`.
// Ajouter ici tout fichier commun que les deux pages chargent à l'identique.
export const PLAIN_COPIES = [
  { source: 'css/app.css', target: 'cloud/public/css/app.css' },
  // Réglages et calcul de taille de position : une seule source, jamais deux versions qui divergent (audit formules, 20/10/2026).
  { source: 'config.js', target: 'cloud/public/config.js' },
  { source: 'js/sizing.js', target: 'cloud/public/js/sizing.js' },
  { source: 'js/labo-real-chain.js', target: 'cloud/public/js/labo-real-chain.js' },
  { source: 'js/strategies-labo.js', target: 'cloud/public/js/strategies-labo.js' },
  { source: 'js/concepts-content.js', target: 'cloud/public/js/concepts-content.js' },
  { source: 'js/ticker-format.js', target: 'cloud/public/js/ticker-format.js' },
  { source: 'js/roue-import.js', target: 'cloud/public/js/roue-import.js' },
  // Définition unique de l'étiquette de l'OBV (audit donnees-marche, constat 1) et son glossaire.
  { source: 'server/obv-trend.js', target: 'cloud/src/lib/obv-trend.js' },
  { source: 'js/glossaire-indicateurs.js', target: 'cloud/public/js/glossaire-indicateurs.js' },
  // Tableaux de bord de la Roue : formules et écran, une source (audit formules, constat 2).
  { source: 'js/options-analytics.js', target: 'cloud/public/js/options-analytics.js' },
  { source: 'js/roue-tab.js', target: 'cloud/public/js/roue-tab.js' },
  // Ancien script en ligne des index.html (découpage phase 2) : code commun, une source dans js/.
  ...['app-base', 'app-listes', 'app-journal', 'app-selection', 'app-fiche', 'app-labo', 'app-screening',
    'app-secteurs', 'app-graphiques', 'app-reglages', 'app-init', 'app-demarrage']
    .map((n) => ({ source: `js/${n}.js`, target: `cloud/public/js/${n}.js` })),
];

export function buildEsm(copy) {
  const source = readFileSync(path(copy.source), 'utf8');
  const prelude = copy.preludeSource
    ? (() => {
      const p = readFileSync(path(copy.preludeSource), 'utf8');
      return p.slice(p.indexOf(copy.preludeStart), p.indexOf(copy.preludeEnd))
        + `// ↑ tranche de ${copy.preludeSource} (laboErf/laboNormCdf), requise par ${copy.source}\n\n`;
    })()
    : '';
  return `// FICHIER GÉNÉRÉ — ne pas éditer. Source : ${copy.source}\n`
    + `// Régénérer avec : npm run sync:cloud (depuis trading-assistant/)\n\n`
    + prelude
    + source
    + `\nexport { ${copy.exports} };\n`;
}

// Compat : l'ancien test importait buildEsm() sans argument (schéma Labo).
export const buildLaboEsm = () => buildEsm(COPIES[0]);

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const check = process.argv.includes('--check');
  let dirty = false;
  for (const copy of COPIES) {
    const expected = buildEsm(copy);
    if (check) {
      let current = '';
      try { current = readFileSync(path(copy.target), 'utf8'); } catch { /* absent */ }
      if (current !== expected) {
        console.error(`${copy.target} a dérivé de ${copy.source} — lance : npm run sync:cloud`);
        dirty = true;
      }
    } else {
      writeFileSync(path(copy.target), expected);
      console.log('Écrit :', copy.target);
    }
  }
  for (const copy of PLAIN_COPIES) {
    if (check) {
      let current = null;
      try { current = readFileSync(path(copy.target)); } catch { /* absent */ }
      if (!current || !current.equals(readFileSync(path(copy.source)))) {
        console.error(`${copy.target} a dérivé de ${copy.source} — lance : npm run sync:cloud`);
        dirty = true;
      }
    } else {
      mkdirSync(dirname(path(copy.target)), { recursive: true });
      copyFileSync(path(copy.source), path(copy.target));
      console.log('Copié :', copy.target);
    }
  }
  if (check) {
    if (dirty) process.exit(1);
    console.log('Copies cloud à jour.');
  }
}
