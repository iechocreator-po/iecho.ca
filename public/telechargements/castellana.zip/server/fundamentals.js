// Fondamentaux de screening (feature 322) — Float, PEG, Beta 5Y, prix,
// volume du jour, VWAP intraday. Toutes ces données viennent de Yahoo
// Finance direct (yahoo-finance2), comme indicators.js — indépendant du
// sidecar tradingview-mcp et de son scanner rate-limité (coin_analysis).
//
// Ce sont des filtres SUPPLÉMENTAIRES, pas des colonnes du score composite :
// le score reste sur les 4 colonnes du design doc (RSI/Force/Golden
// Cross/OBV, voir scoreRow() dans index.js). Ici on fournit la donnée brute
// + des drapeaux pass/fail par critère, et le frontend décide de filtrer ou
// non l'univers dessus.

import YahooFinance from 'yahoo-finance2';
import { withRetry, mapWithConcurrency } from './fetch-retry.js';
import { cached, TTL } from './cache.js';

const yahooFinance = new YahooFinance({ suppressNotices: ['yahooSurvey'] });

// VWAP intraday du jour (typical price pondéré par le volume sur les barres
// 5 min de la séance). Signal du design doc : « VWAP below price » = prix
// au-dessus du VWAP → biais acheteur. Retourne null hors séance / si Yahoo
// ne renvoie pas d'intraday (jour férié, titre peu liquide).
async function computeIntradayVWAP(symbol) {
  const now = new Date();
  const start = new Date(now.getTime() - 24 * 3600 * 1000);
  const chart = await withRetry(`VWAP intraday ${symbol}`, () =>
    yahooFinance.chart(symbol, { period1: start, period2: now, interval: '5m' }));
  const bars = chart.quotes.filter((q) => q.close != null && q.volume != null && q.high != null && q.low != null);
  if (bars.length === 0) return null;
  let pv = 0;
  let vv = 0;
  for (const b of bars) {
    const typical = (b.high + b.low + b.close) / 3;
    pv += typical * b.volume;
    vv += b.volume;
  }
  return vv > 0 ? pv / vv : null;
}

// Un titre : fondamentaux + VWAP. Deux appels Yahoo (quoteSummary + chart
// intraday) ; le VWAP est optionnel (withVwap=false pour un screening plus
// rapide). Lève si quoteSummary échoue ; le VWAP échoue en silence (null).
// Date des prochains résultats (ISO) et moment de la journée déduit de l'heure
// à New York : < 9 h 30 = avant l'ouverture, >= 16 h = après la clôture, sinon
// inconnu (Yahoo donne souvent minuit ou une heure sans signification).
function earningsInfo(qs) {
  const d = qs.calendarEvents?.earnings?.earningsDate?.[0];
  if (!d) return { earningsDate: null, earningsTiming: null };
  const dt = new Date(d);
  if (Number.isNaN(dt.getTime())) return { earningsDate: null, earningsTiming: null };
  const p = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit', hour: 'numeric', minute: 'numeric', hour12: false }).formatToParts(dt);
  const g = (t) => p.find((x) => x.type === t).value;
  const mins = (Number(g('hour')) % 24) * 60 + Number(g('minute'));
  const timing = mins >= 16 * 60 ? 'after close' : (mins > 0 && mins < 9 * 60 + 30 ? 'before open' : null);
  return { earningsDate: `${g('year')}-${g('month')}-${g('day')}`, earningsTiming: timing };
}

export async function getFundamentals(symbol, { withVwap = true } = {}) {
  // TTL court (15 min), PAS 24 h : `quoteSummary` mêlange dans un seul objet
  // des champs trimestriels (bêta, flottant, secteur, industrie) et des
  // champs intrajournaliers (prix, volume) — c'est le plus rapide des deux
  // qui doit cadencer le cache. Les séparer coûterait un appel réseau de
  // plus par titre pour un gain nul. Voir server/cache.js.
  // ⚠️ `v2` dans la clé de cache, et ce n'est pas décoratif : trouvé en
  // testant, pas à la relecture. En ajoutant le module `calendarEvents`
  // ci-dessous, le cache a continué de servir les objets enregistrés AVANT
  // le changement — sans ce module, donc sans date de résultats. Toutes les
  // lignes ressortaient « inconnu », et rien ne signalait que c'était le
  // cache et non Yahoo.
  //
  // Règle à suivre : **changer la FORME d'une réponse mise en cache impose
  // d'incrémenter cette version**, sinon l'ancien format est servi jusqu'à
  // expiration du TTL. Vaut pour tout `cached()` dont le payload change.
  const qs = await cached(`fundamentals:v2:${symbol}`, TTL.FUNDAMENTALS, () =>
    withRetry(`fondamentaux ${symbol}`, () => yahooFinance.quoteSummary(symbol, {
      // `calendarEvents` ajouté le 11/9/2026 pour la date des prochains
      // résultats trimestriels — module de plus dans l'appel EXISTANT, donc
      // zéro requête réseau supplémentaire (vérifié).
      modules: ['price', 'summaryDetail', 'defaultKeyStatistics', 'summaryProfile', 'calendarEvents'],
    })));
  const price = qs.price?.regularMarketPrice ?? null;
  let vwap = null;
  if (withVwap) {
    try {
      vwap = await computeIntradayVWAP(symbol);
    } catch {
      vwap = null;
    }
  }
  return {
    price,
    volume: qs.price?.regularMarketVolume ?? null,
    // Capitalisation boursière — vient du module `price` DÉJÀ demandé, donc
    // zéro appel réseau de plus. Sert au mode « top filtré » de la carte
    // « Titres les plus performants du secteur » (11/9/2026), qui passe
    // désormais par le pipeline de screening.
    marketCap: qs.price?.marketCap ?? null,
    floatShares: qs.defaultKeyStatistics?.floatShares ?? null,
    pegRatio: qs.defaultKeyStatistics?.pegRatio ?? null,
    beta: qs.summaryDetail?.beta ?? null,
    // P/E ratio (trailing) et industrie (GICS sub-industry, summaryProfile) —
    // demandés par JP pour le screening. Le P/E MOYEN de l'industrie n'est
    // PAS fourni ici : voir index.js, calculé après coup sur l'ensemble du
    // batch (approximation par pairs de watchlist, pas un vrai agrégat
    // sectoriel externe).
    peRatio: qs.summaryDetail?.trailingPE ?? null,
    // Price-to-Sales (12 derniers mois) = capitalisation ÷ revenus — Yahoo le
    // fournit déjà dans `summaryDetail` (vérifié égal à marketCap/totalRevenue
    // sur AMD, NVDA, XOM, PLTR), donc zéro appel réseau de plus. Pertinent pour
    // les entreprises non rentables en forte croissance, où le P/E n'existe pas.
    // `null` pour un FNB ou une société sans revenus — jamais 0.
    priceToSales: qs.summaryDetail?.priceToSalesTrailing12Months ?? null,
    industry: qs.summaryProfile?.industry ?? null,
    // Secteur GICS large (Technology, Healthcare, Energy…) — distinct de
    // `industry` (plus fin, ex. "Semiconductors"). Utilisé par
    // server/sectors.js pour agréger le PEG moyen par secteur (30/8/2026).
    sector: qs.summaryProfile?.sector ?? null,
    vwap,
    // Drapeau pratique pour le frontend/scoring : prix au-dessus du VWAP.
    aboveVwap: price != null && vwap != null ? price > vwap : null,
    // Jours avant les prochains résultats trimestriels (11/9/2026).
    //
    // Pourquoi ça compte pour un swing trade : entrer deux jours avant des
    // résultats n'est pas le même pari qu'entrer en milieu de trimestre — le
    // titre peut ouvrir très loin du stop, qui ne protège alors de rien. Ce
    // n'est pas une donnée technique de plus, c'est un risque d'une autre
    // nature, et rien dans l'app ne le signalait.
    //
    // `null` si Yahoo ne donne pas de date (fréquent sur les FNB, qui n'ont
    // pas de résultats) — jamais un 999 qui se lirait comme « très loin ».
    ...earningsInfo(qs),
    daysToEarnings: (() => {
      const d = qs.calendarEvents?.earnings?.earningsDate?.[0];
      if (!d) return null;
      const jours = Math.round((new Date(d).getTime() - Date.now()) / 86_400_000);
      // Une date passée que Yahoo n'a pas encore actualisée ne dit rien
      // d'utile sur le PROCHAIN trimestre : on préfère « inconnu ».
      return jours >= 0 ? jours : null;
    })(),
  };
}

// Batch pour le screening — parallélisme BORNÉ depuis le 7/9/2026 (c'était
// une boucle séquentielle espacée de 300 ms par titre, même prudence héritée
// du rate-limit TradingView que dans indicators.js). Un titre en échec
// ressort avec `error` rempli et tous les champs à null, sans interrompre le
// reste.
export async function getFundamentalsBatch(tickers, { withVwap = true, concurrency = 6 } = {}) {
  return mapWithConcurrency(tickers, async (ticker) => {
    try {
      const data = await getFundamentals(ticker, { withVwap });
      return { ticker, ...data, error: null };
    } catch (err) {
      return {
        ticker,
        price: null,
        volume: null,
        floatShares: null,
        pegRatio: null,
        beta: null,
        peRatio: null,
        priceToSales: null,
        industry: null,
        sector: null,
        vwap: null,
        aboveVwap: null,
        daysToEarnings: null,
        error: err.message,
      };
    }
  }, { limit: concurrency });
}
