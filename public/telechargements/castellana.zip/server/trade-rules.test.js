// Audit routes (21/10/2026) : nombres et dates du Journal et de la Roue, mêmes règles en local et dans le Worker.
import test from 'node:test';
import assert from 'node:assert/strict';
import { tradeIsNumber, tradeIsNonNegative, tradeIsIsoDate, tradeNumberErrors } from './trade-rules.js';
import * as cloudRules from '../cloud/src/lib/trade-rules.js';
import { validateTrade } from './trades.js';
import { validateOptionTrade } from './option-trades.js';
import { validateTrade as validateTradeCloud } from '../cloud/src/db/trades.js';
import { validateOptionTrade as validateOptionTradeCloud } from '../cloud/src/db/option-trades.js';

const trade = (over = {}) => ({ date_entree: '2026-10-01', compte: 'margin', ticker: 'AMD', prix_entree: 100, taille_position: 10, stop_initial: 95, ...over });
const option = (over = {}) => ({ type: 'put', ticker: 'AMD', compte: 'margin', strike: 50, echeance: '2026-11-20', prime_recue: 1, date_ouverture: '2026-10-01', ...over });

test('tradeIsNumber / tradeIsNonNegative : null, vide, tableau et booléen ne sont pas des nombres', () => {
  for (const v of [null, undefined, '', '  ', [], [0], false, true, {}, 'abc', NaN, Infinity]) assert.equal(tradeIsNumber(v), false, String(v));
  for (const v of [0, 1.5, '2', '0']) assert.equal(tradeIsNumber(v), true, String(v));
  assert.equal(tradeIsNonNegative(null), false, 'null >= 0 vaut true en JS : c\'était le défaut du rachat sans prime');
  assert.equal(tradeIsNonNegative(''), false);
  assert.equal(tradeIsNonNegative([]), false);
  assert.equal(tradeIsNonNegative(0), true, '0 reste une prime réelle');
  assert.equal(tradeIsNonNegative(-0.01), false);
});

test('tradeIsIsoDate : un vrai jour du calendrier, au format AAAA-MM-JJ', () => {
  assert.equal(tradeIsIsoDate('2026-10-01'), true);
  assert.equal(tradeIsIsoDate('2024-02-29'), true);
  for (const v of ['2026-02-30', '2026-13-01', '2026-9-1', 'n\'importe quoi', '', null, 20261001, '2026-10-01T00:00:00Z']) assert.equal(tradeIsIsoDate(v), false, String(v));
});

test('validateTrade : un trade valide passe, les valeurs absurdes sont refusées (local et cloud)', () => {
  for (const [nom, fn] of [['local', validateTrade], ['cloud', validateTradeCloud]]) {
    assert.deepEqual(fn(trade()), [], `${nom} : trade valide`);
    assert.ok(fn(trade({ prix_entree: -5 })).some((e) => /prix_entree/.test(e)), `${nom} : prix négatif`);
    assert.ok(fn(trade({ taille_position: 0 })).some((e) => /taille_position/.test(e)), `${nom} : taille 0`);
    assert.ok(fn(trade({ taille_position: 2.5 })).some((e) => /taille_position/.test(e)), `${nom} : taille décimale`);
    assert.ok(fn(trade({ stop_initial: 'abc' })).some((e) => /stop_initial/.test(e)), `${nom} : stop texte`);
    assert.ok(fn(trade({ stop_initial: 100 })).some((e) => /risque nul/.test(e)), `${nom} : stop = entrée`);
    assert.ok(fn(trade({ date_entree: 'n\'importe quoi' })).some((e) => /date_entree/.test(e)), `${nom} : date`);
    assert.ok(fn(trade({ prix_sortie: 0 })).some((e) => /prix_sortie/.test(e)), `${nom} : sortie 0`);
    assert.deepEqual(fn({ stop_initial: 90 }, { partial: true }), [], `${nom} : une modification partielle valide passe`);
    assert.ok(fn({ prix_sortie: 'x' }, { partial: true }).length > 0, `${nom} : modification partielle invalide`);
  }
});

test('validateOptionTrade : les dates doivent être réelles (local et cloud)', () => {
  for (const [nom, fn] of [['local', validateOptionTrade], ['cloud', validateOptionTradeCloud]]) {
    assert.deepEqual(fn(option()), [], `${nom} : option valide`);
    assert.ok(fn(option({ echeance: 'bientôt' })).some((e) => /echeance/.test(e)), `${nom} : échéance`);
    assert.ok(fn(option({ date_ouverture: '2026-02-30' })).some((e) => /date_ouverture/.test(e)), `${nom} : ouverture`);
  }
});

test('la copie cloud des règles est identique à la source', () => {
  for (const v of [null, '', [], 0, '5', 'x']) assert.equal(cloudRules.tradeIsNonNegative(v), tradeIsNonNegative(v));
  for (const d of ['2026-10-01', '2026-02-30', 'x']) assert.equal(cloudRules.tradeIsIsoDate(d), tradeIsIsoDate(d));
  assert.deepEqual(cloudRules.tradeNumberErrors(trade({ prix_entree: -1 })), tradeNumberErrors(trade({ prix_entree: -1 })));
});

test('modification partielle : un champ obligatoire ne peut pas être vidé (local et cloud)', () => {
  for (const [nom, fn] of [['local', validateTrade], ['cloud', validateTradeCloud]]) {
    for (const [champ, vide] of [['ticker', ''], ['ticker', null], ['date_entree', '  '], ['compte', null], ['prix_entree', ''], ['stop_initial', null]]) {
      assert.ok(fn({ [champ]: vide }, { partial: true }).length > 0, `${nom} : ${champ} = ${JSON.stringify(vide)} doit être refusé`);
    }
    assert.deepEqual(fn({ vix_a_entree: null, rsi_a_entree: '', notes: '' }, { partial: true }), [], `${nom} : les champs facultatifs restent videables`);
    assert.deepEqual(fn({ stop_initial: 90 }, { partial: true }), [], `${nom} : une vraie modification passe`);
  }
});
