# castellana — Assistant de swing trading

Outil personnel d'aide à la décision pour le swing trading sur actions
(tech/IA principalement). Ce n'est **ni un robot de trading, ni un
générateur de conseils financiers** : il n'envoie jamais d'ordre et ne
recommande rien à un tiers. C'est un assistant de screening, de calcul de
taille de position, et de journal de trades — pour une seule personne
(usage local, pas de compte, pas d'authentification).

> Nom de code interne : **castellana**. Le dossier s'appelle
> `trading-assistant` par convention (voir `CLAUDE.md` si tu cherches le
> contexte complet du projet — c'est le journal de bord détaillé, pas
> nécessaire pour faire tourner l'app).

## Ce que fait l'app

Trois écrans, dans un seul parcours :

1. **Écran de sélection** — un tableau de 20 titres passés au crible (RSI,
   force relative vs S&P 500, Golden Cross, OBV, P/E, industrie…), plus la
   performance du jour de chaque secteur du marché (graphique + tableau).
   Sert à décider quels titres suivre activement.
2. **Fiche de trade** — une fois un titre choisi, calcule automatiquement la
   taille de position, le stop (basé sur l'ATR), la charge de risque du
   portefeuille, et les cibles de sortie (multiples de R et extensions
   Fibonacci).
3. **Journal & stats** — enregistre chaque trade pris (compte, prix, stop,
   indicateurs au moment de l'entrée) et calcule après coup si tel ou tel
   indicateur a réellement aidé.

Toutes les données de marché (cours, indicateurs techniques, secteurs) sont
allées chercher **en direct**, gratuitement, via Yahoo Finance et un petit
serveur tiers spécialisé (voir architecture ci-dessous) — aucune clé API à
configurer.

## Architecture — les 3 pièces qui doivent tourner ensemble

C'est la source de confusion la plus fréquente à l'installation : **ce
n'est pas une seule application, ce sont deux serveurs séparés** (plus une
base de données locale qui se crée toute seule). Il faut les deux pour
avoir toutes les fonctionnalités — mais l'app **fonctionne en mode dégradé**
si l'un des deux manque (voir plus bas).

```mermaid
flowchart LR
    subgraph Navigateur
        UI["Dashboard\n(index.html — HTML/CSS/JS, aucun build)"]
    end
    subgraph "Machine locale"
        BACK["Backend Express\n(Node.js — server/index.js)\nhttp://127.0.0.1:4700"]
        DB[("SQLite\ndata/castellana.sqlite\ncréée automatiquement")]
        SIDE["Sidecar Python\n(tradingview-mcp)\nhttp://127.0.0.1:4701"]
    end
    YAHOO[("Yahoo Finance\n(gratuit, pas de clé)")]
    TV[("TradingView\n(scanner public, via le sidecar)")]

    UI <--> BACK
    BACK <--> DB
    BACK <-. "protocole MCP\n(optionnel)" .-> SIDE
    BACK --> YAHOO
    SIDE --> TV
```

| Pièce | Techno | Rôle | Obligatoire ? |
|---|---|---|---|
| **Dashboard** | `index.html` — HTML/CSS/JS pur, aucune étape de build | L'interface que tu vois dans le navigateur | Oui — servi par le backend |
| **Backend** | Node.js + Express + SQLite (`server/`) | Sert le dashboard, calcule les indicateurs (RSI, ATR, SMA, OBV…) depuis Yahoo Finance, gère le journal de trades | **Oui, toujours** |
| **Sidecar MCP** | Python (paquet `tradingview-mcp-server`, protocole MCP) | Complète le backend pour VIX, RSI et Golden Cross via le scanner public de TradingView | **Optionnel** — sans lui, ces champs restent à saisir à la main, le reste de l'app marche normalement |

**Aucun compte TradingView n'est nécessaire** (ni aucun autre compte,
clé API, ou `.env` à remplir) — le sidecar interroge les endpoints publics
non officiels de TradingView (mêmes données que son scanner web gratuit),
sans jamais se connecter à un compte ni ouvrir de session. Voir
`CLAUDE.md`, section « Intégration données de marché — tradingview-mcp »,
pour le détail de cette source et sa zone grise côté conditions
d'utilisation de TradingView (pas de risque de compte, mais pas un statut
« officiel » non plus). Tout tourne en local sur `127.0.0.1` (jamais exposé
sur Internet).

## Installer et lancer le projet

👉 **Voir [`SETUP.md`](SETUP.md)** pour les instructions pas-à-pas,
séparément pour Windows et macOS (clonage du repo privé, installation des
dépendances, lancement des deux serveurs, dépannage des erreurs courantes).

> Projet déjà cloné auparavant ? Fais `git pull` avant de relancer — le
> projet évolue souvent, et une erreur inattendue vient presque toujours
> d'une copie locale pas à jour plutôt que d'un vrai problème d'installation.

Résumé pour quelqu'un qui a déjà tout installé :

```bash
# Terminal 1 — obligatoire
npm start
# → http://127.0.0.1:4700

# Terminal 2 — optionnel (VIX/RSI/Golden Cross en direct)
npm run sidecar
```

Le témoin de statut dans l'en-tête de l'app (3 pastilles : Backend /
tradingview-mcp / Calculs maison) indique en direct ce qui tourne et ce qui
manque.

## Stack technique

- **Frontend** : HTML/CSS/JS vanilla, zéro framework, zéro étape de build.
- **Backend** : Node.js (≥ 20) + Express + `better-sqlite3` (module natif —
  voir `SETUP.md` si son installation échoue sur Windows).
- **Données de marché** : `yahoo-finance2` (npm, direct) + `tradingview-mcp`
  (sidecar Python tiers, protocole MCP).
- **Design** : copie vendorée du design system du portfolio
  (`design-system/`), pas de dépendance externe.

## Portée et limites (à lire avant de contribuer)

- Usage **local et personnel** — pas pensé pour être déployé sur le web, pas
  d'authentification.
- **N'envoie jamais d'ordre** à un courtier — c'est un outil d'aide à la
  décision et de journalisation, pas d'exécution automatique.
- Les données de screening dépendent d'API publiques non officielles
  (Yahoo Finance, scanner TradingView) — un rate-limit occasionnel sur le
  scanner TradingView est normal et documenté (voir `CLAUDE.md`).
- `CLAUDE.md` à la racine est le journal de bord détaillé du projet
  (décisions, historique, limites connues) — utile pour comprendre
  *pourquoi* certains choix ont été faits, pas nécessaire pour l'utiliser.
