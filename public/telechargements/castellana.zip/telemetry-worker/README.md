# castellana-telemetry

Petit collecteur de télémétrie pour castellana. **Ce n'est pas castellana
lui-même** — castellana reste une app 100% locale, lancée par chaque
testeur sur sa propre machine (voir [`../SETUP.md`](../SETUP.md)). Ce
Worker est le seul morceau de castellana déployé publiquement : il reçoit
les événements que chaque instance locale lui envoie directement depuis le
navigateur (ticker sélectionné, paramètre modifié, chargement de l'app).

Voir `../CLAUDE.md`, section « Télémétrie testeurs », pour le contexte
complet et le détail des événements capturés.

## Déploiement (geste manuel, une seule fois)

Prérequis : un compte Cloudflare (déjà utilisé ailleurs dans le portfolio),
`wrangler` (installé via `npm install` dans ce dossier).

```bash
cd telemetry-worker
npm install
npx wrangler login          # une seule fois, ouvre le navigateur

# 1. Créer la base D1
npx wrangler d1 create castellana-telemetry-db
# → copier le "database_id" affiché dans la sortie de cette commande
#   et le coller dans wrangler.jsonc, champ d1_databases[0].database_id

# 2. Appliquer le schéma à la base fraîchement créée
npx wrangler d1 execute castellana-telemetry-db --remote --file=schema.sql

# 3. Déployer le Worker
npx wrangler deploy
# → l'URL affichée (ex: https://castellana-telemetry.<sous-domaine>.workers.dev)
#   est à coller dans ../config.js, champ CFG.telemetry.endpoint
```

## Après le déploiement

1. Coller l'URL du Worker dans `../config.js` → `CFG.telemetry.endpoint`.
2. Vérifier que `CFG.telemetry.sharedToken` (dans `../config.js`) est
   identique à `TELEMETRY_TOKEN` (dans `wrangler.jsonc`, section `vars`) —
   ce sont deux copies manuelles du même jeton, aucune synchronisation
   automatique.
3. Définir les identifiants du tableau de bord (12/9/2026) — en SECRETS
   Wrangler, jamais dans `wrangler.jsonc` (qui est commité) :
   ```bash
   npx wrangler secret put DASHBOARD_USER
   npx wrangler secret put DASHBOARD_PASSWORD
   ```
4. Tester : lancer castellana en local, choisir un nom dans le sélecteur du
   header, changer un ticker → ouvrir `https://<votre-url>.workers.dev/dashboard`,
   entrer les identifiants dans la boîte de dialogue du navigateur, et
   confirmer que l'événement apparaît.

## Consulter les événements

- Tableau de bord (activité par jour, tickers les plus sélectionnés, filtre
  par testeur et par plage de jours 7/30/90, + les 200 derniers événements
  de la période filtrée) : `GET /dashboard` — paramètres optionnels
  `&who=<nom>` et `&days=<7|30|90>`. Protégé par HTTP Basic Auth
  (`DASHBOARD_USER`/`DASHBOARD_PASSWORD`) — le navigateur demande les
  identifiants au premier accès, une seule fois par session.
- Export CSV complet (5000 derniers, non filtré) : `GET /events.csv` —
  même authentification.
- Requête SQL directe (sans passer par le Worker) :
  ```bash
  npx wrangler d1 execute castellana-telemetry-db --remote --command \
    "SELECT * FROM telemetry_events ORDER BY id DESC LIMIT 20"
  ```

## Intégration bilbao (13/9/2026, feature #356)

Deux routes supplémentaires, réservées aux appels **serveur→serveur** depuis
bilbao (`feature-factory/server/telemetry.js`) — jamais depuis un
navigateur de visiteur. Même Basic Auth que `/dashboard`/`/events.csv` :
bilbao détient `DASHBOARD_USER`/`DASHBOARD_PASSWORD` dans son propre `.env`
local (jamais commité, jamais envoyé à son propre navigateur — voir
`feature-factory/.env.example`).

- `GET /summary?days=&who=` — les mêmes données que `/dashboard`, en JSON
  (`{ days, who, testeurs, daily, tickers, recent, total }`) plutôt qu'en
  HTML/SVG : bilbao construit son propre rendu avec son propre design
  system.
- `POST /delete` — **destructeur, sur de vraies données de production.**
  Corps JSON avec un `scope` explicite, jamais de défaut implicite :
  - `{"scope":"who","who":"<nom>"}` — supprime tous les événements de ce
    testeur.
  - `{"scope":"range","from":"YYYY-MM-DD","to":"YYYY-MM-DD"}` — supprime les
    événements dont `created_at` tombe dans cette plage (inclusive).
  - `{"scope":"all","confirm":true}` — supprime TOUT ; refusé (400) sans
    `confirm:true` explicite, dernier garde-fou contre un bug d'appel.
  Répond `{"ok":true,"scope":"...","deleted":N}` — le nombre réel de lignes
  supprimées, jamais un succès muet.

Testé en local avec `wrangler dev --local` (D1 simulée, aucun risque pour la
production) avant d'être branché depuis bilbao — voir
`trading-assistant/CLAUDE.md`, 13/9/2026, pour le détail de la vérification.

## Mettre à jour le schéma ou le code

Après toute modification de `schema.sql` ou `src/index.js` :
```bash
npx wrangler d1 execute castellana-telemetry-db --remote --file=schema.sql   # si schéma changé
npx wrangler deploy                                                          # à chaque changement de code
```

## Limites assumées (voir `../CLAUDE.md`)

- `TELEMETRY_TOKEN` (ingestion, `POST /events` seulement) n'est **pas** une
  vraie sécurité — juste un filtre anti-bruit. N'importe qui avec accès à
  castellana peut le lire dans le code source du navigateur. C'est
  irréductible : c'est castellana lui-même qui poste ici, aucun vrai login
  n'est possible à ce point d'entrée.
- `DASHBOARD_USER`/`DASHBOARD_PASSWORD` (consultation, `/dashboard` et
  `/events.csv`, 12/9/2026), eux, sont une vraie authentification — en
  secrets Wrangler, jamais commités.
- Aucune authentification des testeurs (T3, login, est explicitement
  reporté) — le champ « who » est une auto-déclaration, pas une identité
  vérifiée. L'IP capturée par le Worker est un complément, pas une preuve.
