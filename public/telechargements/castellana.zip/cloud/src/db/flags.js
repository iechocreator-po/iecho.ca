// Feature flags GLOBAUX (20/9/2026). Une clé absente de la table vaut son
// défaut — OFF pour tout ce qui est nouveau. KNOWN_FLAGS est la SEULE liste
// des clés valides : on ne peut pas créer un flag par une simple requête, et
// bilbao affiche ce que le Worker déclare (aucune liste dupliquée côté bilbao).

export const KNOWN_FLAGS = {
  concepts_tab: { label: 'Onglet « Concepts » (Réglages)', default: false },
  // 22/9/2026 — onglets « avancés » vente de puts (screener de primes,
  // cycles de la Roue, rendement annualisé…), togglables indépendamment
  // l'un de l'autre puisque Journal A dépend d'un nouveau schéma plus
  // récent/moins éprouvé qu'Options A.
  journal_a_tab: { label: 'Onglet « Screener Prime » (vente de primes)', default: false },
  // 26/9/2026 — carte « Fondamentaux » (EPS, FCF, qualité du FCF) sous la
  // section « Symbole ». ON par défaut : fonction terminée, demandée par JP ;
  // le flag sert à la couper globalement ou par compte depuis bilbao.
  fundamentals_card: { label: 'Carte « Fondamentaux » (EPS, FCF)', default: true },
  // 30/9/2026 — connexion au compte TradingView (OAuth) et choix de la source
  // de données. OFF par défaut : activé compte par compte depuis bilbao.
  tradingview_connect: { label: 'Connexion TradingView (OAuth, watchlists)', default: false },
  // 9/10/2026 — « AI Analyste » : analyse de contexte par Claude (#398). Branché en cloud le
  // 10/10/2026 (routes/ai.js, lib/ai-analyst.js) : le flag est LU côté serveur à chaque appel.
  // Nécessite le secret Wrangler ANTHROPIC_API_KEY (sans lui : 503 « pas encore configurée »).
  ai_analyst: { label: 'AI Analyste (analyse de contexte par Claude)', default: false },
  // 12/10/2026 — onglet « Anticipation » : maquettes des fonctionnalités à venir, votes et propositions
  // des utilisateurs invités (bilbao #418). OFF par défaut, activé compte par compte depuis bilbao.
  // Contrôlé côté serveur à chaque appel (routes/anticipation.js) : masquer l'onglet ne suffit pas.
  anticipation_tab: { label: 'Onglet « Anticipation » (maquettes, votes, propositions)', default: false },
  // 13/10/2026 — onglet « Roue » : journal de la Roue repris du Google Sheets du club (bilbao #434).
  // OFF par défaut, activé compte par compte depuis bilbao.
  roue_tab: { label: 'Onglet « Roue » (journal, positions, capital)', default: false },
  // 17/10/2026 — balayage S&P 500 calculé en local et publié ici : carte « Setups du S&P 500 par
  // secteur » (A3) et univers « S&P 500 » du Screener (B2), qui lisent le même instantané. OFF par
  // défaut, activé compte par compte depuis bilbao. Contrôlé côté serveur (routes/snapshots.js,
  // routes/screening.js) : masquer la carte ne suffit pas.
  sp500_sweep: { label: 'Balayage S&P 500 publié (A3 « Setups par secteur », univers S&P 500 de B2)', default: false },
};

// { concepts_tab: false, … } — toujours TOUTES les clés connues.
export async function getFlags(db) {
  const { results } = await db.prepare('SELECT key, enabled FROM feature_flags').all();
  const stored = new Map(results.map((r) => [r.key, r.enabled === 1]));
  const out = {};
  for (const [key, def] of Object.entries(KNOWN_FLAGS)) out[key] = stored.has(key) ? stored.get(key) : def.default;
  return out;
}

export async function listFlagsAdmin(db) {
  const { results } = await db.prepare('SELECT key, enabled, updated_at FROM feature_flags').all();
  const stored = new Map(results.map((r) => [r.key, r]));
  return Object.entries(KNOWN_FLAGS).map(([key, def]) => ({
    key,
    label: def.label,
    default: def.default,
    enabled: stored.has(key) ? stored.get(key).enabled === 1 : def.default,
    updatedAt: stored.get(key)?.updated_at ?? null,
  }));
}

export async function setFlag(db, key, enabled) {
  if (!(key in KNOWN_FLAGS)) {
    throw Object.assign(new Error(`Flag inconnu : ${key}`), { code: 'UNKNOWN_FLAG' });
  }
  if (typeof enabled !== 'boolean') {
    throw Object.assign(new Error('`enabled` doit être un booléen.'), { code: 'INVALID_FLAG' });
  }
  await db.prepare(`
    INSERT INTO feature_flags (key, enabled, updated_at) VALUES (?, ?, datetime('now'))
    ON CONFLICT(key) DO UPDATE SET enabled = excluded.enabled, updated_at = excluded.updated_at
  `).bind(key, enabled ? 1 : 0).run();
  return listFlagsAdmin(db);
}

// ---- Surcharges PAR UTILISATEUR (22/9/2026) --------------------------------
// Sous-ensemble de KNOWN_FLAGS qu'un administrateur peut forcer ON/OFF pour
// UN compte précis, indépendamment du réglage global — pour activer un
// onglet avancé chez un testeur sans l'imposer à tout le monde. Une clé qui
// n'est pas dans KNOWN_USER_FLAGS reste purement globale (ex. concepts_tab).
export const KNOWN_USER_FLAGS = {
  journal_a_tab: KNOWN_FLAGS.journal_a_tab,
  fundamentals_card: KNOWN_FLAGS.fundamentals_card,
  tradingview_connect: KNOWN_FLAGS.tradingview_connect,
  ai_analyst: KNOWN_FLAGS.ai_analyst,
  anticipation_tab: KNOWN_FLAGS.anticipation_tab,
  roue_tab: KNOWN_FLAGS.roue_tab,
  sp500_sweep: KNOWN_FLAGS.sp500_sweep,
};

// { options_a_tab: true, … } — UNIQUEMENT les clés réellement surchargées
// pour cet utilisateur (pas toutes les clés connues, contrairement à
// getFlags : l'absence signifie « hérite du global », pas « false »).
export async function getUserFlagOverrides(db, userId) {
  const { results } = await db.prepare('SELECT key, enabled FROM user_feature_flags WHERE user_id = ?').bind(userId).all();
  const out = {};
  for (const r of results) if (r.key in KNOWN_USER_FLAGS) out[r.key] = r.enabled === 1;
  return out;
}

// Flags EFFECTIFS pour la session d'un utilisateur — global ⊕ ses
// surcharges. C'est ce que /api/flags doit renvoyer, jamais getFlags() seul.
export async function getEffectiveFlagsForUser(db, userId) {
  const [global, overrides] = await Promise.all([getFlags(db), getUserFlagOverrides(db, userId)]);
  return { ...global, ...overrides };
}

// Vue d'administration (bilbao, onglet Comptes castellana) : les
// surcharges de TOUS les comptes, groupées par utilisateur — pour afficher
// à côté de chaque ligne du tableau des comptes, sans révéler autre chose
// (aucune donnée personnelle au-delà de l'id déjà connu de bilbao).
export async function listAllUsersFlagOverrides(db) {
  const { results } = await db.prepare('SELECT user_id, key, enabled FROM user_feature_flags').all();
  const byUser = {};
  for (const r of results) {
    if (!(r.key in KNOWN_USER_FLAGS)) continue;
    (byUser[r.user_id] ??= {})[r.key] = r.enabled === 1;
  }
  return byUser;
}

// `enabled` : true|false pour forcer, `null` pour réinitialiser (retirer la
// surcharge — le compte revient au réglage global). Jamais un enregistrement
// « hérite » explicite : l'absence de ligne EST l'héritage.
export async function setUserFlag(db, userId, key, enabled) {
  if (!(key in KNOWN_USER_FLAGS)) {
    throw Object.assign(new Error(`Flag utilisateur inconnu : ${key}`), { code: 'UNKNOWN_FLAG' });
  }
  if (enabled === null) {
    await db.prepare('DELETE FROM user_feature_flags WHERE user_id = ? AND key = ?').bind(userId, key).run();
  } else {
    if (typeof enabled !== 'boolean') {
      throw Object.assign(new Error('`enabled` doit être un booléen ou null (réinitialiser).'), { code: 'INVALID_FLAG' });
    }
    await db.prepare(`
      INSERT INTO user_feature_flags (user_id, key, enabled, updated_at) VALUES (?, ?, ?, datetime('now'))
      ON CONFLICT(user_id, key) DO UPDATE SET enabled = excluded.enabled, updated_at = excluded.updated_at
    `).bind(userId, key, enabled ? 1 : 0).run();
  }
  return listAllUsersFlagOverrides(db);
}
