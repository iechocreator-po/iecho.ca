// js/telemetry.js — télémétrie testeurs castellana (6/9/2026)
//
// Contexte : castellana tourne en local chez chaque testeur (pas
// d'hébergement partagé), donc ce module envoie les événements DIRECTEMENT
// du navigateur vers un petit Cloudflare Worker externe
// (../telemetry-worker/), pas vers server/index.js. Voir CLAUDE.md,
// section "Télémétrie testeurs", et telemetry-worker/README.md pour le
// détail complet et le déploiement.
//
// Discipline centrale : la télémétrie ne doit JAMAIS bloquer, ralentir ou
// faire planter l'app si elle échoue (Worker non déployé, réseau coupé,
// jeton mal configuré) — tout est fire-and-forget, silencieux sauf en
// console (console.warn), jamais une erreur visible pour le testeur.
//
// Ce module capture 4 événements, et rien d'autre : app_loaded (quand +
// qui + version installée), ticker_selected (quel ticker, quel onglet),
// param_changed (quel paramètre, ancienne/nouvelle valeur), et error
// (7/9/2026 — quel appel a échoué, sur quelle route). Pas un système
// d'analytics générique — voir CLAUDE.md pour la liste exhaustive.
//
// Ce qui n'est JAMAIS envoyé, et ne doit jamais l'être : aucune donnée de
// marché, aucun trade du journal, aucun montant, aucune position. La
// télémétrie répond à « est-ce que l'outil marche chez eux », pas à « que
// tradent-ils ».

const TELEMETRY_WHO_KEY = 'castellana-who';

function telemetryReady() {
  return Boolean(CFG.telemetry && CFG.telemetry.enabled && CFG.telemetry.endpoint);
}

function getWho() {
  try {
    return localStorage.getItem(TELEMETRY_WHO_KEY) || 'inconnu';
  } catch {
    return 'inconnu';
  }
}

function setWho(value) {
  try {
    localStorage.setItem(TELEMETRY_WHO_KEY, value);
  } catch { /* localStorage indisponible (navigation privée, etc.) — tant pis, pas bloquant */ }
}

// Fire-and-forget : jamais d'attente, jamais de blocage UI. `fetchJSON` est
// réutilisé (index.html) pour la cohérence avec le reste de l'app, mais on
// n'attend jamais sa résolution avant de continuer.
function sendTelemetryEvent(eventType, payload) {
  if (!telemetryReady()) return;
  const event = {
    who: getWho(),
    event_type: eventType,
    payload: payload || {},
    ua: navigator.userAgent,
  };
  fetchJSON(CFG.telemetry.endpoint + '/events', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Telemetry-Token': CFG.telemetry.sharedToken },
    body: JSON.stringify(event),
  }).catch((err) => {
    console.warn('[télémétrie] envoi échoué (non bloquant) :', err.message);
  });
}

// Erreurs rencontrées par un testeur (7/9/2026, constat F2 de l'audit :
// « pour un testeur non technique, une panne est indiscernable d'un bug »).
// Sans ça, JP n'apprenait l'existence d'un problème que si le testeur
// pensait à le lui écrire.
//
// N'envoie QUE le contexte technique : la route appelée et le message
// d'erreur — jamais le contenu de la réponse, jamais une valeur de marché.
// Dédoublonné par (route + message) pour qu'une page qui échoue en boucle
// n'inonde pas la base.
const seenErrors = new Set();

function trackError(route, message, extra) {
  const signature = `${route}::${message}`;
  if (seenErrors.has(signature)) return;
  seenErrors.add(signature);
  sendTelemetryEvent('error', {
    route,
    message: String(message || '').slice(0, 300),
    version: (window.CASTELLANA_VERSION || null),
    ...(extra || {}),
  });
}

// Dédoublonnage par onglet — évite de spammer un événement identique quand
// plusieurs chemins internes convergent vers le même ticker déjà signalé
// (ex. fetchLiveSelectionFor peut être appelé plusieurs fois de suite pour
// la même valeur).
const lastTickerByTab = {};

function trackTickerSelected(tab, ticker, instance) {
  if (!ticker) return;
  const key = tab + (instance ? ':' + instance : '');
  if (lastTickerByTab[key] === ticker) return;
  lastTickerByTab[key] = ticker;
  sendTelemetryEvent('ticker_selected', { tab, ticker, instance: instance || null });
}

// Les 9 champs réellement modifiables par l'utilisateur à l'exécution (le
// reste de config.js ne pilote que des libellés/valeurs par défaut, jamais
// éditées à runtime — voir CLAUDE.md pour l'inventaire complet). Écoute sur
// `change` (pas `input`) pour ne pas spammer à chaque pixel de glissement
// d'un slider ou chaque frappe clavier.
const TRACKED_PARAMS = [
  { id: 'atrmult', label: 'Multiplicateur ATR (sizing)', tab: 'fiche' },
  { id: 'riskpct', label: 'Risque de base % (sizing)', tab: 'fiche' },
  { id: 'capital', label: 'Capital', tab: 'fiche' },
  { id: 'filter-prix-min', label: 'Filtre Prix — min', tab: 'screener' },
  { id: 'filter-prix-max', label: 'Filtre Prix — max', tab: 'screener' },
  { id: 'filter-float-min', label: 'Filtre Float — min', tab: 'screener' },
  { id: 'filter-float-max', label: 'Filtre Float — max', tab: 'screener' },
  { id: 'labo-sma-fast', label: 'Labo — SMA rapide', tab: 'labo' },
  { id: 'labo-sma-medium', label: 'Labo — SMA moyenne', tab: 'labo' },
  { id: 'labo-sma-slow', label: 'Labo — SMA lente', tab: 'labo' },
];

function initParamTelemetry() {
  const lastValue = {};
  TRACKED_PARAMS.forEach(({ id, label, tab }) => {
    const el = document.getElementById(id);
    if (!el) return; // champ absent selon l'état de l'app — jamais bloquant
    lastValue[id] = el.value;
    el.addEventListener('change', () => {
      const oldValue = lastValue[id];
      const newValue = el.value;
      lastValue[id] = newValue;
      if (oldValue === newValue) return;
      sendTelemetryEvent('param_changed', { param: label, tab, oldValue, newValue });
    });
  });
}

function initIdentityPicker() {
  const container = document.getElementById('who-picker');
  if (!container) return;
  const options = (CFG.telemetry && CFG.telemetry.testeurs) || [];
  const current = getWho();
  const optionsHtml = ['<option value="inconnu">Qui êtes-vous ?</option>']
    .concat(options.map((name) => `<option value="${name}"${name === current ? ' selected' : ''}>${name}</option>`))
    .join('');
  container.innerHTML = `<select class="ds-select" id="who-select" title="Identification pour la télémétrie (pas un login)" style="font-size:12px; padding:2px 6px;">${optionsHtml}</select>`;
  document.getElementById('who-select').addEventListener('change', (e) => setWho(e.target.value));
}

// Point d'entrée unique — appelé depuis index.html, APRÈS
// renderTickerSectionInto()/applyConfig()/initScreenFilterRanges() pour que
// tous les champs suivis existent déjà dans le DOM.
function initTelemetry() {
  initIdentityPicker();
  initParamTelemetry();
  sendTelemetryEvent('app_loaded', {});
}
