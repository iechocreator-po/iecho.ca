// js/labo-real-chain.js — Option Lab sur la VRAIE chaîne d'options (feature #396, 8/10/2026).
//
// Jusqu'ici, les strikes du Labo étaient des ESTIMATIONS Black-Scholes (volatilité historique).
// Ce module va chercher la vraie chaîne (même source que l'onglet Options : Yahoo, différée ~15 min)
// et montre, pour chaque jambe d'une stratégie, les contrats réels dont le delta tombe dans la plage :
// bid, ask, IV, open interest — et, pour un Credit Spread, le crédit RÉEL (bid de la jambe vendue −
// ask de la jambe achetée) comparé à la règle du crédit minimal. L'estimation Black-Scholes reste
// affichée au-dessus, étiquetée comme telle ; ceci la vérifie, ne la remplace pas.
//
// Fonctions PURES en tête de fichier (testées : server/labo-real-chain.test.js) ; rendu DOM ensuite.
// Contrainte honnête : données différées, bid = 0 hors séance, cotes périmées sur les contrats peu
// liquides — d'où le filtre de qualité (laboQualityFlags), jamais un contrat douteux présenté comme bon.

const LABO_Q = { maxSpreadPct: 0.25, minOpenInterest: 50, maxIv: 3 };

// Raisons pour lesquelles une cote n'est pas fiable. Tableau vide = cote exploitable.
function laboQualityFlags(c) {
  const f = [];
  if (!(c.bid > 0)) f.push('pas de bid');
  if (!(c.ask > 0)) f.push('pas d\'ask');
  if (c.bid > 0 && c.ask > 0) {
    const spread = (c.ask - c.bid) / ((c.ask + c.bid) / 2);
    if (spread > LABO_Q.maxSpreadPct) f.push(`écart bid-ask ${Math.round(spread * 100)} %`);
  }
  if (!(c.openInterest >= LABO_Q.minOpenInterest)) f.push('open interest faible');
  if (c.iv > LABO_Q.maxIv) f.push('IV aberrante (> 300 %)');
  return f;
}

// Échéance disponible la plus proche d'une cible en jours (≥ 1 jour), ou null.
function laboPickExpiry(expirations, targetDays) {
  let best = null;
  for (const e of expirations || []) {
    if (!(e.dte >= 1)) continue;
    if (best === null || Math.abs(e.dte - targetDays) < Math.abs(best.dte - targetDays)) best = e;
  }
  return best;
}

// Contrats dont |delta| est dans [deltaMin, deltaMax], classés par proximité au milieu de la plage.
// `chosen` = le premier de qualité acceptable (null si aucun : on ne retient pas un contrat douteux).
function laboPickContract(contracts, deltaMin, deltaMax) {
  const mid = (deltaMin + deltaMax) / 2;
  const inRange = (contracts || [])
    .filter((c) => c.delta != null && Math.abs(c.delta) >= deltaMin && Math.abs(c.delta) <= deltaMax)
    .map((c) => ({ ...c, flags: laboQualityFlags(c) }))
    .sort((a, b) => Math.abs(Math.abs(a.delta) - mid) - Math.abs(Math.abs(b.delta) - mid));
  return { candidates: inRange.slice(0, 4), chosen: inRange.find((c) => c.flags.length === 0) || null, total: inRange.length };
}

// Jambe de protection d'un spread : strike listé le plus proche, AU-DELÀ de (strike vendu ∓ largeur),
// avec un ask exploitable. Put : strike ≤ vendu − largeur ; Call : strike ≥ vendu + largeur.
function laboLongLeg(contracts, type, shortStrike, width) {
  const ok = (contracts || []).filter((c) => c.ask > 0);
  if (type === 'put') {
    const cand = ok.filter((c) => c.strike <= shortStrike - width);
    return cand.length ? cand.reduce((a, b) => (b.strike > a.strike ? b : a)) : null;
  }
  const cand = ok.filter((c) => c.strike >= shortStrike + width);
  return cand.length ? cand.reduce((a, b) => (b.strike < a.strike ? b : a)) : null;
}

// Crédit RÉEL d'un spread vendu : on encaisse le bid de la jambe vendue, on paie l'ask de l'achetée.
function laboSpreadCredit(shortLeg, longLeg) {
  const width = Math.abs(shortLeg.strike - longLeg.strike);
  const credit = shortLeg.bid - longLeg.ask;
  return { width, credit, creditPct: width > 0 ? credit / width : null, maxLoss: width - credit };
}

// Contrat dont le strike est le plus proche du prix (jambe achetée « proche du prix »).
function laboAtmContract(contracts, price) {
  const ok = (contracts || []).filter((c) => c.ask > 0);
  return ok.length ? ok.reduce((a, b) => (Math.abs(b.strike - price) < Math.abs(a.strike - price) ? b : a)) : null;
}

// Jambes à vérifier dans la vraie chaîne, par stratégie (paramètres EFFECTIFS `p`).
function laboRealPlan(stratId, p) {
  const mid = (a, b) => Math.round((a + b) / 2);
  const sellPut = { key: 'put', role: 'Put vendu', type: 'put', action: 'sell', dte: mid(p.putDteMin, p.putDteMax), deltaMin: p.putDeltaMin, deltaMax: p.putDeltaMax };
  const sellCall = { key: 'call', role: 'Call vendu', type: 'call', action: 'sell', dte: mid(p.callDteMin, p.callDteMax), deltaMin: p.callDeltaMin, deltaMax: p.callDeltaMax };
  switch (stratId) {
    case 'roue': return [sellPut, sellCall];
    case 'debit-spreads':
      return [
        { ...sellCall, role: 'Call vendu (Bull Call Spread)', buyAtm: true },
        { ...sellPut, role: 'Put vendu (Bear Put Spread)', buyAtm: true },
      ];
    case 'pmcc':
      return [
        { key: 'leaps', role: 'LEAPS Call acheté', type: 'call', action: 'buy', dte: p.leapsDteTypiqueJours, deltaMin: p.leapsDeltaMin, deltaMax: p.leapsDeltaMax },
        sellCall,
      ];
    case 'credit-spreads':
      return [
        { ...sellPut, role: 'Put vendu (Bull Put Spread)', spread: true },
        { ...sellCall, role: 'Call vendu (Bear Call Spread)', spread: true },
      ];
    default: return [];
  }
}

// ---------------------------------------------------------------------------------------------
// Rendu (DOM + réseau)
// ---------------------------------------------------------------------------------------------

const laboChainCache = new Map(); // `${ticker}|${expiry||''}` → { at, ch }
const LABO_CHAIN_TTL_MS = 5 * 60 * 1000;
let laboRealSeq = 0;

async function laboFetchChain(ticker, expiry) {
  const key = `${ticker}|${expiry || ''}`;
  const hit = laboChainCache.get(key);
  if (hit && Date.now() - hit.at < LABO_CHAIN_TTL_MS) return hit.ch;
  const qs = expiry ? `?expiry=${encodeURIComponent(expiry)}` : '';
  const ch = await fetchJSON(`/api/options/${encodeURIComponent(ticker)}${qs}`);
  optionsAttachDeltas(ch); // delta de chaque contrat, avec SON IV
  laboChainCache.set(key, { at: Date.now(), ch });
  return ch;
}

function laboRealRow(c, selected) {
  const mid = c.bid > 0 && c.ask > 0 ? (c.ask - c.bid) / ((c.ask + c.bid) / 2) : null;
  const q = c.flags && c.flags.length ? `<span class="ds-badge ds-badge--warning" title="${optEsc(c.flags.join(' · '))}">⚠ ${optEsc(c.flags[0])}${c.flags.length > 1 ? ` +${c.flags.length - 1}` : ''}</span>` : '<span class="ds-badge ds-badge--success">cote exploitable</span>';
  return `<tr${selected ? ' style="background:var(--surface-2); font-weight:600;"' : ''}>
    <td>${selected ? '✓ ' : ''}${optNum(c.strike, 2)}</td><td class="is-num">${optDelta(c.delta)}</td>
    <td class="is-num">${optNum(c.bid)}</td><td class="is-num">${optNum(c.ask)}</td>
    <td class="is-num">${mid == null ? '—' : Math.round(mid * 100) + ' %'}</td>
    <td class="is-num">${optInt(c.openInterest)}</td><td class="is-num">${c.iv == null ? '—' : Math.round(c.iv * 100) + ' %'}</td><td>${q}</td></tr>`;
}

function laboRealTable(rows, chosenStrike) {
  return `<div class="screen-table-wrap"><table class="ds-table"><thead><tr><th>Strike</th><th class="is-num">Delta</th><th class="is-num">Bid</th><th class="is-num">Ask</th><th class="is-num">Écart</th><th class="is-num">OI</th><th class="is-num">IV</th><th>Qualité</th></tr></thead><tbody>${rows.map((c) => laboRealRow(c, c.strike === chosenStrike)).join('')}</tbody></table></div>`;
}

async function laboRenderRealChain(stratId, params, ticker) {
  const host = document.getElementById('labo-real');
  if (!host) return;
  const seq = ++laboRealSeq;
  const legs = laboRealPlan(stratId, params);
  if (!legs.length) { host.innerHTML = ''; return; }
  if (typeof laboTickerData === 'undefined' || !laboTickerData || laboTickerData.ticker !== ticker) {
    host.innerHTML = '<div class="ds-card" style="margin-top:0.85rem;"><div class="section-title">Vraie chaîne d\'options</div><p class="metric-sub" style="text-align:left;">Charge le symbole (bouton « Charger ») pour comparer les strikes estimés à la vraie chaîne.</p></div>';
    return;
  }
  host.innerHTML = '<div class="ds-card" style="margin-top:0.85rem;"><div class="section-title">Vraie chaîne d\'options</div><p class="metric-sub" style="text-align:left;">Chargement de la chaîne réelle…</p></div>';
  try {
    const first = await laboFetchChain(ticker, null);
    let html = '';
    for (const leg of legs) {
      const exp = laboPickExpiry(first.expirations, leg.dte);
      if (!exp) { html += `<h4>${optEsc(leg.role)}</h4><p class="metric-sub">Aucune échéance exploitable.</p>`; continue; }
      const ch = exp.date === first.expiry ? first : await laboFetchChain(ticker, exp.date);
      const list = leg.type === 'put' ? ch.puts : ch.calls;
      const pick = laboPickContract(list, leg.deltaMin, leg.deltaMax);
      html += `<h4 style="margin:0.8rem 0 0.2rem;">${optEsc(leg.role)} — échéance ${optEsc(ch.expiry)} (${ch.dte} j ; cible ${leg.dte} j) · delta ${leg.deltaMin}–${leg.deltaMax}</h4>`;
      if (!pick.total) {
        html += '<p class="metric-sub" style="text-align:left;">Aucun contrat réel dans cette plage de delta à cette échéance — élargis la plage ou change l\'échéance.</p>';
        continue;
      }
      html += laboRealTable(pick.candidates, pick.chosen && pick.chosen.strike);
      if (!pick.chosen) html += '<p class="metric-sub" style="text-align:left;">⚠ Aucun de ces contrats n\'a une cote exploitable (voir « Qualité ») : n\'en retiens aucun sans vérifier chez ton courtier.</p>';
      if (leg.buyAtm) {
        const atm = laboAtmContract(leg.type === 'put' ? ch.puts : ch.calls, ch.price);
        html += atm
          ? `<p class="metric-sub" style="text-align:left;">Jambe achetée « proche du prix » : strike ${optNum(atm.strike, 2)}, ask ${optNum(atm.ask)} (prix du titre ${optNum(ch.price, 2)}).</p>`
          : '<p class="metric-sub" style="text-align:left;">Aucun contrat acheteur exploitable proche du prix.</p>';
      }
      if (leg.spread && pick.chosen) {
        const width = ch.price * (params.spreadWidthPct / 100);
        const long = laboLongLeg(list, leg.type, pick.chosen.strike, width);
        if (!long) { html += '<p class="metric-sub" style="text-align:left;">Aucune jambe de protection listée à la largeur demandée.</p>'; }
        else {
          const lf = laboQualityFlags(long);
          const s = laboSpreadCredit(pick.chosen, long);
          const ok = s.creditPct != null && s.creditPct * 100 >= params.creditMinPct;
          html += `<div class="banner ${ok ? 'ready' : 'watch'}" style="margin-top:0.4rem;">`
            + `Jambe achetée réelle : strike ${optNum(long.strike, 2)}, ask ${optNum(long.ask)}${lf.length ? ` (⚠ ${optEsc(lf.join(' · '))})` : ''}. `
            + `Crédit réel = ${optNum(pick.chosen.bid)} − ${optNum(long.ask)} = <strong>${optNum(s.credit)} $</strong> par action pour une largeur de ${optNum(s.width, 2)} $ `
            + `(${s.creditPct == null ? '—' : Math.round(s.creditPct * 100)} % de la largeur ; règle : au moins ${params.creditMinPct} %) — `
            + `${ok ? '✓ la règle est respectée' : '✗ la règle n\'est pas respectée'}. Perte maximale ≈ ${optNum(s.maxLoss)} $ par action (${optNum(s.maxLoss * 100, 0)} $ par contrat).`
            + '</div>';
        }
      }
    }
    if (seq !== laboRealSeq) return; // un rendu plus récent a pris le relais
    host.innerHTML = `<div class="ds-card" style="margin-top:0.85rem;"><div class="section-title">Vraie chaîne d'options — ${optEsc(ticker)}</div>
      <p class="metric-sub" style="text-align:left;">Contrats RÉELS (Yahoo, différés ~15 min) dont le delta — calculé avec l'IV de chaque contrat — tombe dans la plage de la stratégie. Vérifie l'estimation Black-Scholes ci-dessus ; « cote exploitable » = bid et ask présents, écart ≤ 25 %, open interest ≥ 50, IV plausible. Hors séance, un bid à 0 est normal.</p>${html}</div>`;
  } catch (err) {
    if (seq !== laboRealSeq) return;
    host.innerHTML = `<div class="ds-card" style="margin-top:0.85rem;"><div class="section-title">Vraie chaîne d'options</div><div class="banner notready">Chaîne indisponible : ${optEsc(err.message)}. L'estimation Black-Scholes ci-dessus reste valable comme repère.</div></div>`;
  }
}
