// IA étape 1 (#398) — routes de l'analyse de contexte, cloud. Réservées aux comptes pour lesquels
// le flag ai_analyst est ACTIF (global ⊕ surcharge du compte, réglée dans bilbao : colonne
// « AI Analyste »). Le contrôle est fait ici, côté serveur : cacher la carte dans le navigateur
// ne suffirait pas à protéger la clé API.
import { getEffectiveFlagsForUser } from '../db/flags.js';
import { analyseTicker, getLastAnalysis } from '../lib/ai-analyst.js';

export function registerAiRoutes(app) {
  app.use('/api/ai/*', async (c, next) => {
    const flags = await getEffectiveFlagsForUser(c.env.DB, c.get('userId'));
    if (flags.ai_analyst !== true) return c.json({ error: "L'analyse IA n'est pas activée pour ce compte.", code: 'FLAG_OFF' }, 403);
    return next();
  });

  app.get('/api/ai/analyse/:ticker', async (c) => {
    const ticker = c.req.param('ticker').toUpperCase();
    return c.json((await getLastAnalysis(c.env.DB, c.get('userId'), ticker)) || { analysis: null });
  });

  app.post('/api/ai/analyse/:ticker', async (c) => {
    let body = {};
    try { body = await c.req.json(); } catch { /* corps vide accepté */ }
    try {
      return c.json(await analyseTicker(c.env.DB, c.get('userId'), c.env, c.req.param('ticker'), { plan: body?.plan, force: body?.force === true }));
    } catch (err) {
      const status = { NO_KEY: 503, BUDGET: 429, BAD_INPUT: 400, NO_DATA: 502, API_ERROR: 502, BAD_RESPONSE: 502 }[err.code] || 500;
      return c.json({ error: err.message, code: err.code || 'ERROR' }, status);
    }
  });
}
