import { searchSymbols } from './symbol-search.js';
import { listCashFlows, createCashFlow, deleteCashFlow } from './cash-flows.js';
import { getOptionChain, getAnnualizedGrid } from './options.js';
import { screenPremiums } from './premium-screener.js';
import { getRollAlerts } from './option-alerts.js';
import {
  createCycle, listCycles, getCycle, updateCycle,
  createOptionTrade, listOptionTrades, getOptionTrade, deleteOptionTrade, closeOptionTrade, deleteRoueEntries,
} from './option-trades.js';
import { isScanRunning, createScan, runDealScan, getScan, listScans, getResults, premiumRowsFromScan, SCAN_WINDOWS } from './deal-scanner.js';
import express from 'express';
import { getStatus as tvLocalStatus, beginConnect as tvBeginConnect, completeConnect as tvCompleteConnect, disconnect as tvDisconnect, getDataSource as tvGetSource, setDataSource as tvSetSource, DATA_SOURCES as TV_SOURCES } from './tv-local.js';
import { startSweep, cancelSweep, sweepStatus, sweepNews, lastSweepInfo, startSweepScheduler } from './sweep.js';
import { readFileSync, writeFileSync, rmSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { db } from './db.js';
import { getTechnicalAnalysis, checkSidecarConnection, isSidecarEnabled } from './tradingview.js';
import { getHomemadeIndicators, getHomemadeIndicatorsBatch, checkYahooConnection, fetchDailyHistory, buildCorrelationReport } from './indicators.js';
import { getQuotes, getRelativeStrength, BENCHMARK_SYMBOL } from './quotes.js';
import { seedWatchlistIfEmpty, getWatchlist, addToWatchlist, removeFromWatchlist } from './watchlist.js';
import { getLists, getListById, createList, renameList, deleteList, addTickerToList, removeTickerFromList } from './lists.js';
import { createTrade, listTrades, getTrade, updateTrade, deleteTrade, validateTrade, COLUMNS as TRADE_COLUMNS } from './trades.js';
import { getFundamentals, getFundamentalsBatch } from './fundamentals.js';
import { getFcfQuality } from './fcf-quality.js';
import { getSectorPerformance, getSectorHistory, SECTOR_TOP_FILTERS, SECTOR_ETF_TO_YAHOO_SECTOR, SECTOR_MODES, SECTOR_DEFS } from './sectors.js';
import { computeStats } from './stats.js';
import { listRules, createRule, setRuleEnabled, deleteRule, listEvents, markEventsRead, runListAlerts, isAlertRunActive, startListAlertsScheduler } from './list-alerts.js';
import { ALERT_TYPES } from './list-alerts-logic.js';
import { emailAvailable, emailConfig, sendAlertEmail, setResendKey, resendKeySource } from './alert-email.js';
import { runBacktest } from './backtest.js';
import { ivRankForTicker } from './iv-rank.js';
import { getCycleBilans } from './cycle-bilan.js';
import { runPositionAlerts, listPositionEvents, markPositionEventsRead, resetPositionAlertState } from './position-alerts.js';
import { getEffectiveParams } from './labo-params.js';
import { getAppSettings, setAppSettings, getAlertEmails, getPositionAlertSettings, kindsReenabled } from './app-settings.js';
import { analyseTicker, getLastAnalysis, getAiSettings, setAiSettings, listOllamaModels } from './ai-analyst.js';
import { startDailyScanScheduler } from './daily-scan.js';
import { readCache, readCacheRaw, writeCache, purgeExpiredCache, TTL } from './cache.js';
import { getLocalVersion, checkForUpdate, applyUpdate } from './update.js';
import { getAllOverrides as getLaboOverrides, setStrategyParams, resetStrategyParams, resetAllStrategyParams, schema as laboSchema } from './labo-params.js';
import { getPreferences, setPreferences, resetPreferences, indicatorOptions, DEFAULTS as PREF_DEFAULTS, getFundamentalWeights, setFundamentalWeights, resetFundamentalWeights, WEIGHT_DEFAULTS } from './preferences.js';
import { buildScreening, buildTickersScreening, buildSectorScreening, screeningCacheKey, SCREENING_KEY, SCREEN_FILTERS, isValidUniverse, getScreeningPerformance, parseTickersParam, SP500 } from './screening.js';
import { sectorBreakdown } from './sweep-sectors.js';
import { publishStatus, publishSweepSnapshot } from './snapshot-publish.js';
import { hostGuard, originGuard, publicFiles } from './http-guard.js';

// Sème la watchlist en base au premier démarrage (idempotent, no-op ensuite).
seedWatchlistIfEmpty();

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const settings = JSON.parse(readFileSync(new URL('../settings.json', import.meta.url)));

const app = express();
// Garde HTTP (audit parite-routes, 20/10/2026) : hôte vérifié AVANT tout, et seuls les fichiers dont la page a besoin
// sont servis (liste explicite dans server/http-guard.js) — plus la racine entière du projet, base de données comprise.
app.use(hostGuard([settings.host]));
app.use(originGuard([settings.host]));
app.use(express.json());
app.use(publicFiles(ROOT));

app.get('/api/health', (req, res) => {
  const { count } = db.prepare('SELECT COUNT(*) AS count FROM trades').get();
  res.json({ status: 'ok', trades: count });
});

// Statut agrégé pour le témoin visuel du frontend (header de index.html).
// `tradingviewMcp` utilise checkSidecarConnection() (listTools(), pas
// d'appel outil) — ne consomme jamais le quota du scanner rate-limité.
// `homemade` teste juste la joignabilité de Yahoo Finance (cotation SPY,
// légère) — les calculs maison (ATR/volume/OBV/SMA) en dépendent tous.
// Chaque check remonte un `*Detail` explicite (30/8/2026, demande de JP) —
// jamais juste un booléen qui masque la vraie cause (sidecar non démarré,
// rate-limit, DB verrouillée…).
// Réglages utilisateur (feature 351, point 4) — périodes des moyennes
// mobiles et du RSI, éditables depuis Réglages → Valeur personnalisée.
// Ils PILOTENT RÉELLEMENT LE CALCUL (screening, fiche de trade, Labo), ce
// qui n'était pas le cas de leurs équivalents dans config.js : ceux-ci ne
// changeaient longtemps que les libellés affichés.
// Pondération du score fondamental (2/10/2026) — voir server/preferences.js.
app.get('/api/app-settings', (req, res) => res.json({ ...getAppSettings(), emailAvailable: emailAvailable(), resendKeySource: resendKeySource(), emailFrom: emailConfig().from, publish: publishStatus(), profitTakeMin: (getEffectiveParams('roue') || {}).profitTakeMin ?? 50 }));
// Envoi manuel du dernier balayage vers la version en ligne (17/10/2026), indépendant de la case.
app.post('/api/snapshot/publish', async (req, res) => res.json(await publishSweepSnapshot({ trigger: 'manuel' })));
app.put('/api/app-settings', (req, res) => {
  try {
    const avant = getPositionAlertSettings();
    const apres = setAppSettings(req.body || {});
    resetPositionAlertState(kindsReenabled(avant, apres.positionAlerts));
    res.json({ ...apres, emailAvailable: emailAvailable(), resendKeySource: resendKeySource(), emailFrom: emailConfig().from }); }
  catch (err) { res.status(400).json({ error: err.message }); }
});
// Clé Resend (R-C2) : écriture seule, jamais relue par le navigateur. { key: null } la retire.
app.put('/api/app-settings/resend-key', (req, res) => {
  // Le champ `key` est obligatoire (null = retirer la clé) : un PUT sans corps supprimait RESEND_API_KEY du .env.
  if (!req.body || !('key' in req.body)) { res.status(400).json({ error: 'Le champ « key » est requis (null pour retirer la clé).' }); return; }
  try { res.json(setResendKey(req.body.key)); }
  catch (err) { res.status(400).json({ error: err.message }); }
});
// Courriel de test vers les adresses ENREGISTRÉES (pas celles en cours de saisie).
app.post('/api/app-settings/test-email', async (req, res) => {
  const to = getAlertEmails();
  if (!emailAvailable()) return res.status(400).json({ error: 'Clé Resend absente : enregistre-la d\'abord.' });
  if (!to.length) return res.status(400).json({ error: 'Aucune adresse enregistrée.' });
  const sent = [], errors = [];
  for (const a of to) {
    try {
      await sendAlertEmail(a, { subject: 'castellana — courriel de test', text: `Ceci est un courriel de test envoyé depuis Réglages → TradingView de castellana (local), le ${new Date().toLocaleString('fr-CA')}.\n\nSi tu le reçois, les alertes de positions et le résumé du balayage planifié arriveront à cette adresse.` });
      sent.push(a);
    } catch (err) { errors.push(`${a} : ${err.message}`); }
  }
  res.json({ sent, errors }); // toujours 200 : l'écran affiche le motif exact de chaque échec
});
// IA étape 1 (#398) : analyse de contexte, locale seulement. Déclarées avant toute route de même forme.
// Flag ai_analyst (OFF par défaut) : sans lui, ces routes n'existent pas (403). Lu au démarrage.
app.use('/api/ai', (req, res, next) => {
  if ((settings.featureFlags || {}).aiAnalyst !== true) return res.status(403).json({ error: "L'analyse IA est désactivée (flag ai_analyst).", code: 'FLAG_OFF' });
  next();
});
app.get('/api/ai/ollama-models', async (req, res) => res.json(await listOllamaModels()));
app.get('/api/ai/settings', (req, res) => res.json(getAiSettings()));
app.put('/api/ai/settings', (req, res) => {
  try { res.json(setAiSettings(req.body || {})); } catch (err) { res.status(400).json({ error: err.message }); }
});
app.get('/api/ai/analyse/:ticker', (req, res) => {
  res.json(getLastAnalysis(req.params.ticker.toUpperCase()) || { analysis: null });
});
app.post('/api/ai/analyse/:ticker', async (req, res) => {
  try {
    res.json(await analyseTicker(req.params.ticker, { plan: req.body?.plan, force: req.body?.force === true }));
  } catch (err) {
    const status = { NO_KEY: 503, BUDGET: 429, BAD_INPUT: 400, NO_MODEL: 400, NO_DATA: 502, API_ERROR: 502, BAD_RESPONSE: 502 }[err.code] || 500;
    res.status(status).json({ error: err.message, code: err.code || 'ERROR' });
  }
});
app.get('/api/fundamental-weights', (req, res) => {
  res.json({ weights: getFundamentalWeights(), defaults: WEIGHT_DEFAULTS });
});
app.put('/api/fundamental-weights', (req, res) => {
  try {
    res.json({ weights: setFundamentalWeights(req.body || {}), defaults: WEIGHT_DEFAULTS });
  } catch (err) {
    res.status(err.code === 'INVALID_PREFERENCES' ? 400 : 500).json({ error: err.message });
  }
});
app.post('/api/fundamental-weights/reset', (req, res) => {
  res.json({ weights: resetFundamentalWeights(), defaults: WEIGHT_DEFAULTS });
});

app.get('/api/preferences', (req, res) => {
  res.json({ preferences: getPreferences(), defaults: PREF_DEFAULTS });
});

// Les périodes d'indicateurs changent TOUS les screenings en cache (watchlist, élargi, MAG7, listes), pas seulement celui de la watchlist
// (audit routes locales, 21/10/2026). Le balayage S&P 500 est une lecture du dernier balayage enregistré, pas un calcul de ces réglages.
function bustAllScreeningCaches() {
  db.prepare("DELETE FROM cache WHERE key LIKE 'screening:last%' AND key != 'screening:last:sp500'").run();
}
app.put('/api/preferences', (req, res) => {
  try {
    const preferences = setPreferences(req.body || {});
    // Le screening en cache a été calculé avec les ANCIENNES périodes : le
    // garder afficherait des RSI et des alignements qui ne correspondent
    // plus aux réglages affichés. On le jette, il se recalculera.
    bustAllScreeningCaches();
    res.json({ preferences, defaults: PREF_DEFAULTS });
  } catch (err) {
    const status = err.code === 'INVALID_PREFERENCES' ? 400 : 500;
    res.status(status).json({ error: err.message });
  }
});

app.post('/api/preferences/reset', (req, res) => {
  const preferences = resetPreferences();
  bustAllScreeningCaches();
  res.json({ preferences, defaults: PREF_DEFAULTS });
});

// Feature flags (20/9/2026). Version LOCALE : lus dans settings.json
// (`featureFlags`), tous à OFF par défaut — l'app locale n'a ni administrateur
// ni base partagée, donc pas d'interrupteur en direct (c'est la version cloud
// qui a la table feature_flags, basculée depuis bilbao). Même contrat de
// réponse que le Worker : { flags: { concepts_tab: bool } }.
app.get('/api/flags', (req, res) => {
  const f = settings.featureFlags || {};
  res.json({
    flags: {
      concepts_tab: f.conceptsTab === true,
      journal_a_tab: f.journalATab === true,
      roue_tab: f.roueTab === true,
      radar_tab: f.radarTab === true,
      fundamentals_card: f.fundamentalsCard === true,
      ai_analyst: f.aiAnalyst === true,
    },
  });
});

// Modifications de l'administrateur sur l'onglet Concepts : n'existent que
// côté cloud (édition dans bilbao). En local, toujours le contenu par défaut.
app.get('/api/concepts', (req, res) => {
  res.json({ overrides: {} });
});

// Version installée + disponibilité d'une mise à jour. Le zip téléchargé
// devenait périmé en silence : un testeur n'avait aucun moyen de savoir que
// sa copie datait. La vérification est tolérante — si le manifeste est
// injoignable, on répond « pas de mise à jour » sans jamais alarmer.
app.get('/api/version', async (req, res) => {
  if (req.query.check === 'true') {
    res.json(await checkForUpdate(settings.updateManifestUrl));
    return;
  }
  res.json({ ...getLocalVersion(), updateAvailable: false });
});

// Mise à jour en un clic. Voir l'avertissement en tête de server/update.js :
// tout est vérifié avant que quoi que ce soit ne soit remplacé, `data/`
// (le journal de trades) n'est jamais touché, et l'ancienne version est
// conservée. Le processus s'arrête ensuite : le code en mémoire est celui de
// l'ANCIENNE version tant qu'il n'a pas redémarré. Le launcher (port 4750)
// le relance automatiquement s'il tourne ; sinon l'utilisateur relance
// demarrer.command / demarrer.bat.
let miseAJourEnCours = false;
app.post('/api/update/apply', async (req, res) => {
  // Deux appels simultanés se marcheraient dessus (nettoyage du dossier de travail, double bascule) : un seul à la fois.
  if (miseAJourEnCours) { res.status(409).json({ error: 'Une mise à jour est déjà en cours.' }); return; }
  miseAJourEnCours = true;
  try {
    const check = await checkForUpdate(settings.updateManifestUrl);
    if (!check.updateAvailable || !check.downloadUrl) {
      miseAJourEnCours = false;
      res.status(409).json({ error: 'Aucune mise à jour disponible', check });
      return;
    }
    const result = await applyUpdate(check.downloadUrl, check.sha256);
    res.json({
      ok: true,
      ...result,
      message: 'Mise à jour installée. castellana redémarre — recharge la page dans quelques secondes.',
    });
    // Laisse la réponse partir avant de rendre la main.
    setTimeout(() => process.exit(0), 500);
  } catch (err) {
    miseAJourEnCours = false; // échec : on peut réessayer (sur un succès le processus s'arrête)
    res.status(500).json({ error: 'Mise à jour annulée', detail: err.message });
  }
});

app.get('/api/status', async (req, res) => {
  let dbOk = true;
  let dbDetail = null;
  try {
    db.prepare('SELECT 1').get();
  } catch (err) {
    dbOk = false;
    dbDetail = err.message;
  }
  const [tradingviewMcp, homemade] = await Promise.all([
    checkSidecarConnection(),
    checkYahooConnection(),
  ]);
  res.json({
    backend: true,
    db: dbOk,
    dbDetail,
    tradingviewMcp: tradingviewMcp.ok,
    // `disabled` distingue « composant optionnel non installé » de « panne ».
    // Sans lui, le frontend afficherait une pastille rouge pour le sidecar
    // chez un testeur qui n'a simplement jamais installé Python — soit,
    // depuis le 7/9/2026, le cas par défaut.
    tradingviewMcpDisabled: tradingviewMcp.disabled === true,
    tradingviewMcpDetail: tradingviewMcp.detail,
    homemade: homemade.ok,
    homemadeDetail: homemade.detail,
    checkedAt: new Date().toISOString(),
  });
});

// Pont vers le sidecar tradingview-mcp — VIX + RSI/ATR/Volume/Golden Cross
// pour un titre. Le sidecar (npm run sidecar) n'est pas géré par ce
// serveur : s'il n'est pas démarré, on répond 503 proprement plutôt que de
// planter (même patron que le GITHUB_TOKEN absent chez bilbao).
// Promise.allSettled (pas Promise.all) : VIX (market_snapshot, Yahoo),
// RSI/Golden Cross (coin_analysis, scanner TradingView) et OBV réel/SMA
// 9-21-100 (calcul maison, historique Yahoo direct — indicators.js) sont
// trois sources indépendantes — l'échec de l'une (rate-limit du scanner,
// observé en test réel) ne doit pas faire perdre les autres.
// P/E moyen "par famille d'industrie" pour UN ticker arbitraire (pas
// forcément dans la watchlist) — réutilise le dernier résultat de
// screening EN CACHE (clé SCREENING_KEY, server/cache.js) plutôt que de
// refaire un batch de 20 appels Yahoo à chaque clic sur "Récupérer en
// direct". Si aucun screening n'a encore été lancé, retourne
// explicitement `null`/0 pairs plutôt que de forcer un fetch coûteux et
// invisible pour l'utilisateur.
function industryPeerStatsFromScreeningCache(industry) {
  if (!industry) return { avgPE: null, peerCount: 0 };
  const { found, value } = readCacheRaw(SCREENING_KEY);
  if (!found) return { avgPE: null, peerCount: 0 };
  const rows = value.rows.filter((r) => r.industry === industry && r.peRatio != null);
  if (!rows.length) return { avgPE: null, peerCount: 0 };
  const avg = rows.reduce((sum, r) => sum + r.peRatio, 0) / rows.length;
  return { avgPE: avg, peerCount: rows.length };
}

// Médiane du P/S des titres du dernier screening (watchlist) partageant le secteur
// Yahoo de `sector` — approximation par pairs, ≥ 3 titres sinon `null`. Lecture
// PASSIVE du cache (jamais un fetch forcé ici), comme industryPeerStatsFromScreeningCache.
function sectorPsFromScreeningCache(sector) {
  if (!sector) return { medianPS: null, peerCount: 0 };
  const { found, value } = readCacheRaw(SCREENING_KEY);
  if (!found) return { medianPS: null, peerCount: 0 };
  const v = value.rows.filter((r) => r.sector === sector && r.priceToSales != null).map((r) => r.priceToSales).sort((a, b) => a - b);
  if (v.length < 3) return { medianPS: null, peerCount: v.length };
  const mid = Math.floor(v.length / 2);
  return { medianPS: v.length % 2 ? v[mid] : (v[mid - 1] + v[mid]) / 2, peerCount: v.length };
}

// P/E moyen du SECTEUR GICS large (28/9/2026, demande de JP après confusion
// entre les deux échelles) — le vrai agrégat de marché déjà affiché par la
// carte « Performance des secteurs » (server/sectors.js, ETF sectoriel réel),
// PAS l'approximation par pairs ci-dessus qui exige un pair de la même
// industrie FINE dans la watchlist (souvent aucun — ex. GE en « Aerospace &
// Defense », que la watchlist tech/IA ne couvre pas). Lecture PASSIVE du
// cache déjà rempli par /api/sectors (`sectors:perf:v2:<mode>`) : jamais un
// fetch forcé ici, /api/market-data doit rester rapide. `null` si l'onglet
// Secteurs n'a encore jamais chargé pour aucun des deux modes, ou si le
// secteur Yahoo ne correspond à aucun des 11 ETF.
function sectorPeFromCache(yahooSector) {
  if (!yahooSector) return null;
  const etfKey = Object.keys(SECTOR_ETF_TO_YAHOO_SECTOR).find((k) => SECTOR_ETF_TO_YAHOO_SECTOR[k] === yahooSector);
  const def = etfKey && SECTOR_DEFS.find((d) => d.key === etfKey);
  if (!def) return null;
  for (const mode of SECTOR_MODES) {
    const { found, value } = readCacheRaw(`sectors:perf:v2:${mode}`);
    if (!found) continue;
    const pe = value[def[mode] ?? def.usd]?.peRatio;
    if (pe != null) return { pe, label: def.label };
  }
  return null;
}

// Fondamentaux (P/E, industrie, PEG, beta, float, VWAP) + OBV/volume pour la
// carte "Ticker" fusionnée de l'onglet Secteurs (5/9/2026, demande de JP
// T5) — 4ᵉ branche Promise.allSettled, indépendante des trois autres (VIX/
// RSI/Golden Cross et calculs maison), Yahoo Finance direct comme
// fundamentals.js.
app.get('/api/market-data/:ticker', async (req, res) => {
  const ticker = req.params.ticker.toUpperCase();
  const sidecarOn = isSidecarEnabled();

  // Une seule requête groupée couvre le VIX ET la cotation du titre — avant
  // le 7/9/2026 c'étaient deux appels distincts au sidecar Python
  // (`market_snapshot` puis `coin_analysis`).
  const [quotesResult, homemadeResult, fundResult, taResult] = await Promise.allSettled([
    // SPY est joint à la requête groupée (11/9/2026) : la bannière de
    // verdict de la carte « Ticker » vit désormais aussi dans la Fiche de
    // trade, qui n'appelait que cette route — sans le benchmark ici, elle
    // n'aurait eu aucun moyen de calculer la force relative. Coût réseau
    // nul en pratique : même requête groupée, et SPY est presque toujours
    // déjà en cache (consulté par tous les autres écrans).
    getQuotes(['^VIX', ticker, BENCHMARK_SYMBOL]),
    getHomemadeIndicators(ticker, indicatorOptions()),
    getFundamentals(ticker, { withVwap: true }),
    // Le sidecar n'est appelé QUE s'il est explicitement activé — sinon la
    // branche se résout immédiatement à null, sans connexion tentée.
    sidecarOn ? getTechnicalAnalysis(ticker, { exchange: req.query.exchange || 'NASDAQ' }) : Promise.resolve(null),
  ]);

  if (quotesResult.status === 'rejected' && homemadeResult.status === 'rejected' && fundResult.status === 'rejected') {
    res.status(503).json({
      error: 'Yahoo Finance injoignable',
      detail: [quotesResult.reason?.message, homemadeResult.reason?.message, fundResult.reason?.message]
        .filter(Boolean).join(' · '),
    });
    return;
  }

  const quotes = quotesResult.status === 'fulfilled' ? quotesResult.value : new Map();
  const hm = homemadeResult.status === 'fulfilled' ? homemadeResult.value : null;
  const fund = fundResult.status === 'fulfilled' ? fundResult.value : null;
  const ta = taResult.status === 'fulfilled' ? taResult.value : null;
  const psSector = sectorPsFromScreeningCache(fund?.sector);
  const industryStat = fund?.industry ? industryPeerStatsFromScreeningCache(fund.industry) : { avgPE: null, peerCount: 0 };
  const sectorPe = fund?.sector ? sectorPeFromCache(fund.sector) : null;

  res.json({
    ticker,
    vix: quotes.get('^VIX')?.price ?? null,
    // RSI, Golden Cross et SMA50/200 viennent désormais du calcul maison
    // (indicators.js, historique Yahoo). Le sidecar ne sert plus que de
    // repli quand il est activé — l'inverse exact d'avant le 7/9/2026.
    rsi: hm?.rsi ?? ta?.rsi?.value ?? null,
    goldenCross: hm?.goldenCross ?? ta?.sma?.signals?.some((x) => x.startsWith('Golden Cross')) ?? null,
    sma50: hm?.sma50 ?? ta?.sma?.sma50 ?? null,
    sma200: hm?.sma200 ?? ta?.sma?.sma200 ?? null,
    atr: hm?.atr ?? ta?.atr?.value ?? null,
    volumeRatio: hm?.volumeRatio ?? ta?.volume_analysis?.ratio ?? null,
    volumeAvg100: hm?.volumeAvg100 ?? null,
    previousClose: hm?.previousClose ?? null,
    previousCloseDate: hm?.previousCloseDate ?? null,
    volumeSMA20: hm?.volumeSMA20 ?? null,
    changePercent: quotes.get(ticker)?.changePercent ?? ta?.price_data?.change_percent ?? null,
    // Force relative : la variation du benchmark sur la même journée, pour
    // que l'appelant n'ait pas à faire un second appel /api/quote/SPY.
    benchmarkSymbol: BENCHMARK_SYMBOL,
    benchmarkChangePercent: quotes.get(BENCHMARK_SYMBOL)?.changePercent ?? null,
    price: quotes.get(ticker)?.price ?? hm?.price ?? fund?.price ?? null,
    // sma9/21/100 : filtre de tendance maison (fenêtre glissante), distinct
    // des SMA50/200 du Golden Cross ci-dessus.
    sma9: hm?.sma9 ?? null,
    sma21: hm?.sma21 ?? null,
    sma100: hm?.sma100 ?? null,
    // Périodes RÉELLEMENT utilisées pour ce calcul, pas celles supposées —
    // le frontend étiquette ses libellés dessus (même principe que l'onglet
    // Labo depuis le 5/9/2026).
    smaPeriods: hm?.smaPeriods ?? null,
    rsiPeriod: hm?.rsiPeriod ?? null,
    smaAlignment: hm?.smaAlignment ?? null,
    obv: hm?.obv ?? null,
    obvTrend: hm?.obvTrend ?? null,
    homemadeError: homemadeResult.status === 'rejected' ? homemadeResult.reason.message : null,
    quotesError: quotesResult.status === 'rejected' ? quotesResult.reason.message : null,
    // Non nul seulement si le sidecar est activé ET a échoué — jamais une
    // erreur pour un composant que l'utilisateur n'a pas installé.
    technicalError: sidecarOn && taResult.status === 'rejected' ? taResult.reason.message : null,
    volume: fund?.volume ?? quotes.get(ticker)?.volume ?? null,
    floatShares: fund?.floatShares ?? null,
    peRatio: fund?.peRatio ?? null,
    priceToSales: fund?.priceToSales ?? null,
    sector: fund?.sector ?? null,
    sectorPS: psSector.medianPS,
    sectorPSPeerCount: psSector.peerCount,
    industry: fund?.industry ?? null,
    industryPE: industryStat.avgPE,
    industryPeerCount: industryStat.peerCount,
    // Repli sur le P/E du secteur GICS large (lecture passive du cache de
    // /api/sectors) quand aucun pair de la même industrie fine n'est suivi —
    // voir sectorPeFromCache() plus haut. Toujours distinct de industryPE :
    // le frontend doit dire clairement lequel des deux il affiche.
    sectorPE: sectorPe?.pe ?? null,
    sectorLabel: sectorPe?.label ?? null,
    pegRatio: fund?.pegRatio ?? null,
    beta: fund?.beta ?? null,
    vwap: fund?.vwap ?? null,
    aboveVwap: fund?.aboveVwap ?? null,
    fundamentalsError: fundResult.status === 'rejected' ? fundResult.reason.message : null,
  });
});

// Cotation simple — Yahoo Finance en direct (server/quotes.js) depuis le
// 7/9/2026. Elle transitait auparavant par l'outil `yahoo_price` DU SIDECAR
// (constat F6 de l'audit) : la force relative, censée survivre à une panne
// du scanner TradingView, tombait en réalité avec le processus Python.
// Recherche de symbole par nom (3/10/2026) — voir server/symbol-search.js.
app.get('/api/search/symbols', async (req, res) => {
  try {
    res.json(await searchSymbols(req.query.q, String(req.query.filter || 'all')));
  } catch (err) {
    res.status(503).json({ error: 'Recherche Yahoo Finance indisponible', detail: err.message });
  }
});

app.get('/api/quote/:symbol', async (req, res) => {
  const symbol = req.params.symbol.toUpperCase();
  try {
    const quotes = await getQuotes([symbol]);
    const q = quotes.get(symbol);
    if (!q) {
      res.status(404).json({ error: `Ticker inconnu de Yahoo Finance : ${symbol}` });
      return;
    }
    res.json({ symbol, price: q.price, changePercent: q.changePercent });
  } catch (err) {
    res.status(503).json({ error: 'Yahoo Finance injoignable', detail: err.message });
  }
});

// Paramètres des stratégies d'options (onglet Labo) — surcharges de
// l'utilisateur uniquement ; les défauts vivent dans js/labo-schema.js.
// ⚠️ À déclarer AVANT `/api/labo/:ticker`, sinon `params` serait pris pour
// un symbole.
app.get('/api/labo/params', (req, res) => {
  res.json({ overrides: getLaboOverrides(), schemaVersion: laboSchema.LABO_SCHEMA.version });
});

app.put('/api/labo/params/:id', (req, res) => {
  try {
    res.json({ overrides: setStrategyParams(req.params.id, (req.body || {}).values || {}) });
  } catch (err) {
    res.status(err.code === 'INVALID_LABO_PARAMS' ? 400 : 500).json({ error: err.message, errors: err.errors });
  }
});

app.post('/api/labo/params/reset', (req, res) => {
  res.json({ overrides: resetAllStrategyParams() });
});

app.post('/api/labo/params/:id/reset', (req, res) => {
  try {
    res.json({ overrides: resetStrategyParams(req.params.id) });
  } catch (err) {
    res.status(err.code === 'INVALID_LABO_PARAMS' ? 400 : 500).json({ error: err.message });
  }
});

// Journal A (22/9/2026) — screener de primes. DOIT être déclarée AVANT
// /api/options/:ticker : les deux chemins ont la même forme
// (/api/options/<segment>), et Express résout par ORDRE d'enregistrement —
// « premium-screener » serait sinon capturé comme `:ticker` (bug réel
// trouvé en testant en direct : la route répondait « Symbole
// "PREMIUM-SCREENER" inconnu »). Même piège que /api/labo/params vs
// /api/labo/:ticker et /api/option-trades/alerts vs /api/option-trades/:id
// ci-dessous — un segment littéral après un préfixe à un seul niveau doit
// TOUJOURS précéder son :param frère.
app.get('/api/options/premium-screener', async (req, res) => {
  try {
    const n = (v, d) => { const f = parseFloat(v); return Number.isFinite(f) ? f : d; };
    const opts = { deltaMin: n(req.query.deltaMin, 0.15), deltaMax: n(req.query.deltaMax, 0.25), dteMin: n(req.query.dteMin, 25), dteMax: n(req.query.dteMax, 45),
      mode: req.query.mode === 'limite' ? 'limite' : 'rendement', rulePct: n(req.query.rulePct, 0.5), rulePeriodDays: n(req.query.ruleDays, 5), type: req.query.type === 'call' ? 'call' : 'put' };
    // Univers élargi (4/10/2026, LOCAL) : jamais 219 chaînes à la volée — on relit le
    // dernier scan hebdo du Radar. 404 explicite s'il n'y en a pas encore.
    if (req.query.universe === 'elargi' || req.query.universe === 'sp500') {
      const data = premiumRowsFromScan({ ...opts, univers: req.query.universe });
      if (!data) { res.status(404).json({ error: 'Aucun scan hebdo du Radar pour l\'instant — lance-en un (il prend environ une minute).', code: 'NO_WEEKLY_SCAN' }); return; }
      res.json(data); return;
    }
    res.json(await screenPremiums(req.query.universe || 'watchlist', opts));
  } catch (err) {
    res.status(err.status || 503).json({ error: err.message });
  }
});

// Chaîne d'options d'un titre (feature #358 v1). `?expiry=AAAA-MM-JJ` (défaut : la plus proche).
app.get('/api/options/:ticker', async (req, res) => {
  try {
    res.json(await getOptionChain(req.params.ticker.toUpperCase(), { expiry: req.query.expiry || null, force: req.query.force === 'true' }));
  } catch (err) {
    res.status(err.status || 503).json({ error: err.message });
  }
});

// Options A (#11, 22/9/2026) — grille de rendement annualisé sur plusieurs
// échéances (segment /grid distinct de /api/options/:ticker, aucune ambiguïté
// de route avec un symbole).
app.get('/api/options/:ticker/grid', async (req, res) => {
  try {
    const deltaMin = parseFloat(req.query.deltaMin);
    const deltaMax = parseFloat(req.query.deltaMax);
    const maxExpiries = parseInt(req.query.maxExpiries, 10);
    res.json(await getAnnualizedGrid(req.params.ticker.toUpperCase(), {
      type: req.query.type === 'call' ? 'call' : 'put',
      deltaMin: Number.isFinite(deltaMin) ? deltaMin : 0.15,
      deltaMax: Number.isFinite(deltaMax) ? deltaMax : 0.25,
      maxExpiries: Number.isFinite(maxExpiries) ? maxExpiries : 6,
    }));
  } catch (err) {
    res.status(err.status || 503).json({ error: err.message });
  }
});

// ---- Journal A (22/9/2026, suite) — cycles de la Roue et alertes de
// roulement. `/api/option-trades/alerts` DOIT être déclarée avant
// `/api/option-trades/:id` (même piège, voir commentaire ci-dessus).

// Secteur de quelques titres (onglet Roue, répartition par secteur, #435). Même source que le reste de
// l'app (Yahoo summaryProfile, cache fundamentals:v2) — jamais le scraping du Sheets du club. 20 titres au plus.
app.get('/api/ticker-sectors', async (req, res) => {
  const tickers = [...new Set(String(req.query.tickers || '').split(',').map((t) => t.trim().toUpperCase()).filter(Boolean))].slice(0, 20);
  try {
    const rows = await getFundamentalsBatch(tickers, { withVwap: false });
    res.json({ sectors: Object.fromEntries(rows.map((r) => [r.ticker, r.sector || null])), earnings: Object.fromEntries(rows.map((r) => [r.ticker, Number.isFinite(r.daysToEarnings) ? r.daysToEarnings : null])) });
  } catch (err) { res.status(503).json({ error: err.message }); }
});

// Flux de trésorerie par compte (Journal de la Roue, #434) — voir server/cash-flows.js.
app.get('/api/cash-flows', (req, res) => res.json({ cashFlows: listCashFlows({ compte: req.query.compte || undefined }) }));
app.post('/api/cash-flows', (req, res) => {
  try { res.status(201).json(createCashFlow(req.body || {})); } catch (err) { res.status(err.status || 400).json({ error: err.message }); }
});
app.delete('/api/cash-flows/:id', (req, res) => {
  if (!deleteCashFlow(Number(req.params.id))) { res.status(404).json({ error: 'flux introuvable' }); return; }
  res.status(204).end();
});

app.get('/api/option-cycles', (req, res) => res.json({ cycles: listCycles() }));

app.post('/api/option-cycles', (req, res) => {
  try {
    res.status(201).json(createCycle(req.body || {}));
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

// Bilan par cycle (#378) : AVANT /api/option-cycles/:id (même piège que /api/labo/params).
app.get('/api/option-cycles/bilans', async (req, res) => {
  try { res.json({ bilans: await getCycleBilans() }); } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/option-cycles/:id', (req, res) => {
  const cycle = getCycle(Number(req.params.id));
  if (!cycle) { res.status(404).json({ error: 'Cycle introuvable' }); return; }
  res.json(cycle);
});

app.patch('/api/option-cycles/:id', (req, res) => {
  try {
    res.json(updateCycle(Number(req.params.id), req.body || {}));
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

app.get('/api/option-trades/alerts', async (req, res) => {
  try {
    res.json({ alerts: await getRollAlerts() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/option-trades', (req, res) => {
  res.json({ trades: listOptionTrades({ statut: req.query.statut, cycleId: req.query.cycleId ? Number(req.query.cycleId) : undefined }) });
});

app.post('/api/option-trades', (req, res) => {
  try {
    res.status(201).json(createOptionTrade(req.body || {}));
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

app.get('/api/option-trades/:id', (req, res) => {
  const ot = getOptionTrade(Number(req.params.id));
  if (!ot) { res.status(404).json({ error: 'Position introuvable' }); return; }
  res.json(ot);
});

app.post('/api/option-trades/:id/close', (req, res) => {
  try {
    res.json(closeOptionTrade(Number(req.params.id), req.body || {}));
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

// Suppression multiple de l'onglet Roue (positions, mouvements, et cycles devenus vides).
app.post('/api/roue/delete', (req, res) => {
  try { res.json({ deleted: deleteRoueEntries(req.body || {}) }); } catch (err) { res.status(err.status || 400).json({ error: err.message }); }
});

app.delete('/api/option-trades/:id', (req, res) => {
  res.json({ deleted: deleteOptionTrade(Number(req.params.id)) });
});

// ---- Radar (22/9/2026) — screener multi-titres de meilleurs deals, LOCAL
// UNIQUEMENT (aucun équivalent cloud, décision explicite de JP — voir
// CLAUDE.md). Le scan tourne en tâche de fond (fire-and-forget depuis la
// route /start, qui répond immédiatement avec l'id) ; le process Node reste
// disponible pour le reste de l'app pendant ce temps.
app.post('/api/deal-scanner/start', (req, res) => {
  if (isScanRunning()) { res.status(409).json({ error: 'Un scan est déjà en cours.' }); return; }
  const fenetre = req.body?.fenetre === 'hebdo' ? 'hebdo' : 'standard';
  const univers = req.body?.univers === 'sp500' ? 'sp500' : 'elargi';
  let created;
  try { created = createScan(fenetre, univers); } catch (err) { res.status(400).json({ error: err.message }); return; }
  const { scanId, tickers } = created;
  runDealScan(scanId, tickers, { ...SCAN_WINDOWS[fenetre], fenetre }).catch((err) => console.error('Radar : scan en échec —', err.message));
  res.status(202).json({ scanId, totalTickers: tickers.length, fenetre, univers });
});

app.get('/api/deal-scanner/status', (req, res) => {
  const id = req.query.scanId ? Number(req.query.scanId) : listScans(1)[0]?.id;
  const scan = id ? getScan(id) : null;
  if (!scan) { res.status(404).json({ error: 'Aucun scan trouvé.' }); return; }
  res.json(scan);
});

// Entier > 0 borné à 500, sinon la valeur par défaut (audit onglets locaux, 21/10/2026).
function entierPositif(v, parDefaut) {
  const n = Number(v);
  return Number.isInteger(n) && n > 0 ? Math.min(n, 500) : parDefaut;
}

app.get('/api/deal-scanner/results', (req, res) => {
  const scanId = Number(req.query.scanId);
  if (!scanId) { res.status(400).json({ error: 'scanId requis.' }); return; }
  res.json({
    results: getResults(scanId, {
      mode: req.query.mode === 'achat' ? 'achat' : 'vente',
      type: ['put', 'call'].includes(req.query.type) ? req.query.type : undefined,
      diversifie: req.query.diversifie === 'true',
      maxPerSector: entierPositif(req.query.maxPerSector, undefined), // « abc » donnait NaN et désactivait le plafond par secteur
      limit: entierPositif(req.query.limit, 20),
      includeExcluded: req.query.includeExcluded === 'true',
    }),
  });
});

app.get('/api/deal-scanner/history', (req, res) => {
  res.json({ scans: listScans(entierPositif(req.query.limit, 20)) });
});

// Qualité du FCF (26/9/2026, lot 1) : EPS, FCF, FCF/action + indice. Route
// non gardée par le flag (comme les autres) — le flag ne masque que la carte.
app.get('/api/fcf/:ticker', async (req, res) => {
  const ticker = req.params.ticker.toUpperCase();
  try {
    res.json(await getFcfQuality(ticker));
  } catch (err) {
    res.status(502).json({ error: `Fondamentaux indisponibles pour ${ticker} : ${err.message}` });
  }
});

// Onglet Labo (5/9/2026) — données réelles d'un titre pour démontrer la
// séquence d'une stratégie d'options (server/../js/strategies-labo.js).
// Uniquement des sources Yahoo Finance directes (fundamentals.js +
// indicators.js) — volontairement PAS tradingview-mcp/coin_analysis, pour
// ne jamais dépendre du rate-limit déjà documenté sur ce chemin. Aucune
// donnée d'options (chaîne, delta, prime) n'existe dans cette app : ce
// endpoint fournit le prix + la volatilité historique réels, à partir
// desquels le frontend ESTIME un strike par Black-Scholes (jamais une
// vraie donnée d'options — voir CLAUDE.md).
//
// `smaFast`/`smaMedium`/`smaSlow` (5/9/2026, demande de JP T3) — périodes du
// filtre de tendance, réellement PASSÉES à getHomemadeIndicators() (pas
// seulement des libellés), surchageables depuis les champs visibles en haut
// de l'onglet Labo. `smaPeriods` dans la réponse confirme les valeurs
// effectivement utilisées.
//
// Depuis la feature 351 (7/9/2026), le défaut n'est plus 9/21/100 en dur
// mais les RÉGLAGES DE L'UTILISATEUR (Réglages → Valeur personnalisée) :
// deux endroits qui affichaient des périodes différentes pour le même
// indicateur auraient été une source de confusion garantie.
app.get('/api/labo/:ticker', async (req, res) => {
  const ticker = req.params.ticker.toUpperCase();
  const parsePeriod = (raw, fallback) => {
    const n = parseInt(raw, 10);
    return Number.isInteger(n) && n > 0 ? n : fallback;
  };
  const prefs = getPreferences();
  const periods = {
    fast: parsePeriod(req.query.smaFast, prefs.smaFast),
    medium: parsePeriod(req.query.smaMedium, prefs.smaMedium),
    slow: parsePeriod(req.query.smaSlow, prefs.smaSlow),
  };
  const [fundResult, indicResult] = await Promise.allSettled([
    getFundamentals(ticker, { withVwap: false }),
    getHomemadeIndicators(ticker, { periods, rsiPeriod: prefs.rsiPeriod }),
  ]);
  if (fundResult.status === 'rejected' && indicResult.status === 'rejected') {
    res.status(503).json({ error: 'Yahoo Finance injoignable pour ce titre', detail: fundResult.reason.message });
    return;
  }
  const fund = fundResult.status === 'fulfilled' ? fundResult.value : null;
  const indic = indicResult.status === 'fulfilled' ? indicResult.value : null;
  res.json({
    ticker,
    price: fund?.price ?? null,
    volume: fund?.volume ?? null,
    beta: fund?.beta ?? null,
    peRatio: fund?.peRatio ?? null,
    industry: fund?.industry ?? null,
    sector: fund?.sector ?? null,
    // Réutilisé par Options A (#10, 22/9/2026) pour l'alerte résultats/dividende
    // sur la chaîne d'options — déjà calculé par getFundamentals(), zéro appel
    // réseau supplémentaire (voir server/fundamentals.js).
    daysToEarnings: fund?.daysToEarnings ?? null,
    earningsDate: fund?.earningsDate ?? null,
    earningsTiming: fund?.earningsTiming ?? null,
    atr: indic?.atr ?? null,
    sma9: indic?.sma9 ?? null,
    sma21: indic?.sma21 ?? null,
    sma100: indic?.sma100 ?? null,
    smaPeriods: indic?.smaPeriods ?? periods,
    smaAlignment: indic?.smaAlignment ?? null,
    obvTrend: indic?.obvTrend ?? null,
    volumeRatio: indic?.volumeRatio ?? null,
    volumeAvg100: indic?.volumeAvg100 ?? null,
    historicalVolatility: indic?.historicalVolatility ?? null,
    fundamentalsError: fundResult.status === 'rejected' ? fundResult.reason.message : null,
    indicatorsError: indicResult.status === 'rejected' ? indicResult.reason.message : null,
  });
});

// Performance + P/E des 11 secteurs SPDR + benchmark S&P 500 (carte
// "Performance des secteurs" de l'écran de sélection, server/sectors.js).
// Rapide (~2s, quote() simple) et pas affecté par le rate-limit de
// coin_analysis — pas de cache nécessaire ici, contrairement à
// /api/screening.
// PEG moyen par secteur (30/8/2026, demande de JP) — AUCUNE source Yahoo ne
// fournit de PEG au niveau ETF/secteur (vérifié : quote()/quoteSummary
// renvoient `undefined` pour XLK/XLF/SPY, contrairement au P/E qui, lui,
// existe réellement au niveau de l'ETF). Calculé à la place comme la
// moyenne des PEG des titres de LA WATCHLIST partageant le même secteur
// GICS large (`summaryProfile.sector`, fundamentals.js + mapping
// SECTOR_ETF_TO_YAHOO_SECTOR de sectors.js) — même principe d'approximation
// assumée que le "P/E industrie" du screening, PAS un agrégat de marché.
// Couverture nécessairement partielle : la watchlist (20 titres tech/IA)
// ne compte aucun titre dans plusieurs secteurs (Énergie, Immobilier,
// Matériaux…) — ces lignes ressortent en `null`/"—", jamais un chiffre
// inventé. `pegPeerCount` expose le nombre de titres utilisés, affiché en
// tooltip pour ne jamais laisser croire à un échantillon plus large.
// `mode` (usd|cad, 2/9/2026) sélectionne quels tickers interroger — voir
// server/sectors.js, SECTOR_DEFS. Invalide par défaut sur 'usd' plutôt que
// de planter si le paramètre est absent ou mal formé.
function parseSectorMode(req, res) {
  const mode = req.query.mode || 'usd';
  if (!SECTOR_MODES.includes(mode)) {
    res.status(400).json({ error: `mode invalide : ${mode} (attendu : ${SECTOR_MODES.join('|')})` });
    return null;
  }
  return mode;
}

app.get('/api/sectors', async (req, res) => {
  const mode = parseSectorMode(req, res);
  if (mode === null) return;
  try {
    const watchlist = getWatchlist();
    const [perf, fundamentalRows] = await Promise.all([
      getSectorPerformance({ mode }),
      getFundamentalsBatch(watchlist.map((w) => w.ticker), { withVwap: false, delayMs: 150 }),
    ]);
    const pegBySector = new Map();
    for (const f of fundamentalRows) {
      if (!f.sector || f.pegRatio == null) continue;
      if (!pegBySector.has(f.sector)) pegBySector.set(f.sector, []);
      pegBySector.get(f.sector).push(f.pegRatio);
    }
    // Jointure par `s.key` (toujours le ticker USD, stable) et non
    // `s.ticker` (qui peut être un ticker .TO en mode CAD) — sinon la
    // moyenne PEG par secteur casserait dès qu'on bascule hors USD.
    const sectorsWithPeg = perf.sectors.map((s) => {
      const values = pegBySector.get(SECTOR_ETF_TO_YAHOO_SECTOR[s.key]);
      return {
        ...s,
        pegAvg: values?.length ? values.reduce((a, b) => a + b, 0) / values.length : null,
        pegPeerCount: values?.length ?? 0,
      };
    });
    res.json({ generatedAt: new Date().toISOString(), mode, sectors: sectorsWithPeg, benchmark: perf.benchmark, equalWeight: perf.equalWeight });
  } catch (err) {
    res.status(503).json({ error: 'Yahoo Finance injoignable', detail: err.message });
  }
});

// Historique quotidien (~13 mois) pour le line graph de performance
// sectorielle — un seul fetch, le frontend découpe par période (1S à 12M)
// et normalise en % côté client, sans refetch à chaque changement de période.
app.get('/api/sectors/history', async (req, res) => {
  const mode = parseSectorMode(req, res);
  if (mode === null) return;
  try {
    const data = await getSectorHistory({ mode });
    res.json({ generatedAt: new Date().toISOString(), mode, ...data });
  } catch (err) {
    res.status(503).json({ error: 'Yahoo Finance injoignable', detail: err.message });
  }
});

// "Titres les plus performants du secteur" (onglet Secteurs, 2/9/2026) —
// classe une liste CURATÉE par secteur (server/sectors.js,
// SECTOR_TOP_CANDIDATES) par variation du jour. PAS une requête de marché
// large — voir le commentaire détaillé dans sectors.js sur l'échec du
// screener personnalisé Yahoo (429 systématique sur un endpoint
// probablement réservé aux comptes connectés). Cache PERSISTANT par
// (sectorKey, mode-filtre) depuis le 7/9/2026 — c'était une Map en mémoire,
// perdue à chaque redémarrage (constat F8). ?force=true bypasse. Jamais un
// 200 avec rows:[] qui laisserait croire à "aucun titre" — un échec Yahoo
// devient un 503 explicite.

app.get('/api/sectors/:sectorKey/top', async (req, res) => {
  const sectorKey = req.params.sectorKey.toUpperCase();
  const filterMode = req.query.mode === 'filtered' ? 'filtered' : req.query.mode === 'raw' ? 'raw' : null;
  if (!filterMode) {
    res.status(400).json({ error: `mode invalide : ${req.query.mode} (attendu : raw|filtered)` });
    return;
  }
  if (!SECTOR_ETF_TO_YAHOO_SECTOR[sectorKey]) {
    res.status(400).json({ error: `secteur inconnu : ${sectorKey}` });
    return;
  }
  // Clé VERSIONNÉE (v2, 11/9/2026) : la forme de la réponse a changé — les
  // lignes portent désormais toutes les colonnes du screening. Réutiliser
  // l'ancienne clé aurait servi des lignes enregistrées AVANT le changement,
  // sans RSI ni score, et rien ne l'aurait signalé. Piège déjà rencontré le
  // même jour sur `fundamentals:v2:`.
  const cacheKey = `sectors:topresult:v2:${sectorKey}:${filterMode}`;
  const ttlSeconds = (settings.sectorTopCacheMinutes ?? 20) * 60;
  const rawEntry = readCacheRaw(cacheKey);
  const cached = rawEntry.found ? { payload: rawEntry.value, timestamp: Date.now() - rawEntry.ageSeconds * 1000 } : null;
  if (req.query.force !== 'true' && cached && rawEntry.ageSeconds < ttlSeconds) {
    res.json({ ...cached.payload, cached: true });
    return;
  }
  try {
    const result = await buildSectorScreening(sectorKey, { mode: filterMode, filters: SECTOR_TOP_FILTERS });
    const payload = {
      sectorKey,
      sectorLabel: SECTOR_DEFS.find((d) => d.key === sectorKey)?.label ?? sectorKey,
      mode: filterMode,
      generatedAt: new Date().toISOString(),
      ...result,
    };
    writeCache(cacheKey, payload, ttlSeconds);
    res.json({ ...payload, cached: false });
  } catch (err) {
    res.status(503).json({ error: 'Yahoo Finance injoignable pour ce secteur', detail: err.message, sectorKey, mode: filterMode });
  }
});

// Bandes de score — dupliquées de config.js (CFG.bandes) faute de format de
// module commun entre le frontend classique <script> et ce backend ESM.
// Si les bandes de config.js changent, reporter le changement ici aussi.
// SCORE_BANDS et la notation ont déménagé dans server/scoring.js le
// 11/9/2026 : le score unique est devenu deux axes (Setup / Contexte), et
// index.js dépassait déjà 750 lignes.

// SCREEN_FILTERS et fundamentalFlags ont déménagé dans server/screening.js
// le 11/9/2026, avec le reste de l'orchestration du screening.

// Screening de l'univers de titres (server/watchlist.js, 20 titres) — deux
// passes séquentielles indépendantes : tradingview.js (RSI/Force
// relative/Golden Cross, rate-limit non documenté observé en test réel) et
// indicators.js (OBV réel, calcul maison sur historique Yahoo direct, pas
// affecté par ce rate-limit). Peut prendre ~45-60s pour 20 titres au total.
// Un titre en échec individuel (sur l'une ou l'autre passe) ne fait pas
// échouer toute la requête — verdict "erreur" pour ce titre seulement si
// vraiment aucune des deux sources n'a rien donné.
//
// Cache (TTL settings.screeningCacheMinutes, défaut 20) : un screening
// relancé dans la fenêtre renvoie le résultat précédent. ?force=true
// bypasse.
app.get('/api/screening', async (req, res) => {
  const universe = isValidUniverse(req.query.universe) ? req.query.universe : 'watchlist';
  const cacheKey = screeningCacheKey(universe);
  // S&P 500 (7/10/2026) : jamais calculé « à la volée » (des minutes d'appels) — il vient du
  // balayage (server/sweep.js), dont le résultat reste valable 3 h.
  const ttlSeconds = universe === 'sp500' ? 3 * 3600 : (settings.screeningCacheMinutes ?? 20) * 60;
  if (universe === 'sp500') {
    // Dernier balayage servi QUEL QUE SOIT son âge (le client affiche l'âge et avertit s'il est
    // ancien) : refuser un résultat de 4 h, c'était cacher un travail de 12 minutes sans rien dire.
    const { found, value, ageSeconds } = readCacheRaw(cacheKey);
    if (!found) {
      res.status(409).json({ error: 'Aucun balayage S&P 500 récent — lance-le depuis Réglages → TradingView (balayage local).', code: 'NO_SWEEP' });
      return;
    }
    res.json({ ...value, cached: true, cacheAgeSeconds: Math.round(ageSeconds) });
    return;
  }

  // Cache par UNIVERS : sans clé distincte, un screening élargi écraserait
  // celui de la watchlist (et l'export CSV avec lui).
  if (req.query.force !== 'true') {
    const { found, value, ageSeconds } = readCacheRaw(cacheKey);
    if (found && ageSeconds < ttlSeconds) {
      res.json({ ...value, cached: true, cacheAgeSeconds: Math.round(ageSeconds) });
      return;
    }
  }

  try {
    const payload = await buildScreening(universe);
    writeCache(cacheKey, payload, TTL.SLOW);
    res.json({ ...payload, cached: false });
  } catch (err) {
    // `passErrors` n'est rempli que quand TOUTES les passes ont échoué —
    // c'est la seule vraie panne. Le reste est une erreur interne, et on le
    // dit plutôt que d'accuser une source au hasard (constat F7).
    if (err.passErrors) {
      res.status(503).json({
        error: err.message,
        passErrors: err.passErrors,
        detail: Object.entries(err.passErrors).filter(([, v]) => v).map(([k, v]) => `${k} : ${v}`).join(' · '),
      });
      return;
    }
    res.status(500).json({ error: 'Erreur interne pendant le screening', detail: err.message });
  }
});

// Performance (%) des titres du dernier screening — graphique de l'onglet
// Screener (21/9/2026). Ne dépend PAS du cache de screening : la liste des
// tickers vient du FRONTEND (déjà triée Setup/Contexte, déjà plafonnée côté
// client) — cette route reste utilisable même si un autre univers a été
// screené entre-temps.
app.get('/api/screening/tickers', async (req, res) => {
  let tickers;
  try { tickers = parseTickersParam(req.query.tickers); } catch (err) { res.status(err.status || 400).json({ error: err.message }); return; }
  try { res.json(await buildTickersScreening(tickers)); } catch (err) { res.status(503).json({ error: err.message }); }
});

app.get('/api/screening/history', async (req, res) => {
  let tickers;
  try {
    tickers = parseTickersParam(req.query.tickers);
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
    return;
  }
  try {
    const series = await getScreeningPerformance(tickers);
    res.json({ series, generatedAt: new Date().toISOString() });
  } catch (err) {
    res.status(503).json({ error: err.message });
  }
});

// Export CSV du screening (bonus) — sert le dernier résultat en cache pour
// ne pas relancer 60s d'appels ; si le cache est vide, invite à lancer un
// screening d'abord (pas de fetch implicite ici).
app.get('/api/screening.csv', (req, res) => {
  const { found: csvFound, value: csvValue } = readCacheRaw(SCREENING_KEY);
  if (!csvFound) {
    res.status(409).json({ error: 'Aucun screening en cache — lancer /api/screening d\'abord.' });
    return;
  }
  // Les deux axes et l'âge du signal en tête : c'est sur eux qu'on trie et
  // qu'on décide depuis le 11/9/2026. `score` (la somme) reste exporté pour
  // ne pas casser un classeur déjà construit sur cette colonne.
  const cols = ['ticker', 'setupScore', 'contexteScore', 'alignmentAge', 'smaAlignment', 'verdict', 'score', 'rsi', 'forceRelative', 'goldenCross', 'obvTrend', 'price', 'volume', 'floatShares', 'peRatio', 'industry', 'industryPE', 'pegRatio', 'beta', 'vwap', 'daysToEarnings', 'atr', 'priceToSales', 'sectorPS'];
  const escape = (v) => {
    if (v == null) return '';
    const s = String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [cols.join(',')];
  for (const row of csvValue.rows) {
    lines.push(cols.map((c) => escape(row[c])).join(','));
  }
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="screening-castellana-${Date.now()}.csv"`);
  res.send(lines.join('\n'));
});

// Routes CRUD du journal de trades (table `trades`, schéma section 7 du
// design doc — voir db.js). Validation manuelle en amont (trades.js) plutôt
// que de laisser remonter les erreurs CHECK brutes de SQLite.
app.post('/api/trades', (req, res) => {
  const errors = validateTrade(req.body);
  if (errors.length) { res.status(400).json({ errors }); return; }
  try {
    res.status(201).json(createTrade(req.body));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/trades', (req, res) => {
  const { compte, ticker } = req.query;
  if ((ticker !== undefined && typeof ticker !== 'string') || (compte !== undefined && typeof compte !== 'string')) { res.status(400).json({ error: 'ticker et compte doivent être une seule valeur.' }); return; } // ?ticker=a&ticker=b faisait un 500
  const open = req.query.open === 'true' ? true : req.query.open === 'false' ? false : undefined;
  res.json({ trades: listTrades({ compte, ticker, open }) });
});

app.get('/api/trades/:id', (req, res) => {
  const trade = getTrade(req.params.id);
  if (!trade) { res.status(404).json({ error: 'trade introuvable' }); return; }
  res.json(trade);
});

// PUT partiel — sert aussi bien à corriger une saisie qu'à clôturer un trade
// (date_sortie/prix_sortie/r_realise/resultat envoyés seuls).
app.put('/api/trades/:id', (req, res) => {
  if (!getTrade(req.params.id)) { res.status(404).json({ error: 'trade introuvable' }); return; }
  const errors = validateTrade(req.body, { partial: true });
  if (errors.length) { res.status(400).json({ errors }); return; }
  try {
    res.json(updateTrade(req.params.id, req.body));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/trades/:id', (req, res) => {
  if (!deleteTrade(req.params.id)) { res.status(404).json({ error: 'trade introuvable' }); return; }
  res.status(204).end();
});

// Export CSV du journal (amélioration 31/8/2026) — même patron que
// GET /api/screening.csv ci-dessus, mais pas de cache : lit la base
// directement, toujours à jour.
app.get('/api/trades.csv', (req, res) => {
  const cols = ['id', ...TRADE_COLUMNS];
  const escape = (v) => {
    if (v == null) return '';
    const s = String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [cols.join(',')];
  for (const row of listTrades()) {
    lines.push(cols.map((c) => escape(row[c])).join(','));
  }
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="journal-castellana-${Date.now()}.csv"`);
  res.send(lines.join('\n'));
});

// Statistiques post-trade (feature 323) — taux de réussite par bande
// d'indicateur (VIX/RSI/OBV/checklist/corrélation/compte) sur les trades
// clôturés. Voir server/stats.js.
app.get('/api/stats', (req, res) => {
  res.json(computeStats());
});

// Webhook TradingView (feature 323, exploratoire) — reçoit l'alerte du Pine
// Script v5 (design doc) et la journalise dans la table `alerts`. AUCUNE
// exécution : c'est un journal pour rapprocher a posteriori le signal du
// trade réel. Accepte du JSON {ticker, message} ou du texte brut.
app.post('/api/webhook/tradingview', express.text({ type: '*/*' }), (req, res) => {
  let ticker = null;
  let message = null;
  let payload = req.body;
  try {
    const parsed = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    ticker = parsed.ticker ?? parsed.symbol ?? null;
    message = parsed.message ?? parsed.text ?? null;
    payload = JSON.stringify(parsed);
  } catch {
    // Pas du JSON — on garde le texte brut comme message.
    message = typeof req.body === 'string' ? req.body : null;
    payload = typeof req.body === 'string' ? req.body : JSON.stringify(req.body);
  }
  const info = db.prepare('INSERT INTO alerts (ticker, message, payload) VALUES (?, ?, ?)').run(
    ticker ? String(ticker).toUpperCase() : null,
    message,
    payload,
  );
  res.status(201).json({ id: info.lastInsertRowid, ticker, message });
});

app.get('/api/alerts', (req, res) => {
  const alerts = db.prepare('SELECT * FROM alerts ORDER BY recu_le DESC, id DESC LIMIT 200').all();
  res.json({ alerts });
});

// Watchlist éditable (bonus) — CRUD sur l'univers de screening persisté en
// base (server/watchlist.js). Modifier la watchlist invalide le cache de
// screening (sinon on servirait un résultat sur l'ancien univers).
app.get('/api/watchlist', (req, res) => {
  res.json({ watchlist: getWatchlist() });
});

app.post('/api/watchlist', (req, res) => {
  const { ticker, exchange } = req.body;
  if (typeof ticker !== 'string' || !/^[A-Za-z.\-]{1,10}$/.test(ticker)) {
    res.status(400).json({ error: 'ticker invalide' });
    return;
  }
  const watchlist = addToWatchlist(ticker, exchange || 'NASDAQ');
  db.prepare('DELETE FROM cache WHERE key = ?').run(SCREENING_KEY);
  res.status(201).json({ watchlist });
});

app.delete('/api/watchlist/:ticker', (req, res) => {
  if (!removeFromWatchlist(req.params.ticker)) {
    res.status(404).json({ error: 'ticker absent de la watchlist' });
    return;
  }
  db.prepare('DELETE FROM cache WHERE key = ?').run(SCREENING_KEY);
  res.json({ watchlist: getWatchlist() });
});

// Listes personnalisées du Screener (12/9/2026, demande de JP) — en plus de
// « Ma watchlist »/« Univers élargi »/« MAG7 ». CRUD complet, plafond de 50
// titres/liste (server/lists.js, MAX_TICKERS_PER_LIST) pour éviter de
// recréer le bug de sous-requêtes déjà rencontré sur l'univers élargi côté
// cloud — même limite appliquée ici pour un comportement identique entre
// les deux versions.
app.get('/api/lists', (req, res) => {
  res.json({ lists: getLists() });
});

app.post('/api/lists', (req, res) => {
  try {
    const list = createList(String(req.body?.nom || ''));
    res.status(201).json({ list });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.patch('/api/lists/:id', (req, res) => {
  try {
    const list = renameList(Number(req.params.id), String(req.body?.nom || ''));
    if (!list) { res.status(404).json({ error: 'liste introuvable' }); return; }
    res.json({ list });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/lists/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!deleteList(id)) { res.status(404).json({ error: 'liste introuvable' }); return; }
  db.prepare('DELETE FROM cache WHERE key = ?').run(screeningCacheKey(`list:${id}`));
  res.json({ ok: true });
});

app.post('/api/lists/:id/tickers', (req, res) => {
  const id = Number(req.params.id);
  const { ticker, exchange } = req.body || {};
  if (typeof ticker !== 'string' || !/^[A-Za-z.\-]{1,10}$/.test(ticker)) {
    res.status(400).json({ error: 'ticker invalide' });
    return;
  }
  try {
    const list = addTickerToList(id, ticker, exchange || 'NASDAQ');
    db.prepare('DELETE FROM cache WHERE key = ?').run(screeningCacheKey(`list:${id}`));
    res.status(201).json({ list });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/lists/:id/tickers/:ticker', (req, res) => {
  const id = Number(req.params.id);
  const list = removeTickerFromList(id, req.params.ticker);
  if (!list) { res.status(404).json({ error: 'liste introuvable' }); return; }
  db.prepare('DELETE FROM cache WHERE key = ?').run(screeningCacheKey(`list:${id}`));
  res.json({ list });
});

// Filet de sécurité des routes API (feature 351, 7/9/2026).
//
// Sans lui, une requête vers une route /api/ inexistante recevait la page
// d'erreur HTML par défaut d'Express (`<!DOCTYPE html>… Cannot GET /api/x`).
// Le frontend la passait à JSON.parse, qui échouait sur
// « Unexpected token '<', "<!DOCTYPE "... is not valid JSON » — un message
// que personne ne peut relier à sa cause réelle. C'est exactement le
// symptôme rapporté par JP dans l'en-tête et dans la carte Secteurs.
//
// Cas concret qui le déclenche : un onglet resté ouvert sur une version du
// frontend plus récente que le serveur qui tourne (après une mise à jour,
// ou pendant un redémarrage), et qui appelle une route pas encore servie.
//
// --- Alertes de positions (30/9/2026, #379, local) : échéance, prise de profit, stop.
app.get('/api/position-alerts/events', (req, res) => {
  res.json({ events: listPositionEvents(), emailConfigured: emailAvailable() && getAlertEmails().length > 0, autoRunMinutes: settings.listAlerts?.autoRunMinutes ?? 0 });
});
app.post('/api/position-alerts/run', async (req, res) => {
  try { res.json(await runPositionAlerts()); } catch (err) { res.status(err.status || 500).json({ error: err.message }); }
});
app.post('/api/position-alerts/read', (req, res) => { markPositionEventsRead(); res.json({ ok: true }); });

// --- IV Rank réel (30/9/2026, #377, local) : historique d'IV du Radar.
app.get('/api/iv-rank/:ticker', (req, res) => {
  const iv = req.query.iv == null ? null : Number(req.query.iv);
  res.json(ivRankForTicker(String(req.params.ticker).toUpperCase(), Number.isFinite(iv) ? iv : null));
});

// --- Backtest du signal d'alignement (30/9/2026, #375, local) ----------------
app.get('/api/backtest', async (req, res) => {
  const universe = String(req.query.universe || 'watchlist');
  const atrMult = Number(req.query.atrMult ?? 1.5);
  const years = Number(req.query.years ?? 5);
  if (!(atrMult >= 0.5 && atrMult <= 5)) { res.status(400).json({ error: 'atrMult doit être entre 0,5 et 5.' }); return; }
  if (![2, 3, 5].includes(years)) { res.status(400).json({ error: 'years doit valoir 2, 3 ou 5.' }); return; }
  const num = (k, d) => (req.query[k] === undefined || req.query[k] === '' ? d : Number(req.query[k]));
  const feesPct = num('fees', 0.05); const slippagePct = num('slippage', 0.05);
  const regime = req.query.regime === '1'; const regimeSma = num('regimeSma', 200); const vixMax = num('vixMax', 0);
  if (!(feesPct >= 0 && feesPct <= 2) || !(slippagePct >= 0 && slippagePct <= 2)) { res.status(400).json({ error: 'Frais et glissement : entre 0 et 2 % par côté.' }); return; }
  if (!Number.isInteger(regimeSma) || regimeSma < 20 || regimeSma > 300) { res.status(400).json({ error: 'SMA du régime : entier entre 20 et 300.' }); return; }
  if (!(vixMax >= 0 && vixMax <= 100)) { res.status(400).json({ error: 'VIX maximum : entre 0 (désactivé) et 100.' }); return; }
  try { res.json(await runBacktest(universe, { atrMult, years, feesPct, slippagePct, regime, regimeSma, vixMax })); } catch (err) { res.status(err.status || 502).json({ error: err.message }); }
});

// --- Alertes sur les listes (30/9/2026, local) ------------------------------
// Règles par liste (watchlist / MAG7 / liste perso), déclenchées sur TRANSITION,
// évaluées sur ce Mac tant que castellana tourne. Voir server/list-alerts.js.
app.get('/api/list-alerts/rules', (req, res) => {
  res.json({
    rules: listRules(),
    types: Object.entries(ALERT_TYPES).map(([id, t]) => ({ id, label: t.label, defaults: t.defaults })),
    emailConfigured: emailAvailable(),
    autoRunMinutes: settings.listAlerts?.autoRunMinutes ?? 0,
    running: isAlertRunActive(),
  });
});
app.post('/api/list-alerts/rules', (req, res) => {
  try { res.status(201).json({ rule: createRule(req.body || {}) }); } catch (err) { res.status(400).json({ error: err.message }); }
});
app.patch('/api/list-alerts/rules/:id', (req, res) => {
  if (typeof req.body?.enabled !== 'boolean') { res.status(400).json({ error: '« enabled » doit être vrai ou faux.' }); return; } // avant : {} activait la règle
  if (!setRuleEnabled(Number(req.params.id), req.body.enabled)) { res.status(404).json({ error: 'règle introuvable' }); return; }
  res.json({ ok: true });
});
app.delete('/api/list-alerts/rules/:id', (req, res) => {
  if (!deleteRule(Number(req.params.id))) { res.status(404).json({ error: 'règle introuvable' }); return; }
  res.json({ ok: true });
});
app.post('/api/list-alerts/run', async (req, res) => {
  try { res.json(await runListAlerts()); } catch (err) { res.status(err.status || 500).json({ error: err.message }); }
});
app.get('/api/list-alerts/events', (req, res) => {
  res.json({ events: listEvents({ unreadOnly: req.query.unread === '1' }) });
});
app.post('/api/list-alerts/events/read', (req, res) => {
  markEventsRead(Array.isArray(req.body?.ids) ? req.body.ids.map(Number).filter(Number.isInteger) : null);
  res.json({ ok: true });
});

// À placer APRÈS toutes les routes /api et AVANT le démarrage du serveur.

// ---- TradingView en appels LOCAUX (option 2, 7/10/2026) — server/tv-local.js ----
app.get('/api/tradingview/status', (req, res) => res.json({ ...tvLocalStatus(), available: TV_SOURCES, sweep: sweepStatus() }));

app.post('/api/tradingview/connect', async (req, res) => {
  try {
    const origin = `http://${req.headers.host}`;
    res.json({ url: await tvBeginConnect(origin) });
  } catch (err) { res.status(502).json({ error: err.message, code: err.code }); }
});

// Retour OAuth : TradingView redirige le navigateur ici (127.0.0.1 seulement).
app.get('/api/tradingview/callback', async (req, res) => {
  const r = await tvCompleteConnect(req.query);
  res.redirect(`/?tv=${r}`);
});

app.post('/api/tradingview/disconnect', (req, res) => { tvDisconnect(); res.json({ ok: true }); });

app.put('/api/data-source', (req, res) => {
  const source = String(req.body?.source || '');
  if (!TV_SOURCES.includes(source)) { res.status(400).json({ error: 'Source inconnue.' }); return; }
  if (source === 'tradingview' && !tvLocalStatus().connected) {
    res.status(409).json({ error: 'Connecte d\'abord ton compte TradingView.', code: 'TV_NOT_CONNECTED' }); return;
  }
  const changed = tvGetSource() !== source;
  tvSetSource(source);
  if (changed) { // les résultats dérivés ont été calculés avec l'autre source
    // Le dernier balayage S&P 500 (12 minutes de travail) n'est pas un calcul de la source de données : on le garde (audit routes locales, 21/10/2026).
    db.prepare("DELETE FROM cache WHERE (key LIKE 'screening:%' AND key != 'screening:last:sp500') OR key LIKE 'sectors:topresult:%'").run();
  }
  res.json({ source });
});

app.post('/api/sweep/start', async (req, res) => {
  try { await startSweep(); res.json(sweepStatus()); }
  catch (err) { res.status(err.status || 500).json({ error: err.message }); }
});
app.get('/api/sweep/status', (req, res) => res.json(sweepStatus()));
app.get('/api/sweep/sectors', (req, res) => {
  const { found, value, ageSeconds } = readCacheRaw(screeningCacheKey('sp500'));
  if (!found) { res.status(409).json({ error: 'Aucun balayage S&P 500 enregistré.', code: 'NO_SWEEP' }); return; }
  res.json({ sectors: sectorBreakdown(value.rows, SP500.tickers), ageSeconds: Math.round(ageSeconds), universeSize: value.universeSize, retainedSize: value.retainedSize });
});
app.get('/api/sweep/news', (req, res) => res.json({ news: sweepNews(), last: lastSweepInfo(), autoDaily: getAppSettings().sweepAuto }));
app.post('/api/sweep/cancel', (req, res) => res.json({ cancelled: cancelSweep() }));


// Corrélation du candidat avec les positions ouvertes du Journal (#397, 8/10/2026).
// Déclarée AVANT toute route `/api/correlation/:x` de même forme (ordre d'enregistrement).
app.get('/api/correlation/:ticker', async (req, res) => {
  const ticker = req.params.ticker.toUpperCase();
  const window = Math.min(250, Math.max(20, parseInt(req.query.window, 10) || 60));
  const threshold = Math.min(0.99, Math.max(0.1, parseFloat(req.query.threshold) || 0.7));
  try {
    const open = [...new Set(listTrades({ open: true }).map((t) => t.ticker.toUpperCase()))].filter((t) => t !== ticker);
    const candidateBars = await fetchDailyHistory(ticker);
    const positions = [];
    for (const t of open) {
      try { positions.push({ ticker: t, bars: await fetchDailyHistory(t) }); } catch { positions.push({ ticker: t, bars: [] }); }
    }
    res.json({ ticker, ...buildCorrelationReport(candidateBars, positions, { window, threshold }) });
  } catch (err) {
    res.status(502).json({ error: `Corrélation indisponible pour ${ticker} : ${err.message}` });
  }
});

app.use('/api', (req, res) => {
  res.status(404).json({
    error: `Route API inconnue : ${req.method} ${req.originalUrl}`,
    hint: "Le serveur ne connaît pas cette route. Il est probablement plus ancien que la page ouverte dans le navigateur — recharge la page (Cmd/Ctrl+Shift+R), ou relance castellana.",
  });
});

// Toute erreur non interceptée d'une route API doit ressortir en JSON elle
// aussi : le gestionnaire d'erreurs par défaut d'Express renvoie du HTML.
app.use('/api', (err, req, res, next) => { // eslint-disable-line no-unused-vars
  console.error(`[api] erreur non interceptée sur ${req.originalUrl} :`, err);
  // Un corps JSON illisible ou trop gros est une erreur du client (400/413), pas une panne; le détail interne reste dans le journal.
  const status = Number.isInteger(err.status) && err.status >= 400 && err.status < 500 ? err.status : 500;
  res.status(status).json({ error: status === 500 ? 'Erreur interne du serveur' : status === 413 ? 'Corps de requête trop volumineux.' : 'Requête illisible (JSON invalide ?).' });
});

// Purge les entrées de cache expirées au démarrage : sans elle, la table
// grossirait indéfiniment avec les tickers consultés une seule fois.
const purged = purgeExpiredCache();

// Repli de port (7/9/2026) — jusqu'ici, un port 4700 déjà occupé produisait
// un `EADDRINUSE` non intercepté : le process mourait, et sous Windows la
// fenêtre du lanceur se refermait aussitôt, sans que le testeur voie la
// moindre explication. Un autre onglet castellana resté ouvert, ou n'importe
// quel logiciel ayant pris le port, suffisait à rendre l'app « cassée ».
//
// On essaie le port configuré, puis PORT_FALLBACKS. Le port retenu est écrit
// dans data/runtime.json pour que les lanceurs ouvrent le navigateur sur la
// BONNE adresse plutôt que sur 4700 en dur.
const PORT_FALLBACKS = [4711, 4712, 4713, 4714, 4715];

function writeRuntimeInfo(port) {
  try {
    writeFileSync(
      new URL('../data/runtime.json', import.meta.url),
      JSON.stringify({ port, host: settings.host, url: `http://${settings.host}:${port}`, startedAt: new Date().toISOString() }, null, 2),
    );
  } catch {
    // Purement informatif pour les lanceurs — ne jamais empêcher le
    // démarrage du serveur parce qu'un fichier annexe n'a pas pu s'écrire.
  }
}

// Une autre instance de castellana répond-elle déjà sur ce port ? (audit routes locales, 21/10/2026)
async function castellanaRepondSur(port) {
  try {
    const r = await fetch(`http://${settings.host}:${port}/api/health`, { signal: AbortSignal.timeout(1500) });
    const d = await r.json();
    return d && d.status === 'ok' && typeof d.trades === 'number';
  } catch { return false; }
}

function listenWithFallback(ports, secondaire = false) {
  const [port, ...rest] = ports;
  const server = app.listen(port, settings.host, () => {
    writeRuntimeInfo(port);
    if (secondaire) {
      // Deuxième instance (ex. demarrer.command pendant que le service tourne) : ses planificateurs doubleraient les balayages
      // et les courriels d'alertes, dont les gardes « déjà en cours » sont en mémoire par processus. Elle sert la page, rien de plus.
      console.log('Une autre instance de castellana tourne déjà : planificateurs (alertes, scan, balayage) NON démarrés ici.');
    } else {
      startListAlertsScheduler(settings.listAlerts?.autoRunMinutes ?? 0);
      startDailyScanScheduler(settings.dealScanner?.autoDaily === true);
      startSweepScheduler();
    }
    console.log(`castellana — http://${settings.host}:${port}`);
    if (port !== settings.port) {
      console.log(`(le port ${settings.port} était déjà utilisé — repli automatique sur ${port})`);
    }
    if (purged > 0) console.log(`cache : ${purged} entrée(s) expirée(s) purgée(s)`);
  });
  server.on('error', async (err) => {
    if (err.code !== 'EADDRINUSE') throw err;
    const autreInstance = secondaire || await castellanaRepondSur(port);
    if (rest.length === 0) {
      console.error(`Aucun port libre parmi ${settings.port} et ${PORT_FALLBACKS.join(', ')}.`);
      console.error('Fermez l\'autre instance de castellana, ou changez "port" dans settings.json.');
      process.exit(1);
    }
    listenWithFallback(rest, autreInstance);
  });
}

// Garde-fous du processus (audit routes locales, 21/10/2026) : Express 4 ne transmet pas les rejets des handlers async, et Node 22 termine
// le processus sur un rejet non géré (balayage en cours perdu). On journalise et on continue; une exception non interceptée, elle, est
// vraiment fatale : on journalise puis on sort pour que le service relance une instance saine.
process.on('unhandledRejection', (reason) => console.error('[processus] promesse rejetée non gérée :', reason));
process.on('uncaughtException', (err) => { console.error('[processus] exception non interceptée :', err); process.exit(1); });
for (const sig of ['SIGTERM', 'SIGINT']) {
  process.on(sig, () => {
    try { rmSync(new URL('../data/runtime.json', import.meta.url), { force: true }); } catch { /* informatif seulement */ }
    process.exit(0);
  });
}

listenWithFallback([settings.port, ...PORT_FALLBACKS]);
