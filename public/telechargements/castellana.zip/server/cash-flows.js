// server/cash-flows.js — flux de trésorerie par compte (Journal de la Roue, #434) : capital de
// départ, dépôts, retraits, dividendes, autres revenus. Le montant est TOUJOURS positif ; c'est le
// type qui donne le signe (un retrait diminue le compte). Table créée dans db.js (#433).
import { db } from './db.js';
import { isValidTicker, TICKER_ERROR } from './ticker-format.js';

export const CASH_FLOW_TYPES = ['depart', 'depot', 'retrait', 'dividende', 'autre_revenu'];
const COMPTES = ['RRSP', 'margin', 'corporatif'];
const SOURCES = ['saisie', 'import_sheets'];

export function validateCashFlow(d = {}) {
  const errors = [];
  if (!COMPTES.includes(d.compte)) errors.push(`compte doit être l'un de : ${COMPTES.join(', ')}`);
  if (!CASH_FLOW_TYPES.includes(d.type)) errors.push(`type doit être l'un de : ${CASH_FLOW_TYPES.join(', ')}`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(d.date || '')) || !Number.isFinite(Date.parse(d.date))) errors.push('date doit être au format AAAA-MM-JJ');
  if (!(Number(d.montant) > 0)) errors.push('montant doit être positif (le type donne le signe)');
  if (d.ticker != null && d.ticker !== '' && !isValidTicker(String(d.ticker))) errors.push(TICKER_ERROR);
  if (d.cycle_id != null && d.cycle_id !== '' && !(Number.isInteger(Number(d.cycle_id)) && Number(d.cycle_id) > 0)) errors.push('cycle_id invalide');
  if (d.source != null && !SOURCES.includes(d.source)) errors.push(`source doit être l'un de : ${SOURCES.join(', ')}`);
  return errors;
}

function clean(d) {
  return {
    compte: d.compte, date: d.date, type: d.type, montant: Number(d.montant),
    ticker: d.ticker ? String(d.ticker).trim().toUpperCase() : null,
    cycle_id: d.cycle_id == null || d.cycle_id === '' ? null : Number(d.cycle_id),
    notes: d.notes ? String(d.notes) : null,
    source: d.source || 'saisie',
  };
}

export function listCashFlows({ compte } = {}) {
  return compte
    ? db.prepare('SELECT * FROM cash_flows WHERE compte = ? ORDER BY date ASC, id ASC').all(compte)
    : db.prepare('SELECT * FROM cash_flows ORDER BY date ASC, id ASC').all();
}

export function createCashFlow(raw) {
  const errors = validateCashFlow(raw);
  if (errors.length) throw Object.assign(new Error(errors.join(' ')), { status: 400 });
  const d = clean(raw);
  const info = db.prepare('INSERT INTO cash_flows (compte, date, type, montant, ticker, cycle_id, notes, source) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
    .run(d.compte, d.date, d.type, d.montant, d.ticker, d.cycle_id, d.notes, d.source);
  return db.prepare('SELECT * FROM cash_flows WHERE id = ?').get(info.lastInsertRowid);
}

export function deleteCashFlow(id) {
  return db.prepare('DELETE FROM cash_flows WHERE id = ?').run(id).changes > 0;
}
