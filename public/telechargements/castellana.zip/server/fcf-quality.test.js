// Tests de server/fcf-quality.js. Les données sont les valeurs RÉELLES du
// spike du 26/9/2026 (Yahoo, fundamentalsTimeSeries annuel) ; les résultats
// attendus sont calculés à la main, pas recopiés de la sortie du code.

import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeYears, scoreFcfQuality } from './fcf-quality.js';

const row = (date, freeCashFlow, netIncome, totalRevenue, dilutedAverageShares) =>
  ({ date: new Date(date), freeCashFlow, netIncome, totalRevenue, dilutedAverageShares });
const EMPTY = { date: new Date('2021-09-30') }; // 1re ligne toujours vide chez Yahoo

const AAPL = [
  EMPTY,
  row('2022-09-30', 111443e6, 99803e6, 394328e6, 16325819000),
  row('2023-09-30', 99584e6, 96995e6, 383285e6, 15812547000),
  row('2024-09-30', 108807e6, 93736e6, 391035e6, 15408095000),
  row('2025-09-30', 98767e6, 112010e6, 416161e6, 15004697000),
];
const NVDA = [
  EMPTY,
  row('2023-01-31', 3808e6, 4368e6, 26974e6, 25070e6),
  row('2024-01-31', 27021e6, 29760e6, 60922e6, 24940e6),
  row('2025-01-31', 60853e6, 72880e6, 130497e6, 24804e6),
  row('2026-01-31', 96676e6, 120067e6, 215938e6, 24514e6),
];
const SHOP = [
  EMPTY,
  row('2022-12-31', -186e6, -3460e6, 5600e6, 1266268155),
  row('2023-12-31', 905e6, 132e6, 7060e6, 1295511385),
  row('2024-12-31', 1597e6, 2019e6, 8880e6, 1294580139),
  row('2025-12-31', 2007e6, 1231e6, 11556e6, 1303904300),
];

test('la ligne vide de Yahoo est écartée, les exercices sont triés', () => {
  const y = normalizeYears([...AAPL].reverse());
  assert.equal(y.length, 4);
  assert.deepEqual(y.map((r) => r.fiscalYear), ['2022', '2023', '2024', '2025']);
});

test('FCF par action = FCF ÷ actions diluées', () => {
  const y = normalizeYears(AAPL);
  // 111 443 M / 16 325,819 M = 6,8262…
  assert.ok(Math.abs(y[0].fcfPerShare - 6.8262) < 0.001);
});

test('conversion nulle quand le résultat net est négatif', () => {
  const y = normalizeYears(SHOP);
  assert.equal(y[0].conversion, null); // 2022 : résultat net −3,46 G$
});

test("AAPL : FCF/action à peu près plat porté par les rachats → Solide", () => {
  const q = scoreFcfQuality(normalizeYears(AAPL));
  // croissance : 6,83 → 6,58 sur 3 ans ≈ −1,2 %/an → 5 pts ; 4/4 positifs → 25 ;
  // conversion médiane ≈ 1,03+ → 25 ; actions −2 %/an → 25. Total 80/100.
  assert.equal(q.sub.growth.score, 5);
  assert.equal(q.sub.consistency.score, 25);
  assert.equal(q.sub.conversion.score, 25);
  assert.equal(q.sub.dilution.score, 25);
  assert.equal(q.score, 80);
  assert.equal(q.verdict, 'solide');
});

test('NVDA : forte croissance, conversion 0,8x → Solide', () => {
  const q = scoreFcfQuality(normalizeYears(NVDA));
  // conversions 0,87 / 0,91 / 0,83 / 0,81 → médiane 0,85 → 18 ; actions ≈ −0,7 %/an → 18
  assert.equal(q.sub.growth.score, 25);
  assert.equal(q.sub.conversion.score, 18);
  assert.equal(q.sub.dilution.score, 18);
  assert.equal(q.score, 86);
  assert.equal(q.verdict, 'solide');
});

test('SHOP : FCF négatif la 1re année → Mitigé, pas Solide malgré la tendance', () => {
  const q = scoreFcfQuality(normalizeYears(SHOP));
  // départ négatif → 15 (redressement, note explicite) ; 3/4 positifs → 12 ;
  // conversion médiane de [6,86 ; 0,79 ; 1,63] = 1,63 → 25 ; actions +0,97 %/an → 18. 70/100.
  assert.equal(q.sub.growth.score, 15);
  assert.match(q.sub.growth.note, /négatif/);
  assert.equal(q.sub.consistency.score, 12);
  assert.equal(q.score, 70);
  assert.equal(q.verdict, 'mitige');
});

test("historique de moins de 3 exercices → null, jamais un score", () => {
  assert.equal(scoreFcfQuality(normalizeYears(AAPL).slice(0, 2)), null);
  assert.equal(scoreFcfQuality([]), null);
  assert.equal(scoreFcfQuality(undefined), null);
});

test('une entreprise durablement déficitaire est Fragile, sans plantage', () => {
  const y = normalizeYears([
    row('2023-12-31', -50e6, -80e6, 100e6, 100e6),
    row('2024-12-31', -40e6, -70e6, 110e6, 110e6),
    row('2025-12-31', -30e6, -60e6, 120e6, 125e6),
  ]);
  const q = scoreFcfQuality(y);
  assert.equal(q.verdict, 'fragile');
  assert.equal(q.sub.conversion.score, null); // aucun résultat net positif
  assert.equal(q.partial, true);              // total ramené aux 3 sous-scores évaluables
  assert.equal(q.sub.growth.score, 0);
  assert.equal(q.score, 0);
});
