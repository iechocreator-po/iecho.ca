#!/usr/bin/env node
// Crée un compte castellana cloud, ou réinitialise son mot de passe s'il
// existe déjà (upsert — 12/9/2026, JP a voulu remettre "tomate" partout
// après un premier test sur un mot de passe local différent). Pas d'écran
// d'inscription dans l'app : 3 utilisateurs connus (JP, Louis, Guillaume),
// pas un produit public.
//
// Réutilise auth.js (hashPassword) TEL QUEL — écrit avec les seules API Web
// Crypto standard (`crypto.subtle`), disponibles nativement dans Node ≥ 20
// ET dans les Workers, pour que le hachage soit calculé UNE SEULE FOIS,
// identique des deux côtés.
//
// Usage :
//   node scripts/create-user.mjs jp             (contre D1 local, --local)
//   node scripts/create-user.mjs jp --remote     (contre le vrai D1 Cloudflare)
//
// Le mot de passe est saisi en clair dans le terminal (pas d'astérisques) —
// limite assumée pour rester à zéro dépendance ajoutée (un masquage propre
// demanderait un paquet npm comme `prompts`/`inquirer`). Ferme le terminal
// après usage si l'écran est partagé.

import { createInterface } from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { hashPassword } from '../src/auth.js';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));

const args = process.argv.slice(2);
const remote = args.includes('--remote');
// Même règle que POST /api/admin/users (src/routes/admin.js) : converti en minuscules avant validation.
const username = args.find((a) => !a.startsWith('--'))?.trim().toLowerCase();

if (!username || !/^[a-z0-9._-]{2,30}$/.test(username)) {
  console.error('Usage : node scripts/create-user.mjs <nom-utilisateur> [--remote]');
  console.error('Le nom : 2 à 30 caractères parmi lettres, chiffres, point, tiret, tiret bas (majuscules converties en minuscules).');
  process.exit(1);
}

const rl = createInterface({ input: stdin, output: stdout });
const password = await rl.question(`Mot de passe pour "${username}" (saisie visible) : `);
rl.close();

if (!password || password.length < 6) {
  console.error('Mot de passe trop court (minimum 6 caractères).');
  process.exit(1);
}

const { hash, salt } = await hashPassword(password);

// Échappement minimal (doublement des apostrophes, syntaxe SQL standard) —
// suffisant ici : hash/salt sont de l'hexadécimal généré par nous-mêmes,
// seul `username` vient de l'utilisateur (déjà validé par la regex
// ci-dessus, donc sans apostrophe possible).
// UPSERT : un nom déjà pris a son mot de passe RÉINITIALISÉ plutôt que de
// faire échouer le script sur la contrainte UNIQUE — c'est le seul geste
// dont JP dispose pour changer un mot de passe existant (pas d'écran
// "mot de passe oublié" dans l'app).
const sql = `INSERT INTO users (username, password_hash, password_salt) VALUES ('${username}', '${hash}', '${salt}')
  ON CONFLICT(username) DO UPDATE SET password_hash = excluded.password_hash, password_salt = excluded.password_salt;`;

const flag = remote ? '--remote' : '--local';
console.log(`\nCréation/réinitialisation du compte "${username}" (${remote ? 'D1 distant' : 'D1 local'})...`);
const result = spawnSync('npx', ['wrangler', 'd1', 'execute', 'castellana-db', flag, '--command', sql], {
  cwd: ROOT,
  stdio: 'inherit',
});

if (result.status !== 0) {
  console.error('\nÉchec — voir le message de wrangler ci-dessus.');
  process.exit(result.status ?? 1);
}
console.log(`\nCompte "${username}" prêt (${flag}). Sa watchlist par défaut sera semée automatiquement à la première connexion si elle n'existe pas déjà.`);
