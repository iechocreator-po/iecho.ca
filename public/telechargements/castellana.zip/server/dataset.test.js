import test from 'node:test';
import assert from 'node:assert/strict';
import { featuresAt, buildRows, rowsToCsv, splitByDate, ROW_COLUMNS } from './dataset.js';
import { simulateSignal } from './backtest.js';

// Série synthétique : creux, puis rebond qui provoque un premier alignement haussier.
function series(n = 460) {
  const bars = [];
  let p = 100;
  for (let k = 0; k < n; k++) {
    const up = (k >= 150 && k < 250) || (k >= 330 && k < 400);
    p *= up ? 1.006 + 0.002 * Math.sin(k / 3) : 0.994 + 0.002 * Math.sin(k / 3);
    const d = new Date(Date.UTC(2023, 0, 2 + k));
    bars.push({ date: d.toISOString().slice(0, 10), open: p * 0.998, high: p * 1.01, low: p * 0.99, close: p, volume: 1e6 + 1e4 * (k % 7) });
  }
  return bars;
}
const OPTS = { fast: 9, medium: 21, slow: 50, atrMult: 1.5 };

test('buildRows : une ligne par trade, appariée brut/net, colonnes complètes', () => {
  const bars = series();
  const costed = simulateSignal(bars, { ...OPTS, costPct: 0.1 }).trades;
  const gross = simulateSignal(bars, OPTS).trades;
  assert.ok(costed.length > 0, 'la série doit produire au moins un trade');
  const rows = buildRows('TEST', 'Tech', bars, { costed, gross }, {}, { warmup: 0 });
  assert.equal(rows.length, costed.length);
  for (const r of rows) {
    for (const c of ROW_COLUMNS) assert.ok(c in r, `colonne ${c}`);
    assert.ok(r.r_gross >= r.r_net, 'les frais ne peuvent que baisser le R');
    assert.ok(r.signal_date < r.entry_date);
  }
});

test('aucune fuite du futur : tronquer l\'historique après le signal ne change aucune variable', () => {
  const bars = series();
  const trades = simulateSignal(bars, OPTS).trades;
  assert.ok(trades.length > 0);
  for (const t of trades) {
    const full = featuresAt(bars, t.signalIndex);
    const cut = featuresAt(bars.slice(0, t.signalIndex + 1), t.signalIndex);
    assert.deepEqual(cut, full);
  }
});

test('force relative alignée PAR DATE sur SPY (null sans SPY)', () => {
  const bars = series();
  const t = simulateSignal(bars, OPTS).trades[0];
  assert.equal(featuresAt(bars, t.signalIndex).rel_strength_60_pct, null);
  const spy = bars.map((b) => ({ ...b, close: 100 })); // SPY plat : force relative = rendement 60 j du titre
  const f = featuresAt(bars, t.signalIndex, { spy });
  const ret = (bars[t.signalIndex].close / bars[t.signalIndex - 60].close - 1) * 100;
  assert.ok(Math.abs(f.rel_strength_60_pct - ret) < 0.01);
});

test('CSV : valeur absente = cellule vide, jamais 0', () => {
  const csv = rowsToCsv([{ ticker: 'A', sector: 'X', signal_date: '2024-01-02', entry_date: '2024-01-03', rsi: null, r_net: -1, win_1r: 0 }]);
  const [head, line] = csv.trim().split('\n');
  const cols = head.split(','); const cells = line.split(',');
  assert.equal(cells[cols.indexOf('rsi')], '');
  assert.equal(cells[cols.indexOf('r_net')], '-1');
});

test('splitByDate : walk-forward strict, aucune ligne dans les deux jeux', () => {
  const rows = [{ signal_date: '2023-05-01' }, { signal_date: '2024-01-01' }, { signal_date: '2024-06-01' }];
  const { train, test } = splitByDate(rows, '2024-01-01');
  assert.equal(train.length, 1); assert.equal(test.length, 2);
});
