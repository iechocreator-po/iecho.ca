#!/usr/bin/env node
// Migration idempotente (30/9/2026) — connexion TradingView : tv_oauth_clients,
// tv_oauth, user_settings. CREATE TABLE IF NOT EXISTS : rejouable, aucune
// donnée existante touchée. `schema.sql` reste la source de vérité pour une
// installation neuve.
//
// ⚠️ À lancer en --remote AVANT `wrangler deploy` (le code déployé lit ces
// tables) puis vérifier avec sqlite_master — pas sur le seul message de fin.
//
// Usage :
//   node scripts/migrate-tradingview.mjs             (D1 local)
//   node scripts/migrate-tradingview.mjs --remote    (vrai D1)

import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const flag = process.argv.includes('--remote') ? '--remote' : '--local';

function run(sql) {
  const r = spawnSync('npx', ['wrangler', 'd1', 'execute', 'castellana-db', flag, '--command', sql], {
    cwd: ROOT, encoding: 'utf8', stdio: 'inherit',
  });
  if (r.status !== 0) process.exit(r.status || 1);
}

console.log(`Migration TradingView (${flag})…`);
run(`CREATE TABLE IF NOT EXISTS tv_oauth_clients (
  redirect_uri TEXT PRIMARY KEY,
  client_id TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
)`);
run(`CREATE TABLE IF NOT EXISTS tv_oauth (
  session_token TEXT PRIMARY KEY REFERENCES sessions(token) ON DELETE CASCADE,
  client_id TEXT NOT NULL,
  redirect_uri TEXT NOT NULL,
  state TEXT,
  code_verifier TEXT,
  access_token TEXT,
  refresh_token TEXT,
  expires_at INTEGER,
  connected_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
)`);
run(`CREATE TABLE IF NOT EXISTS user_settings (
  user_id INTEGER NOT NULL REFERENCES users(id),
  key TEXT NOT NULL,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, key)
)`);
console.log('OK — tables créées (ou déjà présentes). Vérifier avec sqlite_master avant de déployer.');
