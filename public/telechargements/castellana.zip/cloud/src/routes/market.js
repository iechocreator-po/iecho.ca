// Données de marché pour un titre — portage Cloudflare de server/index.js
// (routes /api/market-data/:ticker, /api/quote/:symbol, /api/labo/:ticker).
//
// Le sidecar Python tradingview-mcp n'est PAS porté : Workers ne peut pas
// lancer de process, et ce composant était déjà optionnel et désactivé par
// défaut côté local depuis le 7/9/2026 (le screening tourne entièrement sur
// les calculs maison Yahoo). RSI/Golden Cross/SMA viennent donc uniquement
// du calcul maison — jamais d'un repli sidecar, qui n'existe plus.

import { getOptionChain, getAnnualizedGrid } from '../lib/options.js';
import { getQuotes, BENCHMARK_SYMBOL } from '../lib/quotes.js';
import { getHomemadeIndicators, fetchDailyHistory, buildCorrelationReport } from '../lib/indicators.js';
import { listTrades } from '../db/trades.js';
import { getFundamentals } from '../lib/fundamentals.js';
import { getFcfQuality } from '../lib/fcf-quality.js';
import { searchSymbols } from '../lib/symbol-search.js';
import { getPreferences, indicatorOptions } from '../db/preferences.js';
import { readCacheRaw } from '../db/cache.js';
import { screeningCacheKey } from '../lib/screening.js';
import { SECTOR_ETF_TO_YAHOO_SECTOR, SECTOR_DEFS, SECTOR_MODES } from '../lib/sectors.js';

async function industryPeerStatsFromScreeningCache(db, userId, industry) {
  if (!industry) return { avgPE: null, peerCount: 0 };
  const { found, value } = await readCacheRaw(db, screeningCacheKey(userId, 'watchlist'));
  if (!found) return { avgPE: null, peerCount: 0 };
  const rows = value.rows.filter((r) => r.industry === industry && r.peRatio != null);
  if (!rows.length) return { avgPE: null, peerCount: 0 };
  const avg = rows.reduce((sum, r) => sum + r.peRatio, 0) / rows.length;
  return { avgPE: avg, peerCount: rows.length };
}

// Médiane du P/S des titres du dernier screening (watchlist) du MÊME secteur Yahoo —
// approximation par pairs, ≥ 3 titres sinon null. Lecture passive du cache.
async function sectorPsFromScreeningCache(db, userId, sector) {
  if (!sector) return { medianPS: null, peerCount: 0 };
  const { found, value } = await readCacheRaw(db, screeningCacheKey(userId, 'watchlist'));
  if (!found) return { medianPS: null, peerCount: 0 };
  const v = value.rows.filter((r) => r.sector === sector && r.priceToSales != null).map((r) => r.priceToSales).sort((a, b) => a - b);
  if (v.length < 3) return { medianPS: null, peerCount: v.length };
  const mid = Math.floor(v.length / 2);
  return { medianPS: v.length % 2 ? v[mid] : (v[mid - 1] + v[mid]) / 2, peerCount: v.length };
}

// P/E moyen du SECTEUR GICS large — portage de server/index.js
// (sectorPeFromCache), même discipline (lecture passive du cache déjà
// rempli par /api/sectors, jamais un fetch forcé ici). 28/9/2026.
async function sectorPeFromCache(db, yahooSector) {
  if (!yahooSector) return null;
  const etfKey = Object.keys(SECTOR_ETF_TO_YAHOO_SECTOR).find((k) => SECTOR_ETF_TO_YAHOO_SECTOR[k] === yahooSector);
  const def = etfKey && SECTOR_DEFS.find((d) => d.key === etfKey);
  if (!def) return null;
  for (const mode of SECTOR_MODES) {
    const { found, value } = await readCacheRaw(db, `sectors:perf:v2:${mode}`);
    if (!found) continue;
    const pe = value[def[mode] ?? def.usd]?.peRatio;
    if (pe != null) return { pe, label: def.label };
  }
  return null;
}

export function registerMarketRoutes(app) {
  // Corrélation du candidat avec les positions ouvertes du Journal DU COMPTE (#397, 8/10/2026).
  app.get('/api/correlation/:ticker', async (c) => {
    const db = c.env.DB;
    const ticker = c.req.param('ticker').toUpperCase();
    const window = Math.min(250, Math.max(20, parseInt(c.req.query('window'), 10) || 60));
    const threshold = Math.min(0.99, Math.max(0.1, parseFloat(c.req.query('threshold')) || 0.7));
    try {
      const trades = await listTrades(db, c.get('userId'), { open: true });
      const open = [...new Set(trades.map((t) => t.ticker.toUpperCase()))].filter((t) => t !== ticker).slice(0, 12); // plafond de sous-requêtes
      const candidateBars = await fetchDailyHistory(db, ticker);
      const positions = [];
      for (const t of open) {
        try { positions.push({ ticker: t, bars: await fetchDailyHistory(db, t) }); } catch { positions.push({ ticker: t, bars: [] }); }
      }
      return c.json({ ticker, ...buildCorrelationReport(candidateBars, positions, { window, threshold }) });
    } catch (err) {
      return c.json({ error: `Corrélation indisponible pour ${ticker} : ${err.message}` }, 502);
    }
  });

  app.get('/api/market-data/:ticker', async (c) => {
    const db = c.env.DB;
    const userId = c.get('userId');
    const ticker = c.req.param('ticker').toUpperCase();
    const prefs = await getPreferences(db, userId);

    const [quotesResult, homemadeResult, fundResult] = await Promise.allSettled([
      getQuotes(db, ['^VIX', ticker, BENCHMARK_SYMBOL]),
      getHomemadeIndicators(db, ticker, indicatorOptions(prefs)),
      getFundamentals(db, ticker, { withVwap: true }),
    ]);

    if (quotesResult.status === 'rejected' && homemadeResult.status === 'rejected' && fundResult.status === 'rejected') {
      return c.json({
        error: 'Yahoo Finance injoignable',
        detail: [quotesResult.reason?.message, homemadeResult.reason?.message, fundResult.reason?.message]
          .filter(Boolean).join(' · '),
      }, 503);
    }

    const quotes = quotesResult.status === 'fulfilled' ? quotesResult.value : new Map();
    const hm = homemadeResult.status === 'fulfilled' ? homemadeResult.value : null;
    const fund = fundResult.status === 'fulfilled' ? fundResult.value : null;
    const psSector = await sectorPsFromScreeningCache(db, userId, fund?.sector);
    const industryStat = fund?.industry ? await industryPeerStatsFromScreeningCache(db, userId, fund.industry) : { avgPE: null, peerCount: 0 };
    const sectorPe = fund?.sector ? await sectorPeFromCache(db, fund.sector) : null;

    return c.json({
      ticker,
      vix: quotes.get('^VIX')?.price ?? null,
      rsi: hm?.rsi ?? null,
      goldenCross: hm?.goldenCross ?? null,
      sma50: hm?.sma50 ?? null,
      sma200: hm?.sma200 ?? null,
      atr: hm?.atr ?? null,
      volumeRatio: hm?.volumeRatio ?? null,
      volumeAvg100: hm?.volumeAvg100 ?? null,
      previousClose: hm?.previousClose ?? null,
      previousCloseDate: hm?.previousCloseDate ?? null,
      volumeSMA20: hm?.volumeSMA20 ?? null,
      changePercent: quotes.get(ticker)?.changePercent ?? null,
      benchmarkSymbol: BENCHMARK_SYMBOL,
      benchmarkChangePercent: quotes.get(BENCHMARK_SYMBOL)?.changePercent ?? null,
      price: quotes.get(ticker)?.price ?? hm?.price ?? fund?.price ?? null,
      sma9: hm?.sma9 ?? null,
      sma21: hm?.sma21 ?? null,
      sma100: hm?.sma100 ?? null,
      smaPeriods: hm?.smaPeriods ?? null,
      rsiPeriod: hm?.rsiPeriod ?? null,
      smaAlignment: hm?.smaAlignment ?? null,
      obv: hm?.obv ?? null,
      obvTrend: hm?.obvTrend ?? null,
      homemadeError: homemadeResult.status === 'rejected' ? homemadeResult.reason.message : null,
      quotesError: quotesResult.status === 'rejected' ? quotesResult.reason.message : null,
      // Le sidecar n'existe plus en cloud — jamais d'erreur pour un
      // composant qui ne peut plus exister dans cette version.
      technicalError: null,
      volume: fund?.volume ?? quotes.get(ticker)?.volume ?? null,
      floatShares: fund?.floatShares ?? null,
      peRatio: fund?.peRatio ?? null,
      priceToSales: fund?.priceToSales ?? null,
      sector: fund?.sector ?? null,
      sectorPS: psSector.medianPS,
      sectorPSPeerCount: psSector.peerCount,
      industry: fund?.industry ?? null,
      industryPE: industryStat.avgPE,
      industryPeerCount: industryStat.peerCount,
      sectorPE: sectorPe?.pe ?? null,
      sectorLabel: sectorPe?.label ?? null,
      pegRatio: fund?.pegRatio ?? null,
      beta: fund?.beta ?? null,
      vwap: fund?.vwap ?? null,
      aboveVwap: fund?.aboveVwap ?? null,
      fundamentalsError: fundResult.status === 'rejected' ? fundResult.reason.message : null,
    });
  });

  // Recherche de symbole par nom (3/10/2026) — voir lib/symbol-search.js.
  app.get('/api/search/symbols', async (c) => {
    try {
      return c.json(await searchSymbols(c.req.query('q'), c.req.query('filter') || 'all'));
    } catch (err) {
      return c.json({ error: 'Recherche Yahoo Finance indisponible', detail: err.message }, 503);
    }
  });

  app.get('/api/quote/:symbol', async (c) => {
    const symbol = c.req.param('symbol').toUpperCase();
    try {
      const quotes = await getQuotes(c.env.DB, [symbol]);
      const q = quotes.get(symbol);
      if (!q) return c.json({ error: `Ticker inconnu de Yahoo Finance : ${symbol}` }, 404);
      return c.json({ symbol, price: q.price, changePercent: q.changePercent });
    } catch (err) {
      return c.json({ error: 'Yahoo Finance injoignable', detail: err.message }, 503);
    }
  });

  // Chaîne d'options (feature #358 v1). `?expiry=AAAA-MM-JJ` (défaut : la plus proche).
  app.get('/api/options/:ticker', async (c) => {
    try {
      return c.json(await getOptionChain(c.env.DB, c.req.param('ticker').toUpperCase(), {
        expiry: c.req.query('expiry') || null, force: c.req.query('force') === 'true',
      }));
    } catch (err) {
      return c.json({ error: err.message }, err.status || 503);
    }
  });

  // Options A (#11, 22/9/2026) — grille de rendement annualisé.
  app.get('/api/options/:ticker/grid', async (c) => {
    try {
      const deltaMin = parseFloat(c.req.query('deltaMin'));
      const deltaMax = parseFloat(c.req.query('deltaMax'));
      const maxExpiries = parseInt(c.req.query('maxExpiries'), 10);
      return c.json(await getAnnualizedGrid(c.env.DB, c.get('userId'), c.req.param('ticker').toUpperCase(), {
        type: c.req.query('type') === 'call' ? 'call' : 'put',
        deltaMin: Number.isFinite(deltaMin) ? deltaMin : 0.15,
        deltaMax: Number.isFinite(deltaMax) ? deltaMax : 0.25,
        maxExpiries: Number.isFinite(maxExpiries) ? maxExpiries : 6,
      }));
    } catch (err) {
      return c.json({ error: err.message }, err.status || 503);
    }
  });

  // Qualité du FCF (26/9/2026) : EPS, FCF, FCF/action + indice. Route non
  // gardée par le flag (comme les autres) — le flag ne masque que la carte.
  app.get('/api/fcf/:ticker', async (c) => {
    const ticker = c.req.param('ticker').toUpperCase();
    try {
      return c.json(await getFcfQuality(c.env.DB, ticker));
    } catch (err) {
      return c.json({ error: `Fondamentaux indisponibles pour ${ticker} : ${err.message}` }, 502);
    }
  });

  app.get('/api/labo/:ticker', async (c) => {
    const db = c.env.DB;
    const userId = c.get('userId');
    const ticker = c.req.param('ticker').toUpperCase();
    const parsePeriod = (raw, fallback) => {
      const n = parseInt(raw, 10);
      return Number.isInteger(n) && n > 0 ? n : fallback;
    };
    const prefs = await getPreferences(db, userId);
    const periods = {
      fast: parsePeriod(c.req.query('smaFast'), prefs.smaFast),
      medium: parsePeriod(c.req.query('smaMedium'), prefs.smaMedium),
      slow: parsePeriod(c.req.query('smaSlow'), prefs.smaSlow),
    };
    const [fundResult, indicResult] = await Promise.allSettled([
      getFundamentals(db, ticker, { withVwap: false }),
      getHomemadeIndicators(db, ticker, { periods, rsiPeriod: prefs.rsiPeriod }),
    ]);
    if (fundResult.status === 'rejected' && indicResult.status === 'rejected') {
      return c.json({ error: 'Yahoo Finance injoignable pour ce titre', detail: fundResult.reason.message }, 503);
    }
    const fund = fundResult.status === 'fulfilled' ? fundResult.value : null;
    const indic = indicResult.status === 'fulfilled' ? indicResult.value : null;
    return c.json({
      ticker,
      price: fund?.price ?? null,
      volume: fund?.volume ?? null,
      beta: fund?.beta ?? null,
      peRatio: fund?.peRatio ?? null,
      industry: fund?.industry ?? null,
      sector: fund?.sector ?? null,
      // Réutilisé par Options A (#10, 22/9/2026) — déjà calculé par
      // getFundamentals(), zéro appel réseau supplémentaire.
      daysToEarnings: fund?.daysToEarnings ?? null,
      earningsDate: fund?.earningsDate ?? null,
      earningsTiming: fund?.earningsTiming ?? null,
      atr: indic?.atr ?? null,
      sma9: indic?.sma9 ?? null,
      sma21: indic?.sma21 ?? null,
      sma100: indic?.sma100 ?? null,
      smaPeriods: indic?.smaPeriods ?? periods,
      smaAlignment: indic?.smaAlignment ?? null,
      obvTrend: indic?.obvTrend ?? null,
      volumeRatio: indic?.volumeRatio ?? null,
      volumeAvg100: indic?.volumeAvg100 ?? null,
      historicalVolatility: indic?.historicalVolatility ?? null,
      fundamentalsError: fundResult.status === 'rejected' ? fundResult.reason.message : null,
      indicatorsError: indicResult.status === 'rejected' ? indicResult.reason.message : null,
    });
  });
}
