// server/option-trades.js — Journal A (22/9/2026) : cycles de la Roue et
// jambes d'options vendues (#4/#5 de la feature vente-de-primes).
//
// Décision confirmée avec JP : marquer un PUT « assigné » crée
// automatiquement une ligne dans le Journal actions (trades) — prix
// d'entrée = strike, taille = contrats×contractSize — et marquer un CALL
// vendu du MÊME cycle « assigné » clôture automatiquement cette ligne (prix
// de sortie = strike), avec le même calcul de R que closeTrade() côté
// navigateur (index.html) : r = (sortie-entrée)/(entrée-stop). Le stop
// initial (obligatoire dans trades) est demandé à l'appelant au moment de
// l'assignation d'un put — jamais inventé.
import { db } from './db.js';
import { isValidTicker, TICKER_ERROR } from './ticker-format.js';
import { tradeIsNonNegative, tradeIsIsoDate } from './trade-rules.js';
import { createTrade, updateTrade, getTrade } from './trades.js';
import { getEffectiveParams } from './labo-params.js';
import { optRoueDeletionPlan } from './options-analytics.js';

const COMPTES = ['RRSP', 'margin', 'corporatif'];
const TYPES = ['put', 'call'];
const STATUTS_OUVERTURE = ['ouvert'];
const STATUTS_CLOTURE = ['expire', 'assigne', 'roule', 'rachete'];
const SOURCES = ['saisie', 'import_sheets'];

function fail(message, status = 400) {
  const err = new Error(message);
  err.status = status;
  return err;
}

function contractSize() {
  const p = getEffectiveParams('roue');
  return (p && p.contractSize) || 100;
}

export function validateOptionTrade(data, { partial = false } = {}) {
  const errors = [];
  const required = ['type', 'ticker', 'compte', 'strike', 'echeance', 'prime_recue', 'date_ouverture'];
  if (!partial) {
    for (const f of required) if (data[f] === undefined || data[f] === null || data[f] === '') errors.push(`${f} est requis`);
  }
  if (data.ticker != null && data.ticker !== '' && !isValidTicker(String(data.ticker))) errors.push(TICKER_ERROR);
  if (data.type != null && !TYPES.includes(data.type)) errors.push(`type doit être l'un de : ${TYPES.join(', ')}`);
  if (data.compte != null && !COMPTES.includes(data.compte)) errors.push(`compte doit être l'un de : ${COMPTES.join(', ')}`);
  if (data.strike != null && !(Number(data.strike) > 0)) errors.push('strike doit être positif');
  if (data.prime_recue != null && !(Number(data.prime_recue) >= 0)) errors.push('prime_recue doit être ≥ 0 (0 = prime nulle réelle, distinct d\'une absence)');
  if (data.contrats !== undefined && !(Number.isInteger(Number(data.contrats)) && Number(data.contrats) > 0)) errors.push('contrats doit être un entier positif');
  // Journal de la Roue (#433) : une commission absente reste NULL (« non renseignée »), jamais 0.
  for (const f of ['commission_ouverture', 'commission_cloture']) {
    if (data[f] != null && data[f] !== '' && !(Number(data[f]) >= 0)) errors.push(`${f} doit être ≥ 0`);
  }
  if (data.source != null && !SOURCES.includes(data.source)) errors.push(`source doit être l'un de : ${SOURCES.join(', ')}`);
  for (const f of ['echeance', 'date_ouverture', 'date_cloture']) {
    if (data[f] != null && data[f] !== '' && !tradeIsIsoDate(data[f])) errors.push(`${f} doit être une date AAAA-MM-JJ`);
  }
  return errors;
}

// ---- Cycles ----

export function createCycle({ ticker, compte, notes }) {
  if (!ticker || !COMPTES.includes(compte)) throw fail('ticker et compte (RRSP/margin/corporatif) sont requis');
  if (!isValidTicker(String(ticker))) throw fail(TICKER_ERROR);
  const info = db.prepare('INSERT INTO option_cycles (ticker, compte, notes) VALUES (?, ?, ?)').run(String(ticker).trim().toUpperCase(), compte, notes || null);
  return getCycle(info.lastInsertRowid);
}

export function listCycles() {
  const cycles = db.prepare('SELECT * FROM option_cycles ORDER BY date_creation DESC').all();
  const legs = db.prepare('SELECT * FROM option_trades ORDER BY date_ouverture ASC, id ASC').all();
  const byCycle = new Map();
  for (const l of legs) {
    if (l.cycle_id == null) continue;
    if (!byCycle.has(l.cycle_id)) byCycle.set(l.cycle_id, []);
    byCycle.get(l.cycle_id).push(l);
  }
  const taille = contractSize();
  return cycles.map((c) => {
    const cycleLegs = byCycle.get(c.id) || [];
    // La prime encaissée à la vente reste acquise quel que soit le
    // dénouement (expiration, assignation, rachat) — on la somme donc sur
    // TOUTES les jambes, pas seulement les closes.
    const primeTotale = cycleLegs.reduce((sum, l) => sum + l.prime_recue * l.contrats * taille, 0);
    return { ...c, legs: cycleLegs, primeTotale };
  });
}

export function getCycle(id) {
  const cycle = db.prepare('SELECT * FROM option_cycles WHERE id = ?').get(id);
  if (!cycle) return null;
  const legs = db.prepare('SELECT * FROM option_trades WHERE cycle_id = ? ORDER BY date_ouverture ASC, id ASC').all(id);
  return { ...cycle, legs };
}

export function updateCycle(id, { statut, notes }) {
  if (statut !== undefined && !['actif', 'clos'].includes(statut)) throw fail('statut de cycle invalide (actif/clos)'); // null refusé aussi : colonne NOT NULL
  if (!getCycle(id)) throw fail('Cycle introuvable', 404);
  const cols = [];
  const vals = [];
  if (statut !== undefined) { cols.push('statut = ?'); vals.push(statut); }
  if (notes !== undefined) { cols.push('notes = ?'); vals.push(notes); }
  if (cols.length) db.prepare(`UPDATE option_cycles SET ${cols.join(', ')} WHERE id = ?`).run(...vals, id);
  return getCycle(id);
}

// ---- Jambes (option_trades) ----

export function createOptionTrade(rawData) {
  const errors = validateOptionTrade(rawData);
  if (errors.length) throw fail(errors.join(' '));
  const data = { ...rawData, ticker: rawData.ticker.trim().toUpperCase(), contrats: rawData.contrats ?? 1, statut: 'ouvert' };
  const cols = ['cycle_id', 'type', 'ticker', 'compte', 'strike', 'echeance', 'contrats', 'prime_recue', 'date_ouverture', 'delta_ouverture', 'iv_ouverture', 'statut', 'commission_ouverture', 'source'].filter((c) => data[c] !== undefined);
  const stmt = db.prepare(`INSERT INTO option_trades (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`);
  const info = stmt.run(...cols.map((c) => data[c]));
  return getOptionTrade(info.lastInsertRowid);
}

export function listOptionTrades({ statut, cycleId } = {}) {
  let sql = 'SELECT * FROM option_trades WHERE 1=1';
  const params = [];
  if (statut) {
    const list = String(statut).split(',').map((s) => s.trim()).filter(Boolean);
    sql += ` AND statut IN (${list.map(() => '?').join(',')})`;
    params.push(...list);
  }
  if (cycleId) { sql += ' AND cycle_id = ?'; params.push(cycleId); }
  sql += ' ORDER BY date_ouverture DESC, id DESC';
  return db.prepare(sql).all(...params);
}

export function getOptionTrade(id) {
  return db.prepare('SELECT * FROM option_trades WHERE id = ?').get(id);
}

export function deleteOptionTrade(id) {
  // Aucune clé étrangère sur roule_vers_id : supprimer une jambe laissait des liens de roulement pendants (audit routes locales, 21/10/2026).
  return db.transaction(() => {
    db.prepare('UPDATE option_trades SET roule_vers_id = NULL WHERE roule_vers_id = ?').run(id);
    return db.prepare('DELETE FROM option_trades WHERE id = ?').run(id).changes > 0;
  })();
}

// Clôture d'une jambe — le cœur de #5. `effect` décrit ce qui s'est
// réellement passé côté Journal actions (aucun effet / création / clôture),
// pour que l'appelant (UI) puisse l'afficher en clair plutôt que de deviner.
export function closeOptionTrade(id, { statut, dateCloture, primeCloture, stopInitial, vixAEntree, rsiAEntree, obvAEntree, commissionCloture, rouleVersId } = {}) {
  const ot = getOptionTrade(id);
  if (!ot) throw fail('Position introuvable', 404);
  if (ot.statut !== 'ouvert') throw fail(`Cette position est déjà « ${ot.statut} »`);
  if (!STATUTS_CLOTURE.includes(statut)) throw fail(`statut doit être l'un de : ${STATUTS_CLOTURE.join(', ')}`);
  if (!dateCloture) throw fail('dateCloture est requise');
  if (!tradeIsIsoDate(dateCloture)) throw fail('dateCloture doit être une date AAAA-MM-JJ');
  // null, '' et [] valent >= 0 en JavaScript : un rachat sans prime était compté à 0 $ (audit routes, 21/10/2026).
  if (statut !== 'expire' && !tradeIsNonNegative(primeCloture)) throw fail('primeCloture (≥ 0) est requise sauf pour une expiration sans valeur');
  // Validé AVANT toute écriture — un put assigné sans stop valide ne doit
  // jamais laisser la position bloquée en « assigne » sans position créée
  // (bug réel trouvé en testant : l'UPDATE partait avant ce contrôle).
  if (ot.type === 'put' && statut === 'assigne' && !(Number(stopInitial) > 0)) {
    throw fail('stopInitial (> 0) est requis pour créer la position résultant de l\'assignation d\'un put');
  }
  if (commissionCloture != null && commissionCloture !== '' && !(Number(commissionCloture) >= 0)) throw fail('commissionCloture doit être ≥ 0');
  if (rouleVersId != null && statut !== 'roule') throw fail('rouleVersId n\'a de sens que pour une jambe roulée');

  // Colonnes #433 écrites seulement si fournies (même code que la version cloud, où la colonne
  // peut manquer tant que scripts/migrate-roue.mjs n'a pas tourné).
  const sets = ['statut = ?', 'date_cloture = ?', 'prime_cloture = ?'];
  const vals = [statut, dateCloture, statut === 'expire' ? 0 : primeCloture];
  if (commissionCloture != null && commissionCloture !== '') { sets.push('commission_cloture = ?'); vals.push(Number(commissionCloture)); }
  if (rouleVersId != null) { sets.push('roule_vers_id = ?'); vals.push(Number(rouleVersId)); }
  // UNE transaction (audit routes, 21/10/2026) : la clôture et la position qui en découle réussissent ensemble ou pas du tout;
  // et la clôture ne vaut que si la jambe est encore ouverte (deux requêtes simultanées ne créent pas deux actions).
  const effect = db.transaction(() => {
  const maj = db.prepare(`UPDATE option_trades SET ${sets.join(', ')} WHERE id = ? AND statut = 'ouvert'`).run(...vals, id);
  if (maj.changes === 0) throw fail('Cette position vient d\'être clôturée', 409);

  let effect = { type: 'aucun' };

  if (ot.type === 'put' && statut === 'assigne') {
    const trade = createTrade({
      date_entree: dateCloture,
      compte: ot.compte,
      ticker: ot.ticker,
      prix_entree: ot.strike,
      taille_position: ot.contrats * contractSize(),
      stop_initial: Number(stopInitial),
      vix_a_entree: vixAEntree ?? null,
      rsi_a_entree: rsiAEntree ?? null,
      obv_a_entree: obvAEntree ?? null,
      option_cycle_id: ot.cycle_id ?? null,
    });
    effect = { type: 'trade_cree', tradeId: trade.id };
  } else if (ot.type === 'call' && statut === 'assigne' && ot.cycle_id != null) {
    const open = db.prepare('SELECT * FROM trades WHERE option_cycle_id = ? AND date_sortie IS NULL ORDER BY id DESC LIMIT 1').get(ot.cycle_id);
    if (open) {
      const risque = open.prix_entree - open.stop_initial;
      const rRealise = risque !== 0 ? (ot.strike - open.prix_entree) / risque : null;
      const resultat = ot.strike >= open.prix_entree ? 'gagnant' : 'perdant';
      updateTrade(open.id, { date_sortie: dateCloture, prix_sortie: ot.strike, r_realise: rRealise, resultat });
      effect = { type: 'trade_ferme', tradeId: open.id, rRealise, resultat };
    } else {
      effect = { type: 'aucune_position_liee' };
    }
  }

  return effect;
  })();

  return { optionTrade: getOptionTrade(id), effect };
}

// #7 — alertes de roulement sur les positions ouvertes. Séparé dans son
// propre module (server/option-alerts.js) pour ne dépendre d'aucun appel
// réseau ici — voir ce fichier pour l'implémentation.

// Suppression multiple (onglet Roue) : applique optRoueDeletionPlan dans UNE transaction, dans
// l'ordre des clés étrangères (mouvements et actions avant les cycles). Renvoie le plan exécuté.
export function deleteRoueEntries({ legIds = [], flowIds = [] } = {}) {
  if (!Array.isArray(legIds) || !Array.isArray(flowIds)) throw fail('legIds et flowIds doivent être des listes');
  if (legIds.length + flowIds.length === 0) throw fail('Rien à supprimer');
  if (legIds.length + flowIds.length > 500) throw fail('500 entrées au plus par suppression');
  const plan = optRoueDeletionPlan({
    legIds, flowIds,
    legs: db.prepare('SELECT id, cycle_id, roule_vers_id FROM option_trades').all(),
    cycles: db.prepare('SELECT id FROM option_cycles').all(),
    stock: db.prepare('SELECT id, option_cycle_id FROM trades WHERE option_cycle_id IS NOT NULL').all(),
    flows: db.prepare('SELECT id, cycle_id FROM cash_flows').all(),
  });
  const del = (table, ids) => { for (const id of ids) db.prepare(`DELETE FROM ${table} WHERE id = ?`).run(id); };
  db.transaction(() => {
    del('cash_flows', plan.flowIds);
    del('trades', plan.stockIds);
    for (const id of plan.rollRefs) db.prepare('UPDATE option_trades SET roule_vers_id = NULL WHERE id = ?').run(id);
    del('option_trades', plan.legIds);
    del('option_cycles', plan.cycleIds);
  })();
  return plan;
}
