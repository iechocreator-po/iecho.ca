// Réglages textuels par utilisateur (voir schema.sql). Aujourd'hui : la source
// des données de marché, 'yahoo' (défaut) ou 'tradingview'.

export const DATA_SOURCES = ['yahoo', 'tradingview'];
export const DEFAULT_DATA_SOURCE = 'yahoo';

export async function getDataSource(db, userId) {
  const r = await db.prepare("SELECT value FROM user_settings WHERE user_id = ? AND key = 'dataSource'").bind(userId).first();
  return r && DATA_SOURCES.includes(r.value) ? r.value : DEFAULT_DATA_SOURCE;
}

export async function setDataSource(db, userId, value) {
  if (!DATA_SOURCES.includes(value)) throw new Error(`Source inconnue : « ${value} ».`);
  await db.prepare(
    `INSERT INTO user_settings (user_id, key, value) VALUES (?, 'dataSource', ?)
     ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')`,
  ).bind(userId, value).run();
}
