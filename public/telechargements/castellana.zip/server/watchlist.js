// Univers de titres pour l'écran de sélection (screening).
// Base : les titres suivis activement par JP
// (design_assistant_swing_trading.md section 1, 12 titres). Complété par 8
// grands noms tech/IA liquides du même univers pour atteindre 20 — choix
// de Claude (22/7/2026).
//
// Cette liste ne sert plus que de SEED : au premier démarrage, si la table
// `watchlist` (db.js) est vide, elle y est insérée. Ensuite la source de
// vérité est la base, éditable via l'UI / les routes /api/watchlist (bonus).
// Éditer ce tableau ne change donc rien une fois la base semée — pour
// repartir de zéro, supprimer data/castellana.sqlite (recréée au démarrage).

import { db } from './db.js';

export const SEED_WATCHLIST = [
  // Suivis par JP
  { ticker: 'MSFT', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'META', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'GOOG', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'AMZN', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'AMD', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'ADBE', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'PYPL', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'RDDT', exchange: 'NYSE', source: 'jp' },
  { ticker: 'JD', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'SMCI', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'ASML', exchange: 'NASDAQ', source: 'jp' },
  { ticker: 'CRWV', exchange: 'NASDAQ', source: 'jp' },
  // Complément (Claude, 22/7/2026)
  { ticker: 'AAPL', exchange: 'NASDAQ', source: 'claude' },
  { ticker: 'NVDA', exchange: 'NASDAQ', source: 'claude' },
  { ticker: 'TSLA', exchange: 'NASDAQ', source: 'claude' },
  { ticker: 'AVGO', exchange: 'NASDAQ', source: 'claude' },
  { ticker: 'CRM', exchange: 'NYSE', source: 'claude' },
  { ticker: 'ORCL', exchange: 'NYSE', source: 'claude' },
  { ticker: 'PLTR', exchange: 'NYSE', source: 'claude' },
  { ticker: 'NFLX', exchange: 'NASDAQ', source: 'claude' },
  // Repère diversifié (demande de JP, 31/8/2026) — XEQT (iShares Core
  // Equity ETF Portfolio, FNB mondial ultra-diversifié) pour comparer un
  // titre individuel à un panier ultra-diversifié, PAS pour combler les
  // trous sectoriels du P/E industrie / PEG moyen (aucun sector/industry
  // chez Yahoo pour ce FNB). Ticker Yahoo réel : XEQT.TO (TSX) — "XEQT"
  // seul ne résout pas. RSI/Golden Cross indisponibles (tradingview-mcp ne
  // résout pas ce symbole, voir CLAUDE.md) — le reste (prix, force
  // relative, P/E, SMA/ATR/OBV/volume maison) fonctionne normalement.
  { ticker: 'XEQT.TO', exchange: 'TSX', source: 'jp' },
];

// Sème la table watchlist depuis SEED_WATCHLIST si elle est vide. Idempotent.
export function seedWatchlistIfEmpty() {
  const { count } = db.prepare('SELECT COUNT(*) AS count FROM watchlist').get();
  if (count > 0) return;
  const insert = db.prepare('INSERT INTO watchlist (ticker, exchange, source) VALUES (?, ?, ?)');
  const tx = db.transaction((rows) => {
    for (const r of rows) insert.run(r.ticker, r.exchange, r.source);
  });
  tx(SEED_WATCHLIST);
}

export function getWatchlist() {
  return db.prepare('SELECT ticker, exchange, source FROM watchlist ORDER BY source, ticker').all();
}

export function addToWatchlist(ticker, exchange = 'NASDAQ') {
  const t = ticker.toUpperCase();
  db.prepare(
    'INSERT INTO watchlist (ticker, exchange, source) VALUES (?, ?, ?) ON CONFLICT(ticker) DO UPDATE SET exchange = excluded.exchange'
  ).run(t, exchange, 'user');
  return getWatchlist();
}

export function removeFromWatchlist(ticker) {
  return db.prepare('DELETE FROM watchlist WHERE ticker = ?').run(ticker.toUpperCase()).changes > 0;
}
