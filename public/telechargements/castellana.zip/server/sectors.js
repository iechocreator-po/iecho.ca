// Performance et P/E moyen par secteur — carte "Performance des secteurs" de
// l'écran de sélection (29/8/2026, demande de JP, inspirée d'un tableau de
// performance sectorielle vu ailleurs). Univers : les 11 ETF SPDR Select
// Sector (State Street) — même famille que SPY, déjà utilisé partout
// ailleurs dans ce projet comme indice de référence (server/tradingview.js).
//
// Une seule requête Yahoo Finance légère par ETF (`yahooFinance.quote()`,
// pas `quoteSummary`) donne à la fois la performance du jour
// (`regularMarketChangePercent`) et le P/E trailing de l'ETF
// (`trailingPE`) — contrairement aux titres individuels (fundamentals.js),
// pas besoin d'un second appel pour le VWAP ici. Le "P/E moyen" du secteur
// est donc le P/E réel de l'ETF sectoriel lui-même (déjà une moyenne
// pondérée de marché sur ses constituants, calculée par le fournisseur de
// l'ETF) — PAS une approximation par pairs comme le "P/E industrie" du
// screening (voir server/index.js, section dédiée du CLAUDE.md) : ce champ-ci
// est un vrai agrégat de marché, pas construit maison.
//
// Sélecteur USD/CAD (2/9/2026, demande de JP) — voir SECTOR_DEFS ci-dessous.
// Une version "CAD couverte contre le risque de change" a été envisagée
// mais abandonnée : vérifié en direct que les 11 ETF sectoriels BMO n'ont
// PAS de version couverte listée sur Yahoo (les 11 tickers `.F.TO` testés
// échouent tous), contrairement au S&P 500 qui, lui, a une vraie version
// couverte (ZUE.TO) — mais un secteur seul sur onze n'aurait pas justifié
// un 3e mode. Le dropdown reste donc à 2 choix : USD / CAD (non couvert).

import YahooFinance from 'yahoo-finance2';
import { withRetry, mapWithConcurrency } from './fetch-retry.js';
import { cached, TTL } from './cache.js';

const yahooFinance = new YahooFinance({ suppressNotices: ['yahooSurvey'] });

// `key` reste toujours le ticker USD, stable quel que soit le mode devise
// affiché — c'est lui qui indexe SECTOR_ETF_TO_YAHOO_SECTOR et
// SECTOR_TOP_CANDIDATES plus bas, pour n'avoir qu'une seule table de
// correspondance peu importe la devise choisie à l'écran.
//
// Tickers CAD (BMO) vérifiés en direct sur Yahoo Finance le 2/9/2026
// (yahooFinance.quote()) — tous résolvent sauf le cas Immobilier noté
// ci-dessous. Fournis par JP à partir de la famille BMO "ZXLx" (même
// famille de nommage que XEQT.TO déjà dans la watchlist).
export const SECTOR_DEFS = [
  { key: 'XLK', label: 'Technologie', usd: 'XLK', cad: 'ZXLK.TO' },
  { key: 'XLY', label: 'Conso. discr.', usd: 'XLY', cad: 'ZXLY.TO' },
  { key: 'XLI', label: 'Industriel', usd: 'XLI', cad: 'ZXLI.TO' },
  { key: 'XLF', label: 'Finance', usd: 'XLF', cad: 'ZXLF.TO' },
  { key: 'XLU', label: 'Services publics', usd: 'XLU', cad: 'ZXLU.TO' },
  { key: 'XLV', label: 'Santé', usd: 'XLV', cad: 'ZXLV.TO' },
  // ZXRE.TO (nommage "ZXLx" attendu) ne résout PAS sur Yahoo — l'alternative
  // que JP avait mentionnée, ZRE.TO (BMO Equal Weight REITs Index ETF,
  // famille de nommage différente), résout bien et est utilisée à la place.
  { key: 'XLRE', label: 'Immobilier', usd: 'XLRE', cad: 'ZRE.TO' },
  { key: 'XLP', label: 'Conso. de base', usd: 'XLP', cad: 'ZXLP.TO' },
  { key: 'XLE', label: 'Énergie', usd: 'XLE', cad: 'ZXLE.TO' },
  { key: 'XLC', label: 'Services de comm.', usd: 'XLC', cad: 'ZXLC.TO' },
  { key: 'XLB', label: 'Matériaux', usd: 'XLB', cad: 'ZXLB.TO' },
];

export const BENCHMARK_DEFS = { key: 'SPY', label: 'S&P 500', usd: 'SPY', cad: 'ZSP.TO' };
// 2e ligne de référence (11/10/2026, demande de JP) : le S&P 500 ÉQUIPONDÉRÉ. Comparé à SPY (pondéré par
// la capitalisation), il montre si la hausse vient des grandes capitalisations seulement. Aucun équivalent
// TSX : en mode CAD la ligne reste RSP (US), et le libellé le dit. Tableau seulement, pas le graphique.
export const EQUAL_WEIGHT_DEF = { key: 'RSP', label: 'S&P 500 équipondéré', usd: 'RSP', cad: 'RSP' };

export const SECTOR_MODES = ['usd', 'cad'];

// Grands indices régionaux + dollar US — refonte "analyse de marché élargie"
// (11/9/2026, demande de JP). Le sélecteur USD/CAD devient un sélecteur de
// PLACE DE COTATION ("ETF référence US" vs "ETF Équivalent TSX"), et couvre
// désormais ces 6 lignes en plus des 11 secteurs GICS. Chaque ticker a été
// vérifié en direct (quote() ET chart(), le second nécessaire à l'historique
// du graphique) avant intégration — deux des tickers fournis par JP ne
// résolvaient PAS sur Yahoo Finance et ont été remplacés par un candidat
// réel, même geste que ZXRE.TO → ZRE.TO le 2/9/2026 :
//   - Europe (CAD) : `FIE` seul n'existe pas → `VE.TO` (Vanguard FTSE
//     Developed Europe All Cap, non couvert, même nature que VGK/EZU).
//   - Japon (CAD) : `XJP.TO` n'existe pas → `ZJPN.TO` (BMO Japan Index ETF,
//     non couvert).
// Pour les catégories où JP donnait deux tickers US au choix, le plus
// liquide (volume moyen 3 mois, mesuré) a été retenu : VXUS>ACWX (5,4M vs
// 1,8M), VGK>EZU (2,0M vs 0,86M), EEM>VWO (22,7M vs 7,5M), FXI>MCHI (21,4M
// vs 2,6M).
// DXY et Chine n'ont AUCUN équivalent TSX (vérifié — aucun ticker `.TO`
// plausible ne résout) : `cad: null` n'est pas un oubli, c'est vérifié et
// JP a confirmé que c'est acceptable — voir resolveMarketTicker() ci-dessous
// pour le repli honnête (jamais une ligne US présentée comme canadienne).
export const MARKET_INDEX_DEFS = [
  { key: 'DXY', label: 'Corrélation avec le USD ($DXY)', usd: 'DX-Y.NYB', cad: null },
  { key: 'WORLDEXUS', label: 'Monde hors USA', usd: 'VXUS', cad: 'XEF.TO' },
  { key: 'EUROPE', label: 'Europe', usd: 'VGK', cad: 'VE.TO' },
  { key: 'JAPAN', label: 'Japon', usd: 'EWJ', cad: 'ZJPN.TO' },
  { key: 'EM', label: 'Marchés émergents', usd: 'EEM', cad: 'XEC.TO' },
  { key: 'CHINA', label: 'Chine', usd: 'FXI', cad: null },
];

// Fonction PURE (testable, contrairement au reste réseau de ce fichier) qui
// décide quel ticker interroger pour une catégorie de MARKET_INDEX_DEFS.
// `usedFallback: true` signale qu'aucun équivalent TSX n'existe et que la
// ligne US est utilisée à sa place — le frontend doit alors le dire
// explicitement (légende/tooltip), jamais faire passer cette ligne pour la
// version canadienne.
export function resolveMarketTicker(def, mode) {
  if (mode === 'usd' || !def.cad) {
    return { ticker: def.usd, usedFallback: mode === 'cad' && !def.cad };
  }
  return { ticker: def.cad, usedFallback: false };
}

// Mapping ETF secteur → nom de secteur GICS large tel que renvoyé par Yahoo
// Finance (`summaryProfile.sector`, fundamentals.js) — sert à agréger le PEG
// moyen des titres de la watchlist par secteur (feature "PEG moyen",
// 30/8/2026) et, depuis le 2/9/2026, à construire les listes "titres du
// secteur" (SECTOR_TOP_CANDIDATES ci-dessous). Indexé par `key` (toujours le
// ticker USD), pas par le ticker réellement affiché — reste correct peu
// importe le mode devise choisi. Vérifié en direct sur des titres connus de
// chaque secteur (ex. XOM→"Energy", NEE→"Utilities", PLD→"Real Estate",
// LIN→"Basic Materials", UNH→"Healthcare", HON→"Industrials",
// PG→"Consumer Defensive") — les noms Yahoo diffèrent parfois du nom de
// l'ETF SPDR (ex. "Consumer Cyclical" chez Yahoo = "Consumer Discretionary"
// côté SPDR/XLY), c'est la même catégorie sous deux conventions de nommage
// différentes.
export const SECTOR_ETF_TO_YAHOO_SECTOR = {
  XLK: 'Technology',
  XLY: 'Consumer Cyclical',
  XLI: 'Industrials',
  XLF: 'Financial Services',
  XLU: 'Utilities',
  XLV: 'Healthcare',
  XLRE: 'Real Estate',
  XLP: 'Consumer Defensive',
  XLE: 'Energy',
  XLC: 'Communication Services',
  XLB: 'Basic Materials',
};

// Titres "les plus performants du secteur" (feature top 30 par secteur,
// 2/9/2026) — liste CURATÉE par secteur, pas une requête de marché en
// direct. Décision prise avec JP après l'échec d'un spike sur l'endpoint
// screener personnalisé de Yahoo Finance (`v1/finance/screener` hors
// `/predefined/saved`) : 429 systématique même avec le crumb/cookie déjà
// valide, alors que le screener PRÉDÉFINI (day_gainers, etc., déjà exposé
// par yahoo-finance2) répond normalement avec les mêmes identifiants — tout
// indique un endpoint réservé aux utilisateurs connectés de Yahoo Finance,
// pas un simple rate-limit. Comme documenté dans le CLAUDE.md racine
// (leçon valencia/idealista), on ne force pas ce genre de barrière.
//
// À la place : même principe que la watchlist principale
// (server/watchlist.js) — une liste à la main de titres liquides et
// connus par secteur, classés par performance du jour au moment de la
// requête (getTopMoversForSector ci-dessous), pas figée dans le temps.
// Chaque ticker de cette liste a été VÉRIFIÉ EN DIRECT le 2/9/2026 contre
// la vraie classification `summaryProfile.sector` de Yahoo Finance (pas
// seulement une hypothèse) — plusieurs candidats initiaux ont été écartés
// à cette étape : ADP et PARA sont classés "Technology" chez Yahoo (pas
// dans leur secteur "attendu") ; AVY/PKG/IP/BALL (emballage) sont classés
// "Consumer Cyclical" plutôt que "Basic Materials" ; HES/CTRA/IPG ne
// résolvent plus du tout (probablement des fusions/acquisitions récentes).
// Ces titres ont été retirés plutôt que gardés avec une classification
// fausse. Les comptes par secteur varient donc naturellement (16 à 20) —
// Matériaux et Énergie/Comm. ont des univers plus restreints, ce qui est
// une réalité de la taille de ces secteurs, pas un bug : le nombre réel de
// candidats est toujours exposé (`totalCandidates`), jamais masqué derrière
// un "top 30" qui laisserait croire à un univers plus large qu'il ne l'est.
export const SECTOR_TOP_CANDIDATES = {
  XLK: ['AAPL', 'MSFT', 'NVDA', 'AVGO', 'ORCL', 'CRM', 'ADBE', 'AMD', 'CSCO', 'ACN', 'IBM', 'TXN', 'QCOM', 'INTC', 'NOW', 'PANW', 'MU', 'LRCX', 'KLAC', 'AMAT'],
  XLY: ['AMZN', 'TSLA', 'HD', 'MCD', 'NKE', 'LOW', 'SBUX', 'BKNG', 'TJX', 'CMG', 'MAR', 'ORLY', 'YUM', 'ROST', 'GM', 'F', 'RCL', 'HLT', 'EBAY', 'ABNB'],
  XLI: ['CAT', 'HON', 'UNP', 'RTX', 'BA', 'DE', 'LMT', 'GE', 'UPS', 'NOC', 'ETN', 'ITW', 'EMR', 'CSX', 'WM', 'GD', 'FDX', 'PH', 'NSC'],
  XLF: ['JPM', 'V', 'MA', 'BAC', 'WFC', 'GS', 'MS', 'SPGI', 'AXP', 'C', 'BLK', 'SCHW', 'PGR', 'CB', 'ICE', 'CME', 'USB', 'PNC', 'TFC'],
  XLU: ['NEE', 'DUK', 'SO', 'D', 'AEP', 'EXC', 'SRE', 'XEL', 'PEG', 'ED', 'WEC', 'ES', 'EIX', 'PPL', 'AEE', 'FE', 'DTE', 'CMS', 'ATO', 'CNP'],
  XLV: ['UNH', 'JNJ', 'LLY', 'ABBV', 'MRK', 'PFE', 'TMO', 'ABT', 'DHR', 'BMY', 'AMGN', 'MDT', 'ISRG', 'GILD', 'CVS', 'ELV', 'VRTX', 'CI', 'ZTS', 'SYK'],
  XLRE: ['PLD', 'AMT', 'EQIX', 'PSA', 'O', 'WELL', 'SPG', 'DLR', 'CCI', 'VICI', 'AVB', 'EQR', 'IRM', 'CBRE', 'SBAC', 'EXR', 'VTR', 'MAA', 'ESS', 'ARE'],
  XLP: ['PG', 'KO', 'PEP', 'WMT', 'COST', 'PM', 'MO', 'MDLZ', 'CL', 'TGT', 'KMB', 'GIS', 'STZ', 'SYY', 'KDP', 'KHC', 'HSY', 'MKC', 'CHD', 'CLX'],
  XLE: ['XOM', 'CVX', 'COP', 'EOG', 'SLB', 'MPC', 'PSX', 'WMB', 'OXY', 'VLO', 'KMI', 'OKE', 'BKR', 'HAL', 'DVN', 'FANG', 'TRGP', 'EQT'],
  XLC: ['META', 'GOOGL', 'GOOG', 'NFLX', 'DIS', 'CMCSA', 'T', 'VZ', 'TMUS', 'CHTR', 'EA', 'TTWO', 'WBD', 'OMC', 'LYV', 'MTCH', 'FOXA', 'NWSA'],
  XLB: ['LIN', 'SHW', 'ECL', 'APD', 'FCX', 'NEM', 'NUE', 'DOW', 'DD', 'PPG', 'VMC', 'MLM', 'ALB', 'CTVA', 'IFF', 'CE'],
};

// Seuils du mode "filtré" (exclut les micro-caps peu liquides) — dupliqués
// de config.js (CFG.sectorTop), même limitation de module que SCORE_BANDS/
// SCREEN_FILTERS dans server/index.js. Cohérent avec le rejet déjà
// documenté d'un scan générique "top gainers" ramenant des micro-caps
// spéculatives (voir CLAUDE.md racine).
export const SECTOR_TOP_FILTERS = {
  marketCapMin: 2_000_000_000,
  volumeMin: 1_000_000,
};

// Performance + P/E de TOUS les ETF en UNE requête groupée (`quote()`
// accepte un tableau) — c'étaient 12 appels séquentiels espacés de 150 ms
// jusqu'au 7/9/2026, soit ~2,5 s pour une carte chargée à chaque ouverture
// de page. Un ticker que Yahoo ne résout pas est simplement absent de la
// réponse : il ressort avec `error` rempli, jamais avec des zéros.
async function quoteBatch(tickers) {
  const raw = await withRetry(`cotations sectorielles (${tickers.length} ETF)`, () =>
    yahooFinance.quote([...new Set(tickers)]));
  const rows = Array.isArray(raw) ? raw : [raw];
  const out = new Map();
  for (const q of rows) {
    if (!q?.symbol) continue;
    out.set(q.symbol, {
      changePercent: q.regularMarketChangePercent ?? null,
      peRatio: q.trailingPE ?? null,
    });
  }
  return out;
}

// Variation sur N jours CALENDAIRES (pas de séances de bourse) — dernière
// clôture connue vs la clôture la plus récente à `days` jours ou plus dans
// le passé (approximation usuelle : « il y a une semaine » retombe sur le
// vendredi si le jour exact n'était pas un jour de bourse). Réutilise le
// même historique que le graphique (fetchDailyCloses, cache
// `sectors:history:<ticker>`, TTL.HISTORY) : aucun appel réseau
// supplémentaire quand l'historique est déjà en cache (28/9/2026, demande de
// JP — colonnes « Performance (semaine) »/« Performance (mois) » du tableau
// sectoriel).
export function pctChangeOverDays(history, days) {
  if (!history || history.length < 2) return null;
  const last = history[history.length - 1];
  if (last.close == null) return null;
  const cutoff = new Date(last.date).getTime() - days * 24 * 3600 * 1000;
  let past = null;
  for (let i = history.length - 1; i >= 0; i--) {
    if (new Date(history[i].date).getTime() <= cutoff) { past = history[i]; break; }
  }
  if (!past || past.close == null) return null;
  return ((last.close - past.close) / past.close) * 100;
}

export async function getSectorPerformance({ mode = 'usd' } = {}) {
  const benchmarkTicker = BENCHMARK_DEFS[mode] ?? BENCHMARK_DEFS.usd;
  const tickers = SECTOR_DEFS.map((def) => def[mode] ?? def.usd);
  const equalWeightTicker = EQUAL_WEIGHT_DEF[mode] ?? EQUAL_WEIGHT_DEF.usd;
  const allTickers = [...tickers, benchmarkTicker, equalWeightTicker];
  const [quotes, histories] = await Promise.all([
    cached(
      `sectors:perf:v2:${mode}`,
      TTL.SECTORS,
      async () => Object.fromEntries(await quoteBatch(allTickers)),
    ),
    // Même cache que le graphique (fetchDailyCloses, définie plus bas —
    // hoisting de la déclaration de fonction) : la première ouverture de
    // l'onglet le peuple pour les deux, les suivantes ne font plus aucun
    // appel réseau pour cette partie.
    mapWithConcurrency(allTickers, async (t) => [t, await fetchDailyCloses(t).catch(() => [])], { limit: 6 }),
  ]);
  const historyByTicker = new Map(histories);
  const pick = (ticker) => quotes[ticker] ?? null;
  const build = (key, ticker, label) => {
    const q = pick(ticker);
    const hist = historyByTicker.get(ticker) || [];
    return q
      ? {
        key, ticker, label, changePercent: q.changePercent,
        weekChangePercent: pctChangeOverDays(hist, 7),
        monthChangePercent: pctChangeOverDays(hist, 30),
        peRatio: q.peRatio, error: null,
      }
      : {
        key, ticker, label, changePercent: null, weekChangePercent: null, monthChangePercent: null,
        peRatio: null, error: `Yahoo Finance n'a pas renvoyé de cotation pour ${ticker}`,
      };
  };
  return {
    sectors: SECTOR_DEFS.map((def) => build(def.key, def[mode] ?? def.usd, def.label)),
    benchmark: build(BENCHMARK_DEFS.key, benchmarkTicker, BENCHMARK_DEFS.label),
    equalWeight: build(EQUAL_WEIGHT_DEF.key, equalWeightTicker, EQUAL_WEIGHT_DEF.label + (mode === 'cad' ? ' (US — pas d\'équivalent TSX)' : '')),
  };
}

// Historique quotidien pour le line graph de performance sectorielle
// (29/8/2026, demande de JP — période sélectionnable 1 semaine à 12 mois,
// défaut 12 mois). Un seul appel `yahooFinance.chart()` par ETF récupère
// ~13 mois de barres quotidiennes (marge au-delà de 12 mois pour couvrir le
// calendrier boursier) ; la normalisation en % depuis le début de la période
// choisie et le découpage par période se font côté frontend (sliceAndNormalize
// dans index.html) — pas de refetch à chaque changement de période.
const HISTORY_LOOKBACK_DAYS = 385;

async function fetchDailyCloses(ticker) {
  return cached(`sectors:history:${ticker}`, TTL.HISTORY, async () => {
    const now = new Date();
    const start = new Date(now.getTime() - HISTORY_LOOKBACK_DAYS * 24 * 3600 * 1000);
    const chart = await withRetry(`historique sectoriel ${ticker}`, () =>
      yahooFinance.chart(ticker, { period1: start, period2: now, interval: '1d' }));
    return chart.quotes
      .filter((q) => q.close != null)
      .map((q) => ({ date: q.date.toISOString().slice(0, 10), close: q.close }));
  });
}

export async function getSectorHistory({ mode = 'usd', concurrency = 6 } = {}) {
  const benchmarkTicker = BENCHMARK_DEFS[mode] ?? BENCHMARK_DEFS.usd;
  const load = async (key, ticker, label, extra = {}) => {
    try {
      return { key, ticker, label, history: await fetchDailyCloses(ticker), error: null, ...extra };
    } catch (err) {
      return { key, ticker, label, history: [], error: err.message, ...extra };
    }
  };
  const equalWeightTicker = EQUAL_WEIGHT_DEF[mode] ?? EQUAL_WEIGHT_DEF.usd;
  const [sectors, benchmark, markets, equalWeight] = await Promise.all([
    mapWithConcurrency(SECTOR_DEFS, (def) => load(def.key, def[mode] ?? def.usd, def.label), { limit: concurrency }),
    load(BENCHMARK_DEFS.key, benchmarkTicker, BENCHMARK_DEFS.label),
    mapWithConcurrency(MARKET_INDEX_DEFS, (def) => {
      const { ticker, usedFallback } = resolveMarketTicker(def, mode);
      return load(def.key, ticker, def.label, { usedFallback });
    }, { limit: concurrency }),
    load(EQUAL_WEIGHT_DEF.key, equalWeightTicker, EQUAL_WEIGHT_DEF.label, { usedFallback: mode === 'cad' }),
  ]);
  return { sectors, benchmark, markets, equalWeight };
}

// « Titres les plus performants du secteur » vivait ici jusqu'au 11/9/2026,
// sous la forme d'un simple classement par variation du jour (un
// quoteSummary par titre, aucun indicateur). JP a demandé que ce tableau
// porte LES MÊMES COLONNES que le screening : la fonction a donc déménagé
// dans server/screening.js (`buildSectorScreening`), qui fait passer les
// candidats du secteur par le pipeline complet plutôt que d'en recopier la
// vingtaine de champs ici. SECTOR_TOP_CANDIDATES et SECTOR_TOP_FILTERS
// restent définis dans ce fichier et sont consommés là-bas.
//
// Note historique conservée parce qu'elle explique une contrainte disparue :
// l'ancienne version évitait délibérément tout appel d'indicateur pour ne
// pas re-déclencher le rate-limit de `coin_analysis` (sidecar TradingView).
// Cette contrainte n'existe plus — les indicateurs sont calculés maison
// depuis l'historique Yahoo depuis le 7/9/2026.
