// Tests des fonctions pures de server/deal-scanner.js (Radar, 22/9/2026) :
// firstExpiryInWindow/isEarningsExcluded/scoreChainContracts/applyDiversityCap.
// Le scan complet (runDealScan) fait de vrais appels réseau — vérifié en
// direct, pas ici (même discipline que le reste du projet).
import test from 'node:test';
import assert from 'node:assert/strict';
import { firstExpiryInWindow, isEarningsExcluded, scoreChainContracts, applyDiversityCap, hasWeeklyExpirations } from './deal-scanner.js';

test('firstExpiryInWindow : première échéance dans [dteMin, dteMax]', () => {
  const exps = [{ date: '2026-10-01', dte: 5 }, { date: '2026-10-20', dte: 30 }, { date: '2026-11-10', dte: 50 }];
  assert.equal(firstExpiryInWindow(exps, 25, 45).date, '2026-10-20');
  assert.equal(firstExpiryInWindow(exps, 60, 90), null);
  assert.equal(firstExpiryInWindow([], 25, 45), null);
});

test('isEarningsExcluded : résultats avant l\'échéance → exclu', () => {
  assert.equal(isEarningsExcluded(10, 30), true); // résultats dans 10j, échéance dans 30j → exclu
  assert.equal(isEarningsExcluded(40, 30), false); // résultats après l'échéance → OK
  assert.equal(isEarningsExcluded(null, 30), false); // pas de donnée → jamais exclu sur du vide
  assert.equal(isEarningsExcluded(-2, 30), false); // résultats déjà passés (négatif) → pas un risque futur
});

test('scoreChainContracts : un contrat sans marché exploitable n\'est jamais persisté', () => {
  const chain = {
    ticker: 'TEST', price: 100, expiry: '2026-10-20', dte: 30,
    puts: [{ strike: 95, bid: null, ask: null, iv: 0.3, openInterest: 100, volume: 50 }],
    calls: [],
  };
  const rows = scoreChainContracts(chain, { secteur: 'tech', riskFreeRate: 0.04, historicalVolatility: 0.25, daysToEarnings: null });
  assert.deepEqual(rows, []);
});

test('scoreChainContracts : un contrat exploitable produit une ligne par mode (vente + achat)', () => {
  const chain = {
    ticker: 'TEST', price: 100, expiry: '2026-10-20', dte: 30,
    puts: [{ strike: 90, bid: 1.5, ask: 1.6, iv: 0.30, openInterest: 500, volume: 100 }],
    calls: [],
  };
  const rows = scoreChainContracts(chain, { secteur: 'tech', riskFreeRate: 0.04, historicalVolatility: 0.25, daysToEarnings: null });
  assert.equal(rows.length, 2);
  assert.deepEqual(rows.map((r) => r.mode).sort(), ['achat', 'vente']);
  assert.equal(rows[0].ticker, 'TEST');
  assert.equal(rows[0].excluMotif, null);
});

test('scoreChainContracts : résultats avant échéance → excluMotif renseigné, ligne quand même conservée pour audit', () => {
  const chain = {
    ticker: 'TEST', price: 100, expiry: '2026-10-20', dte: 30,
    puts: [{ strike: 90, bid: 1.5, ask: 1.6, iv: 0.30, openInterest: 500, volume: 100 }],
    calls: [],
  };
  const rows = scoreChainContracts(chain, { secteur: 'tech', riskFreeRate: 0.04, historicalVolatility: 0.25, daysToEarnings: 10 });
  assert.ok(rows.length > 0);
  assert.ok(rows.every((r) => r.excluMotif === 'resultats_avant_echeance'));
});

test('scoreChainContracts : fondamentaux en échec -> résultats inconnus, exclu (inconnu n\'est pas « aucun résultat prévu »)', () => {
  const chain = {
    ticker: 'TEST', price: 100, expiry: '2026-10-20', dte: 30,
    puts: [{ strike: 90, bid: 1.5, ask: 1.6, iv: 0.30, openInterest: 500, volume: 100 }],
    calls: [],
  };
  const base = { secteur: 'tech', riskFreeRate: 0.04, historicalVolatility: 0.25, daysToEarnings: null };
  const rows = scoreChainContracts(chain, { ...base, earningsUnknown: true });
  assert.ok(rows.length > 0 && rows.every((r) => r.excluMotif === 'resultats_inconnus'), 'écartés par défaut quand la date des résultats est inconnue');
  const sain = scoreChainContracts(chain, { ...base, earningsUnknown: false });
  assert.ok(sain.every((r) => r.excluMotif === null), 'aucun résultat prévu (donnée saine) : jamais exclu');
});

test('applyDiversityCap : plafonne le nombre de résultats par secteur', () => {
  const rows = [
    { secteur: 'tech', ticker: 'A' }, { secteur: 'tech', ticker: 'B' }, { secteur: 'tech', ticker: 'C' },
    { secteur: 'energie', ticker: 'D' },
  ];
  const capped = applyDiversityCap(rows, { maxPerSector: 2 });
  assert.deepEqual(capped.map((r) => r.ticker), ['A', 'B', 'D']);
});

test('applyDiversityCap : un secteur absent (null) est groupé mais toujours plafonné', () => {
  const rows = [{ secteur: null, ticker: 'A' }, { secteur: null, ticker: 'B' }, { secteur: null, ticker: 'C' }];
  const capped = applyDiversityCap(rows, { maxPerSector: 1 });
  assert.deepEqual(capped.map((r) => r.ticker), ['A']);
});

test('applyDiversityCap : respecte l\'ordre d\'entrée (déjà trié par score avant l\'appel)', () => {
  const rows = [{ secteur: 'a', ticker: 'meilleur' }, { secteur: 'a', ticker: 'pire' }];
  const capped = applyDiversityCap(rows, { maxPerSector: 1 });
  assert.deepEqual(capped.map((r) => r.ticker), ['meilleur']);
});

test('hasWeeklyExpirations : au moins deux échéances dans les 21 prochains jours', () => {
  // Titre hebdo : vendredis successifs.
  assert.equal(hasWeeklyExpirations([{ dte: 3 }, { dte: 10 }, { dte: 17 }, { dte: 24 }]), true);
  // Mensuel seulement : une échéance proche, la suivante à ~4 semaines.
  assert.equal(hasWeeklyExpirations([{ dte: 12 }, { dte: 40 }, { dte: 68 }]), false);
  // Échéance du jour (dte 0) ou liste vide : jamais un « hebdo » inventé.
  assert.equal(hasWeeklyExpirations([{ dte: 0 }, { dte: 30 }]), false);
  assert.equal(hasWeeklyExpirations([]), false);
  assert.equal(hasWeeklyExpirations(null), false);
});
