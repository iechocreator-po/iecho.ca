// server/option-alerts.js — Journal A (#7, 22/9/2026) : alertes de
// roulement sur les positions ouvertes. Recharge la chaîne courante
// (cache déjà en place, options:v1:<ticker>:<expiry>) pour chaque position
// ouverte, retrouve le contrat au même strike, et compare contre des
// seuils explicites — jamais un score opaque. Un contrat introuvable
// (échéance passée, illiquide) produit une alerte explicite « impossible
// d'évaluer », jamais une ligne silencieusement ignorée.
import { listOptionTrades } from './option-trades.js';
import { getOptionChain } from './options.js';
import { getEffectiveParams } from './labo-params.js';

const DTE_SEUIL_JOURS = 7;

function dteRestant(echeance) {
  const ms = new Date(`${echeance}T00:00:00Z`).getTime() - Date.now();
  return Math.ceil(ms / 86400000);
}

export async function getRollAlerts() {
  const open = listOptionTrades({ statut: 'ouvert' });
  const alerts = [];
  for (const ot of open) {
    const dte = dteRestant(ot.echeance);
    const params = getEffectiveParams('roue') || { profitTakeMin: 50, profitTakeMax: 80 };
    let chain = null;
    let error = null;
    try {
      chain = await getOptionChain(ot.ticker, { expiry: ot.echeance });
    } catch (err) {
      error = err.message;
    }
    const contract = chain ? (ot.type === 'call' ? chain.calls : chain.puts).find((c) => c.strike === ot.strike) : null;

    if (dte <= DTE_SEUIL_JOURS && dte >= 0) {
      alerts.push({
        optionTradeId: ot.id, ticker: ot.ticker, type: ot.type, strike: ot.strike, echeance: ot.echeance,
        raison: `Échéance dans ${dte} jour${dte > 1 ? 's' : ''} (≤ ${DTE_SEUIL_JOURS}) — décide de laisser aller, racheter ou rouler.`,
      });
    }
    if (!chain || !contract) {
      alerts.push({
        optionTradeId: ot.id, ticker: ot.ticker, type: ot.type, strike: ot.strike, echeance: ot.echeance,
        raison: `Impossible d'évaluer cette position aujourd'hui (${error || 'contrat introuvable dans la chaîne courante'}).`,
      });
      continue;
    }
    const rachatEstime = contract.ask ?? contract.last;
    if (rachatEstime != null && ot.prime_recue > 0) {
      const captureRestante = (rachatEstime / ot.prime_recue) * 100;
      if (captureRestante <= (100 - params.profitTakeMin)) {
        alerts.push({
          optionTradeId: ot.id, ticker: ot.ticker, type: ot.type, strike: ot.strike, echeance: ot.echeance,
          raison: `Seuil de prise de profit atteint : rachat estimé à ${rachatEstime.toFixed(2)} $ contre ${ot.prime_recue.toFixed(2)} $ encaissés (${(100 - captureRestante).toFixed(0)} % de la prime déjà captée, cible ${params.profitTakeMin}-${params.profitTakeMax} %).`,
        });
      }
    }
  }
  return alerts;
}
