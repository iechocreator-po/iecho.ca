# castellana — Assistant de swing trading

Outil personnel d'aide à la décision pour le swing trading sur actions
(tech/IA principalement). Ce n'est **ni un robot de trading, ni un
générateur de conseils financiers** : il n'envoie jamais d'ordre et ne
recommande rien à un tiers. C'est un assistant de screening, de calcul de
taille de position, de journal de trades et d'exploration d'options.

> Nom de code interne : **castellana**. Le dossier s'appelle
> `trading-assistant` par convention. `CLAUDE.md` est le journal de bord
> détaillé (décisions, historique, limites connues) — utile pour comprendre
> *pourquoi* un choix a été fait, pas nécessaire pour faire tourner l'app.

## Deux façons de l'utiliser

| | **Version locale** | **Version cloud** |
|---|---|---|
| Où | Sur ta machine (`http://127.0.0.1:4700`) | Cloudflare Workers + D1 (`https://castellana.iechocreator.workers.dev`) |
| Comptes | Aucun, mono-utilisateur | Comptes serveur : mot de passe **ou** « Connexion facile par courriel » (lien à usage unique) |
| Données | SQLite locale (`data/`) | D1, isolées par utilisateur (journal, watchlist, préférences) |
| Code | `server/` + `index.html` | `cloud/` (Hono) + `cloud/public/` |

Les deux partagent la même logique de calcul et le même frontend. La version
cloud est la cible à terme ; la locale reste utilisable en parallèle.

## Ce que fait l'app — six onglets, plus trois onglets « avancés »

1. **Secteurs** — performance des 11 secteurs (ETF US ou équivalents TSX),
   graphique comparé à des indices régionaux et au dollar US, et un clic sur
   un secteur affiche ses titres les plus performants.
2. **Screener** — un *générateur de positions* : univers (watchlist, MAG7,
   univers élargi de 210 titres, listes personnalisées) noté sur deux axes,
   **Setup** (ça se déclenche maintenant ?) et **Contexte** (le titre vaut-il
   la peine ?), avec stop, taille et charge de portefeuille par candidat.
3. **Fiche de trade** — taille de position, stop (ATR), charge de risque,
   cibles (multiples de R et extensions Fibonacci), checklist pré-trade avec
   verdicts calculés (jamais cochée automatiquement).
4. **Journal & stats** — chaque trade avec ses indicateurs à l'entrée ; export
   CSV ; mesure après coup si un indicateur a réellement aidé.
5. **Labo** — stratégies d'options pas à pas (La Roue, Debit Spreads, Poor
   Man's Covered Call) avec des valeurs **toutes paramétrables**, persistées
   par utilisateur et exportables.
6. **Options** — chaîne d'options d'un titre : calls et puts par échéance,
   bid/ask, volume, open interest, IV et **delta estimé** (Black-Scholes à
   partir de l'IV — Yahoo ne le fournit pas), filtres optionnels, comparaison
   « Labo vs marché », export CSV, vue agrandie. Données **différées d'environ
   15 minutes**.

**Onglets avancés**, cachés par défaut derrière des feature flags (activables
par compte depuis bilbao en cloud, dans `settings.json` en local) :

- **Options A** (`options_a_tab`) — la chaîne enrichie pour la vente de primes :
  rendement annualisé, capital requis, probabilité d'assignation, alerte
  résultats/dividende, grille sur plusieurs échéances, calculateur de
  roulement, et un **détecteur de meilleurs deals** (achat ou vente, puts et
  calls) fondé sur trois sous-scores transparents : liquidité, valorisation de
  l'IV, rendement ou levier.
- **Journal A** (`journal_a_tab`) — screener de primes, calculateur « vendre
  une option », cycles de la Roue (l'assignation d'un put ou d'un call agit
  sur le Journal actions), alertes de roulement.
- **Radar** (`radar_tab`, **local uniquement**) — scanne les 210 titres curés
  pour trouver les meilleurs deals d'options du moment (échéance 25-45 jours).
  Exclut les contrats dont l'échéance dépasse les résultats, plafonne le
  classement par secteur. Un scan complet prend environ 20 secondes.

Dans **Réglages** : périodes des moyennes et du RSI, guide de concepts de
trading (derrière un feature flag), aide TradingView, dépannage.

Principe transversal : **une valeur qu'on ne peut pas calculer s'affiche
« — » ou « non renseigné », jamais 0** ; une estimation est toujours
étiquetée comme telle.

## Architecture

```mermaid
flowchart LR
    UI["Dashboard\n(index.html — HTML/CSS/JS, aucun build)"]
    subgraph Local
        BACK["Backend Express\nserver/ — :4700"]
        DB[("SQLite\ndata/castellana.sqlite")]
        RADAR["Radar\nserver/deal-scanner.js\n(local uniquement)"]
    end
    subgraph Cloudflare
        WORK["Worker Hono\ncloud/"]
        D1[("D1")]
        TEL["telemetry-worker/\n(collecte des événements)"]
    end
    YAHOO[("Yahoo Finance\n(gratuit, sans clé)")]
    BIL["bilbao\n(cockpit local)"]

    UI <--> BACK
    UI <--> WORK
    BACK <--> DB
    BACK --> RADAR
    RADAR --> YAHOO
    RADAR --> DB
    WORK <--> D1
    BACK --> YAHOO
    WORK --> YAHOO
    UI -. "événements" .-> TEL
    BIL -. "admin (Basic Auth)" .-> WORK
    BIL -. "consultation / suppression" .-> TEL
```

| Pièce | Techno | Rôle |
|---|---|---|
| **Dashboard** | `index.html` + `js/`, vanilla, zéro build | L'interface (copie dans `cloud/public/`) |
| **Backend local** | Node ≥ 20 + Express + `better-sqlite3` | Sert le dashboard, calcule **tous** les indicateurs depuis Yahoo, journal, cache, et le scanner **Radar** (aucun pendant cloud : le plan gratuit Cloudflare limite à 50 sous-requêtes par invocation) |
| **Worker cloud** | Cloudflare Workers + Hono + D1 (`cloud/`) | Même API, multi-utilisateur, authentification serveur (PBKDF2, sessions, lien par courriel via Resend) |
| **Télémétrie** | Worker + D1 (`telemetry-worker/`) | Collecte des événements des testeurs ; tableau de bord protégé par Basic Auth |
| **Launcher** | Node (`launcher/`, :4750) | Relance castellana automatiquement s'il tombe (local) |
| **Sidecar MCP** | Python (`tradingview-mcp`) | **Optionnel et désactivé par défaut** — rien d'indispensable |

Aucun compte TradingView ni clé API n'est nécessaire.

## Installer et lancer (version locale)

👉 **[`SETUP.md`](SETUP.md)** : pas-à-pas Windows et macOS.

Le plus court : décompresser `castellana.zip`, puis double-cliquer
`demarrer.command` (macOS, **clic droit → Ouvrir** la première fois) ou
`demarrer.bat` (Windows).

Pour qui a déjà tout installé :

```bash
npm run doctor   # vérifie Node, dépendances, base, port, Yahoo — et dit quoi faire
npm start        # l'adresse s'affiche (repli automatique si 4700 est pris)
npm test         # tests automatisés (node:test, aucune dépendance)
```

Version cloud (développement) :

```bash
cd cloud
npm install
npx wrangler dev --local     # Worker + D1 locale sur http://127.0.0.1:8787
npx wrangler deploy          # déploiement (compte Cloudflare requis)
```

Le témoin de statut de l'en-tête indique en direct ce qui tourne ; un point
**gris** signifie *désactivé* (normal), seul un point **rouge** est une vraie
panne, avec sa cause en clair.

## Stack technique

- **Frontend** : HTML/CSS/JS vanilla, zéro framework, zéro build.
- **Backend local** : Node.js + Express + `better-sqlite3` (seul module natif —
  voir `SETUP.md` si son installation échoue sur Windows).
- **Cloud** : Cloudflare Workers, Hono, D1, Web Crypto (mots de passe PBKDF2).
- **Données de marché** : `yahoo-finance2`, source unique. Réessai et
  temporisation sur chaque appel externe, cache persistant (SQLite / D1).
- **Design** : copie vendorée du design system du portfolio (`design-system/`),
  dont les boutons à effet `.ds-btn--shine/--pulse/--orbit`.
- **Tests** : `npm test` — calcul d'indicateurs, sizing, scoring, préférences,
  paramètres du Labo, chaînes d'options, scoring des deals, scanner Radar ; un test de parité vérifie que les
  copies du frontend dans `cloud/public/` ne dérivent pas.

## Organisation du dépôt

```
index.html, js/, config.js   frontend (source) — copie dans cloud/public/
server/                      backend local (routes, indicateurs, screening, options…)
cloud/                       Worker Cloudflare (src/, public/, schema.sql, scripts/)
telemetry-worker/            collecteur de télémétrie (Worker + D1)
launcher/                    outil de relance
design-system/               tokens + composants (copie vendorée)
scripts/                     doctor, empaquetage, synchronisation des copies cloud
```

Quand un fichier de `js/` ou `index.html` change, **répercuter dans
`cloud/public/`** (`npm run sync:cloud` pour les copies générées ; le test de
parité échoue si une copie dérive).

## Portée et limites

- **N'envoie jamais d'ordre** à un courtier — aide à la décision et
  journalisation uniquement.
- Les données dépendent d'API publiques **non officielles** (Yahoo Finance) :
  elles peuvent être différées, refusées (limite 429, surtout depuis les
  adresses de Cloudflare) ou changer sans préavis. Aucune donnée d'options
  n'est fournie avec le delta : il est **estimé**.
- Rien n'a été testé sur une vraie machine Windows (scripts vérifiés par
  lecture de code).
- `CLAUDE.md` à la racine documente l'historique et les décisions ; à lire
  avant de contribuer.
