// Cache persistant en D1 — portage Cloudflare de server/cache.js (local,
// better-sqlite3). Même schéma, même logique de TTL — voir CLAUDE.md du
// produit, section « Refonte de fiabilité », pour l'historique de ce cache
// (F8 de l'audit du 7/9/2026) et l'avertissement sur les TTL courts :
// la dernière barre d'un historique quotidien est celle du jour en cours,
// et `quoteSummary` mêle dans un seul objet des champs trimestriels et
// intrajournaliers. Un cache figé serait pire qu'être lent.
//
// Différence structurelle avec la version locale : `db` (le binding D1,
// `c.env.DB`) n'existe que dans le contexte d'une requête Workers — il n'y
// a pas de singleton de module possible ici. Chaque fonction le reçoit donc
// en paramètre, et l'API D1 (`prepare().bind().first()/.all()/.run()`) est
// asynchrone là où better-sqlite3 était synchrone — tous les appelants
// (quotes.js, fundamentals.js, indicators.js, sectors.js) awaitent déjà ces
// fonctions puisque `cached()` était déjà async côté local.
//
// Table `cache` : global, PAS par utilisateur — une cotation ou un
// historique sont les mêmes pour tout le monde, un cache par utilisateur
// serait un gaspillage sans bénéfice réel.

import { AsyncLocalStorage } from 'node:async_hooks';

// ---- Mode démo (2/10/2026) ------------------------------------------------
// Pour une démonstration, on veut limiter les appels à Yahoo (limites 429 sur
// les adresses de Cloudflare, plafond de sous-requêtes). Le navigateur envoie
// `X-Demo-Mode: 1` quand l'interrupteur de Réglages → Technique est ON ; pour
// CETTE requête seulement :
//   - une entrée de cache est considérée fraîche jusqu'à DEMO_MAX_AGE (4 h),
//     même si son TTL normal est de 1 à 20 minutes ;
//   - si Yahoo échoue, `cached()` sert la dernière valeur connue, même vieille,
//     plutôt qu'une erreur.
// Les prix servis sont donc figés : l'interface le dit (bandeau). Les clés
// techniques (jeton Yahoo, pauses après un 429) ne sont JAMAIS prolongées :
// une pause de 45 s qui durerait 4 h bloquerait tout.
const demoStorage = new AsyncLocalStorage();
export const DEMO_MAX_AGE = 4 * 3600;
export const demoActive = () => demoStorage.getStore() === true;
const demoEligible = (key) => !/cooldown|cookiejar/.test(key);
// TTL effectif d'une lecture de cache faite par une route (readCacheRaw).
export const demoTtl = (ttlSeconds) => (demoActive() ? Math.max(ttlSeconds, DEMO_MAX_AGE) : ttlSeconds);
const freshLimit = (key, ttlSeconds) => (demoActive() && demoEligible(key) ? Math.max(ttlSeconds, DEMO_MAX_AGE) : ttlSeconds);

export async function withDemo(c, next) {
  if (c.req.header('X-Demo-Mode') !== '1') return next();
  await demoStorage.run(true, next);
  c.header('X-Demo-Mode', 'on');
}

export const TTL = {
  QUOTE: 60,
  OPTIONS: 120,        // chaîne d'options : différée ~15 min chez Yahoo, 2 min suffisent
  HISTORY: 15 * 60,
  FUNDAMENTALS: 15 * 60,
  SECTORS: 15 * 60,
  SCREENING: 20 * 60,
  SLOW: 24 * 3600,
};

export async function readCache(db, key) {
  const row = await db.prepare('SELECT payload, fetched_at, ttl_seconds FROM cache WHERE key = ?').bind(key).first();
  if (!row) return { hit: false, value: null };
  const ageSeconds = (Date.now() - row.fetched_at) / 1000;
  // `>=` et non `>` : voir server/cache.js — un TTL de 0 servirait sinon
  // l'entrée tant qu'on la relit dans la même milliseconde.
  if (ageSeconds >= freshLimit(key, row.ttl_seconds)) return { hit: false, value: null };
  try {
    return { hit: true, value: JSON.parse(row.payload), ageSeconds };
  } catch {
    await db.prepare('DELETE FROM cache WHERE key = ?').bind(key).run();
    return { hit: false, value: null };
  }
}

// Lecture SANS contrôle de TTL — sert au dernier screening en cache (export
// CSV, « P/E industrie » d'un ticker hors watchlist), même périmé, plutôt
// que de répondre « aucune donnée » ou de refetcher à l'insu de l'utilisateur.
export async function readCacheRaw(db, key) {
  const row = await db.prepare('SELECT payload, fetched_at, ttl_seconds FROM cache WHERE key = ?').bind(key).first();
  if (!row) return { found: false, value: null, ageSeconds: null };
  try {
    return { found: true, value: JSON.parse(row.payload), ageSeconds: (Date.now() - row.fetched_at) / 1000 };
  } catch {
    await db.prepare('DELETE FROM cache WHERE key = ?').bind(key).run();
    return { found: false, value: null, ageSeconds: null };
  }
}

export async function writeCache(db, key, value, ttlSeconds) {
  await db.prepare(`
    INSERT INTO cache (key, payload, fetched_at, ttl_seconds) VALUES (?, ?, ?, ?)
    ON CONFLICT(key) DO UPDATE SET payload = excluded.payload, fetched_at = excluded.fetched_at, ttl_seconds = excluded.ttl_seconds
  `).bind(key, JSON.stringify(value), Date.now(), ttlSeconds).run();
}

// Lecture GROUPÉE (12/9/2026 — bug « univers élargi » signalé par JP : 0
// retenu sur 218/219, cause réelle "Too many subrequests by single Worker
// invocation"). Chaque `readCache()` est un aller-retour D1 = 1
// sous-requête Workers ; un screening élargi (219 titres) en enchaînait
// ~219 rien que pour LIRE le cache, avant même d'appeler Yahoo. Ici, UNE
// requête = 1 sous-requête pour N clés. Retourne une Map clé → valeur (déjà
// JSON.parse), les clés absentes ou périmées ne sont simplement pas dans la
// Map — jamais une valeur `undefined` qui se confondrait avec « jamais mis
// en cache ».
//
// ⚠️ Piège trouvé EN TESTANT (pas en relisant le code) : un `WHERE key IN
// (?,?,?...)` avec un `?` par clé a d'abord semblé la solution évidente,
// mais échoue sur D1 dès qu'on dépasse ~270 clés — "too many SQL variables"
// (SQLITE_ERROR), reproduit en direct sur les 219+ clés d'un screening
// élargi. `json_each()` contourne la limite de VARIABLES en passant les
// clés comme UN SEUL paramètre (une chaîne JSON), pas un paramètre par clé
// — la requête reste UNE sous-requête Workers, quel que soit N.
export async function readCacheMany(db, keys) {
  const out = new Map();
  if (!keys || keys.length === 0) return out;
  const unique = [...new Set(keys)];
  const { results } = await db.prepare(`
    SELECT c.key, c.payload, c.fetched_at, c.ttl_seconds
    FROM cache c
    JOIN json_each(?) j ON j.value = c.key
  `).bind(JSON.stringify(unique)).all();
  const now = Date.now();
  for (const row of results) {
    const ageSeconds = (now - row.fetched_at) / 1000;
    if (ageSeconds >= freshLimit(row.key, row.ttl_seconds)) continue; // périmée — comme readCache()
    try {
      out.set(row.key, JSON.parse(row.payload));
    } catch {
      // Ligne corrompue : ignorée ici (pas de DELETE en lecture groupée,
      // contrairement à readCache() — un prochain writeCache() la remplacera).
    }
  }
  return out;
}

// Écriture GROUPÉE — `db.batch([...])` envoie N instructions en UN
// aller-retour D1 (1 sous-requête Workers), au lieu de N `writeCache()`
// séquentiels. `entries` : [{ key, value, ttlSeconds }, ...].
export async function writeCacheMany(db, entries) {
  if (!entries || entries.length === 0) return;
  const now = Date.now();
  const stmts = entries.map(({ key, value, ttlSeconds }) =>
    db.prepare(`
      INSERT INTO cache (key, payload, fetched_at, ttl_seconds) VALUES (?, ?, ?, ?)
      ON CONFLICT(key) DO UPDATE SET payload = excluded.payload, fetched_at = excluded.fetched_at, ttl_seconds = excluded.ttl_seconds
    `).bind(key, JSON.stringify(value), now, ttlSeconds));
  await db.batch(stmts);
}

// Une erreur n'est JAMAIS mise en cache — un échec réseau ne doit pas se
// transformer en trou de données persistant.
export async function cached(db, key, ttlSeconds, fn, { revive = null, force = false } = {}) {
  if (!force || demoActive()) { // en démo, « forcer » ne contourne pas le cache
    const { hit, value } = await readCache(db, key);
    if (hit) return revive ? revive(value) : value;
  }
  let fresh;
  try {
    fresh = await fn();
  } catch (err) {
    // Mode démo : Yahoo en panne ou limité → dernière valeur connue, même vieille.
    if (demoActive() && demoEligible(key)) {
      const raw = await readCacheRaw(db, key);
      if (raw.found) return revive ? revive(raw.value) : raw.value;
    }
    throw err;
  }
  await writeCache(db, key, fresh, ttlSeconds);
  return fresh;
}

export async function purgeExpiredCache(db) {
  const result = await db.prepare('DELETE FROM cache WHERE (? - fetched_at) / 1000 >= ttl_seconds').bind(Date.now()).run();
  return result.meta?.changes ?? 0;
}
