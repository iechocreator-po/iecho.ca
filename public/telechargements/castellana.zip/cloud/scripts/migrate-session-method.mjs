#!/usr/bin/env node
// Migration idempotente (17/10/2026) — origine de la session (sessions.method),
// lue par le changement de mot de passe (src/lib/password-rules.js).
// PRAGMA table_info avant l'ALTER : rejouable sans erreur.
// Les sessions existantes reçoivent 'password' (l'ancien mot de passe leur
// sera donc demandé) — jamais un passe-droit rétroactif.
//
// Usage :
//   node scripts/migrate-session-method.mjs             (D1 local)
//   node scripts/migrate-session-method.mjs --remote    (vrai D1, AVANT wrangler deploy)

import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const remote = process.argv.includes('--remote');
const flag = remote ? '--remote' : '--local';

function run(sql, { json = false } = {}) {
  const args = ['wrangler', 'd1', 'execute', 'castellana-db', flag, '--command', sql];
  if (json) args.push('--json');
  const result = spawnSync('npx', args, { cwd: ROOT, stdio: json ? ['ignore', 'pipe', 'pipe'] : 'inherit' });
  if (result.status !== 0) {
    console.error(json ? result.stderr?.toString() : '');
    throw new Error(`Échec de la commande wrangler (SQL: ${sql})`);
  }
  return json ? JSON.parse(result.stdout.toString()) : null;
}

console.log(`\nMigration sessions.method (${remote ? 'D1 distant' : 'D1 local'})...`);
const cols = new Set(run('PRAGMA table_info(sessions)', { json: true })[0].results.map((c) => c.name));
if (!cols.has('method')) {
  console.log('- ajout de la colonne sessions.method');
  run("ALTER TABLE sessions ADD COLUMN method TEXT NOT NULL DEFAULT 'password'");
} else {
  console.log('- sessions.method déjà présente, ignorée');
}
const after = new Set(run('PRAGMA table_info(sessions)', { json: true })[0].results.map((c) => c.name));
if (!after.has('method')) throw new Error('sessions.method absente après migration');
console.log(`\nMigration terminée et vérifiée (${flag}). Rejouable sans erreur.`);
