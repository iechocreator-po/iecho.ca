// Tableau de bord annuel de la Roue : UNE seule définition de « l'année » et du « mois » (audit formules, 20/10/2026, constat 2).
// Convention du Sheets du club : une semaine (dimanche -> samedi) appartient à l'année ET au mois de son vendredi.
// Avant : les semaines la suivaient, mais le graphique par mois, les primes nettes et le dénouement suivaient le calendrier ;
// une option fermée le 29/12/2026 valait 200 $ en 2026 ici, 200 $ en 2027 là, et 0 $ dans le graphique par mois.
import test from 'node:test';
import assert from 'node:assert/strict';
import {
  optPeriodOf, optWeekStart, optWeekYear, optAnnualDashboard, optPremiumBreakdown, optLegOutcomes, optRoueActivity, optLegPnl,
} from './options-analytics.js';

const leg = (over = {}) => ({
  type: 'put', ticker: 'AAA', strike: 50, contrats: 1, prime_recue: 2, prime_cloture: 0, statut: 'expire',
  date_ouverture: '2026-12-21', date_cloture: '2026-12-29', commission_ouverture: 0, commission_cloture: 0, ...over,
});
const somme = (a) => a.reduce((x, y) => x + y, 0);
const jours = (n) => new Date(Date.UTC(2021, 0, 1) + n * 86400000).toISOString().slice(0, 10);

test('optPeriodOf : année et mois du VENDREDI de la semaine', () => {
  assert.deepEqual(optPeriodOf('2026-12-29'), { year: 2027, month: 0 }, 'mardi 29/12/2026 : semaine du 27/12, vendredi 01/01/2027');
  assert.deepEqual(optPeriodOf('2026-12-25'), { year: 2026, month: 11 }, 'vendredi 25/12/2026 : lui-même');
  assert.deepEqual(optPeriodOf('2022-01-01'), { year: 2021, month: 11 }, 'samedi 01/01/2022 : semaine du 26/12/2021, vendredi 31/12/2021');
  assert.deepEqual(optPeriodOf('2026-03-15'), { year: 2026, month: 2 }, 'milieu d\'année : le calendrier et la semaine s\'accordent');
  assert.equal(optPeriodOf('pas une date'), null);
  assert.equal(optPeriodOf(null), null);
  for (const d of ['2026-12-27', '2026-12-31', '2027-01-02', '2024-12-29', '2022-01-01']) {
    assert.equal(optPeriodOf(d).year, optWeekYear(optWeekStart(d)), `même année que le rapport hebdo pour ${d}`);
  }
});

test('le cas de l\'audit : une option fermée le 29/12/2026 compte pour 2027, PARTOUT', () => {
  const legs = [leg()]; // 2 $ × 100 = 200 $
  const d26 = optAnnualDashboard({ legs, year: 2026, today: '2027-06-01' });
  const d27 = optAnnualDashboard({ legs, year: 2027, today: '2027-06-01' });
  assert.equal(d26.profitRealise, 0);
  assert.equal(d27.profitRealise, 200);
  assert.equal(somme(d26.profitMensuel), 0);
  assert.equal(somme(d27.profitMensuel), 200, 'le graphique par mois montre ce profit (avant : 0 $)');
  assert.equal(d27.profitMensuel[0], 200, 'au mois du vendredi de la semaine : janvier 2027');
  assert.equal(optPremiumBreakdown(legs, 2026).total, 0, 'avant : 200 $ en 2026 ici');
  const p27 = optPremiumBreakdown(legs, 2027);
  assert.equal(p27.total, 200);
  assert.equal(p27.parMois[0], 200);
  assert.deepEqual(p27.parTicker, [{ cle: 'AAA', profit: 200 }]);
  assert.equal(optLegOutcomes(legs, 2026).closes, 0);
  const o27 = optLegOutcomes(legs, 2027);
  assert.equal(o27.closes, 1);
  assert.equal(o27.expire, 1);
  assert.equal(o27.parMois[0].expire, 1);
  // Le « autres revenus » de la carte H3 (profit réalisé - primes nettes) n'est plus faussé autour du 1er janvier.
  for (const y of [2026, 2027]) {
    const autres = optAnnualDashboard({ legs, year: y, today: '2027-06-01' }).profitRealise - optPremiumBreakdown(legs, y).total;
    assert.equal(autres, 0, `année ${y} : aucune action ni dividende, donc « autres » = 0 (avant : -200 puis +200)`);
  }
});

test('l\'ouverture suit la même règle : l\'activité de l\'année et le dénouement ne se contredisent pas', () => {
  const legs = [leg({ date_ouverture: '2026-12-28', date_cloture: '2027-01-08' })]; // ouverte le lundi 28/12 -> semaine 2027
  assert.equal(optRoueActivity(legs, 2027).options, 1);
  assert.equal(optRoueActivity(legs, 2026).options, 0);
  assert.equal(optRoueActivity([leg({ date_ouverture: '2026-12-21' })], 2026).options, 1, 'ouverte le 21/12 : semaine du vendredi 25/12/2026');
});

test('PARTITION : sur 3 000 options tirées au hasard autour des fins d\'année, chacune compte une fois, dans la même année partout', () => {
  let s = 20261020; // générateur déterministe
  const rnd = () => { s = (s * 1664525 + 1013904223) % 4294967296; return s / 4294967296; };
  const legs = [];
  for (let i = 0; i < 3000; i++) {
    // dates concentrées autour des 1er janvier (±12 jours) de 2021 à 2028, pour exercer les semaines à cheval
    const an = 2021 + Math.floor(rnd() * 8);
    const base = Date.UTC(an, 0, 1) + Math.floor((rnd() - 0.5) * 24) * 86400000;
    const close = new Date(base).toISOString().slice(0, 10);
    legs.push(leg({ ticker: `T${i % 7}`, strike: 20 + Math.floor(rnd() * 200), contrats: 1 + Math.floor(rnd() * 3), prime_recue: Math.round(rnd() * 500) / 100,
      prime_cloture: Math.round(rnd() * 300) / 100, statut: ['expire', 'assigne', 'rachete', 'roule'][Math.floor(rnd() * 4)],
      date_ouverture: new Date(base - 7 * 86400000).toISOString().slice(0, 10), date_cloture: close,
      commission_ouverture: Math.round(rnd() * 200) / 100, commission_cloture: Math.round(rnd() * 200) / 100 }));
  }
  const annees = [2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029];
  const attenduTotal = somme(legs.map((l) => optLegPnl(l)));
  let totalPrimes = 0; let totalCloses = 0; let totalOuvertes = 0;
  for (const y of annees) {
    const dash = optAnnualDashboard({ legs, year: y, today: '2031-01-01' });
    const prem = optPremiumBreakdown(legs, y);
    const out = optLegOutcomes(legs, y);
    assert.ok(Math.abs(somme(dash.profitMensuel) - dash.profitRealise) < 1e-6, `${y} : la somme des mois (${somme(dash.profitMensuel)}) doit égaler le profit réalisé (${dash.profitRealise})`);
    assert.ok(Math.abs(prem.total - dash.profitRealise) < 1e-6, `${y} : primes nettes (${prem.total}) et profit réalisé (${dash.profitRealise}) doivent s'accorder (seules des options ici)`);
    assert.ok(Math.abs(somme(prem.parMois) - prem.total) < 1e-6, `${y} : les mois des primes nettes somment au total`);
    assert.equal(out.closes, out.parMois.reduce((a, m) => a + m.expire + m.rachete + m.assigne, 0), `${y} : le dénouement par mois somme au total`);
    totalPrimes += prem.total; totalCloses += out.closes; totalOuvertes += optRoueActivity(legs, y).options;
  }
  assert.ok(Math.abs(totalPrimes - attenduTotal) < 1e-5, `toutes années confondues, chaque option compte exactement une fois (${totalPrimes} contre ${attenduTotal})`);
  assert.equal(totalCloses, 3000, 'chaque option close est comptée dans UNE seule année');
  assert.equal(totalOuvertes, 3000, 'chaque option est comptée dans l\'activité d\'UNE seule année');
});
