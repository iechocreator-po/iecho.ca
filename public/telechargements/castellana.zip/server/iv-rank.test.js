// IV Rank réel (#377) : fonctions partagées optAtmIv/optIvRank, bascule du
// sous-score de valorisation sur le rang, et repli honnête sur l'ancien proxy.
import test from 'node:test';
import assert from 'node:assert/strict';
import { optAtmIv, optIvRank, optDealValuation } from './options-analytics.js';

test('IV à la monnaie : médiane des contrats |delta| 0,4–0,6, null sous 2 contrats', () => {
  const cs = [
    { iv: 0.30, delta: 0.5 }, { iv: 0.34, delta: -0.45 }, { iv: 0.32, delta: 0.55 },
    { iv: 0.90, delta: 0.05 },   // hors plage : ignoré
    { iv: null, delta: 0.5 },    // IV absente : ignoré
  ];
  assert.equal(optAtmIv(cs), 0.32);
  assert.equal(optAtmIv([{ iv: 0.3, delta: 0.5 }]), null);
  assert.equal(optAtmIv([]), null);
});

test('IV Rank : position entre le plus bas et le plus haut, percentile, null sous 20 jours', () => {
  const hist = Array.from({ length: 21 }, (_, i) => (20 + i) / 100); // 0,20 … 0,40 (sans erreur flottante)
  const r = optIvRank(hist, 0.30);
  assert.ok(Math.abs(r.rank - 50) < 1e-9);
  assert.equal(r.n, 21);
  assert.ok(Math.abs(r.percentile - (11 / 21) * 100) < 1e-9);
  assert.equal(optIvRank(hist.slice(0, 19), 0.30), null);          // historique insuffisant
  assert.equal(optIvRank(Array(25).fill(0.3), 0.3), null);         // aucune amplitude : pas de rang
  assert.equal(optIvRank(hist, null), null);
  assert.equal(optIvRank(hist, 0.99).rank, 100);                   // au-delà du haut : plafonné
});

test('valorisation : le rang remplace le proxy ; le vendeur veut un rang haut, l\'acheteur un rang bas', () => {
  assert.equal(optDealValuation('vente', 0.30, 0.25, 80).score, 1);
  assert.equal(optDealValuation('vente', 0.30, 0.25, 20).score, -1);
  assert.equal(optDealValuation('achat', 0.30, 0.25, 20).score, 1);
  assert.equal(optDealValuation('achat', 0.30, 0.25, 80).score, -1);
  const v = optDealValuation('vente', 0.30, 0.25, 50);
  assert.equal(v.basis, 'ivrank');
  assert.equal(v.score, 0);
});

test('sans rang : repli sur le proxy IV vs volatilité historique, et il le dit', () => {
  const v = optDealValuation('vente', 0.35, 0.25, null);
  assert.equal(v.basis, 'hv');
  assert.equal(v.score, 1);
  assert.equal(optDealValuation('vente', 0.35, null, null), null);   // ni rang ni HV : rien à dire
  assert.equal(optDealValuation('vente', 0.35, null, 90).basis, 'ivrank'); // le rang suffit sans HV
});

import { shouldRunDailyScan } from './daily-scan.js';

test('scan quotidien : jour ouvrable, après 17 h à New York, une seule fois par date', () => {
  const soir = new Date('2026-09-29T22:30:00Z');       // mardi 18 h 30 NY
  assert.equal(shouldRunDailyScan(soir, null), true);
  assert.equal(shouldRunDailyScan(soir, new Date('2026-09-29T21:10:00Z')), false); // déjà fait ce jour NY
  assert.equal(shouldRunDailyScan(soir, new Date('2026-09-28T21:10:00Z')), true);  // dernier scan = hier
  assert.equal(shouldRunDailyScan(new Date('2026-09-29T15:00:00Z'), null), false); // 11 h NY : marché ouvert
  assert.equal(shouldRunDailyScan(new Date('2026-09-27T22:30:00Z'), null), false); // dimanche
});
