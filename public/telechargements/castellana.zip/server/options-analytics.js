// Évalue js/options-analytics.js pour le serveur local — même patron que
// server/labo-params.js pour js/labo-schema.js : le navigateur, ce serveur
// et le Worker cloud (copie ESM générée) partagent ainsi UNE définition des
// formules de rendement annualisé/capital requis/roulement/delta estimé.
//
// options-analytics.js utilise `laboNormCdf` (défini dans js/strategies-labo.js,
// chargé avant lui côté navigateur) : on évalue donc la même tranche
// laboErf→laboNormInv que server/options-tab.test.js avant d'évaluer ce
// fichier, pour obtenir le même global ici.

import { readFileSync } from 'node:fs';

const labo = readFileSync(new URL('../js/strategies-labo.js', import.meta.url), 'utf8');
const erf = labo.slice(labo.indexOf('function laboErf'), labo.indexOf('function laboNormInv'));
const source = readFileSync(new URL('../js/options-analytics.js', import.meta.url), 'utf8');
export const {
  optAnnualizedYield, optCapitalRequired, optAssignmentProbabilityLabel, optRollNetCredit, optionDelta, optionMarketZone,
  optDealLiquidity, optDealValuation, optIntrinsicValue, optExtrinsicValue, optPremiumRule, optCushion, optRuleLimit, optPickForChain, optPickPutForChain, optBetterPick, optComparePicks, optDealReturnOrLeverage, optDealVerdict, optScoreDeal, optAtmIv, optExpectedMove, optStraddleMove, optEmPosition, optIdealStrike, optIvRank, optCloseOnOrBefore, optCycleBilan,
  optLegEnd, optLegPnl, optLegReturn, optLegIssues, optWeekStart, optWeekYear, optPeriodOf, optWeeklyReport, optAccountSnapshot, optAnnualDashboard, optMaxPricePerTicker, optRoueDeletionPlan, optStrikeDistance, optRouePositions, optLegOutcomes, optPremiumBreakdown, optValueSeries, optRoueActivity, optWeekLegs,
} = new Function(
  `${erf}\n${source}; return { optAnnualizedYield, optCapitalRequired, optAssignmentProbabilityLabel, optRollNetCredit, optionDelta, optionMarketZone, optDealLiquidity, optDealValuation, optIntrinsicValue, optExtrinsicValue, optPremiumRule, optCushion, optRuleLimit, optPickForChain, optPickPutForChain, optBetterPick, optComparePicks, optDealReturnOrLeverage, optDealVerdict, optScoreDeal, optAtmIv, optExpectedMove, optStraddleMove, optEmPosition, optIdealStrike, optIvRank, optCloseOnOrBefore, optCycleBilan, optLegEnd, optLegPnl, optLegReturn, optLegIssues, optWeekStart, optWeekYear, optPeriodOf, optWeeklyReport, optAccountSnapshot, optAnnualDashboard, optMaxPricePerTicker, optRoueDeletionPlan, optStrikeDistance, optRouePositions, optLegOutcomes, optPremiumBreakdown, optValueSeries, optRoueActivity, optWeekLegs };`,
)();
