// Appels externes : réessai, temporisation, parallélisme borné.
//
// Constat F3 de l'audit du 7/9/2026 : une recherche exhaustive sur
// `server/*.js` ne trouvait AUCUNE occurrence de retry, backoff, timeout ou
// AbortController. Un incident réseau d'une seconde produisait un `null`
// définitif, affiché « — » dans l'interface, sans seconde tentative et sans
// distinction visible entre « la donnée n'existe pas » et « l'appel a
// échoué ». Pour une aide à la décision financière, c'est le défaut le plus
// coûteux : un trou silencieux se lit comme une information.
//
// Tout appel externe de l'app passe désormais par `withRetry`.

// Temporisation par défaut. Volontairement généreuse : Yahoo répond en
// général en < 2 s, mais un `quoteSummary` sur un titre peu liquide ou une
// connexion domestique lente peut dépasser 5 s. Mieux vaut attendre que
// produire un faux « donnée indisponible ».
const DEFAULT_TIMEOUT_MS = 10_000;
const DEFAULT_TRIES = 2;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export class ExternalCallError extends Error {
  constructor(label, tries, cause) {
    super(`${label} : échec après ${tries} tentative(s) — ${cause?.message || cause}`);
    this.name = 'ExternalCallError';
    this.label = label;
    this.tries = tries;
    this.cause = cause;
  }
}

// Enveloppe un appel externe : `tries` tentatives, backoff exponentiel,
// temporisation par tentative.
//
// ⚠️ Limite assumée : `yahoo-finance2` n'expose pas de signal d'annulation
// par appel, donc la temporisation est une COURSE (`Promise.race`) — elle
// rend la main à l'appelant à l'heure, mais la requête HTTP sous-jacente
// peut continuer à vivre brièvement en arrière-plan. C'est acceptable ici
// (requêtes GET idempotentes, sans effet de bord), et bien préférable à une
// route qui reste pendue indéfiniment. À revoir si une source à effets de
// bord est branchée un jour.
//
// `label` sert au message d'erreur : il doit nommer la SOURCE (« cotations
// Yahoo », « historique AMD »), pas la fonction — c'est ce que lira JP ou un
// testeur dans le bandeau d'erreur.
export async function withRetry(label, fn, { tries = DEFAULT_TRIES, timeoutMs = DEFAULT_TIMEOUT_MS, baseDelayMs = 400 } = {}) {
  let lastError = null;
  for (let attempt = 1; attempt <= tries; attempt++) {
    let timer = null;
    try {
      const timeout = new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error(`temporisation dépassée (${timeoutMs} ms)`)), timeoutMs);
      });
      return await Promise.race([fn(), timeout]);
    } catch (err) {
      lastError = err;
      if (attempt < tries) await sleep(baseDelayMs * 2 ** (attempt - 1));
    } finally {
      if (timer) clearTimeout(timer);
    }
  }
  throw new ExternalCallError(label, tries, lastError);
}

// Exécute `fn` sur chaque élément avec au plus `limit` appels en vol.
//
// Remplace les boucles séquentielles espacées de `getHomemadeIndicatorsBatch`
// (400 ms/titre), `getFundamentalsBatch` (300 ms/titre) et de l'ancien
// `screenWatchlist` (1 500 ms/titre). Ces temporisations avaient été
// calibrées pour le rate-limit non documenté du scanner TradingView, puis
// appliquées par prudence à Yahoo — qui, lui, a encaissé 20 appels
// parallèles sans un seul échec pendant l'audit. Une limite basse reste de
// mise : c'est une source non officielle, et rien ne garantit sa tolérance.
//
// L'ordre du résultat suit l'ordre d'entrée, quel que soit l'ordre
// d'achèvement — plusieurs appelants s'appuient dessus pour joindre par index.
export async function mapWithConcurrency(items, fn, { limit = 6 } = {}) {
  const results = new Array(items.length);
  let next = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (true) {
      const i = next++;
      if (i >= items.length) return;
      results[i] = await fn(items[i], i);
    }
  });
  await Promise.all(workers);
  return results;
}
