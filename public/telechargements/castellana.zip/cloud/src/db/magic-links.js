// Connexion par magic link (19/9/2026) — s'ajoute au mot de passe, ne le
// remplace pas (décision de JP). Un token est à usage unique et expire
// vite (15 min, MAGIC_LINK_TTL_MS) : une fenêtre courte limite les dégâts
// si un courriel de connexion traîne dans une boîte de réception partagée
// ou un historique de client mail.

export const MAGIC_LINK_TTL_MS = 15 * 60 * 1000;

export async function createMagicLink(db, userId, token) {
  const expiresAt = Date.now() + MAGIC_LINK_TTL_MS;
  await db.prepare('INSERT INTO magic_links (token, user_id, expires_at) VALUES (?, ?, ?)')
    .bind(token, userId, expiresAt).run();
  return expiresAt;
}

// Retourne { userId, username, disabled } si le token est valide (existe,
// pas déjà utilisé, pas expiré), sinon null — jamais de distinction dans
// le message renvoyé à l'appelant entre ces trois cas (routes/auth.js),
// pour ne pas transformer ce champ en outil de reconnaissance.
export async function findValidMagicLink(db, token) {
  const row = await db.prepare(
    `SELECT m.user_id AS userId, u.username, u.disabled FROM magic_links m
     JOIN users u ON u.id = m.user_id
     WHERE m.token = ? AND m.used_at IS NULL AND m.expires_at > ?`,
  ).bind(token, Date.now()).first();
  return row || null;
}

// Atomique (audit routes, 21/10/2026) : renvoie true pour UN SEUL appel. Avant, vérifier puis consommer étaient deux requêtes :
// deux appels simultanés avec le même lien ouvraient deux sessions.
export async function consumeMagicLink(db, token) {
  const r = await db.prepare("UPDATE magic_links SET used_at = datetime('now') WHERE token = ? AND used_at IS NULL AND expires_at > ?")
    .bind(token, Date.now()).run();
  return (r.meta?.changes ?? 0) > 0;
}

// Après un changement de mot de passe : les liens encore valides du compte
// sont invalidés, pour qu'un vieux courriel ne rouvre pas une session.
export async function invalidateMagicLinksForUser(db, userId) {
  await db.prepare("UPDATE magic_links SET used_at = datetime('now') WHERE user_id = ? AND used_at IS NULL")
    .bind(userId).run();
}
