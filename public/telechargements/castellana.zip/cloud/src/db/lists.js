// Listes personnalisées du Screener — portage Cloudflare de server/lists.js,
// isolées PAR UTILISATEUR (comme watchlist.js) : `user_id` sur custom_lists,
// et custom_list_tickers rattaché par list_id (déjà propre à un utilisateur
// via custom_lists, donc pas de user_id redondant sur cette table).

export const MAX_TICKERS_PER_LIST = 50;

export async function getLists(db, userId) {
  const { results: lists } = await db.prepare(
    'SELECT id, nom, date_creation FROM custom_lists WHERE user_id = ? ORDER BY nom',
  ).bind(userId).all();
  if (lists.length === 0) return [];
  const { results: tickers } = await db.prepare(`
    SELECT clt.list_id, clt.ticker, clt.exchange
    FROM custom_list_tickers clt
    JOIN custom_lists cl ON cl.id = clt.list_id
    WHERE cl.user_id = ?
    ORDER BY clt.ticker
  `).bind(userId).all();
  const byList = new Map();
  for (const t of tickers) {
    if (!byList.has(t.list_id)) byList.set(t.list_id, []);
    byList.get(t.list_id).push({ ticker: t.ticker, exchange: t.exchange });
  }
  return lists.map((l) => ({ ...l, tickers: byList.get(l.id) ?? [] }));
}

// `userId` vérifié sur CHAQUE lecture/écriture : sans ce filtre, un id de
// liste deviné donnerait accès à la liste d'un AUTRE utilisateur — même
// garde-fou d'isolation que trades.js/preferences.js.
export async function getListById(db, userId, id) {
  const list = await db.prepare('SELECT id, nom, date_creation FROM custom_lists WHERE id = ? AND user_id = ?')
    .bind(id, userId).first();
  if (!list) return null;
  const { results: tickers } = await db.prepare(
    'SELECT ticker, exchange FROM custom_list_tickers WHERE list_id = ? ORDER BY ticker',
  ).bind(id).all();
  return { ...list, tickers };
}

export async function createList(db, userId, nom) {
  const trimmed = nom.trim();
  if (!trimmed) throw new Error('Nom de liste requis.');
  const result = await db.prepare('INSERT INTO custom_lists (user_id, nom) VALUES (?, ?)').bind(userId, trimmed).run();
  return getListById(db, userId, result.meta.last_row_id);
}

export async function renameList(db, userId, id, nom) {
  const trimmed = nom.trim();
  if (!trimmed) throw new Error('Nom de liste requis.');
  const result = await db.prepare('UPDATE custom_lists SET nom = ? WHERE id = ? AND user_id = ?')
    .bind(trimmed, id, userId).run();
  if ((result.meta?.changes ?? 0) === 0) return null;
  return getListById(db, userId, id);
}

export async function deleteList(db, userId, id) {
  const list = await getListById(db, userId, id);
  if (!list) return false;
  await db.batch([
    db.prepare('DELETE FROM custom_list_tickers WHERE list_id = ?').bind(id),
    db.prepare('DELETE FROM custom_lists WHERE id = ? AND user_id = ?').bind(id, userId),
  ]);
  return true;
}

export async function addTickerToList(db, userId, id, ticker, exchange = 'NASDAQ') {
  const list = await getListById(db, userId, id);
  if (!list) throw new Error('Liste introuvable.');
  const upper = ticker.toUpperCase();
  if (list.tickers.length >= MAX_TICKERS_PER_LIST && !list.tickers.some((t) => t.ticker === upper)) {
    throw new Error(`Cette liste a déjà ${MAX_TICKERS_PER_LIST} titres (maximum).`);
  }
  await db.prepare(
    `INSERT INTO custom_list_tickers (list_id, ticker, exchange) VALUES (?, ?, ?)
     ON CONFLICT(list_id, ticker) DO UPDATE SET exchange = excluded.exchange`,
  ).bind(id, upper, exchange).run();
  return getListById(db, userId, id);
}

export async function removeTickerFromList(db, userId, id, ticker) {
  const list = await getListById(db, userId, id);
  if (!list) return null;
  await db.prepare('DELETE FROM custom_list_tickers WHERE list_id = ? AND ticker = ?')
    .bind(id, ticker.toUpperCase()).run();
  return getListById(db, userId, id);
}

// Vue d'administration (bilbao, 20/9/2026) : « Ma watchlist » ET les listes
// personnalisées du Screener de TOUS les comptes, en lecture seule. Ne renvoie
// que des symboles et des dates — rien de personnel (ni e-mail, ni trades).
//
// Limite assumée : ce sont des ÉTATS COURANTS. Aucune date de modification
// n'existe sur une liste, et une suppression ne laisse pas de trace ici ;
// `lastActivity` est la plus récente des dates d'ajout de symbole et de
// création de liste. L'historique des modifications, lui, passe par la
// télémétrie (événements `list_saved`).
export async function listAllUsersLists(db) {
  const [users, wl, lists, tickers] = await Promise.all([
    db.prepare('SELECT id, username, disabled FROM users ORDER BY username').all(),
    db.prepare('SELECT user_id, ticker, exchange, source, date_ajout FROM watchlist ORDER BY ticker').all(),
    db.prepare('SELECT id, user_id, nom, date_creation FROM custom_lists ORDER BY nom').all(),
    db.prepare('SELECT list_id, ticker, exchange, date_ajout FROM custom_list_tickers ORDER BY ticker').all(),
  ]);
  const tickersByList = new Map();
  for (const t of tickers.results) {
    if (!tickersByList.has(t.list_id)) tickersByList.set(t.list_id, []);
    tickersByList.get(t.list_id).push({ ticker: t.ticker, exchange: t.exchange, dateAjout: t.date_ajout });
  }
  const wlByUser = new Map();
  for (const w of wl.results) {
    if (!wlByUser.has(w.user_id)) wlByUser.set(w.user_id, []);
    wlByUser.get(w.user_id).push({ ticker: w.ticker, exchange: w.exchange, source: w.source, dateAjout: w.date_ajout });
  }
  const listsByUser = new Map();
  for (const l of lists.results) {
    if (!listsByUser.has(l.user_id)) listsByUser.set(l.user_id, []);
    listsByUser.get(l.user_id).push({
      id: l.id, nom: l.nom, dateCreation: l.date_creation, tickers: tickersByList.get(l.id) ?? [],
    });
  }
  return users.results.map((u) => {
    const watchlist = wlByUser.get(u.id) ?? [];
    const customLists = listsByUser.get(u.id) ?? [];
    const dates = [
      ...watchlist.map((t) => t.dateAjout),
      ...customLists.flatMap((l) => [l.dateCreation, ...l.tickers.map((t) => t.dateAjout)]),
    ].filter(Boolean);
    return {
      username: u.username,
      disabled: !!u.disabled,
      watchlist,
      lists: customLists,
      lastActivity: dates.length ? dates.reduce((a, b) => (a > b ? a : b)) : null,
    };
  });
}
