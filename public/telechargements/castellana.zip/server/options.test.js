import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeContract, normalizeChain } from './options.js';

test('bid = ask = 0 devient « pas de cotation » (null), jamais un zéro', () => {
  const c = normalizeContract({ strike: 100, bid: 0, ask: 0, lastPrice: 1.2, volume: 3, openInterest: 9, impliedVolatility: 0.5, inTheMoney: false });
  assert.equal(c.bid, null);
  assert.equal(c.ask, null);
  assert.equal(c.last, 1.2);
});

test('une vraie cotation est conservée, et un champ absent devient null', () => {
  const c = normalizeContract({ strike: 100, bid: 1.1, ask: 1.3, inTheMoney: true });
  assert.equal(c.bid, 1.1);
  assert.equal(c.ask, 1.3);
  assert.equal(c.volume, null);
  assert.equal(c.itm, true);
});

test('normalizeChain : échéances avec DTE, strikes triés, null si aucune chaîne', () => {
  const now = Date.parse('2026-09-20T12:00:00Z');
  const raw = {
    quote: { regularMarketPrice: 100 },
    expirationDates: [new Date('2026-09-25T00:00:00Z'), new Date('2026-10-16T00:00:00Z')],
    options: [{
      expirationDate: new Date('2026-09-25T00:00:00Z'),
      calls: [{ strike: 110, bid: 1, ask: 2 }, { strike: 90, bid: 11, ask: 12 }],
      puts: [{ strike: 95, bid: 1, ask: 1.2 }],
    }],
  };
  const chain = normalizeChain('ABC', raw, now);
  assert.equal(chain.expiry, '2026-09-25');
  assert.equal(chain.dte, 5);
  assert.deepEqual(chain.expirations.map((e) => e.date), ['2026-09-25', '2026-10-16']);
  assert.deepEqual(chain.calls.map((c) => c.strike), [90, 110]);
  assert.equal(chain.price, 100);
  assert.equal(chain.delayed, true);
  assert.equal(normalizeChain('ABC', { expirationDates: [], options: [] }, now), null);
});
