// Scan quotidien automatique du Radar (feature #377, 30/9/2026) — sert à
// ACCUMULER l'historique d'IV dont dépend l'IV Rank réel : sans une observation
// par jour, le rang ne devient jamais fiable (minimum 20 jours).
//
// LOCAL uniquement, comme le Radar : il ne tourne que si castellana est lancé sur
// ce Mac après la clôture. Un jour où l'app est fermée est un jour sans observation
// (pas de rattrapage : l'IV d'hier ne se reconstitue pas). Désactivable via
// settings.json → dealScanner.autoDaily.

import { db } from './db.js';
import { createScan, runDealScan, isScanRunning } from './deal-scanner.js';

const NY = 'America/New_York';

// Date (AAAA-MM-JJ) et heure à New York d'un instant donné.
function nyParts(date) {
  const p = new Intl.DateTimeFormat('en-CA', { timeZone: NY, year: 'numeric', month: '2-digit', day: '2-digit', weekday: 'short', hour: 'numeric', hour12: false }).formatToParts(date);
  const get = (t) => p.find((x) => x.type === t).value;
  return { day: `${get('year')}-${get('month')}-${get('day')}`, weekday: get('weekday'), hour: Number(get('hour')) % 24 };
}

/**
 * Pure : faut-il lancer le scan du jour ?
 * Oui si : jour ouvrable à New York, au moins `hourFrom` h (après la clôture, IV
 * stabilisée), et aucun scan terminé pour CETTE date à New York.
 * @param lastCompletedAt  instant du dernier scan terminé (Date) ou null
 */
export function shouldRunDailyScan(now, lastCompletedAt, { hourFrom = 17 } = {}) {
  const t = nyParts(now);
  if (t.weekday === 'Sat' || t.weekday === 'Sun') return false;
  if (t.hour < hourFrom) return false;
  if (lastCompletedAt && nyParts(lastCompletedAt).day === t.day) return false;
  return true;
}

function lastCompletedScan() {
  const r = db.prepare("SELECT started_at FROM deal_scans WHERE statut = 'termine' AND fenetre = 'standard' ORDER BY id DESC LIMIT 1").get();
  return r ? new Date(`${r.started_at.replace(' ', 'T')}Z`) : null; // SQLite stocke l'UTC sans fuseau
}

export function startDailyScanScheduler(enabled) {
  if (!enabled) return null;
  const timer = setInterval(() => {
    if (isScanRunning() || !shouldRunDailyScan(new Date(), lastCompletedScan())) return;
    try {
      const { scanId, tickers } = createScan();
      console.log(`Radar : scan quotidien lancé (${tickers.length} titres) pour l'historique d'IV`);
      runDealScan(scanId, tickers).catch((err) => console.error('Radar : scan quotidien en échec —', err.message));
    } catch (err) { console.error('Radar : scan quotidien impossible —', err.message); }
  }, 5 * 60_000);
  timer.unref();
  return timer;
}
