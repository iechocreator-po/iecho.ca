// Version installée, détection d'une version plus récente, et mise à jour
// en un clic (7/9/2026).
//
// Le problème résolu : le zip téléchargé depuis iecho.ca devenait périmé EN
// SILENCE. Un testeur n'avait aucun moyen de savoir que sa copie avait trois
// semaines de retard — ni JP de le voir dans la télémétrie. Il fallait le
// prévenir à la main, et espérer qu'il refasse l'installation.
//
// ⚠️ C'EST LE CODE LE PLUS RISQUÉ DE L'APPLICATION : il réécrit
// l'application elle-même pendant qu'elle tourne. Les garde-fous ci-dessous
// ne sont pas décoratifs, ne pas les alléger :
//
//   1. TOUT est vérifié AVANT de toucher quoi que ce soit. Téléchargement,
//      extraction et contrôle du contenu se font dans un dossier de travail
//      séparé ; un échec à ce stade laisse l'installation strictement
//      intacte.
//   2. La bascule elle-même n'est QUE des renommages (rename), jamais des
//      copies : c'est l'opération la plus courte et la plus atomique
//      disponible, ce qui réduit au minimum la fenêtre pendant laquelle
//      l'installation est à moitié remplacée.
//   3. `data/` et `node_modules/` ne sont JAMAIS touchés — la base SQLite
//      contient le journal de trades de l'utilisateur, qu'aucune mise à jour
//      ne doit pouvoir perdre.
//   4. L'ancienne version est conservée (data/.update/backup-<horodatage>)
//      et le retour arrière est un renommage.

import { existsSync, mkdirSync, readFileSync, writeFileSync, renameSync, rmSync, readdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const WORK_DIR = path.join(ROOT, 'data', '.update');

// Ce que la mise à jour ne remplace jamais.
const PRESERVED = new Set(['data', 'node_modules', '.git', '.venv-mcp', 'settings.json']);

// Fichiers dont la présence prouve que l'archive est bien castellana et non
// un zip arbitraire ou un téléchargement tronqué.
const REQUIRED_ENTRIES = ['package.json', 'index.html', path.join('server', 'index.js')];

export function getLocalVersion() {
  for (const file of ['version.json', 'package.json']) {
    try {
      const raw = JSON.parse(readFileSync(path.join(ROOT, file), 'utf8'));
      if (raw.version) return { version: raw.version, buildDate: raw.buildDate ?? null, source: file };
    } catch {
      // fichier absent ou illisible — on tente le suivant
    }
  }
  return { version: null, buildDate: null, source: null };
}

// Compare deux versions sémantiques « x.y.z ». Retourne true si `candidate`
// est strictement plus récente que `current`. Toute version non numérique
// est traitée comme « pas plus récente » : mieux vaut ne rien proposer que
// de proposer une régression sur une comparaison douteuse.
export function isNewer(candidate, current) {
  const parse = (v) => String(v ?? '').split('.').map((n) => Number.parseInt(n, 10));
  const a = parse(candidate);
  const b = parse(current);
  if (a.length !== 3 || b.length !== 3 || [...a, ...b].some(Number.isNaN)) return false;
  for (let i = 0; i < 3; i++) {
    if (a[i] > b[i]) return true;
    if (a[i] < b[i]) return false;
  }
  return false;
}

// Interroge le point de publication (le Worker de télémétrie déjà déployé,
// route /version) pour connaître la dernière version publiée.
export async function checkForUpdate(manifestUrl, { timeoutMs = 6000 } = {}) {
  const local = getLocalVersion();
  if (!manifestUrl) return { ...local, updateAvailable: false, latest: null, reason: 'aucune URL de publication configurée' };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(manifestUrl, { signal: controller.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const manifest = await res.json();
    return {
      ...local,
      latest: manifest.version ?? null,
      downloadUrl: manifest.url ?? null,
      notes: manifest.notes ?? null,
      updateAvailable: isNewer(manifest.version, local.version),
      reason: null,
    };
  } catch (err) {
    // Une vérification de version qui échoue n'est jamais un problème à
    // signaler à l'utilisateur : l'app fonctionne parfaitement sans.
    return { ...local, updateAvailable: false, latest: null, reason: err.message };
  } finally {
    clearTimeout(timer);
  }
}

function cleanWorkDir() {
  rmSync(WORK_DIR, { recursive: true, force: true });
  mkdirSync(WORK_DIR, { recursive: true });
}

// Étape 1-2 : télécharger et extraire dans un dossier de travail, puis
// VÉRIFIER. Rien hors de data/.update n'est touché ici.
async function downloadAndStage(downloadUrl) {
  cleanWorkDir();
  const zipPath = path.join(WORK_DIR, 'castellana.zip');
  const stagingDir = path.join(WORK_DIR, 'staging');
  mkdirSync(stagingDir, { recursive: true });

  const res = await fetch(downloadUrl);
  if (!res.ok) throw new Error(`téléchargement impossible (HTTP ${res.status})`);
  const buffer = Buffer.from(await res.arrayBuffer());
  if (buffer.length < 100_000) {
    throw new Error(`archive suspecte : ${buffer.length} octets, trop petite pour être castellana`);
  }
  writeFileSync(zipPath, buffer);

  // `tar` sait lire les .zip sur macOS (bsdtar) comme sur Windows 10+ —
  // aucune dépendance npm de décompression à ajouter.
  try {
    execFileSync('tar', ['-xf', zipPath, '-C', stagingDir], { stdio: 'pipe' });
  } catch (err) {
    throw new Error(`archive illisible : ${err.message}`);
  }

  // Certains zips contiennent un dossier racine unique : on redescend dedans.
  const entries = readdirSync(stagingDir);
  const realRoot = entries.length === 1 && !REQUIRED_ENTRIES.some((f) => existsSync(path.join(stagingDir, f)))
    ? path.join(stagingDir, entries[0])
    : stagingDir;

  for (const required of REQUIRED_ENTRIES) {
    if (!existsSync(path.join(realRoot, required))) {
      throw new Error(`archive incomplète : ${required} est absent — mise à jour annulée, rien n'a été modifié`);
    }
  }
  return realRoot;
}

// Étape 3 : la bascule. Uniquement des renommages, et seulement une fois que
// tout ce qui précède a réussi.
function swapIn(stagedRoot) {
  const backupDir = path.join(WORK_DIR, `backup-${new Date().toISOString().replace(/[:.]/g, '-')}`);
  mkdirSync(backupDir, { recursive: true });

  const staged = readdirSync(stagedRoot).filter((name) => !PRESERVED.has(name));
  const movedAside = [];
  try {
    for (const name of staged) {
      const current = path.join(ROOT, name);
      if (existsSync(current)) {
        renameSync(current, path.join(backupDir, name));
        movedAside.push(name);
      }
      renameSync(path.join(stagedRoot, name), current);
    }
  } catch (err) {
    // Retour arrière : on remet ce qui avait été mis de côté. Ce chemin
    // n'est atteignable que si un renommage échoue en cours de bascule
    // (disque plein, fichier verrouillé par un antivirus sous Windows).
    for (const name of movedAside) {
      const backedUp = path.join(backupDir, name);
      const current = path.join(ROOT, name);
      try {
        if (existsSync(current)) rmSync(current, { recursive: true, force: true });
        if (existsSync(backedUp)) renameSync(backedUp, current);
      } catch {
        // On a fait ce qu'on a pu ; le dossier de sauvegarde reste sur
        // disque et le message ci-dessous en donne le chemin exact.
      }
    }
    throw new Error(`bascule interrompue et annulée (${err.message}). Sauvegarde : ${backupDir}`);
  }
  return backupDir;
}

// Applique la mise à jour complète. Retourne le chemin de la sauvegarde.
// L'appelant doit redémarrer le processus ensuite : le code en mémoire est
// celui de l'ANCIENNE version tant que le process n'a pas été relancé.
export async function applyUpdate(downloadUrl) {
  if (!downloadUrl) throw new Error('aucune URL de téléchargement fournie');
  // Relevé AVANT la bascule : après, version.json est déjà celui de la
  // nouvelle version et on rapporterait deux fois le même numéro.
  const previousVersion = getLocalVersion().version;
  const stagedRoot = await downloadAndStage(downloadUrl);
  const stagedVersion = (() => {
    try {
      return JSON.parse(readFileSync(path.join(stagedRoot, 'version.json'), 'utf8')).version;
    } catch {
      return null;
    }
  })();
  const backupDir = swapIn(stagedRoot);
  return { backupDir, version: stagedVersion, previousVersion };
}
