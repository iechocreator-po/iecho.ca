// Enregistre l'ORDRE dans lequel chaque page ÉMET ses appels d'API au démarrage (l'API est bouchonnée : seuls les appels comptent).
// On lit l'ordre d'émission côté navigateur (Network.requestWillBeSent), pas l'ordre d'arrivée au serveur, qui varie d'une exécution à l'autre.
// Sert à prouver qu'un remaniement de la séquence de démarrage (découpage des index.html, phase 3) ne change ni l'ensemble ni,
// là où on ne l'a pas voulu, l'ordre des appels.
//
// Usage : node scripts/snapshot-boot.mjs <sortie.json>
//         node scripts/snapshot-boot.mjs --compare <a.json> <b.json>
import { readFileSync, writeFileSync } from 'node:fs';
import { findChrome, launchChrome, startServer, PAGES } from './smoke-browser.mjs';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function record({ root, authenticated, chromePath }) {
  const calls = [];
  const { server, origin } = await startServer(root, { authenticated });
  const chrome = await launchChrome(chromePath);
  try {
    const { targetId } = await chrome.send('Target.createTarget', { url: 'about:blank' });
    const { sessionId } = await chrome.send('Target.attachToTarget', { targetId, flatten: true });
    let loaded; const p = new Promise((ok) => { loaded = ok; });
    chrome.on((m) => {
      if (m.sessionId !== sessionId) return;
      if (m.method === 'Page.loadEventFired') loaded();
      if (m.method === 'Network.requestWillBeSent') {
        const u = new URL(m.params.request.url);
        if (u.pathname.startsWith('/api/')) calls.push(`${m.params.request.method} ${u.pathname}`);
      }
    });
    await chrome.send('Page.enable', {}, sessionId);
    await chrome.send('Network.enable', {}, sessionId);
    await chrome.send('Page.navigate', { url: `${origin}/` }, sessionId);
    await Promise.race([p, sleep(20000)]);
    await sleep(3500);
    return calls;
  } finally { await chrome.close(); server.close(); }
}

if (process.argv[2] === '--compare') {
  const a = JSON.parse(readFileSync(process.argv[3], 'utf8')); const b = JSON.parse(readFileSync(process.argv[4], 'utf8'));
  let bad = 0;
  for (const page of Object.keys(a)) {
    const A = a[page]; const B = b[page] || [];
    const sa = [...A].sort().join('\n'); const sb = [...B].sort().join('\n');
    const memeEnsemble = sa === sb; const memeOrdre = A.join('\n') === B.join('\n');
    console.log(`${memeOrdre ? 'IDENTIQUE' : memeEnsemble ? 'MÊMES APPELS, ORDRE DIFFÉRENT' : 'APPELS DIFFÉRENTS'} : ${page} (${A.length} appels avant, ${B.length} après)`);
    if (!memeOrdre) {
      bad++;
      const only = (X, Y) => X.filter((x) => { const i = Y.indexOf(x); if (i >= 0) { Y = Y.slice(0, i).concat(Y.slice(i + 1)); return false; } return true; });
      const oa = only(A, B), ob = only(B, A);
      if (oa.length || ob.length) console.log('   manquants après :', oa, '| nouveaux après :', ob);
      else { const d = A.map((x, i) => (x === B[i] ? null : `${i}: ${x} -> ${B[i]}`)).filter(Boolean).slice(0, 12); console.log('   positions qui changent :\n     ' + d.join('\n     ')); }
    }
  }
  process.exit(bad ? 1 : 0);
} else if (process.argv[2]) {
  const chromePath = findChrome();
  if (!chromePath) { console.error('Aucun Chrome trouvé (CHROME_PATH).'); process.exit(2); }
  const all = {};
  for (const p of PAGES) { all[p.label] = await record({ ...p, chromePath }); console.log(`${p.label} : ${all[p.label].length} appels`); }
  writeFileSync(process.argv[2], JSON.stringify(all, null, 1));
  console.log('Écrit :', process.argv[2]);
} else { console.error('Usage : node scripts/snapshot-boot.mjs <sortie.json> | --compare <a.json> <b.json>'); process.exit(2); }
