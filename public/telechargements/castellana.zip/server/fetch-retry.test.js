// Tests de server/fetch-retry.js — le chemin réseau n'était couvert par
// aucun test avant le 7/9/2026 (constat de l'audit). Aucun appel réel ici :
// les fonctions injectées simulent les pannes qu'on veut voir gérées.

import test from 'node:test';
import assert from 'node:assert/strict';
import { withRetry, mapWithConcurrency, ExternalCallError } from './fetch-retry.js';

test('withRetry réessaie après un échec transitoire', async () => {
  let appels = 0;
  const flaky = async () => {
    appels += 1;
    if (appels < 2) throw new Error('panne transitoire');
    return 'ok';
  };
  assert.equal(await withRetry('source de test', flaky, { baseDelayMs: 1 }), 'ok');
  assert.equal(appels, 2, 'doit avoir réessayé exactement une fois');
});

test('withRetry n’appelle pas plus que le nombre de tentatives demandé', async () => {
  let appels = 0;
  const toujoursCassé = async () => { appels += 1; throw new Error('panne permanente'); };
  await assert.rejects(
    () => withRetry('source cassée', toujoursCassé, { tries: 3, baseDelayMs: 1 }),
    (err) => err instanceof ExternalCallError && err.tries === 3,
  );
  assert.equal(appels, 3);
});

test('withRetry rend la main sur temporisation même si l’appel ne revient jamais', async () => {
  const jamais = () => new Promise(() => {});
  await assert.rejects(
    () => withRetry('source pendue', jamais, { tries: 1, timeoutMs: 20 }),
    /temporisation dépassée/,
  );
});

test('withRetry propage le succès sans réessai inutile', async () => {
  let appels = 0;
  await withRetry('source saine', async () => { appels += 1; return 1; }, { baseDelayMs: 1 });
  assert.equal(appels, 1);
});

test('mapWithConcurrency préserve l’ordre d’entrée malgré des durées inégales', async () => {
  // Les éléments les plus tardifs se terminent en premier : si le résultat
  // suivait l'ordre d'ACHÈVEMENT, plusieurs appelants qui joignent par index
  // (screening, fondamentaux) associeraient les données au mauvais ticker.
  const items = [50, 40, 30, 20, 10];
  const out = await mapWithConcurrency(items, (ms) => new Promise((r) => setTimeout(() => r(ms), ms)), { limit: 5 });
  assert.deepEqual(out, items);
});

test('mapWithConcurrency ne dépasse jamais la limite d’appels simultanés', async () => {
  let enVol = 0;
  let maxEnVol = 0;
  await mapWithConcurrency(Array.from({ length: 20 }, (_, i) => i), async () => {
    enVol += 1;
    maxEnVol = Math.max(maxEnVol, enVol);
    await new Promise((r) => setTimeout(r, 5));
    enVol -= 1;
  }, { limit: 4 });
  assert.ok(maxEnVol <= 4, `jusqu'à ${maxEnVol} appels simultanés, limite = 4`);
});
