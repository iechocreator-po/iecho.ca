// Tests des deux axes de notation (server/scoring.js).
// Les cas sont construits à la main : un test qui recopie la sortie du code
// qu'il teste ne prouve rien.

import test from 'node:test';
import assert from 'node:assert/strict';
import { scoreSetup, scoreContexte, verdictFrom, scoreRow, SIGNAL_AGE } from './scoring.js';

const base = { smaAlignment: 'haussier', alignmentAge: 1, rsi: 55, aboveVwap: true,
               goldenCross: true, forceRelative: 8, obvTrend: 'accumulation' };

test('un setup parfait atteint le haut de la plage', () => {
  // alignement +2, signal frais +1, RSI en zone +1, prix > VWAP +1
  assert.equal(scoreSetup(base).score, 5);
});

test("l'alignement est une PORTE, pas une composante parmi d'autres", () => {
  // Sans alignement haussier, un RSI sain et un prix au-dessus du VWAP ne
  // doivent PAS fabriquer un demi-setup. C'est le défaut trouvé en regardant
  // la vraie sortie du screener : « Setup 2 » affiché à côté de
  // « pas de setup » sur la même ligne.
  const neutre = scoreSetup({ ...base, smaAlignment: 'neutre', alignmentAge: null });
  assert.equal(neutre.score, 0, 'un titre non aligné ne marque aucun point de setup');
  const baissier = scoreSetup({ ...base, smaAlignment: 'baissier', alignmentAge: null });
  assert.equal(baissier.score, -2);
});

test('un signal ancien vaut moins qu’un signal frais, toutes choses égales', () => {
  const frais = scoreSetup({ ...base, alignmentAge: SIGNAL_AGE.fraisMax });
  const vieux = scoreSetup({ ...base, alignmentAge: SIGNAL_AGE.vieuxMin + 1 });
  assert.ok(frais.score > vieux.score, `${frais.score} doit dépasser ${vieux.score}`);
  assert.equal(frais.score - vieux.score, 2, '+1 pour frais, −1 pour ancien');
});

test('une donnée absente ne pénalise jamais', () => {
  // Un titre mal servi par Yahoo ne doit pas être puni comme un mauvais titre.
  const sansRsi = scoreSetup({ ...base, rsi: null });
  assert.equal(sansRsi.score, 4, 'seul le point du RSI manque, rien n’est retiré');
  const sansVwap = scoreSetup({ ...base, aboveVwap: null });
  assert.equal(sansVwap.score, 4);
});

test('aucune donnée du tout donne null, pas zéro', () => {
  // « Pas calculable » et « neutre » sont deux choses différentes.
  const vide = { smaAlignment: null, alignmentAge: null, rsi: null, aboveVwap: null };
  assert.equal(scoreSetup(vide).score, null);
  assert.equal(scoreContexte({ goldenCross: null, forceRelative: null, obvTrend: null }).score, null);
});

test('le contexte ne note que les trois critères de choix de titre', () => {
  assert.equal(scoreContexte(base).score, 3);
  assert.equal(scoreContexte({ goldenCross: false, forceRelative: -8, obvTrend: 'distribution' }).score, -3);
  // Le RSI et l'alignement appartiennent au Setup : ils ne doivent rien
  // changer au Contexte.
  assert.equal(scoreContexte({ ...base, rsi: 99, smaAlignment: 'baissier' }).score, 3);
});

test('« trop tard » prime sur un excellent titre', () => {
  // Le cas qui justifie toute la séparation en deux axes : un titre de
  // qualité dont le mouvement est déjà fait ne doit pas ressortir « prêt ».
  const row = { ...base, alignmentAge: SIGNAL_AGE.vieuxMin + 10 };
  const r = scoreRow(row);
  assert.equal(r.verdict, 'trop tard');
  assert.equal(r.contexteScore, 3, 'le contexte reste excellent, et c’est le sujet');
});

test('« pas de setup » prime sur tout le reste', () => {
  const r = scoreRow({ ...base, smaAlignment: 'neutre', alignmentAge: null });
  assert.equal(r.verdict, 'pas de setup');
});

test('« prêt » exige les DEUX axes, pas seulement un bon timing', () => {
  assert.equal(scoreRow(base).verdict, 'prêt');
  // Setup impeccable mais contexte négatif → pas « prêt ».
  const sansContexte = scoreRow({ ...base, goldenCross: false, forceRelative: -8, obvTrend: 'distribution' });
  assert.equal(sansContexte.setupScore, 5);
  assert.equal(sansContexte.verdict, 'à surveiller');
});

test('scoreRow conserve `score` (la somme) pour ne pas casser l’export CSV', () => {
  const r = scoreRow(base);
  assert.equal(r.score, r.setupScore + r.contexteScore);
});

test('les composantes sont explicitées, pas seulement chiffrées', () => {
  // Sans ça, un score de 5 est un nombre opaque : impossible de savoir
  // POURQUOI un titre sort en tête.
  const r = scoreRow(base);
  assert.ok(r.setupParts.some((p) => p.includes('alignement haussier')));
  assert.ok(r.setupParts.some((p) => p.includes('frais')));
  assert.ok(r.contexteParts.includes('Golden Cross'));
});
