// Sessions — une ligne par connexion active, révocable/auditable (voir
// auth.js pour le raisonnement sur ce choix plutôt qu'un JWT sans état).
//
// `method` (17/10/2026) : 'password' ou 'magic_link' — l'origine de la
// session, lue par le changement de mot de passe (lib/password-rules.js).
// Colonne ajoutée par scripts/migrate-session-method.mjs. Tant que la
// migration n'a pas tourné, l'INSERT retombe sur l'ancienne forme et la
// lecture renvoie method = undefined (traité comme « mot de passe exigé ») :
// un déploiement avant la migration ne casse pas la connexion.

export async function createSession(db, userId, token, expiresAt, method = 'password') {
  try {
    await db.prepare('INSERT INTO sessions (token, user_id, expires_at, method) VALUES (?, ?, ?, ?)')
      .bind(token, userId, expiresAt, method).run();
  } catch (err) {
    if (!/no column named method|has no column/i.test(String(err?.message))) throw err;
    await db.prepare('INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)')
      .bind(token, userId, expiresAt).run();
  }
  try {
    await db.prepare("UPDATE users SET last_login_at = datetime('now'), last_seen_at = datetime('now') WHERE id = ?")
      .bind(userId).run();
  } catch { /* colonnes absentes avant scripts/migrate-user-activity.mjs : la connexion passe quand même */ }
}

// Dernière activité (18/10/2026) — appelée par le middleware d'auth à chaque
// requête authentifiée, mais n'écrit qu'au plus une fois par 10 minutes et par
// compte : la condition est dans le SQL (vraie même entre isolats), la Map
// évite la plupart des allers-retours vers D1 dans un même isolat.
const ACTIVITY_INTERVAL_MS = 10 * 60 * 1000;
const lastTouch = new Map();

export async function touchUserActivity(db, userId, now = Date.now()) {
  if (now - (lastTouch.get(userId) ?? 0) < ACTIVITY_INTERVAL_MS) return;
  lastTouch.set(userId, now);
  try {
    await db.prepare(
      "UPDATE users SET last_seen_at = datetime('now') WHERE id = ? AND (last_seen_at IS NULL OR last_seen_at < datetime('now', '-10 minutes'))",
    ).bind(userId).run();
  } catch { /* colonne absente avant migration : rien à noter */ }
}

// Retourne { token, userId, username, expiresAt, createdAt, method } si la
// session est valide, sinon null — une session expirée est supprimée au
// passage plutôt que laissée traîner en base. `s.*` plutôt qu'une liste de
// colonnes : fonctionne avant comme après la migration de `method`.
//
// Un compte DÉSACTIVÉ n'a plus de session valide (audit cloud-comptes, 20/10/2026) :
// avant, seule la CONNEXION était refusée, et une session déjà ouverte (30 jours)
// continuait de fonctionner après la désactivation par l'administrateur.
export async function findSession(db, token) {
  let row;
  try {
    row = await db.prepare(
      'SELECT s.*, u.username, u.disabled AS user_disabled FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token = ?',
    ).bind(token).first();
  } catch (err) {
    // Colonne `disabled` absente (base antérieure à scripts/migrate-users-email-magiclinks.mjs) : ancienne forme.
    if (!/no such column/i.test(String(err?.message))) throw err;
    row = await db.prepare(
      'SELECT s.*, u.username FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token = ?',
    ).bind(token).first();
  }
  if (!row) return null;
  if (row.expires_at < Date.now()) {
    await deleteSession(db, token);
    return null;
  }
  if (row.user_disabled) return null;
  return {
    token: row.token,
    userId: row.user_id,
    username: row.username,
    expiresAt: row.expires_at,
    createdAt: row.created_at,
    method: row.method,
  };
}

export async function deleteSession(db, token) {
  await db.prepare('DELETE FROM sessions WHERE token = ?').bind(token).run();
}

// Après un changement de mot de passe : toutes les AUTRES sessions du compte
// sont supprimées (jetons TradingView compris, ON DELETE CASCADE) et la
// session courante perd son passe-droit « lien de courriel récent ».
export async function revokeOtherSessions(db, userId, keepToken) {
  const res = await db.prepare('DELETE FROM sessions WHERE user_id = ? AND token != ?')
    .bind(userId, keepToken).run();
  try {
    await db.prepare("UPDATE sessions SET method = 'password' WHERE token = ?").bind(keepToken).run();
  } catch { /* colonne absente avant migration : rien à retirer */ }
  return res?.meta?.changes ?? null;
}

// Ferme TOUTES les sessions d'un compte (jetons TradingView compris, ON DELETE CASCADE). Appelée par
// l'administrateur quand il désactive un compte ou réinitialise son mot de passe : sans elle, une
// session déjà ouverte survivrait 30 jours à l'une et à l'autre (audit cloud-comptes, 20/10/2026).
export async function revokeAllSessions(db, userId) {
  const res = await db.prepare('DELETE FROM sessions WHERE user_id = ?').bind(userId).run();
  return res?.meta?.changes ?? null;
}
