// Connexion au compte TradingView (feature #367, 30/9/2026) — étape 1 :
// OAuth 2.1 (PKCE) vers le serveur MCP officiel, lecture des watchlists,
// import dans les listes du Screener, et choix de la source de données.
//
// Lecture seule : castellana n'appelle QUE `mcp-watchlist-list-watchlists`.
// Aucune écriture chez TradingView. Jetons liés à la session (db/tv-oauth.js).
// Derrière le flag `tradingview_connect` (OFF par défaut, par compte).
//
// Le retour OAuth (/api/tradingview/callback) reste DERRIÈRE la session : le
// cookie SameSite=Lax est envoyé sur la redirection de premier niveau depuis
// tradingview.com, et le `state` est lié à la session.

import { readSessionToken } from '../auth.js';
import { getEffectiveFlagsForUser } from '../db/flags.js';
import { getClientId, saveClientId, beginAuthorization, getConnection, completeAuthorization, deleteConnection } from '../db/tv-oauth.js';
import { withTvToken } from '../lib/tv-session.js';
import { getDataSource, setDataSource, DATA_SOURCES } from '../db/user-settings.js';
import { getLists, createList, MAX_TICKERS_PER_LIST } from '../db/lists.js';
import { screeningCacheKey } from '../lib/screening.js';
import { randomToken, challengeFor, registerClient, buildAuthUrl, exchangeCode, callTool } from '../lib/tv-mcp.js';
import { normalizeWatchlists, mapWatchlistSymbols } from '../lib/tv-symbols.js';

const LIST_PREFIX = 'TradingView · ';

// Changer de source de données rend périmés les résultats DÉRIVÉS en cache (screening,
// titres du secteur) : ils ont été calculés avec l'autre source. On les supprime pour cet
// utilisateur seulement (clés `screening:v2:<id>[:…]` et `sectors:topresult:v2:<id>:…`).
async function invalidateDerivedCaches(db, userId) {
  await db.prepare('DELETE FROM cache WHERE key = ? OR key LIKE ? OR key LIKE ?')
    .bind(`screening:v2:${userId}`, `screening:v2:${userId}:%`, `sectors:topresult:v2:${userId}:%`).run();
}

function tvErrorResponse(c, err) {
  if (err.code === 'TV_NOT_CONNECTED') return c.json({ error: err.message, code: err.code }, 409);
  if (String(err.code || '').startsWith('TV_')) return c.json({ error: err.message, code: err.code }, 502);
  throw err;
}

async function fetchWatchlists(db, sessionToken) {
  const payload = await withTvToken(db, sessionToken, (tok) => callTool(tok, 'mcp-watchlist-list-watchlists', {}));
  return normalizeWatchlists(payload);
}

export function registerTradingviewRoutes(app) {
  // Garde commune : le flag s'applique par compte. (data-source et disconnect n'en dépendent pas.)
  const guard = async (c, next) => {
    const flags = await getEffectiveFlagsForUser(c.env.DB, c.get('userId'));
    if (!flags.tradingview_connect) return c.json({ error: 'La connexion TradingView n\'est pas activée pour ce compte.', code: 'TV_DISABLED' }, 403);
    return next();
  };
  for (const p of ['/api/tradingview/connect', '/api/tradingview/callback', '/api/tradingview/watchlists', '/api/tradingview/import']) app.use(p, guard);

  app.get('/api/tradingview/status', async (c) => {
    const db = c.env.DB;
    const userId = c.get('userId');
    const flags = await getEffectiveFlagsForUser(db, userId);
    const conn = await getConnection(db, readSessionToken(c.req.header('Cookie')));
    const connected = !!(conn && conn.accessToken);
    let dataSource = await getDataSource(db, userId);
    // Source TradingView sans connexion (nouvelle session, jeton perdu) : incohérent → Yahoo.
    if (dataSource === 'tradingview' && !connected) { dataSource = 'yahoo'; await setDataSource(db, userId, 'yahoo'); await invalidateDerivedCaches(db, userId); }
    return c.json({
      enabled: flags.tradingview_connect === true,
      connected,
      connectedAt: conn?.connectedAt || null,
      dataSource,
    });
  });

  app.post('/api/tradingview/connect', async (c) => {
    const db = c.env.DB;
    const sessionToken = readSessionToken(c.req.header('Cookie'));
    const redirectUri = `${new URL(c.req.url).origin}/api/tradingview/callback`;
    try {
      let clientId = await getClientId(db, redirectUri);
      if (!clientId) { clientId = await registerClient(redirectUri); await saveClientId(db, redirectUri, clientId); }
      const verifier = randomToken(48);
      const state = randomToken(24);
      await beginAuthorization(db, sessionToken, { clientId, redirectUri, state, verifier });
      const url = await buildAuthUrl({ clientId, redirectUri, challenge: await challengeFor(verifier), state });
      return c.json({ url });
    } catch (err) { return tvErrorResponse(c, err); }
  });

  app.get('/api/tradingview/callback', async (c) => {
    const db = c.env.DB;
    const sessionToken = readSessionToken(c.req.header('Cookie'));
    const q = c.req.query();
    const back = (r) => c.redirect(`/?tv=${r}`, 302);
    if (q.error) { await deleteConnection(db, sessionToken); return back('refuse'); }
    const conn = await getConnection(db, sessionToken);
    // state absent, déjà consommé ou différent : on refuse sans détailler.
    if (!conn || !conn.state || !q.state || q.state !== conn.state || !q.code) return back('erreur');
    try {
      const tokens = await exchangeCode({ clientId: conn.clientId, redirectUri: conn.redirectUri, code: q.code, verifier: conn.verifier });
      await completeAuthorization(db, sessionToken, tokens);
      return back('ok');
    } catch {
      await deleteConnection(db, sessionToken);
      return back('erreur');
    }
  });

  app.post('/api/tradingview/disconnect', async (c) => {
    const db = c.env.DB;
    await deleteConnection(db, readSessionToken(c.req.header('Cookie')));
    // Sans connexion, la source TradingView n'a plus de sens : retour à Yahoo.
    if ((await getDataSource(db, c.get('userId'))) === 'tradingview') {
      await setDataSource(db, c.get('userId'), 'yahoo');
      await invalidateDerivedCaches(db, c.get('userId'));
    }
    return c.json({ ok: true });
  });

  app.get('/api/tradingview/watchlists', async (c) => {
    try {
      const lists = await fetchWatchlists(c.env.DB, readSessionToken(c.req.header('Cookie')));
      return c.json({
        watchlists: lists.map((w) => {
          const m = mapWatchlistSymbols(w.symbols, MAX_TICKERS_PER_LIST);
          return { id: w.id, name: w.name, type: w.type, active: w.active, importable: m.imported.length, skipped: m.skipped.length, truncated: m.truncated };
        }),
      });
    } catch (err) { return tvErrorResponse(c, err); }
  });

  // Importe (ou met à jour) une watchlist TradingView comme liste du Screener,
  // nommée « TradingView · <nom> ». Un ré-import REMPLACE les titres de cette liste.
  app.post('/api/tradingview/import', async (c) => {
    const db = c.env.DB;
    const userId = c.get('userId');
    const body = await c.req.json().catch(() => ({}));
    const wanted = String(body.watchlistId || '');
    if (!wanted) return c.json({ error: 'watchlistId requis.' }, 400);
    try {
      const wl = (await fetchWatchlists(db, readSessionToken(c.req.header('Cookie')))).find((w) => w.id === wanted);
      if (!wl) return c.json({ error: 'Watchlist introuvable chez TradingView.' }, 404);
      const m = mapWatchlistSymbols(wl.symbols, MAX_TICKERS_PER_LIST);
      if (m.imported.length === 0) return c.json({ error: 'Aucun symbole importable (actions et FNB des bourses US/TSX seulement).', skipped: m.skipped }, 422);

      const name = LIST_PREFIX + wl.name;
      const existing = (await getLists(db, userId)).find((l) => l.nom === name);
      const listId = existing ? existing.id : (await createList(db, userId, name)).id;
      await db.batch([
        db.prepare('DELETE FROM custom_list_tickers WHERE list_id = ?').bind(listId),
        ...m.imported.map((t) => db.prepare('INSERT INTO custom_list_tickers (list_id, ticker, exchange) VALUES (?, ?, ?)').bind(listId, t.ticker, t.exchange)),
      ]);
      await db.prepare('DELETE FROM cache WHERE key = ?').bind(screeningCacheKey(userId, `list:${listId}`)).run();
      return c.json({ listId, name, updated: !!existing, imported: m.imported.length, skipped: m.skipped, truncated: m.truncated });
    } catch (err) { return tvErrorResponse(c, err); }
  });

  // Source des données de marché (par compte). Yahoo par défaut ; TradingView
  // exige une connexion active. ÉTAPE 2 : avec TradingView, les cotations et l'historique
  // quotidien passent par TradingView (repli Yahoo, voir lib/tv-provider.js).
  app.get('/api/data-source', async (c) => c.json({ source: await getDataSource(c.env.DB, c.get('userId')), available: DATA_SOURCES }));

  app.put('/api/data-source', async (c) => {
    const db = c.env.DB;
    const body = await c.req.json().catch(() => ({}));
    const source = String(body.source || '');
    if (!DATA_SOURCES.includes(source)) return c.json({ error: 'Source inconnue.' }, 400);
    if (source === 'tradingview') {
      const flags = await getEffectiveFlagsForUser(db, c.get('userId'));
      if (!flags.tradingview_connect) return c.json({ error: 'TradingView n\'est pas activé pour ce compte.', code: 'TV_DISABLED' }, 403);
      const conn = await getConnection(db, readSessionToken(c.req.header('Cookie')));
      if (!conn || !conn.accessToken) return c.json({ error: 'Connecte d\'abord ton compte TradingView.', code: 'TV_NOT_CONNECTED' }, 409);
    }
    const changed = (await getDataSource(db, c.get('userId'))) !== source;
    await setDataSource(db, c.get('userId'), source);
    if (changed) await invalidateDerivedCaches(db, c.get('userId'));
    return c.json({ source });
  });
}
