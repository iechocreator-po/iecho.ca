// Notation d'un candidat du screening, sur DEUX axes (11/9/2026).
//
// Ce qui n'allait pas dans le score unique précédent (`scoreRow()`, alors
// dans server/index.js) :
//
//   1. Il notait RSI, Force relative, Golden Cross et OBV — alors que l'app
//      écrit elle-même, sous la checklist de la Fiche de trade : « Golden
//      Cross et Force relative servent à choisir le titre, PAS à valider
//      l'entrée ». Le score était donc composé à moitié de critères que
//      l'app déclare inaptes à décider d'une entrée.
//   2. Il ignorait purement et simplement l'alignement des moyennes — LE
//      signal d'entrée du document de design (close > SMA rapide > moyenne >
//      lente). Il était calculé par indicators.js puis jeté avant le scoring.
//   3. Il mélangeait deux questions sans rapport dans un seul nombre :
//      « ce titre est-il bon ? » et « est-ce le moment d'entrer ? ». Un titre
//      excellent mais dont le mouvement est déjà fait ressortait avec le
//      même score qu'un titre qui vient de se déclencher.
//
// D'où deux axes indépendants, qui répondent chacun à UNE question :
//
//   SETUP    — est-ce que ça se déclenche maintenant ? (timing)
//   CONTEXTE — le titre vaut-il la peine d'être suivi ? (qualité)
//
// Les trier ensemble serait revenu au problème de départ : le frontend trie
// par Setup, puis par Contexte à setup égal.

// Bandes reprises telles quelles de l'ancien `SCORE_BANDS` de
// server/index.js — dupliquées de config.js (CFG.bandes) faute de format de
// module commun entre le frontend classique et ce backend ESM, même
// limitation que SCREEN_FILTERS. Reporter à la main tout changement.
export const SCORE_BANDS = {
  rsiEntreeBas: 40,
  rsiEntreeHaut: 70,
  forceRelativeSeuil: 5,
};

// Fraîcheur du signal, en séances depuis le début de l'alignement haussier.
//
// Ces deux seuils ne sont volontairement PAS dupliqués dans config.js : le
// frontend n'en a pas besoin (il affiche l'âge brut et lit le verdict calculé
// ici), donc les mettre des deux côtés créerait une troisième source de
// vérité à resynchroniser à la main, pour rien.
export const SIGNAL_AGE = {
  fraisMax: 5,   // ≤ 5 séances : le signal vient de se déclencher
  vieuxMin: 20,  // > 20 séances : mouvement déjà largement fait
};

// --- Axe SETUP : est-ce que ça se déclenche maintenant ? ---------------
//
// Plage −2 … +5. L'alignement n'est PAS une composante parmi d'autres :
// c'est la PORTE. S'il n'est pas haussier, il n'y a pas de setup, et les
// autres composantes n'ont rien à modifier.
//
// ⚠️ Corrigé en regardant la vraie sortie du screener, pas à la relecture.
// Première version : alignement à ±1 comme les autres composantes. Résultat,
// des titres NON alignés affichaient « Setup 2 » (RSI en zone +1, prix >
// VWAP +1) juste à côté du verdict « pas de setup » — deux affirmations
// contradictoires sur la même ligne. Un RSI sain sur un titre sans
// alignement ne fait pas un demi-setup : il ne fait pas de setup du tout.
export function scoreSetup(row) {
  let score = 0;
  let hasData = false;
  const parts = [];

  if (row.smaAlignment != null) {
    hasData = true;
    if (row.smaAlignment === 'baissier') {
      // Alignement inverse : c'est le contexte d'une vente, pas d'un achat.
      return { score: -2, parts: ['alignement baissier'] };
    }
    if (row.smaAlignment !== 'haussier') {
      // 'neutre' — les moyennes ne sont pas dans l'ordre. Zéro, et on
      // s'arrête : rien à moduler.
      return { score: 0, parts: ['pas d\'alignement'] };
    }
    score += 2;
    parts.push('alignement haussier');
  }

  // Fraîcheur — la composante qui matérialise « premier alignement » du
  // design doc, et qui manquait entièrement jusqu'ici.
  if (row.alignmentAge != null) {
    hasData = true;
    if (row.alignmentAge <= SIGNAL_AGE.fraisMax) { score += 1; parts.push(`signal frais (${row.alignmentAge} j)`); }
    else if (row.alignmentAge > SIGNAL_AGE.vieuxMin) { score -= 1; parts.push(`signal ancien (${row.alignmentAge} j)`); }
  }

  if (row.rsi != null) {
    hasData = true;
    if (row.rsi > SCORE_BANDS.rsiEntreeHaut) { score -= 1; parts.push('RSI en surachat'); }
    else if (row.rsi >= SCORE_BANDS.rsiEntreeBas) { score += 1; parts.push("RSI en zone d'entrée"); }
    // entre 30 et rsiEntreeBas, et sous 30 : zone amber, 0 point
  }

  // Prix > VWAP : signal de séance, d'où +1 sans pénalité symétrique — être
  // sous le VWAP en cours de journée n'invalide pas un setup quotidien.
  if (row.aboveVwap === true) { hasData = true; score += 1; parts.push('prix > VWAP'); }
  else if (row.aboveVwap === false) { hasData = true; }

  return { score: hasData ? score : null, parts };
}

// --- Axe CONTEXTE : le titre vaut-il la peine d'être suivi ? -----------
//
// Plage −3 … +3. Exactement les trois critères que l'app qualifie de
// « choix du titre » — Golden Cross, force relative, OBV.
export function scoreContexte(row) {
  let score = 0;
  let hasData = false;
  const parts = [];

  if (row.goldenCross === true) { hasData = true; score += 1; parts.push('Golden Cross'); }
  else if (row.goldenCross === false) { hasData = true; score -= 1; parts.push('pas de Golden Cross'); }

  if (row.forceRelative != null) {
    hasData = true;
    if (row.forceRelative > SCORE_BANDS.forceRelativeSeuil) { score += 1; parts.push('surperforme l\'indice'); }
    else if (row.forceRelative < -SCORE_BANDS.forceRelativeSeuil) { score -= 1; parts.push('sous-performe l\'indice'); }
  }

  if (row.obvTrend === 'accumulation') { hasData = true; score += 1; parts.push('OBV en accumulation'); }
  else if (row.obvTrend === 'distribution') { hasData = true; score -= 1; parts.push('OBV en distribution'); }

  return { score: hasData ? score : null, parts };
}

// --- Verdict dérivé des deux axes -------------------------------------
//
// L'ordre des tests compte : « pas de setup » et « trop tard » sont des
// constats sur le TIMING qui priment sur la qualité du titre. Un excellent
// titre dont le mouvement est déjà fait doit ressortir « trop tard », pas
// « prêt » — c'est précisément ce que l'ancien score unique ne savait pas
// dire.
export function verdictFrom(setup, contexte, row) {
  if (setup == null && contexte == null) return 'erreur';
  if (row.smaAlignment != null && row.smaAlignment !== 'haussier') return 'pas de setup';
  if (row.alignmentAge != null && row.alignmentAge > SIGNAL_AGE.vieuxMin) return 'trop tard';
  if (row.smaAlignment == null) return 'à surveiller'; // alignement non calculable
  if ((setup ?? 0) >= 2 && (contexte ?? 0) >= 1) return 'prêt';
  return 'à surveiller';
}

// Point d'entrée unique, appelé par la route /api/screening pour chaque
// ligne. `score` (la somme) est conservé parce que l'export CSV et le tri
// historique s'appuient dessus — les deux axes s'y ajoutent, ils ne le
// remplacent pas.
export function scoreRow(row) {
  const setup = scoreSetup(row);
  const contexte = scoreContexte(row);
  const verdict = verdictFrom(setup.score, contexte.score, row);
  const total = setup.score == null && contexte.score == null
    ? null
    : (setup.score ?? 0) + (contexte.score ?? 0);
  return {
    setupScore: setup.score,
    setupParts: setup.parts,
    contexteScore: contexte.score,
    contexteParts: contexte.parts,
    score: total,
    verdict,
  };
}
