// Alertes de POSITIONS (#379) — orchestration locale : positions ouvertes du Journal
// (jambes d'options vendues et actions), observations courantes, transitions,
// boîte d'alertes et courriel groupé. La décision est pure (position-alerts-logic.js).
// LOCAL uniquement, évalué tant que castellana tourne (voir list-alerts.js).

import { db } from './db.js';
import { listOptionTrades } from './option-trades.js';
import { listTrades } from './trades.js';
import { getOptionChain } from './options.js';
import { getQuotes } from './quotes.js';
import { getEffectiveParams } from './labo-params.js';
import { evaluatePositionObservation, POSITION_KINDS, daysUntil, capturePercent } from './position-alerts-logic.js';
import { emailAvailable, sendAlertEmail } from './alert-email.js';
import { getAlertEmails, getPositionAlertSettings } from './app-settings.js';
import { buildDigest } from './list-alerts-logic.js';

db.exec(`
  CREATE TABLE IF NOT EXISTS position_alert_state (
    kind TEXT NOT NULL,
    ref_id INTEGER NOT NULL,
    value TEXT NOT NULL,
    PRIMARY KEY (kind, ref_id)
  );
  CREATE TABLE IF NOT EXISTS position_alert_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL,
    ref_id INTEGER NOT NULL,
    ticker TEXT NOT NULL,
    message TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    read_at TEXT
  );
`);

export function listPositionEvents({ limit = 100 } = {}) {
  return db.prepare('SELECT id, kind, ticker, message, created_at AS createdAt, read_at AS readAt FROM position_alert_events ORDER BY id DESC LIMIT ?').all(limit);
}

export function markPositionEventsRead() {
  db.prepare("UPDATE position_alert_events SET read_at = datetime('now') WHERE read_at IS NULL").run();
}

// Les situations réactivées repartent d'une page blanche (voir kindsReenabled) : sans cela, un vieil état mémorisé déclencherait une alerte au réveil.
export function resetPositionAlertState(kinds) {
  for (const k of kinds) db.prepare('DELETE FROM position_alert_state WHERE kind = ?').run(k);
}

export function hasOpenPositions() {
  if (!getPositionAlertSettings().enabled) return false;
  return listOptionTrades({ statut: 'ouvert' }).length > 0 || listTrades({ open: true }).length > 0;
}

let running = false;

export async function runPositionAlerts() {
  if (running) throw Object.assign(new Error('Une évaluation est déjà en cours.'), { status: 409 });
  running = true;
  const summary = { legs: 0, stocks: 0, newAlerts: 0, errors: [], email: { sent: 0, skipped: null } };
  try {
    const reglages = getPositionAlertSettings();
    if (!reglages.enabled) { summary.disabled = true; return summary; } // coupées par l'utilisateur : aucun appel Yahoo, rien d'enregistré
    const actifs = (k) => reglages.kinds[k];
    const seuilPct = (getEffectiveParams('roue') || {}).profitTakeMin ?? 50;
    const legs = (actifs('echeance') || actifs('profit')) ? listOptionTrades({ statut: 'ouvert' }) : [];
    const stocks = actifs('stop') ? listTrades({ open: true }) : [];
    summary.legs = legs.length;
    summary.stocks = stocks.length;

    // Observations : [{ kind, refId, obs }] — un champ null = donnée indisponible.
    const observations = [];
    for (const leg of legs) {
      const base = { ticker: leg.ticker, type: leg.type, strike: leg.strike, echeance: leg.echeance, primeRecue: leg.prime_recue, seuilPct };
      if (actifs('echeance')) observations.push({ kind: 'echeance', refId: leg.id, obs: { ...base, dte: daysUntil(leg.echeance) } });
      if (!actifs('profit')) continue; // pas de chaîne d'options à tirer si cette situation est coupée
      let rachat = null;
      try {
        const chain = await getOptionChain(leg.ticker, { expiry: leg.echeance });
        const contract = (leg.type === 'call' ? chain.calls : chain.puts).find((c) => c.strike === leg.strike);
        rachat = contract ? (contract.ask ?? contract.last ?? null) : null;
      } catch (err) { summary.errors.push(`${leg.ticker} ${leg.echeance} : ${err.message}`); }
      observations.push({ kind: 'profit', refId: leg.id, obs: { ...base, rachat, capturePct: capturePercent(leg.prime_recue, rachat) } });
    }
    let quotes = new Map();
    if (stocks.length) {
      try { quotes = await getQuotes([...new Set(stocks.map((t) => t.ticker))]); } catch (err) { summary.errors.push(`cotations : ${err.message}`); }
    }
    for (const t of stocks) {
      observations.push({ kind: 'stop', refId: t.id, obs: { ticker: t.ticker, price: quotes.get(t.ticker)?.price ?? null, stop: t.stop_initial } });
    }

    const getState = db.prepare('SELECT value FROM position_alert_state WHERE kind = ? AND ref_id = ?');
    const setState = db.prepare('INSERT INTO position_alert_state (kind, ref_id, value) VALUES (?, ?, ?) ON CONFLICT(kind, ref_id) DO UPDATE SET value = excluded.value');
    const addEvent = db.prepare('INSERT INTO position_alert_events (kind, ref_id, ticker, message) VALUES (?, ?, ?, ?)');
    const fired = [];
    db.transaction(() => {
      for (const { kind, refId, obs } of observations) {
        const prev = getState.get(kind, refId)?.value ?? null;
        const r = evaluatePositionObservation(kind, obs, prev);
        if (r.state != null) setState.run(kind, refId, r.state);
        if (r.notify) { addEvent.run(kind, refId, obs.ticker, r.message); fired.push({ kind, message: r.message }); }
      }
      // Positions fermées depuis : leur état n'a plus lieu d'être.
      const openLegs = new Set(legs.map((l) => l.id));
      const openStocks = new Set(stocks.map((t) => t.id));
      for (const row of db.prepare('SELECT kind, ref_id FROM position_alert_state').all()) {
        const alive = row.kind === 'stop' ? openStocks.has(row.ref_id) : openLegs.has(row.ref_id);
        if (!alive) db.prepare('DELETE FROM position_alert_state WHERE kind = ? AND ref_id = ?').run(row.kind, row.ref_id);
      }
    })();
    summary.newAlerts = fired.length;

    if (fired.length) {
      const to = getAlertEmails();
      if (!to.length) summary.email.skipped = 'aucune adresse (Réglages → TradingView) — les alertes sont dans la boîte de l\'app';
      else if (!reglages.email) summary.email.skipped = 'courriels de positions désactivés (Réglages) — les alertes sont dans la boîte de l\'app';
      else if (!emailAvailable()) summary.email.skipped = 'clé Resend absente (RESEND_API_KEY dans .env) — les alertes sont dans la boîte de l\'app';
      else {
        const groups = Object.keys(POSITION_KINDS).map((k) => ({ listLabel: 'Positions ouvertes', ruleLabel: POSITION_KINDS[k].label, items: fired.filter((f) => f.kind === k).map((f) => f.message) })).filter((g) => g.items.length);
        for (const a of to) { try { await sendAlertEmail(a, buildDigest(groups)); summary.email.sent += 1; } catch (err) { summary.errors.push(`courriel vers ${a} : ${err.message}`); } }
      }
    }
    return summary;
  } finally {
    running = false;
  }
}
