// Les fichiers js/ sont des scripts CLASSIQUES : tous leurs noms de premier niveau partagent la même
// portée globale. Deux `function x` de même nom : la seconde écrase la première en silence. Un `const x`
// après une `function x` : SyntaxError, et TOUT le second fichier ne se charge pas. C'est arrivé le
// 13/10/2026 : un `function optNum` (options-analytics.js, #433) contre le `const optNum` de
// options-common.js. Les tests unitaires ne le voyaient pas (ils évaluent chaque fichier seul).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const ROOT = new URL('..', import.meta.url);
const DECL = /^(?:async\s+)?(?:function\*?\s+([A-Za-z_$][\w$]*)|(?:const|let|var|class)\s+([A-Za-z_$][\w$]*))/gm;

for (const page of ['index.html', 'cloud/public/index.html']) {
  test(`${page} : aucun nom global déclaré deux fois par ses scripts`, () => {
    const html = readFileSync(new URL(page, ROOT), 'utf8');
    const base = page.startsWith('cloud/') ? 'cloud/public/' : '';
    const seen = new Map();
    const add = (name, where) => { if (!seen.has(name)) seen.set(name, []); seen.get(name).push(where); };
    for (const [, src] of html.matchAll(/<script src="([^"]+\.js)"/g)) {
      if (/^https?:/.test(src)) continue;
      let code;
      try { code = readFileSync(new URL(base + src, ROOT), 'utf8'); } catch { continue; }
      for (const m of code.matchAll(DECL)) add(m[1] || m[2], src);
    }
    for (const [, code] of html.matchAll(/<script>([\s\S]*?)<\/script>/g)) for (const m of code.matchAll(DECL)) add(m[1] || m[2], 'script en ligne');
    // Chaque script doit au moins se compiler : une accolade en trop (16/10/2026, roue-tab.js) faisait
    // disparaître tout l'onglet dans le navigateur alors que tous les tests passaient.
    for (const [, src] of html.matchAll(/<script src="([^"]+\.js)"/g)) {
      if (/^https?:/.test(src)) continue;
      let code;
      try { code = readFileSync(new URL(base + src, ROOT), 'utf8'); } catch { continue; }
      assert.doesNotThrow(() => new vm.Script(code, { filename: src }), `${src} ne se compile pas`);
    }
    const dups = [...seen].filter(([, w]) => w.length > 1).map(([n, w]) => `${n} (${w.join(', ')})`);
    assert.deepEqual(dups, []);
  });
}
