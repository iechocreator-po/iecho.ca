// js/labo-schema.js — Schéma des paramètres des stratégies d'options (onglet
// Labo). SOURCE UNIQUE des valeurs par défaut et des règles de validation.
//
// Trois consommateurs, une seule définition :
//   - le navigateur (script classique, chargé avant js/strategies-labo.js) ;
//   - le serveur local (server/labo-params.js l'évalue, même motif que
//     server/sizing.test.js) ;
//   - le Worker cloud, via une copie ESM GÉNÉRÉE (cloud/src/lib/labo-schema.js,
//     `npm run sync:cloud`) — un test vérifie qu'elle ne dérive pas.
//
// Chaque stratégie possède l'INTÉGRALITÉ de ses paramètres (rien n'est
// partagé entre 'roue' et 'debit-spreads', même quand les défauts sont
// identiques) : l'utilisateur règle chaque stratégie indépendamment.
//
// Seules les SURCHARGES sont stockées en base (voir laboMergeOverrides) : un
// futur changement de défaut profite à qui n'a pas touché la valeur.
//
// Prévu pour les stratégies personnalisées (non construites) : un id
// 'custom:<uuid>' portera sa propre définition (même forme que ci-dessous)
// dans strategy_params.definition_json ; laboResolveStrategy() est le seul
// point qui sait où chercher.
//
// Ce fichier ne doit contenir que des déclarations de premier niveau (const /
// function) : il est évalué tel quel par le serveur et recopié en ESM.

// ---- Fabrique de paramètres (garde le tableau lisible) ----
function _p(key, label, group, type, def, min, max, step, unit, lte) {
  const p = { key, label, group, type, default: def, min, max, step, unit: unit || '' };
  if (lte) p.lte = lte; // cette valeur doit rester ≤ la valeur de la clé `lte`
  return p;
}
const _DTE = (pfx, label, min, max) => [
  _p(pfx + 'DteMin', label + ' — échéance min', label, 'int', min, 1, 1000, 1, 'jours', pfx + 'DteMax'),
  _p(pfx + 'DteMax', label + ' — échéance max', label, 'int', max, 1, 1000, 1, 'jours'),
];
const _DELTA = (pfx, label, min, max) => [
  _p(pfx + 'DeltaMin', label + ' — Delta min', label, 'float', min, 0.01, 0.99, 0.01, '', pfx + 'DeltaMax'),
  _p(pfx + 'DeltaMax', label + ' — Delta max', label, 'float', max, 0.01, 0.99, 0.01, ''),
];
const _PROFIT = () => [
  _p('profitTakeMin', 'Prise de profit — min', 'Sortie', 'int', 50, 1, 100, 1, '%', 'profitTakeMax'),
  _p('profitTakeMax', 'Prise de profit — max', 'Sortie', 'int', 80, 1, 100, 1, '%'),
];
const _RATE = () => _p('riskFreePct', 'Taux sans risque', 'Calcul', 'float', 4, 0, 30, 0.1, '%');
const _CONTRACT = () => _p('contractSize', 'Actions par contrat', 'Calcul', 'int', 100, 1, 10000, 1, 'actions');

const LABO_SCHEMA = {
  version: 1,
  strategies: {
    roue: {
      params: [
        ..._DTE('put', 'Put vendu', 5, 10),
        ..._DELTA('put', 'Put vendu', 0.15, 0.25),
        _p('probOtmMin', 'Chances d\'expirer hors la monnaie — min', 'Put vendu', 'int', 75, 1, 99, 1, '%', 'probOtmMax'),
        _p('probOtmMax', 'Chances d\'expirer hors la monnaie — max', 'Put vendu', 'int', 85, 1, 99, 1, '%'),
        ..._DTE('call', 'Call vendu', 5, 10),
        ..._DELTA('call', 'Call vendu', 0.15, 0.25),
        ..._PROFIT(),
        _CONTRACT(),
        _RATE(),
      ],
    },
    'debit-spreads': {
      params: [
        ..._DTE('call', 'Bull Call Spread', 30, 45),
        ..._DELTA('call', 'Bull Call Spread', 0.15, 0.25),
        ..._DTE('put', 'Bear Put Spread', 30, 45),
        ..._DELTA('put', 'Bear Put Spread', 0.15, 0.25),
        ..._PROFIT(),
        _RATE(),
      ],
    },
    'credit-spreads': {
      params: [
        ..._DTE('put', 'Bull Put Spread', 30, 45),
        ..._DELTA('put', 'Bull Put Spread', 0.15, 0.25),
        ..._DTE('call', 'Bear Call Spread', 30, 45),
        ..._DELTA('call', 'Bear Call Spread', 0.15, 0.25),
        _p('spreadWidthPct', 'Largeur du spread (% du prix)', 'Spread', 'float', 5, 0.5, 50, 0.5, '%'),
        _p('creditMinPct', 'Crédit minimal (% de la largeur)', 'Spread', 'int', 33, 5, 90, 1, '%'),
        ..._PROFIT(),
        _p('stopLossMult', 'Stop — perte égale à … fois le crédit', 'Sortie', 'float', 2, 1, 10, 0.5, '×'),
        _RATE(),
      ],
    },
    pmcc: {
      params: [
        _p('leapsDteMinJours', 'LEAPS — échéance minimale', 'LEAPS acheté', 'int', 180, 1, 2000, 1, 'jours', 'leapsDteTypiqueJours'),
        _p('leapsDteTypiqueJours', 'LEAPS — échéance typique', 'LEAPS acheté', 'int', 365, 1, 2000, 1, 'jours'),
        ..._DELTA('leaps', 'LEAPS acheté', 0.70, 0.85),
        _p('rouleAvantJours', 'Rouler le LEAPS à', 'LEAPS acheté', 'int', 90, 1, 1000, 1, 'jours'),
        ..._DTE('call', 'Call court vendu', 30, 45),
        ..._DELTA('call', 'Call court vendu', 0.15, 0.25),
        _CONTRACT(),
        _RATE(),
      ],
    },
  },
};

// Résout la définition d'une stratégie. Aujourd'hui : intégrées seulement.
// Plus tard : 'custom:<uuid>' → definition (même forme) fournie par
// l'appelant depuis strategy_params.definition_json.
function laboResolveStrategy(id, customDefinition) {
  if (LABO_SCHEMA.strategies[id]) return LABO_SCHEMA.strategies[id];
  if (customDefinition && Array.isArray(customDefinition.params)) return customDefinition;
  return null;
}

function laboDefaults(id, customDefinition) {
  const def = laboResolveStrategy(id, customDefinition);
  if (!def) return null;
  const out = {};
  for (const p of def.params) out[p.key] = p.default;
  return out;
}

// Valeurs effectives = défauts ⊕ surcharges (les clés inconnues sont ignorées).
function laboEffectiveParams(id, overrides, customDefinition) {
  const out = laboDefaults(id, customDefinition);
  if (!out) return null;
  for (const [k, v] of Object.entries(overrides || {})) {
    if (k in out) out[k] = v;
  }
  return out;
}

// Valide `values` (partiel) appliqué par-dessus `currentOverrides`. Retourne
// { errors: [...], overrides } — `overrides` est le NOUVEL ensemble de
// surcharges, débarrassé de toute valeur égale à son défaut (une valeur
// remise au défaut n'est plus une surcharge). Aucune écriture ici : pur.
function laboMergeOverrides(id, currentOverrides, values, customDefinition) {
  const def = laboResolveStrategy(id, customDefinition);
  if (!def) return { errors: [`Stratégie inconnue ou sans paramètres : ${id}`], overrides: null };
  const byKey = {};
  for (const p of def.params) byKey[p.key] = p;
  const errors = [];
  const next = { ...(currentOverrides || {}) };
  for (const [key, raw] of Object.entries(values || {})) {
    const p = byKey[key];
    if (!p) { errors.push(`Paramètre inconnu : ${key}`); continue; }
    const n = typeof raw === 'number' ? raw : Number(String(raw).replace(',', '.'));
    if (raw === '' || raw === null || !Number.isFinite(n)) { errors.push(`${p.label} : nombre attendu.`); continue; }
    if (p.type === 'int' && !Number.isInteger(n)) { errors.push(`${p.label} : entier attendu.`); continue; }
    if (n < p.min || n > p.max) { errors.push(`${p.label} : entre ${p.min} et ${p.max}${p.unit ? ' ' + p.unit : ''}.`); continue; }
    next[key] = n;
  }
  if (errors.length) return { errors, overrides: null };
  // Contrôle d'ordre des plages, sur les valeurs EFFECTIVES résultantes.
  const eff = laboEffectiveParams(id, next, customDefinition);
  for (const p of def.params) {
    if (p.lte && eff[p.key] > eff[p.lte]) {
      errors.push(`${p.label} (${eff[p.key]}) ne peut pas dépasser ${byKey[p.lte].label} (${eff[p.lte]}).`);
    }
  }
  if (errors.length) return { errors, overrides: null };
  for (const p of def.params) {
    if (p.key in next && next[p.key] === p.default) delete next[p.key];
  }
  return { errors: [], overrides: next };
}
