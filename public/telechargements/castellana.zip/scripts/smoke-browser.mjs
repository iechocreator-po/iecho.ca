// Test de fumée dans un VRAI navigateur (Chrome headless), sans dépendance npm.
//
// Pourquoi : deux pannes réelles étaient invisibles aux tests unitaires — une accolade en trop dans
// roue-tab.js (17/10/2026) et un nom global déclaré deux fois, `optNum` (13/10/2026). Dans les deux cas
// un onglet disparaissait en silence. Seul un navigateur qui exécute les scripts le voit.
//
// Ce que fait le test, pour chacune des deux pages (local : index.html ; cloud : cloud/public/index.html) :
//   1. sert le dossier en statique sur 127.0.0.1 (port libre) ; `/api/*` répond par un bouchon (503, ou 401/200
//      pour la session côté cloud) — aucune base, aucun réseau, aucune donnée réelle ;
//   2. charge la page dans Chrome ; rapporte toute exception non attrapée, erreur de syntaxe, ressource
//      (script, CSS) introuvable ;
//   3. clique chaque onglet VISIBLE et vérifie que son panneau devient actif.
//
// Zéro dépendance : Chrome est piloté par le protocole DevTools (WebSocket natif de Node >= 22). Raison : le
// paquet des testeurs se réinstalle avec `npm install`, et « Node comme seul prérequis » est un acquis (7/9/2026).
// Chrome doit être présent (variable CHROME_PATH, Google Chrome, ou le cache de Puppeteer) ; sinon le test est IGNORÉ
// avec un message, jamais faux-vert en silence.
//
// Usage : node scripts/smoke-browser.mjs            (les deux pages)
//         npm run test:smoke                         (idem + auto-test qui injecte de vraies pannes)

import { spawn } from 'node:child_process';
import { createServer } from 'node:http';
import { existsSync, mkdtempSync, readFileSync, readdirSync, rmSync, statSync } from 'node:fs';
import { homedir, tmpdir } from 'node:os';
import { extname, join, normalize, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const REPO = fileURLToPath(new URL('..', import.meta.url));
const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.json': 'application/json', '.png': 'image/png',
  '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.woff': 'font/woff', '.webp': 'image/webp',
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function findChrome() {
  const env = process.env.CHROME_PATH;
  if (env && existsSync(env)) return env;
  const fixed = [
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/Applications/Chromium.app/Contents/MacOS/Chromium',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    '/usr/bin/google-chrome', '/usr/bin/chromium', '/usr/bin/chromium-browser',
  ];
  for (const p of fixed) if (existsSync(p)) return p;
  // Cache de Puppeteer : ~/.cache/puppeteer/chrome/<version>/chrome-<plateforme>/...
  const cache = join(homedir(), '.cache', 'puppeteer', 'chrome');
  if (existsSync(cache)) {
    for (const v of readdirSync(cache).sort().reverse()) {
      const dir = join(cache, v);
      for (const sub of readdirSync(dir)) {
        const c = [
          join(dir, sub, 'Google Chrome for Testing.app', 'Contents', 'MacOS', 'Google Chrome for Testing'),
          join(dir, sub, 'chrome'), join(dir, sub, 'chrome.exe'),
        ].find((x) => existsSync(x));
        if (c) return c;
      }
    }
  }
  return null;
}

// ---- serveur statique + bouchon d'API -------------------------------------------------------
export function startServer(root, { authenticated, overrides = {}, apiStub = null }) {
  const base = resolve(root);
  const server = createServer((req, res) => {
    const url = new URL(req.url, 'http://x');
    const path = decodeURIComponent(url.pathname);
    if (path.startsWith('/api/')) {
      // Réponses fournies par le test (données d'exemple, y compris piégées) ; sinon le bouchon habituel plus bas.
      const custom = apiStub ? apiStub(req.method, path, url.searchParams) : undefined;
      if (custom !== undefined) { res.writeHead(custom.status || 200, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify(custom.body)); }
      const json = (code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
      if (path === '/api/auth/me') return authenticated ? json(200, { username: 'smoke', method: 'password' }) : json(401, { error: 'non connecté' });
      return json(503, { error: 'smoke : API absente' });
    }
    const rel = path === '/' ? 'index.html' : path.replace(/^\/+/, '');
    if (overrides[rel] !== undefined) { res.writeHead(200, { 'Content-Type': TYPES[extname(rel)] || 'text/plain' }); return res.end(overrides[rel]); }
    const file = normalize(join(base, rel));
    const type = TYPES[extname(file).toLowerCase()];
    // Liste blanche d'extensions : jamais .env, .sqlite, .md, ni rien hors du dossier servi.
    if (!type || !file.startsWith(base + sep) || !existsSync(file) || !statSync(file).isFile()) { res.writeHead(404); return res.end('introuvable'); }
    res.writeHead(200, { 'Content-Type': type }); res.end(readFileSync(file));
  });
  return new Promise((ok) => server.listen(0, '127.0.0.1', () => ok({ server, origin: `http://127.0.0.1:${server.address().port}` })));
}

// ---- client DevTools minimal ------------------------------------------------------------------
export async function launchChrome(chromePath) {
  const profile = mkdtempSync(join(tmpdir(), 'castellana-smoke-'));
  const proc = spawn(chromePath, [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check', '--disable-extensions',
    `--user-data-dir=${profile}`, '--remote-debugging-port=0', 'about:blank',
  ], { stdio: ['ignore', 'ignore', 'pipe'] });
  const wsUrl = await new Promise((ok, ko) => {
    const t = setTimeout(() => ko(new Error('Chrome n\'a pas annoncé son port DevTools en 20 s')), 20000);
    let buf = '';
    proc.stderr.on('data', (d) => { buf += d; const m = buf.match(/DevTools listening on (ws:\/\/\S+)/); if (m) { clearTimeout(t); ok(m[1]); } });
    proc.on('exit', () => { clearTimeout(t); ko(new Error('Chrome s\'est arrêté au démarrage')); });
  });
  const ws = new WebSocket(wsUrl);
  await new Promise((ok, ko) => { ws.onopen = ok; ws.onerror = () => ko(new Error('connexion DevTools impossible')); });
  let id = 0; const pending = new Map(); const listeners = new Set();
  ws.onmessage = (e) => {
    const m = JSON.parse(e.data);
    if (m.id) { const p = pending.get(m.id); pending.delete(m.id); if (p) (m.error ? p.ko(new Error(m.error.message)) : p.ok(m.result)); }
    else listeners.forEach((f) => f(m));
  };
  const send = (method, params = {}, sessionId) => new Promise((ok, ko) => { const i = ++id; pending.set(i, { ok, ko }); ws.send(JSON.stringify({ id: i, method, params, sessionId })); });
  const close = async () => { try { ws.close(); } catch {} proc.kill(); await sleep(200); try { rmSync(profile, { recursive: true, force: true }); } catch {} };
  return { send, on: (f) => { listeners.add(f); return () => listeners.delete(f); }, close };
}

// ---- le test d'une page -------------------------------------------------------------------------
/**
 * @param {{root:string, label:string, authenticated?:boolean, overrides?:Record<string,string>, chromePath:string}} o
 * @returns {Promise<{label:string, ok:boolean, problems:string[], tabs:{tab:string, visible:boolean, clicked:boolean, active:boolean}[]}>}
 */
export async function smokePage({ root, label, authenticated = false, overrides = {}, chromePath }) {
  const { server, origin } = await startServer(root, { authenticated, overrides });
  const chrome = await launchChrome(chromePath);
  const problems = [];
  const tabs = [];
  try {
    const { targetId } = await chrome.send('Target.createTarget', { url: 'about:blank' });
    const { sessionId } = await chrome.send('Target.attachToTarget', { targetId, flatten: true });
    const send = (m, p) => chrome.send(m, p, sessionId);
    const isApi = (s) => /\/api\//.test(s || '');
    let loaded;
    const loadedP = new Promise((ok) => { loaded = ok; });
    chrome.on((m) => {
      if (m.sessionId !== sessionId) return;
      const p = m.params || {};
      if (m.method === 'Runtime.exceptionThrown') {
        const d = p.exceptionDetails || {};
        problems.push(`exception : ${(d.exception && d.exception.description || d.text || '?').split('\n')[0]} (${d.url || 'page'}:${(d.lineNumber ?? 0) + 1})`);
      } else if (m.method === 'Log.entryAdded' && p.entry.level === 'error' && !isApi(p.entry.url) && !isApi(p.entry.text)) {
        problems.push(`erreur de console : ${String(p.entry.text).slice(0, 200)} ${p.entry.url || ''}`);
      } else if (m.method === 'Network.responseReceived' && p.response.status >= 400 && !isApi(p.response.url)) {
        problems.push(`ressource en échec HTTP ${p.response.status} : ${p.response.url.replace(origin, '')}`);
      } else if (m.method === 'Page.loadEventFired') loaded();
    });
    for (const d of ['Runtime', 'Log', 'Page', 'Network']) await send(`${d}.enable`);
    await send('Page.navigate', { url: `${origin}/` });
    await Promise.race([loadedP, sleep(20000)]);
    await sleep(2500); // laisse démarrer l'app (appels d'API bouchonnés, rendus initiaux)

    const evalJs = async (expression) => {
      const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
      if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
      return r.result.value;
    };
    const title = await evalJs('document.title');
    const found = await evalJs(`[...document.querySelectorAll('.tab-btn')].map(b => ({ tab: b.dataset.tab, visible: b.offsetParent !== null && getComputedStyle(b).display !== 'none' }))`);
    if (!found.length) problems.push('aucun onglet (.tab-btn) trouvé : la page ne s\'est pas construite');
    if (!authenticated && (await evalJs(`!!document.getElementById('login-overlay')`))) {
      const shown = await evalJs(`getComputedStyle(document.getElementById('login-overlay')).display !== 'none'`);
      if (!shown) problems.push('écran de connexion absent alors que la session est refusée (401)');
    }
    for (const t of found) {
      const row = { tab: t.tab, visible: t.visible, clicked: false, active: false };
      tabs.push(row);
      const hasPanel = await evalJs(`!!document.getElementById('tab-' + ${JSON.stringify(t.tab)})`);
      if (!hasPanel) problems.push(`onglet « ${t.tab} » : panneau #tab-${t.tab} introuvable`);
      if (!t.visible || !hasPanel) continue; // onglet masqué par un feature flag : non testé, signalé comme tel
      if (!authenticated && !(await evalJs(`getComputedStyle(document.getElementById('app-container') || document.body).display !== 'none'`))) continue;
      await evalJs(`document.querySelector('.tab-btn[data-tab="' + ${JSON.stringify(t.tab)} + '"]').click()`);
      row.clicked = true;
      await sleep(350);
      row.active = await evalJs(`document.getElementById('tab-' + ${JSON.stringify(t.tab)}).classList.contains('is-active')`);
      if (!row.active) problems.push(`onglet « ${t.tab} » : cliqué mais son panneau n'est pas devenu actif`);
    }
    return { label, title, ok: problems.length === 0, problems: [...new Set(problems)], tabs };
  } finally {
    await chrome.close();
    server.close();
  }
}

/**
 * Ouvre une page dans Chrome (API bouchonnée par `apiStub`), puis exécute `scenario({ ev, errors, origin, sleep })`.
 * `ev(expr)` évalue une expression dans la page (promesses attendues) ; `errors` collecte les exceptions non attrapées.
 * Sert aux tests qui ont besoin de DONNÉES (onglets derrière un drapeau, données piégées).
 */
export async function withPage({ root, authenticated = false, apiStub = null, overrides = {}, chromePath }, scenario) {
  const { server, origin } = await startServer(root, { authenticated, apiStub, overrides });
  const chrome = await launchChrome(chromePath);
  const errors = [];
  try {
    const { targetId } = await chrome.send('Target.createTarget', { url: 'about:blank' });
    const { sessionId } = await chrome.send('Target.attachToTarget', { targetId, flatten: true });
    const send = (m, p) => chrome.send(m, p, sessionId);
    let loaded; const loadedP = new Promise((ok) => { loaded = ok; });
    chrome.on((m) => {
      if (m.sessionId !== sessionId) return;
      if (m.method === 'Page.loadEventFired') loaded();
      if (m.method === 'Runtime.exceptionThrown') { const d = m.params.exceptionDetails; errors.push((d.exception && d.exception.description || d.text || '?').split('\n')[0]); }
    });
    for (const d of ['Runtime', 'Page']) await send(`${d}.enable`);
    await send('Page.navigate', { url: `${origin}/` });
    await Promise.race([loadedP, sleep(20000)]);
    await sleep(2500);
    const ev = async (expression) => {
      const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
      if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
      return r.result.value;
    };
    return await scenario({ ev, errors, origin, sleep });
  } finally { await chrome.close(); server.close(); }
}

export const PAGES = [
  { label: 'local (index.html)', root: REPO, authenticated: false },
  { label: 'cloud (cloud/public/index.html), session ouverte', root: join(REPO, 'cloud', 'public'), authenticated: true },
  { label: 'cloud (cloud/public/index.html), écran de connexion', root: join(REPO, 'cloud', 'public'), authenticated: false },
];

if (process.argv[1] && fileURLToPath(import.meta.url) === resolve(process.argv[1])) {
  const chromePath = findChrome();
  if (!chromePath) { console.log('Test de fumée ignoré : aucun Chrome trouvé (définir CHROME_PATH). Ce n\'est PAS un succès.'); process.exit(0); }
  let bad = 0;
  for (const p of PAGES) {
    const r = await smokePage({ ...p, chromePath });
    const visibles = r.tabs.filter((t) => t.visible).length;
    console.log(`${r.ok ? 'OK    ' : 'ÉCHEC '} ${r.label} : ${r.tabs.length} onglets (${visibles} visibles, ${r.tabs.filter((t) => t.active).length} cliqués et actifs)`);
    for (const x of r.problems) console.log(`        - ${x}`);
    if (!r.ok) bad++;
  }
  process.exit(bad ? 1 : 0);
}
