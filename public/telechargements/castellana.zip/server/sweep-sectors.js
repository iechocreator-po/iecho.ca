// Vue sectorielle du dernier balayage S&P 500 (#401, 9/10/2026). Fonction PURE.
// Regroupe par secteur GICS (celui de server/sp500.json, un seul référentiel pour
// tout l'univers) le nombre de titres « prêt » et « à surveiller » du balayage.
// Seuls les titres RETENUS par le filtre figurent dans le résultat d'un balayage :
// les autres n'ont pas de verdict affiché, ils comptent seulement dans le total du secteur.

export const SECTOR_FR = {
  'Information Technology': 'Technologie', 'Health Care': 'Santé', Financials: 'Finance',
  'Consumer Discretionary': 'Conso. discrétionnaire', 'Consumer Staples': 'Conso. de base',
  Industrials: 'Industriels', Energy: 'Énergie', Utilities: 'Services publics',
  'Real Estate': 'Immobilier', Materials: 'Matériaux', 'Communication Services': 'Services de communication',
};

/**
 * @param rows            lignes du screening (ticker, verdict)
 * @param universe        [{ ticker, sector }] — le S&P 500 complet
 */
export function sectorBreakdown(rows, universe) {
  const sectorOf = new Map(universe.map((u) => [u.ticker, u.sector]));
  const out = new Map();
  const slot = (s) => { if (!out.has(s)) out.set(s, { sector: s, label: SECTOR_FR[s] || s, total: 0, pret: [], surveiller: [], autres: 0 }); return out.get(s); };
  for (const u of universe) slot(u.sector).total += 1;
  for (const r of rows || []) {
    const s = sectorOf.get(r.ticker);
    if (!s) continue; // titre hors S&P 500 : ignoré, jamais classé dans un secteur inventé
    const e = slot(s);
    if (r.verdict === 'prêt') e.pret.push(r.ticker);
    else if (r.verdict === 'à surveiller') e.surveiller.push(r.ticker);
    else e.autres += 1; // retenu mais ni prêt ni à surveiller (ex. « trop tard »)
  }
  return [...out.values()]
    .map((e) => ({ ...e, pretCount: e.pret.length, surveillerCount: e.surveiller.length, pretPct: e.total ? (e.pret.length / e.total) * 100 : 0 }))
    .sort((a, b) => b.pretCount - a.pretCount || b.surveillerCount - a.surveillerCount || a.label.localeCompare(b.label, 'fr'));
}
