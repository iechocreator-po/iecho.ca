// Garde HTTP du serveur local (audit parite-routes, 20/10/2026, constat 1).
//
// Avant : `app.use(express.static(ROOT))` servait TOUT le dossier du projet — la base de données du journal
// (data/castellana.sqlite et ses -wal/-shm), settings.json, le code de server/ et de cloud/ (wrangler.jsonc contient
// l'identifiant de la base D1), les fichiers du club dans anticipation/. Seuls les fichiers dont le nom commence par
// un point (.env) étaient protégés. Et aucun contrôle de l'en-tête Host : une page web ouverte dans le navigateur
// pouvait, par « DNS rebinding », lire ces fichiers comme s'ils venaient de la même origine.
//
// Maintenant :
//   1. hostGuard()   — refuse (403) toute requête dont l'en-tête Host n'est pas la machine elle-même ;
//   2. publicFiles() — ne sert que ce dont la page a besoin : une liste explicite de fichiers et de dossiers.
//
// Ajouter ici tout nouveau fichier ou dossier que le NAVIGATEUR doit charger. Le tester : server/http-guard.test.js.
import express from 'express';

// Ce que la page charge réellement (index.html, config.js, favicon.svg, <script src="js/…">, <link href="css/…" | "design-system/…">).
export const PUBLIC_FILES = ['index.html', 'config.js', 'favicon.svg'];
export const PUBLIC_DIRS = ['css', 'js', 'design-system'];

const LOOPBACK = new Set(['127.0.0.1', 'localhost', '::1']);

// « 127.0.0.1:4700 », « localhost:4700 », « [::1]:4700 » -> nom d'hôte sans port, en minuscules.
export function hostnameOf(hostHeader) {
  if (typeof hostHeader !== 'string' || !hostHeader) return null;
  const h = hostHeader.trim().toLowerCase();
  if (h.startsWith('[')) { const end = h.indexOf(']'); return end > 0 ? h.slice(1, end) : null; }
  return h.split(':')[0] || null;
}

/** Middleware : 403 si l'en-tête Host n'est pas l'ordinateur local (ou un hôte explicitement autorisé, ex. settings.host). */
export function hostGuard(extraAllowed = []) {
  const allowed = new Set([...LOOPBACK, ...extraAllowed.filter(Boolean).map((h) => String(h).toLowerCase())]);
  return (req, res, next) => {
    const name = hostnameOf(req.headers.host);
    if (name && allowed.has(name)) return next();
    res.status(403).json({ error: 'Hôte non autorisé : castellana ne répond qu\'à 127.0.0.1 ou localhost.' });
  };
}

/**
 * Middleware : refuse (403) toute écriture (POST, PUT, PATCH, DELETE) venant d'une autre origine (audit routes, 21/10/2026).
 * Le contrôle de l'hôte ne suffit pas : une page web ouverte dans le navigateur peut envoyer un POST sans corps vers
 * http://127.0.0.1:4700 (formulaire ou fetch sans CORS), qui déclenchait la mise à jour, un envoi de courriel ou un balayage.
 * Le navigateur joint toujours `Origin` à ces requêtes; une requête sans `Origin` (curl, webhook, scripts) n'est pas touchée.
 */
export function originGuard(extraAllowed = []) {
  const allowed = new Set([...LOOPBACK, ...extraAllowed.filter(Boolean).map((h) => String(h).toLowerCase())]);
  const ECRITURES = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);
  return (req, res, next) => {
    // Lectures à effet de bord (?force=true, backtest de 219 titres, callback OAuth) déclenchées par un <img> d'un autre site : le navigateur
    // n'envoie pas toujours `Origin` pour une lecture, mais il envoie `Sec-Fetch-Site: cross-site`. Seules les routes /api sont concernées.
    if (req.headers['sec-fetch-site'] === 'cross-site' && req.originalUrl.startsWith('/api/')) {
      res.status(403).json({ error: 'Requête d\'un autre site refusée : castellana ne répond qu\'à sa propre page.' });
      return;
    }
    const origin = req.headers.origin;
    if (!ECRITURES.has(req.method) || origin === undefined) return next();
    let name = null;
    try { name = hostnameOf(new URL(origin).host); } catch { /* origine illisible (ex. « null ») : refusée */ }
    if (name && allowed.has(name)) return next();
    res.status(403).json({ error: 'Origine non autorisée : cette action ne peut venir que de la page castellana locale.' });
  };
}

/** Routeur : sert uniquement PUBLIC_FILES et PUBLIC_DIRS sous `root` ; tout le reste tombe dans le 404 habituel. */
export function publicFiles(root) {
  const router = express.Router();
  router.get('/', (req, res) => res.sendFile('index.html', { root }));
  for (const f of PUBLIC_FILES) router.get(`/${f}`, (req, res) => res.sendFile(f, { root }));
  for (const d of PUBLIC_DIRS) {
    router.use(`/${d}`, express.static(`${root.replace(/\/$/, '')}/${d}`, { index: false, dotfiles: 'ignore', redirect: false }));
  }
  return router;
}
