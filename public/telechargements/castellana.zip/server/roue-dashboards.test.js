// Tableaux de bord de la Roue (16/10/2026, #443 semaine, #444 annuel) — calculs purs.
import test from 'node:test';
import assert from 'node:assert/strict';
import {
  optStrikeDistance, optRouePositions, optLegOutcomes, optPremiumBreakdown, optValueSeries, optRoueActivity, optWeekLegs,
} from './options-analytics.js';

const near = (a, b, eps = 1e-9) => assert.ok(Math.abs(a - b) < eps, `${a} ≠ ${b}`);

// Cycle PCG : put assigné à 15 (prime 0,40), puis call 14,50 ouvert (prime 0,10). 1 contrat.
const cycle = { id: 1, ticker: 'PCG', compte: 'margin', statut: 'actif' };
const put = { id: 10, cycle_id: 1, ticker: 'PCG', type: 'put', strike: 15, contrats: 1, prime_recue: 0.4, commission_ouverture: 1, statut: 'assigne', date_ouverture: '2026-08-20', echeance: '2026-08-26', date_cloture: '2026-08-26' };
const call = { id: 11, cycle_id: 1, ticker: 'PCG', type: 'call', strike: 14.5, contrats: 1, prime_recue: 0.1, commission_ouverture: 1, statut: 'ouvert', date_ouverture: '2026-10-09', echeance: '2026-10-16' };
const stock = { id: 5, option_cycle_id: 1, ticker: 'PCG', taille_position: 100, prix_entree: 15, date_entree: '2026-08-26', date_sortie: null };

test('distance au strike : positive hors la monnaie, négative dedans, null sans cours', () => {
  near(optStrikeDistance('call', 100, 110), 0.1);
  near(optStrikeDistance('call', 120, 110), -10 / 120);
  near(optStrikeDistance('put', 100, 90), 0.1);
  assert.equal(optStrikeDistance('put', null, 90), null);
});

test('positions : coût de base net des primes, latent au cours contre ce coût (pas contre le strike)', () => {
  const p = optRouePositions({ cycles: [cycle], legs: [put, call], stockTrades: [stock], prices: { PCG: 13.33 } });
  assert.equal(p.rows.length, 1);
  const r = p.rows[0];
  // primes nettes = 40 + 10 = 50 ; commissions 2 → crédit net 48 ; coût net = (1500 − 48) / 100
  near(r.coutDeBaseNet, 14.52);
  near(r.latentNet, (13.33 - 14.52) * 100);
  near(r.latentBrut, (13.33 - 15) * 100);
  assert.equal(r.verif, 'sous_cout');                 // call 14,50 < 14,52 : une assignation verrouille une perte
  near(p.latentNet, r.latentNet);
  near(p.latentNegatif, r.latentNet);
});

test('positions : cours inconnu → latent null (jamais 0), call plafonné reconnu', () => {
  assert.equal(optRouePositions({ cycles: [cycle], legs: [put, call], stockTrades: [stock] }).latentNet, null);
  const haut = { ...call, strike: 16 };
  assert.equal(optRouePositions({ cycles: [cycle], legs: [put, haut], stockTrades: [stock], prices: { PCG: 17 } }).rows[0].verif, 'plafonne');
  assert.equal(optRouePositions({ cycles: [cycle], legs: [put], stockTrades: [stock], prices: { PCG: 17 } }).rows[0].verif, 'sans_call');
});

test('dénouement : expirée, rachetée (roulée comprise), assignée, par mois de clôture', () => {
  const legs = [
    put,
    { ...put, id: 2, statut: 'expire', date_cloture: '2026-09-05' },
    { ...put, id: 3, statut: 'roule', date_cloture: '2026-09-12' },
    { ...put, id: 4, statut: 'rachete', date_cloture: '2025-09-12' },   // autre année : ignorée
    call,
  ];
  const o = optLegOutcomes(legs, 2026);
  assert.deepEqual([o.expire, o.rachete, o.assigne, o.closes, o.ouvertes], [1, 1, 1, 3, 1]);
  assert.deepEqual(o.parMois[8], { expire: 1, rachete: 1, assigne: 0 });
  assert.deepEqual(o.parMois[7], { expire: 0, rachete: 0, assigne: 1 });
});

test('primes : options closes seulement, frais déduits, par mois, titre et secteur', () => {
  const b = optPremiumBreakdown([put, call, { ...put, id: 2, ticker: 'NFLX', statut: 'expire', date_cloture: '2026-09-05' }], 2026, { sectors: { PCG: 'Utilities' } });
  near(b.total, 39 + 39);
  near(b.parMois[7], 39);
  assert.deepEqual(b.parSecteur.map((r) => r.cle).sort(), ['Non renseigné', 'Utilities']);
});

test('deux traits : un dépôt fait monter les deux, l\'écart = gains des actions', () => {
  const flows = [
    { compte: 'margin', type: 'depart', date: '2026-08-02', montant: 10000 },
    { compte: 'margin', type: 'depot', date: '2026-09-08', montant: 5000 },
  ];
  const vendue = { ...stock, date_sortie: '2026-09-25', prix_sortie: 16 };
  const s = optValueSeries({ legs: [put], stockTrades: [vendue], cashFlows: flows });
  const last = s[s.length - 1];
  near(last.apports, 15000);
  near(last.apportsPlusPrimes, 15039);
  near(last.valeurRealisee, 15039 + 100);                                   // action revendue +1 $ × 100
  const semDepot = s.find((w) => w.apport === 5000);
  assert.ok(semDepot, 'la semaine du dépôt est marquée');
  assert.deepEqual(optValueSeries({ legs: [put], cashFlows: [] }), []);     // sans capital de départ : rien
});

test('activité et semaine : ouverture dans l\'année ; échéance ou ouverture dans la semaine', () => {
  const a = optRoueActivity([put, call], 2026);
  assert.deepEqual([a.options, a.puts, a.calls, a.titres], [2, 1, 1, 1]);
  near(a.dureeMoyenne, 6);
  assert.deepEqual(optWeekLegs([put, call], '2026-10-11').map((l) => l.id), [11]);   // échéance 16-10
  assert.deepEqual(optWeekLegs([put, call], '2026-10-04').map((l) => l.id), [11]);   // ouverte le 9-10
  assert.deepEqual(optWeekLegs([put, call], '2026-09-27'), []);
});
