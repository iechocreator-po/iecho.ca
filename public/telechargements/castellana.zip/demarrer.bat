@echo off
REM demarrer.bat — lanceur self-install castellana (Windows, 6/9/2026)
REM
REM Calque sur devops-dashboard\demarrer.bat (verification Node, redirection
REM vers nodejs.org) etendu avec Python (sidecar optionnel, meme conventions
REM que scripts\run-sidecar.mjs : dossier .venv-mcp, Scripts\...exe).
REM NON TESTE sur une vraie machine Windows — verifie par lecture de code et
REM coherence avec run-sidecar.mjs uniquement (meme limite deja documentee
REM pour ce dernier avant sa correction, voir CLAUDE.md).

setlocal enabledelayedexpansion
cd /d "%~dp0"

echo === castellana - installation et demarrage ===
echo.

REM --- 1. Node.js ---------------------------------------------------------
where node >nul 2>nul
if %errorlevel% neq 0 (
  echo Node.js est requis mais introuvable sur cette machine.
  echo Ouverture de la page de telechargement officielle...
  start https://nodejs.org/
  echo.
  echo Installe Node.js puis relance ce fichier.
  pause
  exit /b 1
)
echo Node.js detecte.

REM --- 2. Python (optionnel - sidecar tradingview-mcp) --------------------
set PYTHON_OK=0
set PYTHON_CMD=
where python >nul 2>nul
if %errorlevel% equ 0 (
  set PYTHON_OK=1
  set PYTHON_CMD=python
) else (
  where python3 >nul 2>nul
  if !errorlevel! equ 0 (
    set PYTHON_OK=1
    set PYTHON_CMD=python3
  )
)
if "%PYTHON_OK%"=="1" (
  echo Python detecte.
) else (
  echo Python introuvable - le sidecar ^(VIX/RSI/Golden Cross en direct^)
  echo ne sera pas installe. castellana fonctionnera quand meme, en mode
  echo degrade pour ces indicateurs.
  echo Ouverture de la page de telechargement officielle ^(optionnel^)...
  start https://www.python.org/downloads/windows/
)
echo.

REM --- 3. Dependances Node -------------------------------------------------
if exist "node_modules" (
  echo Dependances Node deja installees.
) else (
  echo Installation des dependances Node ^(premiere fois^)...
  call npm install
  if !errorlevel! neq 0 (
    echo.
    echo npm install a echoue. Voir SETUP.md ^(section Depannage^) -
    echo causes frequentes : better-sqlite3 necessite des outils de
    echo compilation ^(Visual Studio Build Tools^) sur certaines machines.
    pause
    exit /b 1
  )
)
echo.

REM --- 4. Sidecar Python (si Python disponible et pas deja installe) ------
set SIDECAR_READY=0
if "%PYTHON_OK%"=="1" (
  if exist ".venv-mcp\Scripts\tradingview-mcp.exe" (
    echo Sidecar Python deja installe.
    set SIDECAR_READY=1
  ) else (
    echo Installation du sidecar Python ^(tradingview-mcp^)...
    %PYTHON_CMD% -m venv .venv-mcp
    call .venv-mcp\Scripts\pip install --quiet tradingview-mcp-server
    if exist ".venv-mcp\Scripts\tradingview-mcp.exe" (
      echo Sidecar Python installe.
      set SIDECAR_READY=1
    ) else (
      echo L'installation du sidecar a echoue - castellana demarrera quand
      echo meme, sans VIX/RSI/Golden Cross en direct.
    )
  )
)
echo.

REM --- 5. Demarrage ---------------------------------------------------------
echo Demarrage du serveur castellana...
start "castellana - serveur" cmd /k "npm start"

if "%SIDECAR_READY%"=="1" (
  echo Demarrage du sidecar tradingview-mcp...
  start "castellana - sidecar" cmd /k "npm run sidecar"
)

timeout /t 2 /nobreak >nul
start "" http://127.0.0.1:4700

echo.
echo === castellana tourne - http://127.0.0.1:4700 ===
echo Ferme les fenetres "castellana - ..." pour tout arreter.
echo.
pause
endlocal
