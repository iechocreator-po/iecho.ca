// Alertes de POSITIONS (feature bilbao #379, 30/9/2026) — LOGIQUE PURE, testée dans
// server/position-alerts.test.js. Trois situations, chacune déclenchée sur TRANSITION
// (jamais tant que l'état dure, comme les alertes de listes) :
//   - echeance : une jambe d'option vendue arrive à ≤ 7 jours de l'échéance ;
//   - profit   : la part de prime déjà captée atteint le seuil de prise de profit ;
//   - stop     : le cours d'une action du Journal touche ou passe sous son stop initial.
//
// La PREMIÈRE observation d'une position n'alerte jamais (état de référence) ; une
// observation manquante (cours, chaîne indisponible) ne modifie jamais l'état mémorisé.

export const DTE_SEUIL_JOURS = 7;

const fmt = (v, d = 2) => (v == null ? '—' : Number(v).toFixed(d));

export const POSITION_KINDS = {
  echeance: {
    label: 'Échéance proche',
    stateOf: (o) => (o.dte == null ? null : (o.dte >= 0 && o.dte <= DTE_SEUIL_JOURS ? 'in' : 'out')),
    fires: (prev, cur) => prev === 'out' && cur === 'in',
    message: (o) => `${o.ticker} ${o.type} ${fmt(o.strike)} : échéance dans ${o.dte} jour${o.dte > 1 ? 's' : ''} (${o.echeance}) — laisser aller, racheter ou rouler ?`,
  },
  profit: {
    label: 'Seuil de prise de profit',
    stateOf: (o) => (o.capturePct == null ? null : (o.capturePct >= o.seuilPct ? 'in' : 'out')),
    fires: (prev, cur) => prev === 'out' && cur === 'in',
    message: (o) => `${o.ticker} ${o.type} ${fmt(o.strike)} (${o.echeance}) : ${fmt(o.capturePct, 0)} % de la prime déjà captée (rachat estimé ${fmt(o.rachat)} $ contre ${fmt(o.primeRecue)} $ encaissés) — seuil ${o.seuilPct} %.`,
  },
  stop: {
    label: 'Stop touché',
    stateOf: (o) => (o.price == null || !(o.stop > 0) ? null : (o.price <= o.stop ? 'hit' : 'ok')),
    fires: (prev, cur) => prev === 'ok' && cur === 'hit',
    message: (o) => `${o.ticker} : le cours (${fmt(o.price)} $) a touché le stop initial (${fmt(o.stop)} $) de la position du Journal actions.`,
  },
};

/**
 * Évalue UNE observation.
 * @returns { state, notify, message }  — state null = rien à mémoriser (donnée manquante)
 */
export function evaluatePositionObservation(kind, obs, prevState) {
  const def = POSITION_KINDS[kind];
  const cur = def.stateOf(obs);
  if (cur == null) return { state: null, notify: false, message: null };
  const notify = prevState != null && def.fires(prevState, cur);
  return { state: cur, notify, message: notify ? def.message(obs) : null };
}

// Jours restants avant une échéance (AAAA-MM-JJ), à minuit UTC, arrondis vers le haut.
export function daysUntil(echeance, now = new Date()) {
  const ms = Date.parse(`${echeance}T00:00:00Z`) - now.getTime();
  return Number.isFinite(ms) ? Math.ceil(ms / 86400000) : null;
}

// Part de prime déjà captée (%), à partir du coût de rachat estimé. null si la
// prime reçue est nulle ou si le rachat est inconnu — jamais un 100 % inventé.
export function capturePercent(primeRecue, rachat) {
  if (!(primeRecue > 0) || rachat == null) return null;
  return (1 - rachat / primeRecue) * 100;
}
