#!/usr/bin/env node
// `npm run doctor` — préflight d'installation (7/9/2026).
//
// Pourquoi : jusqu'ici, quand castellana ne démarrait pas chez quelqu'un
// d'autre que JP, il n'existait aucun moyen de savoir POURQUOI sans lire le
// code. Le collègue onboardé le 30/8/2026 s'est heurté à ça, et l'audit du
// 7/9/2026 a montré qu'un testeur non technique ne peut pas distinguer « le
// serveur est mort » de « l'application est cassée ».
//
// Ce script répond à une seule question : « qu'est-ce qui manque, et que
// dois-je faire ? ». Chaque ligne en échec porte son remède — jamais un
// diagnostic sans suite.
//
// Zéro dépendance (modules natifs uniquement) : il doit pouvoir tourner
// AVANT `npm install`, précisément pour dire que celui-ci n'a pas été fait.

import { existsSync, readFileSync, writeFileSync, unlinkSync, mkdirSync } from 'node:fs';
import { createServer } from 'node:net';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const NODE_MIN_MAJOR = 20;

const results = [];
const add = (ok, label, detail, remede = null) => results.push({ ok, label, detail, remede });

// --- 1. Version de Node -------------------------------------------------
const major = Number(process.versions.node.split('.')[0]);
add(
  major >= NODE_MIN_MAJOR,
  'Node.js',
  `version ${process.versions.node}`,
  `castellana requiert Node ${NODE_MIN_MAJOR} ou plus récent. Télécharger la version LTS sur https://nodejs.org/`,
);

// --- 2. Dépendances installées -----------------------------------------
const nodeModules = path.join(ROOT, 'node_modules');
const depsOk = existsSync(nodeModules) && existsSync(path.join(nodeModules, 'express')) && existsSync(path.join(nodeModules, 'yahoo-finance2'));
add(depsOk, 'Dépendances npm', depsOk ? 'présentes' : 'absentes ou incomplètes', 'Lancer `npm install` à la racine du dossier castellana.');

// --- 3. better-sqlite3 : le seul module natif ---------------------------
// C'est le mode d'échec d'installation le plus probable sous Windows :
// le paquet télécharge d'abord un binaire précompilé (prebuild-install) et
// ne compile qu'en dernier recours, ce qui exige alors des outils de
// compilation. On teste le CHARGEMENT réel plutôt que la présence du dossier.
if (depsOk) {
  try {
    const { default: Database } = await import('better-sqlite3');
    const probe = new Database(':memory:');
    probe.exec('CREATE TABLE t (a)');
    probe.close();
    add(true, 'Base de données (better-sqlite3)', 'module natif chargé et fonctionnel');
  } catch (err) {
    add(false, 'Base de données (better-sqlite3)', err.message,
      'Le seul module à compiler. Sous Windows : installer « Visual Studio Build Tools » (charge de travail « Développement Desktop en C++ »), puis relancer `npm install`. Voir SETUP.md.');
  }
} else {
  add(false, 'Base de données (better-sqlite3)', 'non testé — dépendances absentes', 'Lancer `npm install` d\'abord.');
}

// --- 4. Dossier de données accessible en écriture -----------------------
try {
  const dataDir = path.join(ROOT, 'data');
  mkdirSync(dataDir, { recursive: true });
  const probe = path.join(dataDir, '.doctor-probe');
  writeFileSync(probe, 'ok');
  unlinkSync(probe);
  add(true, 'Dossier data/ (journal de trades)', 'accessible en écriture');
} catch (err) {
  add(false, 'Dossier data/ (journal de trades)', err.message,
    'castellana doit pouvoir écrire dans son propre dossier. Déplacer le dossier hors d\'un emplacement protégé (ex. « Program Files »).');
}

// --- 5. Port libre ------------------------------------------------------
const settings = JSON.parse(readFileSync(path.join(ROOT, 'settings.json'), 'utf8'));
const portFree = await new Promise((resolve) => {
  const srv = createServer();
  srv.once('error', () => resolve(false));
  srv.once('listening', () => srv.close(() => resolve(true)));
  srv.listen(settings.port, settings.host);
});
add(true, `Port ${settings.port}`, portFree ? 'libre' : 'déjà utilisé — repli automatique sur 4711-4715 au démarrage');

// --- 6. Yahoo Finance joignable ----------------------------------------
// La seule source de données de l'app depuis le 7/9/2026.
if (depsOk) {
  try {
    const { default: YahooFinance } = await import('yahoo-finance2');
    const yf = new YahooFinance({ suppressNotices: ['yahooSurvey'] });
    const q = await yf.quote('SPY');
    add(!!q?.regularMarketPrice, 'Yahoo Finance (données de marché)', `SPY à ${q?.regularMarketPrice} ${q?.currency ?? ''}`,
      'Vérifier la connexion internet, ou un pare-feu/VPN d\'entreprise qui bloquerait query1.finance.yahoo.com.');
  } catch (err) {
    add(false, 'Yahoo Finance (données de marché)', err.message,
      'Vérifier la connexion internet, ou un pare-feu/VPN d\'entreprise qui bloquerait query1.finance.yahoo.com.');
  }
} else {
  add(false, 'Yahoo Finance (données de marché)', 'non testé — dépendances absentes', 'Lancer `npm install` d\'abord.');
}

// --- 7. Sidecar Python : OPTIONNEL, jamais un échec ---------------------
// Volontairement hors du décompte des problèmes : depuis le 7/9/2026 tous
// les indicateurs sont calculés maison, et signaler son absence comme une
// panne enverrait un testeur installer 170 Mo de Python pour rien.
const sidecarEnabled = settings.tradingviewMcp?.enabled === true;
const venvExists = existsSync(path.join(ROOT, '.venv-mcp'));
console.log('');
console.log('  castellana — vérification de l\'installation');
console.log('  ' + '─'.repeat(58));
for (const r of results) {
  console.log(`  ${r.ok ? '✅' : '❌'} ${r.label.padEnd(34)} ${r.detail}`);
  if (!r.ok && r.remede) console.log(`     → ${r.remede}`);
}
console.log(`  ⚪ ${'Sidecar Python (optionnel)'.padEnd(34)} ${sidecarEnabled ? (venvExists ? 'activé et installé' : 'ACTIVÉ dans settings.json mais non installé') : 'désactivé — non requis'}`);
if (!sidecarEnabled) {
  console.log('     → Tous les indicateurs (RSI, SMA, Golden Cross, ATR, OBV, VIX) sont');
  console.log('       calculés depuis Yahoo Finance. Python n\'est pas nécessaire.');
}
console.log('  ' + '─'.repeat(58));

const failures = results.filter((r) => !r.ok);
if (failures.length === 0) {
  console.log('  Tout est en ordre. Lancer `npm start`, puis ouvrir l\'adresse affichée.');
  console.log('');
  process.exit(0);
}
console.log(`  ${failures.length} point(s) à corriger avant de lancer castellana (voir les → ci-dessus).`);
console.log('  Détails et dépannage complet : SETUP.md');
console.log('');
process.exit(1);
