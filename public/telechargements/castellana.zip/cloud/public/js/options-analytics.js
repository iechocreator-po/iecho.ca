// js/options-analytics.js — formules pures partagées par les onglets « Options A »
// et « Journal A » (vente de puts pour primes continues, feature bilbao à venir,
// 22/9/2026). SOURCE UNIQUE de ces calculs, même discipline que js/labo-schema.js/
// js/sizing.js — ce projet documente déjà SCORE_BANDS/SCREEN_FILTERS comme des
// duplications à éviter, pas à reproduire.
//
// Trois consommateurs, une seule définition :
//   - le navigateur (script classique, chargé avant js/options-tab-a.js et
//     js/journal-a-tab.js) ;
//   - le serveur local (server/options-analytics.js l'évalue, même patron que
//     server/labo-params.js pour js/labo-schema.js) ;
//   - le Worker cloud, via une copie ESM GÉNÉRÉE (cloud/src/lib/options-analytics.js,
//     `npm run sync:cloud`) — un test de parité vérifie qu'elle ne dérive pas.
//
// Règle d'honnêteté constante de ce projet : une entrée manquante ou non
// exploitable renvoie `null`, jamais un 0 ou une valeur inventée.
//
// Ce fichier ne doit contenir que des déclarations de premier niveau (const /
// function) : il est évalué tel quel par le serveur et recopié en ESM.
//
// ⚠️ Dépendance d'ordre de chargement : `optionDelta` utilise `laboNormCdf`,
// défini dans js/strategies-labo.js — celui-ci doit être chargé AVANT ce
// fichier (voir <script> dans index.html). Le serveur et la copie cloud
// évaluent la même tranche de strategies-labo.js avant celui-ci (voir
// server/options-analytics.js et scripts/sync-cloud-copies.mjs) — même
// patron que server/options-tab.test.js pour les tests.

// Sous cette IV, Yahoo renvoie du bruit (contrats sans marché) : pas de delta.
const OPT_MIN_IV = 0.01;

// Pure : delta Black-Scholes (call : N(d1) ; put : N(d1) - 1) à partir de l'IV du
// contrat. null si une entrée manque ou n'est pas fiable — jamais un delta inventé.
function optionDelta(type, S, K, dte, r, iv) {
  if (!(S > 0) || !(K > 0) || !(dte >= 1) || !(iv >= OPT_MIN_IV)) return null;
  const T = dte / 365;
  const d1 = (Math.log(S / K) + (r + (iv * iv) / 2) * T) / (iv * Math.sqrt(T));
  const call = laboNormCdf(d1);
  return type === 'call' ? call : call - 1;
}

// Pure : plage de strikes dont |delta| est dans [dMin, dMax] ; null si aucun contrat.
function optionMarketZone(contracts, dMin, dMax) {
  const ks = contracts.filter((c) => c.delta != null && Math.abs(c.delta) >= dMin && Math.abs(c.delta) <= dMax).map((c) => c.strike);
  return ks.length ? { basse: Math.min(...ks), haute: Math.max(...ks), n: ks.length } : null;
}

// Rendement annualisé d'une prime vendue, en % : (prime/strike) × (365/DTE) × 100.
// Le nombre de contrats/actions par contrat s'annule dans ce ratio — inutile ici.
function optAnnualizedYield(premium, strike, dte) {
  if (!(premium > 0) || !(strike > 0) || !(dte >= 1)) return null;
  return (premium / strike) * (365 / dte) * 100;
}

// Capital requis pour garantir un put vendu (cash-secured) ou couvrir un call
// (covered) : strike × actions par contrat × nombre de contrats.
function optCapitalRequired(strike, contractSize, contracts) {
  if (!(strike > 0) || !(contractSize > 0) || !(contracts > 0)) return null;
  return strike * contractSize * contracts;
}

// Traduction du delta estimé en repère de probabilité d'assignation — une
// APPROXIMATION usuelle (|delta| ≈ probabilité ITM à l'échéance), jamais une
// vraie probabilité statistique. label grossier pour la lecture rapide.
function optAssignmentProbabilityLabel(delta) {
  if (delta == null || !Number.isFinite(delta)) return null;
  const pct = Math.round(Math.abs(delta) * 100);
  let label;
  if (pct < 15) label = 'faible';
  else if (pct < 35) label = 'modérée';
  else label = 'élevée';
  return { pct, label };
}

// Crédit (positif) ou débit (négatif) net d'un roulement : racheter la
// position actuelle (closePremium, coût) et vendre la nouvelle
// (openPremium, encaissé). null si une des deux primes manque.
function optRollNetCredit(openPremium, closePremium, contractSize, contracts) {
  if (openPremium == null || closePremium == null) return null;
  if (!(contractSize > 0) || !(contracts > 0)) return null;
  return (openPremium - closePremium) * contractSize * contracts;
}

// ---- Détecteur de « meilleurs deals » (22/9/2026) — achat vs vente -------
//
// Trois sous-scores TRANSPARENTS (-1/0/+1 chacun, jamais un score opaque —
// même discipline que scoreRow() du screener actions, server/scoring.js) :
// liquidité, valorisation de l'IV vs volatilité historique, et rendement
// (vente) ou levier (achat). Les seuils sont des repères pragmatiques
// documentés ici, PAS une calibration statistique — même statut que les
// bandes RSI/VIX de config.js. Chaque sous-score reste affiché
// séparément ; le total n'est qu'un résumé de lecture rapide, jamais la
// seule information montrée.
//
// Acheteur et vendeur veulent l'INVERSE sur la valorisation de l'IV : le
// vendeur cherche une IV riche par rapport à l'historique (edgePts > 0),
// l'acheteur cherche une IV bon marché (edgePts < 0) — ne jamais partager
// un seul jeu de bandes entre les deux modes.

// null si le contrat n'a aucun marché exploitable (pas d'ask) — jamais noté
// sur des données inventées. bid = 0/absent est toléré (contrat encore
// négociable à l'achat au ask, juste sans acheteur affiché) mais pénalise
// le score (spread non mesurable).
function optDealLiquidity(bid, ask, openInterest, volume) {
  if (!(ask > 0)) return null;
  let score = 0;
  const spreadPct = bid > 0 ? ((ask - bid) / ((bid + ask) / 2)) * 100 : null;
  score += spreadPct == null ? -1 : spreadPct < 10 ? 1 : spreadPct < 25 ? 0 : -1;
  score += openInterest == null ? 0 : openInterest >= 500 ? 1 : openInterest >= 100 ? 0 : -1;
  score += volume == null ? 0 : volume >= 100 ? 1 : volume >= 10 ? 0 : -1;
  return { score, spreadPct };
}

// edgePts : écart IV − volatilité historique, en points de %. Positif =
// IV plus riche que l'historique récent du titre.
//
// IV Rank (30/9/2026, #377) : quand un rang RÉEL (0-100, calculé sur l'historique
// d'IV accumulé par le Radar) est fourni, il REMPLACE le proxy « IV vs volatilité
// historique » — le vendeur veut un rang élevé (prime riche vs son propre passé),
// l'acheteur un rang bas. Sans rang (historique insuffisant, ou version cloud qui
// n'a pas cet historique), on retombe sur l'ancien proxy : `basis` dit lequel a servi.
function optDealValuation(mode, iv, historicalVolatility, ivRank = null) {
  if (iv == null) return null;
  const edgePts = historicalVolatility != null ? (iv - historicalVolatility) * 100 : null;
  if (typeof ivRank === 'number' && Number.isFinite(ivRank)) {
    const score = mode === 'vente'
      ? (ivRank >= 70 ? 1 : ivRank > 30 ? 0 : -1)
      : (ivRank <= 30 ? 1 : ivRank < 70 ? 0 : -1);
    return { score, edgePts, ivRank, basis: 'ivrank' };
  }
  if (edgePts == null) return null;
  const score = mode === 'vente'
    ? (edgePts > 5 ? 1 : edgePts > -5 ? 0 : -1)
    : (edgePts < -5 ? 1 : edgePts < 5 ? 0 : -1);
  return { score, edgePts, ivRank: null, basis: 'hv' };
}

// --- Bilan de la Roue par cycle (30/9/2026, #378) ----------------------
// Dernier cours de clôture À LA DATE donnée ou avant (jour férié, week-end).
// bars : [{ date (Date ou 'AAAA-MM-JJ'), close }] ; renvoie null s'il n'y a rien avant.
function optCloseOnOrBefore(bars, dateStr) {
  const t = Date.parse(dateStr);
  if (!Number.isFinite(t) || !bars || !bars.length) return null;
  let best = null;
  for (const b of bars) {
    const bt = b.date instanceof Date ? b.date.getTime() : Date.parse(b.date);
    if (Number.isFinite(bt) && bt <= t + 86399999 && b.close != null) best = b.close; // barres triées par date
  }
  return best;
}

// Bilan d'UN cycle : primes nettes, action (réalisé/latent), capital immobilisé,
// rendement, et comparaison à la simple DÉTENTION du titre sur la même période.
//   cycle       : { statut, legs:[{type,strike,contrats,prime_recue,prime_cloture,statut,date_ouverture,date_cloture}] }
//   stockTrades : lignes du Journal actions liées au cycle (assignations de put)
//   priceStart  : cours au début du cycle ; priceEnd : cours à la fin (ou dernier cours si actif)
// Honnêteté : une donnée manquante reste NULL (jamais 0) ; le latent d'une action encore
// détenue n'est calculé que si priceEnd est connu, et `latentConnu` le dit. pnl, rendement et
// vsHold restent SANS dividendes ni frais — la détention et le cycle sont comparés sur la même
// base. Les frais et dividendes (Journal de la Roue, #433) sont dans des champs à part :
// commissions, dividendes, pnlNet, rendementNet, coutDeBaseNet (= « coût moyen par action »
// du Sheets du club : coût d'acquisition − crédits nets, par action).
//   cashFlows   : flux du cycle ; seuls les `dividende` comptent ici
function optCycleBilan(cycle, { contractSize = 100, stockTrades = [], priceStart = null, priceEnd = null, today = null, cashFlows = [] } = {}) {
  const legs = cycle && cycle.legs ? cycle.legs : [];
  if (!legs.length) return null;
  const shares = (l) => l.contrats * contractSize;
  const sum = (a) => a.reduce((x, y) => x + y, 0);
  const primesEncaissees = sum(legs.map((l) => l.prime_recue * shares(l)));
  // Le coût de rachat ne concerne que les jambes rachetées ou roulées ; une assignation ou
  // une expiration ne coûte aucune prime supplémentaire.
  const rachats = sum(legs.filter((l) => l.statut === 'roule' || l.statut === 'rachete').map((l) => (l.prime_cloture || 0) * shares(l)));
  const primesNettes = primesEncaissees - rachats;

  const closedStock = stockTrades.filter((t) => t.date_sortie && t.prix_sortie != null);
  const openStock = stockTrades.filter((t) => !t.date_sortie);
  const realiseAction = sum(closedStock.map((t) => (t.prix_sortie - t.prix_entree) * t.taille_position));
  const openQty = sum(openStock.map((t) => t.taille_position));
  const openCost = sum(openStock.map((t) => t.prix_entree * t.taille_position));
  const latentConnu = openStock.length === 0 || priceEnd != null;
  const latentAction = openStock.length === 0 ? 0 : (priceEnd != null ? openQty * priceEnd - openCost : null);

  const capitalPut = Math.max(0, ...legs.filter((l) => l.type === 'put').map((l) => l.strike * shares(l)));
  const capitalAction = sum(stockTrades.map((t) => t.prix_entree * t.taille_position));
  const capital = Math.max(capitalPut, capitalAction);

  const debutMs = Math.min(...legs.map((l) => Date.parse(l.date_ouverture)));
  const finCandidates = [...legs.map((l) => l.date_cloture), ...closedStock.map((t) => t.date_sortie)].filter(Boolean).map((d) => Date.parse(d));
  const finMs = cycle.statut === 'clos' && finCandidates.length ? Math.max(...finCandidates) : Date.parse(today || new Date().toISOString().slice(0, 10));
  const jours = Math.max(1, Math.round((finMs - debutMs) / 86400000));

  const pnl = primesNettes + realiseAction + (latentAction ?? 0);
  const rendement = capital > 0 ? pnl / capital : null;
  // Annualiser un rendement de quelques jours donnerait un chiffre absurde : sous 30 jours, non affiché.
  const rendementAnnualise = rendement != null && jours >= 30 ? rendement * (365 / jours) : null;
  const coutDeBase = openQty > 0 ? (openCost - primesNettes) / openQty : null;
  const holdReturn = priceStart > 0 && priceEnd != null ? priceEnd / priceStart - 1 : null;
  const commissions = sum(legs.map(optLegCommissions)) + sum(stockTrades.map(optStockCommissions));
  const dividendes = sum((cashFlows || []).filter((f) => f.type === 'dividende').map((f) => optNum0(f.montant)));
  const pnlNet = pnl - commissions + dividendes;
  const rendementNet = capital > 0 ? pnlNet / capital : null;
  const coutDeBaseNet = openQty > 0 ? (openCost - (primesNettes - commissions + dividendes)) / openQty : null;
  return {
    primesEncaissees, rachats, primesNettes, realiseAction, latentAction, latentConnu,
    capital, jours, pnl, rendement, rendementAnnualise, coutDeBase,
    commissions, dividendes, pnlNet, rendementNet, coutDeBaseNet,
    holdReturn, vsHold: rendement != null && holdReturn != null ? rendement - holdReturn : null,
    debut: new Date(debutMs).toISOString().slice(0, 10), fin: new Date(finMs).toISOString().slice(0, 10),
  };
}

// --- IV Rank réel (30/9/2026, #377) ------------------------------------
// Nombre minimal de JOURS d'historique avant d'afficher un rang : en dessous,
// un rang serait une fausse précision — on renvoie null (« historique insuffisant »).
const OPT_IVRANK_MIN_OBS = 20;

// IV « à la monnaie » d'une chaîne : médiane de l'IV des contrats dont |delta|
// est entre 0,4 et 0,6 (calls et puts). Même définition pour l'historique et
// pour la valeur courante — sans quoi le rang comparerait des choses différentes.
function optAtmIv(contracts) {
  const ivs = (contracts || [])
    .filter((c) => c && Number.isFinite(c.iv) && c.iv > 0 && Number.isFinite(c.delta) && Math.abs(c.delta) >= 0.4 && Math.abs(c.delta) <= 0.6)
    .map((c) => c.iv)
    .sort((a, b) => a - b);
  if (ivs.length < 2) return null;
  const m = ivs.length >> 1;
  return ivs.length % 2 ? ivs[m] : (ivs[m - 1] + ivs[m]) / 2;
}

// history : IV ATM d'un jour par observation ; currentIv : valeur du jour.
// Rang = position entre le plus bas et le plus haut de l'historique (0-100) ;
// percentile = part des jours passés où l'IV était <= à la valeur courante.
function optIvRank(history, currentIv, minObs = OPT_IVRANK_MIN_OBS) {
  const h = (history || []).filter((v) => Number.isFinite(v) && v > 0);
  if (!Number.isFinite(currentIv) || currentIv <= 0 || h.length < minObs) return null;
  const low = Math.min(...h);
  const high = Math.max(...h);
  if (!(high > low)) return null;
  const rank = Math.min(100, Math.max(0, ((currentIv - low) / (high - low)) * 100));
  const percentile = (h.filter((v) => v <= currentIv).length / h.length) * 100;
  return { rank, percentile, n: h.length, low, high, current: currentIv };
}

// Valeur intrinsèque d'un contrat : call = max(0, S-K), put = max(0, K-S).
// null si le prix du sous-jacent ou le strike manque.
function optIntrinsicValue(type, S, K) {
  if (!(S > 0) || !(K > 0)) return null;
  return type === 'call' ? Math.max(0, S - K) : Math.max(0, K - S);
}

// Valeur temps (extrinsèque) d'une prime : premium − intrinsèque, jamais
// négative. C'est CETTE valeur, pas la prime brute, qui représente ce
// qu'un vendeur encaisse réellement au titre du temps qui passe — pour un
// contrat profondément dans la monnaie, l'essentiel du bid est de la
// valeur intrinsèque (le vendeur ne fait que « rendre » une partie du prix
// de l'action), pas un vrai rendement. Sans cette distinction, un call
// ITM profond ressort avec un rendement annualisé à quatre chiffres —
// défaut réel trouvé en testant sur AMD (22/9/2026).
function optExtrinsicValue(type, S, K, premium) {
  const intrinsic = optIntrinsicValue(type, S, K);
  if (intrinsic == null || premium == null) return null;
  return Math.max(0, premium - intrinsic);
}

// Règle de prime minimale (Roue) : on exige `pct` % du strike par tranche de
// `periodDays` jours, proportionnellement à l'échéance (0,5 % / 5 j → 1 % à
// 10 j). La prime comparée est la valeur TEMPS du bid (bid − intrinsèque) :
// pour un contrat hors la monnaie c'est le bid ; pour un ITM, la part
// intrinsèque n'est pas une vraie prime. Renvoie null si un intrant manque
// (jamais un « échoue » inventé) ; ratio = prime / seuil (≥ 1 → respecte).
function optPremiumRule(type, S, K, bid, dte, pct, periodDays) {
  if (!(K > 0) || !(dte >= 1) || !(pct > 0) || !(periodDays > 0) || bid == null) return null;
  const required = K * (pct / 100) * (dte / periodDays);
  const premium = S > 0 ? optExtrinsicValue(type, S, K, bid) : bid;
  if (premium == null) return null;
  return { required, premium, ratio: premium / required, ok: premium >= required, requiredPct: pct * (dte / periodDays) };
}

// Marge d'un contrat VENDU hors la monnaie (Roue) : de combien le titre doit
// bouger pour que le contrat soit touché. `distancePct` = distance du strike au
// prix, en % du prix (positive hors la monnaie, négative dans la monnaie) ;
// `sigmaMargin` = cette distance divisée par le mouvement attendu
// IV × √(DTE/365) — comparable d'un titre à l'autre (5 % de marge n'est pas la
// même chose sur KO que sur MU). Même seuil d'IV de bruit que optionDelta.
function optCushion(type, S, K, iv, dte) {
  if (!(S > 0) || !(K > 0) || !(dte >= 1) || !(iv >= OPT_MIN_IV)) return null;
  const dist = type === 'put' ? (S - K) / S : (K - S) / S;
  return { distancePct: dist * 100, sigmaMargin: dist / (iv * Math.sqrt(dte / 365)) };
}

// « Strike limite » d'une échéance : le contrat hors la monnaie le plus ÉLOIGNÉ du
// prix dont le bid respecte encore la règle de prime (optPremiumRule). Pour un put,
// la prime baisse quand le strike s'éloigne : au-delà de ce strike la règle échoue,
// en deçà on prend plus de risque d'assignation que nécessaire. On part du strike le
// plus proche du prix et on s'arrête au premier qui échoue réellement : une cotation
// isolée et périmée plus loin ne doit pas être prise pour la limite. Un contrat sans
// bid est simplement sauté (il n'établit ni ne casse rien).
function optRuleLimit(type, S, contracts, dte, pct, periodDays) {
  if (!(S > 0) || !Array.isArray(contracts)) return null;
  const otm = contracts
    .filter((c) => c && c.strike > 0 && (type === 'put' ? c.strike < S : c.strike > S))
    .sort((a, b) => (type === 'put' ? b.strike - a.strike : a.strike - b.strike)); // du plus proche au plus loin
  let limit = null;
  for (const c of otm) {
    const v = optPremiumRule(type, S, c.strike, c.bid, dte, pct, periodDays);
    if (!v) continue;
    if (!v.ok) break;
    limit = c;
  }
  return limit;
}

// Choix du put (ou du call, `o.type`) d'une chaîne (UNE échéance) par le screener de primes. Deux modes :
//  - 'limite'    : le put le plus éloigné qui respecte la règle (strike limite) ; le
//                  delta MINIMUM est ignoré (il empêcherait de s'éloigner), seul le
//                  delta MAXIMUM sert de plafond de risque.
//  - 'rendement' : l'ancien comportement — meilleur rendement annualisé dans la plage
//                  de delta [min, max] (favorise les strikes proches du prix).
// Renvoie null si rien ne convient. Les champs de marge et le ratio de la règle sont
// joints dans les deux modes pour que le tableau les affiche toujours.
function optPickForChain(chain, o) {
  const { mode, deltaMin, deltaMax, r, rulePct, rulePeriodDays } = o;
  const type = o.type === 'call' ? 'call' : 'put';
  const contracts = type === 'put' ? chain.puts : chain.calls;
  // IV à la monnaie de l'échéance (même définition que l'onglet Options : médiane des IV des
  // contrats |Δ| 0,40–0,60, calls et puts) — sert à l'expected move côté navigateur. Les chaînes
  // du serveur n'ont pas de delta : on le calcule ici contrat par contrat.
  const withDelta = (list, t) => (list || []).map((c) => ({ iv: c.iv, delta: optionDelta(t, chain.price, c.strike, chain.dte, r, c.iv) }));
  const atmIv = optAtmIv([...withDelta(chain.calls, 'call'), ...withDelta(chain.puts, 'put')]);
  const build = (c, delta) => {
    const cu = optCushion(type, chain.price, c.strike, c.iv, chain.dte);
    const rule = optPremiumRule(type, chain.price, c.strike, c.bid, chain.dte, rulePct, rulePeriodDays);
    return {
      expiry: chain.expiry, dte: chain.dte, strike: c.strike, premium: c.bid, iv: c.iv, delta, price: chain.price, atmIv,
      annualizedYield: optAnnualizedYield(c.bid, c.strike, chain.dte),
      distancePct: cu ? cu.distancePct : null, sigmaMargin: cu ? cu.sigmaMargin : null, ruleRatio: rule ? rule.ratio : null,
      // Rendement de la période : prime / strike en % et seuil de la règle pour cette échéance.
      premiumPct: c.bid > 0 ? (c.bid / c.strike) * 100 : null, requiredPct: rule ? rule.requiredPct : null,
      sousRegle: !(rule && rule.ok),
    };
  };
  if (mode === 'limite') {
    const lim = optRuleLimit(type, chain.price, contracts, chain.dte, rulePct, rulePeriodDays);
    if (lim) {
      const delta = optionDelta(type, chain.price, lim.strike, chain.dte, r, lim.iv);
      if (delta != null && Math.abs(delta) <= deltaMax) return build(lim, delta);
    }
    // Repli (4/10/2026) : aucun strike ne respecte la règle sous le plafond de delta. On
    // garde quand même le titre avec le put au delta le plus proche du plafond (la plus
    // grosse prime permise) et la mention « sous la règle » : voir OÙ on en est (ex.
    // 0,45 % pour 0,50 % exigé) vaut mieux qu'une liste qui s'évapore.
    let near = null;
    for (const c of contracts) {
      if (!(c.bid > 0)) continue;
      const delta = optionDelta(type, chain.price, c.strike, chain.dte, r, c.iv);
      if (delta == null || Math.abs(delta) > deltaMax) continue;
      if (!near || Math.abs(delta) > Math.abs(near.delta)) near = { c, delta };
    }
    return near ? build(near.c, near.delta) : null;
  }
  let best = null;
  for (const c of contracts) {
    const delta = optionDelta(type, chain.price, c.strike, chain.dte, r, c.iv);
    if (delta == null || Math.abs(delta) < deltaMin || Math.abs(delta) > deltaMax) continue;
    const y = optAnnualizedYield(c.bid, c.strike, chain.dte);
    if (y != null && (!best || y > best.annualizedYield)) best = build(c, delta);
  }
  return best;
}

// Compat : le screener de primes historique ne choisissait que des puts.
function optPickPutForChain(chain, o) { return optPickForChain(chain, { ...o, type: 'put' }); }

// Entre deux échéances candidates d'un même titre : en mode 'limite' un put qui
// respecte la règle l'emporte sur un repli « sous la règle » ; entre deux qui la
// respectent, la plus grande marge en σ ; entre deux replis, le plus proche du
// seuil. En mode 'rendement', le meilleur rendement annualisé.
function optBetterPick(mode, a, b) {
  if (!a) return b;
  if (!b) return a;
  if (mode === 'limite') return optComparePicks('limite')(a, b) <= 0 ? a : b;
  return b.annualizedYield > a.annualizedYield ? b : a;
}

// Comparateur de tri des lignes du screener de primes (négatif = a avant b).
function optComparePicks(mode) {
  if (mode !== 'limite') return (a, b) => b.annualizedYield - a.annualizedYield;
  return (a, b) => {
    if (!!a.sousRegle !== !!b.sousRegle) return a.sousRegle ? 1 : -1;
    return a.sousRegle
      ? (b.ruleRatio ?? -Infinity) - (a.ruleRatio ?? -Infinity)
      : (b.sigmaMargin ?? -Infinity) - (a.sigmaMargin ?? -Infinity);
  };
}

// Vente : rendement annualisé calculé sur la valeur TEMPS de la prime
// (bid − intrinsèque), pas le bid brut — voir optExtrinsicValue(). Pour un
// contrat hors la monnaie, extrinsèque = bid, comportement inchangé.
// Achat : levier — |delta| par dollar de prime payée (ask) — l'exposition
// au sous-jacent obtenue par dollar réellement risqué, PAS une probabilité
// de gain.
function optDealReturnOrLeverage(mode, { type, bid, ask, strike, delta } = {}, { dte, price } = {}) {
  if (mode === 'vente') {
    const extrinsic = optExtrinsicValue(type, price, strike, bid);
    const y = optAnnualizedYield(extrinsic, strike, dte);
    if (y == null) return null;
    return { score: y > 25 ? 1 : y > 10 ? 0 : -1, metric: y };
  }
  if (delta == null || !(ask > 0)) return null;
  const leverage = Math.abs(delta) / ask;
  return { score: leverage > 0.05 ? 1 : leverage > 0.02 ? 0 : -1, metric: leverage };
}

function optDealVerdict(total) {
  if (total >= 3) return 'excellent';
  if (total >= 1) return 'bon';
  if (total >= -1) return 'passable';
  return 'écarter';
}

// Point d'entrée : note un contrat pour le mode demandé. `contract` :
// {type, bid, ask, openInterest, volume, iv, delta, strike} — `type`
// ('call'/'put') est requis pour calculer la valeur intrinsèque/extrinsèque
// en mode vente. `ctx` : {dte, price, historicalVolatility} — `price`
// (prix du sous-jacent) est requis pour la même raison. null si aucun
// marché exploitable — le contrat doit alors être EXCLU du classement,
// jamais affiché avec un score à 0 qui laisserait croire à une évaluation
// neutre.
function optScoreDeal(mode, contract, ctx) {
  const liquidity = optDealLiquidity(contract.bid, contract.ask, contract.openInterest, contract.volume);
  if (!liquidity) return null;
  const valorisation = optDealValuation(mode, contract.iv, ctx.historicalVolatility, ctx.ivRank ?? null);
  const rendement = optDealReturnOrLeverage(mode, contract, ctx);
  const total = liquidity.score + (valorisation ? valorisation.score : 0) + (rendement ? rendement.score : 0);
  return { liquidity, valorisation, rendement, total, verdict: optDealVerdict(total) };
}

// --- Expected move (12/10/2026) -----------------------------------------
// Mouvement attendu du sous-jacent d'ici l'échéance, à 1 écart-type :
//   EM = prix × IV × √(DTE / 365)
// `mult` = multiple de σ (1 = ~68 % de probabilité de rester dans la plage ;
// 2 = ~95 %). L'IV est celle de la monnaie (optAtmIv) : UNE seule IV pour toute
// l'échéance, afin que la plage soit la même pour tous les strikes affichés.
// null si une entrée manque ou n'est pas fiable — jamais un mouvement inventé.
function optExpectedMove(S, iv, dte, mult = 1) {
  if (!(S > 0) || !(dte >= 1) || !(iv >= OPT_MIN_IV) || !(mult > 0)) return null;
  const em1 = S * iv * Math.sqrt(dte / 365);
  const em = em1 * mult;
  return { em, emPct: (em / S) * 100, low: S - em, high: S + em, mult, em1, iv, dte, price: S };
}

// Recoupement par le straddle. En théorie Black-Scholes, un straddle à la
// monnaie vaut ≈ √(2/π) × σ√T × S ≈ 0,80 × EM(1σ) : c'est le mouvement ABSOLU
// moyen attendu, pas l'écart-type. EM(1σ) ≈ straddle ÷ 0,80. (La convention
// « straddle × 0,85 » souvent citée désigne autre chose ; la formule ci-dessous
// est celle qui se vérifie algébriquement.) C'est une VÉRIFICATION de l'IV, pas
// la valeur utilisée. null sans mid exploitable des deux côtés.
const OPT_STRADDLE_RATIO = Math.sqrt(2 / Math.PI); // ≈ 0,7979
function optStraddleMove(S, calls, puts) {
  if (!(S > 0) || !Array.isArray(calls) || !Array.isArray(puts)) return null;
  const mid = (c) => (c && c.bid > 0 && c.ask > 0 ? (c.bid + c.ask) / 2 : null);
  const byK = new Map(puts.map((p) => [p.strike, p]));
  let best = null;
  for (const c of calls) {
    const p = byK.get(c.strike);
    if (!p || mid(c) == null || mid(p) == null) continue;
    if (best == null || Math.abs(c.strike - S) < Math.abs(best.strike - S)) best = { strike: c.strike, call: mid(c), put: mid(p) };
  }
  if (!best) return null;
  const straddle = best.call + best.put;
  return { strike: best.strike, call: best.call, put: best.put, straddle, em: straddle / OPT_STRADDLE_RATIO, ratio: OPT_STRADDLE_RATIO };
}

// --- Journal de la Roue (13/10/2026, bilbao #433) ----------------------
// Ce que le Google Sheets du club (« Journal de la Roue ») calculait et que castellana
// n'avait pas : P/L net d'une jambe avec commissions, rendement annualisé d'une jambe,
// rapport hebdo, tableau annuel, prix maximum par titre. Fonctions PURES : aucune lecture de
// base ni appel réseau ; les cours sont fournis par l'appelant. Règle du portfolio : une
// donnée inconnue reste null (« N/D »), jamais 0.
//
// Conventions reprises du Sheets (vérifiées dans ses formules) :
//   - semaine = dimanche → samedi (sa table « Semaines » : « 28 décembre 2025 au 3 janvier 2026 ») ;
//     une semaine appartient à l'année de son vendredi (jour d'échéance) ;
//   - une jambe compte dans la semaine de sa clôture (le Sheets demandait de choisir la semaine
//     à la main ; ici elle se déduit de la date) ;
//   - capital d'une jambe = strike × 100 × contrats ; rendement annualisé = P/L ÷ capital × 365 ÷ jours.
// Écarts assumés avec le Sheets : la commission de clôture (rachat) est comptée, une jambe
// encore ouverte n'entre dans aucun profit réalisé, et le gain ou la perte sur les actions
// revendues entre dans le profit de la semaine (le Sheets ne le comptait que pour une VENTE
// directe, pas pour une assignation de call).

function optNum0(v) { return v == null || v === '' || !Number.isFinite(Number(v)) ? 0 : Number(v); }
function optLegCommissions(l) { return l ? optNum0(l.commission_ouverture) + optNum0(l.commission_cloture) : 0; }
function optStockCommissions(t) { return t ? optNum0(t.commission_entree) + optNum0(t.commission_sortie) : 0; }
function optDateMs(d) { const ms = typeof d === 'string' ? Date.parse(d.slice(0, 10) + 'T00:00:00Z') : NaN; return Number.isFinite(ms) ? ms : null; }
function optIsoDay(ms) { return new Date(ms).toISOString().slice(0, 10); }

// Date de fin d'une jambe : clôture réelle, sinon échéance prévue.
function optLegEnd(leg) { return leg ? (leg.date_cloture || leg.echeance || null) : null; }

// P/L net d'une jambe = (prime − rachat) × actions − commissions. Pour une jambe encore
// ouverte : la prime déjà encaissée moins la commission d'ouverture (comme le Sheets) ; c'est
// à l'appelant de ne pas la compter comme réalisée (voir optWeeklyReport).
function optLegPnl(leg, contractSize = 100) {
  if (!leg) return null;
  const sh = leg.contrats * contractSize;
  const rachat = leg.statut === 'roule' || leg.statut === 'rachete' ? optNum0(leg.prime_cloture) * sh : 0;
  return optNum0(leg.prime_recue) * sh - rachat - optLegCommissions(leg);
}

// Rendement d'une jambe sur son capital, et annualisé sur sa durée. null si les dates sont
// absentes ou incohérentes (fin avant ouverture) : le Sheets forçait alors 1 jour par MAX(1, …),
// d'où des rendements de plusieurs centaines de % sur une simple faute de date.
function optLegReturn(leg, contractSize = 100) {
  if (!leg || !(leg.strike > 0) || !(leg.contrats > 0)) return null;
  const capital = leg.strike * contractSize * leg.contrats;
  const debut = optDateMs(leg.date_ouverture);
  const fin = optDateMs(optLegEnd(leg));
  const pnl = optLegPnl(leg, contractSize);
  if (debut == null || fin == null || fin < debut) return { capital, pnl, jours: null, rendement: pnl / capital, rendementAnnualise: null };
  const jours = Math.max(1, Math.round((fin - debut) / 86400000));
  return { capital, pnl, jours, rendement: pnl / capital, rendementAnnualise: (pnl / capital) * (365 / jours) };
}

// Incohérences d'une jambe, à SIGNALER (jamais corrigées en silence) — ex. la ligne d'exemple
// LULU du Sheets, ouverte le 26/12/2026 et fermée le 02/01/2026.
function optLegIssues(leg) {
  const out = [];
  if (!leg) return out;
  const o = optDateMs(leg.date_ouverture);
  const c = optDateMs(leg.date_cloture);
  const e = optDateMs(leg.echeance);
  if (leg.date_ouverture && o == null) out.push('date d\'ouverture illisible');
  if (o != null && e != null && e < o) out.push('échéance avant l\'ouverture');
  if (o != null && c != null && c < o) out.push('clôture avant l\'ouverture');
  if (leg.statut && leg.statut !== 'ouvert' && !leg.date_cloture) out.push('jambe close sans date de clôture');
  return out;
}

// Dimanche de la semaine d'une date (YYYY-MM-DD), null si illisible.
function optWeekStart(date) {
  const ms = optDateMs(date);
  if (ms == null) return null;
  return optIsoDay(ms - new Date(ms).getUTCDay() * 86400000);
}
// Année d'une semaine = année de son vendredi.
function optWeekYear(weekStart) { const ms = optDateMs(weekStart); return ms == null ? null : new Date(ms + 5 * 86400000).getUTCFullYear(); }
// Période (année ET mois) à laquelle un événement est rattaché dans les tableaux de bord de la Roue : celles du VENDREDI de sa
// semaine (convention du Sheets du club). Une seule définition pour toutes les cartes — semaines, graphique par mois, primes nettes,
// dénouement, activité. Avant (audit formules, 20/10/2026), les semaines suivaient l'année du vendredi mais le graphique par mois, les
// primes nettes et le dénouement suivaient le calendrier : une option fermée le 29/12/2026 valait 200 $ en 2026 dans une carte, 200 $ en
// 2027 dans une autre, et 0 $ dans le graphique par mois. `month` : 0 = janvier. null si la date est illisible.
function optPeriodOf(date) {
  const ws = optWeekStart(date);
  if (ws == null) return null;
  const friday = new Date(optDateMs(ws) + 5 * 86400000);
  return { year: friday.getUTCFullYear(), month: friday.getUTCMonth() };
}

function optFlowSign(f) { return f.type === 'retrait' ? -Math.abs(optNum0(f.montant)) : Math.abs(optNum0(f.montant)); }

// Événements réalisés et datés, communs au rapport hebdo et au tableau annuel.
function optRealizedEvents({ legs = [], stockTrades = [], cashFlows = [], contractSize = 100 } = {}) {
  const ev = [];
  for (const l of legs) {
    if (!l || l.statut === 'ouvert' || !l.date_cloture) continue;
    ev.push({ kind: 'jambe', date: l.date_cloture, ticker: l.ticker, montant: optLegPnl(l, contractSize), commissions: optLegCommissions(l), leg: l });
  }
  for (const t of stockTrades) {
    if (!t || !t.date_sortie || t.prix_sortie == null) continue;
    ev.push({ kind: 'action', date: t.date_sortie, ticker: t.ticker, montant: (t.prix_sortie - t.prix_entree) * t.taille_position - optStockCommissions(t), commissions: optStockCommissions(t) });
  }
  for (const f of cashFlows) {
    if (!f || !f.date) continue;
    ev.push({ kind: f.type, date: f.date, ticker: f.ticker || null, montant: optFlowSign(f), commissions: 0 });
  }
  return ev.filter((e) => optWeekStart(e.date) != null);
}

// Rapport hebdo (onglet RAPPORT HEBDO du Sheets), pour UN compte (l'appelant filtre).
// Une ligne par semaine, de la première à la dernière semaine qui porte un événement
// (les semaines vides y sont, à 0 : il ne s'y est réellement rien passé).
// valeurCompteRealisee = capital de départ + dépôts − retraits + profits réalisés + autres
// revenus, actions comptées à leur coût d'achat (la réévaluation au cours demande des prix :
// voir optAnnualDashboard). Sans capital de départ saisi, la valeur et le ROI restent null.
function optWeeklyReport({ legs = [], stockTrades = [], cashFlows = [], contractSize = 100 } = {}) {
  const ev = optRealizedEvents({ legs, stockTrades, cashFlows, contractSize });
  if (!ev.length) return [];
  const weeks = new Map();
  for (const e of ev) {
    const k = optWeekStart(e.date);
    if (!weeks.has(k)) weeks.set(k, []);
    weeks.get(k).push(e);
  }
  const keys = [...weeks.keys()].sort();
  const all = [];
  for (let ms = optDateMs(keys[0]); ms <= optDateMs(keys[keys.length - 1]); ms += 7 * 86400000) all.push(optIsoDay(ms));
  const hasDepart = cashFlows.some((f) => f && f.type === 'depart');
  const sum = (a) => a.reduce((x, y) => x + y, 0);
  let valeur = hasDepart ? 0 : null;
  let cumul = 0;
  return all.map((semaine) => {
    const e = weeks.get(semaine) || [];
    const jambes = e.filter((x) => x.kind === 'jambe');
    const puts = jambes.filter((x) => x.leg.type === 'put');
    const nbAssignations = puts.filter((x) => x.leg.statut === 'assigne').length;
    const profitOptions = sum(jambes.map((x) => x.montant));
    const profitActions = sum(e.filter((x) => x.kind === 'action').map((x) => x.montant));
    const dividendes = sum(e.filter((x) => x.kind === 'dividende').map((x) => x.montant));
    const autresRevenus = sum(e.filter((x) => x.kind === 'autre_revenu').map((x) => x.montant));
    const depart = sum(e.filter((x) => x.kind === 'depart').map((x) => x.montant));
    const depotsRetraits = sum(e.filter((x) => x.kind === 'depot' || x.kind === 'retrait').map((x) => x.montant));
    const profitNet = profitOptions + profitActions + dividendes;
    const avant = valeur == null ? null : valeur + depart;
    const base = avant == null ? null : avant + depotsRetraits;
    const roiHebdo = base != null && base > 0 ? profitNet / base : null;
    if (valeur != null) valeur = base + profitNet + autresRevenus;
    cumul += profitNet;
    return {
      semaine, fin: optIsoDay(optDateMs(semaine) + 6 * 86400000), annee: optWeekYear(semaine),
      nbTrades: jambes.length, nbAssignations, pctAssignation: puts.length ? nbAssignations / puts.length : null,
      valeurPutsVendus: sum(puts.map((x) => x.leg.strike * x.leg.contrats * contractSize)),
      profitOptions, profitActions, dividendes, autresRevenus, depart, depotsRetraits,
      commissions: sum(e.map((x) => x.commissions)),
      profitNet, roiHebdo, valeurCompteRealisee: valeur, profitCumule: cumul,
    };
  });
}

// Capital du compte (onglet PORTFOLIO, résumé) : immobilisé = puts ouverts (cash garanti) +
// actions détenues à leur coût ; disponible = valeur réalisée − immobilisé.
function optAccountSnapshot({ legs = [], stockTrades = [], cashFlows = [], contractSize = 100, prices = {} } = {}) {
  const sum = (a) => a.reduce((x, y) => x + y, 0);
  const report = optWeeklyReport({ legs, stockTrades, cashFlows, contractSize });
  const valeurRealisee = cashFlows.some((f) => f && f.type === 'depart') ? (report.length ? report[report.length - 1].valeurCompteRealisee : null) : null;
  const putsOuverts = legs.filter((l) => l && l.type === 'put' && l.statut === 'ouvert');
  const actions = stockTrades.filter((t) => t && !t.date_sortie);
  const capitalPuts = sum(putsOuverts.map((l) => l.strike * l.contrats * contractSize));
  const capitalActions = sum(actions.map((t) => t.prix_entree * t.taille_position));
  const latents = actions.map((t) => (Number.isFinite(prices[t.ticker]) ? (prices[t.ticker] - t.prix_entree) * t.taille_position : null));
  const latentConnu = latents.every((v) => v != null);
  const latentActions = latentConnu ? sum(latents) : null;
  const capitalImmobilise = capitalPuts + capitalActions;
  return {
    valeurRealisee, capitalPuts, capitalActions, capitalImmobilise,
    capitalDisponible: valeurRealisee == null ? null : valeurRealisee - capitalImmobilise,
    latentActions, latentConnu,
    valeurCompte: valeurRealisee == null || latentActions == null ? null : valeurRealisee + latentActions,
  };
}

// Tableau annuel (onglet DASHBOARD ANNUEL du Sheets), pour UN compte et une année.
//   prices  : { TICKER: cours } pour la réévaluation et le « profit réel ajusté »
//   sectors : { TICKER: secteur } (secteur Yahoo de castellana, pas le scraping du Sheets)
//   today   : 'YYYY-MM-DD' — seules les semaines terminées entrent dans le rendement projeté
function optAnnualDashboard({ legs = [], stockTrades = [], cashFlows = [], contractSize = 100, year, prices = {}, sectors = {}, today = null } = {}) {
  const sum = (a) => a.reduce((x, y) => x + y, 0);
  const todayMs = optDateMs(today || new Date().toISOString().slice(0, 10));
  const weeks = optWeeklyReport({ legs, stockTrades, cashFlows, contractSize }).filter((w) => w.annee === year);
  const inYear = (d) => { const s = optWeekStart(d); return s != null && optWeekYear(s) === year; };
  const ev = optRealizedEvents({ legs, stockTrades, cashFlows, contractSize }).filter((e) => inYear(e.date));
  const profitEv = ev.filter((e) => e.kind === 'jambe' || e.kind === 'action' || e.kind === 'dividende');
  const jambes = ev.filter((e) => e.kind === 'jambe');
  const puts = jambes.filter((e) => e.leg.type === 'put');

  const profitRealise = sum(weeks.map((w) => w.profitNet));
  const finies = weeks.filter((w) => w.roiHebdo != null && optDateMs(w.fin) < todayMs);
  const rendementCompose = finies.length ? finies.reduce((p, w) => p * (1 + w.roiHebdo), 1) - 1 : null;
  // Projeter sur un an quelques semaines donnerait un chiffre absurde : sous 4 semaines, rien.
  const rendementAnnualiseProjete = rendementCompose != null && finies.length >= 4 ? (1 + rendementCompose) ** (52 / finies.length) - 1 : null;

  const snap = optAccountSnapshot({ legs, stockTrades, cashFlows, contractSize, prices });
  const actionsOuvertes = stockTrades.filter((t) => t && !t.date_sortie);
  const latents = actionsOuvertes.map((t) => (Number.isFinite(prices[t.ticker]) ? (prices[t.ticker] - t.prix_entree) * t.taille_position : null));
  const pertesLatentes = latents.every((v) => v != null) ? sum(latents.filter((v) => v < 0)) : null;
  // Un call couvert ouvert dans la monnaie plafonne le gain : la part du cours au-dessus du
  // strike ne sera pas encaissée. Le Sheets la retire du profit (« profit réel ajusté »).
  const callsOuverts = legs.filter((l) => l && l.type === 'call' && l.statut === 'ouvert');
  const exces = callsOuverts.map((l) => (Number.isFinite(prices[l.ticker]) ? Math.max(0, prices[l.ticker] - l.strike) * l.contrats * contractSize : null));
  const excesCallsDansLaMonnaie = exces.every((v) => v != null) ? sum(exces) : null;
  const profitReelAjuste = snap.latentActions == null || excesCallsDansLaMonnaie == null ? null : profitRealise + snap.latentActions - excesCallsDansLaMonnaie;

  // Mois du vendredi de la semaine (optPeriodOf) : la somme des 12 mois égale toujours le profit réalisé de l'année.
  const profitMensuel = Array.from({ length: 12 }, (_, m) => sum(profitEv.filter((e) => { const p = optPeriodOf(e.date); return p != null && p.month === m; }).map((e) => e.montant)));
  const group = (keyFn) => {
    const m = new Map();
    for (const e of profitEv) { const k = keyFn(e); m.set(k, (m.get(k) || 0) + e.montant); }
    return [...m.entries()].map(([cle, profit]) => ({ cle, profit })).sort((a, b) => b.profit - a.profit);
  };
  return {
    year, nbSemaines: weeks.length, profitRealise, rendementCompose, rendementAnnualiseProjete,
    tauxSucces: jambes.length ? jambes.filter((e) => e.montant > 0).length / jambes.length : null,
    tauxAssignation: puts.length ? puts.filter((e) => e.leg.statut === 'assigne').length / puts.length : null,
    commissions: sum(ev.map((e) => e.commissions)),
    dividendes: sum(ev.filter((e) => e.kind === 'dividende').map((e) => e.montant)),
    autresRevenus: sum(ev.filter((e) => e.kind === 'autre_revenu').map((e) => e.montant)),
    pertesLatentes, excesCallsDansLaMonnaie, profitReelAjuste,
    capital: snap, profitMensuel,
    parTicker: group((e) => e.ticker || '—'),
    parSecteur: group((e) => (e.ticker && sectors[e.ticker]) || 'Non renseigné'),
    semaines: weeks,
  };
}

// Prix maximum par titre (PORTFOLIO du Sheets, cellules C28 à C34) : avec un budget = capital ×
// part maximale par titre, quel prix d'action permet d'acheter 100 actions puis de moyenner à
// la baisse n fois, à chaque fois après une baisse de `pctBaisse` ? Coût total = 100·P·Σ(1−d)^k
// (k = 0…n), d'où P = budget·d ÷ (100·(1 − (1−d)^(n+1))). pctMax et pctBaisse en fractions (0,1 = 10 %).
function optMaxPricePerTicker({ capital, pctMax, nbAverage = 0, pctBaisse, lot = 100 } = {}) {
  if (!(capital > 0) || !(pctMax > 0) || !(pctMax <= 1) || !(Number.isInteger(nbAverage) && nbAverage >= 0) || !(pctBaisse >= 0) || !(pctBaisse < 1)) return null;
  const budget = capital * pctMax;
  const facteur = pctBaisse === 0 ? nbAverage + 1 : (1 - (1 - pctBaisse) ** (nbAverage + 1)) / pctBaisse;
  const prixMax = budget / (lot * facteur);
  const paliers = Array.from({ length: nbAverage + 1 }, (_, k) => prixMax * (1 - pctBaisse) ** k);
  const capitalTotal = optSum(paliers.map((p) => p * lot));
  return { budget, prixMax, paliers, capitalTotal, coutMoyen: capitalTotal / (lot * (nbAverage + 1)) };
}
function optSum(a) { return a.reduce((x, y) => x + y, 0); }


// Position d'un strike vendu par rapport à la plage de l'expected move.
// Put : hors plage si strike <= low ; call : si strike >= high. `emMargin` =
// distance entre le strike et la borne (positive = hors plage), en $.
function optEmPosition(type, K, move) {
  if (!move || !(K > 0)) return null;
  const bound = type === 'put' ? move.low : move.high;
  const emMargin = type === 'put' ? bound - K : K - bound;
  return { outside: emMargin >= 0, emMargin, bound };
}

// « Strike idéal » = règle de prime + hors de l'expected move : le contrat
// hors plage le plus PROCHE du prix (la prime décroît avec la distance, donc
// c'est celui qui paie le plus tout en restant hors plage). Renvoie
//   { contract, rule }  si ce contrat respecte la règle ;
//   { contract, rule, failsRule: true } s'il est hors plage mais sous la règle
//     (la règle n'est alors pas atteignable hors de la plage) ;
//   null s'il n'existe aucun strike coté hors plage.
function optIdealStrike(type, S, contracts, dte, pct, periodDays, move) {
  if (!move || !Array.isArray(contracts)) return null;
  const outside = contracts
    .filter((c) => c && c.strike > 0 && optEmPosition(type, c.strike, move)?.outside && (type === 'put' ? c.strike < S : c.strike > S))
    .sort((a, b) => (type === 'put' ? b.strike - a.strike : a.strike - b.strike)); // du plus proche au plus loin
  for (const c of outside) {
    const rule = optPremiumRule(type, S, c.strike, c.bid, dte, pct, periodDays);
    if (!rule) continue; // pas de bid : n'établit rien
    return rule.ok ? { contract: c, rule } : { contract: c, rule, failsRule: true };
  }
  return null;
}

// Suppression d'entrées du Journal de la Roue (sélection multiple). Plan PUR, partagé entre
// l'écran (pour annoncer ce qui sera supprimé avant de confirmer) et le serveur (qui supprime
// exactement ce plan). Les positions et mouvements choisis sont supprimés ; un cycle dont il ne
// reste AUCUNE position est supprimé avec ce qui lui est rattaché (actions issues d'une
// assignation ou d'un achat, dividendes et mouvements du cycle) : sans ses positions, ces lignes
// n'ont plus de sens et fausseraient la valeur du compte. Les identifiants inconnus sont ignorés.
// `rollRefs` = positions restantes dont le lien de roulement pointe vers une position supprimée
// (le lien est remis à vide, jamais la position supprimée).
function optRoueDeletionPlan({ legIds = [], flowIds = [], legs = [], cycles = [], stock = [], flows = [] } = {}) {
  const legSet = new Set(legIds.map(Number).filter((id) => legs.some((l) => l.id === id)));
  const remaining = legs.filter((l) => !legSet.has(l.id));
  const touched = new Set(legs.filter((l) => legSet.has(l.id) && l.cycle_id != null).map((l) => l.cycle_id));
  const cycleIds = [...touched].filter((cid) => cycles.some((c) => c.id === cid) && !remaining.some((l) => l.cycle_id === cid));
  const cycleSet = new Set(cycleIds);
  const flowSet = new Set(flowIds.map(Number).filter((id) => flows.some((f) => f.id === id)));
  for (const f of flows) if (f.cycle_id != null && cycleSet.has(f.cycle_id)) flowSet.add(f.id);
  return {
    legIds: [...legSet],
    flowIds: [...flowSet],
    cycleIds,
    stockIds: stock.filter((s) => cycleSet.has(s.option_cycle_id)).map((s) => s.id),
    rollRefs: remaining.filter((l) => l.roule_vers_id != null && legSet.has(l.roule_vers_id)).map((l) => l.id),
  };
}

// --- Tableaux de bord de la Roue (16/10/2026, bilbao #443 semaine, #444 annuel) -----------------
// Décisions de JP : le latent d'une action assignée se mesure au dernier cours contre le coût de
// base NET des primes (jamais contre le strike) ; le « taux de succès » est remplacé par le
// dénouement (expirée, rachetée — roulée comprise —, assignée) ; la valeur du compte se lit en deux
// traits (valeur réalisée, et apports + primes nettes) pour qu'un dépôt ne passe pas pour du rendement.

// Distance du strike au cours, en fraction du cours : > 0 hors la monnaie (marge avant d'être
// touché), < 0 dans la monnaie. null si un intrant manque.
function optStrikeDistance(type, S, K) {
  if (!(S > 0) || !(K > 0)) return null;
  return type === 'call' ? (K - S) / S : (S - K) / S;
}

// Actions détenues, par cycle, avec leur coût de base net (prix d'achat − primes nettes de frais
// et dividendes du cycle, par action — optCycleBilan) et la vérification du call couvert :
//   sous_cout = call ouvert dont le strike est sous le coût de base net (une assignation verrouille
//               une perte) ; plafonne = cours au-dessus du strike du call ; ok ; sans_call.
// Un cycle sans option (action achetée directement) garde son prix d'achat comme coût de base.
// Totaux : latentNet (null si un cours manque — jamais un 0 inventé) et latentNegatif (positions en
// perte seulement, parmi celles dont le cours est connu).
function optRouePositions({ cycles = [], legs = [], stockTrades = [], cashFlows = [], contractSize = 100, prices = {} } = {}) {
  const rows = [];
  for (const c of cycles) {
    const stock = stockTrades.filter((s) => s && s.option_cycle_id === c.id);
    const open = stock.filter((s) => !s.date_sortie);
    if (!open.length) continue;
    const qty = open.reduce((a, s) => a + s.taille_position, 0);
    if (!(qty > 0)) continue;
    const prixAchat = open.reduce((a, s) => a + s.prix_entree * s.taille_position, 0) / qty;
    const cycleLegs = legs.filter((l) => l && l.cycle_id === c.id);
    const b = optCycleBilan({ ...c, legs: cycleLegs }, { contractSize, stockTrades: stock, cashFlows: cashFlows.filter((f) => f && f.cycle_id === c.id) });
    const coutDeBaseNet = b && b.coutDeBaseNet != null ? b.coutDeBaseNet : prixAchat;
    const cours = Number.isFinite(prices[c.ticker]) ? prices[c.ticker] : null;
    const call = cycleLegs.filter((l) => l.type === 'call' && l.statut === 'ouvert').sort((x, y) => (x.echeance < y.echeance ? -1 : 1))[0] || null;
    let verif = 'sans_call';
    if (call) verif = call.strike < coutDeBaseNet ? 'sous_cout' : (cours != null && cours > call.strike ? 'plafonne' : 'ok');
    rows.push({
      cycleId: c.id, ticker: c.ticker, compte: c.compte, qty, prixAchat, coutDeBaseNet, cours,
      depuis: open.map((s) => s.date_entree).filter(Boolean).sort()[0] || null,
      latentNet: cours == null ? null : (cours - coutDeBaseNet) * qty,
      latentBrut: cours == null ? null : (cours - prixAchat) * qty,
      call: call ? { strike: call.strike, echeance: call.echeance, contrats: call.contrats } : null, verif,
    });
  }
  const connus = rows.filter((r) => r.latentNet != null);
  return {
    rows,
    latentNet: connus.length === rows.length ? connus.reduce((a, r) => a + r.latentNet, 0) : null,
    latentNegatif: connus.filter((r) => r.latentNet < 0).reduce((a, r) => a + r.latentNet, 0),
    capitalActions: rows.reduce((a, r) => a + r.prixAchat * r.qty, 0),
  };
}

// Dénouement des options closes dans l'année (mois de la clôture) : expirée, rachetée (roulée
// comprise), assignée. Les options encore ouvertes sont comptées à part (`ouvertes`).
function optLegOutcomes(legs = [], year) {
  const vide = () => ({ expire: 0, rachete: 0, assigne: 0 });
  const out = { ...vide(), ouvertes: 0, parMois: Array.from({ length: 12 }, vide) };
  for (const l of legs) {
    if (!l) continue;
    if (l.statut === 'ouvert') { out.ouvertes += 1; continue; }
    const per = optPeriodOf(l.date_cloture);
    if (per == null || per.year !== year) continue;
    const k = l.statut === 'assigne' ? 'assigne' : l.statut === 'expire' ? 'expire' : (l.statut === 'rachete' || l.statut === 'roule') ? 'rachete' : null;
    if (!k) continue;
    out[k] += 1;
    out.parMois[per.month][k] += 1;
  }
  out.closes = out.expire + out.rachete + out.assigne;
  return out;
}

// Primes nettes (P/L des options closes, frais déduits) de l'année : par mois, par titre, par secteur.
function optPremiumBreakdown(legs = [], year, { contractSize = 100, sectors = {} } = {}) {
  const parMois = Array(12).fill(0);
  const t = new Map(); const s = new Map();
  let total = 0;
  for (const l of legs) {
    if (!l || l.statut === 'ouvert') continue;
    const per = optPeriodOf(l.date_cloture);
    if (per == null || per.year !== year) continue;
    const v = optLegPnl(l, contractSize);
    total += v;
    parMois[per.month] += v;
    t.set(l.ticker, (t.get(l.ticker) || 0) + v);
    const sec = sectors[l.ticker] || 'Non renseigné';
    s.set(sec, (s.get(sec) || 0) + v);
  }
  const tri = (m) => [...m.entries()].map(([cle, profit]) => ({ cle, profit })).sort((a, b) => b.profit - a.profit);
  return { total, parMois, parTicker: tri(t), parSecteur: tri(s) };
}

// Les deux traits de la valeur du compte, semaine par semaine (tout l'historique ; l'appelant
// filtre l'année) : valeurRealisee (actions au coût, comme optWeeklyReport) et apportsPlusPrimes
// (capital de départ + dépôts − retraits + primes nettes cumulées). Un dépôt fait monter les deux ;
// l'écart = actions revendues, dividendes et autres revenus. Sans capital de départ : [].
function optValueSeries({ legs = [], stockTrades = [], cashFlows = [], contractSize = 100 } = {}) {
  if (!cashFlows.some((f) => f && f.type === 'depart')) return [];
  let apports = 0; let primes = 0;
  return optWeeklyReport({ legs, stockTrades, cashFlows, contractSize }).map((w) => {
    apports += w.depart + w.depotsRetraits;
    primes += w.profitOptions;
    return { semaine: w.semaine, fin: w.fin, annee: w.annee, apports, primesCumul: primes, apportsPlusPrimes: apports + primes, valeurRealisee: w.valeurCompteRealisee, apport: w.depart + w.depotsRetraits };
  });
}

// Activité de l'année : options ouvertes dans l'année, put/call, titres distincts, durée moyenne
// (jours de l'ouverture à la clôture, options closes seulement ; null s'il n'y en a pas).
function optRoueActivity(legs = [], year) {
  const yr = legs.filter((l) => { const per = l ? optPeriodOf(l.date_ouverture) : null; return per != null && per.year === year; });
  const durees = yr.map((l) => { const o = optDateMs(l.date_ouverture); const c = optDateMs(l.date_cloture); return l.statut !== 'ouvert' && c != null && c >= o ? (c - o) / 86400000 : null; }).filter((d) => d != null);
  return {
    options: yr.length, puts: yr.filter((l) => l.type === 'put').length, calls: yr.filter((l) => l.type === 'call').length,
    titres: new Set(yr.map((l) => l.ticker)).size,
    dureeMoyenne: durees.length ? durees.reduce((a, d) => a + d, 0) / durees.length : null,
  };
}

// Options de la semaine [dimanche, samedi] : échéance OU ouverture dans la semaine.
function optWeekLegs(legs = [], weekStart) {
  const s = optDateMs(weekStart);
  if (s == null) return [];
  const e = s + 6 * 86400000;
  const inWeek = (d) => { const ms = optDateMs(d); return ms != null && ms >= s && ms <= e; };
  return legs.filter((l) => l && (inWeek(l.echeance) || inWeek(l.date_ouverture)));
}
