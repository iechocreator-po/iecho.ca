# castellana — Assistant de swing trading (screening, sizing, exécution, journal)

> **Nom de code :** castellana — **Dossier :** `trading-assistant/`
> (convention portfolio : le dossier porte un nom fonctionnel, le nom de code
> — ville espagnole/portugaise — vit dans le code, les configs et les
> conversations. Voir la table « Dossier local » du `CLAUDE.md` racine.)
>
> **Mise à jour 2026-10-13 (analyse du Journal de la Roue du club, plan seulement, aucun code) :** le Google Sheets du
> club de trading de JP (journal, rapport hebdo, portfolio, tableau annuel ; copie `anticipation/Copie de NOUVEAU
> TEMPLATE — Journal de la Roue.xlsx`, **non committée**) a été analysé formule par formule et comparé à Journal & stats (D),
> Screener Prime (G) et E4. Analyse et plan : [`anticipation/analyse-journal-roue-club.md`](anticipation/analyse-journal-roue-club.md).
> Décisions de JP : membres du club en cloud (parité local/cloud), nouvel onglet « Roue » (H) derrière `roue_tab`, import de
> l'onglet JOURNAL, et **aucune section existante supprimée** : les sections redondantes portent une ligne « visée pour
> suppression » ou « améliorée », et chaque suppression a sa feature (#439 G Cycles & positions, #440 G Bilan par cycle,
> #441 E4 Revenu de primes), à décider par JP. Étapes de livraison : #433 à #438 (bilbao, `Idee`).
> **Étape 1 (#433) faite le même jour** : schéma et calculs purs, local et cloud, voir la section « Journal de la Roue — étape 1 ».
> **Étape 2 (#434) faite le même jour** : onglet « Roue » (H), flag `roue_tab` OFF par défaut, voir « Journal de la Roue — étape 2 ».
> **Étape 3 (#435) et lignes d'état (#437) faites le même jour** : rapport hebdo (H6), tableau annuel (H7), voir « étape 3 ».
> **Étape 4 (#436) faite le même jour** : import du Sheets du club (H8, .xlsx ou .csv), voir « étape 4 ».
> **Mis en ligne le même jour (#438, en cours)** : migration D1 distante lancée et vérifiée (7 colonnes + `cash_flows`), Worker déployé
> (version `d7ced557`), `roue_tab` activé pour le compte `iechocreator03` (id 5) seulement. **Pas encore testé avec un vrai compte** ;
> ouverture aux membres du club après ton essai. Excess liquidity non gérée (vue cash-secured seulement) : feature #442.
>
> **Dernière vérification factuelle :** 2026-10-12, 2e passe (**expected move dans l'onglet Options**). Plage de
> mouvement attendu calculée depuis l'IV (aucune source externe), multiple de σ réglable, strike idéal, pastille
> « hors EM » et section repliable « Calculs et formules ». Voir la section « Expected move » plus bas. Commits `fae70c9` à `a989bf4` ; déployé (version `f62f1fc2`) ; colonne « Vs EM » aussi dans le screener de primes G2.
>
> Vérification précédente : 2026-10-12 (**trésorerie dans le score fondamental, RSP dans les secteurs,
> onglet Anticipation**). Trois lots déployés le jour même. (1) Tuile « Trésorerie » + 6ᵉ critère « Solidité du bilan »
> (poids 0 % par défaut) ; (2) RSP (S&P 500 équipondéré) dans le tableau et le graphique A2 ; (3) onglet **Anticipation**
> (cloud seulement, drapeau `anticipation_tab` par compte) avec 4 maquettes, votes et propositions, activé pour le compte
> `iechocreator03`. **Un test dans le navigateur avait masqué un bug réel** (les routes `/api/sectors` abandonnaient
> `equalWeight`) : voir les trois sections ci-dessous. 288/288 tests. Features bilbao #418 à #432.
>
> Vérification précédente : 2026-10-10 (**IA étape 2 évaluée : modèle statistique NON
> adopté ; analyses IA liées aux trades**). Jeu de données de 7 589 trades du backtest (univers élargi,
> 5 ans, frais inclus) et régression logistique en JS pur, validée en progression dans le temps :
> AUC hors échantillon 0,52 (seuil 0,55), pas mieux que la ligne de base, écart de R net du meilleur
> quintile indistinguable de zéro. Aucune probabilité n'est affichée. Roadmap #399 `Rejete` (avec le
> résultat), #400 précisé. Aussi : `trades.ai_analysis_id` (analyse IA du même symbole de moins de 3 jours
> jointe à la création du trade). **Non commité** au moment de l'écriture. Voir la section « IA étape 2 ».
>
> Vérification précédente : 2026-10-02, 2e passe (**Price-to-Sales,
> contexte des tuiles Fondamentaux, mode démo, favicon**). Voir les sections « Price-to-Sales et
> contexte des fondamentaux » et « Mode démo et favicon » plus bas ; déployé (version
> `45521ae2`), T2 (pondération du P/S dans le pointage) livré le même jour, version `2742ade0`.
>
> Vérification précédente : 2026-10-02 (**roulement alimenté depuis
> la chaîne, repères du Screener Prime, intro de Secteurs**). Trois demandes de
> JP, déployées le jour même (version `e2e47d97`, puis `15484626` pour les retouches, fichiers statiques, aucune
> migration), commit `1aecc40`. Voir la section « Roulement, repères G et intro
> de Secteurs » plus bas. Roadmap bilbao : #382 et #383, `Livre`.
>
> Vérification précédente : 2026-09-27 (**repères d'interface :
> lettre par onglet, lettre+numéro par carte**). JP veut pouvoir signaler
> rapidement un endroit précis de l'app (« F3 » plutôt qu'une description).
> Nouveau `js/ui-ids.js` (+ copie cloud identique) : identifiants **dérivés
> de l'ordre réel du DOM** à chaque chargement, jamais une table écrite à
> la main — même piège déjà documenté ici (`SCORE_BANDS`,
> `SCREEN_FILTERS`). Un onglet/une carte caché(e) par un feature flag
> compte quand même dans la numérotation. Rendu en CSS pur (`::before`,
> jamais un noeud enfant — plusieurs cartes réécrivent leur `innerHTML`
> au complet). Interrupteur rond dans Réglages → Technique — recréation du
> « 16. Switch button » (Mojtaba Seyedi, prismic.io/blog/css-button-
> animations) —, OFF par défaut, persisté en `localStorage`. **Bug de
> spécificité CSS trouvé et corrigé en testant** (`.row label` écrasait la
> taille du disque). 153/153 tests, vérifié en direct dans le navigateur
> (9 onglets lettrés A-I, 46 cartes). **Déployé en production** le jour
> même (`fa79c5a2`, vérifié sur le `content-type`). Voir la section
> « Repères d'interface » plus bas.
>
> Vérification précédente : 2026-09-26/27 (**correctifs de
> l'interface compacte : Options A/Journal étendus, Screener en 5 cartes,
> « Journal A » renommé « Screener Prime », carte Fondamentaux répliquée
> puis portée en production**). Trois demandes de JP après la première passe
> de gabarits : (1) un bug réel trouvé sur capture d'écran — les listes
> déroulantes coupaient leur texte (30 px de haut, 14 px de zone de texte
> réelle) — corrigé (34 px) en étendant les gabarits à Options A et au
> Journal ; (2) le Screener passe de 2 à 5 cartes, chaque tableau/graphique
> avec son propre bouton « Agrandir », comme Secteurs ; « Journal A » devient
> « Screener Prime » (affichage seulement, la clé `journal_a_tab` ne change
> pas) ; (3) la carte Fondamentaux (EPS, FCF), construite locale uniquement
> le 26/9, répliquée sous « Symbole » dans Secteurs/Screener/Labo, puis
> **portée en production** après que JP a signalé son absence en cloud —
> `cloud/src/lib/fcf-quality.js` (logique identique), route
> `GET /api/fcf/:ticker`, flag `fundamentals_card` (ON par défaut). Vérifié
> avec `wrangler dev --local` (mêmes chiffres qu'en local sur AAPL) puis sur
> la vraie URL (page et route en ligne, pas de compte réel testé). 153/153
> tests. Voir les sections « Interface compacte », « Journal A renommé » et
> « Carte Fondamentaux » plus bas.
>
> Vérification précédente : 2026-09-26 (**interface compacte :
> gabarits de champs et de métriques, chaque élément dans une carte**). JP
> trouvait que les sections prenaient trop de place et ne s'alignaient pas.
> Après validation d'une maquette : composants `.field-grid`, `.metric-band` et
> `.signal-pair`, appliqués à la section Symbole (10 fondamentaux sur une bande),
> au screener de primes et au calculateur « Vendre une option » ; éléments
> flottants rangés dans des cartes (bannière et métriques de la Fiche,
> sous-titres et notes en carte repliable). **Déployé en production**
> (`ed93c9d`, version `14547307`). 153/153 tests. Rendu vérifié par mesure de
> géométrie, pas à l'œil. Voir la section « Interface compacte » plus bas.
>
> Vérification précédente : 2026-09-23 (**Radar : screener
> multi-titres de meilleurs deals d'options, local uniquement**). JP veut
> généraliser le détecteur d'Options A à des centaines de titres. Après un
> travail d'architecture et cinq décisions prises par questions successives
> (fréquence, univers, budget Cloudflare, fenêtre DTE, mode d'exécution,
> portée), le moteur est construit : `server/deal-scanner.js`, onglet « Radar »
> caché derrière le flag `radar_tab`. **Local et non cloud** : le plan gratuit
> Cloudflare (50 sous-requêtes par invocation) rend un scan synchrone
> impossible, et un plan payant ne règlerait pas le rate-limit de Yahoo.
> Deux choix de trader intégrés au moteur : exclusion dure des contrats dont
> l'échéance dépasse les résultats, et plafond par secteur à la présentation.
> **Mesuré : 210 titres en 18 s, 3 erreurs légitimes, aucun 429.** 145/145
> tests. Committé et poussé (`b6744ad`, `02dc964`) ; rien à déployer. Voir la
> section « Radar » plus bas.
>
> Vérification précédente : 2026-09-22, 2e session (**Options A :
> détecteur de « meilleurs deals » — achat vs vente, puts et calls**). Suite
> directe de la session précédente : JP veut identifier dans une chaîne
> d'options les meilleurs achats/ventes de puts/calls, au-delà du volume et
> de la prime seuls — question posée en discussion (« as-tu d'autres
> critères en tête ? »), réponse structurée (liquidité réelle au-delà du
> volume — OI, spread en % de la prime ; cherté relative de l'IV vs
> historique ; rendement par unité de risque ; theta ; et le point central,
> **acheteur et vendeur veulent l'inverse sur la valorisation de l'IV**),
> puis confirmation de construire deux modes séparés.
>
> Nouvelle carte « Meilleurs deals — cette chaîne » dans Options A (flag
> `options_a_tab`), entièrement côté navigateur (`js/options-tab-a.js`,
> aucun nouveau backend ni migration) : sélecteurs Mode (Vente/Achat) et
> Type (Put/Call/Les deux), classe tous les contrats de l'échéance chargée
> via 3 sous-scores TRANSPARENTS ajoutés à `js/options-analytics.js`
> (`optDealLiquidity`/`optDealValuation`/`optDealReturnOrLeverage`/
> `optScoreDeal`) — jamais un score opaque, même discipline que
> `scoreRow()` du screener actions : liquidité (spread bid-ask en % du prix
> médian, OI, volume), valorisation de l'IV vs volatilité historique
> (vendeur cherche `edgePts > 0`, acheteur cherche `edgePts < 0` — jamais
> les mêmes bandes pour les deux modes), et rendement annualisé (vente) ou
> levier `|delta|/prime payée` (achat). Un contrat sans ask exploitable est
> **exclu** du classement, jamais noté à 0.
>
> **Bug réel trouvé en testant sur AMD** (pas en relisant le code) : les
> calls profondément dans la monnaie remontaient en tête avec un
> « rendement annualisé » à **20 000 %** — le calcul utilisait le bid brut,
> qui pour un ITM profond est presque entièrement de la valeur
> **intrinsèque** (le vendeur ne fait que « rendre » une partie du prix de
> l'action), pas une vraie prime de temps. Corrigé en ajoutant
> `optIntrinsicValue`/`optExtrinsicValue` et en calculant le rendement sur
> la valeur **extrinsèque** (bid − intrinsèque) — pour un contrat hors la
> monnaie, extrinsèque = bid, comportement inchangé ; pour un ITM profond,
> le rendement redevient plausible ou affiche honnêtement « — » si la
> valeur temps résiduelle est nulle. Reproduit puis re-vérifié corrigé en
> direct (résultats dominés par des strikes proches du prix après
> correction, plus par des ITM profonds).
>
> 137/137 tests (12 nouveaux, `server/deal-score.test.js`), copies cloud
> synchronisées. **Committé (`6013ede`), poussé et déployé en production**
> le jour même (aucune migration nécessaire — pas de nouveau schéma).
>
> Vérification précédente : 2026-09-22, 1ère session (**Options A / Journal
> A — vente de puts à primes continues, plus des flags par compte**). JP veut
> approfondir la vente de puts (primes continues, style Roue) au-delà de la
> chaîne en lecture seule de l'onglet Options et des strikes ESTIMÉS du
> Labo. 12 idées proposées, réparties en 4 tâches (T1-T4), plan approuvé via
> `EnterPlanMode`/`ExitPlanMode` après 3 décisions confirmées (`AskUserQuestion`) :
> deux flags séparés (`options_a_tab`/`journal_a_tab`, pas un seul combiné),
> screener de primes limité à watchlist/MAG7/listes perso (jamais l'univers
> élargi — 219 titres × un appel de chaîne d'options aurait reproduit le bug
> de sous-requêtes Cloudflare du 12/9/2026), et l'assignation d'un put d'un
> cycle **crée automatiquement** une ligne dans le Journal actions (assignation
> du call couvert du même cycle → la **ferme**, R calculé comme `closeTrade()`).
>
> Livré : **Options A** (`js/options-tab-a.js`) — rendement annualisé et
> capital requis en colonnes, probabilité d'assignation en tooltip sur le
> delta, alerte résultats/dividende (`daysToEarnings`, déjà calculé par
> `getFundamentals()`, ajouté sans appel réseau de plus à `/api/labo/:ticker`),
> grille de rendement sur 6 échéances, calculateur de roulement. **Journal A**
> (`js/journal-a-tab.js`) — screener de primes, calculateur « vendre une
> option », cycles de la Roue, alertes de roulement. **Labo** gagne une carte
> « Revenu de primes réalisé » (données réelles uniquement, aucun rendement
> cible inventé — le Labo n'a pas de paramètre de rendement visé explicite).
> Formules partagées dans `js/options-analytics.js` (annualizedYield/
> capitalRequired/assignmentProbabilityLabel/rollNetCredit + `optionDelta`/
> `optionMarketZone` déménagés depuis `options-tab.js`), même patron à 3
> copies que `labo-schema.js` — y compris une tranche de `strategies-labo.js`
> (laboErf/laboNormCdf) injectée en préambule côté serveur et dans la copie
> cloud générée, `optionDelta` en dépendant. Nouveau schéma
> `option_cycles`/`option_trades` (local + `cloud/schema.sql` + script de
> migration).
>
> **Deux bugs réels trouvés en testant en direct** (local + `wrangler dev`),
> pas en relisant le code : (1) l'assignation d'un put écrivait le nouveau
> statut AVANT de valider le stop initial — un échec de validation laissait
> la position bloquée en `assigne` sans position créée, plus jamais
> réessayable ; corrigé en validant avant toute écriture. (2)
> `/api/options/premium-screener` était capturée par `/api/options/:ticker`
> (même forme de route, Express **et** Hono résolvent par ordre
> d'enregistrement) — même piège que `/api/labo/params` déjà documenté,
> raté une première fois sur cette route précise ; routes réordonnées des
> deux côtés. 125/125 tests, copies cloud synchronisées.
>
> **Puis JP a demandé des flags PAR COMPTE** (« Comptes castellana » de
> bilbao doit pouvoir activer Options A/Journal A pour un testeur précis) —
> nouvelle table `user_feature_flags`, même principe « surcharge ⊕ défaut »
> que `strategy_params` : `getEffectiveFlagsForUser()` (global ⊕ surcharge,
> c'est elle que `/api/flags` renvoie désormais par session) ; routes admin
> `GET /api/admin/user-flags`/`PUT /api/admin/users/:id/flags/:key`
> (`enabled: null` réinitialise — revient au global, jamais un enregistrement
> « hérite » explicite). Côté bilbao : `castellana-users.js` étendu, 2 routes
> `/api/castellana-user-flags`/`/api/castellana-users/:id/flags/:key`
> (auditées), et l'onglet Comptes castellana gagne 2 colonnes avec un menu à
> 3 états (Hérite du global actuel / Forcé activé / Forcé désactivé),
> écriture immédiate au changement. Vérifié de bout en bout : isolation
> confirmée entre deux comptes de test, override qui bat le global dans les
> deux sens, reset qui revient bien à l'héritage, 404/400 sur flag
> inconnu/valeur invalide, **et via bilbao réellement pointé sur un Worker de
> test** (pas seulement `curl` direct sur castellana) — clic réel dans l'UI
> qui change la session castellana correspondante.
>
> **Déployé en production le jour même** : deux migrations `--remote`
> (`migrate-option-trades.mjs`, `migrate-user-flags.mjs`, chacune vérifiée
> par `sqlite_master` après coup, jamais sur le seul message de fin) puis
> deux `wrangler deploy` (routes existantes revérifiées sans 500 après
> chacun). Commits `ea3c408`/`3adf420` (trading-assistant),
> `f620882` (feature-factory) — poussés directement sur `main`, pas de PR
> cette fois. **Les deux flags restent OFF par défaut pour tout le monde** —
> rien ne change pour les testeurs tant que JP n'active rien depuis bilbao.
> Un process bilbao orphelin (tournant depuis la veille, tenant le port 4600
> avec l'ancien code) a dû être identifié (`ps`) et arrêté avant de pouvoir
> relancer avec le nouveau — **un test de vérification en direct a laissé
> une entrée honnête dans le vrai journal d'audit local de bilbao**
> (`flag_utilisateur_castellana`, contre un Worker de test, pas la
> production) — signalée à JP plutôt que supprimée (altérer un journal
> d'audit a semblé pire que d'y laisser une trace véridique d'un test). Voir
> la section « Options A / Journal A » plus bas pour le détail complet.
>
> Vérification précédente : 2026-09-21, 3e session (**Screener :
> graphique de performance des titres retenus — réutilise l'idée du graphique
> sectoriel**). Construit sur une branche dédiée (`feature/screener-performance-
> chart`), fusionnée puis déployée le jour même. Placé juste au-dessus de
> « Filtres supplémentaires », généré automatiquement après « Lancer le
> screening » (pas de bouton séparé), pour n'importe quel univers (watchlist,
> MAG7, univers élargi, liste personnalisée). Titres retenus (déjà classés
> Setup puis Contexte), plafonnés à 20 (note si tronqué) + S&P 500 en repère.
> Backend : `GET /api/screening/history?tickers=...` (local et cloud,
> `parseTickersParam()` testée) — relit surtout le cache déjà rempli par le
> screening lui-même (même clé que le calcul des indicateurs), peu d'appels
> Yahoo en plus. **Refactor** : le moteur de dessin du graphique sectoriel
> (SVG, légende, survol) extrait en fonctions génériques (`renderPerfChart`/
> `renderPerfLegend`/`attachPerfHover`), réutilisées par les deux graphiques —
> évite une troisième copie de ~150 lignes ; non-régression vérifiée sur le
> graphique des secteurs. `cloud/public/index.html` mis à jour par patch exact
> du diff (11 hunks, sans conflit). Vérifié en local et sur le Worker cloud
> (compte de test) : troncature watchlist, MAG7 sans troncature, période,
> survol, agrandissement, changement d'univers. 111/111 tests (6 nouveaux).
> [trading-assistant#1](https://github.com/iechocreator-po/trading-assistant/pull/1),
> fusionnée (`9db1bbe`) et déployée (version `ef274314`).
>
> Vérification précédente : 2026-09-21, 2e session (**README réécrit et
> journal de bord publié en artifact**). `README.md` remis à jour : six onglets (dont
> Options), deux modes (local / cloud avec comptes et « Connexion facile par courriel »),
> architecture (Worker Hono + D1, telemetry-worker, bilbao), organisation du dépôt, limites.
> Les affirmations périmées (« pas de compte », « trois écrans », « 20 titres ») sont retirées.
> Trace de la session des 20-21/9/2026 : artifact privé « Journal de bord castellana »
> (https://claude.ai/artifact/PABBZTJHEHDFVe24ck4VdM) — livraisons, 8 déploiements de Worker,
> leçons, points ouverts ; aucun secret ni IP de testeur.
>
> Vérification précédente : 2026-09-21 (**télémétrie : suppression par adresse
> IP depuis bilbao**). `telemetry-worker` : nouveau scope `ip` de `POST /delete` (champ `ip`
> requis, refusé sans) et `/summary` expose `ips` = `[{ip, n, who}]` sur TOUTE la base (pas
> seulement la période) pour le menu de bilbao. Bilbao : choix « Par adresse IP » + menu
> déroulant (adresse — nb d'événements · testeurs), confirmation nommant l'adresse, audit.
> Vérifié sur base D1 locale jetable (1 IP supprimée, l'autre intacte, 400 sans `ip`) et
> l'interface avec données simulées. Worker redéployé le 21/9/2026.
>
> Vérification précédente : 2026-09-20, 11e session (**boutons à effet dans
> le design system ; « Agrandir » sur la chaîne d'options ; feature bilbao #368**). Trois
> nouvelles classes dans `design-system/components.css` : `.ds-btn--shine` (reflet),
> `--pulse` (halo), `--orbit` (bordure qui tourne), plus `--sm` (compact) ; jour/nuit
> (texte sombre sur l'accent en mode nuit, `--ds-btn-on`), animations coupées avec
> `prefers-reduced-motion`. Dans castellana : « Récupérer en direct » (`js/ticker-section.js`,
> 4 onglets) et les deux « Actualiser » (carte Secteurs, en-tête en `--sm`) passent en **Éclat** ;
> les 4 « ⤢ Agrandir » en **Pulsation** ; Orbite non utilisée pour l'instant. Copies vendorées
> mises à jour (`design-system/` et `cloud/public/design-system/`, identiques au partagé). La
> chaîne d'options gagne son bouton « Agrandir » (`openTableOverlay('opt-results-content', …)`).
> ⚠️ Les AUTRES produits qui vendorent `components.css` ont maintenant une copie en retard
> (détecteur de dérive de bilbao). Principe du design system : un effet qui bouge partout ne
> signale plus rien — à utiliser avec parcimonie. Déployé le 20/9/2026.
>
> Vérification précédente : 2026-09-20, 10e session (**onglet Options :
> filtres optionnels, chaîne complète par défaut**). JP a vu « Aucun contrat ne passe les
> filtres » en production (non reproduit en local ; cause probable : plage ±20 % par défaut
> appliquée à un prix absent/nul) et a demandé que plage de strikes, OI minimum et volume
> minimum soient des filtres SUR LES DONNÉES, pas une sélection en amont. Désormais : champs
> vides au départ = filtre inactif (`null`), bloc repliable « Filtres sur les données (N actifs) »
> au-dessus du tableau, bouton « Réinitialiser » ; `optionsStrikeBounds()` ignore la plage si le
> prix n'est pas > 0 ; message vide explicite (« Aucun des N strikes… » ou « Yahoo n'a renvoyé
> aucun contrat… »). L'export CSV suit les mêmes filtres. 105/105 tests. Déployé le 20/9/2026.
>
> Vérification précédente : 2026-09-20, 9e session (**feature #358 v3 :
> export CSV des chaînes d'options — la feature est complète**). Bouton « Exporter CSV »
> (`downloadOptionsCSV`, `js/options-tab.js`) : une ligne par contrat AFFICHÉ (mêmes filtres
> que le tableau), colonnes type/échéance/DTE/strike/bid/ask/dernier/volume/OI/IV/delta
> estimé/ITM/symbole ; valeur absente = cellule VIDE (jamais 0) ; IV et delta arrondis à
> 4 décimales ; virgule et point décimal comme les autres exports. Fonctions pures
> `optionsCsvRows`/`optionsToCSV` testées. Vérifié sur AMD (22 contrats pour ±5 %, contrats
> cotés). 103/103 tests. Feature #358 marquée `Livre` dans bilbao. Déployé le 20/9/2026.
>
> Vérification précédente : 2026-09-20, 8e session (**feature #358 v2 :
> delta estimé + comparaison Labo vs marché ; bouton de connexion par courriel plus
> visible**). Onglet Options : colonne « Δ est. » = delta Black-Scholes calculé avec
> l'IV de chaque contrat (`optionDelta`, `js/options-tab.js`) ; **null si l'IV est sous
> 1 %, si l'échéance est du jour ou si une entrée manque** (jamais un delta inventé).
> Carte « Repères de la Roue : Labo vs marché » : pour la plage de delta de la Roue
> (`laboEffectiveParams('roue', …)`, réglable dans le Labo), strikes du marché (delta
> issu de l'IV) contre l'estimation du Labo (volatilité historique via `/api/labo/:ticker`),
> avec avertissement si l'échéance affichée est hors de la fenêtre DTE de la Roue. Constat
> sur AMD : vol. historique 69 % contre IV ≈ 50 % → put 500–510 (marché) vs 458–496 (Labo).
> Login cloud : « ✉️ Connexion facile par courriel » (ex. « Ou reçois un lien de connexion »),
> bouton contouré en couleur d'accent. 102/102 tests (4 nouveaux, `server/options-tab.test.js`).
> Feature #358 reste `Idee` (v3 export CSV). Déployé le 20/9/2026.
>
> Vérification précédente : 2026-09-20, 7e session (**feature #358 v1 :
> onglet Options — chaîne d'options d'un titre, lecture seule**). Yahoo direct
> (`yahooFinance.options()`), `server/options.js` + `cloud/src/lib/options.js`,
> route `GET /api/options/:ticker?expiry=`, cache 2 min (`TTL.OPTIONS`, clé
> `options:v1:`). UI `js/options-tab.js` (copie dans `cloud/public/js/`, couverte
> par le test de parité) : tableau miroir Calls | Strike | Puts, ligne ATM encadrée,
> ITM teinté, filtres (plage de strikes, OI, volume, contrats cotés). Différé ~15 min ;
> **bid = ask = 0 → « — »** (jamais un zéro) ; **pas de delta** (Yahoo ne le donne
> pas — v2 : Black-Scholes du Labo à partir de l'IV). `options` ajouté à `NEEDS_CRUMB`
> (`cloud/src/lib/yahoo.js`) : la pause de 45 s après un 429 s'y applique. Vérifié sur
> AMD (navigateur + Worker en local) ; 98/98 tests. La fiche #358 reste `Idee`
> (v2 delta + lien Labo, v3 export CSV à faire). Déployé le 20/9/2026.
>
> Vérification précédente : 2026-09-20, 6e session (**bilbao :
> télémétrie triable/supprimable par ligne, graphique par type, aperçu live des
> Concepts, flags cloud dans la Console ; faux événements « louis » expliqués et
> purgés ; feature 358 cadrée**). (1) `telemetry-worker` : `/summary` expose
> `dailyByType` (`GROUP BY jour, event_type`) — **redéployé** (version
> 1c13633f). (2) Les 23 événements `louis` (ids 246-344, tous depuis l'IP de JP)
> venaient de **nos tests manuels de la version cloud en local** : `cloud/public/
> config.js` pointe vers la télémétrie de PRODUCTION. Ce n'étaient PAS les tests
> automatisés (`npm test` = fonctions pures). Correctif : `isDevHost()` dans
> `cloud/public/js/telemetry.js` coupe l'envoi sur localhost/127.0.0.1 (l'app
> locale des testeurs, `js/telemetry.js`, n'est pas touchée). Événements purgés
> via le scope `ids`. (3) **Feature #358** (chaînes d'options) : approche Yahoo
> `options()` retenue (testée sur AMD : 20 échéances, ~55 calls/puts, bid/ask/IV/
> volume/OI, **pas de delta** → Black-Scholes du Labo), différée 15 min, risque
> 429 Yahoo sur Cloudflare ; découpage v1 tableau / v2 delta+lien Labo / v3 CSV.
> Rien construit côté castellana. Voir `feature-factory/CLAUDE.md`, 20/9/2026.
>
> Vérification précédente : 2026-09-20, 5e session (**roadmap
> réconcilié dans bilbao, et onglet TradingView dans Réglages**). JP demande
> ce que signifie archiver une session et veut s'assurer que l'essentiel est
> conservé au roadmap. Vérifié contre `features.json` : le travail des 19-20/9
> (features 359 à 365) était tracé, mais **quatre éléments livrés les 18-19/9
> ne l'étaient pas** — console des comptes castellana dans bilbao, magic link,
> télémétrie triable/filtrable/supprimable, ticker par défaut retiré. Ajoutés
> en une seule feature **#366** (`Livre`, date de livraison 19/9), avec les deux
> restes à faire dans sa description. La piste **connexion TradingView non
> persistante** devient une feature séparée, **#367** (`Idee`). Voir « Onglet
> TradingView dans Réglages » plus bas. **Déployé : non** — l'onglet n'est
> visible qu'en local tant que `wrangler deploy` n'est pas lancé.
>
> Vérification précédente : 2026-09-20, 4e session (**diagnostic
> du bandeau « temporisation dépassée (6000 ms) » sur la version cloud**). Cause
> trouvée par mesure sur le réseau de Cloudflare : un bug de l'application (instance
> Yahoo partagée entre requêtes), aggravé par une limite côté Yahoo (429 sur le jeton
> « crumb »). Correctif déployé et **confirmé en production** (statut vert vérifié par JP le
> 20/9/2026 à 9 h 48). Voir « Yahoo depuis Cloudflare » plus bas.
>
> Vérification précédente : 2026-09-20, 3e session (**Fiche de
> trade : prix d'entrée sans valeur par défaut, clôture de la veille après
> « Récupérer en direct »**). Le champ portait `value="180"` : un chiffre inventé,
> indiscernable d'un vrai prix, qui alimentait stop et cibles. Voir « Prix d'entrée
> de la Fiche » plus bas. **Déployé en production le 20/9/2026** avec
> l'uniformisation de la section « Symbole ».
>
> Vérification précédente : 2026-09-20, 2e session (**section
> « Symbole » uniformisée dans tous les onglets**). Suite de la question T0 de
> Louis : après inventaire (Secteurs/Screener = gabarit unique ; Fiche, Labo et
> Journal = présentations propres), JP a demandé « uniformise partout ». Décisions
> (`AskUserQuestion`) : le Journal garde un simple champ standardisé ; Fiche et
> Labo reçoivent la section complète, doublons retirés. Voir « Section Symbole
> uniformisée » plus bas.
>
> Vérification précédente : 2026-09-20 (**onglet Concepts
> derrière un feature flag, éditable par l'administrateur depuis bilbao, sans
> images**). Quatre demandes de JP sur Réglages → Concepts : (T0) feature flag
> `concepts_tab`, **défaut OFF** ; (T1) l'administrateur modifie titres et
> textes de chaque fiche ; (T2) photos supprimées ; (T3) le bandeau d'origine
> des images remplacé par un crédit à dtrading.net. Décisions de JP : flag en
> base cloud basculé depuis bilbao, édition dans bilbao, champ HTML brut. Même
> session, un correctif Yahoo : le test de connectivité passe à **2 tentatives**
> (un ralentissement ponctuel allumait le bandeau rouge). Détail dans la section
> « Onglet Concepts — feature flag et édition » plus bas. Même jour, deux
> retours de Louis traités : les deux cases de volume du Labo (T1) et l'onglet
> bilbao « Watchlists » ; T0 (la section « Symbole » est-elle la même partout ?)
> répondu : non, voir « Retours de Louis » plus bas. **Déployé en production
> le 20/9/2026.**
>
> Vérification précédente : 2026-09-19, 2e session (**onglet
> Labo : chaque valeur de chaque stratégie d'options devient éditable,
> persistée par utilisateur, exportable — et visible dans bilbao**). JP,
> après une session de travail : « la valeur 30-45 jours doit être
> paramétrable », pour chaque valeur, pour chaque stratégie, avec reset
> (une ou toutes), persistance par utilisateur ET au-delà (bilbao, pour
> revoir/partager), export, et une future création de stratégies à
> considérer sans la construire. Plan approuvé (`EnterPlanMode`), décisions
> de JP : **cloud + local** (même API) et bilbao en **vue live + archivage**.
> Détail dans la section « Paramètres des stratégies d'options » plus bas.
> **Non déployé** : rien n'a été poussé en production (migration D1
> distante `cloud/scripts/migrate-labo-params.mjs --remote` à lancer AVANT
> `wrangler deploy`). 87/87 tests (69 avant) + 17/17 côté cloud.
>
> Vérification précédente : 2026-09-19 (**console CRUD des
> comptes castellana dans bilbao + connexion par magic link — l'évolution
> "sécurité du login" de la session précédente, implémentée**). Suite
> directe de la réflexion du 18/9 sur le mot de passe partagé et le spike
> TradingView : JP a demandé (1) une console dans bilbao pour gérer les
> comptes castellana sans repasser par `create-user.mjs`, et (2) le magic
> link évoqué comme alternative. Décisions prises avant de coder
> (`AskUserQuestion`) : le magic link **s'ajoute** au mot de passe, ne le
> remplace pas ; **Resend** choisi comme service d'envoi (aucun en place,
> API REST simple en `fetch`, zéro dépendance ajoutée).
>
> **Suppression = désactivation, jamais un DELETE dur** —
> `trades`/`watchlist`/`preferences` référencent `users(id)` sans
> `ON DELETE CASCADE`, et **D1 applique réellement la contrainte** (confirmé
> en le heurtant pendant les tests : une suppression a échoué tant que les
> lignes dépendantes n'étaient pas effacées à la main). Un compte
> "désactivé" (`users.disabled`) ne peut plus se connecter (mot de passe NI
> magic link, même message générique que "mot de passe incorrect" — pas de
> fuite sur l'existence d'un compte bloqué) mais garde toutes ses données.
>
> **Côté `cloud/`** : migration idempotente
> (`scripts/migrate-users-email-magiclinks.mjs`, même patron `PRAGMA
> table_info` que `server/db.js` — testée deux fois en local, rejouable
> sans erreur) ajoutant `email`/`disabled` à `users` et la table
> `magic_links` (token à usage unique, 15 min). Nouvelle API
> d'administration (`routes/admin.js`) protégée par un Basic Auth **distinct**
> de celui de `telemetry-worker` (`ADMIN_USER`/`ADMIN_PASSWORD`, nouveau
> secret Wrangler) — lister/créer/modifier/désactiver/réactiver/
> réinitialiser, jamais le hash/sel de mot de passe exposé. Magic link
> (`routes/auth.js`, `db/magic-links.js`, `lib/email.js`) : réponse
> **toujours identique** à la demande, qu'un compte corresponde ou non
> (anti-énumération, même discipline que le login) ; écran de connexion
> enrichi d'un second formulaire ("Ou reçois un lien de connexion").
>
> **Côté `feature-factory/` (bilbao)** : `server/castellana-users.js`,
> copie conforme du patron déjà établi par `telemetry.js` (identifiants
> vérifiés à l'appel, jamais à l'import) — **deuxième service Cloudflare**
> que bilbao appelle pour de vrai. Nouvel onglet **« Comptes castellana »**
> (7ᵉ onglet, même structure exacte que Télémétrie) : tableau + création +
> modification + désactivation/réactivation + réinitialisation, mot de
> passe temporaire affiché **une seule fois**, chaque mutation auditée
> (`logAudit`).
>
> **Vérifié en direct, de bout en bout** (D1 local jetable, `.dev.vars`/`.env`
> temporaires créés puis retirés — `.env` de bilbao restauré à l'identique
> après coup) : API d'administration testée par `curl` (validations, 401,
> désactivation qui bloque bien une connexion existante) ; magic link testé
> dans le navigateur, token réel généré/consommé, session ouverte, URL
> nettoyée du token usage-unique ; console bilbao testée dans le navigateur
> (création avec mot de passe temporaire affiché, désactivation,
> modification), aucune erreur console, chaque mutation confirmée dans
> `GET /api/audit`. 69/69 + 17/17 tests, aucune régression. **Aucune donnée
> réelle de production touchée** — comptes de test créés puis nettoyés.
>
> **Mise en production complétée le même jour, avec JP.** Secrets Wrangler
> créés (`ADMIN_USER`/`ADMIN_PASSWORD` générés aléatoirement, `.env` de
> bilbao complété) ; **bug réel trouvé au premier déploiement** : le code
> avait été poussé (`wrangler deploy`) sans avoir migré la vraie base D1
> distante (seulement testée en local) — `/api/auth/magic-link/request`
> répondait `500 no such column: email`. Corrigé en lançant la migration en
> `--remote` (idempotente, déjà testée deux fois localement) — **aucune
> donnée réelle perdue**, les 4 comptes (jp/louis/guillaume/luc) intacts.
> **Compte Resend créé** (via GitHub OAuth) — **incident évité de justesse** :
> JP a collé sa première clé API en clair dans le chat en copiant une sortie
> de terminal ; traitée comme compromise, révoquée et régénérée avant tout
> usage, refaite via `npx wrangler secret put RESEND_API_KEY` (saisie
> interactive, jamais transmise). Clé créée en portée **Sending access**
> seulement (pas Full access — le code n'a besoin que d'envoyer, jamais de
> gérer domaines/autres clés). **Domaine `iecho.ca` vérifié** dans Resend le
> jour même via l'intégration Cloudflare de Resend (autorisation en un
> clic, DNS déjà sur les serveurs Cloudflare — 3 enregistrements ajoutés
> automatiquement, propagation quasi instantanée) : `RESEND_FROM` passé de
> `onboarding@resend.dev` (limité à l'adresse du compte Resend) à
> `castellana@iecho.ca`, `wrangler deploy` — **vérifié en direct via
> `wrangler tail`** qu'un envoi vers une adresse externe (pas celle de JP)
> passe sans erreur. Le magic link fonctionne désormais pour n'importe quel
> testeur, pas seulement JP. Voir aussi `feature-factory/CLAUDE.md`,
> 19/9/2026, pour la carte d'aide ajoutée dans l'onglet « Comptes
> castellana » (clarifie que « Réinitialiser » et le magic link sont deux
> mécanismes indépendants — ni l'un ni l'autre n'envoie quoi que ce soit
> automatiquement à la création d'un compte).
>
> **Deux ajouts le même jour, demandés par JP en utilisant la console** :
> colonne **« Dernière connexion »** dans le tableau de bilbao —
> `cloud/src/db/users.js` (`listUsers()`) dérive ça de `MAX(sessions.
> created_at)` par utilisateur plutôt que d'ajouter une colonne (mot de
> passe et magic link créent tous deux une session à la connexion,
> `auth.js`, donc c'est une vraie « dernière connexion réussie », pas juste
> « dernière tentative ») — `null`/« Jamais » distinct d'une vraie date,
> jamais confondu. Carte d'aide de bilbao complétée pour préciser que le
> courriel de magic link contient un lien direct vers l'URL de castellana.
> Vérifié en direct sur les vraies données de production (dates réelles de
> jp/louis/guillaume/luc, `null` correct pour un compte jamais connecté),
> 69/69 + 17/17 tests.
>
> Vérification précédente : 2026-09-18 (**télémétrie : tri,
> filtre et suppression du tableau des événements ; ticker par défaut
> retiré ; spike de faisabilité OAuth pour une connexion TradingView non
> persistante**). Trois volets dans la même session, partis d'une réflexion
> sur la sécurité du login castellana et sur le nouveau connecteur MCP
> officiel de TradingView que JP a ajouté à Claude.
>
> **T1 — télémétrie, tri/filtre/suppression** : `telemetry-worker/src/
> index.js`, tableau « Derniers événements » de `/dashboard`. Ajoutés, tout
> côté client (≤200 lignes déjà chargées, aucun aller-retour serveur) :
> en-têtes cliquables triables (asc/desc, numérique sur `id`, chronologique/
> alphabétique ailleurs), un champ de filtre par colonne (sous-chaîne, ET
> logique entre colonnes), une case à cocher par ligne + « tout
> sélectionner » et un bouton « Supprimer la sélection ». Côté serveur,
> `POST /delete` gagne un 4ᵉ scope, `ids` (1 à 200 entiers positifs,
> `id IN (SELECT value FROM json_each(?))` — même pattern déjà établi pour
> la limite de paramètres liés D1, voir `cloud/src/db/cache.js`) — les
> scopes `all`/`who`/`range` existants n'ont pas changé. La suppression
> réutilise le Basic Auth déjà entré pour `/dashboard` (même origine/
> royaume), rechargement de la page après succès. **Vérifié en direct**
> contre une base D1 locale jetable (`wrangler dev --local`, `.dev.vars`
> créé puis supprimé, même discipline que les sessions précédentes) : tri
> sur `id`/`qui`, filtre sur `id`, suppression réelle d'une ligne de test
> (`{"ok":true,"deleted":1}`), validation refusée sur `ids` vide/non
> entier/>200, 401 sans identifiants, et **non-régression confirmée** sur
> `who`/`range`/`all` (dont le refus de `all` sans `confirm:true`). Portée
> volontairement limitée à `telemetry-worker` — l'onglet Télémétrie de
> bilbao (qui appelle déjà `/summary`+`/delete`) n'expose pas encore ce
> scope, resterait à faire côté `feature-factory` si JP le souhaite.
>
> **T2 — ticker par défaut retiré** : `CFG.defauts.ticker` (`config.js` et
> `cloud/public/config.js`, identiques) passe de `'AMD'` à `''` — un titre
> présélectionné n'avait de sens pour personne en particulier. Placeholder
> « ex. AAPL » ajouté aux 3 champs concernés (`#ticker`, et le template
> partagé `js/ticker-section.js`/`cloud/public/js/ticker-section.js` pour
> `sec-ticker`/`scr-ticker`) pour qu'un champ vide se lise comme un choix,
> pas un bug — même discipline que la bannière de verdict du 11/9/2026.
> `CFG.labo.defaultTicker` (TQQQ) non touché. **Vérifié en direct dans le
> navigateur** (app locale) : les 3 champs vides avec placeholder, bannière
> en état neutre au chargement (« rien à évaluer »), Labo toujours sur
> TQQQ, aucune erreur console — `calcSelectionFor()`/`evaluateSelection()`
> géraient déjà un ticker vide (badges « Non renseigné » du 11/9/2026),
> aucun autre changement de logique nécessaire. 69/69 + 17/17 tests.
>
> **Connexion TradingView non persistante — spike de faisabilité, pas de
> build cette session**. JP a ajouté le nouveau connecteur MCP officiel de
> TradingView à Claude ; testé en lecture seule (`list_watchlists`), il
> renvoie ses vraies watchlists personnelles — donc bien son compte réel.
> Doc officielle lue (tradingview.com/mcp/docs) : OAuth 2.1 réel, un seul
> point d'entrée public (`https://mcp.tradingview.com/mcp`, « one URL for
> every client ») — pas réservé à Claude/ChatGPT. Spike isolé (script hors
> du dépôt applicatif, jamais commité, jamais rien écrit sur disque) avec
> `@modelcontextprotocol/sdk` (déjà utilisé côté `server/tradingview.js`
> pour le sidecar local) : découverte des métadonnées OAuth réussie,
> **enregistrement dynamique du client réussi** (TradingView délivre un
> `client_id` à la volée, sans inscription manuelle préalable), URL
> d'autorisation PKCE valide générée (`code_challenge`/`resource`
> conformes). Arrêté volontairement à cette étape — la suite exige le vrai
> login TradingView de JP, jamais tenté à sa place. **Conclusion : une
> intégration « Connecter TradingView » dans castellana est réellement
> construisible** (castellana deviendrait lui-même un client MCP face au
> serveur officiel), pas un contournement — reste à concevoir dans une
> session dédiée (bouton dans Réglages → Compte, callback OAuth, jeton
> attaché à la session serveur existante — jamais à `users` —, effacé à la
> déconnexion/expiration, jamais persisté au repos).
>
> **Sécurité du login/télémétrie — décision prise, pas encore exécutée par
> JP**. Constat : `js/telemetry.js` (`getWho()`) utilise déjà
> `window.CASTELLANA_USERNAME` (l'identité de session réelle, posée par
> `bootApp()` côté cloud) en priorité sur le sélecteur auto-déclaré —
> l'architecture cloud est déjà correcte. La vraie faille est que
> jp/louis/guillaume/luc partagent tous le mot de passe « tomate ». Aucun
> changement de code : JP doit exécuter lui-même, à sa convenance (le
> script demande une saisie interactive, jamais un mot de passe en
> argument de commande) `node cloud/scripts/create-user.mjs <nom> --remote`
> pour chacun des 4 comptes, avec un mot de passe distinct par personne.
>
> Vérification précédente : 2026-09-13, 2e session
> (**intégration du tableau de bord de télémétrie dans bilbao, feature
> #356 — avec suppression de données**). `telemetry-worker` gagne deux
> routes, protégées par le même Basic Auth que `/dashboard` (session
> précédente, le jour même) : `GET /summary` (les mêmes 4 requêtes que le
> dashboard HTML, en JSON) et `POST /delete`, **destructeur sur de vraies
> données de production** — trois portées explicites (`who`, `range`,
> `all`), aucune par défaut ; `all` refusé sans `confirm:true` explicite,
> compte les lignes avant de les supprimer plutôt qu'un succès muet. Côté
> `feature-factory` (bilbao) : nouveau `server/telemetry.js` (même
> discipline que `github.js` — identifiants vérifiés à l'appel, jamais à
> l'import, bilbao fonctionne sans `.env`), 6ᵉ onglet « Télémétrie » qui
> reproduit les vues du dashboard public avec ses propres composants
> (jamais une iframe vers l'URL publique — l'intégration n'aurait aucun
> sens sinon), et une carte de suppression avec confirmation JS avant
> chaque appel. **Première fois que bilbao parle pour de vrai à un
> service Cloudflare déployé** — jusqu'ici son seul contact était le
> monitoring passif R9 (sonde GET/timeout, jamais d'appel authentifié ni
> de mutation) ; la suppression est auditée dans le journal bilbao
> (`logAudit`) comme toute mutation cross-service. Testé en local avec
> `wrangler dev --local` (D1 simulée) avant tout branchement à bilbao, puis
> bilbao lui-même testé contre ce Worker local (statut/résumé/suppression
> via l'UI réelle, état « non configuré » sans `.env`) — **zéro donnée de
> production réelle touchée par ces tests**. **`telemetry-worker` déployé en
> production par JP juste après** (`wrangler deploy`) — vérifié en direct
> sur la vraie URL : `/summary` et `/delete` répondent 401 sans identifiants
> (même garde que `/dashboard`), `/version` et l'ingestion `POST /events`
> inchangés. Reste à JP : créer/vérifier son `.env` local dans
> `feature-factory/` (mêmes identifiants que les secrets Wrangler du
> Worker) pour que l'onglet Télémétrie de bilbao s'active. Détail complet
> dans `feature-factory/CLAUDE.md`, 13/9/2026.
>
> Vérification précédente : 2026-09-13, 1ère session (**vraie
> authentification sur le tableau de bord de télémétrie**). `/dashboard` et
> `/events.csv` (telemetry-worker) n'étaient protégés que par
> `TELEMETRY_TOKEN` — un jeton documenté comme « pas une vraie sécurité »,
> visible dans le code source public de castellana. JP a demandé un vrai
> user/mot de passe. Ajouté : HTTP Basic Auth (`checkBasicAuth()`,
> `telemetry-worker/src/index.js`) sur ces deux routes de CONSULTATION
> seulement — `POST /events` (l'ingestion, appelée par castellana
> lui-même) garde son jeton partagé, un vrai login y est structurellement
> impossible. Identifiants (`jp`/`tomate`, même mot de passe que les
> comptes castellana) en **secrets Wrangler** (`wrangler secret put`),
> jamais commités — testés localement via un `.dev.vars` créé puis
> supprimé (`.dev.vars` ajouté au `.gitignore` racine au passage, absent
> jusqu'ici). Vérifié en direct sur la vraie production : sans
> identifiants → 401, mauvais mot de passe → 401, bons identifiants → 200
> sur les deux routes, **l'ancien lien `?token=...` ne fonctionne plus**
> (401, confirmé volontairement), et l'ingestion castellana continue de
> fonctionner sans changement. README mis à jour.
>
> Vérification précédente : 2026-09-12, 3e session (**listes
> personnalisées dans le Screener — CRUD complet, plus un vrai bug de
> télémétrie trouvé et corrigé au passage**). Après avoir vu une maquette
> visuelle du concept (pilules à côté de « Ma watchlist »/« Univers
> élargi »/« MAG7 »), JP a donné son feu vert pour construire : créer/
> renommer/supprimer des listes nommées, y ajouter/retirer des titres,
> screener dessus comme n'importe quel autre univers. Nouvelles tables
> `custom_lists`/`custom_list_tickers` (locales dans `server/db.js` — sans
> `user_id`, l'app locale reste mono-utilisateur ; D1 dans
> `cloud/schema.sql` — avec `user_id`, isolées par testeur comme
> `watchlist`/`preferences`). `server/lists.js`/`cloud/src/db/lists.js`
> (même API, portée D1 async côté cloud), nouvelles routes
> `/api/lists[/:id[/tickers[/:ticker]]]` dans les deux versions. Univers
> `list:<id>` **dynamique** ajouté à `screening.js` (local et cloud) via
> une nouvelle fonction `isValidUniverse()` — `UNIVERS.includes(...)` seul
> ne peut pas valider un id imprévisible. **Plafond de 50 titres/liste,
> appliqué côté serveur** (pas seulement dans l'UI) : après le bug de
> sous-requêtes Cloudflare de la session précédente (univers élargi, 219
> titres), une liste custom sans limite aurait pu recréer le même problème
> — le plafond l'empêche par construction, identique en local et en cloud.
>
> **Télémétrie** : JP a demandé de « garder une trace des listes des
> gens » — nouvel `event_type` `list_saved` (état courant de la liste,
> pas des deltas) envoyé à chaque mutation confirmée. **Bug réel trouvé en
> testant, pas en relisant le code** : le collecteur de télémétrie
> (`telemetry-worker/src/index.js`) rejette tout `event_type` absent d'une
> liste blanche (`KNOWN_EVENT_TYPES`) — figée au 6/9/2026, elle ne
> contenait ni `list_saved` (nouveau) ni **`error`**, ajouté le 7/9/2026
> pour `trackError()` et donc **muet depuis sa création** : chaque
> événement d'erreur envoyé par un testeur a été silencieusement rejeté
> (400, absorbé par le `catch` fire-and-forget de `sendTelemetryEvent`,
> jamais vu par personne) pendant cinq jours. Corrigé en ajoutant les deux
> à la liste blanche.
>
> Vérifié en direct : local (CRUD complet — créer, ajouter/retirer des
> titres, screener sur la liste, renommer, supprimer ; plafond de 50
> confirmé avec 51 tentatives réelles, la 51e refusée avec message clair)
> et cloud en local (`wrangler dev` + D1 local, mêmes vérifications, **plus
> l'isolation confirmée entre `jp` et `louis`** — la liste de l'un est
> invisible à l'autre), **69/69 + 17/17 tests**. `cloud/public/index.html`
> resynchronisé par patch du diff, fusionné à la main au seul point de
> conflit (l'appel d'init `loadCustomLists()`, décalé d'indentation à
> l'intérieur de `bootApp()` côté cloud). **Déployé en production après
> confirmation de JP** — schéma D1 réel appliqué (9 tables), castellana et
> telemetry-worker redéployés, vérifié en direct sur les deux vraies URL :
> création/ajout de titre/screening d'une liste custom (puis nettoyée) sur
> castellana, et `list_saved`/`error` acceptés (200, testés puis retirés de
> la base) sur le collecteur de télémétrie. **Compte `luc` ajouté** (mot de
> passe `tomate`, même que les autres testeurs) — local et distant, via
> `scripts/create-user.mjs` (upsert depuis le 12/9/2026).
>
> Vérification précédente : 2026-09-12, 2e session (**dix
> retouches, dont un vrai bug cloud trouvé et corrigé — « univers élargi »
> retournait 0 résultat en production**). JP a testé la version cloud
> déployée et signalé 10 points (T1-T10). **T6, le plus important** :
> lancer le screening sur l'univers élargi (219 titres) répondait
> « 0 retenu(s) sur 218 balayé(s)) » — reproduit en direct contre la vraie
> URL de production (`curl` authentifié), cause exacte confirmée dans
> `passErrors` : **"Too many subrequests by single Worker invocation"**, le
> plafond Cloudflare Workers. Chaque titre appelait `cached()` (lecture D1 +
> appel Yahoo + écriture D1) individuellement — jusqu'à ~1100 sous-requêtes
> pour un screening élargi à cache froid, alors que le patron local
> (better-sqlite3) ne coûte aucune sous-requête pour lire/écrire le cache.
> Corrigé par une refonte du cache D1 dans les trois modules qui balaient
> tout l'univers (`indicators.js`, `quotes.js`, `fundamentals.js`) :
> `readCacheMany()`/`writeCacheMany()` (nouveau, `cache.js`) groupent la
> lecture et l'écriture de N clés en 1 sous-requête chacune au lieu de N.
> **Bug trouvé EN TESTANT ce correctif, pas en le relisant** : un premier
> jet en `WHERE key IN (?,?,?...)` échouait sur D1 dès ~270 clés
> ("too many SQL variables") — corrigé avec `json_each()`, qui passe les
> clés comme un seul paramètre JSON plutôt qu'un `?` par clé. L'appel Yahoo
> par titre absent du cache reste incompressible (aucune API multi-symboles
> pour l'historique) — un compteur `subrequestLimitCount` est désormais
> exposé et affiché en bandeau si la limite est quand même atteinte, pour
> ne plus jamais laisser un « 0 retenu » faire croire à un problème de
> logique.
>
> **Vérifié en vraie production après déploiement, pas seulement en local**
> — et le résultat est plus nuancé qu'« entièrement corrigé » :
> immédiatement après le déploiement, un premier `force=true` sur cache
> **entièrement froid** (jamais peuplé pour l'univers élargi sur cette
> base D1 réelle) a quand même atteint la limite —
> `subrequestLimitCount: 171` sur 218, `retainedSize: 0`. C'est le
> plafond réel de la plateforme (vraisemblablement le plan Workers
> **Gratuit**, 50 sous-requêtes — la refonte a ramené les 219 titres tout
> près de 1 sous-requête chacun, donc ~50 passent avant que la limite ne
> coupe le reste). Ce que la refonte change : **4 relances successives**
> (« Forcer », ~5-10 s chacune) ont suffi à réchauffer le cache
> d'historique (TTL 15 min) jusqu'à disparition complète du problème —
> `171 → 124 → 77 → 30 → 0`, `retainedSize` remontant en parallèle
> `0 → 2 → 4 → 15 → 19`, résultat final identique à la version locale. Sans
> la refonte, ce réchauffement progressif aurait été impossible (chaque
> tentative aurait dû repartir de zéro, une lecture/écriture D1 par titre
> en plus des appels Yahoo). **À savoir pour la suite** : un cache
> entièrement froid (juste après un déploiement, ou après 15 min
> d'inactivité sur l'univers élargi) demandera encore quelques clics sur
> « Forcer » avant de donner un résultat complet — le bandeau
> `subrequestLimitCount` le dit maintenant explicitement, mais ce n'est pas
> un aller simple. Une amélioration possible mais non construite ici : un
> Cron Trigger qui réchaufferait le cache en tâche de fond, hors du budget
> de sous-requêtes d'une requête utilisateur — à envisager si ce
> réchauffement manuel reste gênant à l'usage réel.
>
> **Les neuf autres retouches (T1-T5, T7-T10)** : encadré
> explicatif Variation/Contexte/Setup/Signal au-dessus des deux tableaux qui
> les partagent (Screener, Titres les plus performants du secteur) ; ordre
> des colonnes Contexte/Setup inversé ; colonne Verdict retirée des deux
> tableaux (jugée redondante avec Setup) ; en-têtes de colonne cliquables
> pour trier (mécanisme générique, un seul `initSortableHeaders()` pour les
> deux tableaux) ; Extension Fibonacci validée — la formule correspond au
> document de design (127.2/161.8/261.8 % au-delà du haut du swing), le
> chiffre « trop haut » signalé par JP vient très probablement de
> `swinglow`/`swinghigh`, deux champs **saisis à la main sans repli auto**,
> pas d'un bug de calcul ; bouton « Récupérer en direct » de la Fiche de
> trade déplacé de la carte « Climat de marché » vers la carte « Le titre »
> (à côté du Symbole, même patron que les autres onglets) et renommé (il
> alimentait déjà VIX/RSI/ATR/OBV/l'alignement/la bannière — vérifié
> inchangé) ; cases à cocher barrées au clic sur chaque étape des séquences
> du Labo (toutes les stratégies, pas seulement La Roue — même fonction de
> rendu) ; en-tête « Performance » de la carte sectorielle renommé
> « Performance (jour) ». Vérifié en direct : local (Browser pane +
> `curl`), cloud en local (`wrangler dev` + D1 local, ré-authentifié,
> 218 balayés/19 retenus après le correctif — cohérent avec le résultat
> local), **69/69 + 17/17 tests**, aucune erreur console à aucune étape.
> `cloud/public/index.html` resynchronisé par un patch du diff structurel
> root↔cloud (fusionné à la main au seul endroit où le patch entrait en
> conflit avec les nouvelles lignes de ce tour — la séquence de démarrage
> `bootApp()`). **Déployé en production** après confirmation de JP.
>
> Vérification précédente : 2026-09-12, 1ère session (**six retouches
> d'utilisabilité, déployées en production — MAG7, Agrandir sur les
> tableaux, largeur des champs, Golden Cross normalisé, Symbole en tête de
> la Fiche de trade**). Six demandes de JP après avoir utilisé la version
> cloud déployée la veille. **T1** : bouton « Agrandir » (overlay plein
> écran, même patron que le graphique sectoriel) ajouté aux tableaux
> « Titres les plus performants du secteur » et « Screening — univers de
> titres » — mécanisme généralisé (`openTableOverlay(blockId, anchorId,
> title)`/`closeTableOverlay()`, un seul `#table-overlay`) plutôt que
> recopié deux fois, et surtout **pas fusionné** dans le `#chart-overlay`
> déjà testé du graphique (qui garde sa propre logique de viewBox). **T2/T4**
> (même cause) : `.row .ds-input` était en `flex:1`, donc un champ numérique
> (SMA50, VIX, ATR…) s'étirait jusqu'au bord de la carte à côté d'un
> libellé qui tient sur une ligne — corrigé en `flex: 0 1 180px` (les
> `<select>` gardent `flex:1`, certaines options ont besoin de place).
> **T3** : les trois textes d'état du Golden Cross (« Golden cross établi… »,
> minuscule, formulation différente de l'en-tête « Golden Cross (régime de
> fond) ») sont normalisés pour reprendre le même terme capitalisé et le
> même mot que leur badge (« Golden Cross confirmé/naissant/absent »).
> **T4 (suite)** : la carte « Le titre » est remontée tout en haut de
> l'onglet Fiche de trade, avant la checklist — JP veut déclarer QUEL titre
> il évalue avant tout le reste, qui en dépend. **T5** : univers **MAG7**
> ajouté au sélecteur du Screener (Apple/Microsoft/Alphabet/Amazon/Nvidia/
> Meta/Tesla, liste fixe de 7 titres, toutes les lignes affichées comme
> pour la watchlist) — **pas** encore une vraie gestion de plusieurs listes
> personnalisées, notée comme feature future. **T6** : question de JP sur
> Setup/Contexte/Signal, répondue en texte (déjà documentés en tooltip dans
> le tableau, voir section « Screener générateur de positions » plus bas) —
> aucun changement de code. **Répercuté dans `cloud/public/index.html`** via
> un patch du diff exact (`git apply` sur une copie, vérifié : contenu
> propre au cloud — écran de connexion, panneau Compte — intact), et
> **`cloud/src/lib/screening.js` mis à jour en miroir** pour MAG7. Vérifié
> en direct : local (Browser pane, capture d'écran des overlays/carte
> Symbole/Fiche de trade, `curl` sur `/api/screening?universe=mag7` → 7
> titres), cloud en local (`wrangler dev` + D1 local, connexion réelle,
> mêmes vérifications), **69/69 tests** (`server/`) et **17/17** (`cloud/`)
> verts, aucune erreur console à aucune étape. **Déployé en production**
> (confirmation de JP demandée avant `wrangler deploy`, un classificateur
> avait bloqué la première tentative) — vérifié après coup sur la vraie
> URL : `/index.html` sert le nouveau HTML, connexion `jp`/tomate → 200,
> `GET /api/screening?universe=mag7` → 7 titres réels.
>
> **Bug T1 signalé par JP et corrigé le même jour** : fermer l'overlay
> « Agrandir » d'un des deux nouveaux tableaux repositionnait le contenu
> **hors** de sa carte (juste devant elle) au lieu de l'y remettre. Cause :
> le nœud ancre (`#sector-top-anchor`/`#screening-anchor`) avait été posé
> **devant** la `.ds-card`, alors que le contenu déplacé
> (`#sector-top-content`/`#screening-content`) vit **dedans** —
> `closeTableOverlay()` réinsère toujours juste après l'ancre, donc le
> contenu ressortait à côté de la carte, pas à l'intérieur. Le graphique
> sectoriel (`#sector-chart-anchor`), lui, n'a jamais eu ce bug : son ancre
> est correctement à l'intérieur de sa carte. Corrigé en déplaçant les deux
> ancres à l'intérieur de leur carte respective, juste avant le contenu
> qu'elles repèrent — même patron que le graphique. Reproduit puis
> re-vérifié dans le navigateur (secteur Services publics, onglet
> Screener) : le contenu revient bien À L'INTÉRIEUR de la carte après
> fermeture (`content.closest('.ds-card').contains(content)` confirmé
> `true`). Répercuté dans `cloud/public/index.html`, 69/69 tests,
> **redéployé en production** (cette fois sans blocage du classificateur).
>
> Vérification précédente : 2026-09-11, 4e session (**portage
> Cloudflare Workers + D1, multi-utilisateur — construit et vérifié en local,
> pas encore déployé**). JP veut « vraiment pouvoir déployer castellana sur
> Cloudflare et que ce soit utilisable ». Avant de planifier quoi que ce
> soit, un spike réel a levé le plus gros risque technique déjà documenté le
> 6/9/2026 (« Express persistant + better-sqlite3 natif + sidecar Python,
> tous incompatibles avec le modèle Workers ») : `yahoo-finance2` — le cœur
> de tout le backend — **fonctionne réellement dans un Worker**
> (`nodejs_compat`, `quote()`/`chart()`/requête groupée testés avec de
> vraies données via `wrangler dev --local`). Deux décisions de JP
> (`AskUserQuestion`) ont fixé la portée : **multi-utilisateur** (JP + les
> testeurs Louis/Guillaume, chacun avec SON propre journal/watchlist/
> préférences, pas une instance partagée) et **cloud seulement** à terme —
> l'app locale (launcher, installateurs, sidecar, mise à jour en un clic)
> cesse d'être la version de référence, même si elle n'est pas supprimée
> tant que la version cloud n'est pas confirmée en ligne. Nouveau dossier
> **`cloud/`** (Worker autonome, comme `telemetry-worker/` juste à côté) :
> **Hono** pour le routage (écart assumé au zéro-dépendance de
> `telemetry-worker/`, justifié par 27 routes à paramètres contre 4 routes
> plates), **Cloudflare D1** à la place de better-sqlite3 (schéma étendu
> avec `users`/`sessions`, `trades`/`watchlist`/`preferences` isolés par
> `user_id`, `cache`/`alerts` restés globaux), et une **vraie authentification
> serveur** (PBKDF2 via Web Crypto, session en base) — recherche faite avant
> de coder : aucun des deux mots de passe déjà utilisés dans le portfolio
> (barcelona/porto) n'offre de vérification serveur, tous deux explicitement
> documentés comme un simple écran côté client. `server/update.js` et le
> client du sidecar `server/tradingview.js` ne sont **pas** portés (aucun
> équivalent Workers, et déjà optionnels/désactivés par défaut depuis le
> 7/9/2026). **Vérifié de bout en bout en local** (`wrangler dev` + D1
> local, aucun compte Cloudflare requis pour cette étape) : schéma appliqué,
> 2 comptes créés (`scripts/create-user.mjs`), connexion/déconnexion/mot de
> passe erroné, isolation confirmée entre comptes (le journal et la
> watchlist de l'un sont invisibles à l'autre), écran de connexion réel dans
> le navigateur, les 5 onglets avec de vraies données Yahoo Finance,
> screening exécuté via l'UI, secret du webhook TradingView vérifié.
> **Reste à JP** : créer la vraie base D1, connecter le Worker à son compte
> Cloudflare, choisir les mots de passe de Louis/Guillaume, confirmer que
> la version cloud lui convient avant qu'on retire l'infrastructure locale.
> Voir la section « Portage Cloudflare Workers + D1 » plus bas.
>
> Vérification précédente : 2026-09-11, 3e session (**« Performance
> des secteurs » dépasse les 11 secteurs GICS — analyse de marché élargie**).
> JP veut situer un titre/secteur par rapport à de grands indices régionaux et
> au dollar US, pas seulement aux 11 ETF GICS. Deux changements structurants
> et six nouvelles lignes de graphique. **Le sélecteur « Devise des ETF
> sectoriels (USD ou CAD) » devient « ETF référence US vs ETF Équivalent
> TSX »** — un choix de PLACE DE COTATION plutôt que de devise ; en interne,
> le `mode` `'usd'`/`'cad'` déjà consommé par le tableau ET le graphique n'a
> pas changé, seul le libellé et son rôle conceptuel sont reformulés. **Six
> nouvelles séries sélectionnables au graphique** (cases à cocher, filtre
> côté client sur l'historique déjà chargé — aucun refetch) : DXY,
> Monde hors USA, Europe, Japon, Marchés émergents, Chine — chacune traitée
> comme une ligne de plus sur le même graphique (performance cumulée en %),
> **pas** un coefficient de corrélation calculé (clarifié avec JP avant de
> coder, `AskUserQuestion`). **Deux tickers fournis par JP ne résolvaient PAS
> sur Yahoo Finance**, vérifié en direct avant intégration (même geste que
> ZXRE.TO → ZRE.TO le 2/9/2026) : Europe CAD `FIE` → **`VE.TO`**, Japon CAD
> `XJP.TO` → **`ZJPN.TO`**. Pour les catégories à deux tickers US au choix, le
> plus liquide (volume moyen 3 mois) a été retenu : VXUS>ACWX, VGK>EZU,
> EEM>VWO, FXI>MCHI. DXY et Chine n'ont **aucun** équivalent TSX (vérifié,
> pas supposé) — la ligne US reste affichée en mode TSX, marquée
> explicitement « (US — pas d'équivalent TSX) » (légende, tooltip, étiquette
> de fin de ligne) plutôt que masquée ou faussement présentée comme
> canadienne. **Bouton « Agrandir »** (overlay plein écran, même patron que
> `#settings-overlay`) — l'app entière est limitée à 900px (`.container`),
> donc le graphique l'était aussi peu importe la taille d'écran ; le bloc
> `#sector-chart-block` est **déplacé** (pas dupliqué) vers l'overlay au clic,
> replacé à l'identique (Échap ou ✕) sans perte d'état (catégories, période,
> lignes masquées via la légende). Mesuré : historique à 18 tickers (11
> secteurs + SPY + 6 indices, contre 12 avant) en **~0,4 s à froid**, aucun
> ralentissement notable. **69 tests** (65 avant), 4 nouveaux sur
> `resolveMarketTicker()` — seule fonction pure du nouveau code, le reste
> (réseau Yahoo) vérifié en direct comme le reste de `sectors.js`. Vérifié en
> direct dans le navigateur : catégories cochées/décochées sans requête
> réseau, bascule US/TSX qui recharge tableau ET graphique, thème clair et
> sombre. Voir la section « Analyse de marché élargie » plus bas.
>
> Vérification précédente : 2026-09-11, 2e session (**la bannière
> de verdict déménage, les valeurs de démonstration disparaissent, et le
> tableau sectoriel adopte les colonnes du screening**). Trois demandes de
> JP, plus deux correctifs qu'il a validés après une question sur le
> fonctionnement de la bannière ambre de l'onglet Secteurs. **Le défaut le
> plus important a été trouvé en répondant à cette question, pas en
> codant** : les quatre champs de la carte « Ticker » portaient des valeurs
> de démonstration en dur (12 / 8 / 182 / 170), si bien qu'au chargement
> l'app affichait un verdict complet et crédible — « Golden Cross positif »
> — calculé sur des chiffres fictifs, sous un ticker bien réel. Corrigé :
> champs vides, badges « Non renseigné », et un quatrième état de bannière,
> neutre, qui dit qu'il n'y a rien à évaluer. La bannière elle-même passe du
> haut de l'onglet Secteurs (au-dessus de « Performance des secteurs », où
> sa place laissait croire qu'elle résumait les secteurs) à la **tête de la
> carte « Ticker » des trois onglets** qui portent un titre. Enfin, la carte
> « Titres les plus performants du secteur » porte désormais **les mêmes
> colonnes que le tableau de screening** — obtenu en faisant passer les
> candidats du secteur par le pipeline de screening plutôt qu'en recopiant
> la vingtaine de champs, ce qui aurait créé une troisième duplication
> documentée dans ce projet. Mesuré : **20 titres d'un secteur en 2,3 s**,
> en-têtes vérifiés identiques par comparaison programmatique, filtre
> cap/volume recalculé à la main (16 → 12 sur Matériaux, 4 exclus tous sur
> le volume). **65 tests toujours verts**, aucune erreur console. Voir la
> section « Bannière de verdict et tableau sectoriel » plus bas.
>
> Vérification précédente : 2026-09-11 (**le screener devient un
> générateur de positions**). Question de JP : « comment améliorer l'outil de
> screening pour qu'il génère des positions potentielles intéressantes ? »
> Trois défauts trouvés et MESURÉS avant d'écrire du code : (1) `scoreRow()`
> notait RSI, Force relative, Golden Cross et OBV — mais **pas l'alignement
> des moyennes**, LE signal d'entrée du design doc, calculé par
> `indicators.js` puis jeté avant le scoring ; l'app écrit pourtant
> elle-même que « Golden Cross et Force relative servent à choisir le titre,
> pas à valider l'entrée » ; (2) le score mesurait un ÉTAT là où la
> stratégie demande un ÉVÉNEMENT (« déclenché une seule fois au premier
> alignement ») ; (3) l'univers de 22 titres ne donnait que **2 setups ce
> jour-là**, alors que **210 titres curés dormaient déjà dans
> `SECTOR_TOP_CANDIDATES`**, utilisés uniquement pour l'affichage « top du
> secteur ». Livré en 4 phases : deux axes de score (Setup / Contexte) avec
> âge du signal, sizing extrait et partagé avec garde-fou de charge par
> candidat, univers élargi en deux temps, capture du raisonnement dans le
> journal. Mesuré : **219 titres balayés en 4,9 s**, 18 retenus, 10 « prêt »,
> répartis sur 7 secteurs — et **18 appels de fondamentaux au lieu de 219**,
> preuve que le filtrage précède l'enrichissement. **65 tests** (40 avant),
> dont les tout premiers sur le calcul de sizing. Voir la section « Screener
> générateur de positions » plus bas.
>
> Vérification précédente : 2026-09-07, 2e session (**refonte
> de fiabilité et d'installation, à partir d'un audit**). JP veut mettre
> castellana « dans les mains de personnes sérieuses ». Point de départ : un
> audit fonctionnel et technique mené sur l'instance en marche (8 constats,
> F1→F8), dont le constat structurant était que **le sidecar Python ne
> fournit rien que l'app ne puisse recalculer depuis l'historique Yahoo
> qu'elle télécharge déjà**. Revérifié moi-même avant de coder, puis sur les
> 21 titres de la watchlist : **zéro écart** au-delà de l'arrondi sur les 19
> titres que le sidecar sait traiter, et les 2 qu'il ne résolvait pas du tout
> (PLTR, XEQT.TO) sont désormais couverts. Décision de JP : le sidecar n'est
> pas supprimé mais **rendu optionnel et désactivé par défaut**. Résultats
> mesurés : screening **37 s → 1,99 s** (0,37 s cache de données chaud,
> 0,02 s cache de screening), **21/21 titres complets** contre 18/21,
> installation **223 Mo → 53 Mo** et **2 prérequis → 1** (Python sort du
> chemin par défaut), **32 tests** contre 7. **Deux recommandations de
> l'audit corrigées en les mesurant** : `node:sqlite` n'existe pas sur le
> Node 22.12 de JP (il faut `--experimental-sqlite`) donc `better-sqlite3`
> est conservé ; et un cache long (12-24 h) aurait figé des prix
> intrajournaliers, donc les TTL sont courts. Voir la section « Refonte de
> fiabilité » plus bas pour le détail complet.
>
> Vérification précédente : 2026-09-07 (**tableau de bord de
> télémétrie enrichi**). JP a demandé de pouvoir « récupérer la télémétrie
> et en faire un dashboard » — plutôt qu'un nouvel outil séparé ou un
> Artifact Claude (**écarté** : le pare-feu réseau des Artifacts bloque
> tout `fetch()` vers un hôte externe comme le Worker de télémétrie),
> décision d'enrichir directement la route `/dashboard` déjà déployée
> (`telemetry-worker/src/index.js`) — accès direct à D1, déjà protégée par
> le même jeton. Ajouté : activité par jour (barres verticales, SVG à la
> main, skill `dataviz` du portfolio consultée), tickers les plus
> sélectionnés (barres horizontales classées, `json_extract` sur le
> payload), filtre par testeur + plage de jours (7/30/90), info-bulle au
> survol. **Découverte en testant** : la base contenait déjà de la vraie
> télémétrie (JP avait utilisé castellana après le déploiement précédent)
> — le nettoyage post-test a dû cibler précisément les lignes de test
> ajoutées cette session (`WHERE id >= 9`) pour préserver ces 7 événements
> réels, plutôt qu'un nettoyage global qui les aurait détruits. Vérifié en
> direct dans le navigateur (filtre, info-bulles, état vide). Voir section
> « Télémétrie testeurs » plus bas pour le détail complet. **Même session,
> séparation des stratégies Labo** : « La Roue & Debit Spreads » (une seule
> entrée depuis le 5/9/2026) devient deux entrées distinctes, `roue` et
> `debit-spreads` — pur réarrangement du contenu existant, aucun nouveau
> calcul. Voir section « Séparation La Roue / Debit Spreads » plus bas.
>
> Vérification précédente : 2026-09-06 (**télémétrie testeurs**).
> JP prépare la mise dans les mains de 2 testeurs (chacun lance castellana en
> local, comme lui — décidé après avoir vérifié que l'app entière ne peut PAS
> aller sur Cloudflare telle quelle : Express persistant + `better-sqlite3`
> natif + sidecar Python, incompatibles avec le modèle Workers). Un nouveau
> Cloudflare Worker + D1 (`telemetry-worker/`, **premier composant de
> castellana jamais déployé publiquement** — mais seulement ce collecteur,
> pas l'app) capture 3 événements envoyés directement par le navigateur de
> chaque testeur (`app_loaded`, `ticker_selected`, `param_changed`) — qui,
> quand, quel ticker, quel paramètre changé (ancienne/nouvelle valeur). Pas
> un vrai login (T3 reporté) — juste un sélecteur de nom + l'IP capturée
> côté Worker. `server/index.js` non touché. Détail complet dans la section
> « Télémétrie testeurs » plus bas. **Worker déployé le 6/9/2026** —
> https://castellana-telemetry.iechocreator.workers.dev, testé en direct
> (événement de test inséré puis retiré, jeton invalide bien rejeté en 401,
> `/dashboard` et `/events.csv` vérifiés). **Même session, ajout d'un
> bouton « Partager une idée »** — popup repris tel quel du popup public
> iecho.ca (`FeedbackWidget.astro`), même formulaire Formspree (les idées
> des deux produits atterrissent dans la même boîte de réception), seule
> différence : « Produit concerné » est pré-sélectionné sur `castellana` au
> lieu de vide. **Nouvel onglet « Concepts » dans Réglages** — guide de 15
> concepts de trading transcrit d'un fichier `madrid`
> (`investment-dashboard/indicateur/GUIDE_15_CONCEPTS_TRADING.md`, texte +
> 15 images copiés, aucun lien dynamique entre les deux repos). Voir
> sections dédiées plus bas.
>
> Vérification précédente : 2026-09-05 (**nouvel onglet Labo —
> stratégies d'options**). 5 onglets désormais (Secteurs/Screener/Fiche de
> trade/Journal/**Labo**). Le Labo laisse choisir une stratégie d'options
> (sélecteur), saisir un ticker, et affiche la séquence pas-à-pas à suivre
> pour l'appliquer, avec des données réelles du titre (prix, ATR, beta,
> volume — `GET /api/labo/:ticker`, Yahoo Finance direct, indépendant du
> sidecar tradingview-mcp et de son rate-limit). Deux stratégies
> implémentées, deux marquées « bientôt disponible » (Iron Condor, Credit
> Spreads) plutôt que masquées — même discipline que le hub essen
> (« ne jamais pousser un lien avant que le contenu réponde »). **Écart
> réel trouvé et clarifié avant de coder** : le fichier fourni par JP,
> `strategy/PoorManCoveredCall.md.rtf`, ne décrit PAS la stratégie Poor
> Man's Covered Call (LEAPS call + call court vendu contre) malgré son nom
> — il décrit un système différent, « La Roue & Debit Spreads » (Cash-
> Secured Put → Covered Call, puis Bull Call/Bear Put Spread). Signalé à JP
> avant d'implémenter (`AskUserQuestion`) : décision de garder les deux,
> distinctes, dans le sélecteur — le contenu réel du fichier sous son
> propre nom, et une vraie PMCC selon la définition standard, écrite sans
> dépendre du fichier. **Aucune donnée d'options réelle (chaîne, delta,
> prime) n'est branchée dans cette app** — les « zones de strike » de la
> séquence sont une estimation ATR autour du prix, explicitement étiquetée
> comme telle partout où elle apparaît (disclaimer dédié + note par étape),
> jamais présentée comme une vraie donnée de marché. Détail complet dans la
> section dédiée plus bas.
>
> Vérification précédente : 2026-09-02 (**secteurs USD/CAD,
> nouvel onglet Screener, top titres par secteur** — 4 onglets désormais
> (Secteurs/Screener/Fiche de trade/Journal), sélecteur de devise sur la
> carte Performance des secteurs (USD/CAD, tickers BMO vérifiés en direct),
> clic sur un secteur affiche ses titres les plus performants (liste
> curatée par secteur, pas un scan de marché — l'endpoint screener
> personnalisé de Yahoo Finance s'est révélé bloqué en test réel pour un
> usage anonyme, 429 systématique sur un endpoint probablement réservé aux
> comptes connectés, non contourné conformément au principe déjà en place
> dans ce fichier sur les vrais anti-bots). Le mode CAD "couvert contre le
> risque de change" envisagé en cadrage a été abandonné en cours de route :
> vérifié en direct qu'aucun des 11 ETF sectoriels BMO n'a de version
> couverte listée sur Yahoo. Détail complet dans la section dédiée plus
> bas.)
>
> Vérification précédente : 2026-08-31
> **Statut :** cadrage initial — document de design consolidé, design system
> vendoré, les deux prototypes fusionnés en une seule app à onglets
> (`index.html`), fichier de réglages (`config.js`) créé, repo GitHub créé et
> poussé, produit ajouté au `CLAUDE.md` racine (table sommaire, fiche
> détaillée, mapping code→dossier). Stack backend tranchée et **scaffoldée**
> (Node Express + better-sqlite3, `http://127.0.0.1:4700/`) ; `tradingview-mcp`
> **branché** (sidecar Python) — fiable pour VIX/RSI/Golden Cross/force
> relative. **Frontend câblé sur les données temps réel** (boutons
> « Récupérer en direct » + tableau de screening 20 titres, testés en
> direct). **Rate-limit non documenté confirmé à deux reprises** sur
> `coin_analysis` (RSI/Golden Cross) — l'app reste utilisable en dégradé
> grâce à la résilience par source. **Tous les calculs maison livrés**
> (`server/indicators.js` : OBV réel, SMA 9/21/100, ATR réel, volume vs
> moyenne 20j — historique Yahoo Finance direct via `yahoo-finance2`,
> indépendant de `coin_analysis`) — score du screening à 4 colonnes
> complètes, Fiche de trade entièrement câblée sur les données en direct.
> **Témoin de statut backend** (header, 3 indicateurs : Express/
> tradingview-mcp/calculs maison, auto-actualisé) ajouté. **P/E ratio,
> industrie et P/E moyen de l'industrie ajoutés au tableau de screening**, et
> **carte « Performance des secteurs »** (tableau + line graph interactif
> 11 secteurs/S&P 500, période 1 semaine à 12 mois) ajoutée au-dessus du
> screening (29/8/2026, demandes de JP). **Terminologie et calcul du filtre
> de tendance corrigés (29/8/2026)** : c'était une SMMA (moyenne lissée/RMA)
> présentée tantôt comme « SMMA » tantôt comme « MM » selon l'écran — JP a
> demandé une vraie SMA (Simple Moving Average) partout, code et texte ;
> fait, `computeSMA()` en fenêtre glissante remplace `computeSMMA()` pour le
> filtre 9/21/100 (l'ATR garde son propre lissage RMA, correct par
> définition, renommé `computeRMA()` pour ne plus prêter à confusion).
> **Menu Réglages plein écran** (⚙, même principe que essen/
> nemesis-retaliation) remplace l'ancien bloc d'aide replié. **Bug réel
> trouvé et corrigé** : `fetchJSON()` ignorait silencieusement les options
> `POST`/`PUT` depuis le début — `addWatchlist()` et la clôture d'un trade
> (`closeTrade()`) ne faisaient donc jamais ce qu'ils semblaient faire.
> **`README.md`/`SETUP.md` réécrits pour un tiers (30/8/2026)** — un
> collègue de JP, ajouté comme collaborateur GitHub, n'arrivait pas à
> lancer le projet ; l'ancien `README.md` ne contenait que des commandes
> macOS non expliquées. Au passage, un vrai bug Windows trouvé et corrigé :
> le script `npm run sidecar` codait en dur un chemin Unix
> (`.venv-mcp/bin/...`), impossible à trouver sur un venv créé côté Windows
> (`.venv-mcp\Scripts\...`) — remplacé par `scripts/run-sidecar.mjs`
> (détection de `process.platform`, zéro dépendance ajoutée). Voir section
> « Documentation d'installation pour un tiers » plus bas. **Corrigé côté
> code et testé sur macOS ; pas testé sur une vraie machine Windows.**
> **Statut technique désormais explicite (30/8/2026)** : un point rouge
> dans le témoin de statut affiche maintenant la vraie cause en clair
> (ex. « Sidecar non démarré ou injoignable sur http://127.0.0.1:4701/mcp »)
> au lieu d'un simple point rouge muet — demande directe de JP après avoir
> vu une pastille rouge sans explication. **PEG moyen ajouté à la carte
> Performance des secteurs** — approximation par pairs de watchlist (Yahoo
> n'expose aucun PEG au niveau ETF/secteur), couverture partielle assumée
> et affichée honnêtement (7 des 11 secteurs n'ont aucun titre suivi dans
> la watchlist actuelle, donc « — »). **Disclaimer bilingue FR/EN** ajouté
> en haut de page (même patron que marbella). **Confirmé à JP** : aucun
> compte TradingView n'est nécessaire, à aucune étape — documenté
> explicitement dans `README.md`/`SETUP.md`.
> **Trois pistes d'amélioration planifiées et livrées (31/8/2026)** :
> watchlist élargie à **XEQT.TO** (repère diversifié, PAS un comblement des
> trous sectoriels — RSI/Golden Cross indisponibles pour ce titre via
> tradingview-mcp, limite documentée) ; **édition d'un trade existant**
> dans le journal (bouton Modifier, réutilise le PUT déjà existant) + **export
> CSV du journal** ; **tests automatisés** (`node:test` natif, 7 tests sur
> `server/indicators.js`, `npm test`). Ajoutées au roadmap bilbao (features
> #345-347, statut `Planifie`) avant implémentation. Reste à construire :
> les feature flags (en attente d'une session bilbao — voir Checklist
> portfolio en bas de fichier), les trous sectoriels du P/E industrie/PEG
> moyen avec de vrais titres individuels (pas scopé, JP n'a demandé que
> XEQT).

## Démarrage de session — features en attente

Décision portfolio (R24, 2026-07-20) : **bilbao** (`../feature-factory/`) est
l'**unique source de vérité** des features/roadmap de ce produit — pas de
roadmap locale (la section « Feuille de route suggérée » plus bas n'est qu'un
résumé d'orientation, pas la liste vivante). **À chaque nouvelle session sur
castellana, commencer par présenter la liste des features/idées/questions dont
le statut n'est ni `Livre` ni `Rejete`**, lue directement dans l'export JSON
(pas besoin que bilbao tourne) :

```bash
python3 -c "
import json
d = json.load(open('../feature-factory/data/castellana/features.json'))
for f in d['features']:
    if f['statut'] not in ('Livre', 'Rejete'):
        print(f['id'], f['statut'], f['votes'], f['titre'])
"
```

Pour marquer une feature complétée, en ajouter une nouvelle, ou assembler une
release note, passer par l'API de bilbao (`npm start` dans
`feature-factory/`, 127.0.0.1:4600) — jamais éditer `features.json` /
`releases.json` à la main (artefacts possédés par bilbao, régénérés à chaque
mutation, toute édition manuelle serait écrasée).

## Pourquoi

JP est un investisseur autodirigé (Québec, comptes REER/non-enregistré/
corporatif) pratiquant le swing trading à haute fréquence (250-570
transactions/mois observées, principalement tech/IA : MSFT, META, GOOG,
AMZN, AMD, ADBE, PYPL, RDDT, JD, SMCI, ASML, CRWV). Problèmes observés :
timing de screening peu fiable, pas de mécanisme systématique de
sizing/stop-loss, aucun suivi de la valeur ajoutée réelle des indicateurs
utilisés, saisie manuelle des données de marché.

**Contrainte de compte non négociable** : le REER ne permet aucune déduction
de perte en capital (contrairement au non-enregistré) — l'outil doit
toujours savoir dans quel compte un trade est logé, pour toute logique de
sizing, de journal ou de statistiques.

**Distinct du projet « La Roue »** (simulateur Wheel options, = **barcelona**
`learning-finance/`) — contextes et code base à garder séparés, aucune
dépendance entre les deux.

## Objectif — trois briques

1. **Écran de sélection de titres** — décide quels titres suivre activement.
2. **Fiche de trade** — calcule sizing, stop, cible à chaque entrée.
3. **Automatisation & suivi** — données de marché en direct, journal de
   trades, statistiques post-trade (l'indicateur X a-t-il réellement aidé ?).

## Document de référence

[`design_assistant_swing_trading.md`](design_assistant_swing_trading.md)
contient le détail complet déjà validé avec JP : formules de sizing, code
Pine Script de l'alerte TradingView, bandes de couleur par indicateur,
schéma de données du journal. Ce `CLAUDE.md` n'en est qu'un résumé
d'orientation — se référer au document de design pour les valeurs exactes,
ne pas les redupliquer/dériver ici de mémoire.

## Application — [`index.html`](index.html) (écrans fusionnés, à onglets)

Décision prise (22/7/2026, JP) : **pas deux écrans séparés à naviguer
manuellement — un seul parcours à onglets.** `index.html` (racine du
dossier) est désormais l'app réelle. Charge `config.js` (voir section
Nouvelles exigences → Configurabilité) avant sa propre logique, et consomme
la copie vendorée de `design-system/tokens.css`/`components.css` via les
composants `.ds-card`/`.ds-badge`/`.ds-metric`/`.ds-input`/`.ds-select`.

**5 onglets depuis le 5/9/2026** (voir sections dédiées plus bas pour le
détail complet) : **Secteurs** (`#tab-secteurs`, ex-« Écran de sélection »,
recentré sur les secteurs) → **Screener** (`#tab-screener`) → **Fiche de
trade** → **Journal & stats** → **Labo** (`#tab-labo`, nouvel onglet —
stratégies d'options, indépendant du parcours actions ci-dessus). Les cartes Ticker / Force
relative vs indice / Golden Cross existent en DEUX exemplaires
**indépendants** (un par onglet Secteurs et Screener, IDs préfixés
`sec-`/`scr-`, logique partagée via `calcSelectionFor(instanceKey)`/
`fetchLiveSelectionFor(instanceKey)` plutôt que dupliquée) — un pointeur
`lastTickerInstance` retient laquelle des deux a été utilisée en dernier,
c'est elle qui alimente la Fiche de trade au changement d'onglet.

**Hors onglets, visibles en permanence dans le header** (22-23/7/2026) :
- **Témoin de statut backend** (3 pastilles : Backend Express / tradingview-mcp
  / calculs maison) — `GET /api/status`, auto-actualisé toutes les 30s +
  bouton manuel. Voir section « Calculs maison » plus bas pour le détail.
- **Menu Réglages** (bouton ⚙, overlay plein écran — remplace depuis le
  29/8/2026 l'ancien `<details>` d'aide replié dans le flux de la page,
  demande de JP de reprendre le principe du menu Réglages de essen/
  nemesis-retaliation, voir `SettingsPage.tsx` de ce jeu). Commandes de
  relance backend/sidecar et dépannage, contenu recopié de la section
  « Lancer l'application » ci-dessous (à garder synchronisé si cette section
  change).

**Import multi-titres de l'écran de sélection** (tableau, score composite,
top 20 — design doc section 5) : **fait** (22/7/2026, voir section
« Screening 20 titres » plus bas) ; l'onglet single-ticker reste
disponible en dessous du tableau pour l'analyse détaillée d'un titre.

Les deux prototypes HTML d'origine sont conservés tels quels, à titre de
référence historique, dans [`prototypes/`](prototypes/)
(`fiche_trade_sizing_stop.html`, `ecran_selection_titres.html`) — **ne plus
les éditer**, `index.html` est la seule source de vérité du comportement de
l'app désormais.

## Logique métier à préserver (déjà validée avec JP)

Résumé — détail complet et non-négociable dans le document de design :

- **Filtre de tendance** : SMA 9/21/**50** (ne pas remplacer par EMA
  50/100/200 — révisé 29/8/2026, était une SMMA/RMA lissée ; moyenne lente
  passée de 100 à 50 le 7/9/2026, feature 351). **Réellement paramétrable
  depuis le 7/9/2026** : les périodes vivent dans `server/preferences.js`,
  s'éditent dans Réglages → Valeur personnalisée et pilotent le calcul sur
  tous les écrans — ce n'était auparavant qu'un libellé. Signal au premier
  alignement haussier uniquement, sortie sous SMA21. Alerte TradingView Pine
  Script v5 fournie et à jour (9/21/50) — **à reproduire à la main dans
  l'alerte réelle sur TradingView**.
- **Checklist pré-trade** (gate obligatoire, 6 items) avant tout engagement.
- **Indicateurs retenus** : VIX, RSI(14), OBV, force relative vs indice,
  Golden Cross — bandes vert/amber/rouge décidées avec JP. **Ne pas ajouter
  MACD ni Stochastic RSI** (redondance déjà écartée avec JP, RSI seul comme
  momentum).
- **Sizing** : distance du stop = ATR(14) × multiplicateur ; risque de base
  (défaut 1%) réduit par des discounts multiplicatifs cumulatifs
  (corrélation, VIX, RSI>70, OBV distribution) ; alerte si charge de
  portefeuille agrégée > 6%.
- **Type d'ordre** selon liquidité du titre (3 paliers).
- **Objectifs** : R-multiples et extensions Fibonacci affichés côte à côte.

## Nouvelles exigences (cadrage 22/7/2026)

- **Serveur MCP TradingView — décidé (22/7/2026)** : adoption de
  [`tradingview-mcp`](https://github.com/atilaahmettaner/tradingview-mcp)
  (projet tiers open source, MIT, non affilié à TradingView) pour
  VIX/RSI/ATR/Volume/Golden Cross. **Ne couvre pas tout** — OBV réel et
  SMA 9/21/100 restent à calculer maison. Détail complet (mapping des
  indicateurs, limites, intégration au backend) dans la section
  « Intégration données de marché — tradingview-mcp » ci-dessous.
- **Intuitivité + pédagogie** : chaque indicateur affiché doit pouvoir
  expliquer ce qu'il signifie et pourquoi il est dans telle bande de couleur
  (pas juste la valeur brute). **Décision prise (voir État 22/7/2026)** :
  glossaire JS statique (`js/glossaire-indicateurs.js`), pas d'appel modèle
  à la volée — texte pré-rédigé par indicateur et par bande, calqué sur les
  bandes déjà définies dans le design doc section 4.4.
- **Configurabilité** : toute période d'indicateur (SMA 9/21/100, ATR(14),
  RSI(14), EMA si JP veut en substituer) doit être un paramètre exposé à
  l'utilisateur, jamais une constante en dur dans le code — même principe
  que `config.js` de madrid (`investment-dashboard/`). **Fait (22/7/2026)** :
  [`config.js`](config.js) à la racine, chargé avant la logique de
  `index.html`. Couvre les périodes affichées (SMA/ATR/RSI), les bandes de
  couleur (VIX/RSI/force relative/Golden Cross), les discounts de sizing, les
  seuils de charge de portefeuille et les valeurs par défaut (capital,
  ticker) — plus aucun de ces nombres n'est en dur dans le HTML/JS de l'app.
- **Journal + statistiques** : voir schéma de données section 7 du document
  de design (trade_id, dates, compte, ticker, prix, taille, stop, valeurs
  d'indicateurs à l'entrée, checklist complétée, R réalisé, résultat).
  Objectif analytique : mesurer après coup la valeur prédictive réelle de
  chaque indicateur pour les trades de JP.

## Intégration données de marché — tradingview-mcp (branché 22/7/2026)

Décision de JP après évaluation du repo (README + code source lu, pas
seulement la description marketing) : adopter
[`atilaahmettaner/tradingview-mcp`](https://github.com/atilaahmettaner/tradingview-mcp)
pour la partie qu'il couvre bien, compléter le reste à la main. **Branché et
testé en direct** le jour même (données réelles, pas de mock).

**Légitimité (vérifiée avant adoption)** : ne se connecte à aucun compte
TradingView, n'automatise aucune session/navigateur. S'appuie sur les
endpoints publics **non officiels** de TradingView via les librairies
communautaires `tradingview_ta`/`tradingview-screener` — zone grise côté
CGU (l'auteur le dit lui-même : *"you are responsible for ensuring your own
use complies with the terms of any data source you point it at"*), mais
sans risque de compte JP dans la boucle. Plus sûr qu'un scraper de session,
pas un statut « officiel » pour autant — à garder en tête si la posture
légale devient sensible plus tard.

**Version installée (0.7.1, PyPI) ≠ README GitHub** : le paquet publié sur
PyPI est en retard sur la branche `main` du repo — beaucoup d'outils
documentés dans le README (`get_technical_analysis`, `screen_stocks`,
options, futures, EGX…) **n'existent pas** dans la version installée. Le
vrai outil qui retourne RSI/ATR/SMA/EMA/OBV pour castellana s'appelle
**`coin_analysis`** (pas `get_technical_analysis`), et wrappe la même
fonction `extract_extended_indicators()` déjà analysée avant l'adoption.

**Ce qu'il couvre réellement pour castellana** (vérifié par appel MCP réel
sur AMD/NASDAQ le 22/7/2026, pas seulement en lisant le code) :

| Indicateur castellana | Outil `tradingview-mcp` | Statut |
|---|---|---|
| VIX | `market_snapshot` (`indices[].symbol == "^VIX"`) | ✅ réel — confirmé 16.64 le 22/7/2026 |
| RSI(14) | `coin_analysis` (`rsi.value`) | ✅ réel — confirmé 56.09 |
| Golden Cross (SMA50/SMA200) | `coin_analysis` (`sma.signals` contient `"Golden Cross (SMA50 > SMA200)"`) | ✅ réel, correspond exactement à la définition du design doc |
| **ATR(14)** | `coin_analysis` (`atr.value`) | ⚠️ **revenu `null` en test réel sur AMD** — la librairie sous-jacente `tradingview_ta` ne demande pas ce champ par défaut pour ce couple titre/timeframe. Pas fiable tel quel, malgré le champ qui existe dans le code. **Reclassé en calcul maison.** |
| **Volume vs moyenne 20j** | `coin_analysis` (`volume_analysis.ratio`) | ⚠️ **revenu `null` en test réel** (même cause — `volume.SMA20` absent du dict brut renvoyé par `tradingview_ta` pour ce cas). Le volume courant brut est disponible (`price_data.volume`), pas la moyenne 20j. **Reclassé en calcul maison.** |
| **OBV** | `coin_analysis` (`obv`) | ❌ **faux** — heuristique « clôture > ouverture de la bougie du jour », pas le vrai OBV cumulatif. **Calcul maison.** |
| SMA 9/21/100 | — | ❌ pas exposé à ces périodes précises (seulement SMA/EMA 10/20/30/50/100/200). **Calcul maison.** |
| Force relative vs indice | — | ❌ pas un champ direct, mais dérivable de 2 appels `yahoo_price` (titre + indice de référence). |

**Bilan révisé après test réel** : seuls **VIX, RSI et Golden Cross** sont
vraiment couverts de façon fiable par `tradingview-mcp`. ATR et Volume vs
moyenne 20j, qu'on pensait acquis, se sont révélés absents en pratique — la
liste des calculs maison est donc plus longue que prévu au moment de la
décision d'adoption (voir ci-dessous).

**Implémentation livrée** :
- Sidecar Python installé dans un venv dédié **non commité**
  (`.venv-mcp/`, gitignoré) : `pip install tradingview-mcp-server` (0.7.1,
  Python 3.13). Lancé via `npm run sidecar` → `streamable-http` sur
  `127.0.0.1:4701` (port choisi dans `settings.json`, clé
  `tradingviewMcp`).
- `server/tradingview.js` — client MCP (`@modelcontextprotocol/sdk`),
  connexion **paresseuse** (pas au boot d'Express, pour ne pas planter tout
  le serveur si le sidecar n'est pas encore démarré), fonctions
  `getMarketSnapshot()`, `getTechnicalAnalysis(ticker)`, `getPrice(symbol)`.
- `GET /api/market-data/:ticker` dans `server/index.js` — combine VIX +
  RSI/ATR/Golden Cross/volume pour un titre, `503` propre si le sidecar est
  injoignable (même patron que le `GITHUB_TOKEN` absent chez bilbao —
  jamais planter le serveur pour une dépendance externe indisponible).
  Testé de bout en bout : `curl http://127.0.0.1:4700/api/market-data/AMD`
  → `{"ticker":"AMD","vix":16.64,"rsi":56.09,"atr":null,"volumeRatio":null,
  "goldenCross":true,"sma50":505.39,"sma200":302.21}`.

**Calculs maison** : ~~ATR(14) réel~~, ~~volume vs moyenne 20j~~, ~~OBV
réel~~, ~~SMMA 9/21/100~~ — **tous livrés** (23/7/2026), voir section
« Calculs maison — OBV réel, SMMA 9/21/100, ATR réel, volume vs moyenne
20j » plus bas. Plus aucun indicateur du design doc encore manquant.

## Rate-limit non documenté de `coin_analysis` (confirmé 22/7/2026)

**Constat central, qui façonne tout le design ci-dessous** : une rafale de
~5-6 appels rapprochés à l'outil `coin_analysis` de `tradingview-mcp`
(RSI/SMA/Golden Cross) suffit à déclencher un rate-limit **non documenté**
côté API non officielle de TradingView (réponse vide, `JSON.parse` échoue
côté `tradingview_ta`). **Persistant plus de 5 minutes** en test réel, et
**re-déclenché** par un deuxième screening complet lancé juste après le
premier. Aucune indication de durée ni de mécanisme de retry côté
TradingView — c'est une limite externe, hors de notre contrôle.

**`yahoo_price`/`market_snapshot` ne sont PAS affectés** — vérifié en test
réel qu'ils continuent de répondre normalement pendant que `coin_analysis`
est bloqué. Ce sont deux sources de données distinctes (Yahoo Finance vs
scanner TradingView) à l'intérieur du même serveur MCP. **Conséquence de
design directe** : partout où c'est possible, la donnée qui peut venir de
Yahoo (VIX, cotations, % de variation → force relative) est sourcée
séparément de la donnée qui ne peut venir que du scanner TradingView
(RSI, Golden Cross), avec des `Promise.allSettled` (jamais `Promise.all`)
pour qu'un échec de l'un n'emporte pas l'autre. Voir `server/tradingview.js`.

**À surveiller à l'usage** : si ce rate-limit se déclenche souvent en usage
réel (JP relance le screening plusieurs fois de suite), il faudra soit
espacer davantage (`delayMs` dans `screenWatchlist`), soit mettre en cache
les résultats du screening (ex. 15-30 min) plutôt que tout re-fetcher à
chaque clic — non fait pour l'instant, cache absent.

## Frontend câblé sur les données temps réel (22/7/2026)

Trois ajouts dans `index.html`, tous testés en direct (données réelles, pas
mockées) :

1. **Onglet Fiche de trade** — bouton « Récupérer VIX + RSI en direct »
   (carte Climat de marché) : appelle `GET /api/market-data/:ticker` (le
   ticker de la carte « Le titre »), remplit `#vix`/`#rsi`, relance
   `calcFiche()`. Message de statut inline (« Récupéré avec succès » /
   « Récupéré partiellement — RSI indisponible (tradingview-mcp) » / erreur).
2. **Onglet Écran de sélection, section Ticker** — bouton « Récupérer en
   direct » : 3 appels en parallèle (`Promise.allSettled`) —
   `GET /api/quote/:ticker` (force relative titre), `GET /api/quote/SPY`
   (indice de référence, benchmark fixe), `GET /api/market-data/:ticker`
   (Golden Cross via SMA50/SMA200) — remplit `perfTitre`/`perfIndice`/
   `mm50`/`mm200`, relance `calcSelection()`. Dégradation par champ, pas
   binaire : si Golden Cross échoue (rate-limit), la force relative se
   remplit quand même (source Yahoo indépendante).
3. **Onglet Écran de sélection, nouvelle carte « Screening — univers de
   titres (20) »** — bouton « Lancer le screening » → `GET /api/screening`,
   tableau `.ds-table` trié par score décroissant (Ticker/RSI/Force
   relative/Golden Cross/Score/Verdict), badges colorés, ~30-60s (appels
   séquentiels espacés côté backend). **Cliquer une ligne** copie le ticker
   dans la section Ticker et relance `fetchLiveSelection()` automatiquement
   — enchaîne screening → sélection → (bascule d'onglet) → fiche de trade
   sans ressaisir le ticker.

## Performance des secteurs — `server/sectors.js` + `GET /api/sectors` (29/8/2026)

Nouvelle carte au-dessus du screening dans l'écran de sélection (demande de
JP, inspirée d'un tableau de performance sectorielle vu ailleurs) : les 11
ETF SPDR Select Sector (State Street) — même famille que SPY, déjà utilisé
partout ailleurs dans ce projet comme indice de référence
(`server/tradingview.js`) — plus SPY lui-même en ligne de repère tout en bas.

**Une seule requête `yahooFinance.quote()` par ETF** (pas `quoteSummary`)
donne à la fois la performance du jour (`regularMarketChangePercent`) et le
P/E trailing (`trailingPE`) — 12 appels séquentiels espacés de 150ms par
politesse (même discipline que `fundamentals.js`/`indicators.js`), ~2.5s au
total en test réel, aucun rate-limit observé (c'est `quote()`, pas
`coin_analysis` — sans lien avec le rate-limit documenté plus bas).

**Différence importante avec le "P/E industrie" du screening** : ici le P/E
est celui de l'ETF sectoriel lui-même — un vrai agrégat de marché calculé
par le fournisseur de l'ETF sur ses constituants réels, **pas** une
approximation par pairs de watchlist comme le "P/E industrie" du tableau de
screening (section précédente). Documenté explicitement en tooltip sur
l'en-tête de colonne pour éviter toute confusion entre les deux.

Chargement **automatique** au démarrage de la page (`loadSectors()`, comme
`checkStatus()`) — contrairement au screening, volontairement pas derrière
un bouton "Lancer" : rapide, pas de rate-limit à ménager. Bouton
« Actualiser » disponible pour forcer un rafraîchissement. Tri par
performance décroissante côté client, couleur verte/rouge selon le signe.
**Vérifié en direct dans le navigateur** : 11 secteurs + SPY, données
réelles, tri correct, ligne SPY mise en évidence (gras, bordure) en bas de
tableau.

### Line graph de performance sectorielle (29/8/2026)

Demande de JP après avoir vu la carte ci-dessus : un graphique en ligne de
la performance de **tous** les secteurs, période sélectionnable (1 semaine,
1/2/3/6/12 mois — défaut **12 mois**), placé au-dessus du tableau. Skill
`dataviz` du portfolio consultée avant d'écrire le code (forme, couleur,
marks, interaction — voir `references/*.md` du skill).

**Backend** : `getSectorHistory()` (`server/sectors.js`) — un seul
`yahooFinance.chart()` par ETF (~385 jours calendaires, marge au-delà de 12
mois pour le calendrier boursier), route `GET /api/sectors/history`.
**Un seul fetch pour toutes les périodes** : le frontend reçoit tout
l'historique une fois (`loadSectorHistory()`, appelé au chargement de la
page) et découpe/normalise en % côté client (`sliceAndNormalize()`) à
chaque changement de période — aucun refetch au clic sur un bouton de
période. Pas de cache serveur (comme `/api/sectors` — rapide, ~1,2s pour 12
titres en test réel, aucun rate-limit observé sur `chart()`).

**Rendu** : SVG écrit à la main (pas de librairie de charting — cohérent
avec le reste du portfolio, zéro dépendance frontend ajoutée), 2px lignes
arrondies, grille hairline recessive, axe Y en %, 3 repères de date sur
l'axe X. **Étiquettes directes en bout de ligne** (ticker à droite de
chaque courbe) — c'est le mécanisme d'identité principal, pas la seule
couleur (règle du skill dataviz : « never color alone »), important ici
car **11 secteurs + 1 benchmark dépassent la palette catégorielle validée
CVD du skill (8 teintes max)** — voir note dédiée ci-dessous.
Survol : ligne de mire verticale (crosshair) qui suit le pointeur, infobulle
listant tous les secteurs visibles à cette date triés par performance.
Légende cliquable sous le graphique : cliquer un secteur le masque/l'isole
(`toggleSectorSeries()`), utile vu le nombre de courbes.

**Le S&P 500 (SPY) est traité comme un repère, pas un secteur de plus** :
encre neutre (`var(--text-2)`, pas une teinte catégorielle) + trait
pointillé plus épais — cohérent avec son rôle de benchmark dans tout le
reste de l'app (déjà `SPY` = référence dans le screening et la Fiche de
trade).

**Écart documenté au skill dataviz — 11 couleurs catégorielles, pas 8** :
la palette de référence du skill (`references/palette.md`) ne valide
CVD-safe que 8 teintes. Avec 11 secteurs à distinguer simultanément (le
graphique montre « tous les secteurs », demande explicite de JP — pas
d'option pour replier certains en « Autre »), les 8 premières couleurs
(`--sc-1` à `--sc-8`) reprennent exactement la palette validée du skill ;
les 3 suivantes (`--sc-9` à `--sc-11`, pour XLE/XLC/XLB) sont ajoutées sans
être passées par le validateur CVD. Mitigation appliquée (recommandée par
le skill pour ce cas précis — « fold to Other, small multiples, ou
composite encoding » n'était pas compatible avec la demande) : identité
jamais portée par la seule teinte — légende toujours visible, étiquette de
ticker en bout de ligne sur CHAQUE courbe, infobulle listant nom complet +
valeur au survol. Variables CSS `--sc-1`..`--sc-11` déclarées en dual
clair/sombre dans `index.html` (pas dans `design-system/tokens.css` — ce
sont des teintes de graphique propres à ce composant, pas des jetons
sémantiques partagés).

**Vérifié en direct dans le navigateur** (fonctionnellement, via
inspection DOM/JS — le rendu visuel par capture d'écran n'a pas pu être
confirmé cette session, la tuile du navigateur restant vide sur les
captures malgré un DOM et des logs corrects) : historique réel chargé (265
barres/titre sur 12 mois), changement de période (365→30 jours) qui met à
jour le bouton actif et redessine sans refetch, `toggleSectorSeries('XLK')`
qui retire effectivement la courbe et l'étiquette XLK du SVG puis les
restaure.

## Screening 20 titres — `server/watchlist.js` + `GET /api/screening`

Implémente la section 5 du design doc (tableau multi-titres, score
composite, verdict par ligne), avec deux écarts délibérés documentés
ci-dessous plutôt que cachés.

**Univers de titres (`server/watchlist.js`)** : 12 titres réellement suivis
par JP (design doc section 1 : MSFT, META, GOOG, AMZN, AMD, ADBE, PYPL,
RDDT, JD, SMCI, ASML, CRWV) + 8 grands noms tech/IA liquides ajoutés par
Claude pour atteindre 20 (AAPL, NVDA, TSLA, AVGO, CRM, ORCL, PLTR, NFLX) —
**pas** un scan générique « top gainers » (testé et rejeté : ramène des
micro-caps spéculatives à +3000%/jour, hors sujet pour une stratégie
tech/IA liquide). Liste éditable directement dans le fichier, à ajuster
librement.

**Score composite — écart au design doc** : la section 5 prévoit 4
colonnes (RSI, Force relative, Golden Cross, **OBV**). L'OBV n'étant pas
disponible de façon fiable via `tradingview-mcp` au moment de l'adoption, le
score était initialement calculé sur 3 colonnes — **revenu à 4 colonnes**
(RSI, Force relative, Golden Cross, OBV) depuis l'ajout du calcul maison
d'OBV réel ci-dessous (22/7/2026). `server/index.js`, `scoreRow()` : vert =
+1, rouge = -1, amber = 0 par colonne, `verdict` = `ajouter` (score ≥ 2) /
`surveiller` (score ≥ 0) / `ne pas ajouter` (score < 0) / `erreur` (aucune
donnée récupérée du tout — distinct d'un score simplement bas). Seuils
dupliqués de `config.js` (`CFG.bandes`) dans `SCORE_BANDS`, faute de format
de module commun entre le frontend classique et ce backend ESM — à
reporter à la main si les bandes de `config.js` changent.

**`screenWatchlist()`** (`server/tradingview.js`) : boucle séquentielle
avec délai (`delayMs = 1500` par défaut), jamais `Promise.all`. `changePercent`
vient de `yahoo_price` par titre (résilient), `rsi`/`goldenCross` de
`coin_analysis` par titre (sujet au rate-limit ci-dessus) — un titre peut
donc ressortir avec force relative seule si le scanner est bloqué. `SPY`
(benchmark) fetché une seule fois en tête de fonction. La route
`GET /api/screening` (`server/index.js`) compose ce résultat avec une
seconde passe indépendante — `getHomemadeIndicatorsBatch()`
(`server/indicators.js`) — pour l'OBV réel, fusionnée par ticker avant le
scoring.

### Screening — P/E ratio et industrie (29/8/2026)

Demande de JP : afficher le P/E ratio, la famille d'industrie et le P/E de
cette famille dans le tableau de screening. Source : `server/fundamentals.js`
(déjà utilisé pour Float/PEG/Beta/VWAP), module Yahoo Finance
`summaryProfile` ajouté à l'appel `quoteSummary` existant — `peRatio` vient
de `summaryDetail.trailingPE`, `industry` de `summaryProfile.industry`
(classification GICS sub-industry de Yahoo, ex. « Semiconductors »,
« Software - Infrastructure »).

**P/E de l'industrie — approximation assumée, pas un vrai agrégat
sectoriel** : aucune source gratuite fiable identifiée pour un P/E moyen
d'industrie à l'échelle du marché. Calculé à la place dans `server/index.js`
(route `/api/screening`) comme la **moyenne des P/E des titres de LA
WATCHLIST** (20 titres) qui partagent la même industrie — donc un chiffre
utile pour comparer un titre à ses quelques pairs déjà suivis, pas un
benchmark de marché externe. Sur 20 titres, une industrie n'a parfois qu'1
seul titre (« P/E industrie » = son propre P/E) : `industryPeerCount` est
exposé par l'API et affiché en tooltip sur la cellule pour ne jamais laisser
croire à un agrégat plus large qu'il ne l'est réellement — même principe que
partout ailleurs dans le portfolio (jamais un chiffre silencieux qui ment
sur sa propre fiabilité, voir le piège documenté dans le `CLAUDE.md` racine).
**Vérifié en direct** : Semiconductors (AVGO/NVDA/AMD) → P/E industrie
70.8 (moyenne des 3), `industryPeerCount: 3` ; AAPL seul dans « Consumer
Electronics » → P/E industrie = son propre P/E (36.1), `industryPeerCount: 1`.
Colonnes ajoutées au tableau HTML (`index.html`) et à l'export CSV
(`/api/screening.csv`). Aucun filtre/score ajouté sur ces champs — JP n'a
demandé que l'affichage.

## Calculs maison — OBV réel, SMA 9/21/100, ATR réel, volume vs moyenne 20j

Résout le point ouvert depuis l'adoption de `tradingview-mcp` (celui-ci ne
fournit ni un vrai OBV cumulatif, ni cette moyenne mobile — voir section
précédente). *(Terminologie et calcul de la moyenne mobile révisés le
29/8/2026 : c'était une SMMA/RMA lissée, standardisée sur une vraie SMA —
voir « État » en bas de fichier pour le détail de la demande de JP.)*

**Source de données OHLC brute — tranchée** : `yahoo-finance2` (npm),
historique quotidien direct (`chart()`, ~300 jours calendaires ≈ 200+
barres). Non officiel mais légitime (même famille que `yahoo_price`/
`market_snapshot` de tradingview-mcp) — **zéro dépendance à
`coin_analysis`**, donc pas affecté par son rate-limit ; testé pendant que
celui-ci était bloqué, a continué de répondre normalement. Alpha Vantage
(`TIME_SERIES_DAILY`, déjà connecté côté JP) écarté pour cet usage : quota
25 req/jour bien trop bas pour un screening de 20 titres.

**`server/indicators.js`** — module autonome, ne dépend pas du sidecar
Python :
- `computeSMA(closes, period)` — SMA standard, fenêtre glissante (design doc
  section 4.1, révisé 29/8/2026) : `SMA[i] = moyenne des period dernières
  clôtures`. Remplace l'ancienne `computeSMMA` (RMA lissée) pour le filtre
  de tendance.
- `computeOBV(bars)` — cumul classique (design doc section 4.4) : +volume
  si clôture > veille, -volume si <, inchangé si =.
- `classifyOBV()` — **approximation** de « confirme »/« diverge »/« neutre »
  (pas une détection formelle de divergence sur pics/creux) : compare la
  variation de l'OBV et celle du prix sur les 10 dernières barres — même
  signe → `accumulation`, signes opposés → `distribution`. Documenté comme
  approximation, à affiner si l'usage réel montre des faux signaux.
- `computeTrueRange(bars)` + `computeATR(bars, period=14)` — True Range
  standard puis lissage Wilder, qui **est** une RMA appliquée au TR
  (fonction `computeRMA` dédiée, gardée séparée de `computeSMA` depuis la
  révision du 29/8/2026 — l'ATR reste correctement en RMA par définition,
  ce n'est pas concerné par le passage du filtre de tendance à la SMA).
  Période dupliquée en dur (`ATR_PERIOD`), à reporter à la main si
  `CFG.indicateurs.atrPeriode` change dans `config.js`.
- `computeVolumeVs20d(bars)` — volume du jour ÷ moyenne des 20 jours
  **précédents** (jour courant exclu de sa propre moyenne, sinon un jour à
  fort volume gonflerait sa référence).
- `getHomemadeIndicators(symbol)` — un seul appel Yahoo Finance, tout
  (SMA/OBV/ATR/volume) calculé dessus ; lève si historique < 100 barres
  (SMA100 impossible) ou Yahoo injoignable.
- `getHomemadeIndicatorsBatch(tickers)` — séquentiel, délai léger
  (400ms/titre — Yahoo Finance direct n'a pas montré le rate-limit du
  scanner TradingView, mais reste poli plutôt que d'enchaîner à pleine
  vitesse), tolérant aux échecs par titre.
- `checkYahooConnection()` — cotation SPY minimale, pour le témoin de
  statut du frontend (voir section dédiée plus bas).

**Branché sur** :
- `GET /api/market-data/:ticker` — 3ᵉ branche `Promise.allSettled`
  (`sma9`/`sma21`/`sma100`/`smaAlignment`/`obv`/`obvTrend`/`atr`/
  `volumeRatio`/`volumeSMA20`), indépendante de `coin_analysis` et
  `market_snapshot`. `atr`/`volumeRatio` de la réponse préfèrent
  maintenant le calcul maison (`hm?.atr ?? ta?.atr?.value ?? null`) — celui
  de `tradingview-mcp` reste en repli, gardé au cas où l'outil tiers
  l'exposerait un jour pour un titre/timeframe donné.
- `GET /api/screening` — OBV réintégré comme 4ᵉ colonne du score (voir
  section précédente). ATR/volume n'y figurent pas : ce ne sont pas des
  colonnes du score composite (section 5 du design doc), seulement des
  champs de la fiche de trade individuelle.
- Frontend Fiche de trade — bouton « Récupérer VIX + RSI + ATR + OBV en
  direct » remplit maintenant aussi le champ ATR (`toFixed(2)`) et le
  sélecteur OBV (`accumulation`/`distribution`/`neutre`) ; affiche
  l'alignement SMA **et** le ratio de volume vs moyenne 20j en texte
  (« haussier ✓ · Volume vs moyenne 20j : 44% (en-dessous) ») à côté de la
  checklist — **sans cocher aucune case automatiquement**, l'engagement de
  la checklist reste un geste manuel de JP.
- Frontend Écran de sélection — colonne OBV ajoutée au tableau de
  screening (badges Accumulation/Distribution/Neutre).

**Vérifié en direct le 22/7/2026** (AMD, données réelles — *valeurs figées
au moment du test, obtenues avec l'ancien calcul RMA/SMMA, avant la révision
SMA du 29/8/2026 ; ne pas les relire comme les valeurs SMA actuelles*) :
`smma9=528.16 > smma21=501.20 > smma100=345.31`, prix 552.33 au-dessus →
`smmaAlignment: "haussier"`, cohérent avec le Golden Cross déjà confirmé
par `tradingview-mcp`
(SMA50=505 > SMA200=302). `obv` réel (valeur cumulative ~1.26 milliard,
grandeur brute peu lisible en soi — c'est `obvTrend` qui compte pour
l'app) → `accumulation`. `atr=36.44$` (≈6.6% du prix, plausible pour un
titre volatil), `volumeRatio=0.42` (volume du jour à 42% de sa moyenne
20j) — les deux remplis dans la Fiche de trade via le bouton. Screening
complet re-testé avec le score à 4
colonnes : résultats cohérents, verdicts `ajouter`/`surveiller`/`ne pas
ajouter` bien répartis sur les 20 titres.

## Intégration données de marché — Alpha Vantage (état des tests)

- Connecteur MCP installé et connecté côté JP.
- **GLOBAL_QUOTE fonctionne** (confirmé sur AMD : prix, volume, variation).
- **RSI a échoué** (`No approval received.`) — cause non confirmée, à
  investiguer (flux d'approbation manquant pour les indicateurs calculés vs
  les cotations brutes).
- **Palier gratuit** : 25 requêtes/jour, 5/minute, données décalées de 15
  min — un rafraîchissement complet du tableau de 20 titres dépasse
  largement ce quota en une passe. Architecture à prévoir : rotation d'un
  sous-ensemble prioritaire par jour, et/ou palier payant (49,99$/mois, 75
  req/min, sans plafond quotidien) si l'usage réel le justifie. Prévoir une
  couche de cache/persistance dans tous les cas.
- **Statut depuis l'adoption de tradingview-mcp (22/7/2026)** : `tradingview-mcp`
  devient la voie principale pour VIX/RSI/ATR/Volume/Golden Cross (RSI y
  fonctionne, contrairement au blocage Alpha Vantage ci-dessus). Alpha
  Vantage reste un candidat pour `TIME_SERIES_DAILY` (historique OHLC brut
  nécessaire au calcul maison de l'OBV réel et de la SMMA 9/21/100 — voir
  section précédente), à confirmer une fois cette brique construite.

## Hors scope pour cette phase

- **Exécution automatique de trades** — jamais d'ordre envoyé au courtier
  par l'outil.
- **Conseil en investissement personnalisé** — l'outil est un outil d'aide à
  la décision et de journalisation pour JP, pas un système qui recommande
  des trades de façon prescriptive à un tiers.
- Intégration avec « La Roue » (barcelona, projet séparé).
- Rebalancement de portefeuille long terme (couvert par madrid/
  `investment-dashboard`, hors de ce projet).

## Architecture

**Stack — tranchée (22/7/2026, JP)** : backend, pas frontend statique +
service à part. Raisonnement de JP : le serveur MCP TradingView doit de
toute façon être un backend, donc autant y loger aussi le journal de trades
et les statistiques plutôt que de garder deux couches. Patron retenu : Node
Express + better-sqlite3 (même patron que valencia/bilbao). Le frontend
(`index.html`/`config.js`) reste tel quel — zéro build, servi statiquement
par ce backend (comme `feature-factory/public/` pour bilbao).

**Scaffold livré (22/7/2026)** : `package.json` (ESM, `express` +
`better-sqlite3`), `settings.json` (port 4700, host 127.0.0.1, chemin DB —
voir section Lancer l'application), `server/db.js` (ouvre/crée
`data/castellana.sqlite`, WAL, schéma table `trades` — journal de trades,
section 7 du design doc, CHECK sur les enums `compte`/`obv_a_entree`/
`resultat`, idempotent), `server/index.js` (Express écoute
**127.0.0.1 uniquement** — même garde-fou sécurité que bilbao — sert le
frontend statique en racine, route `GET /api/health`). Vérifié : boot,
`/api/health` retourne `{status:"ok",trades:0}`, `index.html` servi
correctement en `http://127.0.0.1:4700/` (design system, onglets, calculs —
identique au test en `file://`).

**Reste à faire** : décider quelle partie de la logique actuelle du
frontend (sizing, checklist) migre côté serveur vs reste côté client ;
implémenter les calculs maison ATR/Volume/OBV/SMMA (liste allongée après
test réel de `tradingview-mcp`, voir section Intégration données de
marché) ; construire les routes API du journal de trades (CRUD) — la table
existe, aucune route ne l'utilise encore ; faire consommer les données
temps réel (`/api/market-data/:ticker`) par le frontend (`index.html` ne
les appelle pas encore, les champs restent saisis à la main).

Points déjà tranchés (voir section État pour le détail) :
- Design system : copie vendorée en place dans `design-system/` (22/7/2026).
- Explications pédagogiques par indicateur : glossaire JS statique, pas
  d'appel modèle (22/7/2026).
- Configurabilité : `config.js` (22/7/2026).
- Écrans fusionnés en une seule app à onglets, `index.html` (22/7/2026).
- Source de données MCP TradingView : `tradingview-mcp` adopté **et
  branché** — sidecar Python (`npm run sidecar`) + client
  `server/tradingview.js` + route `GET /api/market-data/:ticker`, testé
  avec des données réelles (22/7/2026 — voir section « Intégration données
  de marché — tradingview-mcp »). Fiable pour VIX/RSI/Golden Cross
  seulement ; ATR/Volume rejoignent la liste des calculs maison.
- Scaffold du backend Express + better-sqlite3 (22/7/2026, ci-dessus).

Ce qui reste réellement ouvert : la **source de données OHLC brute** pour
les calculs maison (ATR réel, volume vs moyenne 20j, OBV réel, SMMA
9/21/100 — voir section Intégration données de marché), et le branchement
effectif du journal de trades au backend (le scaffold est prêt à le
recevoir, rien n'est encore
câblé).

## Lancer l'application

```bash
cd trading-assistant
npm install --cache /tmp/npm-cache-castellana   # --cache si EACCES (piège connu, voir CLAUDE.md racine)
npm start
# → http://127.0.0.1:4700/
```

La base SQLite (`data/castellana.sqlite`, gitignorée) est créée
automatiquement au premier démarrage si absente.

### Sidecar tradingview-mcp (optionnel — requis seulement pour `/api/market-data/*`)

```bash
cd trading-assistant
python3 -m venv .venv-mcp        # une seule fois
source .venv-mcp/bin/activate
pip install tradingview-mcp-server
deactivate
npm run sidecar
# → sidecar sur http://127.0.0.1:4701 (Python, streamable-http)
```

Deux process séparés (`npm start` + `npm run sidecar`), deux terminaux.
Le backend Express ne lance pas le sidecar automatiquement — s'il n'est pas
démarré, `/api/market-data/:ticker` répond `503` proprement, tout le reste
de l'app continue de fonctionner normalement.

**Documentation d'installation pour un tiers (30/8/2026)** — JP a ajouté un
collègue comme collaborateur GitHub, qui n'arrivait pas à lancer le projet.
En regardant ce qui existait, deux problèmes réels trouvés (pas juste un
manque de documentation) :
1. `README.md` (à la racine du repo, distinct de ce `CLAUDE.md`) ne
   contenait que des commandes macOS non expliquées, aucune vue d'ensemble
   du projet, aucune mention de `npm install`, du clonage, ni des
   prérequis. Réécrit en présentation générale du projet (pourquoi, les 3
   écrans, l'architecture à 2 serveurs + SQLite, un diagramme Mermaid) —
   renvoie vers un nouveau `SETUP.md` pour l'installation détaillée.
2. **Bug réel, pas seulement documentaire** : le script npm `sidecar`
   codait en dur `./.venv-mcp/bin/tradingview-mcp` — un chemin Unix/macOS.
   Un venv Python créé sur Windows range ses exécutables dans
   `.venv-mcp\Scripts\` avec l'extension `.exe`, donc cette commande ne
   pouvait **jamais** fonctionner sur Windows, quoi que le collègue ait
   fait. Corrigé par `scripts/run-sidecar.mjs` (zéro dépendance ajoutée —
   `node:child_process`/`node:fs` natifs) qui détecte `process.platform` et
   choisit le bon chemin, avec un message d'erreur explicite (pas un crash
   opaque) si le venv n'existe pas encore. `package.json` pointe maintenant
   dessus (`"sidecar": "node scripts/run-sidecar.mjs"`). **Testé en
   direct sur macOS** (le sidecar démarre, répond sur le port 4701) — **pas
   testé sur une vraie machine Windows**, seulement par lecture de code et
   raisonnement sur `process.platform`.

Nouveau `SETUP.md` (racine du repo) : prérequis (Git/Node 20+/Python 3.10+),
étapes numérotées **séparément Windows/macOS** à chaque commande (clonage
d'un repo privé — authentification GitHub requise, plus de mot de passe en
ligne de commande —, `npm install`, création du venv, lancement des deux
serveurs), et une section Dépannage couvrant les échecs les plus probables
pour quelqu'un de nouveau sur le projet : port déjà utilisé (commande par
OS), échec de compilation native de `better-sqlite3` sur Windows (piste
Visual Studio Build Tools), erreur `EACCES` npm, `python` introuvable côté
Windows vs `python3` côté macOS. Ce fichier est pour un tiers qui découvre
le projet — ne pas le confondre avec ce `CLAUDE.md`, qui reste le journal
de bord destiné à JP et aux futures sessions de travail sur ce produit.

## Feuille de route suggérée

1. **Phase 1** — ~~Consolider les deux prototypes HTML en un seul workflow
   cohérent~~ (fait) ; ~~scaffold du backend Express + better-sqlite3~~
   (fait) ; ~~brancher `tradingview-mcp` en sidecar~~ (fait) ; ~~câbler le
   frontend sur les données temps réel~~ (fait) ; ~~calculs maison OBV réel,
   SMMA 9/21/100, ATR réel, volume vs moyenne 20j~~ (fait, 22-23/7/2026 —
   `server/indicators.js`, Yahoo Finance direct). **Phase 1 terminée.**
2. **Phase 2** — ~~Tableau de sélection multi-titres, score composite~~
   (fait, 22/7/2026 — **4 colonnes complètes** RSI/Force relative/Golden
   Cross/OBV depuis l'ajout du calcul maison ; import CSV en bloc de la
   section 5 du design doc pas fait, univers fixé dans
   `server/watchlist.js`). Reste : cache des résultats de screening
   (mitiger le rate-limit `coin_analysis` en cas de relances rapprochées —
   voir section dédiée plus haut).
3. **Phase 3** — Journal de trades automatisé (schéma section 7 du design
   doc) + requêtes analytiques post-trade, explorer le webhook TradingView
   pour rapprocher l'alerte du signal réel.

## Retours de Louis, volume du Labo et watchlists dans bilbao (20/9/2026)

- **T0 — la section « Symbole » n'est PAS la même partout** (constat, aucun
  changement de code) : Secteurs et Screener partagent le même gabarit
  (`tickerSectionHTML`) et les mêmes fonctions (`calcSelectionFor`,
  `fetchLiveSelectionFor`, route `/api/market-data`). La Fiche de trade a la même
  bannière (`evaluateSelection`) et la même route mais pas les cartes Force
  relative/Golden Cross/fondamentaux, puis son propre calcul de sizing. Le Labo a
  ses cartes propres et sa route `/api/labo`. Le Journal n'a qu'un champ. Les
  valeurs communes (volume, beta) viennent de la même source Yahoo.
  **JP a ensuite décidé d'uniformiser** — voir la section suivante.
- **T1 — deux cases de volume dans « Données réelles du titre » (Labo)** :
  « Volume (jour) » (Yahoo, inchangé) et « Volume moyen (100 derniers jours) ».
  `computeAverageVolume()` (`server/indicators.js` et `cloud/src/lib/indicators.js`,
  `VOLUME_AVG_PERIOD = 100`) = moyenne des 100 séances COMPLÈTES précédentes, jour
  courant exclu (même principe que `computeVolumeVs20d` : la barre du jour est en
  cours) ; `null` s'il manque de l'historique, jamais une moyenne sur moins de
  séances que l'étiquette annonce. Exposé par `/api/labo/:ticker` (`volumeAvg100`).
  Vérifié sur AMD contre un recalcul indépendant : 29 648 607, identique à l'unité.
  ⚠️ Le volume du jour est partiel pendant la séance : comparer les deux cases
  n'a de sens qu'après la clôture.
- **Watchlists dans bilbao** : `GET /api/admin/watchlists` (Worker, Basic Auth
  admin, lecture seule, `listAllUsersLists` dans `cloud/src/db/lists.js`) renvoie
  « Ma watchlist » et les listes personnalisées du Screener de tous les comptes —
  symboles et dates seulement, rien de personnel. Onglet bilbao « Watchlists » :
  tableau par testeur, détail, export JSON et CSV (une ligne par symbole, échappement
  vérifié avec guillemets et virgule). **État courant uniquement** : pas de date de
  modification sur une liste, aucune trace d'une suppression ; l'historique passe
  par la télémétrie (`list_saved`).

## Onglet TradingView dans Réglages (20/9/2026)

Demande de JP : documenter, dans un nouvel onglet sous Réglages, comment
configurer une connexion avec TradingView, pas à pas.

**Écart assumé avec la demande.** Aucun bouton « Connecter TradingView »
n'existe (feature #367, `Idee`) : écrire un pas-à-pas pour une fonction absente
l'aurait inventé. L'onglet documente donc trois options, dont la troisième est
explicitement marquée « pas encore disponible » :

1. **Sidecar tradingview-mcp** — local seulement (`installer-sidecar.*`,
   `tradingviewMcp.enabled`, pastille de l'onglet Technique). Dans la version
   cloud, la carte dit « non disponible ».
2. **Alertes TradingView → castellana** — webhook `POST /api/webhook/tradingview`
   (journal seul, aucune exécution). En cloud : `?secret=` = `WEBHOOK_SECRET`.
   En local : injoignable depuis TradingView, l'onglet le dit. Consultation par
   `GET /api/alerts` (JSON, pas d'écran dédié).
3. **Connexion au compte TradingView (OAuth 2.1)** — plan seulement.

**Deux limites à ne pas oublier.** Les prérequis côté TradingView (forfait payant
et authentification à deux facteurs pour les webhooks) sont écrits de mémoire et
signalés « à vérifier sur ton plan » : je ne les ai pas confirmés sur la
documentation de TradingView. Et l'adresse cloud affichée contient le
placeholder `TON_SECRET`, jamais le vrai secret.

Markup statique dans `index.html` et dans `cloud/public/index.html` (la carte
sidecar et l'adresse du webhook diffèrent entre les deux ; pas de fichier JS
partagé, donc rien à ajouter au test de parité). Vérifié dans le navigateur en
local (bouton, 4 cartes, aucune erreur console), 95/95 tests. **La version
cloud n'a été vérifiée que par son contenu**, pas dans un navigateur.

**Feature 367 — à valider avant de construire** : portée des données lisibles,
durée de vie des jetons, comportement sur un Worker sans état en mémoire entre
requêtes. Spike du 18/9 : OAuth 2.1 et enregistrement dynamique du client OK
face à `mcp.tradingview.com/mcp`, arrêté avant le login réel.

## Yahoo depuis Cloudflare — instance par requête et jeton partagé (20/9/2026)

**Symptôme** : bandeau « cotation SPY (test de connectivité) : échec après 2
tentative(s) — temporisation dépassée (6000 ms) », et données qui ne se rafraîchissent
pas, sur la version cloud.

**Mesuré** (sonde `wrangler dev --remote`, réseau de Cloudflare, colo YUL, supprimée
après coup) :
- `chart()` (historique, **sans jeton**) : 12/12 OK en ~80 ms, toujours.
- `quote()` et `quoteSummary()` (**avec jeton crumb**) : échecs intermittents
  « Failed to get crumb, status 429 » — Yahoo limite les adresses Cloudflare, partagées
  par des milliers de Workers. Une fois déclenchée, la limite a duré plus de 10 minutes.
- **10 requêtes simultanées sur une instance chaude : 0 à 40 % de réussite**,
  « Cannot perform I/O on behalf of a different request » et délais de 15 s. **C'est
  le vrai bug de l'application.** `new YahooFinance()` était au niveau du MODULE dans
  quatre fichiers ; la bibliothèque y garde la promesse du crumb en cours (WeakMap par
  cookie jar) et la requête B attend une promesse créée dans le contexte de A, ce que
  Workers interdit ou ne résout jamais.
- Une instance neuve fait **8 appels réseau** avant sa première cotation (consentement
  Yahoo, cookie, crumb) : un jar restauré n'en fait **1**.
- **Le Mac de JP n'est pas en cause** : 8/8 tests locaux à 0,4-1,1 s.

**Correctif** (`cloud/src/lib/yahoo.js`, seul point d'accès à Yahoo) :
1. **Une instance par requête** (`AsyncLocalStorage`, middleware `withYahoo(c.env.DB, next)`
   dans `src/index.js`). `yahooFinance` est un mandataire : les appels existants ne
   changent pas ; hors requête (tests) il retombe sur une instance de repli.
2. **Le jeton est partagé via D1, pas en mémoire** : le cookie jar (qui contient le
   crumb) est sérialisé dans `cache` (`yahoo:cookiejar:v1`, TTL 6 h, global — aucun
   cookie personnel) et restauré au **premier appel Yahoo** de la requête (lecture
   paresseuse : une requête sans Yahoo ne coûte aucune sous-requête). `deserialize()`
   renvoie la classe de base, d'où `Object.setPrototypeOf(jar, ExtendedCookieJar.prototype)`.
   Un crumb refusé (« invalid crumb/cookie ») supprime le jar partagé ; un jar corrompu
   est ignoré.
3. **Le test de statut distingue deux pannes** (`checkYahooConnection`, local et cloud) :
   « Yahoo injoignable » (historique KO) et « Yahoo répond mais refuse le jeton des
   cotations/fondamentaux » (historique OK, cotation KO) — avant, un seul test « cotation »
   annonçait une panne totale alors que l'historique et les indicateurs fonctionnaient.

**Vérifié** : Node avec base factice — requête 1 = 8 appels + 1 écriture ; requête 2 =
1 appel ; 10 requêtes simultanées = 10/10 en 221 ms, 30 appels réseau tous utiles, 0
écriture de plus ; jar corrompu → repli. Runtime Worker (wrangler dev + D1 locale) —
10 `/api/status` simultanés et 10 `/api/market-data` simultanés : 200 partout, ≤ 0,2 s.
95/95 + 17/17 tests. **Non validé sur le vrai réseau de Cloudflare** : Yahoo refusait le
jeton pendant toute la séance de test (limite déclenchée en partie par mes propres
rafales de sonde) — à vérifier après déploiement.

**Suite du même jour, après un premier déploiement resté insuffisant** : JP voyait encore
« Erreur : Yahoo Finance injoignable » (message des routes qui utilisent les cotations :
secteurs, `market-data`). Diagnostic mesuré en PRODUCTION par `GET /api/admin/yahoo`
(Basic Auth admin, lecture seule, sans donnée personnelle : appel brut, historique et
cotation via la bibliothèque, âge du jeton partagé) — proxy par bilbao
(`GET /api/castellana-yahoo`). Résultat : Yahoo joignable, historique toujours OK ; la
cotation échouait en 429 tant que le jeton n'était pas obtenu, puis le jar s'est
enregistré et réutilisé (65 ms). Défaut trouvé : **chaque requête en échec relançait le
parcours d'obtention du jeton** (jusqu'à 8 appels × 2 tentatives) et entretenait la limite
qu'elle subissait. Ajout d'une **pause de 45 s** (`yahoo:crumb-cooldown` dans `cache`)
après un 429 de crumb : pendant elle, `quote`/`quoteSummary` échouent aussitôt (2 ms, 0
appel réseau) avec un message clair ; `chart` n'est jamais bloqué ; qui a déjà un jeton
n'est pas concerné (la pause n'est lue que sans jeton).

**Confirmé en production** : après rechargement, le statut est revenu au vert (vérifié par JP
le 20/9/2026 à 9 h 48). Diagnostic de production (`/api/admin/yahoo`) : historique et cotation
OK en 56-113 ms, jeton partagé réutilisé. Le compte Cloudflare gratuit n'était pas en cause :
aucune limite du plan n'a été atteinte. À surveiller : la première requête après l'expiration
du jeton (6 h) peut échouer brièvement si Yahoo le refuse ; la pause de 45 s la rétablit seule.

**Limites du plan gratuit Cloudflare** (documentation vérifiée le 20/9/2026) : 100 000
requêtes/jour ; **10 ms de CPU par requête** ; **50 sous-requêtes par requête, D1 et KV
compris** ; 6 connexions simultanées ; D1 : 5 M lectures et 100 000 écritures par jour,
500 Mo par base, **50 requêtes D1 par invocation**. Le screening de l'univers élargi
(219 titres) dépasse structurellement les 50 sous-requêtes à cache froid (voir
« Cron Trigger » #354).

## Prix d'entrée de la Fiche — plus de valeur par défaut (20/9/2026)

- **Le champ `#entry` est vide au départ** (`placeholder="non renseigné"`), avec une
  note dessous (`#entry-note`). Même discipline que la bannière de verdict du
  11/9/2026 : jamais un chiffre crédible qui n'en est pas un.
- **Après « Récupérer en direct »**, le champ reçoit la **clôture de la dernière
  séance qui précède aujourd'hui**, et la note le dit avec sa date : « Clôture de la
  veille (18 sept. 2026) — dernier cours final connu de AMD, pas le prix actuel ».
  Si la donnée manque : champ inchangé et note « indisponible » (jamais un prix inventé).
- **`computePreviousClose(bars, now)`** (`server/indicators.js` et
  `cloud/src/lib/indicators.js`) compare des DATES en fuseau de New York et exclut la
  barre du jour (en cours pendant la séance) : le week-end ou le lundi matin retombe
  sur le **vendredi**. On n'utilise volontairement PAS `regularMarketPreviousClose` de
  Yahoo : le week-end il désigne la séance AVANT la dernière (le jeudi). Exposé par
  `/api/market-data` (`previousClose`, `previousCloseDate`). 5 tests (semaine, week-end,
  avant l'ouverture, barre à 23 h à New York — le fuseau, pas UTC —, cas nuls).
- ⚠️ « la veille » = la dernière clôture connue : un dimanche c'est le vendredi
  (d'où la date affichée dans la note).
- **Sans prix d'entrée, stop, cibles R, équivalents R des extensions Fibonacci et le
  texte de l'ordre affichent « — »** (`hasEntry` dans `calcFiche`) au lieu de
  « 0 ± distance ». La taille de position et la charge n'en dépendent pas et restent
  calculées.
- **Le prix rempli automatiquement appartient à son symbole** (`entryAutoFilled`) : si
  le symbole change, il est effacé (`calcFiche` le vérifie, tous chemins confondus) ;
  une saisie à la main le désarme (`entryManualEdit`). Le bouton « Préparer » du
  screening remplit toujours le prix du screening (cours du moment) mais la note dit
  explicitement que ce n'est PAS la clôture de la veille.
- **Vérifié** (local et cloud, données réelles) : départ vide et « — » partout ;
  AMD → 559,82 $ au 18 sept. (identique à l'API) avec la note ; changement de symbole →
  effacé ; saisie manuelle conservée. 95/95 tests.

## Section « Symbole » uniformisée dans tous les onglets (20/9/2026)

- **Standard = le gabarit de `js/ticker-section.js`** (`tickerSectionHTML`) :
  titre, bannière de verdict (+ « Ajouter à la watchlist »), champ « Symbole
  évalué » (placeholder « ex. AAPL »), « Récupérer en direct » + statut,
  **Fondamentaux** (OBV, Volume jour, **Volume moyen 100 j**, Float, P/E, Industrie,
  P/E industrie, PEG, Beta, VWAP), Force relative vs SPY, Golden Cross. Il est
  maintenant rendu **4 fois** : `sec` (Secteurs), `scr` (Screener), `fic` (Fiche de
  trade), `lab` (Labo). Vérifié : la structure statique est identique dans les
  quatre (23 éléments, seul le texte dynamique de la bannière diffère).
- **Options du gabarit** : `tickerId` (la Fiche garde l'id `ticker`, le Labo
  `labo-ticker` — des dizaines de références les lisent), `fetchCall` (le bouton
  lance AUSSI la récupération propre à l'onglet : `fetchLiveFiche()` pour VIX/RSI/
  ATR/OBV/alignement, `loadLaboTicker()` pour la volatilité/SMA du Labo),
  `onTickerInput`. Un seul `/api/market-data` par clic : `fetchLiveSelectionFor`
  accepte un `marketPromise` déjà lancé et `quiet` (l'appelant compose le statut
  final à partir des notes retournées).
- **Journal** : champ « Symbole * » standardisé (placeholder), sans données en
  direct — c'est un formulaire de saisie de trade, pas un écran d'analyse.
- **Doublons retirés** : Volume et Beta quittent la carte « Données réelles » du
  Labo (ils sont dans les fondamentaux) ; elle garde Prix, ATR, SMA, alignement.
  « Volume moyen (100 j) » est désormais dans **tous** les onglets
  (`/api/market-data` renvoie `volumeAvg100`, local et cloud).
- **Nouveau garde-fou, valable partout** : `selectionFetchedFor[instance]` retient
  le symbole d'une récupération. Si le symbole change ensuite, les valeurs
  affichées sont celles d'un AUTRE titre → `invalidateSelectionData()` les efface
  (champs, tuiles, statut) au lieu de les laisser sous le nouveau symbole. La Fiche
  avait déjà ce garde-fou (bannière lecture seule) ; il s'applique désormais aussi
  à Secteurs et Screener, dont le comportement change (avant : les anciennes
  valeurs restaient). Une saisie à la main dans un des 4 champs numériques
  (`selectionManualEdit`) désarme l'effacement — ces valeurs sont à l'utilisateur.
- **`lastTickerInstance` ne concerne que `sec` et `scr`** (`LINKED_INSTANCES`) :
  seuls ces deux onglets alimentent la Fiche au changement d'onglet ; la Fiche et le
  Labo gardent chacun leur symbole (le Labo n'écrase pas la Fiche, et inversement).
- Supprimés : `renderFicheSelectionBanner()`, la bannière lecture seule de la
  Fiche (`BANNER_TARGETS.fiche`), les ids `fiche-live-status`/`labo-live-status`
  (remplacés par `fic-`/`lab-live-status`).
- **Vérifié en direct** (local et cloud) : structure comparée par programme ;
  Fiche (section + VIX/RSI/ATR/OBV, changement de symbole → effacement, saisie
  manuelle conservée) ; Labo (section + volatilité/SMA, séquence rendue) ; Secteurs
  et Screener (non-régression, transfert vers la Fiche) ; aucune nouvelle erreur
  console. 90/90 tests, parité `cloud/public/js/ticker-section.js` ajoutée.

## Onglet Concepts — feature flag et édition par l'administrateur (20/9/2026)

- **T0 — flag `concepts_tab`, défaut OFF.** Premier feature flag réel de
  castellana. **Cloud** : table `feature_flags` (D1), GLOBALE, basculée depuis
  bilbao ; `KNOWN_FLAGS` (`cloud/src/db/flags.js`) est la seule liste de clés
  valides (un flag ne se crée pas par une requête ; bilbao affiche ce que le
  Worker déclare). Une clé absente = son défaut. **Local** : `settings.json`
  → `featureFlags.conceptsTab` (l'app locale n'a ni administrateur ni base
  partagée, donc pas d'interrupteur en direct). Front : `initConceptsTab()`
  lit `GET /api/flags` ; tant que le flag n'est pas `true`, le bouton reste
  caché et RIEN n'est rendu. Toute erreur laisse l'onglet caché.
- **T1 — édition, dans bilbao uniquement.** « Administrateur » = JP via ses
  identifiants admin existants ; aucun rôle créé côté castellana. Les testeurs
  ne font que LIRE (`GET /api/flags`, `GET /api/concepts`, session) ; les
  écritures passent par `/api/admin/flags/:key` et `/api/admin/concepts/:id`
  (Basic Auth admin). Les modifications sont **globales** (ce que voient tous
  les testeurs), stockées dans `concept_overrides` — seules les fiches
  modifiées ont une ligne ; le texte d'origine reste dans `js/concepts-data.js`
  (copie ESM générée `cloud/src/lib/concepts-data.js`), donc « Réinitialiser »
  le rétablit sans qu'il ait jamais été écrasé. Une sauvegarde identique à
  l'original supprime l'override. Bornes : titre 200 car., texte 20 000.
  **`id` des fiches stable** : c'est la clé des modifications.
- **⚠️ Le texte modifié est du HTML injecté chez TOUS les testeurs** →
  `conceptSanitizeHtml()` (`js/concepts-content.js`) ne laisse passer qu'une
  liste blanche (`p strong b em i u ul ol li br span div a h4 h5 code`, classes
  `concept-note`/`concept-note--piege`, liens `https?://` seulement, rendus
  `noopener`). Analyse DOM (template inerte), **pas de regex**. Vérifié avec
  `<script>`, `<img onerror>`, `javascript:`, `onclick`, `style`, `<iframe>` :
  tout retiré, `window.__pwned` jamais défini. Le titre est échappé, pas assaini.
  Le contenu par défaut (dans le dépôt) n'est pas filtré.
- **T2 — images supprimées** : `img/concepts/` (15 JPG, root et
  `cloud/public/`) retiré du dépôt (l'historique git les garde). Plus de champ
  `image`, plus de CSS `.concept-body img`.
- **T3 — crédit** : texte exact demandé par JP, avec ses tournures (« concept
  existant », « reprises ici ») — à corriger si voulu (« concepts existants »,
  « repris »).
- **Découpage** : `js/concepts-data.js` (données pures, 15 fiches) /
  `js/concepts-content.js` (rendu + assainisseur + init). `scripts/sync-labo-schema.mjs`
  devient `scripts/sync-cloud-copies.mjs` (`npm run sync:cloud`, remplace
  `sync:labo`) et génère DEUX copies ESM ; le test de parité les couvre, ainsi
  que `cloud/public/js/concepts-*.js`.
- **Migration D1** : `cloud/scripts/migrate-flags-concepts.mjs --remote` AVANT
  `wrangler deploy`, puis **vérifier `sqlite_master`** (ne pas se fier au
  message de fin — la vérification du 19/9 a d'abord montré une table absente).
- **Bilbao** : onglet « Concepts » — interrupteur (avec confirmation, portée
  « tous les testeurs ») + 15 fiches éditables (titre, HTML, aperçu en iframe
  `sandbox`, enregistrer, réinitialiser). Chaque écriture est auditée : id et
  TAILLES seulement, jamais le texte. Erreurs de validation (400) propagées.
- **Yahoo** : `checkYahooConnection()` (local et cloud) passe de 1 à 2
  tentatives — la panne signalée le 20/9 n'a pas été reproductible (Yahoo
  répondait en 0,4-1 s), c'était un ralentissement ponctuel.

**Vérifié en direct** : local (flag off → onglet caché, panneau vide ; flag on
→ 15 fiches, 0 image, crédit exact) ; cloud (`wrangler dev` + D1 locale) —
testeur : flag off puis on, fiche modifiée assainie, 401/404/400, un testeur ne
peut ni basculer ni modifier ; bilbao (base jetable, Worker local) — bascule,
sauvegarde, erreur titre vide, réinitialisation, audit. Tout nettoyé après.
87/87 tests.

## Paramètres des stratégies d'options — Labo éditable (19/9/2026)

Avant : les valeurs d'une séquence (« échéance dans 30-45 jours », delta
0.15-0.25, prise de profit 50-80 %…) venaient de `CFG.labo` (`config.js`), et
trois étaient même codées en dur dans le texte (« ≈75-85 % », « 100 actions »,
« environ 1 an »). Maintenant chaque valeur est un champ dans la phrase.

**Une seule source : `js/labo-schema.js`** (`LABO_SCHEMA` : défauts, bornes,
plages `lte`, unité, libellé — plus `laboMergeOverrides`, `laboEffectiveParams`).
Trois copies à ne jamais laisser dériver : le navigateur (script classique), le
serveur local (`server/labo-params.js`, évalué comme `sizing.test.js`) et le
Worker (`cloud/src/lib/labo-schema.js`, **généré** par `npm run sync:labo`). Deux
tests de parité échouent si ça dérive (copie ESM ; `cloud/public/js/*` et
`config.js`). `CFG.labo` ne garde que `defaultTicker`.

- **Chaque stratégie possède TOUS ses paramètres** (rien de partagé entre
  `roue` et `debit-spreads`, même à défauts identiques) — c'est la demande.
- **Trois familles de texte** dans une séquence : statique (la règle),
  dynamique (`laboDyn`, calculé depuis le titre : strikes, prix), **éditable**
  (`laboParam`/`laboRange` : `<input class="labo-param">`, souligné en
  pointillé ; modifié = trait plein + fond ambre + ↺ + défaut en info-bulle).
- `build(ctx)` reçoit `ctx.params` (défauts ⊕ surcharges) ; sans `params` il
  retombe sur les défauts. L'état coché des étapes survit au re-rendu (avant :
  remis à zéro).
- **On ne stocke que les SURCHARGES** (`strategy_params`, clé → valeur) : un
  futur changement de défaut profite à qui n'a rien touché ; remettre une
  valeur au défaut la supprime. Reset = `DELETE`, comme `resetPreferences`.
- Routes (locales `server/index.js`, cloud `cloud/src/routes/labo-params.js`) :
  `GET /api/labo/params`, `PUT /api/labo/params/:id` (partiel, validé serveur :
  type, bornes, `min ≤ max` sur les valeurs EFFECTIVES, clé inconnue et
  stratégie « à venir » refusées en 400), `POST …/:id/reset`, `POST …/reset`.
  ⚠️ **À déclarer AVANT `/api/labo/:ticker`**, sinon `params` est pris pour un
  symbole (les deux versions le commentent).
- **Export** côté client (Blob, patron `downloadTradesCSV`), format
  `castellana.options-strategies` v1 : valeurs **effectives complètes** +
  `overridden` (clés modifiées). Prévu pour un futur import (non livré).
- **Bilbao** (repo `feature-factory`) : le Worker expose
  `GET /api/admin/strategies` et `/schema` (Basic Auth admin existant, lecture
  seule, surcharges seulement) ; nouvel onglet « Stratégies options » = vue
  **live** + bouton **Archiver** (table `strategy_snapshots`, immuable, relue
  côté SERVEUR — jamais fournie par le navigateur — + `data/castellana/
  options-strategies.json` à committer soi-même, audité).
- **Stratégies personnalisées — préparées, PAS construites** : colonnes
  `kind`/`definition_json` réservées (rien ne les écrit), ids `custom:<uuid>`,
  schéma = données, `laboResolveStrategy(id, customDefinition)` seul point qui
  sait où chercher. **À trancher le jour venu** : les `build()` intégrés sont du
  JS ; une stratégie perso exigera des gabarits déclaratifs (`{{putDteMin}}`).
- **Non fait** : pas d'import, pas de télémétrie `strategy_saved` (bilbao lit
  D1 directement), onglet non renommé en « Options ».

**Vérifié en direct** : local (Browser pane) — édition, persistance au
rechargement, plage inversée refusée avec message, ↺ par champ, export des 3
stratégies (fichier JSON réel produit), indépendance `roue`/`debit-spreads` ;
cloud (`wrangler dev` + D1 locale, migration rejouée deux fois) — isolation
`jp`/`louis`, 400/401, front connecté ; bilbao (base jetable, Worker local) —
vue live, détail avec défauts, archive, audit. Tout nettoyé après coup (base
locale remise à `{}`, fichier JSON de test et `.dev.vars` supprimés).

## Onglet Labo — stratégies d'options (5/9/2026)

Nouvel onglet, hors du parcours Secteurs→Screener→Fiche→Journal : demande de
JP de pouvoir tester différentes stratégies d'options (wheel, iron condor,
poor man covered call…) sur un titre donné, avec la séquence à suivre pour
l'appliquer.

**Écart trouvé avant d'implémenter, signalé et clarifié avec JP** : le
fichier fourni, `strategy/PoorManCoveredCall.md.rtf`, décrit en réalité un
système « La Roue & Debit Spreads » (Cash-Secured Put → Covered Call, puis
Bull Call Spread / Bear Put Spread pour la gestion du risque) — **pas** la
vraie Poor Man's Covered Call (achat d'un LEAPS Call profondément ITM en
remplacement des 100 actions, vente répétée de Calls courts contre). Plutôt
que de deviner, question posée à JP via `AskUserQuestion` : garder les
**deux stratégies, distinctes**, dans le sélecteur — le contenu réel du
fichier sous son propre nom (`roue-debit-spreads`), et une vraie PMCC
écrite selon la définition standard de la stratégie (`pmcc`), indépendante
du fichier. Les deux sont documentées comme telles dans le code
(`js/strategies-labo.js`, champ `sourceNote` de chaque stratégie, affiché
dans l'UI) pour qu'aucune des deux ne soit prise pour l'autre.

**Architecture** :
- `js/strategies-labo.js` (nouveau, chargé en `<script>` comme
  `glossaire-indicateurs.js`) — catalogue `STRATEGIES_LABO` (id, nom,
  statut `disponible`/`a-venir`, résumé, note de source, fonction
  `build(ctx)` qui génère la séquence pas-à-pas à partir du ticker et des
  données réelles chargées). **À l'origine** (5/9/2026), deux stratégies
  `disponible` (`roue-debit-spreads`, `pmcc`) et deux `a-venir` (Iron
  Condor, Credit Spreads) — **séparée en deux le 7/9/2026** (voir section
  « Séparation La Roue / Debit Spreads » plus bas) : `roue-debit-spreads`
  n'existe plus, remplacée par `roue` et `debit-spreads`, donc 3
  stratégies `disponible` désormais. Affichées dans le sélecteur avec le
  suffixe « (bientôt disponible) » pour les `a-venir` et un bandeau
  explicite plutôt que masquées, même discipline que le hub essen
  (« ne jamais pousser un lien avant que le contenu réponde »).
- `GET /api/labo/:ticker` (`server/index.js`) — combine `getFundamentals()`
  (`server/fundamentals.js` : prix, volume, beta, P/E, industrie, secteur)
  et `getHomemadeIndicators()` (`server/indicators.js` : ATR réel, SMA
  9/21/100, alignement, OBV) sur un `Promise.allSettled`. **Choix
  délibéré : aucune dépendance à `tradingview-mcp`/`coin_analysis`** — ces
  deux sources sont du Yahoo Finance direct, donc jamais affectées par le
  rate-limit déjà documenté sur le scanner TradingView (voir section
  dédiée plus haut). 503 explicite si Yahoo est injoignable pour le ticker
  saisi (ticker invalide, etc.), jamais un objet vide qui laisserait croire
  à des données à zéro.
- `config.js` — nouvelle section `CFG.labo` (DTE/Delta cibles pour Put et
  Call, bornes de prise de profit, multiplicateurs d'ATR pour les zones de
  strike, paramètres PMCC — profondeur ITM du LEAPS, seuil de roulement).
  Même principe que le reste du projet : aucune de ces valeurs n'est en dur
  dans le HTML/JS.

**Discipline centrale, à ne jamais relâcher en étendant cet onglet** :
**aucune donnée d'options réelle (chaîne, strike, delta, prime) n'existe
dans cette app** — aucune source de ce type n'y est branchée. Les « zones
de strike » affichées dans la séquence sont une **estimation grossière**
(prix ± 1 à 2×ATR réel du titre), explicitement étiquetée comme telle à
chaque occurrence (« PAS une vraie donnée d'options ») et rappelée dans un
encart dédié en bas de l'onglet — jamais présentée comme un vrai chiffre de
marché. Un futur ajout de stratégie doit préserver ce principe plutôt que
d'inventer des deltas/primes plausibles.

**Vérifié en direct** (serveur redémarré pour charger le code, données
réelles AMD) : `GET /api/labo/AMD` → prix 477.57$, ATR 22.51$, beta 2.48,
secteur Technology ; `GET /api/labo/ZZZZZZINVALID` → 503 explicite (pas de
donnée inventée). Dans le navigateur (Browser pane) : bascule vers l'onglet
Labo, chargement des données réelles AMD, séquence « La Roue & Debit
Spreads » rendue avec zones de strike calculées (432.55$–455.06$ pour le
Put, 500.08$–522.59$ pour le Call), bascule vers « Poor Man's Covered Call
(PMCC) » → séquence différente rendue correctement (LEAPS ~382.06$, Call
court même zone), bascule vers « Iron Condor » → bandeau « bientôt
disponible » affiché, séquence vidée. Aucune erreur console JS. Serveur de
test arrêté après vérification — rien ne tourne en arrière-plan.

### Terminologie clarifiée (5/9/2026, questions de JP après premier essai)

JP a testé l'onglet et posé 4 questions qui ont révélé un vrai problème
d'utilisabilité, pas juste un manque de documentation : les termes
« LEAPS », « Delta cible », et le mot opaque « neutre » pour l'alignement
SMA n'étaient jamais expliqués dans l'app elle-même.

- **T0/T1 (LEAPS)** : LEAPS = *Long-term Equity AnticiPation Securities* —
  PAS un instrument différent d'un Call/Put, juste une option à échéance
  longue (9 mois à 2-3 ans). « LEAPS Call » = « Call à longue échéance ».
  Nouvelle entrée `leaps` dans `js/glossaire-indicateurs.js` (même popover
  `showGlossaire()` que les indicateurs techniques — réutilisé plutôt que
  dupliqué), bouton d'aide (i) posé sur chaque mention de LEAPS dans
  `js/strategies-labo.js`, et le titre de l'étape 2 du PMCC reformulé en
  verbe-sujet actif (« Acheter un Call à longue échéance (LEAPS)... ») pour
  matcher le style « Vendre un Put/Call... » déjà utilisé côté La Roue —
  c'était l'incohérence de formulation que JP pointait en T1.
- **T3 (Delta cible)** : nouvelle entrée `delta` dans le même glossaire —
  explique les deux sens usuels (sensibilité prix-pour-prix ET
  approximation de probabilité ITM), avec les deux cas d'usage réels de
  l'app (Put vendu à delta bas = probabilité OTM élevée ; LEAPS Call acheté
  à delta haut = comportement proche de l'action). Bouton d'aide posé sur
  chaque mention de « Delta cible » dans les deux stratégies.
- **T2 (validation de l'alignement SMA)** : le mot « neutre » à lui seul ne
  permettait pas à JP de vérifier le calcul. Deux ajouts : (1) la carte
  « Données réelles du titre » de l'onglet Labo affiche maintenant SMA9/
  SMA21/SMA100 en plus du prix (avec un texte rappelant la règle exacte —
  haussier si prix>SMA9>SMA21>SMA100 dans cet ordre, baissier l'inverse
  strict, neutre sinon — server/indicators.js) ; (2) la fonction
  `laboSmaDetail()` (`js/strategies-labo.js`) injecte ces mêmes 4 valeurs
  directement dans le texte de l'étape 1 du PMCC, pour que JP puisse
  vérifier l'ordre lui-même sans quitter la séquence. Réutilise la clé
  `sma` déjà existante du glossaire (bouton d'aide posé aussi ici).
- **DTE**, mentionné dans les deux stratégies sans être défini, est
  maintenant explicité en clair au premier usage de chaque stratégie
  (« DTE = jours restants avant l'échéance ») plutôt que laissé comme
  acronyme nu.

**Vérifié en direct** (fichiers statiques, pas de redémarrage serveur
nécessaire) : bouton (i) sur « LEAPS » et « Delta cible » ouvre le bon
popover (texte confirmé par lecture directe du DOM) ; carte de métriques
Labo affiche SMA9 469.28$/SMA21 475.59$/SMA100 466.56$ pour AMD avec
« neutre » correctement coloré en amber (`warn`) — cohérent avec l'ordre
réel (prix 477.57$ > SMA9 mais SMA9 < SMA21, donc pas haussier). Aucune
erreur console JS.

### Statique vs dynamique, Black-Scholes, SMA réellement configurables (5/9/2026, 3e passe — T1/T2/T3)

JP a testé une deuxième fois et posé 3 nouvelles demandes, plus profondes
que la première passe de clarification terminologique.

**T1 — distinguer visuellement le texte statique du texte dynamique.**
Exemple donné par JP : dans « Zone de strike estimée : 75,19 $ US –
78,02 $ US », seule la seconde partie doit se distinguer visuellement.
Nouvelle classe CSS `.labo-dyn` (accent, gras, chiffres tabulaires) et
fonction `laboDyn(texte)` (`js/strategies-labo.js`) qui l'enveloppe —
appliquée à CHAQUE valeur calculée à partir du ticker/des données chargées
dans les deux stratégies (prix, zones de strike, DTE, Delta, SMA, etc.),
jamais au texte de règle qui ne change pas d'un titre à l'autre.

**T2 — « pourquoi choisir 75,19 $ par exemple… » : aller plus loin sur
l'analyse.** Ce retour a révélé un vrai défaut de méthode, pas seulement un
manque d'explication : la version précédente calculait les zones de strike
par un multiple arbitraire de l'ATR (1 à 2×ATR), **sans AUCUN lien
mathématique** avec le Delta cible affiché juste à côté (ex. « Delta cible
0.15-0.25 » à côté d'un nombre qui n'avait jamais été calculé à partir
d'un delta). Corrigé en profondeur plutôt que rustiné :
- **Volatilité historique réelle du titre**, calculée serveur
  (`computeHistoricalVolatility()`, `server/indicators.js` — écart-type des
  rendements logarithmiques quotidiens sur 60 jours de bourse, annualisé
  ×√252), exposée par `GET /api/labo/:ticker` (champ `historicalVolatility`).
  **Avertissement central, documenté à 3 endroits** (code, config.js, UI) :
  c'est une volatilité **historique** (réalisée sur les prix passés), un
  PROXY de la volatilité **implicite** que le marché utilise réellement
  pour pricer les options (qui intègre les attentes futures — résultats
  trimestriels, etc. — que l'historique ne voit pas) — jamais présentée
  comme équivalente.
- **Black-Scholes minimal implémenté en JS pur** (`js/strategies-labo.js` :
  `laboNormCdf`/`laboNormInv` — approximation d'Abramowitz-Stegun pour erf,
  algorithme rationnel de Peter Acklam pour l'inverse — puis
  `laboStrikeForDelta()`, résout K tel que le delta Black-Scholes du strike
  ≈ le Delta cible réel de la stratégie). Remplace l'heuristique ATR : le
  strike affiché correspond maintenant VRAIMENT au delta annoncé, sous
  l'hypothèse de volatilité ci-dessus.
- **Panneau « Comment ces prix sont calculés » (Black-Scholes)**, un
  `<details>` natif sous chaque stratégie (`laboRenderAnalyse()`),
  entièrement déplié à la demande : montre Prix/Volatilité historique/Taux
  sans risque utilisés, la formule complète en clair, et pour chaque jambe
  (Put vendu, Call vendu, LEAPS acheté…) le d1 et le strike obtenus à
  CHAQUE borne du Delta — de quoi vérifier l'arithmétique à la main plutôt
  que de faire confiance à un chiffre opaque.
- Taux sans risque : nouvelle constante `CFG.labo.riskFreeRate` (4%,
  approximation — aucune source de taux en direct dans cette app).
  `CFG.labo.atrMultiplier` et `leapsProfondeurItmPct` retirés de
  `config.js` (devenus inutiles, l'ATR ne sert plus au calcul de strike du
  Labo — il reste utilisé ailleurs dans l'app, Fiche de trade/screening).
  `leapsDteTypiqueJours` (365 jours, ~1 an) ajouté pour donner un T concret
  au calcul Black-Scholes du LEAPS, distinct de `leapsDteMinJours` (180,
  le minimum annoncé dans le texte).

**T3 — rendre les périodes SMA 9/21/100 réellement configurables, visibles
en haut de l'écran.** En creusant cette demande, un vrai écart a été
trouvé : `CFG.indicateurs.smaRapide/Moyenne/Lente` (config.js) ne pilotait
QUE les libellés affichés — `getHomemadeIndicators()` calculait toujours
sur 9/21/100 en dur, peu importe ce que config.js contenait. Le commentaire
du fichier l'annonçait d'ailleurs lui-même (« informatif pour l'instant »),
mais ce n'était plus vrai depuis que les SMA sont calculées maison (pas
juste lues sur TradingView) — un écart de documentation devenu trompeur.
Corrigé pour l'onglet Labo spécifiquement (pas les autres écrans, qui
gardent 9/21/100 fixes pour l'instant — changement scopé à la demande
réelle) :
- `getHomemadeIndicators(symbol, { periods })` (`server/indicators.js`)
  accepte maintenant `{ fast, medium, slow }`, défaut 9/21/100 inchangé
  pour tous les appelants existants (screening, `/api/market-data`).
- `GET /api/labo/:ticker?smaFast=&smaMedium=&smaSlow=` (`server/index.js`)
  lit ces query params (validés positifs entiers, repli sur 9/21/100
  sinon) et les transmet ; la réponse échoue `smaPeriods` pour confirmer
  les valeurs réellement utilisées.
- 3 champs numériques ajoutés **tout en haut de l'onglet Labo**
  (`index.html`, avant même le sélecteur de stratégie), préremplis depuis
  `CFG.indicateurs` mais modifiables — `loadLaboTicker()` les lit et les
  passe en query params à chaque clic sur « Charger les données en
  direct ». Les libellés de la carte de métriques et du texte de séquence
  (`laboSmaDetail()`) affichent les périodes RÉELLEMENT utilisées
  (`data.smaPeriods`), pas une valeur supposée.

**Vérifié en direct** (serveur redémarré pour charger le code) :
`GET /api/labo/AMD` → volatilité historique 72.1% (titre volatil, plausible
pour AMD), zone de Put 387,15$–421,16$ pour Delta 0.15-0.25 (contre
432,55$–455,06$ avec l'ancienne heuristique ATR — les deux méthodes
divergent, ce qui confirme qu'elles ne mesuraient pas la même chose) ;
`GET /api/labo/AMD?smaFast=5&smaMedium=10&smaSlow=20` → SMA effectivement
recalculées sur ces nouvelles périodes (valeurs différentes de l'appel par
défaut, confirmées différentes à la décimale). Dans le navigateur : 15
valeurs `.labo-dyn` détectées dans la séquence PMCC ; panneau d'analyse
déplié montre le détail complet (d1, strike par jambe) pour les deux
stratégies ; champs SMA changés dans l'UI (5/10/20) → libellés de la carte
de métriques et texte de séquence mis à jour en conséquence
(« Alignement SMA 5/10/20 »). Aucune erreur console JS à aucune étape.
Serveur de test arrêté après vérification — rien ne tourne en
arrière-plan.

## Corrections UI Labo/Secteurs + relanceur React (5/9/2026, 4e passe)

Six demandes de JP : trois retouches d'utilisabilité dans le Labo, deux
ajouts dans l'onglet Secteurs, et un outil de secours pour ne plus dépendre
de Claude Code pour relancer castellana après une panne.

**T1 — ticker par défaut du Labo → TQQQ.** `CFG.labo.defaultTicker`
(`config.js`), distinct de `CFG.defauts.ticker` (AMD, utilisé par Secteurs/
Screener/Fiche de trade) — `applyConfig()` et le repli de
`renderLaboSequence()` (`index.html`) le lisent séparément.

**T2 — statique vs dynamique illisible dans "Données réelles du titre".**
Cause réelle trouvée : cette carte utilisait des `<span>`/`<strong>` bruts
au lieu des classes `.ds-metric__label`/`.ds-metric__value` du design
system (déjà utilisées correctement ailleurs, ex. Fiche de trade) — sans
ces classes, aucun style ne s'appliquait, d'où l'absence totale de
distinction visuelle. Corrigé par simple adoption des bonnes classes ;
`alignEl.className` (JS) corrigé au passage — il écrasait
`ds-metric__value` par `ok`/`warn`/`bad` au lieu de les cumuler.

**T3 — les 3 champs SMA pas au même niveau.** Cause réelle : `.row label`
donne 260px au premier label, les deux labels suivants portaient un
`style="width:auto"` en ligne — largeurs incohérentes, le premier champ
finissait sur sa propre ligne. Remplacé par `.labo-sma-params` (grille 3
colonnes égales, label au-dessus du champ) dédiée, plutôt que de rafistoler
`.row`.

**T4/T5 — fusion Force relative + Golden Cross dans "Ticker", + fondamentaux
(OBV/Volume/Float/P/E/Industrie/P-E industrie/PEG/Beta/VWAP).** Scopé
UNIQUEMENT à l'onglet **Secteurs** (demande explicite de JP) — l'onglet
Screener garde sa disposition en 3 cartes séparées, les deux onglets restent
donc volontairement différents désormais (avant cette session ils étaient
identiques par construction). `GET /api/market-data/:ticker`
(`server/index.js`) gagne une 4ᵉ branche `Promise.allSettled` :
`getFundamentals(ticker, {withVwap:true})`. Le "P/E industrie" pour un
ticker hors watchlist (ex. saisir un titre non suivi) est calculé depuis le
**dernier screening en cache** (`industryPeerStatsFromScreeningCache()`) —
pas un nouveau batch de 20 appels Yahoo à chaque clic ; affiche `—`/0 pair
si aucun screening n'a encore tourné, jamais un chiffre inventé. Nouveau
`renderSecFundamentals()` (`index.html`) peuple la grille `.grid-3` (9
tuiles `.ds-metric`), réutilise `fmtVolume()`/`fmtFloat()`/`obvBadge()` déjà
écrits pour le tableau de screening plutôt que de les redéfinir.

**T6 — outil de relance (`launcher/`), en React, indépendant de
castellana.** Contexte : plusieurs sessions consécutives où JP devait
demander à Claude Code de relancer manuellement le serveur/sidecar après
une panne ou un redémarrage du Mac — aucun mécanisme ne permettait de le
faire soi-même sans terminal. Décision d'architecture explicitée avec JP
au préalable (`AskUserQuestion`, dismissée puis reformulée directement en
"une appli React pour castellana") : outil **séparé**, pas une extension du
mécanisme de relance déjà existant de bilbao (R9a/R9b, actuellement scopé à
valencia) — le mot "React" et le nom explicite "castellana" tranchaient la
question.

Contrainte de conception centrale : cet outil doit rester lui-même stable
et disponible précisément quand castellana ne l'est plus — il tourne donc
sur son **propre port (4750)**, totalement indépendant du serveur Express
de castellana (4700) et de son sidecar (4701).
- `launcher/server.js` — **zéro dépendance npm** (`node:http`, pas Express
  — un framework de plus est une source de panne de plus pour l'outil censé
  nous sortir de la panne), lié à **127.0.0.1 uniquement** (même garde que
  castellana). `GET /api/status` (TCP connect sur les 2 ports),
  `POST /api/restart` (`{target: 'node'|'sidecar'|'both'}`) — cible
  toujours parmi 2 valeurs fixes, jamais une commande/un chemin arbitraire
  venant de la requête (les commandes réelles sont codées en dur, ports lus
  depuis le vrai `../settings.json` pour ne pas diverger). Tue via
  `lsof -ti:PORT -sTCP:LISTEN` puis `spawn(..., {detached:true}).unref()`.
- `launcher/public/index.html` — React 18 UMD (CDN), **sans JSX ni Babel**
  (composants écrits avec `React.createElement` directement) — page unique,
  aucune étape de build, cohérent avec la discipline zéro-dépendance du
  reste du portfolio pour ce type d'outil (coimbra). 3 boutons (Node,
  sidecar, les deux), statuts en direct (poll 10s), journal des actions,
  lien direct vers castellana une fois les deux services actifs.

**Bug réel trouvé et corrigé en testant** (pas en relisant le code) :
`killPort()` utilisait `lsof -ti:PORT` sans `-sTCP:LISTEN` — cette commande
matche aussi les connexions **clientes** vers ce port, pas seulement le
process qui l'écoute en serveur. Comme `server/tradingview.js` (castellana)
ouvre une connexion cliente sortante vers le sidecar sur le port 4701,
cliquer "Relancer le sidecar" tuait **aussi** le serveur Node de castellana
lui-même — repéré uniquement parce que le journal de l'outil listait le PID
du serveur Node parmi les PID "arrêtés" d'une relance du sidecar seul.
Corrigé (`-sTCP:LISTEN` ajouté), reproduit et re-vérifié après correction :
relancer le sidecar seul, puis le serveur Node seul, ne perturbe plus
l'autre service dans un sens comme dans l'autre.

**Vérifié en direct, de bout en bout** : les 4 corrections UI (T1-T5)
vérifiées dans le navigateur (Browser pane) et par lecture directe du DOM ;
le relanceur testé avec de VRAIS kill/respawn (pas des mocks) — relance
Node seul (ancien PID tué, nouveau confirmé répondant), relance sidecar
seul (après correction du bug ci-dessus, confirmé n'affecte plus le
serveur Node), relance des deux ensemble, et rejet propre en 400 d'une
cible invalide (testé avec une chaîne `"rm -rf /"` comme cible — confirme
qu'aucune commande arbitraire ne peut être injectée, la cible est toujours
validée contre l'enum fixe avant tout `exec`/`spawn`). **Laissé actif** au
port 4750 — c'est tout l'intérêt de l'outil, JP peut l'utiliser directement
via `http://127.0.0.1:4750` sans repasser par une session Claude Code.

## Contexte, plages configurables, refactor partagé, onglets Réglages (6/9/2026, 5e passe)

Huit demandes de JP après avoir utilisé les corrections de la 4e passe.

**T1 — bannière "un signal sur deux" pas assez explicite.** `calcSelectionFor()`
(`index.html`) nomme désormais explicitement lequel des deux signaux
(Force relative / Golden Cross) est positif et lequel ne l'est pas, plutôt
que « un signal positif sur deux » sans préciser lequel. Précise aussi que
le ticker affiché est simplement celui saisi dans « Ticker évalué » — pas
une recommandation automatique de l'app (réponse à « pourquoi présenter
TGT ? »).

**T2 — libellé "Devise" pas assez explicite.** Clarifié avec JP avant de
coder (le renommer en "Secteur" aurait rendu la phrase incohérente,
"Secteur : USD / CAD") : l'intention réelle était de préciser qu'on choisit
la devise des **ETF sectoriels** proposés, pas de renommer le concept.
Libellé → « Devise des ETF sectoriels (USD ou CAD) : ».

**T3/T4 — période de référence et indice de référence non précisés.**
Chaque valeur de la grille "Fondamentaux" (carte Ticker, onglet Secteurs)
porte maintenant sa période : OBV (tendance, 10j), Volume (jour), P/E
(trailing), Beta (5 ans), VWAP (séance en cours) — voir
`js/ticker-section.js`. Section "Force relative" renommée
« Force relative vs indice de référence (S&P 500 — SPY) », et le champ
"Performance de l'indice" précise directement "Performance du S&P 500
(SPY)" — l'indice de référence (SPY, en dur dans `server/tradingview.js`
et `js/ticker-section.js`) n'était mentionné nulle part dans l'UI
auparavant. Le champ "Performance du titre" précise aussi que la valeur
récupérée en direct est celle du **jour** (Yahoo `change_pct`), pas une
période arbitraire, tout en restant éditable à la main pour une autre
période si JP le souhaite.

**T5/T6 — plages Prix/Float des filtres du Screener pas explicites, pas
configurables.** Les filtres "Volume > 1M"/"PEG ≤ 1"/"Beta > 1" affichaient
déjà leur seuil ; "Prix dans la plage" et "Float dans la plage" ne
disaient pas laquelle. Ajouté en haut de "Filtres supplémentaires" : deux
paires de champs (`filter-prix-min/max`, `filter-float-min/max`),
préremplis depuis `CFG.screening` (`initScreenFilterRanges()`) mais
**réellement modifiables en direct** — `applyScreenFilters()` recalcule
`passPrix`/`passFloat` CÔTÉ CLIENT à partir de `row.price`/`row.floatShares`
(déjà présents dans chaque ligne) plutôt que de rejouer un screening
complet ; les 4 autres filtres restent sur leurs seuils fixes calculés
côté serveur (non demandés configurables). Libellés des cases à cocher
mis à jour en direct (`updateFilterRangeLabels()`) pour toujours refléter
la plage actuellement configurée.

**T7 — dupliquer la section "Ticker" entre Secteurs et Screener n'est plus
tenable, propose un mécanisme.** La carte "Ticker" de Secteurs a grossi
(fusion Force relative/Golden Cross + 9 champs fondamentaux, 5/9/2026)
pendant que celle de Screener restait plus simple — les deux étaient
écrites à la main dans `index.html`, donc vouées à diverger à la prochaine
retouche oubliée d'un côté. Nouveau `js/ticker-section.js` :
`tickerSectionHTML(instanceKey, {withFundamentals})` génère le markup
complet, `renderTickerSectionInto(instanceKey, options)` l'injecte dans
`#${instanceKey}-ticker-card` — appelé une fois par instance
(`renderTickerSectionInto('sec', {withFundamentals:true})` /
`('scr', {withFundamentals:false})`) avant `applyConfig()`. Les deux
cartes `sec-ticker-card`/`scr-ticker-card` dans `index.html` sont
maintenant des conteneurs vides ; `calcSelectionFor()`/
`fetchLiveSelectionFor()` n'ont pas changé (mêmes IDs générés,
`${instanceKey}-xxx`, cohérent avec `SELECTION_INSTANCES` déjà existant).
Un futur ajout à cette section se fait donc UNE fois, dans le template,
et s'applique aux deux onglets (ou à un seul, via l'option
`withFundamentals`).

**T8 — onglets dans "Réglages".** Panneau Réglages réorganisé en 2 onglets
internes (`.settings-tab-btn`/`.settings-tab-panel`, mécanisme séparé de
`switchTab()` pour ne pas interférer avec les onglets principaux de
l'app) : **Technique** reprend tel quel le contenu de dépannage existant
(Backend/Sidecar/BD), plus une nouvelle carte pointant vers l'outil de
relance (`launcher/`, port 4750). **Valeur personnalisée** est un espace
réservé, vide pour l'instant (aucun réglage éditable directement dans
l'app aujourd'hui — tout reste dans `config.js`) — JP n'a pas précisé ce
qui doit y aller, cet onglet prépare juste la structure pour de futurs
réglages éditables sans passer par un fichier.

**Vérifié en direct** (fichiers statiques, pas de redémarrage serveur —
aucun changement backend ce tour-ci) : bannière T1 testée en forçant un
scénario "1 signal sur 2" (TGT, Force relative positive/Golden Cross
absent) → message nommant explicitement les deux ; carte Fondamentaux
confirmée identique fonctionnellement après le refactor T7 (P/E
industrie, VWAP, etc. toujours peuplés) ; `sec-ticker-card` contient bien
les champs fondamentaux, `scr-ticker-card` non à ce moment-là (options du
template respectées — **revu le lendemain, voir juste en dessous**) ;
plages Prix/Float testées avec de fausses lignes (AAA à 50$ dans
[10$,100$] → non atténuée, BBB à 500$ → atténuée, recalcul confirmé après
changement des bornes) ; onglets Réglages testés (bascule Valeur
personnalisée ↔ Technique, contenu technique intact). Aucune erreur
console JS à aucune étape.

## Bornes Prix/Float resserrées + standard "Ticker" unifié (6/9/2026, 6e passe)

Deux demandes le lendemain de la 5e passe, en usage réel de l'app.

**Nouvelles bornes par défaut des filtres Screener** (JP, univers suivi
visiblement plus small/mid-cap que prévu à l'origine) : Prix 5$-1000$
(était 1$-10000$), Float 10M-20M actions (était 0-100000M). Mis à jour aux
DEUX endroits qui doivent rester synchronisés (pas de format de module
commun entre le `<script>` classique et le backend ESM, voir le
commentaire déjà en place) : `CFG.screening` (`config.js`) et
`SCREEN_FILTERS` (`server/index.js`). Comme ces plages sont maintenant
éditables en direct depuis l'UI (T5/T6, 5e passe), ces valeurs ne sont que
le point de départ affiché à l'ouverture — JP peut toujours les ajuster
sans redémarrer le serveur.

**"Ticker" doit être identique dans Secteurs ET Screener** — revirement
sur la décision du 5/9/2026 (qui scopait volontairement les fondamentaux à
Secteurs seul). JP a remarqué l'incohérence en utilisant l'app et a
tranché : même standard partout. Grâce au refactor T7 de la 5e passe
(`js/ticker-section.js`), ce changement tient en **une ligne** —
`renderTickerSectionInto('scr', {withFundamentals:false})` →
`{withFundamentals:true}` — exactement la promesse du refactor (« un futur
ajout se fait une fois, dans le template »). Seul ajustement de code
supplémentaire nécessaire : `renderSecFundamentals(m)` (nommée pour
l'instance `sec` uniquement) généralisée en
`renderFundamentalsFor(instanceKey, m)`, appelée sans condition
`instanceKey === 'sec'` dans `fetchLiveSelectionFor()` — sinon `scr`
aurait eu les tuiles vides à l'affichage mais jamais peuplées au clic sur
« Récupérer en direct ».

**Vérifié en direct** : serveur redémarré (changement backend
`SCREEN_FILTERS`) — `/api/screening` confirme des flags `passPrix`/
`passFloat` calculés sur les nouvelles bornes (5-1000$, 10-20M) ; champs
`filter-prix-min/max`/`filter-float-min/max` préremplis à 5/1000/10/20
côté UI. `fetchLiveSelectionFor('scr')` sur AMD peuple bien
`scr-m-obv`/`scr-m-volume`/`scr-m-pe` (confirmé par lecture DOM,
identique à `sec`). Aucune erreur console JS.

## Télémétrie testeurs (6/9/2026)

JP veut mettre castellana dans les mains de 2 testeurs. Trois décisions
prises avec lui (`AskUserQuestion`, plusieurs tours) avant de coder :

1. **Hébergement de l'app** : chacun lance castellana en local, comme JP
   (réutilise [SETUP.md](SETUP.md), déjà écrit le 30/8 pour l'onboarding
   d'un collègue). **Aucun hébergement partagé** — castellana reste 100%
   locale, comme documenté partout ailleurs dans ce fichier.
2. **JP a demandé si l'app entière pouvait aller sur Cloudflare** (il y a
   déjà un compte) — **réponse : pas telle quelle**. Castellana a 3 choses
   incompatibles avec le modèle Workers (assets statiques, patron déjà
   utilisé par barcelona/porto/essen-hub) : un process Express persistant,
   `better-sqlite3` (module natif compilé), et le sidecar Python
   `tradingview-mcp` — Workers ne supporte ni process long-terme, ni
   module natif, ni Python. Un vrai portage existerait (Cloudflare D1 à la
   place de better-sqlite3, routes réécrites en handlers Workers,
   abandon du sidecar Python) mais c'est un chantier séparé et important,
   **pas fait cette session** — JP a choisi de garder l'app locale plutôt
   que d'ouvrir ce chantier maintenant.
3. **Identité pour la télémétrie** : un sélecteur de nom + l'IP capturée
   côté serveur, en complément l'un de l'autre — **pas un login** (T3
   explicitement reporté à plus tard, mais le sélecteur sert de socle pour
   quand ce sera construit).

**Architecture retenue** : comme l'app tourne en local chez chaque
testeur, aucune vue d'ensemble n'est possible sans un point de collecte
externe. Un petit **Cloudflare Worker + D1** (`telemetry-worker/`) reçoit
les événements directement du navigateur de chaque testeur — **`server/
index.js` n'est pas impliqué, aucune route ajoutée côté backend local**.
C'est le premier Worker du portfolio avec du vrai code serveur (`main`) et
une base D1 — tous les autres Workers du portfolio (barcelona/porto/
essen-hub) ne servent que des assets statiques. **Conséquence à retenir** :
c'est **le premier élément de castellana jamais déployé publiquement**,
mais seulement ce collecteur — l'app elle-même reste locale.

**3 types d'événements, correspondant exactement aux 4 demandes de JP**
(ticker sélectionné, paramètres modifiés, quand, qui) :
- `app_loaded` — un par chargement de page (qui + quand, horodatage
  serveur pas client, pour rester fiable même si l'horloge d'un testeur
  dérive).
- `ticker_selected` — `{tab, ticker, instance}`. **Pas un `oninput`
  générique** (trouvé en explorant le code : `calcSelectionFor()`/
  `calcFiche()` tournent sur beaucoup de champs non liés au ticker,
  auraient noyé le signal) — hooké sur 4 points d'action réellement
  significatifs à la place : fin de `fetchLiveSelectionFor(instanceKey)`
  (couvre à la fois le bouton « Récupérer en direct » ET les clics de
  ligne `selectScreeningRow`/`selectSectorTopRow`, qui l'appellent en
  interne), fin de `fetchLiveFiche()`, succès de `saveTrade()` (Journal),
  succès de `loadLaboTicker()` (Labo). Les 5 onglets sont donc couverts.
- `param_changed` — `{param, tab, oldValue, newValue}`. Instrumente
  uniquement les **9 champs réellement modifiables à l'exécution**
  (`#atrmult`, `#riskpct`, `#capital`, les 4 bornes de filtre Screener,
  les 3 champs SMA du Labo) — trouvé en explorant `config.js` que la
  grande majorité de ses valeurs ne pilotent que des libellés/valeurs par
  défaut, jamais éditées par l'utilisateur (donc rien à instrumenter
  là-dessus). Écoute sur l'événement `change` (pas `input`), pour ne pas
  spammer à chaque pixel de glissement d'un slider.

**Fichiers** :
- `js/telemetry.js` (nouveau) — `sendTelemetryEvent()`, `trackTickerSelected()`
  (dédoublonné par onglet), `initParamTelemetry()`, `initIdentityPicker()`
  (injecte un `<select class="ds-select">` dans `.status-bar`, persisté en
  `localStorage`), `initTelemetry()` (point d'entrée, appelé une fois à la
  fin de l'init de `index.html`, après `renderTickerSectionInto()`/
  `applyConfig()`/`initScreenFilterRanges()` pour que les champs suivis
  existent déjà). Fire-and-forget total : `try/catch` silencieux, jamais de
  blocage UI ni d'erreur visible si le Worker est injoignable ou pas encore
  déployé (`CFG.telemetry.endpoint` vide au premier lancement).
- `config.js` — section `CFG.telemetry` (`enabled`, `endpoint` — vide tant
  que JP n'a pas déployé le Worker —, `sharedToken`, `testeurs`).
- `telemetry-worker/` (nouveau composant déployé, hors app) — Worker natif
  (`fetch(request, env)`, zéro framework), 3 routes : `POST /events`
  (ingestion, jeton requis), `GET /events.csv?token=` (export, même patron
  d'échappement que `GET /api/screening.csv`/`GET /api/trades.csv`),
  `GET /dashboard?token=` (tableau HTML des 200 derniers événements, pour
  consulter sans repasser par `wrangler d1 execute`). D1 : table unique
  `telemetry_events` (voir `schema.sql`). Voir
  [`telemetry-worker/README.md`](telemetry-worker/README.md) pour les
  commandes de déploiement exactes.
- `index.html` — `<script src="js/telemetry.js">`, conteneur
  `#who-picker` dans `.status-bar`, `initTelemetry()` ajouté à la séquence
  d'init de fin de fichier, 4 appels `trackTickerSelected(...)` insérés
  dans les fonctions listées ci-dessus. **`server/index.js`/`server/db.js`
  non touchés.**

**Sécurité — volontairement limitée, documentée comme telle** :
`CFG.telemetry.sharedToken` (dupliqué à la main dans
`telemetry-worker/wrangler.jsonc`, aucune synchronisation automatique,
même limite déjà documentée pour `SCORE_BANDS`/`SCREEN_FILTERS`) n'est
**pas** une vraie authentification — juste un filtre anti-bruit pour
qu'un bot qui découvrirait l'URL publique du Worker ne pollue pas la
base. Il est visible dans le code source du navigateur par construction.
Le champ « who » est une auto-déclaration (pas un login), l'IP capturée
côté Worker est un complément, pas une preuve d'identité — cohérent avec
le report explicite de T3 (vrai login) à plus tard.

**Non fait cette session** (hors scope, confirmé avec JP) : aucun vrai
login, aucun changement à l'hébergement de l'app, aucune route ajoutée au
serveur Express local.

**Worker déployé le 6/9/2026** (session suivante) —
https://castellana-telemetry.iechocreator.workers.dev. `wrangler login`
(OAuth navigateur, complété par JP), `wrangler d1 create` (id
`3647b572-e88e-45c1-9401-df62e5e46e12`), schéma appliqué en `--remote`,
`wrangler deploy`. `CFG.telemetry.endpoint` mis à jour en conséquence.
**Testé en direct** : `POST /events` avec le bon jeton → 200 + ligne
insérée (confirmée via `/dashboard` et `/events.csv`) ; avec un mauvais
jeton → 401 ; ligne de test retirée de la base après vérification
(`DELETE FROM telemetry_events WHERE who = '...'`) pour ne pas polluer les
vraies données des testeurs.

**Tableau de bord enrichi (7/9/2026)** — JP a demandé de pouvoir
« récupérer la télémétrie et en faire un dashboard ». Décision : enrichir
directement la route `/dashboard` déjà déployée (accès direct à D1, pas de
CORS/latence) plutôt qu'un Artifact Claude (**écarté** : le pare-feu réseau
des Artifacts bloque tout `fetch()` vers un hôte externe comme ce Worker —
impossible d'y afficher des données en direct depuis cette source) ou un
nouvel outil séparé. Skill `dataviz` du portfolio consultée avant d'écrire
le SVG à la main (palette catégorielle slot 1 bleu, mode sombre — voir
`references/palette.md` du skill).

Ajouté à `handleDashboard()` (`telemetry-worker/src/index.js`) :
- **Filtre par testeur** + **plage de jours** (7/30/90, défaut 30) — un
  formulaire GET classique (pas de JS de filtrage côté client), qui scope
  les 2 graphiques et le tableau détaillé en une seule requête cohérente.
- **Activité par jour** — barres verticales (une série, magnitude dans le
  temps), `json_extract` non nécessaire ici (`substr(created_at,1,10)`
  pour grouper par jour). Pas de valeur affichée sur chaque barre (jusqu'à
  90 barres selon le filtre) — info-bulle au survol + graduations Y
  portent le détail, conforme à la règle du skill (« jamais un nombre sur
  chaque point »).
- **Tickers les plus sélectionnés** — barres horizontales classées,
  `json_extract(payload_json,'$.ticker')` filtré sur
  `event_type='ticker_selected'`, top 15. Valeur affichée au bout de
  chaque barre ici (liste courte, contrairement au graphique quotidien —
  labelliser reste lisible).
- Info-bulle au survol (JS minimal, `pointermove`/`pointerleave`,
  `textContent` — jamais `innerHTML` — pour les valeurs qui viennent de
  données utilisateur comme le nom du testeur ou le ticker).

**Bug réel évité en testant, pas juste en relisant le code** : le premier
lot de données de test envoyé via `curl` (12 événements JP/Louis/
Guillaume) partageait tous le même horodatage serveur (`new Date()` au
moment de l'insertion), donc le graphique « activité par jour » n'aurait
montré qu'une seule barre — insuffisant pour vérifier visuellement un
graphique à plusieurs jours. Corrigé en insérant un second lot directement
en SQL (`INSERT ... VALUES` avec des `created_at` explicites sur 5 jours
différents) pour un test visuel réaliste.

**Découverte en testant, pas anticipée** : la base contenait déjà de la
**vraie télémétrie** (7 événements, `user_agent` Chrome/macOS réel,
IP réelle) — JP avait dû utiliser castellana pour de vrai après le
déploiement de la session précédente. Le nettoyage post-test a donc dû
être chirurgical : `DELETE FROM telemetry_events WHERE id >= 9` (ciblant
précisément les données de test insérées cette session), **en préservant**
les 7 événements réels antérieurs (ids 2-8) plutôt qu'un nettoyage global
qui les aurait détruits — un `DELETE FROM telemetry_events` sans clause
aurait été une perte de données réelle, pas juste de bruit de test.

**Vérifié en direct dans le navigateur** : filtre par testeur (isolé sur
`inconnu` → 2 événements, état vide correct sur le graphique tickers —
« Aucun ticker sélectionné sur cette période », jamais un graphique
vide sans explication) ; info-bulle au survol sur les deux graphiques
(barre quotidienne → « 7 — 2026-09-06 », barre ticker → « 1 — TQQQ ») ;
aucune erreur console. Redéployé (`wrangler deploy`), URL inchangée.

## Refonte de fiabilité et d'installation (7/9/2026, 2e session)

Point de départ : un audit de l'app en marche, commandé par JP avec l'objectif
explicite de « mettre ce produit dans les mains de personnes sérieuses ».
8 constats (F1→F8) et un budget de requêtes mesuré. Plan approuvé via
`EnterPlanMode`/`ExitPlanMode` (`~/.claude/plans/robust-honking-yeti.md`).

### Le constat structurant, revérifié avant d'y toucher

L'audit affirmait que le sidecar Python ne fournit rien d'irremplaçable.
**Revérifié en direct contre le sidecar en marche**, d'abord sur AMD puis sur
les 21 titres de la watchlist (`rsi`/`sma50`/`sma200`/`goldenCross`, maison
vs `coin_analysis`) : **aucun écart au-delà de l'arrondi**. Mieux — PLTR et
XEQT.TO, que le sidecar ne résout pas du tout, ressortent maintenant
complets. C'est le taux d'échec de 14 % relevé par l'audit, tombé à 0.

**Décision de JP** : le sidecar n'est pas supprimé, il devient **optionnel et
désactivé par défaut** (`settings.tradingviewMcp.enabled`, défaut `false`).
Il reste branchable pour comparer les deux sources.

### Ce qui a changé, par constat

| | Constat | Traitement |
|---|---|---|
| **F1** | Session MCP jamais invalidée : un sidecar redémarré restait mort jusqu'au redémarrage d'Express | `clientPromise` jeté au premier échec de **transport** (pas sur une erreur métier « No data found », où la session est saine). Corrigé bien que le sidecar soit désormais éteint par défaut |
| **F2** | Rien ne surveille les processus | Watchdog dans `launcher/server.js` : sondage 15 s, relance automatique, **backoff** et **plafond de 5 tentatives** pour ne pas boucler sur une panne permanente, compteur remis à zéro dès que le service répond, journal consultable. Bascule via `POST /api/watchdog` |
| **F3** | Aucun retry, aucun timeout nulle part | `server/fetch-retry.js` — `withRetry` (2 tentatives, backoff, temporisation 10 s) sur **tous** les appels externes, + `mapWithConcurrency` |
| **F4** | Rate-limit TradingView en usage normal | Sans objet sur le chemin par défaut : plus aucun appel au scanner |
| **F5** | PLTR bloqué sur `exchange: NYSE` (migré au NASDAQ en 2024) | Corrigé dans le seed **et** dans la base déjà semée de JP (le seed seul n'aurait rien changé chez lui). Sans effet sur le chemin par défaut, Yahoo résolvant le ticker sans bourse |
| **F6** | Les cotations transitaient par le sidecar | `server/quotes.js` — Yahoo direct, **requête groupée** (1 appel pour 21 titres + SPY) |
| **F7** | `/api/screening` accusait « tradingview-mcp injoignable » quelle que soit la cause | `Promise.allSettled` + `passErrors` : chaque passe rapporte son propre échec, comme le fait déjà `/api/status` |
| **F8** | Caches en mémoire, perdus à chaque redémarrage | `server/cache.js` — cache persistant en SQLite. Les deux caches mémoire (`screeningCache`, `sectorTopCache`) ont disparu |

### Deux recommandations de l'audit corrigées en les mesurant

1. **`node:sqlite` n'est pas utilisable ici.** L'audit recommandait de
   remplacer `better-sqlite3` pour supprimer la compilation native. Sur le
   Node **v22.12.0** de JP, `require('node:sqlite')` échoue (`No such
   built-in module`) : il faut `--experimental-sqlite`, avec une API
   annoncée instable. Et `better-sqlite3@11.10` installe via
   `prebuild-install || node-gyp rebuild` — il **télécharge un binaire
   précompilé** et ne compile qu'en dernier recours. Le remède était pire
   que le mal. **`better-sqlite3` conservé** ; `npm run doctor` teste
   désormais son chargement réel et donne le remède exact s'il échoue.
   À revoir quand Node 24 sera la base.
2. **Les TTL longs auraient figé des prix.** Le plan prévoyait 12 h pour un
   historique quotidien et 24 h pour un bêta. Faux dans les deux cas : la
   **dernière barre** d'un historique quotidien est celle du jour en cours,
   encore en mouvement, et `quoteSummary` mêle dans un seul objet des champs
   trimestriels et des champs intrajournaliers. Servir un prix figé à un
   outil de trading est bien pire que d'être lent. TTL courts partout où la
   réponse contient un champ intrajournalier — avertissement en tête de
   `server/cache.js`, à ne pas « rétablir » par inadvertance.

### Installation

- **Python sort du chemin par défaut.** `demarrer.command`/`demarrer.bat`
  n'installent plus de venv. Deux nouveaux scripts `installer-sidecar.*`
  l'installent pour qui le veut (avec confirmation, et bascule automatique de
  `enabled` à `true`). **223 Mo → 53 Mo, 2 prérequis → 1.**
- **Version de Node vérifiée** (≥ 20), pas seulement sa présence.
- **Repli de port** : 4700 puis 4711-4715, avec le port retenu écrit dans
  `data/runtime.json`. Un port occupé produisait avant un `EADDRINUSE` non
  intercepté — sous Windows, la fenêtre se refermait sans explication. Les
  lanceurs **attendent ce fichier** au lieu d'un `sleep` fixe, et ouvrent le
  navigateur sur la bonne adresse.
- **`npm run doctor`** (`scripts/doctor.mjs`, zéro dépendance, tourne avant
  `npm install`) : Node, dépendances, module natif, droits d'écriture, port,
  Yahoo. Chaque ligne en échec porte son remède.
- **Gatekeeper** : `demarrer.command` lève lui-même la quarantaine du reste
  du dossier une fois autorisé. Le clic droit → Ouvrir reste nécessaire pour
  lui-même — sans compte Apple Developer, il n'y a pas d'échappatoire.
  **⚠️ Toujours pas testé avec un vrai téléchargement navigateur.**

### Bandeau de version et mise à jour en un clic

Le zip devenait périmé **en silence** : un testeur n'avait aucun moyen de
savoir que sa copie datait. Ajouté : `version.json` estampillé par
`npm run package`, route `/version` sur le Worker de télémétrie déjà déployé
(publique, sans jeton), bandeau dans l'app, et bouton **Mettre à jour**.

`server/update.js` est **le code le plus risqué de l'app** — il réécrit
l'application pendant qu'elle tourne. Garde-fous, à ne pas alléger : tout est
téléchargé, extrait et **vérifié dans un dossier de travail** avant que quoi
que ce soit ne bouge ; la bascule n'est **que des renommages** ; `data/`,
`node_modules/` et `settings.json` ne sont **jamais** touchés ; l'ancienne
version est conservée dans `data/.update/backup-<horodatage>`.

⚠️ **`PUBLISHED_VERSION` (telemetry-worker/wrangler.jsonc) doit être bumpé à
la main** en même temps que `version` dans `package.json`, à chaque
publication d'un zip — rien ne synchronise les deux (même limite déjà
documentée pour `TELEMETRY_TOKEN`). Publier un zip sans toucher à cette
variable laisse simplement les testeurs sur leur version : silencieux, pas
cassé.

**Worker redéployé le 7/9/2026** (`wrangler deploy`, version
`da7148df-fc65-408c-874c-0b4ddb5fdd26`) : la route `/version` répond en
ligne, publiquement et sans jeton. Vérifié après coup que `/events.csv` et
`/dashboard` refusent toujours une requête sans jeton (401), et que les
**31 événements de télémétrie réels ont survécu** — un déploiement ne touche
pas D1. `PUBLISHED_VERSION` vaut 1.0.0, soit la version installée : aucun
bandeau de mise à jour n'est donc proposé, ce qui est le comportement voulu
tant que le zip n'est pas publié sur iecho.ca.

### Télémétrie d'erreurs

4ᵉ type d'événement (`error`), branché sur `fetchJSON()` — le point de
passage unique de tous les appels API du frontend. Dédoublonné par
(route + message). N'envoie que la route et le message : **aucune donnée de
marché, aucun trade, aucun montant**. JP voit désormais quand un testeur
heurte un mur, au lieu de l'apprendre par message.

### Vérifié en direct cette session

- **Comparaison maison vs sidecar sur les 21 titres** : 0 écart (tableau
  complet dans la sortie de session).
- **Screening chronométré** : 37 s → **1,99 s** à froid, 0,37 s données en
  cache, 0,023 s screening en cache. **21/21 titres sans trou**, `passErrors`
  vide.
- **Cache persistant** : 65 entrées, screening et export CSV toujours servis
  **après un redémarrage du serveur** (l'export répondait 409 avant).
- **Retry/timeout/parallélisme** : échec puis succès, temporisation qui rend
  la main sur un appel qui ne revient jamais, 12 tâches de 100 ms en 204 ms
  avec une limite de 6.
- **Watchdog** : castellana **réellement tué**, détecté, relancé
  automatiquement, récupération confirmée (journal à l'appui).
- **Repli de port** : 4700 occupé → bascule sur 4711 annoncée + `runtime.json`.
- **Mise à jour, sur une copie jetable**, trois cas : archive tronquée →
  refus, rien modifié, journal intact ; archive qui n'est pas castellana →
  refus, rien modifié ; **vraie mise à jour 1.0.0 → 1.0.1** → version
  basculée, fichier nouveau présent, **sentinelle du journal de trades
  intacte**, `node_modules` préservé, sauvegarde de 22 entrées récupérable,
  processus arrêté puis redémarré en 1.0.1.
- **Navigateur** : 5 onglets, pastille sidecar **grise** (désactivé, pas
  rouge), 21 lignes au Screener avec **PLTR et XEQT.TO complets**, secteurs,
  Labo, Journal, bandeau de mise à jour rendu avec son bouton. **Aucune
  erreur console.**
- **`npm test` : 32/32** (7 auparavant).

### Deux erreurs faites et corrigées en cours de route

1. **Suppression accidentelle d'un bloc d'`index.js`** : une ancre de
   remplacement (`try { const watchlist = getWatchlist();`) matchait
   `/api/sectors` avant `/api/screening`, emportant tout ce qui se trouvait
   entre les deux. Repéré par un crash au démarrage (`screeningCache is not
   defined`), restauré depuis git, réappliqué avec des ancres relatives à la
   route, puis **vérifié par un diff de la liste des routes contre HEAD** —
   identiques.
2. **Un test faux, pas un code faux** : j'avais écrit que le RSI de Wilder
   vaut exactement 50 sur une alternance +1/-1. C'est vrai de l'**amorce**
   seulement ; au-delà, le lissage oscille autour de 50 et la dernière
   variation décide du côté. Test corrigé (égalité exacte sur `period+1`
   clôtures, encadrement sur la série longue), code inchangé.

Au passage, un **vrai bug trouvé par un test** : `readCache` utilisait
`age > ttl`, ce qui servait une entrée pile à son TTL — avec un TTL de 0
(« ne jamais mettre en cache »), l'entrée était servie tant qu'on la relisait
dans la même milliseconde. Corrigé en `>=`, ici et dans `purgeExpiredCache`.

### Non fait, et à savoir

- **Rien n'a été testé sur une vraie machine Windows** — `demarrer.bat` et
  `installer-sidecar.bat` sont vérifiés par lecture de code et cohérence avec
  leurs équivalents macOS uniquement. Limite déjà connue et inchangée.
- **Gatekeeper non testé avec un vrai téléchargement navigateur.**
- ~~Le zip n'a pas été publié sur iecho.ca~~ — **publié le 7/9/2026 en
  version 1.1.0**, voir la section « Publication de la 1.1.0 » plus bas.
- La `getFundamentals` mêle toujours champs lents et intrajournaliers dans un
  seul appel : les séparer permettrait un cache 24 h sur bêta/flottant/
  secteur, au prix d'un appel réseau de plus par titre. Non fait, gain jugé
  nul au vu des temps mesurés.


## Feature 351 — correctifs (7/9/2026)

Lot de 4 points relevés par JP après la refonte de fiabilité.

### 1 et 2 — « Unexpected token '<', "<!DOCTYPE "... is not valid JSON »

Deux symptômes (en-tête et carte Performance des secteurs), **une seule
cause**, reproduite au caractère près : une requête vers une route `/api/`
que le serveur ne connaît pas reçoit la **page d'erreur HTML par défaut
d'Express**, que `fetchJSON` passait telle quelle à `JSON.parse`. Le message
qui en sort ne peut être relié à sa cause par personne.

Déclencheur typique : un onglet resté ouvert sur une version du frontend plus
récente que le serveur qui tourne — exactement ce qui arrive pendant un
redémarrage ou après une mise à jour.

Corrigé aux deux bouts, pour que ce message ne puisse plus réapparaître :
- **Serveur** : `app.use('/api', …)` en fin de chaîne renvoie un **404 JSON**
  nommant la route, plus un gestionnaire d'erreurs `/api` qui renvoie du JSON
  au lieu du HTML par défaut d'Express sur une exception non interceptée.
- **Frontend** : `fetchJSON` lit le corps en **texte** avant de le parser ;
  s'il commence par `<` ou porte un `content-type` HTML, il lève un message
  en clair (« Le serveur a renvoyé une page HTML au lieu de données… recharge
  la page »).
- **`checkStatus`** distingue enfin deux pannes qu'il confondait :
  « injoignable » (erreur réseau) et « répond, mais pas ce qui est attendu ».
  L'ancien message envoyait chercher un serveur éteint alors qu'il tournait.

### 3 — Ménage dans Réglages → Technique

Trois cartes étaient devenues **fausses** depuis que le sidecar est optionnel :
elles envoyaient diagnostiquer un composant dont l'app n'a plus besoin
(« témoin rouge malgré un sidecar démarré », rate-limit TradingView), et
affirmaient que sans lui « les champs concernés restent en saisie manuelle » —
ce n'est plus vrai, ils sont calculés.

Pire, la carte de relance proposait `lsof -ti:4700 | xargs kill` **sans
`-sTCP:LISTEN`** — la commande exacte qui avait fait tuer le mauvais
processus dans le launcher le 5/9/2026. Corrigée, avec l'explication du
pourquoi.

Onglet réécrit en 7 cartes : **Cette installation** (version, adresse et état
du sidecar en direct — de quoi répondre à « quelle version tournes-tu ? »
sans terminal), `npm run doctor` en premier réflexe, relance (avec le repli
de port), watchdog du launcher, sidecar présenté comme optionnel et inutile,
données locales (et le fait qu'une mise à jour ne touche jamais `data/`),
mises à jour.

### 4 — Réglages → Valeur personnalisée : périodes éditables + réinitialisation

L'onglet était un espace réservé vide. Il porte maintenant les 4 périodes
demandées (SMA rapide 9, moyenne 21, **lente 50**, RSI 14), un bouton
Enregistrer et un bouton **Réinitialiser aux valeurs par défaut**.

**Ces valeurs pilotent réellement le calcul**, ce qui est le point important :
`config.js` ne changeait longtemps que les **libellés** pendant que le serveur
calculait toujours sur 9/21/100 (écart déjà corrigé pour le seul onglet Labo
le 5/9/2026 — il l'est ici pour toute l'app). Nouveau `server/preferences.js` :
- stockage **en base**, pas dans `settings.json` — les réglages appartiennent
  à l'utilisateur et **survivent à une mise à jour** (`server/update.js` ne
  touche jamais `data/`, alors qu'il remplace les fichiers de code) ;
- validation : entier entre 2 et 250, **et** ordre rapide < moyenne < lente —
  sans ce dernier contrôle, 50/21/9 serait accepté et l'alignement haussier
  deviendrait silencieusement inatteignable ;
- `resetPreferences()` **supprime** les lignes au lieu d'y réécrire les
  défauts, pour qu'un utilisateur ayant réinitialisé suive un futur
  changement de défaut plutôt que de rester figé sur l'ancien ;
- branché sur `/api/screening`, `/api/market-data` et `/api/labo` (dont les
  3 champs partent désormais des préférences au lieu de 9/21/100 en dur —
  deux écrans affichant des périodes différentes pour le même indicateur
  auraient garanti la confusion) ;
- un changement **vide le cache de screening** : le garder afficherait des RSI
  calculés avec les anciennes périodes sous des libellés annonçant les
  nouvelles.

Le glossaire (`js/glossaire-indicateurs.js`), qui annonçait « SMA 9/21/100 »
en dur, parle maintenant de rapide/moyenne/lente.

**⚠️ Écart assumé avec le document de design** : celui-ci fixe le filtre de
tendance à 9/21/**100**, et ce fichier demandait explicitement de ne pas y
toucher. JP a demandé **50** dans la feature 351, à deux reprises (valeurs
initiales *et* valeurs du bouton de réinitialisation) — c'est donc délibéré.
Noté dans `design_assistant_swing_trading.md`, qui porte désormais 9/21/50.
**Le Pine Script a été mis à jour le 7/9/2026** à la demande de JP : il
calcule `sma50`, le titre de l'indicateur et le message d'alerte suivent.
⚠️ Le document n'est pas l'alerte — **JP doit recopier le script dans
l'alerte réellement configurée sur TradingView**, qu'aucun outil d'ici ne
modifie à distance. Tant que ce n'est pas fait, l'alerte se déclenche encore
sur l'ancien alignement à 100.

### Vérifié en direct

- Cause des points 1-2 **reproduite** avant correction : une route API
  inconnue renvoyait bien `text/html` et produisait le message exact de JP.
- Après correction : route inconnue → `{"error":"Route API inconnue : …"}` en
  JSON ; `fetchJSON` sur une page HTML → message en clair ; backend simulé
  injoignable → message « injoignable » distinct, et le bandeau disparaît au
  rétablissement.
- Préférences : refus de l'ordre incohérent et de la valeur non entière avec
  message lisible, enregistrement, **libellés et champs du Labo qui suivent**,
  bouton Réinitialiser qui rétablit 9/21/50 et RSI 14.
- **Le calcul suit vraiment** : AMD `rsi=49.3262` en période 21 contre
  `49.6732` en 14, SMA recalculées sur 7/25/60 — et le screening rapporte les
  préférences appliquées.
- Onglet Technique : 7 cartes, « Cette installation » peuplée en direct
  (1.0.0 | 127.0.0.1:4700 | désactivé).
- Chargement à froid dans le navigateur : **toutes les requêtes en 200**,
  aucune erreur console (les 400/404 observés venaient de mes propres tests
  d'erreur volontaires).
- `npm test` : **40/40** (32 auparavant), dont 8 nouveaux sur les préférences.


## Statuts bilbao remis à jour (7/9/2026)

En marquant la feature 351 livrée, un écart est apparu : **#346 (journal —
modifier + export CSV) et #347 (tests automatisés) étaient livrés depuis le
31/8/2026 et encore marqués `Planifie`** — exactement la dérive à deux
sources de vérité que bilbao existe pour éviter. Vérifiés un par un avant de
les marquer (`editTrade()` présent, `GET /api/trades.csv` → 200, `npm test`
vert) plutôt que sur la foi du journal de bord.

**#345 scindée en deux** plutôt que marquée livrée en bloc : son titre
couvrait « XEQT comme repère diversifié **+ trous sectoriels du P/E
industrie/PEG moyen** », dont seule la première moitié est faite. #345 est
recadrée sur XEQT.TO et passée à `Livre` ; la seconde moitié devient
**#352** (`Planifie`). Ce qui la bloque n'est pas technique : choisir des
titres individuels représentatifs par secteur est une décision de JP. Noté
aussi dans #352 que XEQT.TO ne comble PAS ces trous — Yahoo ne lui donne ni
`sector` ni `industry`, vérifié le 31/8/2026.

Toutes ces mutations sont passées par l'API de bilbao
(`PATCH /api/feedbacks/:id`, `POST /api/feedbacks`), jamais par une édition
à la main de `features.json` — artefact possédé par bilbao et régénéré à
chaque mutation. **Seule #352 reste ouverte** pour castellana.


## Publication de la 1.1.0 (7/9/2026)

Première version de castellana réellement distribuée depuis la refonte.

**Numéro de version : 1.1.0, pas 1.0.0.** La 1.0.0 n'a jamais été publiée,
mais le code a changé depuis qu'elle a été estampillée (feature 351) :
republier « 1.0.0 » avec un contenu différent aurait fait exister deux états
distincts sous le même numéro, exactement ce que le mécanisme de mise à jour
est censé empêcher.

**Ordre d'opérations, qui compte** : le zip a été mis en ligne et vérifié
AVANT que le Worker n'annonce la 1.1.0. Dans l'ordre inverse, les testeurs
se seraient vu proposer une mise à jour pointant vers un fichier pas encore
déployé — la mise à jour aurait échoué proprement (l'archive est vérifiée
avant toute bascule), mais pour rien.

**Vérifié à chaque étape** :
- Paquet avant publication : 0 entrée `.venv-mcp`, 0 fichier de `data/`,
  `version.json` à 1.1.0, `demarrer.command` qui conserve son bit
  d'exécution à travers le zip.
- **Déballé et exécuté** dans un dossier isolé : `node scripts/doctor.mjs`
  tourne SANS `npm install` (c'est tout son intérêt) et rapporte
  correctement les 3 points manquants avec leur remède.
- Paquet en ligne : `content-type: application/zip` — vérifié sur le type,
  jamais sur le code 200 (piège du repli SPA documenté dans le `CLAUDE.md`
  racine) — puis **téléchargé et comparé octet pour octet** au fichier
  local. Identique, `version.json` à 1.1.0.
- Chaîne complète : `/version` du Worker annonce 1.1.0 ; un testeur en 1.0.0
  se verrait proposer la mise à jour, un testeur déjà en 1.1.0 non.

**Corrigé au passage sur iecho.ca** : le `stack` affiché publiquement
listait « Sidecar Python (TradingView) » dans les trois langues. C'était
devenu faux, et surtout c'était la mention qui décourageait à
l'installation — elle laissait croire que Python était nécessaire, soit
précisément l'obstacle que cette version supprime.

⚠️ **Les testeurs encore sur l'ancien paquet (6/9) ne verront aucun
bandeau** : leur version n'embarque ni `version.json` ni la route
`/api/version`. Le mécanisme de mise à jour ne fonctionne qu'à partir de la
1.1.0 — pour cette transition-là, il faut leur envoyer le lien à la main.

⚠️ **Pour toute publication suivante** : bumper `version` dans
`package.json` ET `PUBLISHED_VERSION` dans `telemetry-worker/wrangler.jsonc`,
`npm run package`, copier le zip dans `iecho.ca/public/telechargements/`,
pousser iecho.ca, **attendre que le zip soit réellement en ligne**, et
seulement ensuite `wrangler deploy`. Rien n'automatise cette séquence.


## Pine Script paramétrable + verdicts de checklist (7/9/2026)

### Périodes réglables dans TradingView

Le Pine Script du document de design passe de périodes en dur à des
`input.int` (rapide 9, moyenne 21, lente 50, volume 20) : elles se règlent
dans les paramètres de l'indicateur, sans recoller le script. C'était la
troisième fois qu'un changement de période obligeait à repasser par ce
fichier — ce ne devrait plus arriver.

Les trois moyennes sont aussi tracées (`plot`), ce qu'elles n'étaient pas :
un filtre de tendance qu'on ne voit pas sur le graphique est difficile à
vérifier à l'œil.

⚠️ **Limite du langage, trouvée en écrivant** : `alertcondition` exige un
`message` constant à la compilation — il ne peut donc PAS contenir les
périodes choisies. Le message est passé de « alignement SMA9/21/100
confirmé » à « alignement SMA confirmé » : un chiffre écrit là resterait
figé après un changement de réglage, et c'est exactement le piège qui a fait
annoncer 9/21/100 alors que le calcul était à 50. Les périodes réelles
apparaissent sur une `label.new` posée au moment du signal.

**Comme toujours, ce fichier n'est pas l'alerte** : JP doit recopier le
script dans l'alerte configurée sur TradingView.

### Verdicts de la checklist pré-trade (Fiche de trade)

Demande de JP : calculer, pour chaque ligne de la checklist, si l'indicateur
est positif. Une pastille par ligne, à droite du libellé.

**Discipline conservée, et c'est le point central** : **aucune case n'est
jamais cochée automatiquement**, conformément à la règle en place depuis le
23/7/2026. Une checklist auto-cochée n'est plus une checklist, c'est un
score — elle perdrait sa fonction de garde-fou. L'app dit ce que disent les
données ; cocher reste l'engagement de JP, et le résumé sous la checklist le
rappelle explicitement.

**4 lignes sur 6 sont calculables** :

| Ligne | Source | Verdict |
|---|---|---|
| Setup confirmé (alignement) | `smaAlignment` du calcul maison | ✓ aligné / ✗ aligné à la baisse / ~ non aligné |
| Volume vs moyenne 20 j | `volumeRatio` | ✓ ou ✗ avec le pourcentage réel |
| Climat (VIX) | champ du formulaire → `vixInterp()` | ✓ Normal / ~ Complaisance ou Nervosité / ✗ Panique |
| RSI + OBV | champs du formulaire → `rsiInterp()` + OBV | vert **seulement si les deux** le sont, sinon nomme celle qui manque |

**2 lignes ne sont pas calculables, et le disent** plutôt que d'inventer un
verdict : « bougie de confirmation clôturée » dépend de l'unité de temps que
JP regarde et du moment (l'app ne connaît ni l'une ni l'autre), et
« je m'engage à placer le stop » est un engagement, pas une mesure.

**Deux choix de conception qui évitent des verdicts faux et crédibles** :
- Les lignes VIX et RSI/OBV lisent **les champs du formulaire**, pas le
  dernier fetch : JP peut saisir une valeur à la main, et le verdict doit
  suivre ce qu'il a sous les yeux. `renderChecklistVerdicts()` est donc
  appelée depuis `calcFiche()`, pas seulement après `fetchLiveFiche()`.
- **Les données mémorisées sont réattribuées au ticker courant à chaque
  rendu.** Le champ ticker déclenche `calcFiche()` à la frappe : sans ce
  contrôle, changer de titre sans recliquer « Récupérer en direct » aurait
  laissé l'alignement et le volume du titre PRÉCÉDENT à l'écran — un verdict
  faux et parfaitement crédible, le pire des deux mondes.

Réutilise `vixInterp()`/`rsiInterp()`/`obvInterp()` déjà en place plutôt que
de redéfinir les bandes de `config.js` une seconde fois.

Corrigé au passage : la capsule d'aide du RSI conseillait de « vérifier si la
SMA100 tient encore » — période en dur, fausse depuis que la lente est
réglable.

**Vérifié en direct** (AMD, données réelles) : avant récupération, les deux
lignes qui dépendent du calcul maison affichent « — non récupéré » (jamais un
verdict inventé) ; après, `~ non aligné`, `✓ 110 %`, `✓ Normal (15.3)`,
`✗ OBV en distribution`, résumé « 2/4 favorables ». Changement de ticker sans
refetch → les deux lignes concernées repassent à « non récupéré », retour sur
AMD → elles reviennent. VIX saisi à la main : 35 → `✗ Panique`, 17 →
`✓ Normal`, 12 → `~ Complaisance`. RSI vidé → « — pas de RSI ». **Les 6 cases
restent décochées à chaque étape.** Aucune erreur console.

Un défaut cosmétique trouvé et corrigé en testant : le VIX en panique
affichait le préfixe `~` sur une pastille rouge — deux signaux
contradictoires sur la même ligne. Un préfixe par état désormais (✓ / ✗ / ~).


## Screener générateur de positions (11/9/2026)

Question de JP : « comment améliorer l'outil de screening pour qu'il génère
des positions potentielles intéressantes ? » Plan approuvé via
`EnterPlanMode`/`ExitPlanMode` (`~/.claude/plans/robust-honking-yeti.md`).
Suivi dans bilbao sous la **feature 353** (`Livre`).

### Les trois défauts, mesurés avant de coder

1. **Le screener ne notait pas le filtre d'entrée de la stratégie.**
   `scoreRow()` notait RSI, Force relative, Golden Cross, OBV. Or l'app
   écrit elle-même, sous la checklist : « Golden Cross et Force relative
   servent à choisir le titre, **pas à valider l'entrée** ». Et
   `smaAlignment` — `close > SMA9 > SMA21 > SMA50`, le signal d'entrée du
   design doc — était calculé par `getHomemadeIndicators()` puis **jeté**
   avant le scoring : absent de l'objet `merged`.
2. **Un ÉTAT là où le design doc demande un ÉVÉNEMENT** (« déclenché une
   seule fois au premier alignement, pas à chaque barre où l'état est
   vrai »). Rien ne distinguait un titre aligné depuis hier d'un titre
   aligné depuis trois mois.
3. **Un univers trop petit pour générer quoi que ce soit** : 2 setups sur
   22 titres le jour de la mesure. Alors que `SECTOR_TOP_CANDIDATES`
   (`server/sectors.js`) porte **210 titres curés et vérifiés un par un
   contre Yahoo le 2/9/2026**, qui ne servaient qu'à l'affichage « top du
   secteur ».

### Ce qui a été livré

**`server/scoring.js` (nouveau)** — deux axes au lieu d'un score unique :

| Axe | Composantes | Plage |
|---|---|---|
| **Setup** (ça se déclenche maintenant ?) | alignement (PORTE, ±2) · fraîcheur ±1 · RSI en zone ±1 · prix > VWAP +1 | −2 … +5 |
| **Contexte** (le titre vaut-il la peine ?) | Golden Cross ±1 · force relative ±1 · OBV ±1 | −3 … +3 |

Verdicts : `prêt` · `à surveiller` · `trop tard` · `pas de setup` · `erreur`.
Le timing prime sur la qualité dans l'ordre des tests — un excellent titre
dont le mouvement est fait ressort `trop tard`, pas `prêt`.

⚠️ **L'alignement est une PORTE, pas une composante — corrigé en regardant
la vraie sortie, pas à la relecture.** Première version : ±1 comme les
autres. Résultat à l'écran, des titres NON alignés affichaient « Setup 2 »
(RSI +1, VWAP +1) juste à côté du verdict « pas de setup » — deux
affirmations contradictoires sur la même ligne. Un RSI sain sur un titre
sans alignement ne fait pas un demi-setup.

**`server/indicators.js`** — `computeAlignmentSeries()` et `alignmentAge`
(séances depuis le début de l'alignement courant), calculés sur les séries
SMA déjà en mémoire : **aucun appel réseau ajouté**. Défaut interne de la
moyenne lente aligné sur `DEFAULTS` de `preferences.js` (50, pas 100).

**`js/sizing.js` (nouveau)** — `computeSizing()` extrait de `calcFiche()`,
où il était enfermé au milieu d'écritures DOM. Le screening affiche
désormais, par candidat, son stop, sa taille et **ce qu'il ajouterait à la
charge de portefeuille** ; au-delà du seuil d'alerte, la ligne est **grisée
avec sa raison** — jamais masquée (même discipline que les verdicts de
checklist : l'app dit, JP décide).

⚠️ **Ce fichier est la seule maison de ces formules.** Ne jamais les
redupliquer côté serveur : le projet porte déjà deux duplications
documentées comme pièges (`SCORE_BANDS`, `SCREEN_FILTERS`). Une troisième,
sur le calcul qui décide combien d'argent est engagé, serait la pire.
Effet de bord qui compte : ce calcul est **testé pour la première fois**.

**`server/screening.js` (nouveau)** — orchestration en **deux temps**,
dictée par une mesure (210 fondamentaux ≈ 16 s à froid, contre ≈ 4 s pour
les historiques) : indicateurs sur tout l'univers, filtrage, **puis**
fondamentaux sur les seuls retenus. Règle différente par univers, et c'est
délibéré : watchlist → toutes les lignes (JP veut voir SES titres, en setup
ou non) ; élargi → seuls les titres en setup, sinon 190 lignes de bruit.
Clé de cache distincte par univers ; `screening:last` reste celle de la
watchlist, pour ne pas casser l'export CSV ni le « P/E industrie ».

**`server/fundamentals.js`** — `daysToEarnings` via le module
`calendarEvents` ajouté à l'appel `quoteSummary` **existant** : zéro requête
réseau de plus. Entrer deux jours avant des résultats n'est pas le même pari
qu'en milieu de trimestre — le titre peut ouvrir très loin du stop.

⚠️ **Piège trouvé en testant : changer la FORME d'une réponse mise en cache
impose de versionner sa clé.** Après l'ajout du module, toutes les lignes
ressortaient « inconnu » — le cache servait les objets enregistrés AVANT le
changement, sans `calendarEvents`, et rien ne le signalait. D'où
`fundamentals:v2:` et la règle écrite dans le fichier.

**Journal (`server/db.js`, `server/trades.js`)** — migration **additive et
idempotente** (`PRAGMA table_info` avant chaque `ALTER TABLE ADD COLUMN`,
parce que le `CREATE TABLE IF NOT EXISTS` ne s'exécute plus chez JP) :
`setup_score`, `contexte_score`, `alignement_a_entree`,
`signal_age_a_entree`. Bouton **« Préparer »** sur chaque ligne de
screening : bascule vers la Fiche pré-remplie et mémorise le raisonnement.

⚠️ **Le raisonnement n'est joint que si le ticker correspond.** Préparer AMD
puis changer le ticker à la main n'enregistre PAS le score d'AMD sur un
autre trade — ce serait une donnée fausse et parfaitement crédible, qui
fausserait silencieusement toute analyse ultérieure. Vérifié dans les deux
sens.

**L'écran d'analyse n'est PAS livré**, et c'est délibéré : aucun trade fermé
ne porte encore de score, donc tout graphique « le score prédit-il le R ? »
serait calculé sur zéro point. La collecte commence, l'analyse suivra.

### Deux bugs trouvés en testant, pas à la relecture

1. **`switchTab('fiche')` écrasait le ticker préparé.** Il recopie le titre
   de la dernière carte Ticker utilisée. `prepareTradeFrom()` remplissait
   d'abord puis basculait : le bouton avait l'air de marcher tout en
   préparant le mauvais trade. Corrigé (bascule d'abord), plus une garde
   dans `switchTab` — `SELECTION_INSTANCES[lastTickerInstance]` plantait tout
   le changement d'onglet si l'instance était inconnue.
2. **Le test de `computeSizing` ne chargeait rien.** `createRequire` semblait
   direct, mais le paquet est en `"type": "module"` : Node charge le fichier
   comme ESM, où `module` n'existe pas, donc la garde
   `typeof module !== 'undefined'` du bas de `js/sizing.js` ne s'exécutait
   jamais et l'import ressortait **vide, sans erreur**. Le test l'évalue
   désormais comme le navigateur le ferait.

### Vérifié en direct

- **Univers élargi : 219 titres balayés en 4,9 s**, 18 retenus, 10 « prêt »,
  7 secteurs représentés (la watchlist tech/IA n'en produit qu'un).
- **18 appels de fondamentaux au lieu de 219** — cache vidé puis recompté,
  preuve directe que le filtrage précède l'enrichissement.
- **`universe=watchlist` inchangé** : 22 lignes, et un appel SANS paramètre
  d'univers se comporte exactement comme avant.
- **Refactor du sizing sans changement de comportement** : trois cas de
  référence capturés AVANT extraction, identiques au chiffre près après
  (`50 act. / 1,0 %`, `26 act. / 2,5 %`, `18 act. / 4,4 %`).
- **Garde-fou de charge** : 0 ligne grisée à charge nulle, 22 à 5,5 %.
- **Arithmétique du stop recalculée à la main** : ATR 2,30 × 1,5 = 3,45 $,
  stop 39,84 − 3,45 = 36,39 $, taille 500 $ ÷ 3,45 = 144 actions.
- **Migration rejouée deux fois** sans erreur, le trade existant de JP
  préservé, nouveaux champs à `null`.
- **Liste des routes diffée contre HEAD** après l'extraction de
  `server/screening.js` — identiques.
- Navigateur : les 5 onglets, bascule d'univers, aucune erreur console
  (celle qui persiste au tampon date d'avant un correctif de la session,
  vérifié : `calcFiche()` s'exécute sans exception).
- **`npm test` : 65/65** (40 avant), dont 9 sur le sizing — jamais testé
  jusqu'ici alors que c'est le calcul le plus lourd de conséquences.

### Non fait, et à savoir

- **Aucun backtest.** Le screening reste une photo du jour : « ce signal
  a-t-il marché les fois précédentes ? » demande de rejouer l'historique,
  c'est une autre fonctionnalité.
- **La colonne Secteur est un proxy de corrélation, pas une mesure.** Deux
  titres du même secteur sont probablement corrélés ; deux titres de
  secteurs différents ne sont pas forcément décorrélés.
- La taille affichée au screening suppose `correlated: false` — l'app ne
  sait pas si un candidat est corrélé à une position ouverte. C'est donc un
  **plafond** : elle ne peut que baisser une fois la corrélation déclarée.
- **Rien testé sous Windows**, limite inchangée.


## Bannière de verdict et tableau sectoriel (11/9/2026, 2e session)

Point de départ : JP demande **comment est générée** la bannière ambre de
l'onglet Secteurs. Répondre a exigé de la lire ligne à ligne — et a fait
apparaître un défaut que personne ne cherchait.

### Le défaut : des valeurs de démonstration indiscernables de vraies données

`js/ticker-section.js` initialisait les quatre champs de la carte « Ticker »
à `perfTitre=12`, `perfIndice=8`, `sma50=182`, `sma200=170`. Au chargement,
`calcSelectionFor('sec')` tournait donc sur ces chiffres et rendait un
verdict complet :

- force relative : 12 − 8 = 4 pts, sous le seuil de 5 → pas de point ;
- Golden Cross : (182 − 170) / 170 = **+7,1 %** → un point.

Soit « ◐ AMD — à surveiller : Golden Cross positif », affiché sous un ticker
bien réel (`CFG.defauts.ticker`), **sans qu'aucune donnée d'AMD n'ait jamais
été chargée**. Rien dans l'interface ne distinguait ça d'un vrai résultat.

C'est exactement le risque déjà nommé ailleurs dans le portfolio — une
métrique qui ment sur sa propre fiabilité — mais ici en pire : un chiffre
inventé sous une identité réelle.

**Corrigé** : champs vides (`placeholder="non récupéré"`), badges
« Non renseigné », et un **quatrième état de bannière** (`.banner.unknown`,
gris neutre) qui dit qu'il n'y a rien à évaluer. Un seul des deux signaux
renseigné produit un message « évaluation incomplète » nommant ce qu'on sait
ET ce qu'on ignore, jamais un demi-verdict. `SMA200 = 0` est traité comme
non renseigné et non comme un écart de 0 % — c'était une division par zéro
qui s'affichait comme un résultat.

**Les champs restent saisissables à la main**, comme avant.

### La bannière déménage dans la section « Ticker » des trois onglets

Elle flottait en haut de l'onglet Secteurs, **au-dessus de « Performance des
secteurs »** — une place qui laissait croire qu'elle résumait les secteurs
alors qu'elle ne parle que du ticker saisi bien plus bas. Elle est désormais
générée en tête de la carte « Ticker » par `js/ticker-section.js`, donc
présente à l'identique dans **Secteurs** et **Screener**, et dupliquée dans
la carte « Le titre » de la **Fiche de trade**.

- Le calcul est extrait en fonction **pure** `evaluateSelection()` — il était
  enfermé au milieu d'écritures DOM, impossible à partager entre trois écrans.
- `BANNER_TARGETS` est séparé de `SELECTION_INSTANCES` **exprès** : `fiche`
  n'est pas une instance de carte Ticker (pas de champs, pas de badges), et
  l'y mettre ferait croire à `switchTab()` et à `lastTickerInstance` qu'il en
  existe une troisième.
- Dans la Fiche, la bannière est en **lecture seule** : tout vient du dernier
  `/api/market-data`, et les données sont **réattribuées au ticker courant à
  chaque rendu** — même garde-fou que les verdicts de la checklist. Changer
  de titre sans recliquer « Récupérer en direct » vide la bannière au lieu de
  laisser le verdict du titre précédent, faux et crédible.
- Pour que la Fiche puisse calculer la force relative sans second appel,
  `/api/market-data/:ticker` joint **SPY à la requête groupée déjà existante**
  et expose `benchmarkChangePercent` : coût réseau nul en pratique.

### Le tableau sectoriel adopte les colonnes du screening

Demande de JP : la carte « Titres les plus performants du secteur » doit
porter les mêmes colonnes que le tableau de screening (RSI, force relative,
Golden Cross, OBV, prix, volume, float, taille/charge, P/E industrie, PEG,
beta, VWAP, score, verdict).

**Le choix qui compte** : recopier ces champs dans `sectors.js` aurait créé
une **troisième duplication** dans ce projet, après `SCORE_BANDS` et
`SCREEN_FILTERS` — et la pire des trois, puisque les deux tableaux sont
censés être identiques et se lisent côte à côte. À la place :

- `server/screening.js` : le cœur sort en `screenTickers(tickers, …)` ;
  `buildScreening()` et le nouveau `buildSectorScreening()` l'appellent tous
  deux.
- `index.html` : le markup d'une ligne n'existe plus qu'à un seul endroit,
  `screeningRowHTML(r, { onclick, pairsLabel, leadCell })` — même remède que
  le refactor T7 des deux cartes « Ticker ».
- `getTopMoversForSector()` (sectors.js) est **supprimé** : devenu mort.
  Sa contrainte d'origine — n'appeler aucun indicateur pour ne pas
  re-déclencher le rate-limit de `coin_analysis` — **n'existe plus** depuis
  que tout est calculé maison (7/9/2026).
- `marketCap` ajouté à `fundamentals.js` : il vient du module `price` **déjà
  demandé**, donc zéro appel réseau supplémentaire ; il sert au mode
  « top filtré ».

**Deux différences assumées avec le Screener**, pour une seule raison — cette
carte répond à « qu'est-ce qui bouge dans ce secteur ? », pas à « qu'est-ce
qui se déclenche ? » : aucun filtre avant enrichissement (on montre tous les
titres suivis du secteur), et **tri par variation du jour**, pas par
Setup/Contexte. D'où une colonne **« Variation » conservée en tête**, avant
Setup : c'est le critère de tri, la masquer rendrait le classement
inexplicable.

⚠️ **Clé de cache versionnée en `sectors:topresult:v2:`.** La forme de la
réponse a changé ; réutiliser l'ancienne clé aurait servi des lignes
enregistrées avant, sans RSI ni score, **sans que rien ne le signale** — le
piège rencontré le matin même sur `fundamentals:v2:`.

### Colonne Symbole en tête, et « Ticker » disparaît de l'interface

Deux retouches demandées dans la foulée.

**Symbole en première colonne des quatre tableaux** qui en portent un :
« Performance des secteurs » et « Titres les plus performants » (Secteurs),
« Screening » (Screener), et le journal des trades (Journal). Dans le tableau
sectoriel, Variation se place juste après — elle reste le critère de tri, et
se lit immédiatement à côté du titre.

**« Ticker » est renommé « Symbole » partout dans l'interface** (JP : c'est le
terme juste en français) — en-têtes, libellés, titre de la carte, placeholder
de l'éditeur de watchlist, messages de statut, et la bannière qui cite le nom
du champ (« … saisi dans « Symbole évalué » »).

⚠️ **Le renommage s'arrête à l'affichage, et c'est délibéré.** Les
identifiants HTML (`sec-ticker`, `j-ticker`, `labo-ticker`), les champs d'API
(`ticker` dans `/api/screening`, `/api/trades`, les exports CSV), les colonnes
SQLite et les noms de fonctions (`renderTickerSectionInto`,
`trackTickerSelected`, `lastTickerInstance`) **restent en « ticker »**. Les
renommer aurait cassé le contrat d'API — les exports CSV déjà entre les mains
des testeurs compris — pour un gain nul côté utilisateur. Les commentaires qui
*citent le nom affiché* de la carte ont suivi ; ceux qui parlent du code, non.

**L'ordre des colonnes des exports CSV n'a pas changé** non plus : il suit
l'ordre des champs en base, et le modifier casserait un import existant.

**Vérifié en direct** : les 4 en-têtes, les 5 libellés et les 2 titres de
carte affichent « Symbole » ; **zéro occurrence de « Ticker » dans le texte
rendu des 5 onglets** ; en-têtes et cellules toujours alignés (5=5, 25=25,
24=24, 10=10) ; clic sur une ligne de secteur, de titre sectoriel et de
screening chargent tous le bon symbole ; filtres client et « Préparer »
intacts. 65/65 tests, aucune erreur console.

### Messages « tradingview-mcp » périmés

Quatre mentions affirmaient encore que le RSI, le Golden Cross ou les titres
TSX dépendent du sidecar, ou échouent sur son rate-limit. Faux depuis le
7/9/2026 : le sidecar est désactivé par défaut et n'est plus qu'un repli.
Corrigées (échec du Golden Cross, échec du RSI, pied du tableau de screening,
infobulle TSX de l'éditeur de watchlist).

### En-tête de l'onglet Secteurs

L'ancien sous-titre (« Une fois par titre, avant de l'ajouter à ta liste de
suivi active — pas à chaque trade. ») est **supprimé** : l'onglet n'a plus de
sous-titre du tout. La mention « Analyse sectorielle — classification GICS
(Global Industry Classification Standard). » vit directement **sous le titre
de la carte « Performance des secteurs »**, là où elle qualifie ce qu'elle
décrit plutôt que l'onglet entier.

*(Passage intermédiaire, pour mémoire : le sous-titre est d'abord devenu
« Écran d'analyse des secteurs » avec la ligne GICS en dessous, avant que JP
ne demande de retirer le premier et de rapprocher la seconde de son tableau.)*

### Vérifié en direct

- **Les 7 états de la bannière**, y compris `SMA200 = 0`.
- **Données réelles AMD** : +2,49 % contre SPY +0,85 % → 1,6 pts → *Neutre* ;
  SMA50 496,5 > SMA200 346,9 → +43,1 % → *Confirmé* → « à surveiller ».
  Recalculé à la main, concordant.
- **Vrai cas 2/2** : SMCI (+6,4 pts, Golden Cross +3,3 %) → bandeau vert.
- **Garde-fou de réattribution** : AMD → NVDA → AMD, le verdict disparaît
  puis revient.
- **Bouton « + Ajouter à la watchlist » depuis la Fiche** : ajout réel
  confirmé en base, **puis retiré — watchlist restaurée à l'identique**
  (22 titres).
- **En-têtes secteur vs screening identiques** après « Variation »
  (comparaison programmatique), 25 cellules par ligne = 25 en-têtes.
- **XLK** : 20/20 titres en **2,3 s**, toutes colonnes peuplées.
- **Filtre cap/volume recalculé à la main** sur XLB : 16 → 12, les 4 exclus
  le sont tous sur le volume. (Le journal notait 5/16 le 2/9 — c'est la
  donnée de marché du jour, vérifiée ligne par ligne, pas une régression.)
- **Infobulle du « P/E industrie »** : « de ce secteur » côté Secteurs, « de
  la watchlist » côté Screener — elle aurait affirmé du faux sinon.
- **« Préparer » depuis le tableau sectoriel** : ouvre la Fiche sur SHW,
  contexte mémorisé (Setup −2, Contexte 2, alignement baissier).
- **Non-régression** : 22/22 watchlist, **19 retenus / 219 balayés sur
  7 secteurs en 4,5 s**, filtres client opérants, export CSV 200 `text/csv`.
- **Largeur** : le tableau défile dans son conteneur, la page ne défile pas
  horizontalement. Thème clair et sombre vérifiés.
- **`npm test` : 65/65**, aucune erreur console.

### Défaut trouvé en testant

Accord en genre faux dans l'état « évaluation incomplète » (« la force
relative n'est pas renseigné »). Les libellés portent désormais leur propre
genre. Corrigé aussi la conjonction : « mais » quand le signal connu est
positif, « et » sinon.

### Non fait

- **Aucune feature bilbao créée pour cette session** — à faire via l'API de
  bilbao (jamais à la main) si JP veut la tracer.
- **Rien testé sous Windows**, limite inchangée.
- Les filtres supplémentaires du Screener (cases à cocher) n'atténuent pas
  les lignes du tableau sectoriel : ils vivent dans l'autre onglet, et rien
  ne le demandait.


## Analyse de marché élargie — au-delà des 11 secteurs GICS (11/9/2026, 3e session)

JP veut pouvoir situer un titre/secteur par rapport à de grands indices
régionaux et au dollar US, pas seulement aux 11 secteurs GICS. Plan approuvé
via `EnterPlanMode`/`ExitPlanMode`
(`~/.claude/plans/golden-pondering-phoenix.md`). Deux clarifications
obtenues via `AskUserQuestion` avant de coder : le DXY devient une ligne
superposée de plus (performance cumulée en %, comme les autres séries), pas
un coefficient de corrélation calculé ; et l'agrandissement se fait par un
bouton qui ouvre le graphique en overlay plein écran, même patron que le
panneau Réglages déjà en place.

### Sélecteur de devise → sélecteur de place de cotation

L'ancien « Devise des ETF sectoriels (USD ou CAD) » devient « ETF référence
US vs ETF Équivalent TSX » — reformulation conceptuelle (quel MARCHÉ suivre,
pas quelle devise), sans casser le contrat existant : en interne, le `mode`
`'usd'`/`'cad'` (`sectorCurrencyMode`, déjà partagé entre le tableau et le
graphique) n'a pas changé, seuls le libellé et le tooltip du bouton TSX sont
reformulés.

### Six nouvelles catégories sélectionnables au graphique

Nouvelle table `MARKET_INDEX_DEFS` (`server/sectors.js`), à côté de
`SECTOR_DEFS` : DXY, Monde hors USA, Europe, Japon, Marchés émergents,
Chine — chacune avec un ticker US et, quand il existe, un équivalent TSX.
`getSectorHistory()` est **étendu** (pas remplacé) : en plus de
`sectors`/`benchmark` déjà renvoyés par `GET /api/sectors/history`, un
troisième champ `markets` (6 entrées) est ajouté — additif, ne casse pas le
contrat existant. Toujours **un seul fetch pour tout** (même principe que
le découpage par période déjà en place) : les 8 nouvelles cases à cocher
« Catégories affichées » (`.category-chk`) filtrent CÔTÉ CLIENT l'historique
déjà chargé, sans jamais redéclencher de requête réseau — vérifié en direct
(`read_network_requests`) en cochant/décochant plusieurs catégories d'affilée.
« Secteurs GICS » et « S&P 500 » restent cochées par défaut (comportement
identique à avant cette refonte) ; les 6 nouvelles sont décochées par défaut.

Distinction visuelle (jamais la couleur seule, même règle déjà appliquée à
la palette des 11 secteurs) : les 6 nouvelles séries portent une palette
dédiée (`--mkt-dxy`…`--mkt-china`, clair+sombre) ET un style de trait propre
(`stroke-dasharray` pointillé fin), distinct du plein des secteurs GICS et
du tiret long du S&P 500 — la catégorie se lit au style du trait, pas
seulement à la teinte.

### Deux tickers fournis par JP ne résolvaient pas — vérifié avant d'écrire du code

Même discipline que ZXRE.TO → ZRE.TO le 2/9/2026 : chaque ticker candidat a
été interrogé en direct (`quote()` ET `chart()`, ce dernier nécessaire à
l'historique du graphique) avant intégration.

| Catégorie | Fourni par JP | Résultat | Retenu |
|---|---|---|---|
| Europe (CAD) | `FIE` | ❌ n'existe pas sur Yahoo | **`VE.TO`** (Vanguard FTSE Developed Europe All Cap, non couvert) |
| Japon (CAD) | `XJP.TO` | ❌ n'existe pas sur Yahoo | **`ZJPN.TO`** (BMO Japan Index ETF, non couvert) |

Pour les catégories où JP donnait deux tickers US au choix (« A / B »), le
plus liquide (volume moyen 3 mois, mesuré en direct) a été retenu : **VXUS**
(5,4 M) > ACWX (1,8 M) pour Monde hors USA ; **VGK** (2,0 M) > EZU (0,86 M)
pour Europe ; **EEM** (22,7 M) > VWO (7,5 M) pour Marchés émergents ;
**FXI** (21,4 M) > MCHI (2,6 M) pour Chine. DXY utilise `DX-Y.NYB` (le vrai
indice ICE US Dollar Index, pas un proxy ETF comme UUP — correspond
littéralement à « $DXY »).

**DXY et Chine n'ont AUCUN équivalent TSX** — vérifié (aucun ticker `.TO`
plausible ne résout), pas supposé, et JP a confirmé que c'est acceptable.
Petite fonction **pure** `resolveMarketTicker(def, mode)` (testable,
contrairement au reste réseau de `sectors.js` — 4 tests dans le nouveau
`server/sectors.test.js`) décide le repli : en mode TSX sans équivalent, la
ligne US reste affichée, avec `usedFallback: true`. Le frontend le dit
explicitement à trois endroits — étiquette de fin de ligne (`DX-Y.NYB *`),
légende (« Corrélation avec le USD ($DXY) *(US — pas d'équivalent TSX)* »),
tooltip au survol — jamais présentée comme une version canadienne.

### Bouton « Agrandir » — overlay plein écran

L'app entière est limitée à 900px (`.container`), donc le graphique l'était
aussi peu importe la taille d'écran, alors qu'il peut désormais porter
jusqu'à 18 lignes simultanées. Nouveau `#chart-overlay`, top-level comme
`#settings-overlay` (un tab-panel masqué via `display:none` cache aussi ses
descendants `position:fixed`, donc cette modale ne peut pas vivre à
l'intérieur de `#tab-secteurs`). Au clic sur « Agrandir », tout le bloc
`#sector-chart-block` (catégories, période, statut, SVG, légende) est
**déplacé** dans l'overlay (`appendChild`, pas de duplication de DOM ni
d'écouteurs) ; à la fermeture (✕ ou Échap, même geste que Réglages), il est
replacé exactement à sa position d'origine via un nœud ancre
(`#sector-chart-anchor`). Aucun état perdu dans l'aller-retour : catégories
cochées, période choisie, lignes masquées via la légende. En mode agrandi,
`renderSectorChart()` utilise un viewBox plus grand (1400×560 contre
760×320) — re-rendu au moment du basculement, pas un simple zoom CSS.

### Vérifié en direct

Serveur redémarré pour charger le code (un process `node server/index.js`
tournait déjà depuis 1h46 sur le port 4700 — code obsolète en mémoire,
confirmé par `sectorHistoryData.markets` `undefined` côté navigateur avant
le redémarrage, présent avec les 6 entrées après). Dans le navigateur
(Browser pane) : les 6 nouvelles catégories se cochent/décochent sans
requête réseau (`read_network_requests` confirmé) ; décocher « Secteurs
GICS » retire les 11 lignes d'un coup ; bascule US→TSX recharge tableau ET
graphique (`ZSP.TO`/`VE.TO`/`DX-Y.NYB *`/`FXI *` observés, fallback DXY et
Chine bien marqués « (US — pas d'équivalent TSX) » en légende) ; bouton
Agrandir ouvre l'overlay plein écran avec tout l'état préservé, Échap
referme et replace le bloc à l'identique ; thème clair et sombre vérifiés.
Historique à 18 tickers (contre 12 avant) mesuré à **~0,4 s à froid**
(cache purgé manuellement pour la mesure) — aucun ralentissement notable
malgré 50 % de tickers en plus. **69 tests** (65 avant), 4 nouveaux sur
`resolveMarketTicker()`. Serveur de test arrêté après vérification — rien
ne tourne en arrière-plan.

### Non fait

- Le tableau « Performance des secteurs » (P/E moyen, PEG moyen) n'a pas été
  étendu aux 6 nouvelles catégories — hors demande (un P/E n'a pas de sens
  pour un indice comme DX-Y.NYB), et JP n'a demandé l'élargissement que pour
  le graphique.
- **Rien testé sous Windows**, limite inchangée.
- Aucune feature bilbao créée pour cette session — à faire via l'API de
  bilbao si JP veut la tracer.


## Portage Cloudflare Workers + D1 — multi-utilisateur (11/9/2026, 4e session)

JP : « j'aimerais vraiment pouvoir le déployer sur Cloudflare et que ce soit
utilisable ». Le `CLAUDE.md` documentait déjà, depuis le 6/9/2026, pourquoi
ce n'était pas fait : Express persistant, `better-sqlite3` natif et le
sidecar Python sont tous les trois incompatibles avec le modèle Workers.
Plan approuvé via `EnterPlanMode`/`ExitPlanMode`
(`~/.claude/plans/golden-pondering-phoenix.md`), précédé de deux agents
Explore en parallèle (inventaire complet du backend à porter — schéma
exact, les 27 routes une par une, ce qui est Node-only ; et recherche des
patrons D1/mot de passe déjà dans le portfolio).

### Le risque technique levé avant de planifier

`yahoo-finance2` alimente presque tout le backend (secteurs, screening,
indicateurs, fondamentaux). Un spike réel — pas une lecture de
documentation — l'a testé dans un vrai Worker local
(`wrangler dev --local`, `compatibility_flags: ["nodejs_compat"]`) :
`quote('AAPL')`, `chart()` sur 30 jours et une requête groupée de 3 titres
ont tous les trois renvoyé de vraies données. La dépendance qui inquiétait
(`tough-cookie-file-store`, qui écrit des cookies sur disque — inexistant
en Workers) ne bloque rien en pratique.

### Deux décisions de JP avant de concevoir le reste (`AskUserQuestion`)

1. **Multi-utilisateur** : JP + les testeurs Louis et Guillaume, chacun
   avec SON propre journal de trades, sa propre watchlist et ses propres
   préférences — pas une instance partagée où le journal de l'un serait
   visible par les autres.
2. **Cloud seulement** à terme : l'app locale (launcher, `demarrer.command`/
   `.bat`, `installer-sidecar.*`, `scripts/doctor.mjs`, mise à jour en un
   clic) cesse d'être la version de référence. **Nuance appliquée en
   construisant** : rien de tout ça n'est supprimé dans cette passe — l'app
   locale continue de fonctionner pendant que la version cloud est
   construite et vérifiée, retirée seulement une fois JP l'ayant confirmée
   en ligne (voir « Reste à faire » plus bas).
3. Mot de passe **réel**, pas le patron client-side de barcelona/porto — le
   journal de trades est une donnée personnelle, pas du contenu
   pédagogique.

### Aucun patron d'authentification réutilisable trouvé dans le portfolio

Recherche faite avant de coder (agent Explore dédié) : les mots de passe de
`learning-finance`/`learning-softengineer` sont comparés **en clair, côté
client**, dans un bundle sans aucun Worker serveur (`wrangler.jsonc` sans
`main`, assets statiques seuls) — les deux sont explicitement commentés
dans leur code comme « pas une vraie barrière de sécurité ». Le seul
« contrôle serveur » du portfolio est le jeton partagé de
`telemetry-worker` (`checkToken`), documenté lui aussi comme n'étant pas
une vraie authentification. Conçu de zéro pour 3 personnes connues (pas
d'auto-inscription) :
- `users` (id, username, password_hash, password_salt) — **PBKDF2 via Web
  Crypto** (`crypto.subtle`, 100 000 itérations, sel aléatoire par
  utilisateur), écrit dans `cloud/src/auth.js` avec les seules API
  standard — disponibles à la fois dans les Workers ET dans Node ≥ 20, pour
  que la MÊME fonction de hachage serve au Worker et à
  `scripts/create-user.mjs` (exécuté par JP en local).
- `sessions` (token, user_id, expires_at) — cookie
  `HttpOnly; Secure; SameSite=Lax`, vérifié par une lecture D1 sur chaque
  route protégée. Pas de JWT sans état : à 3 utilisateurs, une session en
  base est plus simple à révoquer/auditer — cohérent avec la discipline du
  reste du portfolio de ne jamais sur-ingénierier pour un usage aussi
  restreint (voir coimbra, mono-utilisateur).
- Middleware Hono unique (`cloud/src/index.js`), appliqué à `/api/*` sauf
  `/api/auth/*` (public) et `/api/webhook/tradingview` (TradingView ne peut
  pas envoyer de cookie — protégé par son propre secret partagé,
  `env.WEBHOOK_SECRET`, absent côté local où le risque n'existait pas).

### Schéma D1 (`cloud/schema.sql`)

Reprend le schéma local (`server/db.js`/`preferences.js`/`cache.js`) en
ajoutant `user_id` sur les données personnelles :
`trades`/`watchlist`/`preferences`. **`cache` et `alerts` restent
globaux** — une cotation ou un historique sont les mêmes pour tout le
monde (un cache par utilisateur serait un gaspillage sans bénéfice réel),
et attribuer une alerte TradingView à un utilisateur précis exigerait une
URL de webhook distincte par personne (hors scope tant que JP ne le
demande pas). `watchlist` perd sa clé primaire simple (`ticker`) au profit
de `(user_id, ticker)` — un ticker n'est plus unique globalement.

**Piège trouvé en écrivant les routes, pas en testant** : `buildScreening`/
`buildSectorScreening` dépendent désormais des préférences ET de la
watchlist propres à CHAQUE utilisateur (périodes SMA/RSI, quel titre est
« suivi »). La clé de cache du screening local (`screening:last`, une
seule pour toute l'app) aurait donc servi à Louis le résultat calculé sur
les réglages de JP. Corrigée en `screeningCacheKey(userId, universe)` —
versionnée par utilisateur — avant même d'avoir testé quoi que ce soit,
en relisant le code plutôt qu'en le découvrant en production. Même
correction appliquée à la clé de cache du tableau sectoriel
(`sectors:topresult:v2:${userId}:...`).

### Modules copiés vs réécrits

Les modules de calcul pur (`fundamentals.js`, `indicators.js`, `scoring.js`,
`quotes.js`, `sectors.js`, `screening.js`, `fetch-retry.js`) sont copiés
**avec la même logique** dans `cloud/src/lib/` — mais PAS inchangés à
l'octet près : chacun des modules qui appelle `cached()`
(`fundamentals.js`, `indicators.js`, `quotes.js`, `sectors.js`) reçoit
désormais `db` (le binding D1) en paramètre explicite, parce que
`better-sqlite3` importait un singleton de module au chargement — un
patron impossible en Workers, où le binding D1 n'existe que dans le
contexte d'une requête (`c.env.DB`). `cache.js`, `preferences.js`,
`watchlist.js`, `trades.js`, `stats.js` sont réécrits en API D1
asynchrone (`db.prepare(sql).bind(...).first()/.all()/.run()`,
`db.batch([...])` pour les écritures groupées — pas de `db.transaction()`
comme better-sqlite3), avec `userId` en plus de `db` pour les trois
premiers. `cloud/src/index.js` (Hono) + `cloud/src/routes/*.js`
remplacent `server/index.js` (Express, 755 lignes) — un fichier par
domaine (auth, secteurs, screening, trades, watchlist, marché, divers),
chaque route enregistrée à son **chemin exact** via une fonction
`registerXRoutes(app)` plutôt qu'un sous-routeur Hono préfixé : un
sous-routeur monté sur `/api/screening` ne peut pas servir
`/api/screening.csv`, qui est un chemin FRÈRE et non un sous-chemin —
piège trouvé en écrivant, corrigé avant même le premier test.

### Frontend — ajustements, pas une réécriture

`cloud/public/` est une copie de `index.html`/`js/`/`design-system/`/
`img/concepts/` avec trois changements : un écran de connexion réel
(`GET /api/auth/me` → formulaire si 401, sinon démarre l'app), la carte
« Cette installation » de Réglages → Technique qui affiche le compte
connecté au lieu de la version/l'adresse locale (les cartes sidecar/
launcher/mise à jour en un clic sont retirées — sans objet en cloud), et
`js/telemetry.js` dont l'ancien sélecteur `#who-picker` (un `<select>`
auto-déclaré, explicitement documenté « pas un login ») devient un simple
affichage du compte RÉELLEMENT connecté (`window.CASTELLANA_USERNAME`,
posé après connexion). `strategy/PoorManCoveredCall.md.rtf` n'est PAS
copié : cité en commentaire dans `js/strategies-labo.js`, jamais fetché
par le frontend.

### Vérifié en direct, de bout en bout (D1 local, aucun compte Cloudflare requis)

`wrangler d1 execute --local --file=schema.sql`, deux comptes créés
(`scripts/create-user.mjs jp` / `louis`). Par `curl` : connexion, watchlist
seedée automatiquement au premier accès (`getWatchlist` sème si vide —
plus robuste qu'un seed uniquement à la création, qui aurait laissé un
compte créé directement en SQL sans watchlist), préférences (avec le refus
d'un ordre incohérent des moyennes), cycle complet créer/modifier un
trade, statistiques, exports CSV (screening et journal), secret du webhook
refusé puis accepté, **isolation confirmée entre `jp` et `louis`** (le
trade créé sous `jp` est invisible pour `louis`, chacun a sa propre
watchlist auto-seedée indépendamment). Dans le navigateur (Browser pane,
`wrangler dev`) : écran de connexion rendu, mot de passe erroné refusé
avec message clair, connexion réussie démarre l'app avec les 5 onglets sur
de vraies données Yahoo Finance, secteurs et historique (avec les 6
nouvelles catégories de la refonte du jour) chargés, screening lancé
depuis l'UI (21 titres, résultat affiché), Réglages → Technique montre le
bon compte, déconnexion ramène à l'écran de connexion. Aucune erreur
console liée au code de cette session (les 401 observés sont le
comportement attendu du contrôle de session — vérifications avant
connexion et après une tentative de mot de passe erroné). Serveur de test
arrêté après vérification — rien ne tourne en arrière-plan.

### Déployé réellement le 11/9/2026 (5e session)

Le Worker est **en ligne**, sur le vrai compte Cloudflare de JP
(`iechocreator@gmail.com`, déjà authentifié localement via `wrangler` depuis
le déploiement de `telemetry-worker/`) :

- Base D1 réelle créée (`wrangler d1 create castellana-db`,
  `database_id: b93ea580-3e6b-4ee4-a552-23b83a1672cc`, reporté dans
  `cloud/wrangler.jsonc`), schéma appliqué en `--remote`.
- `WEBHOOK_SECRET` de `wrangler.jsonc` **retiré** — remplacé par un vrai
  secret Wrangler généré aléatoirement (`wrangler secret put`), jamais en
  clair dans le code.
- **3 comptes créés en D1 distant**, mot de passe **« tomate »** pour les
  trois (choisi par JP — le même mot de passe déjà utilisé pour le zip
  téléchargeable local, réutilisé ici comme mot de passe de connexion
  réel) : `jp`, `louis`, `guillaume`.
- `wrangler deploy` → **https://castellana.iechocreator.workers.dev**.

**Vérifié en direct sur le vrai déploiement** (pas seulement en local) :
`GET /` → 200 ; connexion réussie pour les 3 comptes (`tomate`) ; mot de
passe erroné → 401 ; watchlist par défaut semée automatiquement à la
première connexion (confirmé sur le compte `jp`, 21 titres) ; déconnexion
puis accès à une route protégée sans session → 401.

**Intégré à iecho.ca le même jour** : champ `lien` ajouté dans
`src/data/produits/{fr,en,es}.json` (pointant vers l'URL ci-dessus), et la
section `stack` corrigée (`Cloudflare Workers`/`Cloudflare D1`/`Hono`/
`Yahoo Finance` — remplace `Node.js`/`Express`/`SQLite`, devenu faux pour
la version que ce lien sert réellement). Committé et poussé sur le repo
iecho.ca — le bouton « Essayer » castellana est désormais public dans les
3 langues.

**Reste pour JP** : `scripts/migrate-local-data.mjs` est prêt pour
transférer le trade/la watchlist/les préférences déjà présents localement
(`data/castellana.sqlite` — 1 trade, 22 titres, 4 préférences) vers son
compte cloud (`node scripts/migrate-local-data.mjs jp --remote`), pas fait
cette session (pas demandé). Aucun fichier local-only (`launcher/`,
installateurs, `server/update.js`, `server/tradingview.js`) n'a été
supprimé — ce nettoyage attend que JP confirme que la version cloud lui
convient à l'usage réel.


## Intégration télémétrie dans bilbao — avec suppression (13/9/2026, feature #356)

Suite directe de la session « vraie authentification » du même jour : une
fois `/dashboard` et `/events.csv` protégés par Basic Auth, JP a demandé de
pouvoir les consulter **depuis bilbao** (feature-factory) plutôt que via
l'URL publique du Worker, avec en plus une **suppression de données**
(par testeur, par plage de dates, ou totale) — inexistante côté
`telemetry-worker` jusqu'ici.

**Côté `telemetry-worker`** (`src/index.js`) : la requête à 4 volets du
dashboard HTML (testeurs, activité par jour, tickers, 200 derniers
événements) est extraite dans `queryTelemetry()`, partagée entre
`handleDashboard()` (HTML+SVG, pour JP) et le nouveau **`GET /summary`**
(JSON brut, pour bilbao) — une seule implémentation SQL plutôt que deux.
**`POST /delete`** est le point le plus sensible du fichier : il n'a **aucun
scope implicite**. Trois formes, chacune validée séparément —
`{scope:'who',who}`, `{scope:'range',from,to}` (`YYYY-MM-DD`, bornes
inclusives) et `{scope:'all',confirm:true}`, cette dernière refusée en 400
sans le `confirm:true` explicite (un bug d'appel qui omettrait le scope
réel ne peut donc pas dégénérer en suppression totale silencieuse). Compte
les lignes concernées **avant** de les supprimer, pour toujours répondre le
nombre réel — jamais un `{ok:true}` muet. Les deux routes utilisent le
**même** Basic Auth que `/dashboard`/`/events.csv` (pas un nouveau secret) :
c'est délibéré, voir la feature #357 (« login plus solide ») pour le
raisonnement sur ce qui resterait à durcir si JP voulait un jour y accéder
autrement que via bilbao.

**Côté bilbao** : voir `feature-factory/CLAUDE.md`, 13/9/2026, pour le
détail complet (nouveau `server/telemetry.js`, 6ᵉ onglet « Télémétrie »,
audit de la suppression). Point notable pour ce dépôt-ci : **c'est la
première fois qu'un autre produit du portfolio appelle `telemetry-worker`
par une route autre que `POST /events`** — jusqu'ici seul le navigateur de
JP (via `/dashboard`) ou castellana lui-même (via `/events`) y touchaient.

**Vérifié en local avant tout appel à la production** — `wrangler dev
--local` (D1 simulée, `.dev.vars` jetable créé puis supprimé, même patron
que la session précédente) : les 3 scopes de suppression avec des données
de test, le refus 400 sur `all` sans `confirm`, le refus 401 sans Basic
Auth, `range` avec des dates invalides. Puis bilbao démarré avec un `.env`
de test pointant vers ce Worker local : `/api/telemetry/status`,
`/api/telemetry/summary`, et une suppression réelle **déclenchée depuis
l'interface** (bouton → `confirm()` → appel → tableau et sélecteur de
testeurs qui se rafraîchissent tout seuls), `logAudit` confirmé dans
`GET /api/audit` côté bilbao, état « non configuré » vérifié sans `.env`
(le reste de bilbao continue de fonctionner normalement). **Zéro donnée de
production réelle touchée** — tout sur une base D1 locale, jetée après le
test.

Feature #356 marquée `Livre` dans bilbao via son API (jamais à la main).

**`telemetry-worker` redéployé en production juste après** (`wrangler
deploy`, demandé explicitement par JP) — Version ID
`e76952f1-6c64-4c0b-bdec-555e8e03629a`. Vérifié en direct sur la vraie URL,
sans identifiants réels (je ne les détiens pas — secrets Wrangler côté
JP) : `GET /summary` → 401, `POST /delete` → 401 (même garde que
`/dashboard`, inchangé), `GET /version` toujours public, `POST /events`
avec un jeton volontairement faux → 401 (pas de donnée de test insérée en
production). **Reste à JP** : renseigner `.env` de bilbao avec les vrais
identifiants (mêmes que les secrets Wrangler `DASHBOARD_USER`/
`DASHBOARD_PASSWORD`) pour activer l'onglet Télémétrie.


## Options A / Journal A — vente de puts à primes continues (22/9/2026)

Point de départ : JP veut réfléchir plus en profondeur à la vente d'un put
pour encaisser une prime continue (style « La Roue »), au-delà de ce que
l'onglet Options (chaîne en lecture seule, v1-v3 du 20/9/2026) et le Labo
(strikes ESTIMÉS par Black-Scholes sur volatilité historique, pas de vraie
donnée d'options) offrent déjà. 12 idées proposées en brainstorm, réparties
par JP en 4 tâches. Plan approuvé via `EnterPlanMode`/`ExitPlanMode`
(`~/.claude/plans/mutable-wondering-flask.md`), 3 décisions confirmées par
`AskUserQuestion` avant de coder — voir la vérification factuelle en tête de
ce fichier pour le détail des 3 décisions et le résumé complet.

### Bloc partagé — `js/options-analytics.js`

SOURCE UNIQUE des formules de vente de primes, même discipline que
`js/labo-schema.js`/`js/sizing.js` : `optAnnualizedYield(premium, strike,
dte)` = `(premium/strike) × (365/dte) × 100` (le nombre de contrats s'annule
dans ce ratio) ; `optCapitalRequired(strike, contractSize, contracts)` ;
`optAssignmentProbabilityLabel(delta)` (repère grossier faible/modérée/
élevée à partir de `|delta|` — une approximation usuelle, jamais présentée
comme une vraie probabilité statistique) ; `optRollNetCredit(...)`.
`OPT_MIN_IV`/`optionDelta`/`optionMarketZone` y ont été **déménagés** depuis
`js/options-tab.js` (réutilisés côté serveur pour la grille et le screener
de primes — un besoin qui n'existait pas avant cette session).

**Dépendance non triviale** : `optionDelta` utilise `laboNormCdf`, défini
dans `js/strategies-labo.js`. Côté navigateur, résolu par l'ordre des
`<script>` (strategies-labo.js avant options-analytics.js). Côté serveur
(`server/options-analytics.js`) et côté copie cloud générée
(`cloud/src/lib/options-analytics.js`, via `scripts/sync-cloud-copies.mjs`
étendu avec un `prelude`), la même tranche `laboErf`→`laboNormInv` de
`strategies-labo.js` est injectée avant d'évaluer le fichier — même tranche
que celle déjà utilisée par `server/options-tab.test.js`. Tests migrés en
conséquence : `optionDelta`/`optionMarketZone` testés désormais dans
`server/options-analytics.test.js`, `options-tab.test.js` allégé aux
fonctions qui lui restent (CSV, bornes de strike).

### Options A (`js/options-tab-a.js`)

Copie structurelle de l'onglet Options (IDs préfixés `opta-`), enrichie :
- **#1/#3** : deux colonnes par côté (calls/puts) — rendement annualisé
  (calculé sur le **bid**, jamais l'ask ni le dernier échangé) et capital
  requis, sur 1 contrat, `contractSize` lu depuis les paramètres Labo de la
  Roue (`roue.contractSize`, même source que le reste de l'app).
- **#2** : le delta estimé existant porte désormais aussi son pourcentage
  de probabilité d'assignation en tooltip.
- **#10** : `/api/labo/:ticker` (local **et** cloud) expose maintenant
  `daysToEarnings` (`getFundamentals()` le calculait déjà pour le screener
  actions, jamais exposé sur cette route — une ligne, zéro appel réseau de
  plus) ; bannière ambre si résultats dans ≤ 10 jours.
- **#11** : `GET /api/options/:ticker/grid` (local `server/options.js`,
  cloud `cloud/src/lib/options.js`) — boucle sur les 6 premières échéances à
  venir, réutilise le cache par échéance déjà en place
  (`options:v1:<ticker>:<expiry>`), retient par échéance le contrat dans la
  plage de delta au **meilleur** rendement annualisé (pas le premier
  trouvé).
- **#12** : calculateur de roulement — saisie manuelle des deux jambes
  (prime de rachat / prime encaissée), pas de préremplissage automatique
  depuis une ligne de la chaîne (scope volontairement réduit pour tenir
  dans la session).

### Journal A (`js/journal-a-tab.js`)

Nouveau schéma `option_cycles`/`option_trades` (local `server/db.js`,
cloud `cloud/schema.sql` + `cloud/scripts/migrate-option-trades.mjs`,
`trades.option_cycle_id` ajouté en migration additive des deux côtés).
`server/option-trades.js`/`cloud/src/db/option-trades.js` : CRUD + l'effet
de bord central de #5 — `closeOptionTrade()` valide **avant** d'écrire
(voir le bug ci-dessous), et sur assignation d'un put crée une ligne
`trades` (prix d'entrée = strike, taille = contrats×contractSize, stop
initial **demandé à l'appelant**, jamais déduit) ; sur assignation d'un
call du même cycle, retrouve la ligne `trades` ouverte liée
(`option_cycle_id` + `date_sortie IS NULL`) et la ferme (prix de sortie =
strike, R = `(sortie-entrée)/(entrée-stop)`, même formule que
`closeTrade()` côté navigateur).

`server/premium-screener.js`/`cloud/src/lib/premium-screener.js` (#8/#9) :
`isPremiumUniverse()` **refuse explicitement** `elargi` (watchlist/MAG7/
listes perso seulement — décision de JP, voir tête de fichier) ; pour
chaque titre, cherche le put dans la plage de delta sur la fenêtre DTE
demandée (jusqu'à 3 échéances testées), joint `computeHistoricalVolatility()`
(déjà dans `indicators.js`, réutilisé via `getHomemadeIndicatorsBatch`) pour
comparer l'IV du contrat retenu à la volatilité **historique** du titre —
**pas un vrai « IV rank »**, Yahoo n'expose aucun historique d'IV.

`server/option-alerts.js`/`cloud/src/lib/option-alerts.js` (#7) : pour
chaque position ouverte, recharge la chaîne courante, compare DTE restant
(≤ 7 jours) et prime de rachat estimée vs seuil de prise de profit
(`roue.profitTakeMin/Max`, mêmes paramètres Labo) — contrat introuvable →
alerte explicite « impossible d'évaluer », jamais une ligne muette.

Interface : 4 cartes (screener, calculateur, alertes, cycles), le calcul
du rendement de primes réalisé (Labo #6) lit
`GET /api/option-trades?statut=expire,assigne,roule,rachete` et agrège par
mois/symbole/compte — **aucune comparaison à un rendement « visé »
inventé**, seulement des chiffres réalisés (voir tête de fichier).

### Deux bugs réels, trouvés en testant en direct

1. **Position bloquée** — `closeOptionTrade()` écrivait `UPDATE option_trades
   SET statut = 'assigne', ...` **avant** de vérifier que `stopInitial` était
   fourni pour un put. Un premier appel sans stop initial (reproduit via
   `curl`) laissait la position en `assigne` sans jamais créer la ligne
   `trades` — et un second appel avec le stop correct échouait avec
   « Cette position est déjà "assigne" », sans recours. Corrigé en
   déplaçant la validation avant l'`UPDATE`, des deux côtés (local + cloud),
   reproduit puis re-vérifié corrigé.
2. **Route avalée** — `/api/options/premium-screener` enregistrée APRÈS
   `/api/options/:ticker` (même forme `/api/options/<segment>`) se faisait
   capturer, `premium-screener` pris pour un symbole
   (`{"error":"Symbole « PREMIUM-SCREENER » inconnu..."}`). Même piège déjà
   documenté pour `/api/labo/params` vs `/api/labo/:ticker` — raté une
   première fois sur cette route précise, malgré le commentaire déjà en
   place ailleurs dans le fichier. Corrigé en réordonnant (local Express
   **et** cloud Hono — les deux résolvent par ordre d'enregistrement ici),
   reproduit puis re-vérifié corrigé sur les deux runtimes.

### Vérifié en direct

Local (serveur temporaire sur port libre, données réelles Yahoo pré-marché —
la grille/le screener retournent honnêtement « — »/vide quand les bids sont
absents, comportement attendu hors heures de marché, pas un bug) : chaîne
Options A avec les nouvelles colonnes, calculateur de roulement, cycle
complet put→assigné (trade créé, prix_entree=strike, taille=contrats×100)
→call couvert→assigné (trade fermé, R=1.0 recalculé à la main), 125/125
tests. Cloud (`wrangler dev --local` + D1 locale, compte de test créé) :
mêmes parcours, isolation `user_id` confirmée, correctif de route validé
identique au local.

## Meilleurs deals — achat vs vente, puts et calls (22/9/2026, 2e session)

Suite directe : une fois Options A/Journal A livrés, JP demande d'identifier
dans une chaîne d'options les meilleurs achats/ventes de puts/calls, au-delà
du volume et de la prime. Discussion structurée avant de coder (pas de
`AskUserQuestion` cette fois — une vraie question ouverte de JP, « as-tu
d'autres critères en tête ? ») : liquidité réelle (OI en plus du volume,
spread bid-ask en **% de la prime**, pas en valeur absolue — un écart de
0,05 $ ne pèse pas pareil sur une prime à 2 $ ou à 20 $), cherté relative de
l'IV (déjà là pour le screener de primes, #9, mais généralisable au skew
entre strikes voisins), rendement par unité de risque plutôt que rendement
annualisé seul, theta approximé, et le point structurant : **acheteur et
vendeur veulent l'inverse** sur la valorisation de l'IV (le vendeur cherche
une prime riche, l'acheteur une prime bon marché) — jamais un seul jeu de
critères partagé entre les deux.

### Conception

Nouvelle carte dans Options A (pas un nouvel onglet, pas une extension du
screener de primes multi-titres de Journal A — le screener actions déjà en
place opère sur un univers de tickers avec une fenêtre de delta fixe pour la
Roue ; ceci opère sur TOUTE la chaîne déjà chargée, calls et puts, tous les
strikes). Entièrement côté navigateur : `optaChain` (déjà en mémoire) +
`optaLaboContext.sigma` (volatilité historique, déjà chargée pour la carte
Labo vs marché) suffisent, zéro appel réseau supplémentaire.

Trois sous-scores dans `js/options-analytics.js`, TRANSPARENTS (-1/0/+1
chacun, jamais un score opaque additionné en secret) — même discipline que
`scoreRow()` du screener actions (`server/scoring.js`) :

- `optDealLiquidity(bid, ask, openInterest, volume)` — null si pas d'ask
  exploitable (le contrat est alors EXCLU du classement, jamais scoré à 0) ;
  spread en % du prix médian, bandes sur OI et volume.
- `optDealValuation(mode, iv, historicalVolatility)` — edge = IV −
  volatilité historique, en points de % ; bandes **inversées** entre les
  deux modes (vente : edge > 5 pts = bon ; achat : edge < -5 pts = bon).
- `optDealReturnOrLeverage(mode, contract, ctx)` — vente : rendement
  annualisé ; achat : `|delta| / prime payée` (exposition par dollar
  réellement risqué, pas une probabilité de gain).

Seuils = repères pragmatiques documentés dans le code, pas une calibration
statistique — même statut que les bandes RSI/VIX de `config.js`.

### Bug réel trouvé en testant sur AMD, pas en relisant le code

Premiers résultats : des calls profondément dans la monnaie en tête de
classement, « rendement annualisé » à 20 000 %+. Cause : `optAnnualizedYield`
était appelée sur le bid **brut** — pour un ITM profond, l'essentiel du bid
est de la valeur **intrinsèque** (`max(0, S-K)` pour un call), pas une
prime de temps réelle ; le vendeur d'un tel contrat « rend » une partie du
prix de l'action, il n'encaisse pas un vrai rendement. Ce défaut existait
en germe dans `optAnnualizedYield` depuis sa création (20/9/2026) mais ne
s'était jamais manifesté : le screener de primes et la grille (#8/#11) ne
regardent que des puts OTM dans une fenêtre de delta 0.15-0.25 par
construction — jamais de contrat ITM. C'est le premier endroit qui classe
TOUTE la chaîne, calls et puts ITM compris, qui l'a exposé.

Corrigé en ajoutant `optIntrinsicValue(type, S, K)` et
`optExtrinsicValue(type, S, K, premium)` (= `max(0, premium − intrinsèque)`),
et en calculant le rendement de vente sur l'extrinsèque plutôt que le bid
brut — inchangé pour un contrat hors la monnaie (extrinsèque = bid), corrigé
pour un ITM (rendement redevient plausible, ou affiche honnêtement « — » si
la valeur temps résiduelle est nulle plutôt qu'un chiffre inventé).
`optDealReturnOrLeverage`/`optScoreDeal` ont dû recevoir `type` (put/call)
et `price` (prix du sous-jacent) en plus de `dte` pour calculer l'intrinsèque
— signature étendue, tests mis à jour en conséquence.

**Vérifié en direct, avant et après le correctif** : sur AMD, le call
580 (profondément ITM, bid 42,65 $) est passé de « rendement 2684 %,
excellent » à « rendement —, excellent » (liquidité et valorisation IV
restent calculables et informatives même sans rendement exploitable) ; les
strikes proches du prix (605-650, calls et puts) ont pris la tête du
classement avec des rendements à trois chiffres plausibles pour une
échéance à 1 jour. Mode Achat vérifié séparément (`|delta|/ask`, IV bon
marché récompensée). 137/137 tests (12 nouveaux,
`server/deal-score.test.js`), copies cloud synchronisées. Committé
(`6013ede`), poussé et déployé en production le jour même — aucune
migration nécessaire (zéro nouveau schéma, entièrement côté navigateur).

## Flags par compte — Comptes castellana (22/9/2026)

Suite directe de la session ci-dessus : JP veut pouvoir activer
`options_a_tab`/`journal_a_tab` pour un testeur précis depuis bilbao, sans
toucher au réglage global des autres. Nouvelle table `user_feature_flags`
(`user_id`, `key`, `enabled`) — même principe « surcharge ⊕ défaut » que
`strategy_params` (labo) : absence de ligne = hérite du global, jamais une
troisième valeur par défaut inventée. `KNOWN_USER_FLAGS` (sous-ensemble de
`KNOWN_FLAGS` — aujourd'hui les deux mêmes clés) ; `getEffectiveFlagsForUser()`
= global ⊕ surcharges, c'est elle que `GET /api/flags` renvoie désormais
(donc **par session**, plus une valeur unique pour tout le monde) ;
`setUserFlag(..., enabled)` — `enabled: null` supprime la surcharge (retour
à l'héritage), jamais un enregistrement « hérite » explicite en base.

Routes admin : `GET /api/admin/user-flags` (clés + surcharges de tous les
comptes, pour bilbao), `PUT /api/admin/users/:id/flags/:key`. Côté bilbao :
`castellana-users.js` étendu (`listUserFlags`/`setUserFlag`), routes
`/api/castellana-user-flags`/`/api/castellana-users/:id/flags/:key`
(auditées, `flag_utilisateur_castellana`), et l'onglet **Comptes castellana**
gagne 2 colonnes — un menu à 3 états par compte (« Hérite (ON/OFF actuel) »
/ « Forcé activé » / « Forcé désactivé »), écriture immédiate au
changement (pas de bouton « enregistrer » séparé, même geste que les
switches de Flags cloud).

**Vérifié de bout en bout**, pas seulement `curl` direct sur castellana :
`wrangler dev --local` + D1 locale, 2 comptes de test créés, puis **bilbao
lui-même lancé en pointant `CASTELLANA_ADMIN_URL` sur ce Worker local**
(overrides d'environnement en ligne de commande, jamais le vrai `.env`
touché) — isolation confirmée entre les deux comptes, override qui bat le
global dans les deux sens (forcé ON quand le global est OFF, forcé OFF
quand le global passe ON), réinitialisation qui revient bien à
l'héritage, 404 sur flag inconnu, 400 sur valeur non booléenne, **et un
clic réel dans le menu de l'UI bilbao** qui a changé la session castellana
correspondante (vérifié par un second `curl` sur `/api/flags` de ce
compte).

### Déploiement

Séquence confirmée par JP (« lance les deux » / « enchaîne tout ») :
commit+push (trading-assistant, `ea3c408` puis `3adf420`) → migration
`--remote` (`migrate-option-trades.mjs` puis `migrate-user-flags.mjs`,
chacune vérifiée par `sqlite_master`/`PRAGMA table_info` après coup) →
`wrangler deploy` (2 fois, versions `65dd824f…`/`b2561a01…`, routes
existantes revérifiées sans 500 après chaque déploiement) → commit+push
(feature-factory, `f620882`). **bilbao n'est jamais déployé** (app locale
par principe) : JP a dû `git pull` + relancer lui-même. Un process bilbao
**orphelin** (actif depuis la veille, tenant encore le port 4600 avec
l'ancien code après que JP a fermé sa fenêtre de terminal sans que le
process meure) a été identifié par `ps` puis arrêté avant de pouvoir
relancer avec le nouveau code — c'est ce qui causait le `HTTP 404`
générique que JP voyait dans le tableau des comptes (une page 404 par
défaut d'Express, sans JSON, contre les 3 nouveaux appels désormais requis
par `loadCastellanaUsers()`).

⚠️ **Note honnête** : la vérification de bout en bout via bilbao a laissé
une entrée réelle dans le journal d'audit LOCAL de JP
(`flag_utilisateur_castellana`, contre le Worker de test — jamais la
production). Signalée à JP plutôt que supprimée : altérer un journal
d'audit a semblé pire que d'y laisser une trace véridique d'un test.

**Les deux flags restent OFF par défaut pour tout le monde** — rien ne
change pour un testeur tant que JP n'active rien explicitement pour son
compte depuis bilbao.

## Radar — screener multi-titres de meilleurs deals (22/9/2026, local uniquement)

Généralise le détecteur de « meilleurs deals » d'Options A (une chaîne à la
fois) en un scan des **210 titres curés** (`SECTOR_TOP_CANDIDATES` ; le plan
disait 219, l'univers dédoublonné en compte 210), échéance entre 25 et 45
jours, puts et calls, modes vente et achat.

**Décisions de JP** (`AskUserQuestion`, plusieurs tours) : univers = les titres
déjà curés ; **exécution locale, pas cloud** ; à la demande (planification
automatique = amélioration future, non construite) ; outil personnel, invisible
des testeurs.

**Pourquoi local** : un scan synchrone est impossible sur le plan gratuit
Cloudflare (50 sous-requêtes et 10 ms de CPU par invocation). Un plan payant
règlerait ce plafond mais **pas** le rate-limit de Yahoo, qui est indépendant de
l'infrastructure. En local, seul le rythme face à Yahoo compte.

**Architecture** :
- `server/deal-scanner.js` : un seul fetch de chaîne par titre sert les deux
  modes et les deux types (`optScoreDeal` est un calcul local peu coûteux).
  Au plus 2 appels Yahoo par titre, concurrence 2. Fonctions pures testées :
  `firstExpiryInWindow`, `isEarningsExcluded`, `scoreChainContracts`,
  `applyDiversityCap`. Le scan tourne en tâche de fond (`runDealScan`,
  garde `scanEnCours` : un second lancement répond 409).
- **Exclusion dure des résultats avant échéance** (`daysToEarnings < dte`) :
  le contrat est conservé avec `exclu_motif = 'resultats_avant_echeance'`
  pour audit, mais n'entre jamais dans le classement. Un contrat sans ask
  exploitable n'est jamais persisté.
- **Diversification à la présentation**, pas à la donnée : le classement brut
  reste consultable, la vue diversifiée plafonne à 2 par secteur.
- Tables `deal_scans`/`deal_results` (`server/db.js`). Une ligne par titre par
  jour de scan s'accumule : de quoi bâtir plus tard un vrai historique d'IV
  (IV Rank réel). Rien n'exploite cela aujourd'hui.
- Routes locales : `POST /api/deal-scanner/start`, `GET …/status`, `…/results`,
  `…/history`. Aucune côté cloud ; `js/deal-scanner-tab.js` n'est pas dans
  `cloud/public/` ni dans le test de parité.

**Flag `radar_tab`** : ajouté à la demande de JP, par cohérence avec les autres
onglets avancés (`settings.json` → `featureFlags.radarTab`, défaut `false`,
exposé par `/api/flags`, `initRadarVisibility()`). ⚠️ `settings.json` n'est lu
**qu'au démarrage** : après l'avoir passé à `true`, il faut relancer le serveur.

**Mesuré (scan réel, 210 titres)** : 18 s, 3 erreurs (AVB, EQR, EA : « sans
options cotées »), aucun 429. Sans diversification, INTC occupait le haut du
classement ; avec, le top 10 couvre 7 secteurs. TSLA (résultats à
29 jours, échéance à 30) exclu, comme voulu. 145/145 tests.

**Piège rencontré** : JP ne voyait pas l'onglet parce qu'un `node server/index.js`
tournait depuis près de 24 h avec l'ancien code. Vérifier `lsof -ti:4700` et
relancer avant de chercher un bug.

**Non fait** : version cloud, planification automatique, exploitation de
l'historique d'IV, backtest des deals recommandés, extension de l'univers.

## Interface compacte — gabarits et cartes (26/9/2026)

Point de départ : JP trouvait que les zones de saisie et de métriques
prenaient trop de place et ne s'alignaient pas (10 tuiles de fondamentaux sur
plusieurs lignes, Force relative et Golden Cross mal alignés, screener de
primes et calculateur « Vendre une option » en `.row` sans colonnes). Une
maquette a été validée avant de coder.

**Nouveaux composants CSS** (dans `index.html` et `cloud/public/index.html`) :
- `.field-grid` : grille de 6 colonnes égales ; chaque `.field` porte son
  libellé **au-dessus** du champ, hauteur de contrôle unique (30 px).
  `.span-2` pour deux colonnes, `.field-actions` pour les boutons.
- `.metric-band` : bande de métriques (libellé 11 px, valeur 13 px), nombre de
  colonnes via `--cols`. Les libellés longs se tronquent, le texte complet est
  en infobulle.
- `.signal-pair` / `.signal` : deux panneaux côte à côte.
- Sous 700 px : grilles à 3 colonnes, bande à 5 colonnes sur 2 lignes.
  **Non testé visuellement.**

**Appliqués à** : la section Symbole (`js/ticker-section.js` : 10 fondamentaux
sur une bande, Force relative et Golden Cross côte à côte, mêmes identifiants
qu'avant), le screener de primes et le calculateur (`js/journal-a-tab.js`). Les
copies `cloud/public/js/` sont identiques (test de parité).
**Étendus ensuite à la Fiche de trade** (26/9/2026, commit suivant, déployé
version `6845198d`) : prix d'entrée, ATR et liquidité sur une ligne ;
curseurs en ligne via `.field-inline` (curseur et valeur côte à côte) ;
« Position et stop » en bande de 4 métriques avec la carte « Type d'ordre
recommandé » fusionnée dedans ; Objectifs en deux panneaux (multiples de R et
Fibonacci). Les 30 identifiants sont conservés. ⚠️ `calcFiche()` écrase la
classe de `#m-heat` (`ds-metric__value ok/warn/bad`) : la bande stylise donc
`.ds-metric__label/value/sub` et non des classes propres, sinon la couleur de
la charge se perdrait. Vérifié : aucun identifiant manquant, calcul correct
(ATR 4 × 1,5 = stop à 6,00 $, 83 actions), aucune erreur console.

**Étendus à Options A et au Journal** (26/9/2026, commit suivant) : la chaîne
(symbole/échéance/boutons), les filtres, la grille de rendement, les
meilleurs deals et le calculateur de roulement passent en `.field-grid` ;
le formulaire « Nouveau trade » du Journal passe de `grid-template-columns:
repeat(auto-fit, …)` (rangées inégales) à 6 colonnes fixes.

⚠️ **Bug trouvé sur capture d'écran, corrigé** : à 30 px de haut, la marge
verticale des `<select>`/`<input>` (8 px en haut et en bas via
`.ds-input/.ds-select`) ne laissait que 14 px de zone de texte pour un texte
de 13 px — les listes déroulantes (ex. OBV, Compte) étaient coupées. Hauteur
des contrôles portée à **34 px** (22 px de zone de texte), dans les trois
composants (`.field-grid .field`, `.metric-band .val`, `.field-inline`).
Vérifié en mesurant chaque champ visible : plus aucun n'est trop serré.

**Screener scindé en 5 cartes** (26/9/2026, demande de JP — « rendre le
tableau agrandissable séparément du graphique, comme Secteurs ») : commandes
seules dans « Screening — univers de titres » ; « Performance des titres
retenus » (le graphique, `#screen-chart-card`, caché tant qu'aucun screening
n'a tourné) et « Résultats du screening » (légende, bandeau de sous-requêtes,
tableau) deviennent des cartes séparées, chacune avec son propre bouton
« Agrandir » (`openTableOverlay`, même mécanisme que Secteurs). Vérifié avec
un vrai screening (22 lignes) : le graphique apparaît après lancement, les
deux agrandissements déplacent puis replacent le bon bloc, aucune erreur
console.

**Non étendu** : Radar garde `.row`.

**Chaque élément dans une carte** : audit des huit onglets. Rangés : la
bannière de verdict de la Fiche (dans la carte « Checklist pré-trade »), les
quatre métriques de la Fiche (nouvelle carte « Position et stop »), et tous
les sous-titres et notes flottants (carte repliable `.tab-intro`
« À propos de cet onglet », fermée par défaut).

**Vérifié** par mesure de géométrie dans le navigateur (bande sur une seule
rangée, panneaux alignés, colonnes du calculateur régulières) ; les captures de
l'aperçu étaient trop petites pour juger à l'œil.

## « Journal A » renommé « Screener Prime » (26/9/2026)

Demande de JP, pur renommage d'affichage. Changé : le bouton de l'onglet
(`index.html`, `cloud/public/index.html`), un message de
`js/journal-a-tab.js` (« clôture une jambe dans l'onglet Screener Prime… »),
le libellé du flag côté cloud (`cloud/src/db/flags.js`,
`KNOWN_FLAGS.journal_a_tab.label`), et l'en-tête de colonne de la console
« Comptes castellana » de bilbao (`feature-factory/public/index.html`,
autre dépôt). **La clé technique `journal_a_tab` n'a pas changé** — flags
déjà activés pour un testeur, routes API, schéma : rien à migrer.

## Carte Fondamentaux (EPS, FCF) — étendue puis portée en production (26/9/2026)

La carte du 26/9/2026 (`server/fcf-quality.js`, flag `fundamentals_card`)
n'existait qu'à la Fiche de trade et **local uniquement**. Deux demandes de
JP dans la foulée :

**1. Répliquée sous « Symbole »** dans Secteurs, Screener et Labo — même
rendu, `renderFcfCard(d, cardId)`/`loadFcfCard(ticker, cardId)` prennent
maintenant l'id de la carte en paramètre (`FCF_INSTANCES = ['sec','scr','lab']`
dans `js/fcf-card.js`), appelés depuis `fetchLiveSelectionFor()` ; la carte se
cache avec le reste de la section quand le symbole change
(`invalidateSelectionData()`), pour ne jamais afficher les chiffres d'un
autre titre.

**2. Portée en production** — JP a signalé ne pas la voir en cloud : elle
n'existait tout simplement pas côté Worker (pas un bug, un lot volontairement
local que JP voulait finalement partout). Portage : `cloud/src/lib/
fcf-quality.js` (logique et seuils **identiques**, seuls changent l'accès
Yahoo — instance par requête, `./yahoo.js` — et le cache, D1 via `cached(db,
…)`), route `GET /api/fcf/:ticker` (`cloud/src/routes/market.js`), flag
`fundamentals_card` ajouté à `KNOWN_FLAGS`/`KNOWN_USER_FLAGS`
(`cloud/src/db/flags.js`, **ON par défaut** — fonction terminée, pas un
lot en test comme `options_a_tab`/`journal_a_tab`), et `js/fcf-card.js`
copié dans `cloud/public/js/` (ajouté au test de parité).

⚠️ **Deux copies du calcul à ne pas laisser diverger** :
`server/fcf-quality.js` et `cloud/src/lib/fcf-quality.js` — même limite déjà
documentée pour `SCORE_BANDS`/`SCREEN_FILTERS` ailleurs dans ce fichier.

**Vérifié avec `wrangler dev --local`** (compte de test créé, base D1
jetable) : AAPL donne exactement les mêmes chiffres qu'en local (80/100,
solide, 4 exercices) ; JPM (secteur financier) correctement non applicable ;
un symbole inconnu renvoie 502 ; les 4 cartes s'affichent dans le navigateur
connecté. **Déployé en production** — vérifié sur la vraie URL que la page
sert les cartes, que `js/fcf-card.js` répond 200, et que la route `/api/fcf`
exige une session (401 sans elle). **Non vérifié sur la vraie URL avec un
vrai compte** (identifiants non détenus par Claude).

## Roadmap — features de haut niveau pour la semaine du 22-27/9/2026

Demande de JP : pouvoir suivre dans bilbao ce qui a été livré cette
semaine, sans avoir à recomposer le fil à partir des sessions individuelles.
Six features de haut niveau créées via l'API de bilbao (`POST /api/feedbacks`,
jamais `features.json` à la main), toutes `Livre` :

| id | Titre |
|---|---|
| 369 | Options A — chaîne enrichie, meilleurs deals, flags par compte |
| 370 | Login et télémétrie — comptes, magic link, suppression par IP |
| 371 | Screener Prime — screener de primes multi-titres |
| 372 | Fondamentaux — EPS, FCF, qualité du FCF |
| 373 | Radar — screener multi-titres de meilleurs deals (local) |
| 374 | Interface compacte — gabarits de champs, chaque élément dans une carte |

Chacune renvoie vers sa section détaillée de ce fichier. #370 consolide des
livraisons déjà tracées individuellement (#356, #357, #366) plus la
suppression par adresse IP (21/9/2026), qui n'avait pas sa propre entrée.

## Repères d'interface — lettre par onglet, lettre+numéro par carte (27/9/2026)

JP veut pouvoir modifier rapidement un endroit précis de l'app, sans devoir
décrire l'onglet et la section à chaque retour — un testeur (ou JP
lui-même) doit pouvoir dire simplement « F3 » plutôt que « la troisième
carte de l'onglet Options ». Idée initiale de JP, affinée puis maquettée en
Artifact avant de coder (un chip de coin sur chaque carte, une lettre dans
chaque onglet, un interrupteur dans Réglages) — voir la conversation pour
le détail du choix de conception.

**Nouveau `js/ui-ids.js`** (+ copie identique `cloud/public/js/ui-ids.js`,
octet pour octet) : les identifiants sont **dérivés de l'ordre réel du
DOM à chaque chargement** (lettre = ordre des `.tab-btn` dans la barre
d'onglets, numéro = ordre des `.ds-card` DANS chaque onglet) — **jamais une
table écrite à la main**, même piège déjà documenté dans ce fichier
(`SCORE_BANDS`, `SCREEN_FILTERS`, `fcf-quality.js`) : une table dupliquée
dérive en silence dès qu'on ajoute un onglet ou une carte sans penser à la
mettre à jour ici. Conséquence directe : les 9 onglets se sont lettrés
A→I dans l'ordre réel du DOM (Secteurs, Screener, Fiche de trade, Journal,
Labo, Options, Options A, Screener Prime, Radar) — **pas** la liste à 8
que j'avais proposée de mémoire dans la conversation (j'avais oublié
l'onglet « Options » de base, distinct d'« Options A ») ; l'auto-dérivation
a corrigé cette erreur d'elle-même, sans intervention.

**Un onglet/une carte caché(e) par un feature flag compte quand même dans
la numérotation** — sa place dans le DOM ne change pas selon l'état du
flag (Options A, Screener Prime et Radar sont des `.ds-card` statiques,
juste `style="display:none"` tant que leur flag est OFF, jamais injectées
dynamiquement). Conséquence recherchée : « G3 » désigne toujours la même
carte, que le testeur ait ce flag activé ou non.

**Rendu en CSS pur**, via des attributs (`data-ui-tab`, `data-ui-card`) lus
par un `::before` (`content: attr(...)`) — **jamais un noeud enfant
injecté dans la carte** : plusieurs cartes (`js/fcf-card.js`,
`js/ticker-section.js`, le tableau de screening…) réécrivent leur
`innerHTML` au complet à chaque rafraîchissement, ce qui aurait effacé un
badge inséré comme enfant en silence. `initUiIds()` tourne une seule fois,
en tout dernier dans la séquence d'init (après `initRadarVisibility()`
local / à la fin de `bootApp()` cloud), pour que toutes les cartes
statiques soient déjà en place au moment de numéroter.

**Interrupteur rond** — recréation du « 16. Switch button » (Mojtaba
Seyedi), recensé sur prismic.io/blog/css-button-animations : silhouette
ronde en relief, grille de points, halo lumineux à l'activation, texte
ON/OFF qui bascule ; couleur ramenée à l'accent bleu de castellana plutôt
que le doré de l'original. Composant propre à cette carte
(`.ui-switch`/`.ui-switch-knob`), pas ajouté au design system partagé.
Câblé dans **Réglages → Technique**, en tête de liste, **OFF par défaut**
(comme tous les autres feature flags du produit) et **persisté en
`localStorage`** (`castellana-ui-ids`) — même patron que la bascule de
thème (`castellana-theme`) : une fois activé, le choix survit aux
rechargements, par navigateur/appareil (pas partagé entre JP et un
testeur, chacun garde le sien).

**Bug de spécificité CSS trouvé et corrigé en testant, pas en relisant le
code** : le conteneur flex de la carte utilisait `class="row"`, dont la
règle déjà existante `.row label { width: 260px; }` (12/9/2026, pour les
champs de formulaire) l'emportait sur `.ui-switch-knob { width: 44px; }` —
même `<label>`, spécificité supérieure — et étirait le disque en ovale.
Corrigé en retirant la classe `.row` du conteneur (remplacée par un style
en ligne équivalent) plutôt qu'en renforçant la spécificité de
`.ui-switch-knob`, pour ne pas ajouter une troisième couche de
contournement à un piège déjà documenté dans ce fichier (« watch your
selector specificity »).

**Vérifié en direct dans le navigateur** (local) : les 9 onglets lettrés
A→I, 46 cartes numérotées séquentiellement par onglet (`A1`…`A4`,
`B1`…`B6`, …, `G1`…`G5` pour Options A malgré son flag OFF), interrupteur
qui bascule ON/OFF avec halo et changement de disque, aucune erreur
console. 153/153 tests (`js/ui-ids.js` ajouté au test de parité root ↔
`cloud/public` de `server/labo-params.test.js`). **Le rendu cloud n'a pas
été vérifié dans `wrangler dev`** — les blocs ajoutés sont diffés
identiques octet pour octet à la version locale déjà testée (CSS, markup
de la carte, fichier JS), donc le risque résiduel est faible mais ce
n'est pas une vérification en direct du Worker. **Déployé en production**
le jour même (`fa79c5a2-efaa-4cbe-8424-c3aad5248535`, `wrangler deploy` —
aucune migration, changement purement statique), vérifié sur le
`content-type` de `/js/ui-ids.js` (`text/javascript`), pas seulement le
code 200.

## Roulement, repères G et intro de Secteurs (2/10/2026)

- **Roulement alimenté depuis la chaîne (onglet Options, F3/F6 → F7).** Chaque ligne de la chaîne (F3, un jeu de boutons par côté call/put) et des meilleurs deals (F6) porte « ↩ Racheter » et « ➜ Vendre » (colonne « Roul. »). Racheter prend l'**ask** (on paie pour fermer), Vendre prend le **bid** (on encaisse) ; un prix absent ou nul ne remplit rien et le dit (jamais un 0 inventé). Le calcul de F7 se lance seul dès qu'un bouton est cliqué ou qu'une prime/le nombre de contrats change ; une ligne (`#opta-roll-legs`) nomme les deux jambes, et une saisie manuelle repasse la jambe à « saisie manuelle ». Délégation d'événements sur `#tab-options-a` (`optaRollCell`, `setOptaRollLeg`, `js/options-tab-a.js`). F7 reste une carte séparée de F6 : ce sont deux opérations différentes (classer des contrats / comparer deux jambes, parfois d'échéances différentes). **Non fait** : boutons masqués en mode Achat de F6 (ils s'affichent mais l'ask n'a pas de sens pour un roulement), préremplissage de la jambe à racheter depuis une position ouverte du Screener Prime.
- **Repères G1…G7 (Screener Prime).** Les cartes de G sont injectées par `renderJournalATab()` après `initUiIds()`, donc n'avaient aucun repère. `js/ui-ids.js` expose maintenant `uiIdsNumber()` (numérotation idempotente, extraite d'`initUiIds`), rappelée après l'injection. G = intro G1, screener G2, calculateur G3, puis alertes, alertes de positions (local), bilan, cycles.
- **Clic sur une ligne du screener de primes (G2 → G3).** Toute la ligne est cliquable (`.janl-screener-row`, curseur main) et appelle `janlUseScreenerRow(i)` ; le bouton « Utiliser » reste comme repère visuel, sans handler propre (le clic remonte à la ligne — un handler en double l'exécuterait deux fois).
- **Intro de Secteurs.** Carte « À propos de cet onglet » ajoutée en tête (comme les autres onglets). ⚠️ Elle devient **A1** : l'ancienne A1 est A2, etc. — un retour de testeur sur « A3 » antérieur au 2/10/2026 ne vise plus la même carte.
- **Retouches du 2/10/2026 (suite).** Bouton « Utiliser » retiré du tableau de G2 (la ligne entière est cliquable, texte d'aide de G3 adapté). A2 renommée « Performance des secteurs - GICS (Global Industry Classification Standard) » et la ligne « Analyse sectorielle… » supprimée. Labo : la carte « Paramètres du filtre de tendance (SMA) » (E2) est retirée — les périodes se règlent dans Réglages → Valeur personnalisée ; les trois champs `labo-sma-fast/medium/slow` **restent dans un bloc `hidden`** car `loadLaboTicker()` les lit et `applyPreferences()` les synchronise (ne pas les supprimer sans adapter ces deux endroits). ⚠️ Les repères du Labo se décalent : « Stratégie » = E2, « Données réelles du titre » = E6. Commits `3dd6053` et `e4ddb02`, déployés (version `15484626`).
- **RSI** : la période du RSI était déjà éditable (Réglages → Valeur personnalisée → « RSI — période », défaut 14) ; rien à ajouter.
- Vérifié dans le navigateur local (AMD, ligne de screener simulée), 194/194 tests. **Vérifié par JP avec son vrai compte sur la version en ligne le 3/10/2026** ; JS déployé identique aux copies locales.

## Mode démo et favicon (2/10/2026, cloud)

- **Mode démo** — pour limiter les appels à Yahoo pendant une démonstration (limites 429 sur les adresses de Cloudflare). Interrupteur rond dans Réglages → Technique, sous « Repères d'interface », **OFF par défaut**, persisté en `localStorage` (`castellana-demo-mode`). Quand il est ON, `fetchJSON()` ajoute `X-Demo-Mode: 1` ; le Worker (`withDemo`, `cloud/src/db/cache.js`) prolonge le cache à **4 h** pour CETTE requête, ignore « force » (`cached()`, routes screening et titres du secteur), et, si Yahoo échoue, sert la **dernière valeur connue même vieille** (`stale: true` pour les routes qui le signalent). ⚠️ Les clés techniques (`cooldown`, `cookiejar` : jeton Yahoo, pauses après 429) ne sont **jamais** prolongées — une pause de 45 s qui durerait 4 h bloquerait tout. Bandeau 🎬 en haut : les prix sont figés, jamais présentés comme frais.
- **« Préparer la démo »** (`js/demo-mode.js`, cloud seulement) : parcourt une fois, côté client, secteurs, historique, screener watchlist/MAG7 puis, par symbole (6 max, éditable, défaut AMD/NVDA/AAPL), données de marché, Labo, FCF, chaîne d'options et grille. Orchestré par le navigateur (une requête par étape) pour rester sous le plafond de sous-requêtes d'une invocation ; 0,7 s entre étapes ; un échec n'arrête pas les suivantes. Mesuré : 9 étapes en ~8 s pour un symbole.
- **Limites** : version locale non concernée ; la chaîne d'options n'est préchauffée que pour l'échéance par défaut ; un cache vide ou > 4 h refait des appels réels (préchauffer juste avant la démo) ; **plafond d'appels par minute non construit**. Tests : `cloud/src/db/cache.test.js` (5). Vérifié en local (`wrangler dev`), puis **par JP avec son vrai compte sur la version en ligne le 3/10/2026**.
- **Favicon** : `favicon.svg` d'iecho.ca (ondes concentriques sarcelle) copié à la racine et dans `cloud/public/`, lié par `<link rel="icon">`. SVG seulement : Safari peut ne pas l'afficher dans l'onglet (ajouter un PNG si besoin).

## Price-to-Sales et contexte des fondamentaux (2/10/2026)

- **P/S (12 mois)** = capitalisation ÷ revenus, lu dans `summaryDetail.priceToSalesTrailing12Months` de Yahoo (vérifié égal à marketCap/totalRevenue sur AMD, NVDA, XOM, PLTR) : **zéro appel de plus**, et le cache brut de `quoteSummary` le contient déjà (pas de bump de clé côté fondamentaux). `null` pour un FNB ou une société sans revenus, jamais 0. **Repère « très bien » : 1 à 2**, vert (`CFG.fondamentaux.psBon` dans `config.js`, copie identique en cloud) — hors plage le P/S n'est PAS jugé mauvais (normal pour une forte croissance).
- **Où il apparaît** : tuile « P/S » de la bande Fondamentaux de la section Symbole (`js/ticker-section.js`, bande à 11 tuiles) ; colonnes **P/S** et **P/S secteur** après PEG dans A3 (titres du secteur) et B4 (screening), triables, ajoutées **à la fin** de l'export CSV (ordre existant préservé) ; 5ᵉ tuile de la carte « Fondamentaux » (A5/B6 et équivalents, `js/fcf-card.js`, grille `.grid-5`).
- **P/S « du secteur » = approximation par pairs**, comme le P/E industrie : **médiane** (pas la moyenne : un titre à 74× tirerait tout le secteur) du P/S des titres DU TABLEAU partageant le même secteur Yahoo, **≥ 3 pairs** sinon « — » (`sectorPsStats()` dans `server/screening.js` et `cloud/src/lib/screening.js`). Dans A3, ce sont les titres suivis du secteur cliqué (fiable) ; dans B4 avec une watchlist tech/IA, plusieurs secteurs n'ont que 1-2 titres. Pour les tuiles, la médiane vient du **dernier screening de la watchlist** (lecture passive du cache, `sectorPsFromScreeningCache`) : sans screening, le message le dit. Les lignes de screening portent maintenant `sector` (secteur Yahoo brut) ; un screening en cache d'avant le déploiement n'a pas le P/S jusqu'à son rafraîchissement.
- **Contexte des tuiles de la carte Fondamentaux** : EPS et FCF/action comparés au dernier exercice complet (« +49 % vs exercice 2025 »), FCF → marge de FCF (FCF ÷ revenus, `ttm.revenue` ajouté à `fcf-quality`, **clé de cache passée en `fcf-quality:v2:`** local et cloud), rendement du FCF vs le taux sans risque des paramètres de la Roue (défaut 4 %), P/S vs médiane du secteur. Exercice de référence ≤ 0 : pas de pourcentage, la valeur seule. Bulles (i) sur les 5 tuiles (`fcfEps`, `fcfTotal`, `fcfPerShare`, `fcfYield`, `priceToSales` dans `js/glossaire-indicateurs.js`) ; les seuils du rendement du FCF y sont des « repères usuels », pas des règles de castellana.
- **T2 livré (2/10/2026) — pondération du score fondamental.** Réglages → Valeur personnalisée : carte « Pondération du score fondamental », 5 poids entiers (croissance du FCF par action, régularité, conversion en cash, dilution, valorisation P/S) dont la **somme doit faire 100** (validée côté serveur, total en direct côté écran), **20 % chacun par défaut**, par compte. Stockés dans la table `preferences` sous des clés `fw_*` mais par leurs propres fonctions et routes (`/api/fundamental-weights`, GET/PUT/POST reset ; local `server/preferences.js`, cloud `cloud/src/db/preferences.js`) : la réinitialisation des périodes **ne touche pas** les poids et inversement. Le score est calculé **côté navigateur** (`fcfWeightedScore`, `js/fcf-card.js`) : les 4 mesures de qualité du FCF viennent du serveur (en points sur 25, cache 24 h) et la valorisation est évaluée sur le P/S courant (le prix bouge dans la journée) — donc le cache `fcf-quality` reste global. Moyenne pondérée ; un critère **sans donnée ou à 0 % est exclu** et les autres ramenés à 100 % (jamais compté comme un zéro) ; tous exclus → pas de score. Le titre devient « Score fondamental », le tableau gagne une colonne « Poids ». **Barème du P/S = PROPOSITION non validée** (< 1 → 75 %, 1–2 → 100 %, 2–5 → 75 %, 5–10 → 40 %, > 10 → 0 %), dans `config.js` `fondamentaux.psBareme` (pas d'écran de réglage). ⚠️ Le changement de défaut (20 % chacun avec P/S) modifie le verdict de certains titres par rapport à l'ancien score à 4 critères × 25 (AMD : 83 « Solide » → 66 « Mitigé » à cause du P/S de 25 ; P/S à 0 % retrouve exactement 83).
- **Couleurs vert / jaune / rouge des 4 tuiles EPS, FCF, FCF par action, rendement du FCF** (même jour) : `fcfTileBands()` (`js/fcf-card.js`, pur, testé) lit `CFG.fondamentaux.bandes` (`fcfMargeVert` 10 %, `fcfParActionHausseVert` +5 %, `fcfParActionBaisseRouge` −5 %, `rendementVert` 5 %, `rendementRouge` 2 %) — **propositions à valider** ; les popovers (i) lisent les mêmes valeurs (`_FB` dans `js/glossaire-indicateurs.js`) pour ne pas diverger. EPS : perte rouge, ≥ dernier exercice vert, en baisse jaune ; FCF : par la marge ; FCF/action : par la variation vs dernier exercice. **Une tuile sans comparaison possible n'a pas de couleur** (« non évalué », pas « neutre »). Le P/S garde sa règle propre : seul le vert (1–2) colore la tuile, pas de rouge (un P/S élevé est normal en forte croissance).
- **Section Symbole (A4, B5…)** : la bande des fondamentaux passe sur **2 lignes** (`.metric-band--rows`, `--cols:6`, 6 + 5 tuiles) ; Force relative et Golden Cross affichent **2 décimales** (champs arrondis par `fmt2`, badges `toFixed(2)`), et la colonne « Régime » est élargie (`1,6fr`, badge sans retour à la ligne).
- Tests : `server/fcf-card.test.js` (score pondéré, barème, couleurs des tuiles, évalués comme le navigateur via `vm`) et pondération dans `server/preferences.test.js`. 209/209.
- Commit `edf9b3b`, déployé (version `45521ae2`). Vérifié en local (AMD, JPM, XEQT.TO) et sur le Worker local (screening MAG7), puis **par JP avec son vrai compte sur la version en ligne le 3/10/2026**.

## IA étape 1 — « Claude analyste de contexte » (9/10/2026, #398, local seulement)

Première utilisation de l'IA dans castellana, tout le reste étant déterministe. Carte « Analyse de contexte (IA) » dans la **Fiche de trade** (décision de JP : pas de bouton sur B4), plafond **5 $/mois** par défaut.
- **Aucun effet** sur Setup/Contexte, sizing ni alertes. Résumé affiché avec « généré par IA, non vérifié — pas une prédiction », date, modèle, coût.
- `server/ai-analyst-logic.js` (pur, 11 tests, aucun réseau) : coût, plafond, plan assaini, actualités normalisées, schéma d'outil, validation, clé de cache. `server/ai-analyst.js` : rassemble fondamentaux + signal (`getHomemadeIndicators`, `scoreRow`) + actualités Yahoo `search()` (titre, date, éditeur, URL https), appelle `POST /v1/messages` en `fetch` (zéro dépendance) avec **appel d'outil forcé** (JSON structuré). Routes : `GET/PUT /api/ai/settings`, `GET/POST /api/ai/analyse/:ticker`. Table `ai_analyses` (jetons, coût, réponse, sources).
- **Garde-fous** : le prompt ne contient que les données rassemblées ; une actualité absente de la liste fournie fait **rejeter** la réponse, et les champs affichés viennent de la SOURCE, pas du modèle ; champ « non disponible » plutôt qu'une estimation. Le plan envoyé = pourcentages seulement (stop %, risque %, charge %, ATR %), **jamais** capital, taille ni montants. Clé `ANTHROPIC_API_KEY` dans le `.env` local (comme Resend), jamais renvoyée au navigateur ni journalisée. Cache par symbole + jour (New York) + `daysToEarnings` + modèle ; « Réanalyser » force.
- Réglages → Paramètres : modèle (Haiku 5.5 par défaut, Sonnet 5.5) et budget. **Écart au plan** : un seul appel par analyse, avec le modèle choisi, plutôt que Haiku pour le résumé et Sonnet pour la critique.
- ⚠️ Prix par million de tokens (`MODELS`) = **estimations à vérifier**. **Non testé avec une vraie clé** : chaîne vérifiée avec une réponse Claude simulée et de vraies données Yahoo. 258/258 tests. Non commité, rien à déployer.

## IA étape 2 — modèle statistique sur les backtests : NON adopté (10/10/2026, #399)

Question : peut-on estimer P(R > 1) d'un setup à partir des variables déjà calculées ? Réponse mesurée : **non**, pas avec ces variables. Tout est local, JS pur, zéro dépendance.
- **Jeu de données** (`server/dataset.js`, `scripts/build-dataset.mjs [univers] [années]`) : une ligne par trade simulé du signal d'alignement (`simulateSignal` renvoie maintenant `signalIndex`), 12 variables **connues à la clôture du signal** (RSI, ATR %, écart au SMA lent, écart SMA rapide/lente, rendement 20 j, force relative 60 j vs SPY alignée par date, volume vs 20 j, tendance OBV, volatilité 60 j, Golden Cross, SPY > SMA 200, VIX), résultat en R net (frais 0,1 % par côté) et brut, `exit_date`. Les 250 premières barres de chaque titre sont écartées (SMA 200). Valeur absente = cellule vide. **Test anti-fuite** : tronquer l'historique après le signal ne change aucune variable. Sortie : `data/dataset-<univers>.csv` (ignoré par git).
- **Modèle** (`server/ml-logistic.js`) : régression logistique ridge (Newton-Raphson), prétraitement (imputation, bornes 1-99 %, standardisation) **appris sur l'entraînement seulement**. **Validation en progression** : pour l'année de test Y, entraînement sur les trades dont le résultat était **connu** avant le 1ᵉʳ janvier de Y (`exit_date`, purge), jamais une ligne dans les deux jeux. Tests sur données synthétiques : retrouve des coefficients connus, **AUC ≈ 0,5 sur du bruit pur** (le protocole ne fabrique pas de signal).
- **Règle d'adoption fixée avant de regarder** (`scripts/train-model.mjs`) : AUC agrégé ≥ 0,55, Brier meilleur que la base, AUC > 0,5 dans ≥ 3/4 des années, et écart de R net du top 20 % dont la borne basse (bootstrap) est > 0.
- **Résultat** (7 589 trades, tests 2022-2026) : AUC 0,520 ; Brier 0,136 contre 0,133 (base) ; R net moyen +0,004 (tous) contre +0,014 (top 20 %), écart IC 95 % [-0,10 ; +0,12] ; calibration plate (7 % prédit → 16 % observé). Idem avec une régularisation ×20 et ×200. **Verdict : non adopté**, aucune probabilité affichée. Variables les moins faibles : RSI (+), écart au SMA lent (−), toutes très petites.
- **Lecture** : cohérente avec le backtest (le signal seul vaut ≈ 0 après frais). Des arbres boostés ne sont pas justifiés. **Réserves** : biais du survivant, IC optimiste (trades d'une même période corrélés), test limité au signal d'alignement. À rouvrir seulement avec de vraies variables nouvelles (#400) ou un autre signal, **avec le même protocole**.
- **Lien analyse IA ↔ trade** : `trades.ai_analysis_id` (migration additive). `createTrade` joint la dernière analyse du même symbole de **moins de 3 jours** (`AI_LINK_WINDOW_DAYS`), sinon rien ; l'analyse renvoie son `id`. Prépare le suivi des prédictions (#400). Pas de test automatisé (le module utilise la vraie base), **local seulement**.
- **Non fait** : test de l'étape 1 avec une vraie clé Claude (pas de `.env` ici), extension au S&P 500, IA en cloud. 272 tests.

## Expected move dans l'onglet Options (12/10/2026)

Question de JP : le strike idéal doit respecter la règle des 0,5 % de prime par semaine **et** se situer hors de l'expected move. Constat : l'EM est **calculé, pas une donnée propriétaire** (Barchart le dérive de la chaîne ; Yahoo et TradingView n'ont aucun champ dédié ; l'API de Barchart est payante et son scraping se heurterait à de l'anti-bot, non contourné). On le calcule donc depuis la chaîne Yahoo déjà chargée : zéro appel de plus, local et cloud identiques.

- **Formules** (`js/options-analytics.js`, source unique, copies cloud générées) : `optExpectedMove` = prix × IV<sub>ATM</sub> × √(DTE/365) × k, avec IV<sub>ATM</sub> = `optAtmIv` (médiane des IV des contrats |Δ| 0,40–0,60), **une seule IV pour toute l'échéance** ; `optEmPosition` (put hors plage si strike ≤ prix − EM, call si ≥ prix + EM) ; `optIdealStrike` (le contrat hors plage **le plus proche du prix**, car la prime baisse avec la distance ; `failsRule` si même celui-là ne respecte pas la règle, `null` si aucun strike coté) ; `optStraddleMove` (recoupement).
- **Multiple de σ réglable** : champ `#opta-em-mult` (défaut 1, 0,25 à 5), mémorisé par navigateur (`castellana-opta-em-mult`). 1σ ≈ 68 %, 2σ ≈ 95 % selon le modèle.
- **Affichage (F3)** : ligne de synthèse `#opta-em` (plage, IV, strike idéal ◆ put et call), pastille « hors EM / dans EM » dans la colonne Marge (contrats hors la monnaie seulement), colonne « Vs EM » dans les meilleurs deals. Carte repliable en bas de l'onglet, « Calculs et formules (transparence) » (`#opta-transparency`) : chaque formule avec les valeurs de la chaîne affichée, plus les limites.
- **Échéance du jour (DTE 0)** : EM non évaluable, message explicite (l'IV du jour même est du bruit).
- **Erreur corrigée en testant** : le recoupement par le straddle avait d'abord été écrit « straddle × 0,85 » (convention citée de mémoire), et l'écart avec l'IV atteignait −31 %. En Black-Scholes un straddle ATM vaut ≈ √(2/π) × EM(1σ) ≈ 0,80 × EM : le bon recoupement est **straddle ÷ 0,80**. Sur AMD : 46,22 $ contre 45,52 $ par l'IV, écart 1,5 %. Un test vérifie la cohérence algébrique.
- **Deux σ qui diffèrent légèrement** : la colonne Marge existante utilise l'IV de chaque contrat, l'EM celle de la monnaie (smile de volatilité) ; la section de transparence l'écrit.
- **Mesuré sur AMD (échéance à 11 j)** : EM ±45,52 $ (±7,7 %), plage 548,72–639,76 $ ; à 2σ, 503,19–685,29 $. Aucun put ni call hors plage ne respectait la règle ce jour-là (le premier put hors plage, 545, paie 57 % du seuil) : l'outil le dit au lieu de proposer un strike sous la règle.
- **Screener de primes G2 (même jour, déployé version `f62f1fc2`)** : colonne « Vs EM » après « Marge σ ». `optPickForChain` renvoie `atmIv` (IV à la monnaie de l'échéance, deltas recalculés contrat par contrat car les chaînes du serveur n'en portent pas) ; le navigateur calcule la plage avec le multiple de σ de F3 (`optaEmMult()`), donc changer le multiple met G2 à jour sans relancer le screener. Badge générique `optaEmBadge(type, strike, move, ideal)`, partagé avec F3 et les meilleurs deals. Les lignes issues d'un scan du Radar (univers élargi, S&P 500) n'ont pas `atmIv` : « — », jamais une valeur inventée. **Mesuré sur les MAG7 (puts Δ 0,15–0,25)** : tout est « dans EM » à 1σ et 2σ, ce qui est cohérent (un put de Δ 0,15–0,25 est à ≈ 0,6–0,8σ du prix) ; « hors EM » apparaît à 0,5σ (7/7) et à 0,75σ (TSLA seul). Pour être hors de la plage à 1σ il faut un delta ≲ 0,16 : un mode « strike hors EM + règle » dans G2 n'est pas construit. Note d'instruction ajoutée sous la ligne « Expected move » de F3 (hors EM = au-delà de la plage = à vendre ; dans EM = à éviter ; ◆ = idéal).
- **Non fait** : affichage cloud non vérifié avec un vrai compte (contenu servi vérifié seulement) ; un serveur local lancé avant le changement sert l'ancien calcul de G2 (relancer) ; EM avant résultats non traité à part (l'IV intègre déjà le saut). Aucune de ces valeurs n'est une recommandation. 293/293 tests.

## Trésorerie dans les fondamentaux et score pondéré (12/10/2026)

- **Source** : `financialData.totalCash` et `totalDebt` de Yahoo, module **déjà demandé** par `getFcfQuality` : zéro appel de plus. Renvoyés sous `balance: { cash, debt }` (`null` = Yahoo ne le donne pas, jamais 0 : une dette absente n'est pas une dette nulle). La dette de Yahoo **inclut les contrats de location**. Clé de cache `fcf-quality:v3:` (la forme de la réponse change).
- **Tuile « Trésorerie (cash) »** dans la carte Fondamentaux (`js/fcf-card.js`, grille `.grid-6`) : trésorerie, dette, trésorerie nette ou dette nette. Couleur par trésorerie ÷ dette (`bandes.tresorerieVert` 1, `tresorerieRouge` 0,25). Bulle (i) `cashEquivalents`.
- **6ᵉ critère « Solidité du bilan »** : `fcfCashFraction()` avec `CFG.fondamentaux.cashBareme` (≥ 1 → 100 %, ≥ 0,5 → 75 %, ≥ 0,25 → 40 %, sinon 0 ; dette nulle = 100 %). Cash ou dette inconnu → critère **exclu**, les autres ramenés à 100 %. **Poids par défaut : 0 %** (`WEIGHT_DEFAULTS.balance`) : l'activer à 20 % aurait changé tous les verdicts sans demande. Les cinq poids existants gardent leur 20 %, la somme reste 100. Barème et seuils de couleur = **propositions à valider**.
- Banques (`Financial Services`) restent « non applicable », comme le FCF. Tests : `server/fcf-card.test.js` (+4). Vérifié sur AAPL (62,4 G$ pour 84,3 G$, ratio 0,74), NVDA, AMD (trésorerie nette positive), XEQT.TO (`null` → N/D).

## RSP dans le tableau et le graphique des secteurs (12/10/2026)

- **RSP** (S&P 500 équipondéré) en 2ᵉ ligne de référence sous SPY dans A2, et en série du graphique (groupe « S&P 500 (SPY et RSP équipondéré) », coché par défaut, trait en **petits points** pour le distinguer des tirets de SPY). `EQUAL_WEIGHT_DEF` dans `sectors.js` (local et cloud) ; aucun équivalent TSX : en mode CAD la ligne reste RSP (US) et le dit.
- **Piège** : les routes `/api/sectors` (Express et Hono) **reconstruisent** la réponse (`{ sectors: sectorsWithPeg, benchmark }`) au lieu de passer `perf` tel quel : un champ ajouté à `getSectorPerformance()` est perdu en silence. Mon premier test avait **fabriqué le champ dans la page** et conclu à tort que ça marchait ; seul un test contre la vraie réponse du serveur l'a révélé. Clé de cache `sectors:perf:v2:` (trois endroits, dont `routes/market.js` et `server/index.js` qui la lisent en brut). Un serveur local qui tourne depuis avant le changement sert l'ancien code.

## Onglet Anticipation (12/10/2026, bilbao #418, cloud seulement)

- **Drapeau `anticipation_tab`** : OFF par défaut, surchargeable par compte depuis bilbao (colonne « Anticipation », ajoutée dans `feature-factory/public/`). **Contrôlé côté serveur à chaque appel** (`routes/anticipation.js`) : masquer l'onglet ne protège rien. Activé en production pour le compte **`iechocreator03`** (id 5) ; aucun compte `iecho-creator` n'existe.
- **Cartes** : `anticipation/cards.json` (versionné avec le code ; `featureId` = identifiant bilbao) + une maquette HTML autonome par carte (`semaine`, `earnings`, `plan`, `assigne`). Importées au build du Worker (`lib/anticipation.js`, règle « Text » de wrangler pour `.html`) et **servies par l'API authentifiée**, jamais en fichiers statiques publics. Affichées dans une `<iframe sandbox="">` via `srcdoc` : ni script, ni formulaire, ni accès à la page.
- **Règles pures** (`lib/anticipation-logic.js`, 10 tests) : 5 votes actifs, un vote par compte et par carte (clé primaire), une carte `livree` ou `rejetee` n'accepte plus de vote et **rend** les siens, 5 propositions par jour, bornes de longueur. Tables `anticipation_votes` et `anticipation_proposals` (migration `cloud/scripts/migrate-anticipation.mjs`, vérifiée par `sqlite_master`).
- **Statuts** : `maquette`, `planifiee`, `en_construction`, `livree`, `rejetee`, **écrits à la main dans `cards.json`** tant que bilbao ne les pousse pas (feature #430). Les propositions ne sont lisibles que par `GET /api/admin/anticipation` (Basic Auth admin) ; l'onglet bilbao pour les trier n'existe pas encore.
- **Limites** : limite de 5 votes vérifiée seulement par les tests unitaires (4 cartes seulement) ; affichage **non vérifié avec le vrai compte** ; pas de copie locale (pas de comptes en local). Les maquettes sont des chiffres d'exemple, rien n'y est calculé.
- **Parcours « Roue hebdo »** (features #419 à #429, toutes `Idee` sauf le feu des résultats `Planifie`) : préparation de la semaine, largeur MMTW/MMFI/MMTH calculée depuis le balayage, plan de match, position assignée, calendrier de la Roue, expected move depuis l'IV, profil « Roue » du screener, rotation sectorielle, résumé LLM ancré sur le calendrier. Aucun n'est construit.

## Réglages : onglet « Liens utiles » (11/10/2026)

- Nouvel onglet **Liens utiles** dans Réglages (`data-stab="liens"`, local et cloud), placé **après Concepts** pour ne pas décaler les repères `R-…` existants. Quatre liens externes (`target="_blank" rel="noopener noreferrer"`) : Options Profit Calculator (cash-secured put), OptionsAI, Barchart expected move (AVGO), une vidéo YouTube. Liste écrite en dur dans le markup des deux `index.html`. 274/274 tests ; affichage non vérifié dans le navigateur.
- **Connexion injoignable (constat)** : le même jour, `castellana.iechocreator.workers.dev`, `iecho.ca` et `essen-hub.iechocreator.workers.dev` ne répondaient pas depuis la machine de dev (DNS → `172.64.80.1`, délai dépassé) alors que `cloudflare.com` répondait. Tous les domaines étant touchés, la cause n'est pas propre à castellana (réseau/DNS/VPN ou Cloudflare) ; non identifiée.

## Réglages : repères, courriels, onglet TradingView (10/10/2026)

- **Repères d'interface** : l'interrupteur passe de Réglages → Technique à Réglages → **Personnalisation** (en tête). `js/ui-ids.js` numérote aussi Réglages : onglets `R-A`…`R-F` (Valeur personnalisée, Technique, TradingView, Paramètres, Personnalisation, Concepts — celui-ci compte même caché par son flag), cartes `R-D2`, etc. Préfixe `R-` pour ne jamais confondre avec une carte d'onglet principal. ⚠️ Les repères de cartes de **Technique** et **Personnalisation** se décalent. `ui-ids.js` reste identique octet pour octet en cloud.
- **Courriels pour les alertes** (Paramètres, local) : saisie **séparée par des virgules**. `normalizeEmails` (`server/app-settings.js`) accepte une chaîne (virgule, point-virgule ou saut de ligne) ou un tableau ; l'écran envoie la chaîne telle quelle et c'est le serveur qui découpe et valide (400 « Adresse invalide : … »). Maximum 10, doublons et casse normalisés.
- **Onglet TradingView (local)** nettoyé : carte « Trois façons de relier… » et « Option 3 — connexion au compte » supprimées (périmées : la connexion existe, voir la carte « Source de données » et #391/#381) ; il reste Source de données, Balayage, Sidecar (facultatif), Webhook. Pine Script : périodes réglables dans l'indicateur (plus de renvoi à « SMA 9/21/50 »). Deux **features à venir** créées et signalées dans les cartes : **#405** écran des alertes webhook (aujourd'hui `/api/alerts` en JSON), **#406** chiffrer au repos le jeton TradingView local. Version **cloud** : seules les phrases du webhook ont changé ; sa carte « Option 3 » dépend d'un flag par compte et est laissée telle quelle. #367 est encore `Planifie` dans bilbao alors que ses étapes 1 et 2 sont livrées (#381, #391) : à clarifier.

## AI Analyste en cloud et ménage des Réglages (10/10/2026, 2e passe)

- **Colonne « AI Analyste »** (bilbao, onglet Comptes castellana ; ex-« IA avancée ») : le flag `ai_analyst` est maintenant **réellement branché** côté Worker. `cloud/src/routes/ai.js` lit le flag effectif du compte (global ⊕ surcharge) à chaque appel : 403 `FLAG_OFF` sinon. `cloud/src/lib/ai-analyst.js` = portage de `server/ai-analyst.js` **sans Ollama** (Claude seulement) ; la logique pure `ai-analyst-logic.js` est une copie identique (test de parité). Carte « Analyse de contexte (IA) » dans la Fiche de trade cloud (`js/ai-analyst-tab.js`, identique en cloud, rendue visible par `initAiVisibility()` si le flag est ON).
- **Garde-fous cloud** : clé = **secret Wrangler `ANTHROPIC_API_KEY`** (jamais dans `wrangler.jsonc`) — sans elle, 503 « pas encore configurée » ; **plafond mensuel PAR COMPTE** (`AI_BUDGET_USD`, 2 $ par défaut) calculé sur `ai_analyses.user_id` ; cache par compte (le plan de trade est propre à l'utilisateur) ; modèle `AI_MODEL` (Haiku 5.5 par défaut). Table `ai_analyses` (`schema.sql`, `scripts/migrate-ai.mjs`).
- **Vérifié en local** (`wrangler dev` + D1 locale) : flag OFF → 403, flag ON sans clé → 503, avec une fausse clé → collecte des données puis 401 Anthropic correctement mappé (502 `API_ERROR`), symbole invalide → 400. **Le chemin réussi n'a jamais été testé avec une vraie clé.**
- **Pour l'activer en production** : (1) `node cloud/scripts/migrate-ai.mjs --remote` puis vérifier `sqlite_master` ; (2) `npx wrangler secret put ANTHROPIC_API_KEY` (saisie interactive) ; (3) `wrangler deploy` ; (4) activer le flag pour un compte dans bilbao. Non fait au moment de l'écriture.
- **Réglages locaux** : l'onglet **Paramètres** (R-D) est supprimé ; ses cartes (balayage planifié, courriels d'alertes, analyse IA) sont dans **R-C (TradingView)**, après le balayage manuel. Les textes « Réglages → Paramètres » renvoient à « Réglages → TradingView ». Message « Envoi impossible : RESEND_API_KEY absente… » : renvoie aux features #379 (alertes de positions) et #395 (résumé du balayage).
- **Section Symbole (A4/B5…, 10/10/2026)** : « Industrie » quitte la bande des fondamentaux et passe dans la rangée du symbole (champ en lecture seule à droite du bouton « Récupérer en direct », `#<p>-m-industry`, infobulle avec le texte complet). La bande fait donc **2 rangées × 5 colonnes (10 tuiles)** : `--cols:5` et filets `.metric-band--rows` recalés sur 5 colonnes (la surcharge mobile pour 6 colonnes est supprimée). Local et cloud (`ticker-section.js` identique).
- **Réglages R-C2** : balayage manuel, planification et courriels d'alertes regroupés dans une seule carte, séparés par des filets et des sous-titres numérotés (`.sub-title`) ; un seul bouton Enregistrer.
- **Bilbao** : en-tête « AI Analyste » ; le bouton Agrandir/Réduire de la carte Comptes est calé à droite de la barre d'outils.

## Option Lab sur la vraie chaîne et corrélation réelle (8/10/2026, #396 et #397)

- **#396 — vraie chaîne d'options dans l'Option Lab** (`js/labo-real-chain.js`, local et cloud). Sous l'estimation Black-Scholes, une carte « Vraie chaîne d'options » va chercher la chaîne Yahoo (même route que l'onglet Options, différée ~15 min), choisit l'échéance la plus proche de la cible de chaque jambe, calcule le delta de chaque contrat avec SON IV (`optionsAttachDeltas`) et montre les contrats dont le delta tombe dans la plage : bid, ask, écart, open interest, IV, **qualité**. Filtre de qualité (`laboQualityFlags`) : pas de bid/ask, écart > 25 %, OI < 50, IV > 300 % — un contrat douteux n'est **jamais retenu** (cas MTD du 8/10 : put à 85 $ avec IV de 329 %). **Credit Spreads** : jambe de protection réelle (strike listé le plus proche au-delà de la largeur), **crédit réel = bid vendu − ask acheté**, comparé à la règle `creditMinPct`. Mesuré sur TQQQ : crédit réel 0,59 $ sur 5 $ de largeur = 12 % contre 33 % exigés → règle non respectée. Chaînes en cache 5 min par session ; chargement automatique après « Charger ». Fonctions pures testées (`server/labo-real-chain.test.js`).
- **#397 — corrélation réelle dans la Fiche de trade.** `computeReturnCorrelation`/`buildCorrelationReport` (`server/indicators.js` et `cloud/src/lib/indicators.js`, duplication assumée) : Pearson des rendements logarithmiques quotidiens du symbole contre chaque position OUVERTE du Journal, alignés **par date**, fenêtre `CFG.correlation.window` (60 séances), seuil `CFG.correlation.threshold` (0,7), **null sous 20 rendements communs**. Route `GET /api/correlation/:ticker` (local ; cloud : positions du compte, plafond de 12). La Fiche remplit le choix « position corrélée ? » après « Récupérer en direct » et affiche la note (corrélation la plus forte, autres positions) ; **le choix reste modifiable à la main** et la note garde la valeur calculée. Aucune position ouverte → « non corrélé » ; historique insuffisant → pas de verdict, choix manuel. **Limite** : le screening (`sizingForCandidate`) suppose toujours `correlated: false` (plafond) ; positions du Journal seulement (pas d'autre courtier).
- 236/236 tests. Non déployé au moment de l'écriture.

## Balayage planifié, légendes et résultats dans F3 (8/10/2026, #395)

- **Balayage S&P 500 planifié** (local) : `startSweepScheduler` (`server/sweep.js`), un par jour ouvrable après 17 h à New York (règle pure `shouldRunDailyScan` du Radar), **case à cocher dans Réglages → Paramètres, décochée par défaut** (clé `app_sweep_auto`, `server/app-settings.js` ; plus de réglage dans `settings.json`), seulement tant que castellana tourne. Un balayage manuel du jour compte (pas de doublon).
- **Nouveautés depuis le précédent** (`server/sweep-news.js`, pur, testé) : « candidat » = verdict « prêt » ; nouveau = candidat qui ne l'était pas au balayage précédent, sorti = l'inverse. **Sans balayage précédent, aucune nouveauté n'est annoncée** (baseline). État en cache (`sweep:ready`, `sweep:news`, `sweep:last`, 30 j), route `GET /api/sweep/news`, carte « S&P 500 — nouveautés » dans le Screener (local seulement).
- **Courriel groupé** (Resend) pour un balayage planifié seulement, si `RESEND_API_KEY` et `ALERT_EMAIL` sont dans le `.env` local ; sinon la carte dit pourquoi. **Aucun SMS** (décision de JP). Courriel non testé de bout en bout (pas de clé locale).
- **Réglages → Paramètres** (local seulement) : la case ci-dessus et la liste des **courriels d'alerte** (0 à 10 adresses, une par ligne, validées ; `GET/PUT /api/app-settings`). Elles servent aux alertes de positions et au résumé du balayage ; les alertes de listes gardent l'adresse de chaque règle. Liste jamais enregistrée → repli sur `ALERT_EMAIL` du `.env` ; liste enregistrée vide → aucun courriel. Clés `app_*` de la table `preferences`, préservées par la réinitialisation des périodes. Il faut toujours `RESEND_API_KEY` dans le `.env`.
- **Légendes de couleurs** : F3 (vert = prime respecte la règle, bleu = ITM, bleu encadré = strike limite ★, lignes bleues = ATM) et G2 (vert, ligne grisée = sous la règle, ambre ⚠ = résultats avant l'échéance). Classes `.opt-legend*`.
- **Résultats dans le menu d'échéance de F3** : `earningsDate` et `earningsTiming` ajoutés à `getFundamentals` (local et cloud) et à `/api/labo/:ticker` ; une option désactivée « ── Earnings: Nov 3 ── » sépare les échéances. Le moment (« after close » / « before open ») est **déduit de l'heure à New York** donnée par Yahoo et omis quand elle n'est pas significative (cas d'AMD aujourd'hui) — jamais deviné.

## Vue sectorielle S&P 500 et backtest réaliste (9/10/2026, #401 et #402, local seulement)

- **#401 — « Setups du S&P 500 par secteur »** : carte dans Secteurs entre A2 et A3 (**les repères A3 et suivants se décalent d'un cran en local ; le cloud n'a pas cette carte**). Lit le dernier balayage (`screening:last:sp500`) : par secteur GICS (référentiel de `server/sp500.json`, libellés français), nombre de titres « prêt » et « à surveiller », total du secteur (largeur de la barre) et liste des « prêt ». Pure : `server/sweep-sectors.js` ; route `GET /api/sweep/sectors` (409 `NO_SWEEP` sans balayage). Seuls les titres retenus par le filtre ont un verdict.
- **#402 — backtest réaliste** (carte existante du Screener) : frais et glissement en % **par côté** (0,05 + 0,05 par défaut) appliqués à l'entrée (payée plus cher) et à la sortie (encaissée moins cher) ; le R net garde le risque **planifié** comme dénominateur. **Filtre de régime** optionnel : SPY clôture au-dessus de sa SMA (200 par défaut) et VIX ≤ seuil (0 = off), évalué à la barre du signal (aucun regard vers l'avenir) ; régime faux **ou inconnu** = signal ignoré. Le résultat compare **le même signal trois fois** (brut, avec frais, avec frais + régime) ; les tableaux par secteur/titre suivent la dernière lecture. Cache `backtest:v2:`. Mesuré sur MAG7, 3 ans : 153 trades, +0,30 R brut → +0,25 R avec frais → +0,23 R avec le filtre (152 trades) : **le filtre n'apporte rien ici**. Biais du survivant inchangé.

## Réglages → Personnalisation : 5 styles pour F3 et G2 (8/10/2026)

- `js/table-styles.js` (+ copie cloud, test de parité) : 5 styles (1 Thermomètre de la règle, 2 La ligne du prix, 3 Carte thermique sobre, 4 Rails d'état, 5 Échelle de σ). **Défaut : 5 pour F3, 4 pour G2.** Choix **par navigateur** (`localStorage` : `castellana-style-f3`, `castellana-style-g2`), jamais côté serveur ; local et cloud.
- Le tableau reçoit `tsx tsx<N>` ; l'ITM et la règle se lisent au niveau de la **ligne** (classes `itm/otm/ok/under/warn/lim`). Les anciennes classes `opt-itm`/`opt-rule-ok` ne sont plus posées sur les cellules de F3/G2.
- L'onglet montre, pour chaque style, un **aperçu vivant** (mêmes fonctions de rendu que le vrai tableau, données fictives) avec sa légende ; cliquer applique et redessine F3/G2 s'ils sont chargés. Bouton « Revenir aux styles par défaut ».
- Le mini-graphique de σ (style 5) est omis quand l'échéance est du jour (DTE 0) ou sans IV : jamais dessiné sur des données absentes.
- Maquette d'origine des 5 propositions : `prototypes/f3-g2-styles.html`.

## TradingView — trois modes et balayage S&P 500 local (7/10/2026)

Trois modes de données, demandés par JP : (1) **sans TradingView, via Cloudflare** (source Yahoo du Worker) ; (2) **avec TradingView, appels LOCAUX** sans Cloudflare ; (3) **avec TradingView, via Cloudflare** (étape 2 de #367, déjà en place). Décision de JP : le mode 2 vit dans **l'app locale** (le cloud n'affiche que 1 et 3 et renvoie vers le local pour le 2).

- `server/tv-local.js` : connexion OAuth 2.1 PKCE de l'app locale au serveur MCP officiel, en **important tels quels** `cloud/src/lib/tv-mcp.js` et `tv-symbols.js` (ESM pur, une seule implémentation). Jetons dans la table SQLite locale `tv_local` (jamais renvoyés par l'API ni journalisés, base gitignorée, **non chiffrés au repos**). Connexion mono-utilisateur persistante (≠ jeton par session du Worker). Appels sérialisés, 200 ms d'écart, **pause 60 s après un 429** ; mode « patient » (balayage) : attend et réessaie au lieu de basculer sur Yahoo. Yahoo reste le repli titre par titre. Source TradingView sans connexion → retour à Yahoo.
- Routes locales : `/api/tradingview/status|connect|callback|disconnect`, `PUT /api/data-source` (change de source → vide les caches `screening:*` et `sectors:topresult:*`). Redirect OAuth `http://<hôte>:4700/api/tradingview/callback` : l'inscription dynamique du client avec une adresse `localhost` a été acceptée par TradingView (vérifié) ; **le vrai login n'a pas été fait** — chemin TradingView local non vérifié avec un vrai jeton.
- Hooks : `getQuotes` (cache `quote:tv:`), `fetchDailyHistory` (cache `history:tv:`, options `ttl` et `patient`).
- **Balayage S&P 500** (`server/sweep.js`, `server/sp500.json` = 503 titres, Wikipedia au 7/10/2026, à rafraîchir à la main) : phase historique (cache 3 h, reprise naturelle) puis screening de l'univers `sp500` (filtre avant fondamentaux), résultat sous `screening:last:sp500`. Réglages → TradingView (local) pour lancer/annuler/suivre ; résultat dans Screener → « S&P 500 ». `/api/screening?universe=sp500` ne calcule jamais à la volée : 409 sans balayage récent. Exclu du screener de primes.
- **B2 et G2 (7/10/2026)** : bouton « S&P 500 » dans B2 (Screener) et option « S&P 500 » dans G2 (Screener Prime). **Local seulement** : en cloud, le bouton B2 est grisé (`disabled`) et l'option G2 est listée mais non sélectionnable (`option.disabled`, détection par `window.CASTELLANA_USERNAME`, comme l'univers élargi). G2 sur le S&P 500 relit un **scan hebdo du Radar sur 503 titres** (`deal_scans.univers = 'sp500'`, migration additive ; `createScan(fenetre, univers)`, `getLatestScan(fenetre, univers)`, `POST /api/deal-scanner/start {fenetre:'hebdo', univers:'sp500'}`, fenêtre hebdo seulement). Le Radar et l'historique d'IV ne voient que `univers = 'elargi'`. Mesuré : scan de 503 chaînes en 36 s, 70 titres sans hebdomadaires ignorés ensuite, 367 résultats.
- Mesuré en source **Yahoo** : 503 titres en 14 s, 48 retenus. Le débit en source TradingView est **inconnu** (429 fréquents observés le 30/9).

## Option Lab — refonte de l'onglet Labo (7/10/2026)

- **Renommé « Option Lab »** (bouton seulement ; id `tab-labo`, clés et routes inchangés).
- **Ordre** : À propos → Stratégie → séquence de la stratégie, puis les anciennes cartes de données (Symbole, Fondamentaux, Données réelles) dans `<details id="labo-data-wrap">`, repliable, ouvert par défaut, état retenu en `localStorage` (`castellana-labo-data-open`). ⚠️ Les repères d'interface se décalent : la séquence devient E3, les données E4 à E7.
- **Cases à cocher inversées** : plus de case sur les titres numérotés ; une case par sous-point (`laboStepDone[strat]['i.j']`) ; le titre se barre quand tous ses sous-points sont cochés.
- **« En clair »** : champ `enClair: { quand, comment }` sur chaque stratégie (`js/strategies-labo.js`), rendu par `laboRenderExplain()`, formulé pour quelqu'un de 15 ans. Textes rédigés par Claude, à relire.
- **Credit Spreads (Bull Put / Bear Call)** livré (`statut: 'disponible'`, schéma `credit-spreads` dans `js/labo-schema.js`) : jambe vendue par Black-Scholes comme les autres, jambe achetée à `spreadWidthPct` % du prix, crédit minimal `creditMinPct` % de la largeur, stop `stopLossMult` × crédit, avertissement si résultats avant l'échéance. **Aucune prime réelle** : le crédit minimal est une règle à vérifier dans la vraie chaîne. Iron Condor reste « à venir » (texte « En clair » déjà écrit).
- Copies cloud synchronisées (`npm run sync:cloud`, `cloud/public/`) ; test de schéma mis à jour (4 stratégies). 224/224.

## Graphiques de performance — style shadcn (3/10/2026)

Inspirés des Line/Area Charts de shadcn, pour A2 (Performance des secteurs) et B3 (Performance des titres retenus), qui partagent `renderPerfChart` (`index.html` et copie cloud).
- **Épaisseur** : les traits faisaient d'abord 2 px, comme shadcn ; JP les a ensuite voulus 0,5 px plus fins (déployé, validé en ligne le 3/10/2026) : 1,5 px pour les lignes pleines, 2 px pour le S&P 500, 1,75 px pour les indices (`.sector-chart-line` dans `index.html` et la copie cloud). Ajoutés : grille en pointillés, points actifs sur chaque ligne au survol.
- **Légende triée** du plus performant au moins performant sur la période (séries sans données à la fin), avec la performance en % : on retire les pires en cliquant de droite à gauche. Le tri se recalcule à chaque changement de période.
- **Période en liste déroulante** (`#sector-period-select`, `#screen-chart-period-select`) à la place des boutons `.period-btn`.
- Vérifié dans le navigateur local sur A2 ; B3 non lancé (même code). 209/209 tests.

## Fusion Options/Options A et connexion TradingView (29-30/9/2026)

**Onglet Options unique (29/9/2026).** L'onglet « Options » de base (lettre F) était redondant avec « Options A » : supprimé. Options A devient « Options », **sans flag** (`options_a_tab` retiré du local, du cloud et de la console bilbao). Les helpers partagés (`optEsc`, `optNum`, filtres, CSV) vivent dans `js/options-common.js`, dont dépendent Screener Prime et Radar. ⚠️ **Les lettres d'onglet après F se sont décalées d'un cran** (G→F, H→G, I→H) : un retour de testeur daté d'avant cette date ne désigne plus le même onglet. Déployé (`268102b5`).

**Connexion TradingView, étape 1 (30/9/2026, feature #367).** Cloud seulement, derrière le flag `tradingview_connect` (OFF par défaut, surchargeable par compte).
- **Spike concluant** : OAuth 2.1 + PKCE faisable dans un Worker, testé sur le réseau de Cloudflare. **Pas de SDK MCP** : `fetch` direct (`cloud/src/lib/tv-mcp.js`). Client public inscrit dynamiquement, un par adresse de retour.
- ⚠️ **TradingView répond 403 sans en-tête `User-Agent`.** On envoie toujours `castellana/1.0 (+https://iecho.ca)` — identité déclarée, pas un contournement.
- **Jetons liés à la SESSION** (`tv_oauth`, ON DELETE CASCADE + suppression au logout), jamais à `users` : il faut reconnecter TradingView à chaque nouvelle session castellana. `state`/PKCE en D1 (Worker sans état), usage unique.
- **Lecture seule** : seul l'outil `mcp-watchlist-list-watchlists` est appelé (renvoie déjà les symboles `BOURSE:SYMBOLE`, avec en-têtes `###Section` et actifs non actions). Portée demandée `mcp:read mcp:tools`.
- **Import** : la watchlist devient la liste « TradingView · nom » du Screener (ré-import = remplacement). Conversion pure et testée (`cloud/src/lib/tv-symbols.js`) : actions/FNB US et TSX seulement (`.TO`, `.V`, `BRK.B`→`BRK-B`) ; crypto, forex, futures, indices refusés et listés, jamais devinés. Plafond 50.
- **Source de données par compte** (`user_settings.dataSource`, Yahoo par défaut ; TradingView exige une connexion). **Étape 1 : le choix n'alimente que les watchlists** — cotations, indicateurs et options restent Yahoo. Étape 2 (fournisseur de cotations/historique via `get-symbol-data`/`get-ohlcv`) non construite : formats, quotas et durée de vie du jeton à mesurer avec un vrai jeton.
- Migration `cloud/scripts/migrate-tradingview.mjs` (--remote faite avant le déploiement, vérifiée par `sqlite_master`). Déployé (`b45a236d`). **Le flux de connexion réel (échange du code, lecture, import) n'a pas encore été vérifié avec un vrai login** — vérifié seulement jusqu'à la page de connexion TradingView.
- Roadmap bilbao : #375 backtest, #376 rétro-analyse score/R, #377 IV Rank, #378 bilan de la Roue, #379 alertes poussées, #380 alertes sur les listes.

**Connexion TradingView, étape 2 (30/9/2026) — fournisseur de cotations et d'historique.** Cloud seulement, derrière le flag `tradingview_connect` et le choix « TradingView » dans Réglages. `cloud/src/lib/tv-provider.js` : cotations en **lot de 50** (`mcp-tv-get-symbol-data-batch`), historique quotidien **un symbole par appel** (`mcp-tv-get-ohlcv`), résolution ticker Yahoo → `BOURSE:SYMBOLE` (NASDAQ, puis NYSE, puis AMEX ; TSX direct) mise en cache 30 jours dans `cache` (clé `tv:sym:`). **Yahoo est toujours le repli** (par titre) ; en-tête `X-Data-Source` (`tradingview` / `mixed` / `yahoo-fallback`) affiché en badge. Mesuré le 30/9/2026 : **le scanner de TradingView répond 429 régulièrement** (3 essais sur 6 depuis un poste) et le websocket de l'historique a échoué une fois → **pause globale de 60 s après un 429**, budget de 24 appels par requête (plan gratuit : 50 sous-requêtes), 2 échecs d'historique tolérés par requête, appels **sérialisés**. Données **différées ~15 min**, dernière barre partielle — même nature que Yahoo : le bénéfice est la cohérence avec les graphiques TradingView, pas la vitesse. Données obtenues via le compte en **cache par utilisateur** (`quote:tv:<id>:`, `history:tv:<id>:`), jamais dans le cache global ; changer de source **vide** les caches dérivés de l'utilisateur (screening, titres du secteur). Une source « TradingView » sans connexion valide est **ramenée à Yahoo** automatiquement. **Reste sur Yahoo** : fondamentaux, chaînes d'options, ETF sectoriels, VIX/indices. La devise n'est pas fournie (nulle part consommée). Le screening principal (`getHomemadeIndicatorsBatch`) contournait `fetchDailyHistory` : branché séparément. **Le chemin réussi n'a pas été testé avec un vrai jeton** (login de JP requis) ; testé : repli avec jeton factice (401), état ramené à Yahoo, screening MAG7 en repli.

## Alertes, backtest, rétro-analyse et IV Rank (30/9/2026)

Six features livrées le même jour (bilbao #380, #375, #376, #377, #378, #379). Sauf mention, **LOCAL uniquement**.

- **Alertes sur les listes (#380).** `server/list-alerts-logic.js` (pur, testé) + `server/list-alerts.js` (base, screening, courriel). Règles par liste (watchlist / MAG7 / liste perso — jamais l'univers élargi) : setup devient « prêt », alignement perdu, RSI franchit un seuil, résultats imminents, put à rendement annualisé ≥ X %. **Déclenchement sur TRANSITION**, jamais sur un état continu ; le premier passage d'une règle enregistre l'état sans alerter ; une donnée manquante ne modifie jamais l'état mémorisé. Évaluation toutes les `listAlerts.autoRunMinutes` min (60), jours ouvrables 9 h–17 h New York, **seulement tant que castellana tourne**. Boîte d'alertes dans l'onglet Screener ; courriel groupé via Resend si `RESEND_API_KEY` est dans un `.env` local (ajouté au `.gitignore`) — **sans clé, aucun courriel ne part et l'interface le dit**. Chemin courriel non testé de bout en bout (pas de clé locale).
- **Backtest du signal d'alignement (#375).** `server/backtest.js` : entrée à l'ouverture suivant le premier alignement, stop N × ATR (contrôlé avant la sortie), sortie sous la SMA moyenne, une position à la fois. **Simulation** : sans frais ni glissement, et **biais du survivant** (listes d'aujourd'hui) — l'interface l'écrit. Mesuré : MAG7 sur 5 ans = 216 trades, +0,45 R moyen, mais **univers élargi (219 titres) = 6 820 trades, +0,06 R moyen, facteur de profit 1,12** : le signal seul a un avantage mince. Un trade recalculé à la main concorde.
- **Rétro-analyse score → R (#376).** Groupes par score Setup, Contexte, alignement et âge du signal dans Journal & stats (local et cloud). Un trade sans score n'entre dans aucun groupe. Aujourd'hui **aucun trade clôturé ne porte de score** : la carte le dit et avertit sous 30 trades.
- **IV Rank réel (#377).** `server/iv-rank.js` : IV à la monnaie par jour (médiane des contrats |delta| 0,4–0,6) accumulée par le Radar, groupée par **date de New York**. `optAtmIv`/`optIvRank` dans `js/options-analytics.js` (source unique, copies générées). Rang 0–100 + percentile, **null sous 20 jours**. Quand disponible il **remplace** le proxy IV vs volatilité historique dans la valorisation (Options et Radar), sinon repli explicite (`basis: 'hv'`). Scan quotidien automatique après 17 h New York (`dealScanner.autoDaily`). **Collecte lancée le 30/9/2026 : le rang ne s'affichera qu'à partir d'environ fin octobre** (2 jours d'historique aujourd'hui). Un jour où l'app est fermée est un jour sans observation.

- **Bilan de la Roue par cycle (#378, local ET cloud).** `optCycleBilan`/`optCloseOnOrBefore` (`js/options-analytics.js`, source unique, copie cloud générée) : primes encaissées − coûts de rachat (jambes rachetées/roulées seulement), résultat réalisé de l'action (Journal, via `option_cycle_id`), latent au dernier cours si détenue (**null**, jamais 0, sans cours), capital = max(strike × contrats, coût de l'action), rendement, annualisé **seulement à partir de 30 jours**, coût de base réel, et comparaison à la **détention** du titre sur la même période (cours de début/fin Yahoo ; sans dividendes ni frais des deux côtés). Route `/api/option-cycles/bilans` déclarée AVANT `/:id`. Carte dans Screener Prime. Vérifié sur un cycle de démonstration (créé puis supprimé).
- **Alertes de positions poussées (#379, local).** `server/position-alerts-logic.js` (pur, testé) + `server/position-alerts.js`. Trois transitions : jambe à ≤ 7 jours de l'échéance, seuil de prise de profit atteint (part de prime captée d'après le rachat estimé, `profitTakeMin` de la Roue), stop initial d'une action du Journal touché (cours Yahoo, donc différé). La **première observation d'une position n'alerte jamais** ; une donnée manquante ne modifie pas l'état ; une position fermée efface son état. Évalué par le même passage planifié que les alertes de listes (heures de marché, tant que castellana tourne). Boîte dans Screener Prime (carte masquée en cloud) ; courriel groupé si `ALERT_EMAIL` **et** `RESEND_API_KEY` sont dans le `.env` local — sinon la boîte de l'app seule, et l'interface le dit. Chemin de déclenchement vérifié avec une action de test (stop relevé entre deux évaluations) ; **courriel non testé** (pas de clé locale).

## État

- 2026-07-22 : cadrage initial. Document de design consolidé
  (`design_assistant_swing_trading.md`), nom de code **castellana** assigné,
  ce `CLAUDE.md` créé (remplace un contenu erroné — copie de celui de bilbao
  — collé par erreur dans ce dossier). Architecture, périmètre MCP et
  intégration au portfolio (bilbao, root `CLAUDE.md`) encore à faire.
- 2026-07-22 : les deux prototypes HTML (`fiche_trade_sizing_stop.html`,
  `ecran_selection_titres.html`) confirmés présents à la racine du dossier
  (déposés par JP). Copie vendorée de `design-system/tokens.css` et
  `components.css` ajoutée dans `design-system/` — résout le point
  « Design system » de la section Architecture.
- 2026-07-22 : les deux prototypes rendus conformes au design system, à la
  demande de JP — liens vers `design-system/tokens.css`/`components.css`,
  suppression des `:root` locaux dupliqués/dérivés (`--surface2` →
  `--surface-2`, etc.), adoption des composants `.ds-card`/`.ds-badge`/
  `.ds-metric`/`.ds-input`/`.ds-select`. Comportement/calculs inchangés,
  vérifié en navigateur. Repo Git initialisé, premier commit, repo GitHub
  privé créé et poussé
  ([iechocreator-po/trading-assistant](https://github.com/iechocreator-po/trading-assistant)).
  Produit ajouté au `CLAUDE.md` racine (table sommaire, fiche détaillée,
  table de consommation du design system) et à `REPOS` dans
  `portfolio-checkin.sh`.
- 2026-07-22 : décision prise sur les explications pédagogiques
  d'indicateurs — pas d'appel dynamique à un modèle Claude. Structure
  retenue : `js/glossaire-indicateurs.js`, objet JS statique par indicateur
  (`label`, `pourquoi`, `bandes.{vert,amber,rouge}`), calqué sur les bandes
  de la section 4.4 du design doc. Une seule fonction de rendu lit ce
  glossaire pour le tooltip/popover. Aucune clé API, aucun credential.
  Résout le point « Explications d'indicateurs » de la section Architecture.
- 2026-07-22 : les deux prototypes fusionnés en une seule app à onglets. À
  la demande de JP (« c'est le même produit », « les écrans devraient être
  fusionnés avec un système d'onglet ») : `index.html` créé à la racine,
  onglets « Écran de sélection » / « Fiche de trade », transfert automatique
  du ticker de l'un vers l'autre au changement d'onglet. `config.js` créé en
  parallèle (fichier de réglages demandé par JP) — voir entrée
  Configurabilité plus haut. Les anciens fichiers `fiche_trade_sizing_stop.html`
  et `ecran_selection_titres.html` déplacés (`git mv`) dans
  [`prototypes/`](prototypes/), conservés à titre de référence historique
  uniquement, ne sont plus la source de vérité. Vérifié en navigateur :
  bascule d'onglet, transfert du ticker, libellés/bornes pilotés par
  `config.js` (SMMA 9>21>100, RSI(14), capital 50000$, risque 1%), calculs
  de sizing inchangés.
- 2026-07-22 : décision d'architecture de JP — le stack sera un backend
  (pas frontend statique + service à part), puisque le serveur MCP
  TradingView en nécessite un de toute façon. Patron retenu : Node Express +
  better-sqlite3 (même patron que valencia/bilbao). Résout le point
  « Stack » de la section Architecture ; le backend lui-même reste à
  scaffolder (pas encore de `package.json`/`server/` dans ce dossier).
- 2026-07-22 : demande de JP sur les feature flags — pas de
  `bilbao.features.json` créé à la main : ce fichier est, par convention
  établie dans tout le portfolio (voir `CLAUDE.md` racine, section
  « Convention — fichiers standards par produit »), écrit exclusivement par
  la Console de bilbao (`PUT /api/console/:code/flags`), jamais à la main —
  règle qui évite justement d'avoir deux sources de vérité qui dérivent
  (même leçon que R16/R20/R24 chez bilbao). Reste en attente d'une session
  bilbao dédiée (voir Checklist portfolio ci-dessous).
- 2026-07-22 : adoption de `tradingview-mcp` comme serveur MCP TradingView,
  après évaluation par Claude (README + code source
  `core/services/indicators.py` du projet, pas seulement la description
  marketing) et décision de JP (« adopte-le pour ça et documente le
  reste »). Couvre VIX/RSI(14)/ATR(14)/Volume-vs-moyenne-20j/Golden Cross
  avec de vraies valeurs calculées, correspondant à la logique déjà validée
  du design doc. Deux lacunes identifiées et documentées plutôt
  qu'ignorées : son champ « OBV » est une fausse heuristique (clôture vs
  ouverture de la bougie, pas un vrai cumul), et la SMMA 9/21/100 n'est pas
  exposée (seulement SMA/EMA) — les deux resteront des calculs maison sur
  historique OHLC brut, source encore à choisir. Résout le point « Serveur
  MCP TradingView » de la section Nouvelles exigences et le point
  « périmètre MCP » de la section Architecture ; **n'implémente rien
  encore** — pas de sidecar lancé, pas de dépendance ajoutée au projet, la
  décision est documentée en amont du scaffold du backend.
- 2026-07-22 : scaffold du backend livré (Node Express + better-sqlite3,
  patron valencia/bilbao). `package.json`, `settings.json` (port 4700),
  `server/db.js` (schéma `trades` — journal de trades, section 7 du design
  doc), `server/index.js` (écoute 127.0.0.1 uniquement, sert `index.html`
  statiquement, route `GET /api/health`). Piège npm connu du CLAUDE.md
  racine rencontré et contourné (`npm install --cache
  /tmp/npm-cache-castellana`, EACCES sur le cache root-owned). Vérifié :
  boot, `/api/health` → `{status:"ok",trades:0}`, app identique en
  `http://127.0.0.1:4700/` à ce qu'elle était en `file://`. Serveur de test
  arrêté après vérification — rien ne tourne en arrière-plan. Résout le
  point « scaffold du backend » de la section Architecture. Reste ouvert :
  brancher `tradingview-mcp`, les calculs maison OBV/SMMA, et des routes
  API pour la table `trades` (elle existe, rien ne l'utilise encore).
- 2026-07-22 : `tradingview-mcp` branché en sidecar Python (demande de JP).
  Installé dans un venv dédié non commité (`.venv-mcp/`), lancé en
  `streamable-http` sur `127.0.0.1:4701` (`npm run sidecar`).
  `server/tradingview.js` (client `@modelcontextprotocol/sdk`, connexion
  paresseuse) + route `GET /api/market-data/:ticker` dans `server/index.js`
  (503 propre si le sidecar est injoignable, même patron que le
  `GITHUB_TOKEN` absent chez bilbao). **Testé avec des données réelles**,
  pas des mocks : `curl .../api/market-data/AMD` → VIX 16.64, RSI 56.09,
  Golden Cross confirmé. **Correction importante découverte en testant** :
  ATR et volume-vs-moyenne-20j, évalués « ✅ réel » lors de la décision
  d'adoption sur la seule lecture du code source, reviennent en fait `null`
  en usage réel (la librairie sous-jacente `tradingview_ta` ne demande pas
  ces champs par défaut) — reclassés en calcul maison aux côtés d'OBV réel
  et de la SMMA 9/21/100. Découverte additionnelle : la version PyPI
  installée (0.7.1) est en retard sur le README du repo GitHub — plusieurs
  outils documentés n'existent pas dans le paquet publié ; le bon outil
  pour l'analyse technique s'appelle `coin_analysis`, pas
  `get_technical_analysis` comme supposé initialement. Section « Intégration
  données de marché — tradingview-mcp » corrigée en conséquence. Serveurs
  de test (Express + sidecar) arrêtés après vérification — rien ne tourne
  en arrière-plan. Le frontend (`index.html`) ne consomme pas encore cette
  route — les champs y restent saisis à la main pour l'instant.
- 2026-07-22 : JP demande de lancer les deux process pour usage réel (pas
  juste un test) — backend + sidecar démarrés et **laissés actifs** cette
  fois (contrairement aux vérifications précédentes où ils étaient arrêtés
  après coup). Vérifié : `/api/health`, `/api/market-data/AMD` (données
  réelles), rendu de l'app dans le navigateur — tout fonctionne.
- 2026-07-22 : câblage du frontend sur les données temps réel + tableau de
  screening 20 titres (demande de JP). **Rate-limit de `coin_analysis`
  découvert en testant** (confirmé deux fois, persistant plus de 5 minutes,
  re-déclenché par un screening lancé juste après un autre — voir section
  dédiée « Rate-limit non documenté »). Réponse de conception : résilience
  par source dans `server/tradingview.js`/`server/index.js`
  (`Promise.allSettled`, jamais `Promise.all` ; force relative sourcée de
  `yahoo_price`, indépendante du scanner TradingView rate-limité). Livré :
  `server/watchlist.js` (20 titres — 12 de JP + 8 ajoutés par Claude,
  `top_gainers` testé et rejeté car ramène des micro-caps spéculatives sans
  rapport avec la stratégie) ; `screenWatchlist()` séquentiel espacé
  (1.5s/titre, ~30-60s pour 20) ; route `GET /api/screening` (score sur 3
  colonnes RSI/Force relative/Golden Cross — OBV exclu, pas fiable ; verdict
  `ajouter`/`surveiller`/`ne pas ajouter`/`erreur`) ; route
  `GET /api/quote/:symbol` (cotation Yahoo simple, résiliente) ; correction
  de résilience sur `GET /api/market-data/:ticker` (était `Promise.all`,
  donc perdait le VIX — pourtant disponible — quand `coin_analysis`
  échouait ; passé à `Promise.allSettled`). Frontend (`index.html`) : bouton
  « Récupérer en direct » sur les deux onglets, carte « Screening — univers
  de titres (20) » avec tableau cliquable (sélectionner une ligne charge le
  titre dans la section Ticker). **Vérifié en direct de bout en bout, deux
  fois** : une première fois en dégradé pendant le rate-limit (force
  relative seule disponible, RSI/Golden Cross vides, table affichée sans
  planter), une seconde fois après résorption du rate-limit (~5-10 min plus
  tard) avec RSI/Golden Cross/scores réels et corrects dans le tableau
  trié. Aucune donnée inventée à aucun moment — soit la vraie valeur, soit
  `null`/`erreur` explicite. Serveurs laissés actifs (voir entrée
  précédente).
- 2026-07-23 : OBV réel et SMMA 9/21/100 livrés (demande de JP : « Attaque
  les calculs maison »). Source OHLC brute tranchée : `yahoo-finance2`
  (npm), historique quotidien direct — écarté Alpha Vantage
  (`TIME_SERIES_DAILY`, déjà connecté côté JP) pour cet usage précis, quota
  25 req/jour trop bas pour un screening de 20 titres. Nouveau
  `server/indicators.js` : `computeSMMA()` (RMA standard), `computeOBV()`
  (cumul classique), `classifyOBV()` (approximation confirme/diverge sur
  fenêtre de 10 barres — documentée comme approximation, pas une détection
  formelle de divergence), `getHomemadeIndicators()` +
  `getHomemadeIndicatorsBatch()`. Module autonome, aucune dépendance à
  `tradingview-mcp`. Branché sur `GET /api/market-data/:ticker` (3ᵉ branche
  `Promise.allSettled`, indépendante des deux autres sources) et
  `GET /api/screening` (OBV réintégré comme 4ᵉ colonne du score, résout
  l'écart au design doc noté lors du lancement de la fonctionnalité de
  screening). Frontend : sélecteur OBV de la Fiche de trade auto-rempli par
  « Récupérer VIX + RSI en direct » (sans cocher la checklist
  automatiquement — reste un geste manuel de JP), indice d'alignement SMMA
  affiché en texte à côté de la checklist, colonne OBV ajoutée au tableau
  de screening. **Vérifié en direct** (AMD, données réelles) : SMMA
  9>21>100 cohérente avec le prix et le Golden Cross déjà confirmé par
  `tradingview-mcp`, OBV réel calculé et classifié `accumulation` ;
  screening à 4 colonnes re-testé, verdicts cohérents sur les 20 titres.
  Reste ouvert : ATR réel et volume vs moyenne 20j (même approche à
  étendre sur `server/indicators.js`, non demandé cette session).
- 2026-07-23 : session interrompue (« ta session est morte en cours de
  travail ») puis reprise — état vérifié avant de continuer : les deux
  serveurs tournaient toujours (Express 4700, sidecar 4701), aucun commit
  perdu, `git log` cohérent des deux côtés. Les commits `194752f`
  (trading-assistant) et `27cf6ab` (portfolio-meta) de la session
  précédente poussés à ce moment-là.
- 2026-07-23 : ATR réel et volume vs moyenne 20j livrés (demande de JP :
  « Attaque l'ATR réel et le volume vs moyenne 20j »), même module
  `server/indicators.js`. `computeTrueRange()` + `computeATR()` (Wilder —
  réutilise `computeSMMA()` sur le True Range, l'ATR de Wilder EST une
  SMMA) ; `computeVolumeVs20d()` (volume du jour ÷ moyenne des 20 jours
  **précédents**, jour courant exclu de sa propre référence). Branché sur
  `/api/market-data/:ticker` (préfère le calcul maison, `tradingview-mcp`
  en repli) ; le bouton Fiche de trade renommé « Récupérer VIX + RSI + ATR
  + OBV en direct » remplit maintenant aussi le champ ATR, et le hint
  texte combine alignement SMMA + ratio de volume. **Vérifié en direct**
  (AMD) : `atr=36.44$` (≈6.6% du prix), `volumeRatio=0.42` (42% de la
  moyenne 20j) — tous les indicateurs du design doc sont maintenant
  calculés à partir de vraies données, plus aucun `null` structurel.
  **En cours de route, découverte que le sidecar tradingview-mcp était
  mort** (crash pendant l'interruption de session ci-dessus) — relancé
  (`npm run sidecar`), et la connexion MCP côté Express s'est rétablie
  automatiquement sans redémarrage d'Express (le transport
  `streamable-http` n'est pas une socket persistante à re-répondre à la
  main). Cet incident a directement motivé la demande suivante de JP
  (témoin de statut + aide au dépannage), traitée dans la foulée.
- 2026-07-23 : témoin de statut backend + zone d'aide repliable ajoutés
  (demande de JP, suite à l'incident sidecar ci-dessus). `GET /api/status`
  (`server/index.js`) agrège 3 vérifications : `db` (`SELECT 1`),
  `tradingviewMcp` (`checkSidecarConnection()` dans `tradingview.js` —
  `listTools()`, poignée de main MCP qui n'appelle **aucun** outil, donc ne
  consomme jamais le quota du scanner rate-limité), `homemade`
  (`checkYahooConnection()` dans `indicators.js` — cotation SPY minimale,
  teste `yahoo-finance2` directement plutôt que de transiter par le
  sidecar). **Erreur corrigée en cours de session** : premier jet du
  contrôle "homemade" appelait `getPrice('SPY')` de `tradingview.js` — ça
  testait le sidecar une deuxième fois, pas `yahoo-finance2` ; remplacé par
  `checkYahooConnection()`, un vrai test indépendant. Frontend
  (`index.html`) : 3 pastilles colorées (vert/rouge/amber `is-checking`)
  dans le header, hors des onglets (visibles peu importe l'onglet actif),
  actualisées au chargement + toutes les 30s + bouton manuel. Zone
  `<details>`/`<summary>` native (repliée par défaut, zéro JS requis pour
  le pli) juste en dessous, avec les commandes de relance (`npm start`,
  `npm run sidecar`, `lsof -ti:PORT | xargs kill` si port occupé) et le
  rappel du rate-limit `coin_analysis`. **Vérifié en navigateur** : les 3
  pastilles passent au vert avec les deux serveurs actifs, la zone d'aide
  s'ouvre/se referme correctement, le contenu affiché correspond à la
  section « Lancer l'application » de ce fichier (pas de divergence entre
  les deux).
- 2026-08-29 : P/E ratio, industrie et P/E moyen de l'industrie ajoutés au
  tableau de screening (demande de JP). `server/fundamentals.js` : module
  Yahoo `summaryProfile` ajouté à l'appel `quoteSummary` existant,
  `peRatio`/`industry` extraits sans appel réseau supplémentaire. P/E de
  l'industrie calculé dans `server/index.js` comme la moyenne des P/E des
  titres de la watchlist (20) partageant la même industrie — **pas un vrai
  agrégat sectoriel de marché**, documenté comme tel (voir section
  « Screening — P/E ratio et industrie » plus haut), avec
  `industryPeerCount` exposé et affiché en tooltip pour ne jamais laisser
  croire à un échantillon plus large qu'il ne l'est. Colonnes ajoutées au
  tableau HTML et à l'export CSV. **Vérifié en direct** (backend redémarré
  pour charger le code, données réelles) : Semiconductors (AVGO/NVDA/AMD)
  → P/E industrie 70.8 sur 3 pairs ; AAPL seul dans Consumer Electronics →
  P/E industrie = son propre P/E, `industryPeerCount: 1`. Rendu vérifié
  dans le navigateur (tableau, tooltip).
- 2026-08-29 : carte « Performance des secteurs » ajoutée au-dessus du
  screening dans l'écran de sélection (demande de JP, inspirée d'un tableau
  de performance sectorielle). Nouveau `server/sectors.js` : 11 ETF SPDR
  Select Sector + SPY en repère, un seul appel `yahooFinance.quote()` par
  ETF (performance + P/E trailing en un coup, pas besoin de `quoteSummary`).
  Route `GET /api/sectors`, pas de cache (rapide, ~2.5s pour 12 titres, pas
  affecté par le rate-limit de `coin_analysis`). Chargement automatique au
  démarrage de la page (`loadSectors()`), tri par performance décroissante,
  couleur verte/rouge, ligne S&P 500 mise en évidence en bas. **Vérifié en
  direct dans le navigateur** (backend redémarré pour charger le code) :
  11 secteurs + SPY, tri et couleurs corrects, données réelles cohérentes
  avec un aperçu de marché externe pris comme référence.
- 2026-08-29 (deuxième round) : six demandes traitées dans la foulée. **(1)
  Line graph de performance sectorielle** — voir section dédiée plus haut ;
  skill `dataviz` du portfolio consultée avant d'écrire le SVG à la main
  (pas de librairie ajoutée). **(2) Menu Réglages** en overlay plein écran
  (⚙), remplace l'ancien `<details>` d'aide — repris du principe de
  `SettingsPage.tsx` chez essen/nemesis-retaliation (topbar titre+fermer,
  cartes de contenu). **(3) Clic sur une ligne du screening** — déjà câblé
  fonctionnellement (`selectScreeningRow()` remplissait déjà le champ
  Ticker), mais invisible sur un tableau qui occupe tout le viewport ;
  ajouté un `scrollIntoView` + flash de surbrillance (`.flash-highlight`,
  animation CSS) pour rendre le déplacement du ticker réellement visible.
  **(4) Terminologie SMMA/MM → SMA** — voir section « Calculs maison » et
  entrée dédiée ci-dessous. **(5) Capsules d'aide manquantes sur
  « Objectifs — Multiples de R vs Fibonacci »** — deux nouvelles entrées
  `rMultiples`/`fibonacci` dans `js/glossaire-indicateurs.js`, boutons `i`
  ajoutés à côté des deux `colhead`. **(6) Confusion sur « ajouter à la
  liste de suivi active »** — JP a signalé, à raison, qu'aucune liste
  réelle n'était derrière ce texte du banner (c'était une formule
  d'intention, pas une fonctionnalité). Clarifié en deux temps : le texte du
  banner ne parle plus de "liste" mais d'un "candidat à suivre au screening
  quotidien" ; et un vrai bouton **« + Ajouter à la watchlist »** apparaît
  sur un verdict ✓ (2/2), branché sur la VRAIE watchlist
  (`server/watchlist.js`, déjà utilisée par le screening) — désactivé avec
  le libellé « ✓ Déjà dans la watchlist » si le ticker y est déjà.
  **Bug réel trouvé en construisant ce bouton** : `fetchJSON(url)` dans
  `index.html` n'acceptait qu'un seul argument et ignorait silencieusement
  toute option passée en second paramètre — `fetch(url, options)` devenait
  `fetch(url)`. Deux call sites l'utilisaient déjà ainsi sans jamais
  fonctionner : `addWatchlist()` (le bouton "Ajouter" de l'éditeur de
  watchlist ne postait donc jamais rien, il refaisait juste un GET) et
  `closeTrade()` (cliquer "Clôturer" sur un trade ne le clôturait jamais
  réellement, le PUT n'était jamais envoyé). Corrigé une fois pour toutes
  (`fetchJSON(url, options)`), ce qui répare ces deux bugs préexistants au
  passage. **Vérifié en direct** (backend redémarré) : `addCurrentTickerToWatchlist()`
  poste réellement sur `/api/watchlist` (confirmé par lecture de la base
  après coup, puis nettoyé), légende du graphique sectoriel cliquable
  (`toggleSectorSeries('XLK')` retire effectivement la courbe et
  l'étiquette du SVG), capsules R-multiples/Fibonacci lisibles au clic,
  menu Réglages s'ouvre/se ferme. **Non vérifié visuellement par capture
  d'écran** cette session (la tuile du navigateur est restée vide sur
  toutes les captures malgré un DOM/JS confirmé correct par inspection
  directe) — vérification fonctionnelle uniquement pour cette partie.

### Terminologie et calcul du filtre de tendance : SMMA → SMA (29/8/2026)

JP a relevé que les capsules d'aide parlaient tantôt de « SMMA » (filtre de
tendance 9/21/100) tantôt de « MM » (Golden Cross 50/200) pour ce qui
ressemblait au même type de moyenne — une incohérence de vocabulaire. Sa
demande allait au-delà du texte : « je veux que l'on utilise les simple
moving average » et « assure-toi que les données reçues sont bien les
Simple Moving Average (SMA) » — un changement d'algorithme, pas seulement
de libellé.

**Constat** : le filtre de tendance (9/21/100) était bien une SMMA (Smoothed
Moving Average / RMA de Wilder), pas une SMA — vérifié dans le code
(`computeSMMA()`, lissage exponentiel `(prev × (n-1) + close) / n`), pas une
moyenne de fenêtre glissante. Le Golden Cross (50/200), lui, utilisait déjà
une vraie SMA (fournie telle quelle par `tradingview-mcp`/`coin_analysis`,
champ `sma.sma50`/`sma.sma200`) — seul son libellé « MM » (moyenne mobile,
générique) était sous-spécifié, pas le calcul.

**Changements** :
- `server/indicators.js` : nouvelle `computeSMA(closes, period)` (fenêtre
  glissante, somme courante ajustée par soustraction/addition — testée sur
  `[1..10]` avec période 3, résultats exacts). L'ancienne fonction RMA est
  conservée mais renommée `computeRMA()` (non exportée) et réservée à
  `computeATR()` — l'ATR de Wilder reste correctement en RMA par
  définition, ce n'est pas concerné par cette révision.
- Champs renommés partout (API, config, HTML, JS) : `smma9`/`smma21`/
  `smma100`/`smmaAlignment` → `sma9`/`sma21`/`sma100`/`smaAlignment` ;
  `CFG.indicateurs.smmaRapide/smmaMoyenne/smmaLente` →
  `smaRapide`/`smaMoyenne`/`smaLente` ; ids HTML `mm50`/`mm200` →
  `sma50`/`sma200`, `lbl-smma` → `lbl-sma`, `smma-live-hint` →
  `sma-live-hint`. `js/glossaire-indicateurs.js` : clé `smma` → `sma`,
  texte corrigé (« Trois moyennes mobiles SIMPLES », plus de mention RMA) ;
  capsule `goldenCross` : « MM50/MM200 » → « SMA50/SMA200 ».
  `design_assistant_swing_trading.md` (section 4.1/4.2/4.4) mis à jour en
  conséquence, y compris le Pine Script (`ta.rma()` → `ta.sma()`) — **JP
  doit reproduire ce changement à la main dans l'alerte réellement
  configurée sur TradingView**, cet outil ne peut pas la modifier à
  distance.
- **Vérifié en direct** (AMD) : `computeSMA([1..10], 3)` → `[null, null, 2,
  3, 4, 5, 6, 7, 8, 9]`, exact. `getHomemadeIndicators('AMD')` retourne
  `sma9/sma21/sma100` cohérents (valeurs différentes de l'ancien calcul RMA,
  comme attendu — une SMA et une RMA sur les mêmes données ne convergent
  pas vers le même nombre), `atr` inchangé (toujours RMA, comme voulu).

### Statut technique explicite (30/8/2026)

JP a vu une pastille rouge « tradingview-mcp » sans explication et a
demandé que l'app soit explicite sur la nature d'un problème technique
plutôt que d'afficher un point rouge muet. `checkSidecarConnection()`
(`server/tradingview.js`) et `checkYahooConnection()`
(`server/indicators.js`) retournaient un simple booléen, avalant l'erreur
réelle — retournent maintenant `{ ok, detail }`. **Piège trouvé en
implémentant** : l'erreur `fetch` masque la vraie cause système derrière
un message générique `"fetch failed"` — le code réel (`ECONNREFUSED`,
etc.) vit dans `err.cause.code`, pas `err.message` ; vérifié en réel
(sidecar arrêté puis relancé) avant de coder le message utilisateur.
`GET /api/status` expose `tradingviewMcpDetail`/`homemadeDetail`/`dbDetail`.
Frontend (`index.html`) : nouveau bandeau `#status-issues` (rouge, sous la
barre de statut), affiché uniquement si au moins un check échoue, listant
la cause exacte de chacun (ex. « tradingview-mcp : Sidecar non démarré ou
injoignable sur http://127.0.0.1:4701/mcp (npm run sidecar) »). **Vérifié
en direct** : sidecar arrêté → bandeau affiché avec le bon message ;
sidecar relancé + clic Actualiser → bandeau disparaît, 3 pastilles vertes.
`SETUP.md` mis à jour (section dépannage) pour refléter ce nouveau
comportement et corriger une inexactitude qui y trainait : ce témoin teste
la joignabilité du sidecar (poignée de main MCP), **pas** le rate-limit de
`coin_analysis` — les deux sont des problèmes différents, l'ancien texte
laissait croire au même.

### PEG moyen — carte Performance des secteurs (30/8/2026)

Demande de JP. **Vérifié avant d'implémenter** : contrairement au P/E
(exposé nativement au niveau de chaque ETF sectoriel, voir section
précédente), Yahoo Finance n'expose **aucun** PEG au niveau ETF — testé en
direct sur XLK/XLF/SPY via `quote()` et `quoteSummary` (module
`defaultKeyStatistics`) : `pegRatio` revient `undefined` dans les deux cas.
Un PEG n'a d'ailleurs pas de définition standard au niveau d'un secteur
entier (c'est un ratio par entreprise, croissance des bénéfices incluse).

**Calculé à la place** comme la moyenne des PEG des titres de LA WATCHLIST
partageant le même secteur GICS large — même principe d'approximation par
pairs que le « P/E industrie » du screening, mais au niveau du secteur
large (`summaryProfile.sector`, ex. « Technology », « Consumer Cyclical »)
plutôt que de l'industrie fine (`summaryProfile.industry`, ex.
« Semiconductors »). Nouveau champ `sector` ajouté à
`server/fundamentals.js` (même appel `quoteSummary` existant, aucune
requête réseau supplémentaire). Mapping ETF→secteur Yahoo
(`SECTOR_ETF_TO_YAHOO_SECTOR`, `server/sectors.js`) vérifié en direct sur
un titre connu par secteur (XOM→Energy, NEE→Utilities, PLD→Real Estate,
LIN→Basic Materials, UNH→Healthcare, HON→Industrials, PG→Consumer
Defensive) — les noms Yahoo diffèrent parfois du nom SPDR de l'ETF (ex.
« Consumer Cyclical » chez Yahoo = « Consumer Discretionary » côté
XLY/SPDR, même catégorie).

**Couverture nécessairement partielle, assumée et affichée comme telle** :
la watchlist (20 titres tech/IA) n'a aucun titre dans 7 des 11 secteurs
(Énergie, Services publics, Santé, Immobilier, Conso. de base, Industriel,
Matériaux) — ces lignes affichent « — », jamais un chiffre inventé.
`pegPeerCount` exposé et affiché en tooltip (même discipline que
« P/E industrie »). `/api/sectors` fait maintenant `Promise.all` entre
`getSectorPerformance()` (ETF, rapide) et `getFundamentalsBatch()` sur la
watchlist (`withVwap:false`, 20 titres) — **vérifié en direct** :
Technologie 11 pairs (PEG moyen 1.30), Conso. discr. 3 pairs (2.41),
Finance 1 pair (1.13), Services de comm. 4 pairs (1.14), les 7 autres à
0 pair (`null`/« — »), cohérent avec la composition réelle de la
watchlist.

### Disclaimer bilingue (30/8/2026)

Demande de JP : reprendre le disclaimer FR/EN de marbella
(`calc-retirement/calculatrice_retraite_swr_v2.html`) — texte identique
mot pour mot, même structure visuelle (deux blocs côte à côte, fond
amber), adapté aux variables déjà vendorées de castellana
(`--ds-radius-sm`, `--amber`/`--amber-bg` — pas de variables redérivées
comme chez marbella, castellana vendore déjà `tokens.css` correctement).
Placé juste sous le header, avant le témoin de statut. **Vérifié en
direct dans le navigateur** : rendu correct en thème sombre, responsive
(passe en une colonne sous 620px comme chez marbella).

## Trois pistes d'amélioration — roadmap + implémentation (31/8/2026)

JP a demandé de formaliser dans le roadmap bilbao les 3 pistes proposées en
fin de session précédente, avec un plan d'implémentation. Passé par
`EnterPlanMode`/`ExitPlanMode` (approuvé par JP) avant de coder — voir
`~/.claude/plans/glowing-zooming-hejlsberg.md` pour le plan complet.

**Roadmap (bilbao)** : 3 features ajoutées via `POST
http://127.0.0.1:4600/api/feedbacks` (`produit_vise: castellana`,
`type_feedback: Amelioration`, `statut: Planifie`) — ids **345, 346, 347**.
Jamais édité `feature-factory/data/castellana/features.json` à la main
(convention portfolio).

### Watchlist — XEQT.TO comme repère diversifié

JP a demandé d'ajouter XEQT (iShares Core Equity ETF Portfolio) à la
watchlist. **Investigation avant d'implémenter** (pas d'ajout à l'aveugle) :
- Le ticker plain `XEQT` ne résout pas chez Yahoo Finance — il faut
  `XEQT.TO` (Bourse de Toronto). Vérifié en direct.
- `XEQT.TO` n'a **ni `sector` ni `industry`** chez Yahoo (`summaryProfile`
  renvoie `undefined` pour les deux) — normal pour un FNB diversifié
  détenant des milliers de titres. **Ne comblera donc PAS** les trous du
  P/E industrie / PEG moyen. Signalé à JP avant d'implémenter (via
  `AskUserQuestion`), qui a confirmé : l'intention réelle est d'avoir un
  **point de comparaison contre un FNB ultra-diversifié**, pas de combler
  les secteurs — objectif de la feature #345 recadré en conséquence.
- **Limite technique confirmée en direct** : `tradingview-mcp`
  (`coin_analysis`) ne résout pas `XEQT.TO`, quel que soit l'exchange passé
  (`TSX` testé) — erreur *"No data found for XEQT.TO on KUCOIN"* (la
  librairie tierce part sur une bourse crypto par défaut pour ce symbole
  non reconnu). **RSI et Golden Cross resteront donc indisponibles pour
  XEQT.TO** — mais tout le reste fonctionne : prix/force relative
  (`yahoo_price`), P/E réel (21.65), et les calculs maison
  (SMA9/21/100/OBV/ATR/volume, tous via Yahoo direct). État dégradé déjà
  géré nativement (`Promise.allSettled`, colonnes à `—`), aucun code
  spécial nécessaire.

**Implémenté** : `SEED_WATCHLIST` (`server/watchlist.js`) +
`XEQT.TO`/`TSX`/`source: jp`, avec le contexte ci-dessus en commentaire.
Ajouté aussi à la base **actuelle** de JP via `POST /api/watchlist` (éditer
le seed seul n'a aucun effet sur une base déjà semée). Option `TSX` ajoutée
au menu déroulant de l'éditeur de watchlist (`index.html`, `#wl-exchange` —
n'affecte aucun calcul, Yahoo ignore ce champ et tradingview-mcp ne le
résout pas correctement de toute façon pour ce symbole). **Vérifié en
direct** : `GET /api/screening?force=true` (21 titres, XEQT.TO inclus) ne
plante pas — XEQT.TO ressort avec `rsi: null`, `goldenCross: null`,
`error` explicite, mais `price: 45.92`, `peRatio: 21.65`,
`forceRelative: 0.06`, `obvTrend: "accumulation"` tous corrects,
`industry`/`industryPE` à `null` (exclus proprement de l'agrégation),
`verdict: "surveiller"` calculé sur les données partielles disponibles —
comportement identique à tout autre titre en dégradé, pas un cas spécial.
**Trous sectoriels du P/E industrie/PEG moyen** (Énergie, Santé,
Immobilier, Industriel, Matériaux…) : **pas traités** dans cette session —
JP n'a demandé que XEQT explicitement, choisir des titres individuels
reste sa décision, à rouvrir séparément s'il le souhaite.

### Journal de trades — modifier un trade existant + export CSV

**Constat avant d'implémenter** : le CRUD backend (`server/trades.js`,
`PUT /api/trades/:id`) acceptait déjà une mise à jour partielle de
n'importe quel champ — aucun gap backend. Le vrai manque était uniquement
frontend : aucun bouton « Modifier » dans le journal (seulement
Clôturer/Suppr.), et pas d'export CSV du journal (existait déjà pour le
screening, `/api/screening.csv`).

**Implémenté** :
- `server/trades.js` — `COLUMNS` exporté (était un const local) pour être
  réutilisé par l'export CSV.
- `server/index.js` — nouvelle route `GET /api/trades.csv`, même patron
  que `GET /api/screening.csv` (échappement identique), mais **sans
  cache** — lit la base directement à chaque appel (contrairement au
  screening, pas de rate-limit externe à ménager ici).
- `index.html` — bouton « Modifier » ajouté à chaque ligne du journal
  (`editTrade(id)` : pré-remplit le formulaire « Nouveau trade » avec les
  valeurs existantes, bascule le libellé du bouton en « Mettre à jour le
  trade #id », affiche un bouton « Annuler la modification »).
  `addTrade()` renommé `saveTrade()` : POST si `editingTradeId` est `null`,
  sinon PUT vers `/api/trades/:id` — **aucun changement backend requis**,
  le PUT partiel existait déjà. Champs de clôture (date/prix de
  sortie, résultat) volontairement **non éditables** via ce formulaire —
  restent le rôle du bouton « Clôturer » existant, pour ne pas dupliquer
  deux chemins vers le même état. Bouton « Exporter CSV » ajouté dans la
  carte « Trades », même emplacement relatif que pour le screening.
- **Vérifié en direct** (trade de test créé puis supprimé après coup) :
  `editTrade(8)` pré-remplit correctement le formulaire et bascule le
  bouton ; modifier la taille de position (10→25) et `saveTrade()` PUT
  bien vers `/api/trades/8` (vérifié par re-fetch, `taille_position: 25`) ;
  état réinitialisé après sauvegarde (`editingTradeId` revient à `null`,
  libellé du bouton revient à « Enregistrer le trade ») ; export CSV
  contient bien le trade avec sa valeur modifiée.

### Tests automatisés — server/indicators.js

**Décision** : `node:test` natif (Node 22, zéro dépendance ajoutée) plutôt
que Jest/Vitest — cohérent avec la discipline zéro-dépendance du reste du
portfolio pour ce type de besoin (voir coimbra). Script `"test": "node
--test server/*.test.js"` dans `package.json` — **piège trouvé en le
configurant** : `node --test server/` (sans le glob) essaie de charger
TOUS les fichiers `.js` du dossier comme suites de test, y compris
`server/index.js` lui-même, qui démarre alors un vrai serveur Express et
plante avec `EADDRINUSE` si le vrai serveur tourne déjà (ce qui était le
cas) — corrigé en ciblant explicitement `server/*.test.js`.

**`server/indicators.test.js`** (7 tests, uniquement sur les fonctions
**pures**, aucun appel réseau ni mock) : `computeSMA` (fenêtre glissante
sur `[1..10]`/période 3, cas déjà vérifié à la main en session précédente,
plus le cas historique trop court) ; `computeOBV` (hausse/baisse/plat
connus) ; `computeVolumeVs20d` (le jour courant exclu de sa propre
moyenne, plus le cas <21 barres → `null` explicite) ; `computeTrueRange`
et `computeATR` (série OHLC choisie à la main, valeurs de lissage Wilder
calculées et vérifiées manuellement : TR=`[2,3,2,3]` →
ATR(période=2)=`[null,2.5,2.25,2.625]`). Les fonctions réseau
(`getHomemadeIndicators`, `fetchDailyHistory`, `checkYahooConnection`…)
restent hors périmètre — testées manuellement en direct, comme le reste du
projet (pas d'infrastructure de mock ici). **`npm test` → 7/7 verts.**

## Secteurs USD/CAD, onglet Screener, top 30 par secteur (2/9/2026)

Trois demandes de JP, cadrées via `EnterPlanMode`/`ExitPlanMode` (plan
approuvé : `~/.claude/plans/voici-plusieurs-am-liorations-graceful-dewdrop.md`)
puis ajustées en cours d'implémentation quand deux hypothèses du plan se
sont révélées fausses en test réel (voir « Écarts au plan approuvé »
ci-dessous).

### Architecture finale — 4 onglets

`index.html` passe de 3 à 4 onglets, dans cet ordre :

1. **« Secteurs »** (`#tab-secteurs`, renommé depuis « Écran de sélection ») :
   bannière → carte **Performance des secteurs** (sélecteur USD/CAD, voir
   T1) → carte **« Titres les plus performants du secteur »** (voir T2b,
   remplace l'ancienne carte de screening 21-titres qui vivait ici) →
   cartes Ticker/Force relative/Golden Cross (préfixe `sec-`).
2. **« Screener »** (`#tab-screener`, nouvel onglet) : carte
   « Screening — univers de titres (21) » (identique à l'ancienne, même
   route `/api/screening`, mêmes filtres/éditeur de watchlist/export CSV —
   **relocalisée** ici, pas dupliquée) + cartes Ticker/Force relative/
   Golden Cross (préfixe `scr-`, dupliquées de l'onglet Secteurs à la
   demande explicite de JP — « garder une copie dans les deux onglets »,
   pas déplacées).
3. **« Fiche de trade »** — inchangé.
4. **« Journal & stats »** — inchangé.

**Refactor JS partagé** (`SELECTION_INSTANCES` dans `index.html`) : les
deux jeux de cartes Ticker/FR/GC sont rendus par les MÊMES fonctions
(`calcSelectionFor(instanceKey)`, `fetchLiveSelectionFor(instanceKey)`,
`instanceKey` ∈ `{sec, scr}`) plutôt que par du code copié-collé — évite
que les deux instances divergent silencieusement à la prochaine
modification. Les deux champs Ticker sont **volontairement indépendants**
(saisir un titre dans un onglet n'écrase pas l'autre) ; seul un pointeur
`lastTickerInstance`, mis à jour à chaque interaction (saisie, clic
« Récupérer en direct », clic sur une ligne de tableau), détermine lequel
des deux alimente `#ticker` au passage vers l'onglet Fiche de trade
(`switchTab('fiche')`). L'éditeur de watchlist (ajout/suppression de
titres) ne vit plus que dans l'onglet Screener — c'est lui le propriétaire
réel de la watchlist fixe de 21 titres désormais.

### T1 — Sélecteur USD/CAD sur la carte Performance des secteurs

`server/sectors.js` : `SECTOR_ETFS`/`BENCHMARK` (tableaux plats) remplacés
par `SECTOR_DEFS`/`BENCHMARK_DEFS` (objets `{key, label, usd, cad}`, `key`
= toujours le ticker USD, stable). `getSectorPerformance()`/
`getSectorHistory()` prennent un paramètre `mode` (`'usd'`|`'cad'`) et
choisissent `def[mode]` — une seule implémentation pour les deux devises,
pas de code triplé. `/api/sectors` et `/api/sectors/history`
(`server/index.js`) lisent `?mode=` (400 si invalide). La jointure PEG par
secteur utilise désormais `s.key` (pas `s.ticker`, qui peut être un ticker
`.TO` en mode CAD) pour rester correcte peu importe le mode affiché.
Frontend : toolbar 2 boutons USD/CAD (`setSectorCurrency()`), relance les
deux fetches secteurs au clic. `SECTOR_COLORS`/`sectorChartHidden`/
`toggleSectorSeries()` (line graph, légende) réindexés sur `s.key` plutôt
que `s.ticker` pour que les secteurs masqués/isolés dans la légende
survivent à un changement de devise.

**Tickers CAD (BMO)** — fournis par JP puis **vérifiés en direct sur
Yahoo Finance** avant intégration (`yahooFinance.quote()` sur chacun) :

| Secteur | USD | CAD |
|---|---|---|
| Technologie | XLK | ZXLK.TO |
| Conso. discr. | XLY | ZXLY.TO |
| Industriel | XLI | ZXLI.TO |
| Finance | XLF | ZXLF.TO |
| Services publics | XLU | ZXLU.TO |
| Santé | XLV | ZXLV.TO |
| Immobilier | XLRE | **ZRE.TO** (pas ZXRE.TO — voir écart ci-dessous) |
| Conso. de base | XLP | ZXLP.TO |
| Énergie | XLE | ZXLE.TO |
| Services de comm. | XLC | ZXLC.TO |
| Matériaux | XLB | ZXLB.TO |
| Benchmark (S&P 500) | SPY | ZSP.TO |

### T2b — « Titres les plus performants du secteur » (onglet Secteurs)

Clic sur une ligne de `#sectors-tbody` (pas sur la ligne benchmark) →
`selectSectorForTop(sectorKey, label)` → peuple la carte juste en dessous
avec les titres les plus performants du secteur, triés par variation du
jour, avec un choix **top brut / top filtré** (cap. boursière > 2 G$ et
volume > 1M — seuils dans `config.js` `CFG.sectorTop`, dupliqués côté
serveur en `SECTOR_TOP_FILTERS`, `server/sectors.js`).

**Ce n'est PAS une requête de marché en direct** — voir « Écarts au plan
approuvé » ci-dessous pour pourquoi. `SECTOR_TOP_CANDIDATES`
(`server/sectors.js`) est une liste **curatée à la main par secteur**
(16 à 20 titres liquides et connus par secteur, 207 au total), **chaque
ticker vérifié en direct le 2/9/2026** contre la vraie classification
`summaryProfile.sector` de Yahoo Finance (pas seulement supposé) — 4
candidats initiaux ont été écartés à cette étape faute de correspondre :
ADP et PARA sont classés « Technology » chez Yahoo (pas dans leur secteur
« attendu ») ; AVY/PKG/IP/BALL (emballage) sont classés
« Consumer Cyclical » plutôt que « Basic Materials » ; HES/CTRA/IPG ne
résolvent plus du tout (probablement des fusions/acquisitions closes
depuis la connaissance du modèle). `getTopMoversForSector(sectorKey, {mode})`
fait un appel `quoteSummary` par titre de la liste (prix, variation,
cap. boursière, P/E, bourse — **aucun** appel vers `coin_analysis`/
indicateurs maison, pour ne jamais re-déclencher le rate-limit déjà
documenté sur 30 titres à la fois), trie par variation, filtre si demandé,
plafonne à 30. Nouvelle route `GET /api/sectors/:sectorKey/top?mode=raw|filtered`,
cache mémoire par `(secteur, mode)` (`settings.sectorTopCacheMinutes`,
défaut 20 min, `?force=true` bypass), `503` explicite (jamais un `200`
avec `rows:[]`) si Yahoo est injoignable.

**Le compte de titres varie par secteur (16 à 20), et c'est honnête, pas
un bug** : `totalCandidates` est toujours affiché à côté du nombre de
lignes réellement montrées (ex. « 5 sur 16 titre(s) suivis » en mode
filtré sur Matériaux) — jamais un « top 30 » qui laisserait croire à un
univers plus large qu'il ne l'est. Constaté en test réel sur Matériaux
(mode filtré) : plusieurs très grandes capitalisations (LIN, 225 G$)
échouent quand même le filtre de **volume** (moins d'1M d'actions/jour,
prix par action élevé) — comportement attendu du seuil, pas une erreur.

### Écarts au plan approuvé — deux hypothèses fausses trouvées en testant

**1. Le screener personnalisé de Yahoo Finance ne fonctionne pas pour un
usage anonyme.** Le plan prévoyait d'interroger l'endpoint
`v1/finance/screener` (hors `/predefined/saved`) avec une requête filtrée
par secteur, en réutilisant le crumb/cookie déjà géré par `yahoo-finance2`.
**Spike réalisé, résultat négatif, de façon révélatrice** : le screener
**prédéfini** (`day_gainers` etc., déjà supporté par la librairie) répond
normalement avec ce crumb/cookie ; le screener **personnalisé** répond
**429 Too Many Requests** de façon systématique — en GET et en POST, sur
`query1` et `query2`, à plusieurs minutes d'écart, sans aucune rafale de
requêtes. Ce n'est pas un vrai rate-limit (un seul appel isolé suffit à le
déclencher, alors que l'endpoint voisin avec les mêmes identifiants répond
instantanément) — tout indique un endpoint réservé aux comptes connectés
de Yahoo Finance (fonction « créer mon propre screener »), pas une limite
de trafic. **Conformément au principe déjà documenté plus haut dans ce
fichier** (« un vrai anti-bot ne se contourne pas », leçon valencia/
idealista), la barrière n'a pas été forcée — JP a choisi l'alternative
« liste maintenue par secteur » (voir T2b ci-dessus) plutôt que de
persister sur des en-têtes/empreintes de navigateur plus élaborés.

**2. Aucune version CAD "couverte contre le risque de change" n'existe
pour les 11 ETF sectoriels BMO.** Le plan prévoyait un sélecteur à 3 voies
(USD / CAD non couvert / CAD couvert, tickers `.F.TO`). **Vérifié en
direct** : les 10 tickers `.F.TO` testés échouent TOUS sur Yahoo Finance
(`Cannot read properties of undefined`), alors que leurs équivalents non
couverts résolvent tous. Seul le S&P 500 a une vraie version couverte
chez BMO, sous un ticker de racine différente (`ZUE.TO`, pas `ZSP.F.TO`)
— cohérent avec le fait que BMO ne semble tout simplement pas offrir de
version couverte pour ses ETF sectoriels étroits, seulement pour ses
produits larges. JP a choisi de retirer le mode CAD couvert plutôt que de
proposer un sélecteur à 3 voies dont 10 des 11 secteurs pointeraient vers
des tickers inexistants — le dropdown reste à 2 voies (USD/CAD).

### Vérifié en direct (2/9/2026)

Backend : `curl` sur `/api/sectors?mode=usd|cad` (11/11 secteurs résolus
dans les deux modes, aucune erreur), `/api/sectors?mode=bogus` → 400,
`/api/sectors/XLK/top?mode=raw` (20/20 candidats résolus, triés), `/api/sectors/XLB/top?mode=filtered`
(5/16, tous ≥ 2 G$ cap.), cache confirmé (`cached:true` au second appel),
`/api/sectors/SPY/top` → 400 (SPY n'est pas un secteur). Navigateur (via
le Browser pane, JS exécuté directement) : bascule USD→CAD (tableau ET
graphique se remettent à jour, `ZRE.TO`/`ZSP.TO` corrects) ; clic sur
« Énergie » → carte du bas peuplée (18/18 titres, HAL en tête) ; clic sur
une ligne (HAL) → charge dans la carte Ticker de l'onglet Secteurs avec
flash de mise en évidence ; `sec-ticker`/`scr-ticker` confirmés
indépendants (`HAL` vs `AMD` par défaut) ; bascule vers Fiche de trade →
`#ticker` suit bien `HAL` (dernière instance touchée) ; bascule top
brut/filtré sur Matériaux → 16/16 puis 5/16, cohérent. Screening 21-titres
de l'onglet Screener relancé après le refactor — toujours fonctionnel
(voir aussi la note sur le témoin de statut, section dédiée plus haut).
Aucune erreur console JS à aucune étape. Serveur de test arrêté après
vérification — rien ne tourne en arrière-plan (le sidecar tradingview-mcp,
déjà actif avant cette session, n'a pas été touché).
- 2026-09-05 : nouvel onglet **Labo** (stratégies d'options), demande de JP.
  **Écart trouvé et clarifié avant d'implémenter** : le fichier fourni
  (`strategy/PoorManCoveredCall.md.rtf`) décrit en réalité « La Roue &
  Debit Spreads », pas la vraie PMCC — signalé via `AskUserQuestion`, JP a
  choisi de garder les deux, distinctes, dans le sélecteur. Livré :
  `js/strategies-labo.js` (catalogue de stratégies + génération de
  séquence pas-à-pas), `GET /api/labo/:ticker` (`server/index.js` — prix/
  ATR/beta/volume réels via `fundamentals.js`+`indicators.js`, Yahoo direct,
  aucune dépendance à `tradingview-mcp`), section `CFG.labo` (`config.js`).
  4 stratégies au sélecteur (2 `disponible` : La Roue & Debit Spreads, PMCC ;
  2 `a-venir` : Iron Condor, Credit Spreads). Voir section dédiée plus haut
  pour le détail complet et la vérification en direct (AMD, données
  réelles, 3 stratégies testées dans le navigateur, aucune erreur console).
  Serveur redémarré pour charger le code puis arrêté après vérification —
  rien ne tourne en arrière-plan.
- 2026-09-05 (même jour) : terminologie du Labo clarifiée suite à 4
  questions de JP après son premier essai (LEAPS pas défini, formulation
  incohérente entre les deux stratégies, alignement SMA « neutre » non
  vérifiable, Delta cible non expliqué). Nouvelles entrées `leaps`/`delta`
  dans `js/glossaire-indicateurs.js` (même popover que les indicateurs
  techniques), boutons d'aide posés sur chaque mention dans
  `js/strategies-labo.js`, titre de l'étape LEAPS reformulé en verbe-sujet
  actif pour matcher le style de l'autre stratégie, carte de métriques Labo
  (`index.html`) enrichie des valeurs SMA9/21/100 réelles pour que
  l'alignement soit vérifiable à l'œil plutôt qu'un mot opaque. Voir section
  dédiée plus haut. Fichiers statiques uniquement, pas de redémarrage
  serveur nécessaire — vérifié en direct par lecture du DOM (popovers,
  valeurs SMA AMD).
- 2026-09-05 (3e passe, même jour) : trois demandes plus profondes de JP
  (T1 distinction visuelle statique/dynamique, T2 "pourquoi ce prix ?",
  T3 SMA réellement configurables). **Écart de méthode réel trouvé et
  corrigé** : les zones de strike étaient calculées par un multiple d'ATR
  sans AUCUN lien avec le Delta cible affiché à côté — remplacé par un
  vrai calcul Black-Scholes (`js/strategies-labo.js` : normCdf/normInv/
  strikeForDelta, JS pur) à partir de la volatilité HISTORIQUE réelle du
  titre (`computeHistoricalVolatility()`, `server/indicators.js`,
  documentée comme proxy de la volatilité implicite, jamais équivalente).
  Panneau "Comment ces prix sont calculés" ajouté (détail complet, d1 +
  strike par jambe). **Écart de configuration réel trouvé et corrigé** :
  `CFG.indicateurs.smaRapide/Moyenne/Lente` ne pilotait que des libellés,
  jamais le calcul réel (toujours 9/21/100 en dur côté serveur) — corrigé
  pour l'onglet Labo (`getHomemadeIndicators(symbol, {periods})`,
  `GET /api/labo/:ticker?smaFast=&smaMedium=&smaSlow=`), avec 3 champs
  désormais visibles tout en haut de l'onglet. `.labo-dyn` (CSS) distingue
  maintenant chaque valeur calculée du texte de règle statique. Voir
  section dédiée plus haut pour le détail complet et la vérification en
  direct (AMD, volatilité 72.1%, zones Black-Scholes vs ancien calcul ATR
  confirmées différentes, SMA recalculées sur 5/10/20). Serveur redémarré
  pour charger le code backend puis arrêté après vérification.
- 2026-09-06 (4e passe) : 6 demandes — ticker Labo par défaut → TQQQ (T1),
  carte "Données réelles du titre" corrigée (T2, vraie cause : `<span>`/
  `<strong>` bruts au lieu de `.ds-metric__label`/`__value`, aucun style ne
  s'appliquait), 3 champs SMA réalignés en grille dédiée (T3), Force
  relative + Golden Cross fusionnés dans "Ticker" et 9 champs fondamentaux
  ajoutés (OBV/Volume/Float/P-E/Industrie/P-E industrie/PEG/Beta/VWAP) —
  **onglet Secteurs uniquement**, pas Screener (T4/T5). Et
  **`launcher/`** : outil de relance de castellana (Node + sidecar) en
  React 18 UMD (sans build, sans JSX), backend zéro dépendance
  (`node:http`) sur son propre port (4750) — répond à une frustration
  répétée de JP (devoir demander à Claude Code de relancer le serveur après
  chaque panne/redémarrage du Mac). **Bug réel trouvé et corrigé en
  testant, pas en relisant le code** : `killPort()` sans `-sTCP:LISTEN`
  tuait aussi le serveur Node de castellana en relançant le sidecar seul
  (une connexion cliente sortante de castellana vers le sidecar matchait le
  filtre par port) — corrigé, reproduit puis re-vérifié après le correctif.
  Voir section dédiée plus haut pour le détail complet. Vérifié en direct,
  vrais kill/respawn (pas des mocks) : relance Node seul, sidecar seul,
  les deux ensemble, rejet 400 d'une cible invalide (`"rm -rf /"` testé
  explicitement). Le relanceur est **laissé actif** (port 4750, l'intérêt
  de l'outil est justement qu'il reste disponible) ; castellana
  (4700/4701) aussi.
- 2026-09-06 (5e passe) : 8 demandes après usage réel des passes
  précédentes. Bannière "1 signal sur 2" nomme désormais lequel des deux
  (Force relative/Golden Cross) est positif (T1) ; libellé "Devise" clarifié
  en "Devise des ETF sectoriels" après clarification avec JP — "Secteur"
  aurait rendu la phrase incohérente (T2) ; périodes de référence ajoutées
  partout (OBV 10j, Volume jour, P/E trailing, Beta 5 ans, VWAP séance en
  cours — T3) et indice de référence S&P 500 (SPY) enfin nommé dans l'UI,
  jamais mentionné auparavant (T4) ; plages Prix/Float des filtres du
  Screener rendues explicites ET configurables en direct côté client, sans
  rejouer de screening (T5/T6) ; **refactor T7** — nouveau
  `js/ticker-section.js` (`tickerSectionHTML`/`renderTickerSectionInto`)
  génère la section "Ticker" pour les 2 instances (Secteurs avec
  fondamentaux, Screener sans) depuis un seul template, remplaçant la
  duplication manuelle qui menaçait de diverger ; onglets "Valeur
  personnalisée"/"Technique" dans Réglages (T8), le second reprenant le
  contenu existant, le premier laissé en espace réservé (JP n'a pas précisé
  son contenu). Aucun changement backend — vérifié en direct sur les
  fichiers statiques (bannière forcée en scénario mixte, plages de filtre
  testées avec de fausses lignes, bascule des onglets Réglages), aucune
  erreur console. Voir section dédiée plus haut pour le détail complet.
- 2026-09-06 (6e passe, le lendemain) : bornes par défaut des filtres
  Screener resserrées (Prix 5$-1000$, Float 10M-20M actions — étaient
  1$-10000$/0-100000M), mises à jour aux deux endroits synchronisés
  (`CFG.screening` + `SCREEN_FILTERS`). Et revirement sur le scope de la
  section "Ticker" : JP veut le même standard (avec fondamentaux) dans
  Secteurs ET Screener — la décision de la veille qui le limitait à
  Secteurs est annulée. Grâce au refactor T7 (`js/ticker-section.js`), ce
  changement a tenu en une ligne (`withFundamentals:false` →
  `true` pour l'instance `scr`) plus la généralisation de
  `renderSecFundamentals()` en `renderFundamentalsFor(instanceKey, m)`
  (sinon les tuiles de Screener restaient vides au clic "Récupérer en
  direct"). Voir section dédiée plus haut. Vérifié en direct (serveur
  redémarré pour le changement backend) : nouvelles bornes reflétées dans
  `/api/screening` et préremplies dans l'UI, fondamentaux de Screener
  peuplés correctement sur AMD. Aucune erreur console.
- 2026-09-06 (7e passe) : télémétrie testeurs (voir section dédiée plus
  haut) — JP veut mettre castellana dans les mains de 2 testeurs. Avant de
  coder, clarifié avec lui (`AskUserQuestion`, `EnterPlanMode`/
  `ExitPlanMode`) que l'app entière ne peut PAS être déployée sur
  Cloudflare telle quelle (Express persistant + `better-sqlite3` natif +
  sidecar Python, tous incompatibles avec le modèle Workers) — un vrai
  portage existerait mais reste un chantier séparé, pas fait cette
  session. Décision retenue : app en local chez chaque testeur (comme JP),
  télémétrie centralisée via un nouveau Cloudflare Worker + D1
  (`telemetry-worker/`) — **premier composant de castellana jamais
  déployé publiquement**, `server/index.js` non touché. Livré :
  `js/telemetry.js` (3 événements — `app_loaded`/`ticker_selected`/
  `param_changed` — fire-and-forget, jamais bloquant), section
  `CFG.telemetry` dans `config.js`, sélecteur d'identité dans
  `.status-bar` (pas un login, T3 reporté), 4 points d'accroche pour le
  ticker (`fetchLiveSelectionFor`, `fetchLiveFiche`, `saveTrade`,
  `loadLaboTicker` — trouvés en explorant le code plutôt qu'un `oninput`
  générique trop bruyant), listeners `change` sur les 9 champs réellement
  modifiables à l'exécution (le reste de `config.js` ne pilote que des
  libellés, jamais éditable par l'utilisateur). **Vérification partielle
  cette session** : syntaxe validée (`node --check` sur `telemetry.js`,
  `config.js`, le script inline de `index.html`, et
  `telemetry-worker/src/index.js`), tous les 4 appels
  `trackTickerSelected` et les 10 ids de champs suivis confirmés présents
  par grep, `npm test` toujours 7/7 vert (aucun fichier serveur touché).
  **Pas de test en direct dans le navigateur** — le port 4700 était
  occupé par le serveur d'une autre session Claude Code en cours,
  injoignable depuis le Browser pane de celle-ci (isolation entre
  sessions).
- 2026-09-06 (8e passe, même session) : bouton « Partager une idée » (voir
  section dédiée plus haut) — repris tel quel du popup public d'iecho.ca
  (`FeedbackWidget.astro`), même formulaire Formspree partagé, seule
  différence demandée par JP : « Produit concerné » pré-sélectionné sur
  `castellana`. Livré : CSS dans `index.html`, markup bouton+`<dialog>`,
  `js/feedback-widget.js` (nouveau). **Vérifié visuellement** (serveur
  statique temporaire, 4700 étant occupé par une autre session) : rendu
  correct, `castellana` bien pré-sélectionné, aucune erreur console liée
  au widget. **Envoi réel testé par JP juste après, en conditions réelles
  (castellana lancée normalement) — confirmé fonctionnel**, la soumission
  est bien arrivée dans la boîte Formspree partagée avec iecho.ca.
- 2026-09-06 (9e passe, session suivante) : Worker de télémétrie déployé,
  à la demande de JP. `wrangler login` (OAuth navigateur, complété par
  JP), `wrangler d1 create castellana-telemetry-db` (id
  `3647b572-e88e-45c1-9401-df62e5e46e12`), schéma appliqué en `--remote`,
  `wrangler deploy` →
  https://castellana-telemetry.iechocreator.workers.dev.
  `CFG.telemetry.endpoint` mis à jour. **Testé en direct** : `curl POST
  /events` avec le bon jeton → 200 + ligne insérée (confirmée via
  `/dashboard?token=...` et `/events.csv?token=...`) ; avec un mauvais
  jeton → 401 (rejet confirmé) ; ligne de test retirée de la base après
  vérification pour ne pas polluer les vraies données des testeurs. La
  télémétrie est maintenant pleinement active pour les 3 événements
  (`app_loaded`/`ticker_selected`/`param_changed`).
- 2026-09-06 (10e passe, même session) : onglet « Concepts » dans Réglages
  (voir section dédiée plus haut) — guide de 15 concepts de trading
  transcrit d'un fichier `madrid` (`investment-dashboard/indicateur/
  GUIDE_15_CONCEPTS_TRADING.md`), texte + 15 images copiés dans
  `js/concepts-content.js`/`img/concepts/`, aucun lien dynamique entre les
  deux repos. Chaque concept garde sa structure propre (conseil/piège/
  listes ✅❌ selon le cas) plutôt que d'être forcé dans un schéma rigide.
  **Vérifié visuellement** (serveur statique temporaire, 4700 occupé par
  une autre session) : les 15 fiches se déplient, les 15 images se
  chargent, tableau récapitulatif correct en bas, aucune erreur console
  liée au contenu.

## Bouton "Partager une idée" (6/9/2026)

JP a demandé de reprendre le popup « Partager une idée » d'iecho.ca
(`iecho.ca/src/components/FeedbackWidget.astro`) dans castellana, avec une
seule différence : « Produit concerné » pré-sélectionné sur `castellana`
au lieu de vide (« Général / aucun en particulier »).

**Porté tel quel, pas réinventé** : bouton flottant bas-droite → `<dialog>`
natif (pas de librairie modale) → envoi `fetch(...,{method:'POST',
body:new FormData(form)})` vers **le même formulaire Formspree que
iecho.ca** (`mwvdgqgy`) — décision délibérée de réutiliser le même
formulaire plutôt que d'en créer un séparé pour castellana, puisque le
champ `produit` sert justement à distinguer la provenance dans la même
boîte de réception. Mêmes noms de champs (`message`, `produit`, `email`,
`page`, `langue`), même comportement de succès/échec (message vert/amber,
fermeture auto après 1.8s en cas de succès, dialogue qui reste ouvert en
cas d'échec pour permettre de réessayer).

**Différences volontaires par rapport au composant original** (adaptées au
contexte castellana, pas des oublis) :
- Pas d'Astro/i18n FR/EN/ES — castellana est mono-langue (français), les
  libellés sont écrits en dur dans `index.html`/`js/feedback-widget.js`.
- Le champ caché `page` capture l'**onglet actif** (`.tab-btn.is-active`)
  plutôt que `window.location.pathname` — castellana est une app à page
  unique (pas de routes), l'URL serait toujours la même peu importe
  l'onglet ; l'onglet est l'information réellement utile ici.
- La liste des produits du `<select>` (identique à celle d'iecho.ca) est
  **dupliquée à la main** dans `index.html` — castellana n'a pas accès au
  fichier `iecho.ca/src/data/produits.config.json` (repos séparés). À
  mettre à jour manuellement si cette liste change côté hub.
- Style adapté aux jetons de castellana (`--surface`/`--text`/`--accent`
  déjà vendorés) plutôt qu'aux variables propres au thème d'iecho.ca
  (`--fond`/`--texte`/`--accent-vif`, qui n'existent pas ici) ; les champs
  du formulaire réutilisent `.ds-input`/`.ds-select`/`.ds-textarea`/
  `.ds-btn`/`.ds-btn--primary` déjà vendorés, plutôt que de recopier le CSS
  `.bouton-primaire`/`.bouton-secondaire` propre à iecho.ca.

**Fichiers** : CSS ajouté dans le `<style>` de `index.html` (bloc
`.feedback-*`), markup (bouton + `<dialog>`) inséré juste après
`#settings-overlay`, `js/feedback-widget.js` (nouveau —
`openFeedback()`/`closeFeedback()`/`initFeedbackWidget()`), script tag +
appel `initFeedbackWidget()` ajoutés à la séquence d'init de fin de
fichier. Aucun changement serveur.

**Vérifié visuellement** (serveur statique temporaire sur un port libre,
4700 étant occupé par une autre session Claude Code — voir la limite déjà
documentée pour la télémétrie ci-dessus) : bouton visible en bas à droite,
clic ouvre le dialogue avec `castellana` bien pré-sélectionné dans
« Produit concerné », style cohérent avec le thème sombre de l'app, bouton
Fermer ferme proprement, aucune erreur console liée au widget (les 404
observés viennent de l'absence des routes `/api/*` sur ce serveur statique
temporaire, sans rapport). **Envoi réel du formulaire testé par JP en
conditions réelles depuis castellana lancée normalement (pas le serveur
statique temporaire ci-dessus) — confirmé fonctionnel**, la soumission est
bien arrivée dans la boîte Formspree partagée avec iecho.ca.

## Onglet "Concepts" dans Réglages (6/9/2026)

JP a demandé d'intégrer un guide qu'il avait déjà écrit —
`investment-dashboard/indicateur/GUIDE_15_CONCEPTS_TRADING.md` (un autre
produit du portfolio, `madrid`) — dans un nouvel onglet « Concepts » du
panneau Réglages de castellana.

**Contenu transcrit, pas lié dynamiquement** : les deux repos sont
indépendants (pas de fichier partagé), donc le texte des 15 concepts
(EMA, RSI, MACD, Stochastic RSI, Volume, OBV, VWAP, Bandes de Bollinger,
ATR, Fibonacci, Force relative, Breakout, Gaps, Golden Cross, Support &
Résistance) a été copié dans `js/concepts-content.js`, et les 15 images
qui les accompagnent copiées dans `img/concepts/` (renommées en minuscules
plutôt que les noms originaux `1 DTrading_EMA.JPG` etc.). **Si le guide
source change côté `madrid`, il faut reporter les changements ici à la
main** — même limite déjà documentée ailleurs dans ce fichier pour
d'autres contenus dupliqués entre repos (produits.config.json pour le
bouton Partager une idée, par exemple).

**Attribution des images (6/9/2026, signalé par JP)** : les 15 images
proviennent en réalité de la page Facebook de **dtrading.net**
(cohérent avec leur nom de fichier d'origine, `1 DTrading_EMA.JPG` etc.).
Un avertissement d'attribution (« Origine des images ») a été ajouté en
tout premier dans `renderConceptsTab()`, avant même le rappel pédagogique,
avec un lien vers https://dtrading.net/ — crédit explicite, usage
présenté comme purement éducatif.

**Pas de schéma rigide forcé** : le guide source a une structure qui varie
d'un concept à l'autre (la plupart ont un « conseil du pro », RSI et
Breakout ont un « piège à éviter » à la place ou en plus, Golden Cross a
deux listes ✅/❌, Gaps n'a pas de liste « à retenir » mais « les 4
types »). Plutôt que d'inventer un schéma de données qui aurait aplati ou
perdu ces nuances, chaque concept porte directement son corps en HTML
pré-écrit dans le tableau `CONCEPTS_TRADING` — fidèle au texte source, pas
une réinterprétation.

**Rendu** : `renderConceptsTab()` génère un `<details class="ds-card">`
repliable par concept (résumé + image + texte), plus une carte finale pour
le tableau récapitulatif « comment ces 15 outils travaillent ensemble ».
Appelé une seule fois au chargement (contenu statique, pas de
recalcul) — même patron que `initTelemetry()`/`initFeedbackWidget()`.
Nouvel onglet ajouté à la grille déjà existante de Réglages (« Valeur
personnalisée » / « Technique » / **Concepts**) via le mécanisme générique
`switchSettingsTab()` déjà en place (T8, 6/9/2026) — aucune modification
de ce mécanisme nécessaire.

**Vérifié visuellement** (serveur statique temporaire, 4700 occupé par une
autre session) : les 15 fiches se déplient correctement, les 15 images se
chargent, le tableau récapitulatif et l'avertissement final s'affichent en
bas de l'onglet, aucune erreur console liée au contenu (les 404 observés
viennent des routes `/api/*` absentes sur ce serveur statique, sans
rapport).

## Paquet téléchargeable self-install (6/9/2026)

JP veut donner accès à castellana à Louis et Guillaume sans passer par un
accès collaborateur GitHub privé — un lien de téléchargement direct sur
iecho.ca (voir aussi la Partie B de ce changement dans `iecho.ca/CLAUDE.md`).
Décisions confirmées par JP : (1) le sidecar Python est **inclus** dans
l'installation automatique, pas seulement Node ; (2) le lien est protégé
par un mot de passe simple (« tomate »), pas un accès restreint par compte
GitHub — voir la fiche iecho.ca pour le détail du mécanisme de mot de
passe.

**Castellana n'est pas une page statique** — Express + `better-sqlite3`
(module natif) + sidecar Python optionnel. Un « lien téléchargeable » veut
donc dire un zip du code source + des scripts de lancement par OS qui
font l'installation eux-mêmes au premier double-clic — pas un simple
fichier statique comme les démos autonomes de porto.

**Livré** :
- [`demarrer.command`](demarrer.command) (macOS) et
  [`demarrer.bat`](demarrer.bat) (Windows), calqués sur
  `devops-dashboard/demarrer.bat` (vérification Node, redirection vers
  nodejs.org) étendus avec la vérification/installation Python (sidecar
  optionnel — s'il est absent, castellana démarre quand même en mode
  dégradé, comportement déjà géré nativement par l'app). Réutilisent les
  mêmes conventions que `scripts/run-sidecar.mjs` déjà en place (nom du
  dossier `.venv-mcp`, `Scripts\` vs `bin/`, suffixe `.exe`) — à ne pas
  faire diverger si l'un des deux change.
- [`scripts/package-zip.sh`](scripts/package-zip.sh) (`npm run package`) —
  construit `castellana.zip` à la racine, excluant tout ce qui est dans
  `.gitignore` plus `.git/`. **Bug réel trouvé en testant** : le premier
  jet incluait aussi `.claude/settings.local.json` et
  `.claude/scheduled_tasks.lock` (état interne de session Claude Code,
  non suivi par git mais pas non plus dans `.gitignore` de ce repo) — ces
  fichiers n'ont rien à faire dans un paquet destiné à des testeurs,
  exclusions ajoutées explicitement dans `package-zip.sh`. `*.zip` ajouté
  à `.gitignore` (l'archive elle-même ne se committe jamais ici).
- `SETUP.md` — encart en haut renvoyant vers le double-clic comme
  alternative au clonage manuel, avec l'avertissement Gatekeeper (voir
  ci-dessous).

**Process de mise à jour du zip — volontairement manuel, pas de CI** :
`npm run package` dans `trading-assistant/`, copier `castellana.zip` vers
`iecho.ca/public/telechargements/castellana.zip`, committer+pousser
`iecho.ca` pour redéployer. Rien n'automatise cette étape — si le code de
castellana change, le zip existant sur iecho.ca devient périmé jusqu'à la
prochaine reconstruction manuelle.

**⚠️ Limite réelle non résolue — Gatekeeper macOS** : un script `.command`
téléchargé depuis un navigateur reçoit l'attribut `com.apple.quarantine`.
Sans signature Apple Developer (hors scope), macOS peut refuser de
l'exécuter au double-clic ou afficher « développeur non identifié ».
Mitigation documentée dans `SETUP.md` (clic droit → Ouvrir la première
fois), mais **jamais testée avec un vrai téléchargement navigateur** dans
cette session — impossible à reproduire ici (pas de vrai flux HTTP de
téléchargement + Gatekeeper). À vérifier par JP avant de considérer le
flux "sans friction" pour Louis/Guillaume.

**Vérifié en direct cette session** :
- `npm run package` → `castellana.zip` de 3.1 Mo, confirmé sans
  `node_modules`/`data`/`.venv-mcp`/`.git`/`.claude/settings.local.json`
  (via `unzip -l`).
- Permission d'exécution de `demarrer.command` confirmée survivre à un
  aller-retour zip/dézip sur cette machine (`-rwxr-xr-x` après `unzip`).
- **`demarrer.command` exécuté pour de vrai** dans une copie dézippée
  isolée (`/tmp`, sans `node_modules`/`.venv-mcp` préexistants) :
  détection Node ✅, détection Python 3 ✅, déclenchement correct de
  `npm install` (absent au départ). L'installation a échoué sur cette
  machine précise à cause du **bug de cache npm root-owned déjà documenté**
  dans le `CLAUDE.md` racine (`EACCES`, historique à cette machine, pas un
  bug du script) — le script a géré l'échec proprement (message clair
  pointant vers `SETUP.md`, pas de plantage silencieux, pas de port
  démarré donc aucun conflit avec l'instance castellana d'une autre
  session déjà active sur 4700/4701). **La suite du flux (installation du
  sidecar, démarrage réel des serveurs, ouverture du navigateur) n'a pas
  pu être testée de bout en bout** à cause de ce blocage local — à
  reprendre sur une machine sans ce problème de cache, ou après
  `sudo chown -R 501:20 "~/.npm"` sur celle-ci.
- `demarrer.bat` : **non testé sur une vraie machine Windows** — vérifié
  par lecture de code et cohérence avec `scripts/run-sidecar.mjs`
  uniquement, même limite déjà documentée pour ce dernier avant sa
  correction (voir plus haut dans ce fichier).
- 2026-09-07 : tableau de bord de télémétrie enrichi (voir section
  « Télémétrie testeurs » plus haut) — activité par jour, tickers les plus
  sélectionnés, filtre par testeur + plage de jours, sur la route
  `/dashboard` déjà déployée (Artifact Claude écarté : pare-feu réseau
  bloque le `fetch()` externe nécessaire). Skill `dataviz` consultée avant
  d'écrire le SVG. **Vraie télémétrie découverte dans la base pendant les
  tests** (JP avait utilisé castellana réellement) — nettoyage ciblé
  (`WHERE id >= 9`) pour préserver ces 7 événements réels plutôt qu'un
  nettoyage global destructeur. Vérifié en direct dans le navigateur :
  filtre par testeur (état vide correct sur « inconnu »), info-bulles au
  survol sur les deux graphiques, aucune erreur console. Redéployé,
  URL du Worker inchangée.

## Séparation La Roue / Debit Spreads (7/9/2026)

JP a demandé de séparer les 2 stratégies « La Roue & Debit Spreads »
(fusionnées en une seule entrée du sélecteur depuis le 5/9/2026, voir
section « Onglet Labo » plus haut) en deux entrées distinctes.

**Pur réarrangement, aucun nouveau calcul introduit** : `roue-debit-spreads`
(une entrée `STRATEGIES_LABO`) devient `roue` (Cash-Secured Put → Covered
Call, étapes 1-3 + règles de sortie de l'ancienne séquence) et
`debit-spreads` (Bull Call Spread / Bear Put Spread, ex-étape 4 de
l'ancienne séquence, + ses propres règles de sortie adaptées — un spread a
un risque déjà limité au montant payé, donc pas de « rouler » comme pour
un Put/Call vendu seul). Même texte, mêmes chiffres, juste réorganisés en
deux séquences pédagogiques complètes plutôt qu'une seule qui mélangeait
deux techniques différentes.

**Un choix explicite plutôt que deviné** : `debit-spreads` a besoin de sa
propre jambe vendue calculée par Black-Scholes pour son panneau « Comment
ces prix sont calculés » (avant, l'étape 4 de l'ancienne séquence
réutilisait simplement les zones déjà calculées pour le Put/Call vendu de
La Roue). Plutôt que d'inventer un Delta cible propre aux spreads (non
fourni par `strategy/PoorManCoveredCall.md.rtf`, qui ne détaille pas cette
partie), `debit-spreads` recalcule sa jambe vendue avec **exactement la
même formule et les mêmes bornes de Delta** (`cfg.put`/`cfg.call` de
`config.js`) que La Roue — documenté explicitement en commentaire dans le
code pour que ce choix ne soit pas pris pour un oubli. La jambe achetée
reste "proche du prix" en texte, comme dans le fichier source, sans zone
Black-Scholes calculée (aucun Delta cible fourni pour elle non plus).

**Fichier touché** : `js/strategies-labo.js` uniquement — le sélecteur de
`index.html` génère ses options dynamiquement depuis `STRATEGIES_LABO`
(`initLaboStrategies()`), donc aucune modification de `index.html`
n'était nécessaire pour que les 2 nouvelles entrées apparaissent.

**Vérifié en direct** (serveur castellana réel relancé, sidecar actif,
données réelles AMD) : le sélecteur liste bien 5 stratégies (`La Roue
(Wheel Strategy)`, `Debit Spreads (Bull Call / Bear Put)`, `Poor Man's
Covered Call (PMCC)`, 2× « bientôt disponible ») ; bascule entre `roue` et
`debit-spreads` → deux séquences indépendantes et complètes, mêmes zones
de strike (387,15$–421,16$ pour la jambe Put, 576,43$–627,07$ pour la
jambe Call) cohérentes entre les deux puisqu'elles réutilisent
délibérément la même formule ; `pmcc` non affecté par le changement.
Aucune erreur console à aucune étape. Serveur arrêté après vérification —
rien ne tourne en arrière-plan.

- 2026-09-11 (2e session) : bannière de verdict déplacée dans la section
  « Ticker » des 3 onglets, valeurs de démonstration supprimées, tableau
  sectoriel aligné sur les colonnes du screening — voir la section
  « Bannière de verdict et tableau sectoriel » plus haut. Point de départ :
  une **question** de JP sur le fonctionnement de la bannière ambre, pas une
  demande de changement — y répondre a révélé que les 4 champs partaient sur
  des valeurs de démonstration en dur, donc que l'app affichait un verdict
  crédible sur des chiffres fictifs dès le chargement. Trois fichiers
  serveur touchés (`screening.js` refactoré en `screenTickers()` +
  `buildSectorScreening()`, `getTopMoversForSector()` supprimé,
  `marketCap` ajouté aux fondamentaux sans appel réseau de plus), deux côté
  frontend (`index.html`, `js/ticker-section.js`). Vérifié en direct sur
  données réelles (AMD, SMCI, SHW, XLK, XLB), 65/65 tests, aucune erreur
  console ; watchlist modifiée puis **restaurée à l'identique** après le test
  du bouton d'ajout.
- 2026-09-12 : six retouches d'utilisabilité sur la version cloud déployée
  (voir la vérification factuelle en tête de ce fichier pour le détail
  complet) — overlay « Agrandir » généralisé aux tableaux sectoriel et
  Screener (T1), largeur des champs `.ds-input` corrigée dans `.row` (T2/T4),
  terminologie Golden Cross normalisée (T3), carte « Le titre » remontée en
  tête de la Fiche de trade (T4), univers **MAG7** ajouté au Screener (T5,
  `server/screening.js` + mirroré dans `cloud/src/lib/screening.js`),
  Setup/Contexte/Signal expliqués (T6, texte seulement). Répercuté dans
  `cloud/public/index.html` via patch du diff exact. 69/69 + 17/17 tests,
  aucune erreur console. **Déployé en production** après confirmation
  explicite de JP (un classificateur avait refusé le premier `wrangler
  deploy` sans confirmation) — vérifié sur la vraie URL après coup.
- 2026-09-12, 2e session : dix retouches (T1-T10), dont un vrai bug cloud
  (T6) — « univers élargi » répondait 0 retenu en production, cause exacte
  "Too many subrequests by single Worker invocation" confirmée par `curl`
  contre la vraie URL. Corrigé par des lectures/écritures D1 GROUPÉES
  (`readCacheMany`/`writeCacheMany`, `cloud/src/db/cache.js`) dans
  `indicators.js`/`quotes.js`/`fundamentals.js` — un `WHERE key IN (...)`
  a d'abord échoué sur D1 au-delà de ~270 clés ("too many SQL variables"),
  corrigé avec `json_each()`. Compteur `subrequestLimitCount` exposé et
  affiché en bandeau si la limite est quand même atteinte. Voir la
  vérification factuelle en tête de ce fichier pour les neuf autres
  retouches (encadré explicatif, colonnes inversées/retirée/triables,
  validation Fibonacci, bouton Récupérer déplacé, cases à cocher Labo,
  en-tête Performance renommé). `cloud/public/index.html` resynchronisé
  (patch + fusion manuelle sur `bootApp()`), 69/69 + 17/17 tests, aucune
  erreur console. **Déployé en production** après confirmation de JP —
  compte local `jp`/`louis` remis sur "tomate" au passage (`create-user.mjs`
  passé en upsert), même mot de passe qu'en production, pour éviter la
  confusion vécue par JP entre les deux environnements pendant ses tests.
  **Vérifié en vraie production après coup** : cache entièrement froid →
  `subrequestLimitCount: 171/218` au premier essai (le plafond réel de
  sous-requêtes de la plateforme, probablement le plan Workers Gratuit) ;
  4 relances (« Forcer ») ont suffi à réchauffer le cache jusqu'à
  disparition complète (`171 → 124 → 77 → 30 → 0`, 19 retenus au final,
  identique au résultat local). La refonte rend ce réchauffement possible
  en quelques clics au lieu d'être impraticable — mais un cache froid
  (juste après déploiement, ou après 15 min d'inactivité) redemandera
  encore quelques relances avant un résultat complet. Voir le détail
  complet en tête de ce fichier.
- 2026-09-12, 3e session : listes personnalisées du Screener (CRUD complet)
  — maquette visuelle montrée à JP avant construction, feu vert donné en
  conversation. Nouvelles tables `custom_lists`/`custom_list_tickers`
  (local sans `user_id`, cloud D1 avec, isolées par testeur), univers
  dynamique `list:<id>` ajouté via `isValidUniverse()`, plafond de 50
  titres/liste appliqué côté serveur (leçon du bug T6 de la session
  précédente — une liste custom sans limite aurait pu recréer le même
  problème de sous-requêtes). Télémétrie `list_saved` ajoutée à la demande
  de JP (« garder une trace des listes des gens »), et bug réel trouvé en
  la testant : le collecteur (`telemetry-worker/`) rejetait tout
  `event_type` hors d'une liste blanche figée depuis le 6/9 — `error`
  (ajouté le 7/9) n'y avait jamais été ajouté, donc **muet depuis 5
  jours**. Corrigé (les deux ajoutés à la liste blanche). Vérifié en
  direct local + cloud dev (isolation `jp`/`louis` confirmée, plafond de
  50 testé avec 51 tentatives réelles), 69/69 + 17/17 tests. Feature 355
  marquée `Livre` dans bilbao (354 = Cron Trigger, notée en amont comme
  piste future, `Planifie`). **Déployé en production** après confirmation
  de JP — schéma D1 réel appliqué, castellana et telemetry-worker
  redéployés, vérifiés en direct sur les deux vraies URL (création/ajout/
  screening/suppression d'une liste sur castellana ; `list_saved`/`error`
  acceptés sur le collecteur, testés puis retirés de la base).
- 2026-09-18 : T1 (tri/filtre/suppression du tableau « Derniers
  événements » de `telemetry-worker`, nouveau scope `ids` sur
  `POST /delete`) et T2 (ticker par défaut retiré, `CFG.defauts.ticker`
  `'AMD'` → `''`, placeholder « ex. AAPL » sur les 3 champs Symbole) livrés
  et vérifiés (D1 local jetable pour T1, navigateur pour T2, 69/69 +
  17/17 tests, aucune régression). Même session, un spike de faisabilité
  (script isolé, jamais commité) a confirmé qu'un client MCP fait maison
  avec `@modelcontextprotocol/sdk` peut mener un vrai flux OAuth 2.1 face
  au serveur MCP officiel de TradingView (`https://mcp.tradingview.com/mcp`)
  — découverte des métadonnées et enregistrement dynamique du client tous
  deux réussis, URL d'autorisation PKCE valide obtenue — arrêté
  volontairement avant l'étape de login réelle de JP. Voir section
  « Connexion TradingView non persistante » plus haut. Décision prise mais
  pas encore exécutée : mots de passe uniques par testeur (jp/louis/
  guillaume/luc), via `node cloud/scripts/create-user.mjs <nom> --remote`,
  à lancer par JP lui-même.
- 2026-09-19 : console CRUD des comptes castellana dans bilbao + magic
  link — voir la vérification factuelle en tête de ce fichier pour le
  détail complet. Migration idempotente (`cloud/scripts/migrate-users-
  email-magiclinks.mjs`), API d'administration (`cloud/src/routes/
  admin.js`, Basic Auth distinct de telemetry-worker), magic link
  (`cloud/src/routes/auth.js`, `db/magic-links.js`, `lib/email.js`,
  Resend), et côté bilbao un nouveau `server/castellana-users.js` +
  7ᵉ onglet « Comptes castellana ». Suppression = désactivation
  (`users.disabled`), jamais un DELETE dur — confirmé nécessaire en
  heurtant la contrainte de clé étrangère réelle de D1 en testant. Vérifié
  de bout en bout (D1 local, navigateur, `curl`), 69/69 + 17/17 tests,
  aucune donnée réelle touchée.
- 2026-09-19 (suite, même jour) : **mise en production complétée avec
  JP.** Secrets Wrangler créés, `.env` bilbao complété — bug réel trouvé
  au déploiement (migration jamais lancée en `--remote`, corrigé sans
  perte de données réelles), compte Resend créé via GitHub, domaine
  `iecho.ca` vérifié (intégration Cloudflare de Resend, DNS déjà sur
  Cloudflare), `RESEND_FROM` → `castellana@iecho.ca`, redéployé — magic
  link confirmé fonctionnel vers n'importe quelle adresse via
  `wrangler tail`. **Incident de sécurité évité de justesse** : une
  première clé API Resend collée par erreur dans le chat (copie d'une
  sortie de terminal) a été traitée comme compromise, révoquée et
  regénérée en portée Sending access seulement avant tout usage. Voir la
  vérification factuelle en tête de fichier pour le détail complet.
- 2026-09-19 (suite) : colonne « Dernière connexion » dans le tableau
  « Comptes castellana » de bilbao (`cloud/src/db/users.js`, dérivée de
  `MAX(sessions.created_at)`, aucune migration) et précision ajoutée dans
  la carte d'aide de bilbao (le courriel de magic link contient un lien
  direct vers castellana). Vérifié sur les vraies données de production.

- 2026-09-20 (5e session) : roadmap bilbao réconcilié — feature #366 (comptes,
  magic link, télémétrie, ticker par défaut ; `Livre` au 19/9) et #367
  (connexion TradingView non persistante, `Idee`), commits `3ea8c22` et
  `f9492f3` dans `feature-factory`. Onglet TradingView ajouté sous Réglages
  (commit `050853a`), **non déployé**. Reste à JP : mots de passe uniques par
  testeur (`create-user.mjs --remote`), et `wrangler deploy` quand il le veut.

- 2026-09-22 : Options A/Journal A (vente de puts à primes continues) et
  flags par compte — voir les deux sections dédiées plus haut et la
  vérification factuelle en tête de fichier pour le détail complet.
  Résumé : nouvel onglet Options A (rendement annualisé/capital requis/
  grille/roulement), nouvel onglet Journal A (screener de primes/
  calculateur/cycles de la Roue avec effet de bord sur le Journal actions/
  alertes), carte Labo « Revenu de primes réalisé », deux bugs réels
  corrigés en testant (position bloquée à l'assignation, route
  `/api/options/premium-screener` avalée par `/api/options/:ticker`),
  flags `options_a_tab`/`journal_a_tab` désormais surchargeables PAR
  COMPTE depuis « Comptes castellana » (bilbao). **Déployé en production
  le jour même** (2 migrations `--remote`, 2 `wrangler deploy`) —
  commits `ea3c408`/`3adf420` (trading-assistant), `f620882`
  (feature-factory). Les deux flags restent OFF par défaut pour tout le
  monde. 125/125 tests.

- 2026-09-22 (2e session) : détecteur de « meilleurs deals » (achat vs
  vente, puts et calls) dans Options A — voir la section dédiée plus haut
  et la vérification factuelle en tête de fichier. Résumé : carte « Meilleurs
  deals — cette chaîne » (`js/options-tab-a.js`), 3 sous-scores transparents
  dans `js/options-analytics.js` (liquidité, valorisation IV vs historique —
  inversée entre vente et achat —, rendement/levier), entièrement côté
  navigateur (aucun backend, aucune migration). **Bug réel trouvé en
  testant sur AMD** : un call ITM profond ressortait avec un rendement
  annualisé à 20 000 %+ (calculé sur le bid brut, presque entièrement
  intrinsèque) — corrigé avec `optIntrinsicValue`/`optExtrinsicValue`, le
  rendement se calcule désormais sur la valeur temps seule. 137/137 tests
  (12 nouveaux). **Déployé en production le jour même** (`6013ede`,
  `wrangler deploy`).

- 2026-09-22/23 : **Radar** — screener multi-titres de meilleurs deals
  d'options, **local uniquement** (voir la section « Radar » plus haut et la
  vérification factuelle en tête de fichier). `server/deal-scanner.js`, tables
  `deal_scans`/`deal_results`, 4 routes `/api/deal-scanner/*`, onglet « Radar »
  (`js/deal-scanner-tab.js`) caché derrière le flag local `radar_tab`
  (`settings.json` → `featureFlags.radarTab`, défaut OFF). Scan réel de
  210 titres en 18 s, 3 erreurs légitimes, aucun 429. 145/145 tests
  (8 nouveaux). Commits `b6744ad` (moteur + UI) et `02dc964` (flag), poussés ;
  rien à déployer (aucun pendant cloud).

- 2026-09-26 : **interface compacte** et chaque élément dans une carte (voir
  la section « Interface compacte » plus haut). Composants `.field-grid`,
  `.metric-band`, `.signal-pair` ; appliqués à la section Symbole, au
  screener de primes et au calculateur « Vendre une option ». Éléments hors
  carte rangés dans les huit onglets. Commit `ed93c9d`, **déployé en
  production** (version `14547307`, fichiers statiques, aucune migration),
  153/153 tests. Extension à la Fiche de trade le même jour, déployée
  (version `6845198d`).

- 2026-09-26/27 : correctifs — listes déroulantes coupées corrigées (34 px),
  gabarits étendus à Options A et au Journal ; Screener scindé en 5 cartes
  avec « Agrandir » séparé pour le graphique et le tableau ; « Journal A »
  renommé « Screener Prime » (affichage seulement) ; carte Fondamentaux
  répliquée sous Symbole (Secteurs/Screener/Labo) puis **portée en
  production** (route, flag ON par défaut, déployée version `af8f7a9c`).
  Voir les sections dédiées plus haut. 153/153 tests.

- 2026-09-27 : **repères d'interface** — lettre par onglet, lettre+numéro
  par carte (`js/ui-ids.js`), dérivés de l'ordre réel du DOM plutôt qu'une
  table écrite à la main ; une carte cachée par un feature flag compte
  quand même dans la numérotation. Rendu en CSS pur (`::before`, jamais un
  noeud enfant — plusieurs cartes réécrivent leur `innerHTML`).
  Interrupteur rond dans Réglages → Technique (recréation du « 16. Switch
  button » de Mojtaba Seyedi), OFF par défaut, persisté en `localStorage`.
  Bug de spécificité CSS (`.row label`) trouvé et corrigé en testant.
  153/153 tests. **Déployé en production** le jour même
  (`fa79c5a2`). Voir la section dédiée plus haut.

## Checklist portfolio restante (voir `CLAUDE.md` racine, section
« Checklist — ajouter un nouveau produit »)

- [x] Créer le repo Git dédié + repo GitHub sous `iechocreator-po` (22/7/2026
  — [iechocreator-po/trading-assistant](https://github.com/iechocreator-po/trading-assistant), privé).
- [x] Ajouter `castellana` à la table sommaire et écrire sa fiche détaillée
  dans `2000_DigitalProducts/CLAUDE.md` (22/7/2026).
- [x] Ajouter `castellana → trading-assistant/` au mapping code→dossier
  (table « Dossier local » du `CLAUDE.md` racine, lu par bilbao) (22/7/2026)
  — bilbao peut désormais suivre ses features/releases une fois une première
  session de travail avec lui déclenchée.
- [x] Ajouter `trading-assistant` à `REPOS` dans
  `~/.claude/scripts/portfolio-checkin.sh` (22/7/2026).
- [x] Une fois un `bilbao.features.json` généré via la Console de bilbao,
  mettre à jour la section « Démarrage de session » de ce fichier pour lire
  `feature-factory/data/castellana/features.json` (même patron que madrid)
  (2026-07-25 — section « Démarrage de session — features en attente » ajoutée
  en haut du fichier ; `feature-factory/data/castellana/features.json` existe
  et contient 5 features en attente).

## Journal de la Roue — étape 1 : schéma et calculs (13/10/2026, bilbao #433)

Reprend ce que le Google Sheets du club calculait (analyse : `anticipation/analyse-journal-roue-club.md`). **Aucune interface
encore** : l'onglet « Roue » est l'étape 2 (#434).

- **Schéma, migrations additives** (`server/db.js` au démarrage ; `cloud/schema.sql` + `cloud/scripts/migrate-roue.mjs`, idempotent,
  vérifié par `PRAGMA table_info`/`sqlite_master`, rejoué deux fois sur le D1 local) :
  `option_trades` + `commission_ouverture`, `commission_cloture`, `roule_vers_id`, `source` ; `trades` + `commission_entree`,
  `commission_sortie`, `source` ; table `cash_flows` (compte, date, type `depart|depot|retrait|dividende|autre_revenu`, montant
  **toujours positif**, le type donne le signe ; ticker et cycle_id optionnels).
- **Écart avec le plan, voulu** : les achats et ventes d'actions directs ne deviennent PAS des types `achat`/`vente` de
  `option_trades` (il aurait fallu reconstruire la table en production pour changer son CHECK). Les actions restent dans `trades`,
  liées au cycle par `option_cycle_id`, comme pour une assignation : une seule source pour les actions détenues. Les dividendes sont
  des `cash_flows` datés, pas une colonne : le Sheets les mettait sur une ligne sans date propre.
- **Sûr avant migration** : la clôture d'une jambe n'écrit `commission_cloture`/`roule_vers_id` que s'ils sont fournis, et le bilan
  cloud lit `cash_flows` dans un `try`. Un Worker déployé avant `migrate-roue.mjs --remote` continue donc de fonctionner tant qu'on
  ne lui envoie pas ces champs. **Lancer quand même la migration distante avant le prochain `wrangler deploy`.**
- **Calculs purs** (`js/options-analytics.js`, copies `cloud/src/lib/` et `cloud/public/js/` resynchronisées) : `optLegPnl`,
  `optLegReturn`, `optLegIssues` (incohérences signalées, jamais corrigées), `optWeekStart`/`optWeekYear` (semaine dimanche →
  samedi, année du vendredi, comme la table Semaines du Sheets), `optWeeklyReport`, `optAccountSnapshot`, `optAnnualDashboard`
  (profit réel ajusté, rendement composé, projeté seulement à partir de 4 semaines), `optMaxPricePerTicker` (formule C32 du
  Sheets, pour #422). `optCycleBilan` gagne `commissions`, `dividendes`, `pnlNet`, `rendementNet`, `coutDeBaseNet` ; `pnl`,
  `rendement` et `vsHold` sont **inchangés** (la comparaison à la détention reste sans frais ni dividendes).
- **Écarts assumés avec le Sheets** : commission de rachat comptée ; jambe ouverte hors de tout profit réalisé ; gain sur actions
  revendues compté dans la semaine (le Sheets ne le comptait que pour une VENTE directe) ; pas de rendement annualisé quand les dates
  sont incohérentes (le Sheets forçait 1 jour : la ligne d'exemple LULU sortait à ~248 %).
- **Tests** : `server/roue-journal.test.js` (13), recoupés avec le Sheets : LULU → P/L 139, valeur du compte 100 139 (cellule O5 du
  RAPPORT HEBDO), prix max = C32. 306/306. Bout-en-bout sur une copie jetable du projet (base neuve) : jambe avec commission,
  assignation → ligne `trades`, dividende du cycle dans le bilan, rapport hebdo. La vraie base locale a reçu les colonnes au premier
  lancement des tests (2 jambes et 2 trades conservés).

## Journal de la Roue — étape 2 : onglet « Roue » (13/10/2026, bilbao #434)

- **Onglet H, après Screener Prime**, derrière le flag `roue_tab` : `settings.json` → `featureFlags.roueTab` en local (false),
  `KNOWN_FLAGS`/`KNOWN_USER_FLAGS` en cloud (surchargeable par compte : colonne « Roue » dans Comptes castellana de bilbao).
  **Les onglets suivants reculent d'une lettre** : Anticipation (cloud) et Radar (local) passent de H à I.
- **Repères réels** (dérivés du DOM ; l'encadré « À propos » est H1, comme dans tous les onglets) : H2 Comptes et capital,
  H3 Journal des positions, H4 Positions de la Roue, H5 Bilan par cycle. Le plan (analyse-journal-roue-club.md) les numérotait
  H1 à H4 : c'est l'ordre, pas le repère.
- **Code** : `js/roue-tab.js` (+ copie `cloud/public/js/`, dans le test de parité), aucun calcul propre — tout vient de
  `js/options-analytics.js`. Nouvelles routes `GET/POST /api/cash-flows`, `DELETE /api/cash-flows/:id` (`server/cash-flows.js`,
  `cloud/src/db/cash-flows.js`, montant toujours positif, le type donne le signe ; en cloud, un `cycle_id` d'un autre compte est
  refusé). Clôture dans un `<dialog>` : un roulement crée d'abord la nouvelle position du même cycle puis clôture l'ancienne avec
  `rouleVersId` ; si la clôture échoue, la nouvelle position est supprimée. Stop initial toujours demandé pour un put assigné.
- **Lignes d'état** (#437, en cours) : sur les cartes de Screener Prime « Bilan de la Roue par cycle » (→ H5, #440) et « Cycles &
  positions ouvertes » (→ H3/H4, #439), classe `.roue-etat`, visibles seulement quand l'onglet Roue est actif (`html.roue-on`).
  Restent à faire : E4 (avec le tableau annuel, étape 3) et les lignes « améliorée » (calculateur G, Journal & stats D).
- **Bug trouvé et corrigé, introduit à l'étape 1** : `function optNum` (aide de #433) avait le même nom que le `const optNum` de
  `js/options-common.js`. Scripts classiques = portée globale partagée → SyntaxError, `options-common.js` ne se chargeait plus
  (onglets Options cassés dans le navigateur) alors que tous les tests passaient (ils évaluent chaque fichier seul). Renommée
  `optNum0`. **Nouveau test** `server/browser-globals.test.js` : aucun nom de premier niveau déclaré deux fois par les scripts de
  `index.html` et de `cloud/public/index.html`.
- **Vérifié** dans le navigateur sur une **copie jetable** du projet (base neuve, port 4710, flag activé ; ta base n'a pas été
  touchée) : capital de départ, dépôt, dividende lié au cycle ; LULU expiré (P/L 139), put AMD assigné (stop manquant refusé, action
  créée), call racheté puis roulé (lien #3 → #4) ; valeur réalisée 102 449 $ comme au calcul de l'étape 1 ; repères H2 à H5 ;
  lignes d'état visibles ; aucune erreur console liée (le seul 409 vient de `/api/sweep/sectors`, base sans balayage). 309/309.
  **Cloud** : modules importés et `wrangler deploy --dry-run` réussi ; **pas vérifié dans le navigateur**, migration D1 distante
  non lancée, rien déployé.

## Journal de la Roue — étape 3 : rapport hebdo et tableau annuel (13/10/2026, bilbao #435, #437)

- **H6 Rapport hebdo** (`optWeeklyReport`) : une ligne par semaine dimanche → samedi de l'année choisie, semaines vides estompées ;
  positions, assignations, puts vendus, commissions, dividendes, autres revenus, dépôts/retraits, profit net, ROI hebdo, valeur du
  compte réalisée, profit cumulé. Sélecteur d'année partagé avec H7.
- **H7 Tableau annuel** (`optAnnualDashboard`) : 10 indicateurs en bande de 2 rangées (profit réalisé, profit réel ajusté, rendement
  composé et projeté, taux de succès, taux d'assignation, commissions, dividendes, autres revenus, pertes latentes, valeur du compte),
  4 graphiques faits main (profit par mois, courbe de la valeur réalisée, profit par titre, par secteur — barres horizontales plutôt
  que les camemberts du Sheets, top 10).
- **Secteurs** : nouvelle route `GET /api/ticker-sectors?tickers=A,B` (local et cloud, 20 titres au plus) qui lit le secteur Yahoo
  via `getFundamentalsBatch` (cache `fundamentals:v2`) ; jamais le scraping stockanalysis.com du Sheets. Inconnu → « Non renseigné ».
- **Lignes d'état terminées (#437)**, toutes visibles seulement sous `html.roue-on` : E4 « Revenu de primes réalisé » (visée, #441) ;
  calculateur de Screener Prime « améliorée » (nouveau champ Commission, vide = non renseignée, et l'onglet Roue se rafraîchit à
  l'enregistrement) ; Journal & stats « améliorée » (lien « Roue #cycle » sur une action issue d'une assignation, classe `.roue-lien`).
  **Aucune section supprimée.**
- **Vérifié** dans le navigateur sur une copie jetable (base neuve, port 4710) : 30 semaines de puts sur 4 titres, une assignation
  AMD, un call couvert dans la monnaie, un dépôt, un dividende. Profit réel ajusté recoupé à la main (5 689 + 553 de latent − 1 553 de
  call plafonné = 4 689) ; repères H1 à H7 ; secteurs Yahoo reçus ; calculateur → commission 0,65 enregistrée et position visible dans
  H3 ; lignes d'état visibles (G ×3, E4, D) ; aucune erreur console liée. 309/309, `wrangler deploy --dry-run` réussi. **Cloud non
  vérifié dans le navigateur, migration D1 distante non lancée, rien déployé.**

## Journal de la Roue — étape 4 : import du Google Sheets du club (13/10/2026, bilbao #436)

- **Lecture sans dépendance, dans le navigateur** (`js/roue-import.js`, copie `cloud/public/js/`, évalué par `server/roue-import.js`
  pour les tests) : un `.xlsx` est un zip de XML, lu avec `DecompressionStream('deflate-raw')` (navigateur et Node ≥ 18) ; on lit
  les **valeurs en cache** des formules, pas les formules. Dates Excel en numéros de série (époque 1899-12-30). `.csv` aussi
  (export Google Sheets de l'onglet JOURNAL, virgule ou point-virgule, dates JJ/MM/AAAA ou ISO, décimales à virgule).
- **Colonnes repérées par leur en-tête** normalisé (sans accents), jamais par leur lettre : le Sheets a déjà inséré une colonne
  « Earnings » qui a décalé son propre guide.
- **Statut déduit, affiché avec sa raison et modifiable** : rachat rempli → racheté ; échéance à venir → ouvert ; PUT assigné si
  clôture < strike, CALL si clôture > strike (la règle du Sheets, qui rate une assignation anticipée) ; clôture absente ou égale au
  strike → « à vérifier ». Ligne incohérente (optLegIssues) signalée et **décochée**, jamais corrigée.
- **Ré-import sans doublon** : option = même compte, symbole, type, strike, ouverture, échéance ; ACHAT = même date d'entrée et
  prix ; VENTE = même date de sortie et prix. Une option déjà présente rattache le reste de son cycle au cycle castellana existant.
- **Stop par cycle** obligatoire dès qu'une action est créée (put assigné ou ACHAT) : saisi par cycle ou rempli d'un coup à
  « x % sous le prix d'achat » choisi par l'utilisateur ; l'import est refusé tant qu'il en manque un.
- **Exécution** (`roueImpExecute`, `js/roue-tab.js`) par l'API existante, cycle par cycle, dans l'ordre chronologique (ouverture,
  clôture, achat, vente) ; une erreur n'arrête pas le reste et est listée. Dividendes d'une ligne → flux `dividende` du cycle.
  Cycle fermé s'il ne reste ni option ouverte ni action détenue. Depuis un `.xlsx` seulement : capital de départ (PORTFOLIO,
  « Capital de départ », daté du dimanche de la semaine 1), dépôts/retraits et autres revenus (RAPPORT HEBDO, datés par la table
  Semaines). Tout est marqué `source = 'import_sheets'`.
- **Vérifié** : tests (`server/roue-import.test.js`, dont le **vrai fichier du club**, sauté s'il est absent puisqu'il n'est pas
  versionné : LULU lue, statut « expiré » car 210,81 > 205, signalée pour ses dates et décochée ; capital de départ 100 000 $ du
  28/12/2025). 314/314. Navigateur sur une copie jetable : import du .xlsx (capital seul), import d'un CSV (put assigné → action,
  call racheté, call assigné → action revendue, achat/vente NVDA, dividende, stops refusés tant qu'absents), puis ré-import. **Deux
  défauts trouvés par le ré-import et corrigés** : une VENTE n'était pas reconnue comme déjà faite, et un cycle fait seulement
  d'actions restait « actif ». Après correction : 6 lignes sur 6 « déjà présentes », cycle NVDA clos. Les erreurs
  `ERR_CONNECTION_REFUSED` de la console venaient des appels de statut pendant que le serveur de test était arrêté entre deux passes.
  **Cloud non vérifié dans le navigateur, migration D1 distante non lancée, rien déployé.**

## Journal de la Roue — étape 6 : mise en ligne (13/10/2026, bilbao #438, en cours)

- **Migration D1 distante** : `node scripts/migrate-roue.mjs --remote`, lancée AVANT le déploiement ; sortie vérifiée (les 7 colonnes
  ajoutées, `cash_flows` et son index présents). Aucune donnée existante touchée.
- **Déploiement** : `wrangler deploy`, version `d7ced557-5b5b-4fbb-8211-c943271582a8`. Seuls changements cloud depuis le déploiement du
  12/10 : les étapes 1 à 4. Vérifié sur la vraie URL **par le contenu** : `js/roue-tab.js`, `js/roue-import.js` et
  `js/options-analytics.js` servis en `text/javascript` avec les nouvelles fonctions (`optNum0`, pas l'ancien `optNum` en collision),
  la page référence l'onglet ; `/api/cash-flows` et `/api/ticker-sectors` répondent 401 sans session ; le Worker déclare `roue_tab`
  (lu par bilbao).
- **Activation** : `roue_tab` forcé ON pour `iechocreator03` (id 5) depuis bilbao (audité). Aucun autre compte. **Non testé avec un vrai
  compte** (je n'ai pas d'identifiants, et ne dois pas en avoir) : à faire par JP, puis activation pour les membres du club depuis la
  colonne « Roue » de bilbao.
- **Limite connue** : excess liquidity non gérée. L'onglet raisonne en cash-secured (un put vendu immobilise strike × 100 ×
  contrats), prudent pour un compte sur marge. Feature #442 (estimation Reg T, à clarifier : courtier du club, marge ou cash-secured).


## Onglet Roue — tableaux de bord Semaine (H2) et annuel (H3) (16/10/2026, bilbao #443, #444)

Inspirés du « Wheel Journal » vu par JP (maquettes `anticipation/roue-semaine.html` et `roue-annuel.html`, onglet Anticipation).
Placés en tête de la Roue : **tous les repères suivants reculent de deux crans** (Comptes et capital H4, Journal H5, Positions H6,
Bilan H7, Rapport hebdo H8, ancien Tableau annuel H9, Import H10). Les lignes d'état de Screener Prime et du Journal ont suivi.
- **Décisions de JP** : latent d'une action assignée = au dernier cours contre le **coût de base net des primes** (jamais contre
  le strike) ; valeur du compte en **deux traits** (valeur réalisée, et apports + primes nettes cumulées : un dépôt monte les deux,
  marqué d'un trait vertical) ; « taux de succès » remplacé par **expirée / rachetée (roulée comprise) / assignée** ; projection
  annualisée dès 4 semaines seulement, réalisé toujours à côté.
- **H2 Semaine** : sélecteur ‹ › / Aujourd'hui (`roueState.weekStart`, non mémorisé), filtre compte. Options dont l'échéance OU
  l'ouverture tombe dans la semaine (`optWeekLegs`) ; prime/strike avec la règle d'Options (`OPTA_RULE_DEFAULT`, 0,5 % par 5 jours,
  `optPremiumRule` sur la prime de vente) ; distance au strike (`optStrikeDistance`, cours Yahoo) ; feu des résultats (rouge ≤ 5 j,
  orange ≤ 10 j). Positions assignées (`optRouePositions` : coût de base net, latent, vérification « call sous le coût de base » /
  « plafonné »), semaine suivante, encadré « À surveiller » calculé (rien d'inventé : un point absent n'est pas listé).
- **H3 annuel** : 10 indicateurs (valeur, profit réalisé, rendement composé = pondéré dans le temps, options closes, vs S&P 500,
  profit réel ajusté, latent des positions, capital assigné, taux d'assignation, commissions), deux traits (`optValueSeries`),
  dénouement par mois (`optLegOutcomes`), primes par mois / titre / secteur (`optPremiumBreakdown`, options seules, frais déduits),
  positions en cours, capital, activité (`optRoueActivity`). **Vs S&P 500** = rendement composé − rendement de SPY depuis la première
  semaine terminée de l'année (`/api/screening/history?tickers=SPY`, chargé une fois).
- **Limite** : le latent n'est pas historisé (pas d'historique des cours) ; la courbe montre la valeur réalisée, le latent est dans
  la tuile « Valeur du compte ».
- `/api/ticker-sectors` (local et cloud) renvoie aussi `earnings` (jours avant les résultats, `daysToEarnings` des fondamentaux,
  zéro appel de plus). Lots de 20, titres ouverts d'abord, 60 au plus.
- L'ancien « Tableau annuel » (H9) porte une ligne « visée pour suppression » : feature **#445**.
- **Piège** : une accolade en trop dans `roue-tab.js` faisait disparaître l'onglet alors que les 324 tests passaient.
  `server/browser-globals.test.js` compile maintenant chaque script des deux `index.html` (`vm.Script`).
- Vérifié dans le navigateur sur une copie jetable (port 4710, base neuve, 15 positions sur 2 comptes) : navigation des semaines,
  filtres, année, positions (PCG : call 14,50 sous le coût net 14,78 signalé). 324 tests. Cloud : `--dry-run` seulement.

## Retouches du 16/10/2026 : « À surveiller », (i) des en-têtes

- **H2** : les tableaux reprennent toute la largeur ; « À surveiller » est en bas à droite (300 px), à côté de « Semaine
  suivante » (empilé sous 900 px), texte compact.
  Colonne « Résultats » renommée **« Earning »**.
- **(i) sur les en-têtes** de H2, H5 (onglet Roue), A2 (P/E moyen, PEG moyen), A3 et B4 (toutes les colonnes sauf Symbole).
  37 entrées ajoutées à `js/glossaire-indicateurs.js` (78 au total). `glossInfoBtn(clé)` pour les tableaux écrits en JS ;
  `initGlossHeaders()` ajoute le bouton à chaque `<th data-gloss="clé">` de index.html (appelé à l'init). Le clic sur (i)
  fait `event.stopPropagation()` : il ouvre l'aide sans trier la colonne. Avant, ces colonnes n'avaient que des infobulles
  `title` au survol (toujours là).

## Section Symbole : bloc « Tendance » (16/10/2026, ex-carte E7 de l'Option Lab)

La carte « Données réelles du titre » de l'Option Lab (E7 : prix, ATR, 3 SMA, alignement) est retirée ; ses chiffres
forment maintenant le bloc **« Tendance (filtre d'entrée) »** de la section Symbole des **4 onglets** (A4 Secteurs, B5
Screener, Fiche de trade, E5 Option Lab), entre Fondamentaux et Force relative. `renderTrendFor()` (`js/ticker-section.js`)
lit la même réponse `/api/market-data` que les fondamentaux : **aucun appel de plus**. Les libellés suivent les périodes des
Réglages (`smaPeriods`, ex. SMA 9 / 21 / 50) ; le bloc se vide avec le reste quand le symbole change. `loadLaboTicker()` garde
`laboTickerData` (séquences, volatilité) mais n'écrit plus dans la carte disparue. Repères de l'Option Lab inchangés
(E7 était la dernière carte).

## Onglet Roue — suppression multiple (16/10/2026)

- Cases à cocher (une par ligne + « tout sélectionner ») sur le **Journal des positions** (H3) et la liste des **mouvements** (H2),
  bouton « Supprimer la sélection (N) ». Une sélection ne garde que les lignes du compte affiché.
- **Plan pur partagé** `optRoueDeletionPlan` (`js/options-analytics.js`, copies générées) : l'écran l'utilise pour annoncer ce qui
  partira dans la confirmation, le serveur pour supprimer exactement la même chose. Règle : un cycle dont il ne reste **aucune**
  position est supprimé avec ses actions (Journal & stats compris), dividendes et mouvements ; un lien de roulement vers une position
  supprimée est remis à vide. Tests : `server/roue-delete.test.js`.
- Route `POST /api/roue/delete {legIds, flowIds}` (500 au plus) : local dans une transaction, cloud en un `db.batch` limité au
  `user_id` (les identifiants d'un autre compte sont ignorés). Le bouton ✕ par mouvement a été retiré le 17/10/2026 (les cases à cocher font la même chose, avec une confirmation plus complète).
- Vérifié dans le navigateur sur une copie jetable (cascade d'un cycle assigné, annulation, désélection). **Cloud : `--dry-run`
  seulement**, ni vérifié dans le navigateur ni déployé (aucune migration nécessaire).

## Largeur de l'application (16/10/2026)

- La limite de 900 px (`.container`, héritée des prototypes de 760/860 px) devient une variable `--app-max`, la **même pour tous
  les onglets et les Réglages** (choix de JP : pas de largeur différente selon le contexte). **Défaut : 1400 px.**
- Réglages → Personnalisation, carte « Largeur de l'application » : Étroite (900) / Large (1400) / Pleine largeur. Mémorisé par
  navigateur (`castellana-app-width`), appliqué par un script dans `<head>` avant l'affichage (pas de saut). Local et cloud.
- ⚠️ Nouvelle carte placée après « Repères d'interface » : les repères `R-E…` suivants de Personnalisation reculent d'un cran.
- Vérifié dans le navigateur à 1600 px (900 / 1400 / 1553 px mesurés, persistance au rechargement).

## Onglet Roue — colonne Compte et filtres par compte (16/10/2026)

- Colonne **Compte** dans les tableaux H2 (mouvements), H3 (positions), H4 (actions), H5 (bilans) et H6 (rapport hebdo).
- **Filtre par compte, avec « Tout »**, propre à chaque carte H3 à H7 (`roueState.filtres`, mémorisé par navigateur :
  `castellana-roue-filtres`, défaut « Tout »). Le compte de H2 reste celui des saisies et de l'import, et filtre la carte H2.
  `roueView(k)` accepte un compte ou `'tout'` ; cours, secteurs et années se calculent sur tous les comptes.
- **H6 « Tout »** : une ligne par compte et par semaine active (le ROI et la valeur n'ont de sens que pour un compte) ;
  les semaines vides ne sont estompées qu'avec un seul compte. **H7 « Tout »** : comptes additionnés.
- Vérifié dans le navigateur sur une copie jetable avec deux comptes (H7 Tout = margin + RRSP, 10 100 + 20 562 = 30 662 $).
- **H2 accepte aussi « Tout »** (même jour) : métriques et mouvements de tous les comptes additionnés. Le compte de destination
  n'est donc plus celui de H2 : un champ **Compte *** a été ajouté au formulaire de mouvement, à celui de position, et à côté du
  fichier d'import (`roue-flow-compte`, `roue-leg-compte`, `roue-imp-compte`), réglés sur le compte de H2 quand il est précis,
  sur le premier compte (margin) quand H2 est sur « Tout ». Les cycles proposés suivent le compte du formulaire.
- **Tableau « Par compte » dans H2** (même jour), au-dessus des « Mouvements » : une ligne par compte (avec « Tout », chaque compte
  ayant des données + une ligne Total) — capital de départ, dépôts − retraits, options ouvertes, actions détenues, valeur
  réalisée, capital immobilisé, disponible, valeur du compte. Déclencheur : JP croyait margin absent de H2, alors que le tableau
  de H2 ne listait que les mouvements et que margin n'en avait aucun (2 positions, pas de capital de départ).

## R-C2 terminé : envoi des courriels, et service macOS (17/10/2026)

- **R-C2, sous-section « 4 · Envoi des courriels (Resend) »** (local) : champ mot de passe pour la clé Resend, écrite dans le
  `.env` local (droits 600, autres lignes conservées) par `setResendKey()` (`server/alert-email.js`), jamais en base ni relue par
  le navigateur ; format `re_…` validé. Badge « Clé configurée » (source : `.env` ou variable d'environnement, prioritaire) avec
  l'expéditeur, bouton « Retirer la clé », bouton **« Envoyer un courriel de test »** vers les adresses ENREGISTRÉES (désactivé sans
  clé ou sans adresse). Routes `PUT /api/app-settings/resend-key` (`{key: null}` retire) et `POST /api/app-settings/test-email`
  (toujours 200, `{sent, errors}` avec le motif exact par adresse). Vérifié sur une copie jetable : clé invalide refusée, `.env`
  en 600 avec `ALERT_EMAIL` conservé, vrai appel à Resend refusé en 401 avec une fausse clé et motif affiché. **Pas encore testé
  avec une vraie clé** (aucune `.env` sur la machine au 17/10).
- **Service macOS** (`scripts/service-macos.sh`, `npm run service:install|restart|status|uninstall`) : LaunchAgent
  `ca.iecho.castellana` (RunAtLoad + KeepAlive, journal `data/castellana-service.log`). Raison : lancé depuis un terminal ou une
  session Claude Code, le serveur mourait avec eux. `install` arrête d'abord un serveur lancé à la main sur 4700. Pas installé
  automatiquement : c'est à JP de lancer `npm run service:install`. Après un `git pull`, `npm run service:restart`.
- **Roue, boutons alignés sur les autres onglets (17/10/2026)** : « Actualiser les cours », « Actualiser » (H7) et « Aujourd'hui »
  (H2) en **Éclat** (`ds-btn--shine ds-btn--sm`), boutons de ligne et de sélection en `--sm`, « ⤢ Agrandir » (Pulsation) sur le
  Rapport hebdo H8 (`openTableOverlay`, ancre `roue-weeks-anchor` ; pas sur H5, dont les cases à cocher dépendent d'une délégation
  d'événements sur l'onglet). Formulaires repliables de H4 et H5 : un vrai bouton « ＋ Ajouter un mouvement » / « ＋ Saisir une
  position » (classe `.roue-add`, devient « − Fermer le formulaire » une fois ouvert) au lieu d'un lien discret. Local et cloud.
- **Artifact « Architecture de castellana »** (`docs/architecture-castellana.html`, https://claude.ai/artifact/CNHkyqCUquAHRctEzQXXiE,
  privé) : deux versions, partage du code, règles d'affaires serveur/navigateur, secrets, mise en ligne, pièges.


## Mot de passe oublié et changement de mot de passe (17/10/2026, cloud)

- **« Mot de passe oublié ? »** sur l'écran de connexion : réutilise le lien de connexion par courriel (même route
  `/api/auth/magic-link/request`, même réponse `{ok:true}` que le compte existe ou non, jeton à usage unique de 15 min).
  `purpose: 'reset'` ne change que l'atterrissage (`?magic=…&reset=1`, puis Réglages → Technique, carte « Compte ») et
  le sujet du courriel. L'écran dit qu'un compte **sans courriel** ne peut pas recevoir le lien et doit demander une
  réinitialisation à l'administrateur (bilbao, déjà en place).
- **« Changer mon mot de passe »** dans la carte « Compte » de Réglages → Technique (pas de nouvelle carte : aucun repère
  ne bouge). `POST /api/auth/password {oldPassword?, newPassword}` (sous `/api/auth/`, donc public dans `index.js` : la
  session est vérifiée dans la route). Ancien mot de passe **exigé**, sauf session ouverte par lien de courriel depuis
  moins de 15 min (`canSkipOldPassword`, `src/lib/password-rules.js`, testé). Nouveau : 10 à 200 caractères, différent
  du nom d'utilisateur, hachage PBKDF2 existant. Après changement : **toutes les autres sessions du compte supprimées**
  (jetons TradingView compris, cascade), liens de courriel encore valides invalidés, et la session courante repasse en
  `method = 'password'` (le passe-droit ne sert qu'une fois). `GET /api/auth/me` renvoie `method` et
  `canChangeWithoutOld` ; l'écran masque le champ, le serveur revérifie de toute façon.
- **Origine de la session** : colonne `sessions.method` (`'password'` | `'magic_link'`, défaut `'password'`, donc aucune
  session existante ne reçoit de passe-droit). Migration idempotente `cloud/scripts/migrate-session-method.mjs`
  (`PRAGMA table_info`, vérifie après coup). `createSession`/`findSession` fonctionnent **avant** la migration (repli sur
  l'ancien INSERT, `s.*`) : un déploiement trop tôt ne casse pas la connexion, il désactive seulement le passe-droit.
- **Vérifié** en local seulement (`wrangler dev` + D1 locale montée depuis l'ancien schéma, migration rejouée deux fois) :
  changer connecté (ancien manquant 400, faux 403, trop court 400, sans session 401, succès → l'autre session 401,
  ancien mot de passe refusé au login) ; oublié → lien → nouveau mot de passe sans l'ancien (4 autres sessions
  déconnectées, lien réutilisé refusé, 2ᵉ lien non utilisé invalidé, 2ᵉ changement exige l'ancien) ; session par lien
  vieillie à 16 min → ancien exigé ; parcours écran dans le navigateur. Tests : `cloud/src/lib/password-rules.test.js`
  (`node --test 'src/**/*.test.js'` dans `cloud/`, 27/27). **Rien migré en `--remote` ni déployé** : lancer
  `node scripts/migrate-session-method.mjs --remote` AVANT `wrangler deploy`. Courriel réel (Resend) non testé.
- **Non fait** : pas de limite de fréquence sur les demandes de lien ; la réinitialisation admin de bilbao ne déconnecte
  pas les sessions existantes.


## Balayage S&P 500 publié vers la version en ligne (17/10/2026)

Le balayage (503 titres) ne peut pas tourner sur le plan gratuit de Cloudflare (50 sous-requêtes par requête). Il est
donc calculé par l'app **locale** et son résultat, le même pour tous, est **poussé** vers le Worker, où tous les comptes
le lisent en lecture seule. Aucun calcul à la volée en cloud.

- **Module pur partagé** `cloud/src/lib/snapshots.js`, importé tel quel par le Worker et par `server/snapshot-publish.js`
  (comme `tv-mcp.js`) : forme de l'instantané (`buildSweepSnapshot`), validation stricte (`validateSnapshot`), fraîcheur
  (`snapshotStale`), réponse du Screener (`screeningFromSnapshot`). Pas de copie à synchroniser.
- **Instantané compact (~17 Ko pour 57 titres)** : version, date à New York, `computedAt`, source, tailles, lignes retenues
  (symbole, secteur GICS de `sp500.json`, verdict, Setup, Contexte, RSI, alignement, âge du signal, prix, force relative,
  Golden Cross, OBV, ATR, jours avant résultats — **pas de fondamentaux**, colonnes absentes = « — »), nouveautés depuis la
  veille, résumé par secteur (`sweep-sectors.js`).
- **Worker** : table D1 `daily_snapshots` (kind, date, json, created_at ; clé (kind, date), un second envoi le même jour
  remplace le premier, > 30 jours supprimé au même lot). `PUT /api/admin/snapshots/:kind` (Basic Auth admin existant,
  413 au-delà de 300 Ko, 400 au moindre champ inconnu, valeur hors type, date ≠ date New York de `computedAt`, date future
  ou > 30 j) ; `GET /api/admin/snapshots/:kind` (liste) ; `GET /api/snapshots/:kind/latest` (session) ; et
  `/api/screening?universe=sp500` sert le dernier instantané (409 `NO_SWEEP` sinon). Un seul type : `sp500_sweep`.
- **Local** : case « Publier vers la version en ligne » (R-C2, sous-section 5, **décochée par défaut**, clé `app_publish_cloud`),
  statut du dernier envoi (cache `snapshot:publish:last`) et bouton « Publier le dernier balayage maintenant »
  (`POST /api/snapshot/publish`, indépendant de la case). Identifiants dans le `.env` local : `CASTELLANA_ADMIN_URL`
  (https, ou http vers localhost pour wrangler dev), `CASTELLANA_ADMIN_USER`, `CASTELLANA_ADMIN_PASSWORD` — mêmes valeurs
  que les secrets Wrangler `ADMIN_USER`/`ADMIN_PASSWORD`. Jamais renvoyés au navigateur (seul l'hôte cible est affiché).
  L'envoi part après un balayage terminé ; `publishSweepSnapshot` ne lève jamais : un échec est affiché, le balayage reste réussi.
- **Cloud** : bouton « S&P 500 » actif dans B2, bandeau « Balayage calculé le … sur le poste local » (vert ; ambre s'il a
  plus d'un jour ouvrable — vendredi soir lu lundi = à jour, mardi = vieux ; jours fériés non comptés). Nouvelle carte
  « Setups du S&P 500 par secteur » après A2 : ⚠️ **en cloud, les repères A3 et suivants reculent d'un cran** (comme en local).
- **Vérifié** avec `wrangler dev --local` + D1 locale (jamais la production) et l'app locale du worktree (port 4711, `.env`
  et `.dev.vars` jetables, supprimés après) : vrai balayage de 503 titres → envoi automatique (57 titres), lecture par un
  compte de test, B2 et carte sectorielle dans le navigateur ; 401 sans auth, refus de forme, mauvais mot de passe → échec
  « HTTP 401 » affiché localement. Tests : `server/snapshots.test.js` (6). 
- **À faire par JP** (rien n'a été déployé) : `node cloud/scripts/migrate-snapshots.mjs --remote` (vérifier la sortie
  `sqlite_master`), puis `wrangler deploy`, puis remplir le `.env` local et cocher la case dans R-C2.

## Mise en production du 17/10/2026 (fusion, déploiement, publication testée)

- Branches `claude/cranky-rosalind-0ec0c3` (mot de passe oublié) et `claude/suspicious-feynman-d0dac1` (publication du balayage)
  fusionnées dans `main` ; 330 + 27 tests verts. Migrations distantes `migrate-snapshots.mjs` (un premier essai a échoué, le second a
  réussi) et `migrate-session-method.mjs`, vérifiées par `sqlite_master` / `pragma_table_info` ; `wrangler deploy` version `3ab48b9c`.
  Vérifié en ligne sans compte : page et JS servis, routes de session et admin en 401, demande de lien toujours `{ok:true}`.
- Publication : les 3 accès `CASTELLANA_ADMIN_*` copiés du `.env` de bilbao vers le `.env` local de castellana (600, ignoré par git).
  Envoi manuel réussi (`POST /api/snapshot/publish`) : balayage du 17/10, 57 lignes, ligne `sp500_sweep` présente en base distante.
  Case « Publier vers la version en ligne » encore **décochée**. **Affichage en ligne non vérifié avec un vrai compte.**

## Dernière connexion et dernière activité des comptes (18/10/2026, cloud)

- « Dernière connexion » (bilbao G3) venait de `MAX(sessions.created_at)` : faux, car une session dure 30 jours (un compte resté connecté ne
  se reconnecte jamais) et une déconnexion efface la ligne. Colonnes `users.last_login_at` (écrite par `createSession`) et `users.last_seen_at`
  (écrite par le middleware d'auth via `touchUserActivity`, au plus une fois par 10 min, après la réponse) ; `scripts/migrate-user-activity.mjs`
  lancé en local puis `--remote`, `last_login_at` rempli depuis les sessions restantes, `last_seen_at` laissé NULL (« Non mesuré »).
  `listUsers` renvoie encore `last_login` pour un bilbao ancien. Déployé (version `ef67b884`), vérifié en ligne dans bilbao.
- Même jour : `telemetry-worker` `/summary` renvoie `lastByWho` (dernier événement et nombre d'événements par testeur, toute la base),
  lu par bilbao G3 pour combiner télémétrie et `last_seen_at`. Redéployé (version `192a2a40`).

## Noms d'utilisateur cloud plus souples et skill `/revue-avant-push` (20/10/2026)

- **Noms de comptes cloud** : lettres, chiffres, `.`, `-`, `_`, 2 à 30 caractères, convertis en minuscules avant validation
  (`POST /api/admin/users` et `PUT /api/admin/users/:id`, `cloud/src/routes/admin.js`, commits `9074a56` et `179a59e`) ; la connexion
  met déjà le nom en minuscules, donc `Jp` et `jp` sont le même compte. `cloud/scripts/create-user.mjs` suit la même règle (`485931c`).
  Aucune migration, aucun test automatisé sur ces routes. Déployé (version `2411338d`) ; **non vérifié** : création d'un compte
  avec majuscule ou point sur la version en ligne.
- **Skill `/revue-code`** (20/10/2026), adaptée de `automated-pr-reviewer.md` (TJaenichen/claude-code-harness) : revue **en lecture seule**,
  **méthode commune** dans `2000_DigitalProducts/skills/revue-code/` (versionnée dans portfolio-meta, reliée par un lien symbolique à
  `~/.claude/skills/revue-code`) et **pièges propres à castellana** dans `.claude/revue-pieges.md` (18 pièges déjà vécus, commandes
  mécaniques, zones d'audit, règles de notation). Deux modes : `/revue-code` (diff en attente, avant push) et `/revue-code audit <zone>`
  (état des lieux du code existant, sans le plafond sur le code préexistant ; zones : `parite-routes`, `formules`, `donnees-marche`,
  `cloud-comptes`, `onglets`, `pages`). Mécanique (`npm test`, parité cloud, `--dry-run`), cinq passes notées de 0 à 100, seuls les constats
  à 80 ou plus. Remplace `/revue-avant-push` (première version, 65bd865, retirée). Premier essai (avant-push, sur les deux commits des noms
  d'utilisateur) : aucun constat à 80, un à 55 corrigé. **Le mode audit et la séparation méthode/pièges n'ont pas encore été essayés ;
  le lien symbolique est vérifié, pas le chargement de la skill dans une nouvelle session.**
- **Test de fumée navigateur (20/10/2026, phase 0 du plan de découpage)** : `npm run test:smoke` (`scripts/smoke-browser.mjs` et
  `.test.js`). Charge les deux pages dans un vrai Chrome headless, **sans dépendance npm** (protocole DevTools par le WebSocket natif de
  Node >= 22 ; Puppeteer aurait été installé chez les testeurs), avec un bouchon d'API. Voit les exceptions, erreurs de syntaxe, ressources
  introuvables, onglets qui ne s'activent pas. **Auto-test** : il injecte l'accolade en trop de `roue-tab.js` (17/10), le `optNum` dupliqué
  (13/10) et un script introuvable, et exige qu'ils soient vus. 6 tests sur 6, environ 45 s ; **hors de `npm test`** (Chrome requis, ignoré
  avec un message sinon). Limites : onglets masqués par un flag non cliqués, API non réelle.
- **Découpage des `index.html`, phase 1 : le CSS (20/10/2026)** : le bloc `<style>` de chaque page est sorti dans `css/app.css` (commun),
  `css/mode-local.css` et `css/mode-cloud.css` ; `cloud/public/css/app.css` est une copie octet pour octet (`npm run sync:cloud`,
  `server/css-parity.test.js`). Pages : 5 543 -> 4 878 lignes (local), 5 449 -> 4 770 (cloud). **Rendu prouvé identique** par
  `scripts/snapshot-styles.mjs` (styles calculés de chaque élément dans 29 états : 54 712 élément-états, 0 différence ; l'outil voit
  un écart de 0,1 rem). **Trouvé en route** : `.sub-title` n'a jamais été stylé dans le cloud alors que la carte « Compte » l'utilise ;
  gardé local pour ne rien changer, **décision à prendre**. Reste : les `style="…"` en ligne (251 / 239). 333 tests + 6 de fumée.
- **Découpage des `index.html`, phase 2 : le script en ligne (20/10/2026)** : les ~3 400 lignes de script en ligne de chaque page sont devenues
  11 fichiers communs `js/app-*.js` (2 677 lignes, copies cloud par `npm run sync:cloud`) et un fichier de mode (`js/mode-local.js`,
  `cloud/public/js/mode-cloud.js`, ~560 lignes chacun, dont les 10 fonctions qui diffèrent). Il ne reste en ligne que le démarrage.
  `index.html` 4 878 -> 1 551 lignes, cloud 4 770 -> 1 461. Découpage fait par un analyseur de syntaxe (acorn, hors dépôt), code déplacé
  tel quel. **Piège trouvé par le test de fumée** : le hissage des fonctions ne traverse pas les scripts séparés (`ReferenceError:
  renderSectorTopRows`) -> énoncés de chargement regroupés dans `js/app-init.js`, fichier de mode chargé en premier. **Preuves** :
  `scripts/snapshot-globals.mjs` (1 899 noms globaux, source de chaque fonction et valeurs d'état : 0 différence), styles : 0 différence
  sur 54 712 élément-états, 349 tests + 6 de fumée. **Non vérifié** avec un vrai compte ni les parcours hors onglets/Réglages. Reste : phase 3
  (démarrage en ligne), 1b (`style="…"`). Le cloud n'est pas redéployé.
- **Audit `donnees-marche` et correctif de l'étiquette de l'OBV (20/10/2026)** : constat à 82, prouvé en exécutant la vraie fonction :
  `classifyOBV` disait « même signe pour le prix et l'OBV = accumulation, signes opposés = distribution », donc faux dans 2 cas sur 4 (prix et OBV
  qui baissent -> « accumulation », prix qui baisse et OBV qui monte -> « distribution »), contre le glossaire (« OBV monte avec le prix »).
  Effet : +1 au contexte pour un repli accompagné d'un OBV qui baisse (verdict « prêt » au lieu de « à surveiller », exemple chiffré), taille réduite
  à tort, contexte de l'analyse IA faussé ; règle recopiée en trois endroits (`indicators.js` serveur et cloud, `dataset.js`). **Corrigé** : définition
  unique `obvTrendFrom` (`server/obv-trend.js`, copie cloud gardée par `PLAIN_COPIES`) : accumulation = prix ET OBV montent, distribution = le prix monte
  et l'OBV baisse, neutre = le reste (**choix par défaut : prix qui baisse avec OBV qui monte -> « neutre »**, à confirmer par JP) ; `classifyOBV`
  exportée ; glossaire précisé. 9 tests de plus (`server/obv-trend.test.js`, 4 échouent avec l'ancienne règle) ; 418 tests + 6 de fumée ; seul écart des noms
  globaux : `GLOSSAIRE` ; styles : 0 différence. **Non déployé.** **Le jeu de données du backtest change** (`obv_trend`) : tout jeu déjà généré
  (`data/dataset-elargi.csv`) est périmé. Observations non corrigées, créées dans bilbao le 20/10/2026 (`Idee`) : **#449** VWAP « du jour » en réalité sur 24 h
  glissantes (mesuré sur les vraies données de Yahoo : deux séances, heures hors séance comprises), **#450** force relative sur 1 jour alors que le glossaire dit
  « sur la période » (question pour JP), **#451** Golden Cross sans le seuil de 1 % du design. Autres observations sans feature : volume du jour partiel contre
  moyenne complète, `withRetry` qui réessaie les erreurs définitives.
- **Audit `formules` et correctif de la taille de position (20/10/2026)** : constat à 85, prouvé en exécutant la vraie fonction :
  `computeSizing` (`js/sizing.js`) donnait `floor(risque ÷ distance du stop)` sans borne par le capital, donc un titre calme
  (ATR 0,5 % du prix, risque 1 %, stop à 1,5 ATR) sortait à **133 % du capital** sans alerte (Fiche de trade et tableau du Screener).
  **Corrigé** : plafond `CFG.sizing.positionMaxPct` (config.js, **100 % par défaut**, réglable), `shares = min(risque, plafond)`, nouveaux
  champs (`sharesParRisque`, `plafonneParCapital`, `riskEngage`, `valeurPosition`, `pctCapital`), charge calculée sur le risque réel,
  `sizingCapNote()` partagée ; la Fiche affiche « N act. · X % du capital » et un avertissement ambre, le tableau « plafonné au capital ».
  `config.js` et `js/sizing.js` rejoignent `PLAIN_COPIES` (copies cloud gardées). 10 tests de plus dans `server/sizing.test.js` (dont une
  propriété sur 5 000 cas tirés au hasard ; 5 échouent sans le plafond) ; vérifié dans un vrai Chrome sur les deux pages (2 500 actions au lieu de
  3 030, risque réel 825 $, aucune erreur JS) ; noms globaux : seuls écarts attendus ; styles : 0 différence ; 403 tests + 6 de fumée.
  **Constat 2 corrigé ensuite** (20/10/2026) : le tableau de bord annuel de la Roue mélangeait l'année de la semaine (celle du vendredi, convention
  du Sheets du club) et l'année du calendrier ; une option fermée le 29/12/2026 valait 200 $ en 2026 dans « Primes nettes », 200 $ en 2027 dans
  « Profit réalisé », 0 $ dans le graphique par mois, et la ligne « actions et dividendes » de la carte H3 affichait -200 $ puis +200 $. Une seule
  définition maintenant, `optPeriodOf` (année et mois du VENDREDI), utilisée par le graphique par mois, les primes nettes, le dénouement,
  l'activité et la règle des 0,5 % « depuis janvier ». `js/options-analytics.js` et `js/roue-tab.js` rejoignent `PLAIN_COPIES`. 4 tests dans
  `server/roue-year-boundary.test.js` (dont une partition sur 3 000 options autour des fins d'année : chacune compte une fois, dans la même année
  partout ; tous échouent avec l'ancienne définition) ; vérifié dans un vrai Chrome (carte H3 : 2026 = 0 $ partout, 2027 = 200 $ partout) ; noms
  globaux : seuls écarts attendus ; styles : 0 différence ; 409 tests + 6 de fumée. **Non déployé.** Non traité : dates non validées à l'écriture + `Date.parse` permissif dans `optCycleBilan` (un cycle abîmé fait
  échouer tout le bilan), échéance hors fenêtre du screener de primes, capital d'un cycle à lots multiples.
- **Audit `cloud-comptes` et correctif des sessions (20/10/2026)** : constat à 90, **prouvé sur un Worker local jetable** (`wrangler dev --local`,
  base temporaire, compte de test inventé) : désactiver un compte ou réinitialiser son mot de passe depuis bilbao **ne fermait pas les
  sessions déjà ouvertes** (30 jours) ; seule la nouvelle connexion était refusée. **Corrigé** : `findSession` refuse un compte désactivé ;
  `disableUserAndRevoke` et `resetPasswordAndRevoke` (`cloud/src/db/users.js`) ferment les sessions (jetons TradingView compris) et
  invalident les liens magiques ; les routes `/disable` et `/reset-password` renvoient `sessionsClosed`. 8 tests dans
  `server/account-revocation.test.js` (vrai schéma SQL, deux échouent si l'ancien comportement revient) ; refait de bout en bout sur le
  Worker local : ancienne session -> 401 après désactivation et après réinitialisation. **`npm test` lance maintenant aussi les 27 tests de
  `cloud/src/`** (qu'il ignorait) : 392 au total. **Non déployé** : le Worker en production a encore l'ancien comportement.
  **Constats non traités** (voir `.claude/revue-pieges.md` et le rapport d'audit) : **aucune limitation du nombre d'essais** (60 mauvais
  mots de passe d'affilée et 30 demandes de lien magique = tout passe ; en production chaque demande envoie un courriel), lien magique
  consommable deux fois en parallèle, comptes devinables par le temps de réponse, aucun en-tête de sécurité en production, jetons stockés en
  clair, mots de passe de départ de 6 caractères (script `create-user.mjs`). **À vérifier par JP** : si un mot de passe partagé existe
  encore (le commentaire du 12/9 de `create-user.mjs` mentionne « tomate »), le remplacer compte par compte.
- **Audit `parite-routes` et correctif du serveur local (20/10/2026)** : premier audit de la skill `/revue-code`. Un constat à 80 ou plus,
  prouvé : `app.use(express.static(ROOT))` servait **toute la racine du projet** (base `data/castellana.sqlite` et ses `-wal`/`-shm`,
  `settings.json`, code de `server/` et `cloud/`, fichiers du club dans `anticipation/`) ; seuls les fichiers à point (`.env`) étaient
  protégés, et l'en-tête `Host` n'était jamais vérifié (« DNS rebinding »). **Corrigé** : `server/http-guard.js` (`hostGuard`, premier
  middleware ; `publicFiles`, liste explicite : `index.html`, `config.js`, `favicon.svg`, `css/`, `js/`, `design-system/`),
  `server/http-guard.test.js` (7 tests, dont un qui échoue si l'ancien comportement revient), vérifié aussi avec le vrai serveur
  dans une copie jetable (base neuve, port 4799) : fichiers sensibles 404, `Host` étranger 403, `localhost` et `127.0.0.1` 200.
  **À faire par JP : `npm run service:restart`** (le service launchd tourne encore sur l'ancien code) ; les testeurs l'auront à la
  prochaine publication du zip. Dette relevée, non traitée : 7 modules de calcul écrits en double (`server/*.js` et `cloud/src/lib/*.js`)
  sans test sur la version cloud (feature à créer dans bilbao) ; `ai-analyst-logic.js`, `fetch-retry.js`, `scoring.js` identiques
  à la main mais hors `PLAIN_COPIES` ; webhook local sans secret. Voir `.claude/revue-pieges.md`, zone `parite-routes`.
- **Découpage des `index.html`, phase 3a : une seule séquence de démarrage (20/10/2026)** : la suite d'appels de démarrage existait deux fois
  (script en ligne local, `bootApp()` cloud) ; elle vit dans `js/app-demarrage.js` (`demarrerApp(etapes)`), les étapes propres à un mode s'y
  accrochent par des points nommés (`MODE_LOCAL` dans `js/mode-local.js`, `bootApp()` dans `mode-cloud.js`). Le script en ligne local tient
  en une ligne ; la fonction `boot()` du cloud (authentification) reste en ligne, intacte (3b, à part). **Un seul changement voulu** :
  `loadSectorSetups()` s'appelle au même endroit dans les deux modes (en local, sa requête part plus tôt). Preuves : nouvel outil
  `scripts/snapshot-boot.mjs` (ordre d'émission des appels d'API : cloud identique, local mêmes 23 appels), noms globaux (seuls écarts
  attendus), styles 0 différence, 350 tests + 6 de fumée. **Non déployé, non vérifié avec un vrai compte.**
- **Plan de découpage des `index.html`** (feature #447) : `docs/plan-decoupage-index-html.md`, mesuré (142 fonctions sur 170 identiques entre
  les deux pages, 606 lignes de CSS sur 666), en 5 phases ; **plan seulement, rien n'est modifié**.
- **Retours de JP T1 à T5 (21/10/2026)** : (T1) les liens (`<a>`) gardaient le bleu par défaut du navigateur (`#0000EE`), quasi invisible en mode
  sombre (R-F1 « Liens utiles », « Mot de passe oublié ? » du login) ; règle `a:where(:link, :visited) { color: var(--accent) }` dans `css/app.css`,
  de spécificité 0 (toute classe de lien reste prioritaire). (T2) icône ✉️ retirée du bouton « Connexion facile par courriel » du login. (T3) RSI de
  C6 à deux décimales (champ à pas de 0,01, `toFixed(2)` au remplissage et dans les messages de la checklist). (T4) `createListFromReady()` (A3,
  « Générer une nouvelle liste ») passe maintenant les titres retenus, par lots de 20, dans `/api/screening/tickers` après la création : les
  données (prix, indicateurs, fondamentaux du screening) sont chargées et la liste est relue du serveur ; un lot en échec est signalé sans rien
  retirer de la liste. **Non exécuté en réel** (aucun balayage S&P 500 disponible pendant les essais). (T5) **G6 (Bilan de la Roue par cycle, Screener
  Prime) et H9 (ancien Tableau annuel de la Roue) supprimés**, bilbao #440 et #445 `Livre` ; **les repères se décalent** : G7 devient G6, H10 devient H9.
  Reste **G7 (Cycles & positions ouvertes, #439)** : H5 permet déjà de clôturer une position, mais la Roue n'existe que pour les comptes qui ont le drapeau
  `roue_tab` (aujourd'hui `iechocreator03`) ; la retirer maintenant ferait perdre la vue des cycles aux autres comptes de Screener Prime. **Question de JP
  (A6 et A4)** : le screening de A4 n'alimente PAS la carte Fondamentaux A6. A4 lit un `quoteSummary` par titre (P/E, float, PEG, bêta, P/S ; cache
  15 min), A6 lit `/api/fcf/:ticker` (`fundamentalsTimeSeries` + `quoteSummary`, 2 appels par titre, cache 24 h, au clic seulement). Les relier
  = feature bilbao **#452** (`Idee`, une demi-journée à une journée, environ 100 appels Yahoo à froid pour 50 titres). Commits `1ff0d18` et `c18bb6b`,
  poussés, **déployés** (version `ccb68aa3`), contenu vérifié sur la vraie URL ; **pas vérifié avec un vrai compte** (contraste des liens, C6, A3, cartes G et H).

## Audit « onglets » : correctifs d'échappement et test des onglets cachés (20/10/2026)

Audit de la zone `onglets` (Roue, Anticipation, Journal, listes, Screener) : un défaut d'injection dans du HTML construit à partir de données
(ticker, nom de liste, message d'erreur) et des onglets cachés par drapeau que le test de fumée ne visitait jamais.
- **Tickers validés à l'écriture** : `js/ticker-format.js` (`isValidTicker`, 1 à 15 caractères, lettres, chiffres, `. - ^ =`), copie serveur
  (`server/ticker-format.js`) et cloud ; appliqué aux trades, flux de trésorerie et options. L'import de la Roue signale « symbole invalide ».
- **Échappement** : `optEsc` ajouté dans `roue-tab`, `app-journal`, `app-listes`, `app-screening`, `mode-local`. Le champ de stop de
  l'import (Roue) et les actions de l'onglet Anticipation passent par `data-*` et un écouteur délégué, plus de gestionnaire en ligne.
- **Test** : `scripts/smoke-flags.test.js` (dans `npm run test:smoke`, 9 tests) charge local et cloud avec tous les drapeaux et des données
  piégées. Mutation vérifiée : retirer l'échappement du ticker dans `roue-tab` le fait échouer. L'échappement de `roueTag` est défensif,
  aucune donnée piégée ne l'atteint aujourd'hui.
- Vérifié : `npm test` 425/425, `test:smoke` 9/9, `sync:cloud --check` propre, `wrangler deploy --dry-run` passe. **Pas commité ni déployé.**

## Audit « app-js » : état partagé, session expirée, échappement (21/10/2026)

Audit de 3 862 lignes (`js/app-*.js`, `mode-local.js`, `mode-cloud.js`) par trois sous-agents en lecture seule, constats relus dans le code. Six corrigés :
- **Fiche de trade** : l'onglet ne recopie plus le symbole d'une carte Symbole que s'il diffère (et vide alors RSI/ATR/OBV de l'ancien titre) ; « Préparer » garde son titre au retour sur l'onglet.
- **Rafraîchissement de la watchlist et des réglages** : `refreshSelectionsPassively` ne change plus la carte qui alimente la Fiche.
- **Journal** : le contexte du screening préparé est joint une fois, jamais en modification.
- **Labo** : les données ne servent que pour le symbole chargé (`laboTickerData.ticker`), y compris pour la vraie chaîne d'options.
- **Cloud, session perdue** : un 401 hors `/api/auth/` recharge la page (au plus un rechargement par 10 s) avec un message sur l'écran de connexion ; `appDemarree` empêche les minuteries de 30 s de tourner (et d'envoyer des erreurs de télémétrie) avant la connexion.
- **Échappement** : `optEsc` sur les messages d'erreur et la bannière de mise à jour (`mode-local`, `mode-cloud`, `app-listes`).
Nouveau `scripts/smoke-etat.test.js` (5 tests, mutations vérifiées sauf celui du 401) ; `js/labo-real-chain.js` rejoint les copies synchronisées. 426 tests, 14 de fumée.
**Pas corrigé (sous 80, à décider)** : `vix ?? 17`, `rsi ?? 50` dans le sizing du Screener ; virgule décimale du prix de sortie ; courses de réponses (secteurs, Modifier puis Préparer) ; graphiques alignés par indice ; `localStorage` sans `try` dans `app-init.js`. Dette : ~310 lignes quasi identiques entre `mode-local` et `mode-cloud` (feature #447). **Pas commité ni déployé.**

### Audit « app-js » : suite, quatre observations corrigées (21/10/2026)
- **Sizing du Screener** : sans VIX, RSI ou OBV, la taille affiche « N/D » (plus de 17 / 50 / « neutre » inventés) ; les tableaux se redessinent à l'arrivée du VIX.
- **Clôture d'un trade** : la virgule décimale est lue (« 12,5 » valait 12).
- **Graphiques de performance** : séries alignées par DATE (`alignSeriesByDate`), plus par indice.
- **`localStorage` bloqué** : le thème ne fige plus le démarrage.
`scripts/smoke-etat.test.js` : 10 tests (mutations vérifiées). Reste, sous le seuil : les courses de réponses (secteurs, Modifier puis Préparer, Fiche), à traiter avec un compteur de séquence pour les lectures et un bouton désactivé pendant les écritures. **Pas commité ni déployé.**

## Audit « routes » : mise à jour vérifiée, écritures protégées, isolation testée (21/10/2026)

Audit d'environ 5 500 lignes (couche de données locale, opérations et alertes, couche D1, modules cloud sans équivalent local) par quatre sous-agents. Un seul constat à 80, plus une dizaine d'observations; corrigés :
- **Mise à jour en un clic** : URL en https et empreinte sha256 obligatoires (`urlSure`, `verifierEmpreinte`), comparée avant toute écriture. **À FAIRE à la prochaine publication** : `npm run package` affiche l'empreinte; la mettre dans `PUBLISHED_SHA256` (`telemetry-worker/wrangler.jsonc`) et redéployer le Worker de télémétrie, sinon « Mettre à jour » refuse (le champ `sha256` du manifeste manque). Pas encore redéployé.
- **`originGuard`** : le serveur local refuse (403) une écriture venue d'une autre origine (`server/http-guard.js`).
- **`js/trade-rules.js`** : prix > 0, taille entière > 0, dates réelles, stop différent du prix d'entrée, rachat avec prime `>= 0` réelle (`null` valait 0 $); local et cloud.
- **Écritures atomiques** : clôture d'une jambe (transaction en local, `AND statut = 'ouvert'` et compensation en cloud), lien de connexion consommé une seule fois, watchlist re-semée seulement à la première ouverture (marqueur `watchlistSeeded`).
- **Cloud** : en-têtes de sécurité (`public/_headers` et middleware : nosniff, X-Frame-Options DENY, HSTS), `onError` sans le détail D1, une jambe ne se rattache qu'à un cycle du même compte.
- **Tests** : `server/cloud-isolation.test.js` (8 tests à deux comptes, mutations vérifiées), `trade-rules.test.js`, `update.test.js`, `http-guard.test.js`. 444 tests.
**Pas corrigé** (features à créer) : limite de débit sur la connexion et le lien par courriel, jetons de session et de lien stockés en clair, plafond de coût de l'analyste IA contournable, scan du Radar relancé toutes les 5 min en cas d'échec, alerte d'échéance jamais déclenchée à la 1re observation, regex de ticker des listes/watchlist, validation des préférences. **Pas commité ni déployé.**

## Audit « onglets locaux » : pannes qui s'affichaient comme des succès (21/10/2026)

Audit d'environ 2 640 lignes (Radar, alertes de listes, backtest, modèle maison, analyste IA, carte FCF, TradingView local). Le backtest (pas d'anticipation) et le modèle (pas de fuite) sont sains. Corrigé :
- **Radar** : un scan en panne s'affichait « terminé » (`scanned > 0` toujours vrai); il passe en `erreur` si aucun titre n'est lu et l'écran montre le nombre d'erreurs. Fondamentaux en échec = contrats `resultats_inconnus` (écartés). `runDealScan` a un `try/finally` (plus de scan bloqué). `limit` et `maxPerSector` invalides retombent sur la valeur par défaut. Changer de scan pendant un scan est refusé.
- **Analyste IA (local et cloud)** : le coût s'écrit avant la validation (une réponse rejetée comptait 0 $), estimation prudente si `usage` manque, plan inclus dans la clé de cache, la carte n'est plus écrasée par la réponse d'un autre titre et affiche le symbole.
- **ATR** : une barre Yahoo sans haut/bas est écartée (une seule suffisait à fausser le stop et le R du backtest). Clé de cache du backtest : frais et glissement séparés. Alertes de listes : erreurs affichées.
`scripts/smoke-etat.test.js` : 12 tests. **Pas corrigé** : `premiumRowsFromScan` propose des contrats qui enjambent les résultats (à décider), `splitByDate` du jeu de données sans purge par date de sortie (aucun appelant), jetons TradingView locaux en mode 644, injection de prompt dans les champs libres de l'IA, critère « conversion » du FCF exclu pour une entreprise déficitaire. **Pas commité ni déployé.**

## Alertes de positions : contrôle de l'utilisateur dans les Réglages (21/10/2026, local)

Les alertes de positions (#379) peuvent maintenant être pilotées par l'utilisateur : **Réglages → TradingView → « 3 · Alertes de positions »** (les sections suivantes passent à 4, 5 et 6). Une case principale (tout couper : rien n'est évalué, aucun appel Yahoo), une case par situation (échéance proche, seuil de prise de profit, stop touché) et une case « envoyer aussi un courriel » (décochée : l'alerte reste dans la boîte de Screener Prime). **Tout est activé par défaut**, comme avant. Le seuil de profit s'affiche en lecture seule : il vient des paramètres de la Roue (« Prise de profit — min », 50 % par défaut).
- Stockage : clé `app_position_alerts` (JSON) de la table `preferences`; `server/app-settings.js` (`normalizePositionAlerts`, `kindsReenabled`, purs et testés).
- **Réactiver une situation remet son état à zéro** (`resetPositionAlertState`) : la prochaine observation redevient la référence, sinon un vieil état mémorisé déclencherait une alerte au réveil.
- Une situation coupée n'appelle pas Yahoo : pas de chaîne d'options si « profit » est décoché.
- Les deux jambes MSFT put 475 de la base locale (ids 1 et 2) sont des données du compte de test de JP, pas un défaut du code.
- Version en ligne : feature bilbao **#463** (déclencheur planifié, drapeau par compte, tables D1, budget de sous-requêtes). Tests : `app-settings.test.js` (3 de plus) et un test de fumée des Réglages. **Pas commité ni déployé; le service local doit être relancé.**

## Audit « routes locales » : `server/index.js` lu handler par handler (21/10/2026)

Deux sous-agents (lignes 1-720 et 720-fin, plus `options.js` et `symbol-search.js`) : aucun constat à 80, onze observations entre 50 et 75, **toutes corrigées**. Le serveur local est maintenant couvert en entier (la couverture globale passe à environ 64 % : `server/index.js` comptait déjà dans l'audit de parité des routes, un premier chiffre de 67 % était surestimé).
- **Cache** : changer les périodes vide tous les screenings (watchlist, élargi, MAG7, listes) en local et pour le compte concerné en cloud; changer la source de données ne détruit plus le dernier balayage S&P 500.
- **Réglages** : un patch invalide n'écrit rien (`planAppSettingsWrites` + transaction); le champ `key` de la clé Resend est obligatoire (un PUT sans corps la supprimait).
- **Écritures** : un PUT partiel ne peut pas vider un champ obligatoire (ticker, date, compte, prix, stop; local et D1); supprimer une jambe détache celles qui roulaient vers elle; modifier un cycle inexistant = 404; mise à jour en un clic verrouillée.
- **Démarrage** : une instance secondaire ne démarre plus les planificateurs; garde-fous `unhandledRejection` / `uncaughtException` / SIGTERM; JSON illisible = 400 (413 si trop gros); lectures `/api` d'un autre site refusées (`Sec-Fetch-Site`).
- **Petits durcissements** : `PATCH list-alerts` exige un booléen, tickers de watchlist/listes de type texte, `?ticker=a&ticker=b` = 400.
Tests : 454 (`trade-rules`, `app-settings`, `http-guard`, `cloud-isolation`). **Pas corrigé** : webhook TradingView sans secret en local (écoute locale seulement), `index.js` de 1 420 lignes sans `createApp()` (aucune route testable sans lancer l'app), regex de ticker des listes encore différente de `isValidTicker` (#462). **Pas commité ni déployé.**

## Audit « pages et périphérie » : le paquet distribué, la télémétrie, le lanceur (22/10/2026)

Quatre sous-agents (≈ 8 000 lignes : `index.html` local et en ligne, CSS, Worker de télémétrie, lanceur, installeurs et scripts, formules du Labo, glossaire, modules du navigateur restants). **Les pages elles-mêmes sont propres** (aucun constat). Couverture globale ≈ 88 %. Corrigé :
- **Paquet distribué** (`scripts/package-zip.sh`, constat 95) : `zip -r .` aurait embarqué `.env` (clé Resend, mot de passe admin du Worker cloud), des copies de la base du journal et les données du club. Maintenant `git ls-files` + garde-fou qui supprime l'archive si elle contient un secret; le zip de septembre était sain (défaut dormant). **Relancer `npm run package` avant la prochaine publication** : il affiche aussi l'empreinte à mettre dans `PUBLISHED_SHA256`.
- **Worker de télémétrie** (jeton d'ingestion public) : corps 16 Ko, `who` 40 caractères sans balise, `ua` 256, charge utile 4 Ko, 300 événements par minute et par IP, rétention 365 jours, `LIMIT` sur les requêtes, Basic Auth à temps constant, formules neutralisées dans le CSV, `/delete` en JSON et sans origine étrangère, fenêtres de dates en ISO (l'ancienne dépassait de 24 h). 7 tests (il n'en avait aucun).
- **Télémétrie client** : le capital et le risque de base ne sont plus envoyés. **Les anciennes lignes déjà en base ne sont pas supprimées** : à faire dans l'onglet Télémétrie de bilbao (le résumé ne montre que les 200 dernières lignes, aucune ne correspondait).
- **Lanceur** (`launcher/guard.js`) : garde d'hôte, de site d'origine et de type de contenu avant toute route, corps borné, « relancer » vise le port réel de l'app.
- **Concepts** : l'assainisseur HTML parcourt un nœud avant de le déplier. **Labo** : symbole et secteur échappés (`laboDyn`), formule du profit maximal du PMCC corrigée. **Glossaire** : seuils de Setup (≥ 2) et Contexte (≥ 1), moyennes 9/21/50, VWAP sur 24 h, seuil de résultats du Screener (7 j). **Divers** : rayon CSS de la bulle du glossaire, texte « JP, Louis, Guillaume » obsolète, `role="alert"` sur les erreurs de connexion, plist du service échappé en XML.
- `strategies-labo.js` et `concepts-content.js` rejoignent les copies synchronisées (ils dérivaient à la main).
Tests : 465 (`telemetry-worker`, `launcher-guard`, `smoke-etat`). **Pas corrigé** : `pip install tradingview-mcp-server` sans version (installeur facultatif), `doctor.mjs` qui bloque le démarrage hors ligne, jeton webhook TradingView en URL (contrainte de TradingView), `pkill` du service sur le port 4700 en dur. **Pas commité ni déployé au moment d'écrire.**

## `npm audit` sur les trois dossiers : 0 alerte partout (22/10/2026)

Racine 13 -> 0, `cloud/` 15 -> 0, `telemetry-worker/` 9 -> 0. Aucune alerte n'était atteignable dans l'usage normal (pas de `trust proxy`, le SDK MCP ne sert qu'au sidecar facultatif, `wrangler` et `miniflare` sont des outils de développement), mais le verrou part chez les testeurs avec le paquet. **Piège de méthode** : `npm audit fix` n'a d'abord mis à jour que `package-lock.json` et laissé `node_modules` sur les anciennes versions (`npm ls` annonçait les nouvelles); lire la version dans `node_modules/<paquet>/package.json` et faire `mv node_modules <ailleurs> && npm ci --cache <dossier-écrivable>` (le cache npm de la machine est en `EACCES`). Wrangler 3 -> 4.152 pour le Worker de télémétrie; Worker castellana promu après un essai de JP sur une version de test. Reste : feature bilbao **#464** (anciennes lignes de télémétrie à supprimer, empreinte de mise à jour à publier, essai du nouveau paquet, test avec un vrai compte).

