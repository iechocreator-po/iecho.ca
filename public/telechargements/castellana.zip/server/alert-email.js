// Envoi de courriel pour les alertes (Resend, API REST en fetch — zéro
// dépendance). La clé vit dans un `.env` LOCAL à la racine (jamais commité) ou
// dans la variable d'environnement RESEND_API_KEY. Sans clé, les alertes restent
// dans la boîte de l'app et on le dit — jamais un envoi silencieusement perdu.
//
// ⚠️ Clé Resend : portée « Sending access » seulement (le code n'a besoin que
// d'envoyer). Ne jamais la coller dans un chat ni la committer.

import { readFileSync, existsSync, writeFileSync, chmodSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const ENV_PATH = fileURLToPath(new URL('../.env', import.meta.url));

// Lecture minimale de KEY=VALUE (commentaires # et guillemets tolérés).
function readDotEnv() {
  if (!existsSync(ENV_PATH)) return {};
  const out = {};
  for (const line of readFileSync(ENV_PATH, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !line.trim().startsWith('#')) out[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
  return out;
}

// Valeur d'une variable du .env local (ou de l'environnement) — jamais renvoyée au navigateur.
export function envValue(name) {
  return process.env[name] || readDotEnv()[name] || null;
}

export function emailConfig() {
  const env = readDotEnv();
  return {
    apiKey: process.env.RESEND_API_KEY || env.RESEND_API_KEY || null,
    from: process.env.RESEND_FROM || env.RESEND_FROM || 'castellana@iecho.ca',
  };
}

// Destinataire des alertes de POSITIONS (#379) : ALERT_EMAIL dans le .env local — jamais
// dans settings.json, qui est versionné. null si absent : la boîte de l'app suffit alors.
export function alertRecipient() {
  const env = readDotEnv();
  const v = process.env.ALERT_EMAIL || env.ALERT_EMAIL || null;
  return v && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? v : null;
}

export function emailAvailable() {
  return !!emailConfig().apiKey;
}

export async function sendAlertEmail(to, { subject, text }) {
  const { apiKey, from } = emailConfig();
  if (!apiKey) throw Object.assign(new Error('Clé Resend absente (RESEND_API_KEY dans .env).'), { code: 'NO_KEY' });
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: `castellana <${from}>`, to: [to], subject, text }),
    signal: AbortSignal.timeout(15000),
  });
  if (!res.ok) throw new Error(`Resend a refusé l'envoi (HTTP ${res.status}).`);
}

// Clé Resend saisie depuis Réglages → TradingView (R-C2, 17/10/2026) : écrite dans le .env LOCAL
// (gitignoré, droits 600), jamais en base ni renvoyée au navigateur. Les autres lignes du .env sont
// conservées telles quelles. key = null retire la ligne. Une variable d'environnement du processus
// (process.env.RESEND_API_KEY) reste prioritaire : on le signale plutôt que de prétendre l'avoir changée.
export const RESEND_KEY_RE = /^re_[A-Za-z0-9_-]{10,200}$/;
export function setResendKey(key) {
  if (key !== null) {
    key = String(key ?? '').trim();
    if (!RESEND_KEY_RE.test(key)) throw new Error('Clé Resend invalide : elle commence par « re_ ».');
  }
  const lines = existsSync(ENV_PATH) ? readFileSync(ENV_PATH, 'utf8').split('\n') : [];
  const kept = lines.filter((l) => !/^\s*RESEND_API_KEY\s*=/.test(l));
  while (kept.length && kept[kept.length - 1].trim() === '') kept.pop();
  if (key) kept.push(`RESEND_API_KEY=${key}`);
  writeFileSync(ENV_PATH, kept.length ? kept.join('\n') + '\n' : '', { mode: 0o600 });
  try { chmodSync(ENV_PATH, 0o600); } catch { /* best-effort */ }
  return { emailAvailable: emailAvailable(), fromProcessEnv: !!process.env.RESEND_API_KEY };
}

// Origine de la clé, pour l'écran : 'process' (variable d'environnement), 'dotenv', ou null.
export function resendKeySource() {
  if (process.env.RESEND_API_KEY) return 'process';
  return readDotEnv().RESEND_API_KEY ? 'dotenv' : null;
}
