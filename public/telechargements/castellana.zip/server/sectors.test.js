import { test } from 'node:test';
import assert from 'node:assert/strict';
import { resolveMarketTicker } from './sectors.js';

test('resolveMarketTicker — mode usd retourne toujours le ticker US, jamais un repli', () => {
  const def = { usd: 'VXUS', cad: 'XEF.TO' };
  assert.deepEqual(resolveMarketTicker(def, 'usd'), { ticker: 'VXUS', usedFallback: false });
});

test('resolveMarketTicker — mode cad avec équivalent TSX retourne le ticker CAD', () => {
  const def = { usd: 'VXUS', cad: 'XEF.TO' };
  assert.deepEqual(resolveMarketTicker(def, 'cad'), { ticker: 'XEF.TO', usedFallback: false });
});

test('resolveMarketTicker — mode cad SANS équivalent TSX (DXY/Chine) replie sur le ticker US avec usedFallback', () => {
  const def = { usd: 'DX-Y.NYB', cad: null };
  assert.deepEqual(resolveMarketTicker(def, 'cad'), { ticker: 'DX-Y.NYB', usedFallback: true });
});

test('resolveMarketTicker — mode usd sans équivalent TSX ne déclenche jamais usedFallback', () => {
  const def = { usd: 'FXI', cad: null };
  assert.deepEqual(resolveMarketTicker(def, 'usd'), { ticker: 'FXI', usedFallback: false });
});
