import { db } from './db.js';
import { isValidTicker, TICKER_ERROR } from './ticker-format.js';
import { tradeNumberErrors } from './trade-rules.js';

// Colonnes éditables du journal — schéma complet dans db.js, section 7 du
// design doc. id/date_creation sont gérés par SQLite, jamais dans le body.
// Exporté pour l'export CSV (server/index.js, GET /api/trades.csv).
export const COLUMNS = [
  'date_entree', 'date_sortie', 'compte', 'ticker', 'prix_entree', 'prix_sortie',
  'taille_position', 'stop_initial', 'vix_a_entree', 'rsi_a_entree', 'obv_a_entree',
  'correlation_flag', 'checklist_complete', 'r_realise', 'resultat',
  // Raisonnement du screening au moment de l'entrée (11/9/2026) — pour
  // pouvoir mesurer plus tard si le score prédit quoi que ce soit.
  'setup_score', 'contexte_score', 'alignement_a_entree', 'signal_age_a_entree',
  // Traçabilité (22/9/2026) : ligne créée automatiquement par l'assignation
  // d'un put d'un cycle d'options — voir server/option-trades.js.
  'option_cycle_id',
  // Journal de la Roue (#433) : commissions d'achat et de vente des actions, provenance.
  'commission_entree', 'commission_sortie', 'source',
  // IA (#398) : dernière analyse de contexte du même symbole, jointe à la création.
  'ai_analysis_id',
];

// Une analyse n'est jointe que si elle a été faite pour CE symbole dans les derniers jours :
// une analyse vieille de trois semaines n'a pas informé cette entrée.
export const AI_LINK_WINDOW_DAYS = 3;

export function findRecentAnalysisId(ticker, { days = AI_LINK_WINDOW_DAYS } = {}) {
  try {
    const row = db.prepare("SELECT id FROM ai_analyses WHERE ticker = ? AND result_json != '' AND created_at >= datetime('now', ?) ORDER BY id DESC LIMIT 1")
      .get(String(ticker).toUpperCase(), `-${days} days`);
    return row ? row.id : null;
  } catch { return null; } // table absente (IA jamais utilisée) : pas de lien, pas d'erreur
}

const REQUIRED_ON_CREATE = ['date_entree', 'compte', 'ticker', 'prix_entree', 'taille_position', 'stop_initial'];

const COMPTES = ['RRSP', 'margin', 'corporatif'];
const OBV_VALUES = ['accumulation', 'neutre', 'distribution'];
const RESULTATS = ['gagnant', 'perdant'];
// Pas de contrainte CHECK en base sur cette colonne (elle est ajoutée par
// ALTER TABLE, qui ne peut pas en poser) — la validation se fait donc ici,
// comme pour les autres énumérations.
const ALIGNEMENTS = ['haussier', 'neutre', 'baissier'];

// Validation manuelle avant insert/update plutôt que de laisser remonter les
// erreurs CHECK brutes de SQLite — messages clairs pour l'appelant de l'API.
export function validateTrade(data, { partial = false } = {}) {
  const errors = [];
  if (!partial) {
    for (const field of REQUIRED_ON_CREATE) {
      if (data[field] === undefined || data[field] === null || data[field] === '') {
        errors.push(`${field} est requis`);
      }
    }
  }
  if (data.compte != null && !COMPTES.includes(data.compte)) {
    errors.push(`compte doit être l'un de : ${COMPTES.join(', ')}`);
  }
  if (data.ticker != null && data.ticker !== '' && !isValidTicker(String(data.ticker))) errors.push(TICKER_ERROR);
  if (data.obv_a_entree != null && !OBV_VALUES.includes(data.obv_a_entree)) {
    errors.push(`obv_a_entree doit être l'un de : ${OBV_VALUES.join(', ')}`);
  }
  if (data.resultat != null && !RESULTATS.includes(data.resultat)) {
    errors.push(`resultat doit être l'un de : ${RESULTATS.join(', ')}`);
  }
  if (data.correlation_flag !== undefined && ![0, 1].includes(Number(data.correlation_flag))) {
    errors.push('correlation_flag doit être 0 ou 1');
  }
  if (data.checklist_complete !== undefined && ![0, 1].includes(Number(data.checklist_complete))) {
    errors.push('checklist_complete doit être 0 ou 1');
  }
  if (data.alignement_a_entree != null && !ALIGNEMENTS.includes(data.alignement_a_entree)) {
    errors.push(`alignement_a_entree doit être l'un de : ${ALIGNEMENTS.join(', ')}`);
  }
  for (const f of ['commission_entree', 'commission_sortie']) {
    if (data[f] != null && data[f] !== '' && !(Number(data[f]) >= 0)) errors.push(`${f} doit être ≥ 0`);
  }
  if (data.source != null && !['saisie', 'import_sheets'].includes(data.source)) errors.push('source doit être saisie ou import_sheets');
  errors.push(...tradeNumberErrors(data)); // nombres et dates (audit routes, 21/10/2026)
  // Une modification partielle ne peut pas VIDER un champ obligatoire (audit routes locales, 21/10/2026) : {ticker:'', date_entree:null}
  // était accepté et écrit tel quel (ticker vide envoyé ensuite aux cotations).
  if (partial) {
    for (const field of REQUIRED_ON_CREATE) {
      if (field in data && (data[field] === null || data[field] === '' || (typeof data[field] === 'string' && data[field].trim() === ''))) errors.push(`${field} ne peut pas être vide`);
    }
  }
  return errors;
}

// Ticker normalisé en majuscules à l'écriture — cohérent avec le filtre de
// listTrades() et le reste de l'app (ex. GET /api/market-data/:ticker).
function normalize(data) {
  return data.ticker !== undefined ? { ...data, ticker: String(data.ticker).trim().toUpperCase() } : data;
}

export function createTrade(rawData) {
  const data = normalize(rawData);
  if (data.ai_analysis_id === undefined && data.ticker) {
    const id = findRecentAnalysisId(data.ticker);
    if (id != null) data.ai_analysis_id = id;
  }
  const cols = COLUMNS.filter((c) => data[c] !== undefined);
  const stmt = db.prepare(`INSERT INTO trades (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`);
  const info = stmt.run(...cols.map((c) => data[c]));
  return getTrade(info.lastInsertRowid);
}

export function listTrades({ compte, ticker, open } = {}) {
  let sql = 'SELECT * FROM trades WHERE 1=1';
  const params = [];
  if (compte) { sql += ' AND compte = ?'; params.push(compte); }
  if (ticker) { sql += ' AND ticker = ?'; params.push(ticker.toUpperCase()); }
  if (open === true) sql += ' AND date_sortie IS NULL';
  if (open === false) sql += ' AND date_sortie IS NOT NULL';
  sql += ' ORDER BY date_entree DESC, id DESC';
  return db.prepare(sql).all(...params);
}

export function getTrade(id) {
  return db.prepare('SELECT * FROM trades WHERE id = ?').get(id);
}

export function updateTrade(id, rawData) {
  const data = normalize(rawData);
  const cols = COLUMNS.filter((c) => data[c] !== undefined);
  if (cols.length > 0) {
    const stmt = db.prepare(`UPDATE trades SET ${cols.map((c) => `${c} = ?`).join(', ')} WHERE id = ?`);
    stmt.run(...cols.map((c) => data[c]), id);
  }
  return getTrade(id);
}

export function deleteTrade(id) {
  return db.prepare('DELETE FROM trades WHERE id = ?').run(id).changes > 0;
}
