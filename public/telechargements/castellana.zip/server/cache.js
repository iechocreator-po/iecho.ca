// Cache persistant, stocké dans la base SQLite déjà présente (server/db.js).
//
// Constat F8 de l'audit du 7/9/2026 : les deux seuls caches de l'app
// (screening et top-secteur) vivaient dans des variables de processus et
// disparaissaient à chaque redémarrage — c'est-à-dire, en pratique, à chaque
// fois qu'on réparait une panne. Les routes /api/market-data, /api/quote,
// /api/labo et /api/sectors n'avaient aucun cache du tout : ouvrir la page
// déclenchait à elle seule 45 à 66 requêtes.
//
// ⚠️ CORRECTION AU PLAN INITIAL, à ne pas « rétablir » par inadvertance.
// Le plan prévoyait des durées longues pour les données réputées stables :
// 12 h pour un historique quotidien, 24 h pour un bêta ou un flottant. C'est
// faux ici, pour une raison qui n'apparaît qu'en regardant la forme réelle
// des réponses :
//   — la DERNIÈRE barre d'un historique quotidien est la barre du JOUR EN
//     COURS, encore en train de bouger. La mettre en cache 12 h fige le prix,
//     l'ATR et le volume du jour pendant toute la séance ;
//   — `quoteSummary` renvoie dans le MÊME objet les champs trimestriels
//     (bêta, flottant, secteur) et des champs intrajournaliers (prix, volume).
// Servir un prix figé à un outil de trading est bien pire que d'être lent.
// Les durées ci-dessous sont donc courtes partout où la réponse contient
// ne serait-ce qu'un champ intrajournalier. Séparer les deux natures
// coûterait un appel réseau de plus par titre, pour un gain nul.

import { db } from './db.js';

db.exec(`
  CREATE TABLE IF NOT EXISTS cache (
    key TEXT PRIMARY KEY,
    payload TEXT NOT NULL,
    fetched_at INTEGER NOT NULL,
    ttl_seconds INTEGER NOT NULL
  );
`);

// Durées de vie, en secondes. `SLOW` n'est utilisé que pour des réponses
// SANS aucun champ intrajournalier (voir l'avertissement ci-dessus).
export const TTL = {
  QUOTE: 60,          // cotations — la donnée la plus volatile de l'app
  HISTORY: 15 * 60,   // historique quotidien : la dernière barre est celle du jour
  FUNDAMENTALS: 15 * 60, // mêlé prix/volume et bêta/flottant — cadencé sur le plus rapide
  SECTORS: 15 * 60,
  SCREENING: 20 * 60,
  SLOW: 24 * 3600,
};

const selectStmt = db.prepare('SELECT payload, fetched_at, ttl_seconds FROM cache WHERE key = ?');
const upsertStmt = db.prepare(`
  INSERT INTO cache (key, payload, fetched_at, ttl_seconds) VALUES (?, ?, ?, ?)
  ON CONFLICT(key) DO UPDATE SET payload = excluded.payload, fetched_at = excluded.fetched_at, ttl_seconds = excluded.ttl_seconds
`);
const deleteStmt = db.prepare('DELETE FROM cache WHERE key = ?');

export function readCache(key) {
  const row = selectStmt.get(key);
  if (!row) return { hit: false, value: null };
  const ageSeconds = (Date.now() - row.fetched_at) / 1000;
  // `>=` et non `>` : une entrée pile à son TTL est expirée. Avec `>`, un
  // TTL de 0 (« ne jamais mettre en cache ») servait quand même l'entrée
  // tant qu'on la relisait dans la même milliseconde — trouvé par un test,
  // pas à la relecture.
  if (ageSeconds >= row.ttl_seconds) return { hit: false, value: null };
  try {
    return { hit: true, value: JSON.parse(row.payload), ageSeconds };
  } catch {
    // Entrée corrompue (interruption pendant l'écriture, changement de
    // format) : on la jette plutôt que de faire échouer l'appelant.
    deleteStmt.run(key);
    return { hit: false, value: null };
  }
}

// Lecture SANS contrôle de TTL, avec l'âge de l'entrée. Sert aux cas où une
// valeur périmée reste utile : l'export CSV du dernier screening et le calcul
// du « P/E industrie » d'un ticker hors watchlist doivent pouvoir s'appuyer
// sur le dernier screening connu, même vieux, plutôt que de répondre « aucun
// screening » ou de relancer 21 appels à l'insu de l'utilisateur.
export function readCacheRaw(key) {
  const row = selectStmt.get(key);
  if (!row) return { found: false, value: null, ageSeconds: null };
  try {
    return { found: true, value: JSON.parse(row.payload), ageSeconds: (Date.now() - row.fetched_at) / 1000 };
  } catch {
    deleteStmt.run(key);
    return { found: false, value: null, ageSeconds: null };
  }
}

export function writeCache(key, value, ttlSeconds) {
  upsertStmt.run(key, JSON.stringify(value), Date.now(), ttlSeconds);
}

// Enveloppe mémoïsante. `revive` permet de reconstruire ce que JSON ne sait
// pas porter (les `Date` d'un historique, typiquement) — sans lui, une valeur
// relue du cache n'aurait pas la même forme qu'une valeur fraîche, et le bug
// ne se verrait qu'au deuxième appel.
//
// Une erreur n'est JAMAIS mise en cache : un échec réseau ne doit pas se
// transformer en trou de données persistant.
export async function cached(key, ttlSeconds, fn, { revive = null, force = false } = {}) {
  if (!force) {
    const { hit, value } = readCache(key);
    if (hit) return revive ? revive(value) : value;
  }
  const fresh = await fn();
  writeCache(key, fresh, ttlSeconds);
  return fresh;
}

// Purge les entrées expirées. Appelée au démarrage : sans elle, la table
// grossit indéfiniment avec les tickers consultés une seule fois.
export function purgeExpiredCache() {
  const { changes } = db
    .prepare('DELETE FROM cache WHERE (? - fetched_at) / 1000 >= ttl_seconds')
    .run(Date.now());
  return changes;
}
