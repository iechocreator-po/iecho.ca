import test from 'node:test';
import assert from 'node:assert/strict';
import { fitLogistic, predictProba, auc, calibration, fitPreprocessor, walkForward, bootstrapMeanDiff, brier } from './ml-logistic.js';

function lcg(seed) { let s = seed; return () => { s = (s * 1664525 + 1013904223) % 4294967296; return s / 4294967296; }; }
const gauss = (r) => Math.sqrt(-2 * Math.log(r() || 1e-9)) * Math.cos(2 * Math.PI * r());

test('fitLogistic retrouve les coefficients d\'un modèle connu', () => {
  const r = lcg(1);
  const X = [], y = [];
  for (let i = 0; i < 6000; i++) {
    const x = [gauss(r), gauss(r), gauss(r)];
    const p = 1 / (1 + Math.exp(-(-0.5 + 1.2 * x[0] - 0.8 * x[1])));
    X.push(x); y.push(r() < p ? 1 : 0);
  }
  const m = fitLogistic(X, y, { lambda: 0.1 });
  assert.ok(Math.abs(m.intercept + 0.5) < 0.15);
  assert.ok(Math.abs(m.coefs[0] - 1.2) < 0.15);
  assert.ok(Math.abs(m.coefs[1] + 0.8) < 0.15);
  assert.ok(Math.abs(m.coefs[2]) < 0.12, 'variable sans effet ≈ 0');
});

test('auc : parfait = 1, inversé = 0, aléatoire ≈ 0,5, une seule classe = null', () => {
  assert.equal(auc([0.1, 0.2, 0.8, 0.9], [0, 0, 1, 1]), 1);
  assert.equal(auc([0.9, 0.8, 0.2, 0.1], [0, 0, 1, 1]), 0);
  assert.equal(auc([0.5, 0.5, 0.5, 0.5], [0, 1, 0, 1]), 0.5);
  assert.equal(auc([0.1, 0.2], [1, 1]), null);
});

test('bruit pur : AUC hors échantillon ≈ 0,5 (le protocole ne fabrique pas de signal)', () => {
  const r = lcg(3);
  const rows = [];
  for (let i = 0; i < 4000; i++) {
    const year = 2021 + Math.floor(i / 800);
    const d = `${year}-0${1 + (i % 9)}-15`;
    rows.push({ signal_date: d, exit_date: `${year}-0${1 + (i % 9)}-25`, win_1r: r() < 0.2 ? 1 : 0, rsi: 100 * r(), atr_pct: 5 * r(), vix: 10 + 20 * r(), obv_trend: 'neutre' });
  }
  const folds = walkForward(rows, { testYears: [2023, 2024, 2025] });
  assert.equal(folds.length, 3);
  const p = folds.flatMap((f) => f.p), y = folds.flatMap((f) => f.test.map((t) => t.win_1r));
  assert.ok(Math.abs(auc(p, y) - 0.5) < 0.05);
});

test('walkForward : purge — aucune ligne d\'entraînement ne sort après le début du test', () => {
  const rows = [];
  for (let i = 0; i < 1500; i++) rows.push({ signal_date: `202${1 + (i % 4)}-06-01`, exit_date: `202${1 + (i % 4)}-12-20`, win_1r: i % 5 === 0 ? 1 : 0, rsi: i % 100, obv_trend: 'neutre' });
  // un trade signalé fin 2022 sort en 2023 : il ne doit PAS servir à entraîner le fold 2023
  rows.push({ signal_date: '2022-12-28', exit_date: '2023-02-10', win_1r: 1, rsi: 50, obv_trend: 'neutre' });
  const f = walkForward(rows, { testYears: [2023], minTrain: 10 })[0];
  assert.ok(f.trainN > 0);
  assert.equal(rows.filter((r) => r.exit_date < '2023-01-01').length, f.trainN);
});

test('prétraitement appris sur l\'entraînement : une valeur aberrante du test est bornée', () => {
  const train = Array.from({ length: 200 }, (_, i) => ({ rsi: 40 + (i % 20), obv_trend: 'neutre' }));
  const prep = fitPreprocessor(train);
  const v = prep.transform({ rsi: 1e9, obv_trend: 'neutre' })[0];
  assert.ok(Math.abs(v) < 5);
});

test('calibration et bootstrap', () => {
  const c = calibration([0.1, 0.1, 0.9, 0.9], [0, 0, 1, 1], 2);
  assert.equal(c.length, 2); assert.equal(c[0].observed, 0); assert.equal(c[1].observed, 1);
  const b = bootstrapMeanDiff([1, 1, 1, 1], [0, 0, 0, 0], { n: 200 });
  assert.equal(b.mean, 1); assert.ok(b.lo >= 0.99);
  assert.ok(brier([0, 1], [0, 1]) === 0);
});
