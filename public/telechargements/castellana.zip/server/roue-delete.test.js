import { test } from 'node:test';
import assert from 'node:assert/strict';
import { optRoueDeletionPlan } from './options-analytics.js';

const cycles = [{ id: 1 }, { id: 2 }];
const legs = [
  { id: 10, cycle_id: 1, roule_vers_id: 11 },
  { id: 11, cycle_id: 1, roule_vers_id: null },
  { id: 20, cycle_id: 2, roule_vers_id: null },
];
const stock = [{ id: 100, option_cycle_id: 1 }, { id: 200, option_cycle_id: 2 }];
const flows = [{ id: 1000, cycle_id: 1 }, { id: 2000, cycle_id: null }, { id: 3000, cycle_id: 2 }];

test('supprimer une position qui laisse son cycle non vide : le cycle reste', () => {
  const p = optRoueDeletionPlan({ legIds: [11], legs, cycles, stock, flows });
  assert.deepEqual(p.legIds, [11]);
  assert.deepEqual(p.cycleIds, []);
  assert.deepEqual(p.stockIds, []);
  assert.deepEqual(p.flowIds, []);
  assert.deepEqual(p.rollRefs, [10]); // le lien de roulement de #10 vers #11 est remis à vide
});

test('supprimer toutes les positions d\'un cycle : le cycle, ses actions et ses mouvements partent', () => {
  const p = optRoueDeletionPlan({ legIds: [20], legs, cycles, stock, flows });
  assert.deepEqual(p.cycleIds, [2]);
  assert.deepEqual(p.stockIds, [200]);
  assert.deepEqual(p.flowIds, [3000]);
});

test('mouvements seuls, identifiants inconnus ignorés', () => {
  const p = optRoueDeletionPlan({ flowIds: [2000, 9999], legIds: [999], legs, cycles, stock, flows });
  assert.deepEqual(p.flowIds, [2000]);
  assert.deepEqual(p.legIds, []);
  assert.deepEqual(p.cycleIds, []);
});
