// Backtest du signal d'alignement (feature bilbao #375, 30/9/2026).
//
// Répond à « ce signal a-t-il marché les fois précédentes ? » en REJOUANT la
// règle du design doc sur l'historique Yahoo :
//   - ENTRÉE au premier alignement haussier (close > SMA rapide > moyenne > lente,
//     la veille non aligné), à l'OUVERTURE de la séance suivante — jamais à la
//     clôture du signal (ce serait regarder l'avenir) ;
//   - STOP = entrée − multiplicateur × ATR(14) mesuré à la barre du signal ;
//   - SORTIE : stop touché (contrôlé AVANT tout, cas pessimiste ; ouverture en
//     gap sous le stop = sortie à l'ouverture) ou clôture sous la SMA moyenne.
//   - Une seule position à la fois par titre, pas de renforcement.
//
// ⚠️ C'EST UNE SIMULATION, pas une promesse : aucun frais, aucun glissement,
// aucun impôt, exécution parfaite aux prix supposés. Et un biais du survivant
// réel : les listes testées (watchlist, MAG7, univers élargi) sont celles
// d'AUJOURD'HUI — des titres qui ont survécu et souvent monté. Les résultats
// sont donc plutôt trop beaux ; l'interface le dit.

import { fetchDailyHistory, computeSMA, computeATR, computeAlignmentSeries } from './indicators.js';
import { getPreferences } from './preferences.js';
import { universeTickers, isValidUniverse } from './screening.js';
import { SECTOR_TOP_CANDIDATES } from './sectors.js';
import { cached } from './cache.js';
import { mapWithConcurrency } from './fetch-retry.js';

export const MIN_TRADES_FOR_CONCLUSION = 30;

/**
 * Rejoue le signal sur les barres d'UN titre. Fonction PURE.
 * @param bars   [{ date, open, high, low, close }] par ordre chronologique
 * @returns { trades: [...], open: trade|null }
 */
export function simulateSignal(bars, { fast = 9, medium = 21, slow = 50, atrPeriod = 14, atrMult = 1.5, costPct = 0, regimeOk = null } = {}) {
  // costPct : frais + glissement, en % du prix, PAR CÔTÉ (entrée et sortie) — l'entrée est payée
  //   plus cher et la sortie encaissée moins cher ; le risque de référence du R reste le risque
  //   PLANIFIÉ (entrée − stop), pour que le R net se compare au R brut.
  // regimeOk : fonction (date) → true/false/null, évaluée à la barre du SIGNAL (connue à sa
  //   clôture, l'entrée n'a lieu qu'à l'ouverture suivante : aucun regard vers l'avenir).
  //   Régime non vrai (faux ou inconnu) = signal ignoré.
  const c = Math.max(0, costPct) / 100;
  const closes = bars.map((b) => b.close);
  const align = computeAlignmentSeries(closes, { fast, medium, slow });
  const smaMedium = computeSMA(closes, medium);
  const atr = computeATR(bars, atrPeriod);
  const trades = [];
  let open = null;
  let i = 1;
  while (i < bars.length - 1) {
    const isSignal = align[i] === 'haussier' && align[i - 1] != null && align[i - 1] !== 'haussier';
    if (!isSignal || atr[i] == null || !(atr[i] > 0)) { i += 1; continue; }
    if (regimeOk && regimeOk(bars[i].date) !== true) { i += 1; continue; }

    const entryIdx = i + 1;
    const entry = bars[entryIdx].open;
    if (!(entry > 0)) { i += 1; continue; }
    const stop = entry - atrMult * atr[i];
    const risk = entry - stop;
    // Un stop à zéro ou négatif rendrait le R absurde : signal ignoré, pas inventé.
    if (!(stop > 0) || !(risk > 0)) { i += 1; continue; }

    let exitIdx = null;
    let exitPrice = null;
    let reason = null;
    for (let j = entryIdx; j < bars.length; j += 1) {
      const b = bars[j];
      if (b.low != null && b.low <= stop) { exitIdx = j; exitPrice = b.open != null && b.open < stop ? b.open : stop; reason = 'stop'; break; }
      if (j > entryIdx && smaMedium[j] != null && b.close < smaMedium[j]) { exitIdx = j; exitPrice = b.close; reason = 'sma'; break; }
    }

    if (exitIdx == null) { // position encore ouverte à la fin de l'historique
      const last = bars[bars.length - 1];
      open = { entryDate: bars[entryIdx].date, entry, stop, mark: last.close, rOpen: (last.close * (1 - c) - entry * (1 + c)) / risk };
      break;
    }
    trades.push({
      signalIndex: i, entryDate: bars[entryIdx].date, exitDate: bars[exitIdx].date, entry, exit: exitPrice, stop,
      r: (exitPrice * (1 - c) - entry * (1 + c)) / risk, bars: exitIdx - entryIdx, reason,
    });
    i = exitIdx; // pas de nouveau signal tant que la position n'est pas sortie
  }
  return { trades, open };
}

/** Statistiques d'un ensemble de trades fermés. Fonction PURE. `n` est toujours rapporté. */
export function summarizeTrades(trades) {
  const n = trades.length;
  if (n === 0) return { n: 0, enough: false, winRate: null, avgR: null, medianR: null, totalR: null, profitFactor: null, maxDrawdownR: null, avgBars: null, stops: 0 };
  const rs = trades.map((t) => t.r);
  const wins = rs.filter((r) => r > 0);
  const losses = rs.filter((r) => r <= 0);
  const sum = (a) => a.reduce((x, y) => x + y, 0);
  const sorted = [...rs].sort((a, b) => a - b);
  const median = n % 2 ? sorted[(n - 1) / 2] : (sorted[n / 2 - 1] + sorted[n / 2]) / 2;
  // Drawdown en R sur la courbe cumulée, dans l'ordre des SORTIES.
  let cum = 0; let peak = 0; let dd = 0;
  for (const t of [...trades].sort((a, b) => new Date(a.exitDate) - new Date(b.exitDate))) {
    cum += t.r; peak = Math.max(peak, cum); dd = Math.max(dd, peak - cum);
  }
  return {
    n,
    enough: n >= MIN_TRADES_FOR_CONCLUSION,
    winRate: wins.length / n,
    avgR: sum(rs) / n,
    medianR: median,
    totalR: sum(rs),
    profitFactor: losses.length && sum(losses) < 0 ? sum(wins) / Math.abs(sum(losses)) : null,
    maxDrawdownR: dd,
    avgBars: sum(trades.map((t) => t.bars)) / n,
    stops: trades.filter((t) => t.reason === 'stop').length,
  };
}

const dayKey = (d) => new Date(d).toISOString().slice(0, 10);

/**
 * Régime de marché par date. Fonction PURE. Vrai quand le S&P 500 (SPY) clôture AU-DESSUS de sa SMA
 * de `smaPeriod` séances et, si `vixMax > 0`, quand le VIX clôture à `vixMax` ou moins.
 * Une date sans donnée (SPY/VIX absent, SMA pas encore calculable) renvoie null = inconnu.
 */
export function buildRegime(spyBars, vixBars, { smaPeriod = 200, vixMax = 0 } = {}) {
  const sma = computeSMA(spyBars.map((b) => b.close), smaPeriod);
  const spyOk = new Map();
  spyBars.forEach((b, i) => { if (sma[i] != null) spyOk.set(dayKey(b.date), b.close > sma[i]); });
  const vix = new Map((vixBars || []).map((b) => [dayKey(b.date), b.close]));
  return (date) => {
    const k = dayKey(date);
    if (!spyOk.has(k)) return null;
    if (vixMax > 0) { if (!vix.has(k)) return null; if (!(vix.get(k) <= vixMax)) return false; }
    return spyOk.get(k);
  };
}

const SECTOR_OF = (() => {
  const m = new Map();
  for (const [sector, tickers] of Object.entries(SECTOR_TOP_CANDIDATES)) for (const t of tickers) if (!m.has(t)) m.set(t, sector);
  return m;
})();

/** Orchestration : historique de chaque titre → simulation → agrégats globaux, par secteur et par titre. */
export async function runBacktest(universe = 'watchlist', { atrMult = 1.5, years = 5, feesPct = 0.05, slippagePct = 0.05, regime = false, regimeSma = 200, vixMax = 0 } = {}) {
  if (!isValidUniverse(universe)) throw Object.assign(new Error(`Univers invalide : ${universe}`), { status: 400 });
  const prefs = getPreferences();
  const costPct = feesPct + slippagePct;
  const key = `backtest:v2:${universe}:${prefs.smaFast}-${prefs.smaMedium}-${prefs.smaSlow}:${atrMult}:${years}:${feesPct}-${slippagePct}:${regime ? `${regimeSma}-${vixMax}` : 'off'}`;
  return cached(key, 3600, async () => {
    const tickers = universeTickers(universe);
    const lookbackDays = Math.round(years * 365) + 120; // marge pour la SMA la plus lente
    let regimeFn = null;
    if (regime) {
      const spy = await fetchDailyHistory('SPY', lookbackDays + regimeSma * 2);
      const vix = vixMax > 0 ? await fetchDailyHistory('^VIX', lookbackDays + 30) : [];
      regimeFn = buildRegime(spy, vix, { smaPeriod: regimeSma, vixMax });
    }
    const base = { fast: prefs.smaFast, medium: prefs.smaMedium, slow: prefs.smaSlow, atrMult };
    const results = await mapWithConcurrency(tickers, async (ticker) => {
      try {
        const bars = await fetchDailyHistory(ticker, lookbackDays);
        // Trois lectures du MÊME signal : brut (ni frais ni filtre), avec frais, avec frais + régime.
        const gross = simulateSignal(bars, base);
        const costed = simulateSignal(bars, { ...base, costPct });
        const filtered = regimeFn ? simulateSignal(bars, { ...base, costPct, regimeOk: regimeFn }) : costed;
        return { ticker, bars: bars.length, gross: gross.trades, costed: costed.trades, trades: filtered.trades, open: filtered.open, error: null };
      } catch (err) {
        return { ticker, gross: [], costed: [], trades: [], open: null, error: err.message };
      }
    }, { limit: 6 });

    const all = results.flatMap((r) => r.trades.map((t) => ({ ...t, ticker: r.ticker, sector: SECTOR_OF.get(r.ticker) ?? 'Autre' })));
    const bySector = new Map();
    for (const t of all) { if (!bySector.has(t.sector)) bySector.set(t.sector, []); bySector.get(t.sector).push(t); }
    const perTicker = results.filter((r) => !r.error).map((r) => ({ ticker: r.ticker, sector: SECTOR_OF.get(r.ticker) ?? 'Autre', ...summarizeTrades(r.trades), open: r.open }));

    return {
      generatedAt: new Date().toISOString(),
      universe, years, atrMult,
      realism: { feesPct, slippagePct, costPct, regime, regimeSma: regime ? regimeSma : null, vixMax: regime && vixMax > 0 ? vixMax : null },
      periods: { fast: prefs.smaFast, medium: prefs.smaMedium, slow: prefs.smaSlow },
      tickersTested: results.length,
      errors: results.filter((r) => r.error).map((r) => ({ ticker: r.ticker, error: r.error })),
      overall: summarizeTrades(all),
      comparison: {
        gross: summarizeTrades(results.flatMap((r) => r.gross)),
        costed: summarizeTrades(results.flatMap((r) => r.costed)),
        filtered: regime ? summarizeTrades(all) : null,
      },
      bySector: [...bySector.entries()].map(([sector, ts]) => ({ sector, ...summarizeTrades(ts) })).sort((a, b) => b.n - a.n),
      perTicker: perTicker.sort((a, b) => (b.totalR ?? -99) - (a.totalR ?? -99)),
      openPositions: results.filter((r) => r.open).map((r) => ({ ticker: r.ticker, ...r.open })),
      minTrades: MIN_TRADES_FOR_CONCLUSION,
    };
  });
}
