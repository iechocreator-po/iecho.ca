# Document de design — Assistant de swing trading (screening, sizing, exécution)

## 1. Contexte

JP est un investisseur autodirigé basé au Québec, gérant un portefeuille multi-comptes (REER, non-enregistré/margin, corporatif) et pratiquant le swing trading à haute fréquence (250-570 transactions/mois observées) principalement sur des titres tech/IA (MSFT, META, GOOG, AMZN, AMD, ADBE, PYPL, RDDT, JD, SMCI, ASML, CRWV). Stratégie de tendance existante : alignement SMA 9/21/50 comme filtre d'entrée, sortie sur clôture sous SMA21. *(Révisé le 29/8/2026 — était SMMA/RMA lissée jusque-là ; JP a demandé de standardiser sur la moyenne mobile SIMPLE après avoir relevé une incohérence de terminologie SMMA/MM dans les capsules d'aide de l'app.)*

**Problème observé** : difficulté de timing au screening ("trop tôt ou en retard"), pas de mécanisme systématique de sizing/stop-loss, pas de suivi de la valeur ajoutée réelle des indicateurs utilisés, saisie manuelle de données de marché.

**Contrainte importante à respecter dans toute logique de compte** : le swing trading actif doit être traité différemment selon le compte — le REER ne permet aucune déduction de perte en capital (contrairement au non-enregistré), donc l'outil doit toujours savoir dans quel compte un trade est logé.

## 2. Objectif du projet

Construire un système d'aide à la décision pour le swing trading, en trois briques :
1. **Écran de sélection de titres** — décide quels titres suivre activement
2. **Fiche de trade** — calcule sizing, stop, cible à chaque entrée
3. **Automatisation & suivi** — branche les données de marché en direct et mesure après coup si chaque indicateur a réellement aidé

Ce projet est distinct du projet séparé "La Roue" (simulateur Wheel options) — garder les deux contextes séparés.

## 3. Prototypes existants (point de départ pour Claude Code)

Deux fichiers HTML autonomes ont déjà été construits et validés fonctionnellement — Claude Code devrait les utiliser comme référence de logique métier plutôt que de repartir de zéro :

- `fiche_trade_sizing_stop.html` — calculateur de sizing/stop par trade
- `ecran_selection_titres.html` — écran de sélection de titres (version single-ticker, à faire évoluer en tableau multi-titres, voir section 5)

## 4. Logique métier à préserver (déjà validée avec JP)

### 4.1 Filtre de tendance
- SMA (Simple Moving Average, fenêtre glissante — **pas** une SMMA/RMA lissée, voir note du 29/8/2026 ci-dessus) sur 3 périodes, **paramétrables** (défaut : 9/21/**50** — ne pas remplacer par EMA 50/100/200)

> **Révisé le 7/9/2026 (feature 351).** La moyenne lente passe de **100 à 50**,
> à la demande explicite de JP. Les trois périodes et celle du RSI sont
> désormais **réellement modifiables dans l'app** (Réglages → Valeur
> personnalisée) et pilotent le calcul serveur sur tous les écrans — la
> source de vérité est `server/preferences.js` (`DEFAULTS`), plus ce
> document ni `config.js`.
>
> **Pine Script mis à jour le 7/9/2026** (demande de JP) : il calcule
> désormais `sma50`, aligné sur le défaut de l'app. ⚠️ **Ce fichier n'est pas
> l'alerte** — JP doit recopier le script ci-dessous dans l'alerte réellement
> configurée sur TradingView, qu'aucun outil d'ici ne peut modifier à
> distance. Tant que ce n'est pas fait, l'alerte continue de se déclencher
> sur l'ancien alignement à 100.
- Signal haussier : close > SMA9 > SMA21 > SMA50, déclenché une seule fois au premier alignement (pas à chaque barre où l'état est vrai)
- Sortie : clôture sous SMA21

### 4.2 Alerte TradingView (Pine Script v5 déjà fourni à JP)
```pinescript
//@version=5
indicator("Alerte SMA rapide/moyenne/lente + Volume", overlay=true)

// Périodes réglables depuis les paramètres de l'indicateur (roue dentée sur
// le graphique) — plus besoin de recoller le script pour changer une valeur.
// Défauts alignés sur ceux de castellana : Réglages -> Valeur personnalisée.
pRapide  = input.int(9,  "SMA rapide",  minval=2)
pMoyenne = input.int(21, "SMA moyenne", minval=2)
pLente   = input.int(50, "SMA lente",   minval=2)
pVolume  = input.int(20, "Moyenne de volume", minval=2)

smaRapide  = ta.sma(close, pRapide)
smaMoyenne = ta.sma(close, pMoyenne)
smaLente   = ta.sma(close, pLente)

plot(smaRapide,  "SMA rapide",  color=color.new(color.aqua,   0))
plot(smaMoyenne, "SMA moyenne", color=color.new(color.orange, 0))
plot(smaLente,   "SMA lente",   color=color.new(color.fuchsia,0))

volMA     = ta.sma(volume, pVolume)
volFiltre = volume > volMA

alignementHaussier = close > smaRapide and smaRapide > smaMoyenne and smaMoyenne > smaLente
premierAlignement  = alignementHaussier and not alignementHaussier[1]
signalEntree       = premierAlignement and volFiltre
signalSortie       = ta.crossunder(close, smaMoyenne)

// Le message d'alerte ne mentionne PLUS de périodes chiffrées : `alertcondition`
// exige une chaîne constante à la compilation, donc un chiffre écrit là
// resterait figé même après un changement de réglage — c'est exactement le
// piège qui a fait annoncer « SMA9/21/100 » alors que le calcul était à 50.
// Les périodes réelles apparaissent sur l'étiquette du graphique, plus bas.
txtPeriodes = str.tostring(pRapide) + "/" + str.tostring(pMoyenne) + "/" + str.tostring(pLente)
alertcondition(signalEntree, title="Entrée - Alignement confirmé", message="{{ticker}} : alignement SMA confirmé avec volume, clôture {{close}}")
alertcondition(signalSortie, title="Sortie - Sous la SMA moyenne", message="{{ticker}} : clôture sous la SMA moyenne, réviser la position")

// Étiquette sur le graphique au moment du signal — rappelle les périodes
// utilisées, que `alertcondition` ne peut pas interpoler dynamiquement.
if signalEntree
    label.new(bar_index, low, "Entrée SMA " + txtPeriodes, style=label.style_label_up, color=color.new(color.green, 20), textcolor=color.white, size=size.small)
```
Réglage critique côté TradingView : déclencheur = "Une fois par clôture de bougie" (élimine le bruit intrabar).

*Historique des révisions de ce script — chacune doit être recopiée à la main dans l'alerte TradingView, qu'aucun outil d'ici ne modifie à distance :*
- *29/8/2026 — `ta.rma()` → `ta.sma()` (standardisation sur la moyenne mobile simple).*
- *7/9/2026 — moyenne lente `100` → `50`, pour rester aligné sur le défaut de l'app (feature 351). À noter : la SMA50 sert désormais à la fois de moyenne lente du filtre de tendance ici, et de moyenne rapide du Golden Cross (SMA50/SMA200) ailleurs dans l'app — deux usages distincts qui partagent la même période, ce n'est pas une confusion.*
- *7/9/2026 — **périodes passées en `input.int`** : elles se règlent maintenant dans les paramètres de l'indicateur sur TradingView (roue dentée du graphique), sans recoller le script. C'est la dernière fois qu'un changement de période oblige à repasser par ce document. Les défauts (9/21/50) restent alignés sur ceux de l'app.*

⚠️ **`alertcondition` n'interpole pas les variables** : son `message` doit être une chaîne constante à la compilation, donc il ne peut pas contenir les périodes choisies. C'est pour ça que le message ne dit plus « SMA9/21/50 » mais « alignement SMA confirmé » — annoncer un chiffre figé serait pire que de n'en annoncer aucun, puisqu'il deviendrait faux dès que JP change un réglage. Une étiquette sur le graphique porte les périodes réelles au moment du signal.

### 4.3 Checklist pré-trade (gate obligatoire, 6 items)
1. Setup confirmé (SMA aligné)
2. Bougie de confirmation clôturée
3. Volume au-dessus de la moyenne 20 jours
4. Climat de marché (VIX) vérifié
5. RSI en zone d'entrée + OBV sans divergence baissière
6. Engagement à placer le stop immédiatement à l'entrée

### 4.4 Indicateurs retenus et bandes de couleur (décidées avec JP, ne pas réinventer)

| Indicateur | Vert | Amber | Rouge |
|---|---|---|---|
| VIX | 15-20 (normal) | <15 (complaisance) ou 20-30 (nervosité) | ≥30 (panique) |
| RSI(14) | 40-70 (zone d'entrée) | 30-40 (pullback profond) ou <30 (survente) | >70 (surachat) |
| OBV | Accumulation | Neutre | Distribution (divergence) |
| Force relative vs indice | écart >+5 pts | écart entre -5 et +5 | écart <-5 pts |
| Golden Cross (écart SMA50 vs SMA200) | >+1% (confirmé) | 0 à +1% (naissant) | ≤0% (absent) |

**Redondance à éviter** : ne pas ajouter MACD ni Stochastic RSI — décision déjà prise avec JP (RSI seul retenu comme momentum, pour éviter la duplication avec le système de croisement SMA déjà en place).

### 4.5 Sizing (le cœur de la fiche de trade)
- Distance du stop = ATR(14) × multiplicateur (1.0–3.0x, défaut 1.5x, ajustable par titre selon liquidité)
- Prix du stop = Prix d'entrée − distance du stop
- Risque de base = % du capital alloué au trading (défaut 1%, slider 0.25–3%)
- **Discounts multiplicatifs appliqués au risque de base** (cumulatifs) :
  - × 0.7 si la position est corrélée aux positions déjà ouvertes (même thème dominant, ex. tech/IA)
  - × 0.5 si VIX ≥ 30, × 0.75 si VIX ≥ 20
  - × 0.8 si RSI > 70
  - × 0.7 si OBV = distribution
- Taille de position (actions) = (capital × risque effectif%) ÷ distance du stop
- **Charge de portefeuille agrégée** : risque déjà engagé (autres positions ouvertes, saisi manuellement pour l'instant) + risque de ce trade → alerte si total > 6%

### 4.6 Type d'ordre recommandé selon liquidité
| Liquidité | Entrée | Sortie |
|---|---|---|
| Liquide (MSFT, GOOG, AMZN) | Stop d'achat au-dessus de la bougie de confirmation | Stop-market au prix du stop |
| Mi-liquide (AMD, RDDT, JD) | Stop d'achat | Stop-limit, marge de 15% de la distance du stop |
| Mince/volatil (SMCI, CRWV, ASML) | Ordre limite au retest — jamais de stop d'achat au marché | Stop-limit obligatoire, marge de 30% |

### 4.7 Objectifs — comparaison R vs Fibonacci
- R-multiples : 1R/2R/3R = Prix d'entrée + (distance du stop × multiple)
- Extension Fibonacci (depuis bas/haut du dernier swing) : 127.2%, 161.8%, 261.8% au-delà du haut du swing
- Afficher les deux côte à côte avec le R-équivalent de chaque niveau Fibonacci, pour que l'utilisateur voie si sa cible R est trop conservatrice ou trop ambitieuse par rapport à la structure du marché

## 5. Évolution demandée : tableau de sélection multi-titres

Remplacer/étendre l'écran de sélection single-ticker par :
- Import en bloc (coller une liste CSV : ticker, prix, RSI, écart force relative, écart golden cross, état OBV)
- Tableau trié par score composite décroissant (score = somme des indicateurs verts/ambres/rouges sur 4 colonnes : RSI, Force relative, Golden Cross, OBV)
- Affichage plafonné aux 20 meilleurs titres
- Cellules colorées selon les bandes de la section 4.4
- Verdict par ligne : ajouter à la liste active / à surveiller / ne pas ajouter

## 6. Intégration Alpha Vantage MCP — état actuel des tests

- Connecteur installé et connecté côté JP
- **GLOBAL_QUOTE : fonctionne**, confirmé avec un appel réel sur AMD (retour correct : prix, volume, variation)
- **RSI : a échoué** avec l'erreur `No approval received.` — cause non confirmée, à investiguer côté Claude Code (possible flux d'approbation manquant pour les outils d'indicateurs calculés vs les cotations brutes)
- **Contrainte de palier gratuit à respecter dans l'architecture** : 25 requêtes/jour, 5/minute, données décalées de 15 minutes. Un rafraîchissement complet du tableau de 20 titres (RSI + Force relative + Golden Cross + OBV, chacun potentiellement plusieurs appels) dépasse largement ce quota en une seule passe.
- **Recommandation d'architecture** : soit limiter le rafraîchissement automatique à un sous-ensemble prioritaire de titres par jour (rotation), soit budgéter le palier payant (49,99 $/mois, 75 requêtes/minute, sans plafond quotidien) si l'usage réel le justifie.
- Prévoir une couche de cache/persistance (éviter de re-interroger l'API pour une donnée déjà récupérée dans la même journée)

## 7. Suivi post-trade automatisé (à construire)

**Schéma de données minimal pour le journal de trades** :
```
trade_id, date_entree, date_sortie, compte (RRSP/margin/corporatif), ticker,
prix_entree, prix_sortie, taille_position, stop_initial,
vix_a_entree, rsi_a_entree, obv_a_entree, correlation_flag,
checklist_complete (bool), R_realise, resultat (gagnant/perdant)
```

**Objectif analytique** : déterminer, après coup, si chaque indicateur (VIX, RSI, OBV, corrélation) a une vraie valeur prédictive dans les trades de JP — ex. requête type "quel est le taux de réussite des trades pris avec VIX > 20 vs VIX < 20 ?"

**Source de données** : peut se brancher sur l'export d'activités déjà utilisé dans les analyses de portefeuille (format connu : transaction_date, account_type, symbol, activity_sub_type, quantity, net_cash_amount, etc.) plutôt que de redemander à JP de ressaisir ses trades.

## 8. Hors scope pour cette phase

- Exécution automatique de trades (pas d'ordres envoyés automatiquement au courtier)
- Intégration avec la stratégie "La Roue" (projet séparé)
- Rebalancement du portefeuille long terme (couvert par les outils d'analyse de portefeuille existants, hors de ce projet)

## 9. Feuille de route suggérée

1. **Phase 1** — Consolider les deux prototypes HTML existants en une seule application (React/PWA cohérente avec le reste du travail de JP), résoudre le blocage RSI sur Alpha Vantage
2. **Phase 2** — Automatiser le remplissage du tableau de sélection (avec gestion du quota API), ajouter le cache/persistance
3. **Phase 3** — Construire le journal de trades automatisé et les requêtes analytiques post-trade; explorer le webhook TradingView pour rapprocher l'alerte du signal réel
