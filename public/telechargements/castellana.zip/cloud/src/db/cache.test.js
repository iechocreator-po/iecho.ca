// Mode démo (2/10/2026) : TTL prolongé, repli sur la valeur périmée, clés techniques exclues.
import test from 'node:test';
import assert from 'node:assert/strict';
import { cached, readCache, withDemo, DEMO_MAX_AGE } from './cache.js';

// Faux D1 : une seule table `cache` en mémoire.
function fakeDb(rows) {
  return {
    prepare(sql) {
      return {
        bind(...args) {
          return {
            async first() { return rows.get(args[0]) ?? null; },
            async run() {
              if (/INSERT INTO cache/.test(sql)) rows.set(args[0], { payload: args[1], fetched_at: args[2], ttl_seconds: args[3] });
              return {};
            },
          };
        },
      };
    },
  };
}
const row = (value, ageSeconds, ttl) => ({ payload: JSON.stringify(value), fetched_at: Date.now() - ageSeconds * 1000, ttl_seconds: ttl });
const inDemo = (fn) => withDemo({ req: { header: () => '1' }, header() {} }, fn);

test('hors démo : une entrée au-delà de son TTL est périmée', async () => {
  const db = fakeDb(new Map([['quote:AMD', row({ p: 1 }, 600, 60)]]));
  assert.equal((await readCache(db, 'quote:AMD')).hit, false);
});

test('en démo : la même entrée reste fraîche jusqu\'à 4 h', async () => {
  const db = fakeDb(new Map([['quote:AMD', row({ p: 1 }, 600, 60)]]));
  await inDemo(async () => { assert.equal((await readCache(db, 'quote:AMD')).hit, true); });
  const vieille = fakeDb(new Map([['quote:AMD', row({ p: 1 }, DEMO_MAX_AGE + 10, 60)]]));
  await inDemo(async () => { assert.equal((await readCache(vieille, 'quote:AMD')).hit, false); });
});

test('en démo : les pauses et le jeton Yahoo ne sont jamais prolongés', async () => {
  const db = fakeDb(new Map([['yahoo:crumb-cooldown', row({}, 600, 45)], ['tv:cooldown', row(true, 600, 60)], ['yahoo:cookiejar:v1', row({}, 7 * 3600, 6 * 3600)]]));
  await inDemo(async () => {
    for (const k of ['yahoo:crumb-cooldown', 'tv:cooldown', 'yahoo:cookiejar:v1']) assert.equal((await readCache(db, k)).hit, false, k);
  });
});

test('en démo : Yahoo en échec → dernière valeur connue, même vieille ; hors démo → erreur', async () => {
  const db = fakeDb(new Map([['quote:AMD', row({ p: 42 }, 3 * 24 * 3600, 60)]]));
  const boom = async () => { throw new Error('429'); };
  await assert.rejects(() => cached(db, 'quote:AMD', 60, boom), /429/);
  await inDemo(async () => { assert.deepEqual(await cached(db, 'quote:AMD', 60, boom), { p: 42 }); });
  await inDemo(async () => { await assert.rejects(() => cached(fakeDb(new Map()), 'quote:ZZZ', 60, boom), /429/); });
});

test('en démo : « force » ne contourne pas le cache', async () => {
  const db = fakeDb(new Map([['quote:AMD', row({ p: 1 }, 300, 60)]]));
  let appels = 0;
  await inDemo(async () => {
    const v = await cached(db, 'quote:AMD', 60, async () => { appels++; return { p: 2 }; }, { force: true });
    assert.deepEqual(v, { p: 1 });
  });
  assert.equal(appels, 0);
});
