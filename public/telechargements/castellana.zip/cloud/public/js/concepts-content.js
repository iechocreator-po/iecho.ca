// js/concepts-content.js — onglet "Concepts" du panneau Réglages (6/9/2026).
//
// Le CONTENU par défaut des 15 fiches vit dans js/concepts-data.js. Ce fichier
// ne fait que le rendre.
//
// 20/9/2026 (demandes de JP) :
// - T0 : l'onglet est derrière un feature flag (`concepts_tab`, défaut OFF) —
//   invisible et non rendu tant que le flag n'est pas activé (depuis bilbao).
// - T1 : titre et texte de chaque fiche peuvent être remplacés par
//   l'administrateur (édition dans bilbao) ; les modifications viennent de
//   GET /api/concepts et se superposent au contenu par défaut.
// - T2 : plus aucune image (les fichiers img/concepts/ sont supprimés).
// - T3 : le bandeau d'origine des images est remplacé par un crédit à
//   dtrading.net qui ne parle plus d'images.

// Table récapitulative de fin de guide ("comment ces 15 outils travaillent
// ensemble") — transcrite telle quelle.
const CONCEPTS_RESUME_TABLE = [
  ['Dans quel sens va le marché ?', 'EMA, Golden Cross'],
  ['Le prix est-il « trop étiré » ?', 'RSI, Stochastic RSI'],
  ['L’élan est-il en train de changer ?', 'MACD'],
  ['Y a-t-il assez de monde derrière le mouvement ?', 'Volume, OBV'],
  ['Où le prix pourrait-il réagir ?', 'Support/Résistance, Fibonacci, VWAP'],
  ['À quel point le marché bouge-t-il ?', 'Bandes de Bollinger, ATR'],
  ['Ce titre est-il un leader ou un retardataire ?', 'Force relative'],
  ['Un nouveau mouvement démarre-t-il ?', 'Breakout, Gaps'],
];

// ---- Assainissement du HTML modifié par l'administrateur ----
// Le contenu PAR DÉFAUT est de confiance (il est dans le dépôt). Le contenu
// modifié, lui, vient de la base et est injecté chez TOUS les testeurs : on
// n'y laisse passer qu'une liste blanche de balises et d'attributs. Analyse
// DOM (template inerte), pas de regex — les regex sont la mauvaise façon de
// filtrer du HTML. Tout ce qui n'est pas listé est retiré avec son contenu.
const CONCEPT_ALLOWED_TAGS = new Set(['P', 'STRONG', 'B', 'EM', 'I', 'U', 'UL', 'OL', 'LI', 'BR', 'SPAN', 'DIV', 'A', 'H4', 'H5', 'CODE']);
const CONCEPT_ALLOWED_CLASSES = new Set(['concept-note', 'concept-note--piege']);

function conceptSanitizeHtml(html) {
  const tpl = document.createElement('template');
  tpl.innerHTML = String(html ?? '');
  const walk = (node) => {
    for (const child of [...node.childNodes]) {
      if (child.nodeType === Node.TEXT_NODE) continue;
      if (child.nodeType !== Node.ELEMENT_NODE || !CONCEPT_ALLOWED_TAGS.has(child.tagName)) {
        child.remove();
        continue;
      }
      for (const attr of [...child.attributes]) {
        const name = attr.name.toLowerCase();
        if (name === 'class') {
          const kept = attr.value.split(/\s+/).filter((c) => CONCEPT_ALLOWED_CLASSES.has(c));
          if (kept.length) child.setAttribute('class', kept.join(' ')); else child.removeAttribute('class');
        } else if (name === 'href' && child.tagName === 'A' && /^https?:\/\//i.test(attr.value.trim())) {
          child.setAttribute('target', '_blank');
          child.setAttribute('rel', 'noopener noreferrer');
        } else {
          child.removeAttribute(attr.name);
        }
      }
      // Parcourir AVANT de déplier : sinon les enfants d'un lien sans href passaient dans le parent sans être filtrés (audit périphérie, 22/10/2026).
      walk(child);
      if (child.tagName === 'A' && !child.getAttribute('href')) child.replaceWith(...child.childNodes);
    }
  };
  walk(tpl.content);
  return tpl.innerHTML;
}

function conceptEscape(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// Rend le contenu complet de l'onglet Concepts dans le conteneur donné.
// `overrides` = { [id]: { titre, corps } } — les fiches modifiées par
// l'administrateur ; les autres gardent leur contenu par défaut.
function renderConceptsTab(containerId, overrides = {}) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const cards = CONCEPTS_TRADING.map((c) => {
    const o = overrides[c.id];
    const titre = o ? conceptEscape(o.titre) : c.titre;
    const corps = o ? conceptSanitizeHtml(o.corps) : c.corps;
    return `
    <details class="ds-card concept-card">
      <summary>${titre}</summary>
      <div class="concept-body">
        ${corps}
      </div>
    </details>
  `;
  }).join('');

  const resumeRows = CONCEPTS_RESUME_TABLE
    .map(([question, outils]) => `<tr><td>${question}</td><td>${outils}</td></tr>`)
    .join('');

  container.innerHTML = `
    <p class="concept-note concept-note--piege">Ce guide est inspiré de concept existant et fortement inspiré de <a href="https://dtrading.net/" target="_blank" rel="noopener">dtrading.net</a> (https://dtrading.net/) — crédit à leur auteur, reprises ici à titre éducatif uniquement.</p>
    <p class="metric-sub" style="text-align:left;">Ce guide reprend 15 concepts de trading expliqués simplement — sans jargon, avec des exemples de la vraie vie. Clique un titre pour déplier.</p>
    <p class="concept-intro-note">💡 <strong>Rappel important</strong> : aucun de ces outils ne prédit l'avenir avec certitude. Ce sont des indices, un peu comme les traces de pas d'un animal dans la neige — ça te dit ce qui vient de se passer, pas ce qui va forcément arriver.</p>
    ${cards}
    <div class="ds-card">
      <div class="section-title">En résumé : comment ces 15 outils travaillent ensemble</div>
      <p class="metric-sub" style="text-align:left;">Aucun de ces indicateurs ne doit être utilisé seul — c'est comme les ingrédients d'une recette : un seul ne fait pas le plat, mais ensemble ils racontent une histoire cohérente.</p>
      <table class="ds-table">
        <thead><tr><th>Ce que tu veux savoir</th><th>Les outils à regarder</th></tr></thead>
        <tbody>${resumeRows}</tbody>
      </table>
      <p class="concept-note concept-note--piege" style="margin-top:12px;">⚠️ <strong>Le plus important à retenir</strong> : ces outils décrivent ce qui vient de se passer et donnent des indices sur ce qui pourrait arriver — ils ne garantissent jamais rien. Personne, même avec 30 ans d'expérience, ne prédit le marché à coup sûr. Le trading, ce n'est pas de la magie, c'est de la probabilité et de la gestion du risque.</p>
    </div>
  `;
}

// Point d'entrée (feature flag `concepts_tab`, défaut OFF). Tant que le flag
// n'est pas activé, l'onglet reste caché et RIEN n'est rendu. Toute erreur
// (réseau, serveur ancien sans la route) laisse l'onglet caché : un onglet
// qu'on ne peut pas garantir ne s'affiche pas.
async function initConceptsTab() {
  const btn = document.getElementById('settings-tab-btn-concepts');
  try {
    const { flags } = await fetchJSON('/api/flags');
    if (!flags || flags.concepts_tab !== true) return;
    let overrides = {};
    try {
      overrides = (await fetchJSON('/api/concepts')).overrides || {};
    } catch { /* contenu par défaut */ }
    renderConceptsTab('settings-tab-concepts', overrides);
    if (btn) btn.style.display = '';
  } catch {
    if (btn) btn.style.display = 'none';
  }
}
