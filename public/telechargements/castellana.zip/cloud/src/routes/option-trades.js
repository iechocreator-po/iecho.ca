// cloud/src/routes/option-trades.js — Journal A (22/9/2026) : screener de
// primes, cycles de la Roue, alertes de roulement. Portage direct de
// server/index.js (voir ce fichier pour le raisonnement complet).
import { screenPremiums } from '../lib/premium-screener.js';
import { getRollAlerts } from '../lib/option-alerts.js';
import { getCycleBilans } from '../lib/cycle-bilan.js';
import {
  createCycle, listCycles, getCycle, updateCycle,
  createOptionTrade, listOptionTrades, getOptionTrade, deleteOptionTrade, closeOptionTrade, deleteRoueEntries,
} from '../db/option-trades.js';
import { listCashFlows, createCashFlow, deleteCashFlow } from '../db/cash-flows.js';
import { getFundamentalsBatch } from '../lib/fundamentals.js';

export function registerOptionTradesRoutes(app) {
  app.get('/api/options/premium-screener', async (c) => {
    try {
      const n = (v, d) => { const f = parseFloat(v); return Number.isFinite(f) ? f : d; };
      const result = await screenPremiums(c.env.DB, c.get('userId'), c.req.query('universe') || 'watchlist', {
        deltaMin: n(c.req.query('deltaMin'), 0.15),
        deltaMax: n(c.req.query('deltaMax'), 0.25),
        dteMin: n(c.req.query('dteMin'), 25),
        dteMax: n(c.req.query('dteMax'), 45),
        mode: c.req.query('mode') === 'limite' ? 'limite' : 'rendement',
        rulePct: n(c.req.query('rulePct'), 0.5),
        rulePeriodDays: n(c.req.query('ruleDays'), 5),
        type: c.req.query('type') === 'call' ? 'call' : 'put',
      });
      return c.json(result);
    } catch (err) {
      return c.json({ error: err.message }, err.status || 503);
    }
  });

  // Secteur de quelques titres (onglet Roue, #435) — voir server/index.js. 20 titres au plus (sous-requêtes).
  app.get('/api/ticker-sectors', async (c) => {
    const tickers = [...new Set(String(c.req.query('tickers') || '').split(',').map((t) => t.trim().toUpperCase()).filter(Boolean))].slice(0, 20);
    try {
      const rows = await getFundamentalsBatch(c.env.DB, tickers, { withVwap: false });
      return c.json({ sectors: Object.fromEntries(rows.map((r) => [r.ticker, r.sector || null])), earnings: Object.fromEntries(rows.map((r) => [r.ticker, Number.isFinite(r.daysToEarnings) ? r.daysToEarnings : null])) });
    } catch (err) { return c.json({ error: err.message }, 503); }
  });

  // Flux de trésorerie par compte (Journal de la Roue, #434) — voir db/cash-flows.js.
  app.get('/api/cash-flows', async (c) => {
    try { return c.json({ cashFlows: await listCashFlows(c.env.DB, c.get('userId'), { compte: c.req.query('compte') || undefined }) }); } catch (err) { return c.json({ error: err.message }, 500); }
  });
  app.post('/api/cash-flows', async (c) => {
    try {
      const body = await c.req.json().catch(() => ({}));
      return c.json(await createCashFlow(c.env.DB, c.get('userId'), body), 201);
    } catch (err) { return c.json({ error: err.message }, err.status || 400); }
  });
  app.delete('/api/cash-flows/:id', async (c) => {
    if (!(await deleteCashFlow(c.env.DB, c.get('userId'), Number(c.req.param('id'))))) return c.json({ error: 'flux introuvable' }, 404);
    return new Response(null, { status: 204 });
  });

  app.get('/api/option-cycles', async (c) => c.json({ cycles: await listCycles(c.env.DB, c.get('userId')) }));

  app.post('/api/option-cycles', async (c) => {
    try {
      const body = await c.req.json().catch(() => ({}));
      return c.json(await createCycle(c.env.DB, c.get('userId'), body), 201);
    } catch (err) {
      return c.json({ error: err.message }, err.status || 400);
    }
  });

  // Bilan par cycle (#378) : AVANT /api/option-cycles/:id (même piège que /api/labo/params).
  app.get('/api/option-cycles/bilans', async (c) => {
    try { return c.json({ bilans: await getCycleBilans(c.env.DB, c.get('userId')) }); } catch (err) { return c.json({ error: err.message }, 500); }
  });

  app.get('/api/option-cycles/:id', async (c) => {
    const cycle = await getCycle(c.env.DB, c.get('userId'), Number(c.req.param('id')));
    if (!cycle) return c.json({ error: 'Cycle introuvable' }, 404);
    return c.json(cycle);
  });

  app.patch('/api/option-cycles/:id', async (c) => {
    try {
      const body = await c.req.json().catch(() => ({}));
      return c.json(await updateCycle(c.env.DB, c.get('userId'), Number(c.req.param('id')), body));
    } catch (err) {
      return c.json({ error: err.message }, err.status || 400);
    }
  });

  // Déclaré AVANT /api/option-trades/:id — même prudence que /api/trades.csv.
  app.get('/api/option-trades/alerts', async (c) => {
    try {
      return c.json({ alerts: await getRollAlerts(c.env.DB, c.get('userId')) });
    } catch (err) {
      return c.json({ error: err.message }, 500);
    }
  });

  app.get('/api/option-trades', async (c) => {
    const userId = c.get('userId');
    const statut = c.req.query('statut');
    const cycleId = c.req.query('cycleId') ? Number(c.req.query('cycleId')) : undefined;
    return c.json({ trades: await listOptionTrades(c.env.DB, userId, { statut, cycleId }) });
  });

  app.post('/api/option-trades', async (c) => {
    try {
      const body = await c.req.json().catch(() => ({}));
      return c.json(await createOptionTrade(c.env.DB, c.get('userId'), body), 201);
    } catch (err) {
      return c.json({ error: err.message }, err.status || 400);
    }
  });

  app.get('/api/option-trades/:id', async (c) => {
    const ot = await getOptionTrade(c.env.DB, c.get('userId'), Number(c.req.param('id')));
    if (!ot) return c.json({ error: 'Position introuvable' }, 404);
    return c.json(ot);
  });

  app.post('/api/option-trades/:id/close', async (c) => {
    try {
      const body = await c.req.json().catch(() => ({}));
      return c.json(await closeOptionTrade(c.env.DB, c.get('userId'), Number(c.req.param('id')), body));
    } catch (err) {
      return c.json({ error: err.message }, err.status || 400);
    }
  });

  // Suppression multiple de l'onglet Roue (positions, mouvements, et cycles devenus vides).
  app.post('/api/roue/delete', async (c) => {
    try {
      const body = await c.req.json().catch(() => ({}));
      return c.json({ deleted: await deleteRoueEntries(c.env.DB, c.get('userId'), body) });
    } catch (err) {
      return c.json({ error: err.message }, err.status || 400);
    }
  });

  app.delete('/api/option-trades/:id', async (c) => {
    return c.json({ deleted: await deleteOptionTrade(c.env.DB, c.get('userId'), Number(c.req.param('id'))) });
  });
}
