import { getSectorPerformance, getSectorHistory, SECTOR_MODES, SECTOR_ETF_TO_YAHOO_SECTOR, SECTOR_TOP_FILTERS, SECTOR_DEFS } from '../lib/sectors.js';
import { getFundamentalsBatch } from '../lib/fundamentals.js';
import { getWatchlist } from '../db/watchlist.js';
import { buildSectorScreening } from '../lib/screening.js';
import { readCacheRaw, writeCache, demoTtl, demoActive } from '../db/cache.js';

function parseSectorMode(c) {
  const mode = c.req.query('mode') || 'usd';
  if (!SECTOR_MODES.includes(mode)) return null;
  return mode;
}

export function registerSectorsRoutes(app) {
  app.get('/api/sectors', async (c) => {
    const mode = parseSectorMode(c);
    if (mode === null) {
      return c.json({ error: `mode invalide : ${c.req.query('mode')} (attendu : ${SECTOR_MODES.join('|')})` }, 400);
    }
    const userId = c.get('userId');
    try {
      const watchlist = await getWatchlist(c.env.DB, userId);
      const [perf, fundamentalRows] = await Promise.all([
        getSectorPerformance(c.env.DB, { mode }),
        getFundamentalsBatch(c.env.DB, watchlist.map((w) => w.ticker), { withVwap: false }),
      ]);
      const pegBySector = new Map();
      for (const f of fundamentalRows) {
        if (!f.sector || f.pegRatio == null) continue;
        if (!pegBySector.has(f.sector)) pegBySector.set(f.sector, []);
        pegBySector.get(f.sector).push(f.pegRatio);
      }
      const sectorsWithPeg = perf.sectors.map((s) => {
        const values = pegBySector.get(SECTOR_ETF_TO_YAHOO_SECTOR[s.key]);
        return {
          ...s,
          pegAvg: values?.length ? values.reduce((a, b) => a + b, 0) / values.length : null,
          pegPeerCount: values?.length ?? 0,
        };
      });
      return c.json({ generatedAt: new Date().toISOString(), mode, sectors: sectorsWithPeg, benchmark: perf.benchmark, equalWeight: perf.equalWeight });
    } catch (err) {
      return c.json({ error: 'Yahoo Finance injoignable', detail: err.message }, 503);
    }
  });

  // Déclaré AVANT /api/sectors/:sectorKey/top pour que Hono le matche en
  // premier (même règle de spécificité qu'Express : un segment littéral
  // 'history' ne doit jamais tomber dans le paramètre :sectorKey).
  app.get('/api/sectors/history', async (c) => {
    const mode = parseSectorMode(c);
    if (mode === null) {
      return c.json({ error: `mode invalide : ${c.req.query('mode')} (attendu : ${SECTOR_MODES.join('|')})` }, 400);
    }
    try {
      const data = await getSectorHistory(c.env.DB, { mode });
      return c.json({ generatedAt: new Date().toISOString(), mode, ...data });
    } catch (err) {
      return c.json({ error: 'Yahoo Finance injoignable', detail: err.message }, 503);
    }
  });

  app.get('/api/sectors/:sectorKey/top', async (c) => {
    const sectorKey = c.req.param('sectorKey').toUpperCase();
    const rawMode = c.req.query('mode');
    const filterMode = rawMode === 'filtered' ? 'filtered' : rawMode === 'raw' ? 'raw' : null;
    if (!filterMode) {
      return c.json({ error: `mode invalide : ${rawMode} (attendu : raw|filtered)` }, 400);
    }
    if (!SECTOR_ETF_TO_YAHOO_SECTOR[sectorKey]) {
      return c.json({ error: `secteur inconnu : ${sectorKey}` }, 400);
    }
    const userId = c.get('userId');
    // Clé versionnée PAR UTILISATEUR (v2) — le résultat dépend des
    // préférences et de la watchlist propres à chaque compte.
    const cacheKey = `sectors:topresult:v2:${userId}:${sectorKey}:${filterMode}`;
    const ttlSeconds = 20 * 60;
    const rawEntry = await readCacheRaw(c.env.DB, cacheKey);
    const forced = !demoActive() && c.req.query('force') === 'true'; // « Forcer » ne force rien en démo
    if (!forced && rawEntry.found && rawEntry.ageSeconds < demoTtl(ttlSeconds)) {
      return c.json({ ...rawEntry.value, cached: true });
    }
    try {
      const result = await buildSectorScreening(c.env.DB, userId, sectorKey, { mode: filterMode, filters: SECTOR_TOP_FILTERS });
      const payload = {
        sectorKey,
        sectorLabel: SECTOR_DEFS.find((d) => d.key === sectorKey)?.label ?? sectorKey,
        mode: filterMode,
        generatedAt: new Date().toISOString(),
        ...result,
      };
      await writeCache(c.env.DB, cacheKey, payload, ttlSeconds);
      return c.json({ ...payload, cached: false });
    } catch (err) {
      if (demoActive() && rawEntry.found) return c.json({ ...rawEntry.value, cached: true, stale: true });
      return c.json({ error: 'Yahoo Finance injoignable pour ce secteur', detail: err.message, sectorKey, mode: filterMode }, 503);
    }
  });
}
