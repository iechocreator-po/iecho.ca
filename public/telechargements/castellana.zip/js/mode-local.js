// js/mode-local.js — code propre à la version LOCALE
// Extrait de l'ancien script en ligne des index.html (découpage phase 2, 20/10/2026) : code déplacé tel quel, sans réécriture.
// (TradingView local, balayage S&P 500, courriels, mise à jour, publication du balayage, et les variantes locales de fonctions qui existent aussi en cloud.)
// Script classique : ses noms de premier niveau sont globaux et partagés avec les autres scripts de la page.

function calcFiche() {
  // Un prix d'entrée rempli automatiquement appartient à SON symbole : si le
  // symbole a changé (frappe, ou autre chemin que la récupération), on l'efface.
  if (entryAutoFilled && entryAutoFilled.ticker !== document.getElementById('ticker').value.trim().toUpperCase()) clearAutoFilledEntry();
  const capital   = +document.getElementById('capital').value;
  const riskPct   = +document.getElementById('riskpct').value;
  const heatExist = +document.getElementById('heatexist').value;
  const correlated = document.getElementById('correlated').value === 'oui';
  const entryRaw  = document.getElementById('entry').value;
  const entry     = +entryRaw;
  // Sans prix d'entrée, le stop et les cibles seraient « 0 ± distance » : des
  // chiffres faux et crédibles. On les remplace par « — ».
  const hasEntry  = entryRaw !== '' && Number.isFinite(entry) && entry > 0;
  const atr       = +document.getElementById('atr').value;
  const atrMult   = +document.getElementById('atrmult').value;
  const liq       = document.getElementById('liq').value;
  const ticker    = document.getElementById('ticker').value.toUpperCase() || 'CE TITRE';
  // VIX vient de la pastille globale du header (currentVix), plus d'un
  // champ de saisie ici depuis le 28/9/2026 — computeSizing() traite déjà
  // un VIX manquant (NaN/null) comme "aucun discount", sans rien inventer.
  const vix       = currentVix;
  const rsi       = +document.getElementById('rsi').value;
  const obv       = document.getElementById('obv').value;
  const swingLow  = +document.getElementById('swinglow').value;
  const swingHigh = +document.getElementById('swinghigh').value;
  // `discounts` et les bandes VIX vivent désormais dans computeSizing
  // (js/sizing.js). Ne restent ici que ce que calcFiche utilise encore pour
  // ses propres messages.
  const heatCfg = CFG.sizing.chargePortefeuille;
  const bRsi = CFG.bandes.rsi;

  document.getElementById('riskpct-out').textContent = riskPct.toFixed(2) + ' %';
  document.getElementById('heatexist-out').textContent = heatExist.toFixed(2) + ' %';
  document.getElementById('atrmult-out').textContent = atrMult.toFixed(2) + 'x';

  const rsiInfo = rsiInterp(rsi);
  document.getElementById('rsi-badge').innerHTML = '<span class="ds-badge ' + rsiInfo.cls + '">' + rsiInfo.label + '</span>';
  document.getElementById('rsi-note').textContent = rsiInfo.note;

  const obvInfo = obvInterp(obv);
  document.getElementById('obv-note').innerHTML = obvInfo.warn ? '<span class="bad">' + obvInfo.note + '</span>' : obvInfo.note;

  // Le calcul lui-même vit dans js/sizing.js depuis le 11/9/2026 — il était
  // enfermé ici, au milieu des écritures DOM, donc inutilisable ailleurs et
  // intestable. Le tableau de screening appelle exactement la même fonction
  // pour chiffrer la charge de chaque candidat : une seule maison pour ces
  // formules, jamais une copie.
  const sz = computeSizing({ capital, riskPct, heatExist, entry, atr, atrMult, correlated, vix, rsi, obv });
  const { stopDist, stopPrice, shares, totalHeat, riskEngage } = sz;

  document.getElementById('m-dist').textContent = fmt(stopDist);
  document.getElementById('m-stop').textContent = hasEntry ? fmt(stopPrice) : '—';
  document.getElementById('m-size').textContent = shares + ' act.';
  document.getElementById('m-size-sub').textContent = (sz.reasons.length ? 'réduite (' + sz.reasons.join(', ') + ')' : 'taille de base')
    + (sz.pctCapital != null ? ' · ' + Math.round(sz.pctCapital) + ' % du capital' : '');

  const heatEl = document.getElementById('m-heat');
  heatEl.textContent = totalHeat.toFixed(1) + ' %';
  heatEl.className = 'ds-metric__value ' + (sz.depasseAlerte ? 'bad' : sz.depasseAvertissement ? 'warn' : 'ok');

  const rec = document.getElementById('order-rec');
  let recHtml = '';
  const stopTxt = hasEntry ? fmt(stopPrice) : "(renseigne d'abord le prix d'entrée)";
  if (liq === 'liquide') {
    recHtml = '<strong>Entrée :</strong> ordre stop d\'achat juste au-dessus du haut de la bougie de confirmation, ou marché si l\'écart est minime.<br><strong>Sortie :</strong> stop-market au prix ' + stopTxt + '.';
  } else if (liq === 'moyen') {
    recHtml = '<strong>Entrée :</strong> ordre stop d\'achat au-dessus du haut de la bougie de confirmation.<br><strong>Sortie :</strong> stop-limit au prix ' + stopTxt + ', limite ' + fmt(stopDist*0.15) + ' plus bas.';
  } else {
    recHtml = '<strong>Entrée :</strong> ordre limite au niveau du retest — pas de stop d\'achat, le glissement peut être important.<br><strong>Sortie :</strong> stop-limit obligatoire, marge élargie de ' + fmt(stopDist*0.3) + '.';
  }
  const capNote = sizingCapNote(sz);
  if (capNote) recHtml += '<br><br><span style="color:var(--amber); font-weight:600;">⚠ ' + capNote + '</span>';
  if (totalHeat > heatCfg.alerte) recHtml += '<br><br><span style="color:var(--red); font-weight:600;">⚠ Charge totale du portefeuille au-delà de ' + heatCfg.alerte + '% — réduire cette position ou fermer une autre avant d\'ajouter du risque.</span>';
  if (obv === 'distribution' && rsi > bRsi.entreeHaut) recHtml += '<br><br><span style="color:var(--red); font-weight:600;">⚠ Surachat + divergence OBV en même temps — signal de prudence élevé, envisage sérieusement d\'attendre.</span>';
  rec.innerHTML = recHtml;

  const rEl = document.getElementById('rtable');
  const targets = [1, 2, 3];
  rEl.innerHTML = targets.map(r => `<tr><td>Cible ${r}R</td><td>${hasEntry ? fmt(entry + stopDist * r) : '—'}</td></tr>`).join('')
    + `<tr><td>Risque $ (si stop touché)</td><td>${fmt(riskEngage)}</td></tr>`;

  const fibEl = document.getElementById('fibtable');
  const range = swingHigh - swingLow;
  const fibLevels = [
    { label: 'Ext. 127.2%', price: swingHigh + range * 0.272 },
    { label: 'Ext. 161.8%', price: swingHigh + range * 0.618 },
    { label: 'Ext. 261.8%', price: swingHigh + range * 1.618 }
  ];
  fibEl.innerHTML = fibLevels.map(f => {
    const rEquiv = hasEntry && stopDist > 0 ? ((f.price - entry) / stopDist).toFixed(1) : '—';
    return `<tr><td>${f.label}</td><td>${fmt(f.price)} (${rEquiv}R)</td></tr>`;
  }).join('');

  // Les verdicts se recalculent ici et pas seulement après un fetch : les
  // lignes VIX et RSI/OBV lisent les champs du formulaire, que JP peut
  // saisir à la main. Sans ça, taper un VIX laisserait un verdict périmé.
  renderChecklistVerdicts();
  const allChecked = ['c1','c2','c3','c4','c5','c6'].every(id => document.getElementById(id).checked);
  const banner = document.getElementById('banner');
  if (allChecked) {
    banner.className = 'banner ready';
    banner.textContent = '✓ Checklist complète — ' + ticker + ' prêt pour l\'entrée calculée ci-dessus';
  } else {
    banner.className = 'banner notready';
    banner.textContent = '⚠ Checklist incomplète — ne pas entrer sur ' + ticker + ' encore';
  }
}
// ---- Données en direct (backend Express → Yahoo Finance ; le sidecar
// tradingview-mcp n'est qu'un repli optionnel depuis le 7/9/2026) ----
async function fetchJSON(url, options) {
  try {
    const res = await fetch(url, options);
    // On lit le corps en TEXTE avant de le parser (feature 351, 7/9/2026).
    // `res.json()` direct laissait remonter le message brut de JSON.parse —
    // « Unexpected token '<', "<!DOCTYPE "... is not valid JSON » — quand le
    // serveur répondait une page HTML : illisible, et sans rapport apparent
    // avec la vraie cause. On nomme désormais la cause.
    const raw = await res.text();
    const type = res.headers.get('content-type') || '';
    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      if (type.includes('text/html') || raw.trimStart().startsWith('<')) {
        throw new Error(
          `Le serveur a renvoyé une page HTML au lieu de données (HTTP ${res.status}). `
          + 'Cause la plus probable : la page ouverte est plus récente que le serveur qui tourne. '
          + 'Recharge la page (Cmd/Ctrl+Maj+R) ; si ça persiste, relance castellana.'
        );
      }
      throw new Error(`Réponse illisible du serveur (HTTP ${res.status}) : ${raw.slice(0, 120)}`);
    }
    if (!res.ok) {
      // `code` et `status` accompagnent le message : les écrans peuvent réagir à la CAUSE (ex. NO_SWEEP)
      // plutôt que d'analyser un texte.
      const e = new Error(data.error || data.detail || res.statusText);
      e.code = data.code; e.status = res.status; e.detail = data.detail;
      throw e;
    }
    return data;
  } catch (err) {
    // Point de passage unique de tous les appels API de l'app : c'est donc
    // le bon endroit — et le seul — pour remonter une panne à la télémétrie
    // (7/9/2026). Sans ça, JP n'apprenait l'existence d'un problème chez un
    // testeur que si celui-ci pensait à lui écrire.
    // `typeof` plutôt qu'un appel direct : telemetry.js peut ne pas être
    // chargé (ordre des <script>), et la remontée d'erreur ne doit jamais
    // devenir elle-même une source d'erreur. On n'instrumente pas l'endpoint
    // de télémétrie lui-même, sous peine de boucle.
    try {
      if (typeof trackError === 'function' && !String(url).includes('/events')) {
        trackError(String(url).split('?')[0], err.message);
      }
    } catch { /* jamais bloquant */ }
    throw err;
  }
}
// ---- TradingView local + balayage S&P 500 (option 2, 7/10/2026) ----
let tvSweepTimer = null;
async function tvLocalRefresh() {
  let d;
  try { d = await fetchJSON('/api/tradingview/status'); } catch (err) { document.getElementById('tv-local-status').textContent = 'État indisponible : ' + err.message; return; }
  document.getElementById('tv-local-source').value = d.dataSource;
  document.getElementById('tv-local-connect').style.display = d.connected ? 'none' : '';
  document.getElementById('tv-local-disconnect').style.display = d.connected ? '' : 'none';
  const parts = [d.connected ? `Connecté à TradingView depuis le ${new Date(d.connectedAt).toLocaleString('fr-CA')}.` : 'TradingView non connecté (la source TradingView exige une connexion).'];
  parts.push(d.active ? 'Source active : TradingView (local).' : 'Source active : Yahoo.');
  if (d.coolingUntil) parts.push('Pause après une limite (429) de TradingView.');
  if (d.stats.tv || d.stats.yahoo) parts.push(`Depuis le démarrage : ${d.stats.tv} valeur(s) via TradingView, ${d.stats.yahoo} via Yahoo (repli), ${d.stats.rateLimits} limite(s) 429.`);
  if (d.stats.lastError) parts.push('Dernière erreur : ' + d.stats.lastError);
  document.getElementById('tv-local-status').textContent = parts.join(' ');
  tvSweepRender(d.sweep);
}
async function tvLocalSetSource(source) {
  try { await fetchJSON('/api/data-source', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ source }) }); }
  catch (err) { alert(err.message); }
  tvLocalRefresh();
}
async function tvLocalConnect() {
  try { const d = await fetchJSON('/api/tradingview/connect', { method: 'POST' }); window.location.href = d.url; }
  catch (err) { document.getElementById('tv-local-status').textContent = 'Connexion impossible : ' + err.message; }
}
async function tvLocalDisconnect() {
  if (!confirm('Déconnecter TradingView ? Le jeton local sera effacé et la source repassera à Yahoo.')) return;
  await fetchJSON('/api/tradingview/disconnect', { method: 'POST' }).catch(() => {});
  tvLocalRefresh();
}
function tvSweepRender(sw) {
  const st = document.getElementById('tv-sweep-status');
  const bar = document.getElementById('tv-sweep-progress');
  document.getElementById('tv-sweep-start').disabled = sw.running;
  document.getElementById('tv-sweep-cancel').style.display = sw.running ? '' : 'none';
  bar.style.display = sw.running || sw.phase === 'terminé' ? '' : 'none';
  bar.max = sw.total || 1; bar.value = sw.done;
  if (sw.running) {
    const eta = sw.etaSeconds != null ? ` — encore ~${Math.ceil(sw.etaSeconds / 60)} min` : '';
    st.textContent = sw.phase === 'analyse' ? 'Analyse des résultats…' : `Phase « ${sw.phase} » : ${sw.done}/${sw.total} titres (source : ${sw.source})${eta}.`;
    if (!tvSweepTimer) tvSweepTimer = setInterval(tvLocalRefresh, 3000);
  } else {
    if (tvSweepTimer) { clearInterval(tvSweepTimer); tvSweepTimer = null; }
    if (sw.phase === 'terminé' && typeof loadSweepNews === 'function') { loadSweepNews(); loadSectorSetups(); }
    if (sw.phase === 'terminé') st.textContent = `Terminé en ${sw.elapsedSeconds} s (source : ${sw.source}) : ${sw.result.retained} retenu(s) sur ${sw.result.universeSize}. Ouvre Screener → S&P 500.` + (sw.failed ? ` ${sw.failed} titre(s) sans historique exploitable (${sw.failedTickers.slice(0, 8).join(', ')}${sw.failed > 8 ? '…' : ''}) : ignorés.` : '');
    else if (sw.phase === 'erreur') st.textContent = 'Échec : ' + sw.error;
    else if (sw.phase === 'annulé') st.textContent = `Annulé après ${sw.done} titres (ils restent en cache : relancer reprend).`;
    else st.textContent = '';
  }
}
const esc = (t) => String(t ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
async function loadAppSettings() {
  const st = document.getElementById('app-settings-status');
  try {
    const d = await fetchJSON('/api/app-settings');
    document.getElementById('app-sweep-auto').checked = d.sweepAuto;
    renderPosAlerts(d);
    renderPublishState(d);
    document.getElementById('app-alert-emails').value = d.alertEmails.join(', ');
    document.getElementById('app-emails-note').textContent =
      (d.emailsFromEnv ? 'Adresse reprise de ALERT_EMAIL (.env) tant que tu n\'enregistres pas cette liste. ' : '') +
      (d.alertEmails.length ? '' : 'Aucune adresse enregistrée : aucun courriel ne part.');
    const rs = document.getElementById('app-resend-state');
    rs.innerHTML = d.emailAvailable
      ? `<span class="ds-badge ds-badge--success">Clé configurée</span> ${d.resendKeySource === 'process' ? '(variable d\'environnement du processus, prioritaire sur le .env)' : '(fichier .env local)'} · expéditeur ${esc(d.emailFrom)}`
      : '<span class="ds-badge ds-badge--warning">Aucune clé</span> Les alertes restent dans l\'app : alertes de positions (#379) et résumé du balayage (#395) ne partent pas par courriel.';
    document.getElementById('app-resend-remove').style.display = d.resendKeySource === 'dotenv' ? '' : 'none';
    const tb = document.getElementById('app-test-email');
    tb.disabled = !(d.emailAvailable && d.alertEmails.length);
    tb.title = tb.disabled ? 'Il faut une clé et au moins une adresse enregistrée.' : 'Envoie un courriel aux adresses enregistrées.';
    st.textContent = '';
  } catch (err) { st.textContent = 'Indisponible : ' + err.message; }
}
// Publication vers la version en ligne (17/10/2026) : jamais d'identifiant affiché, seulement l'hôte.
function renderPublishState(d) {
  const p = d.publish || {};
  document.getElementById('app-publish-cloud').checked = !!d.publishCloud;
  const last = p.last;
  const lastTxt = !last ? 'Aucun envoi pour l\'instant.'
    : last.ok ? `Dernier envoi : ${new Date(last.at).toLocaleString('fr-CA')} (${esc(last.trigger || '')}) — balayage du ${esc(last.date)}, ${last.rows} titre(s), ${Math.round(last.bytes / 1024)} Ko, reçu par ${esc(last.target)}.`
    : `Dernier envoi : ${new Date(last.at).toLocaleString('fr-CA')} (${esc(last.trigger || '')}) — échec : ${esc(last.error)}`;
  document.getElementById('app-publish-state').innerHTML = (p.configured
    ? `<span class="ds-badge ds-badge--success">Cible : ${esc(p.target)}</span> `
    : `<span class="ds-badge ds-badge--warning">Non configuré</span> ${esc(p.reason || '')} `) + (last && !last.ok ? `<span style="color:var(--red)">${lastTxt}</span>` : lastTxt);
  document.getElementById('app-publish-now').disabled = !p.configured;
}
async function publishSnapshotNow() {
  const st = document.getElementById('app-publish-status');
  st.textContent = 'Envoi…';
  try {
    const r = await fetchJSON('/api/snapshot/publish', { method: 'POST' });
    st.textContent = r.ok ? 'Publié.' : 'Échec : ' + r.error;
    loadAppSettings();
  } catch (err) { st.textContent = err.message; }
}
async function saveResendKey() {
  const st = document.getElementById('app-resend-status');
  const inp = document.getElementById('app-resend-key');
  if (!inp.value.trim()) { st.textContent = 'Colle d\'abord la clé.'; return; }
  try {
    const r = await fetchJSON('/api/app-settings/resend-key', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key: inp.value }) });
    inp.value = '';
    st.textContent = r.fromProcessEnv ? 'Clé écrite dans .env, mais une variable d\'environnement RESEND_API_KEY reste prioritaire.' : 'Clé enregistrée.';
    loadAppSettings();
  } catch (err) { st.textContent = err.message; }
}
async function removeResendKey() {
  const st = document.getElementById('app-resend-status');
  if (!confirm('Retirer la clé Resend du fichier .env ? Plus aucun courriel ne partira.')) return;
  try {
    await fetchJSON('/api/app-settings/resend-key', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key: null }) });
    st.textContent = 'Clé retirée.';
    loadAppSettings();
  } catch (err) { st.textContent = err.message; }
}
async function sendTestEmail() {
  const st = document.getElementById('app-resend-status');
  st.textContent = 'Envoi…';
  try {
    const r = await fetchJSON('/api/app-settings/test-email', { method: 'POST' });
    st.textContent = (r.sent.length ? `Envoyé à ${r.sent.join(', ')}.` : '') + (r.errors.length ? ` Échec : ${r.errors.join(' ; ')}` : '');
  } catch (err) { st.textContent = err.message; }
}
// Alertes de positions (#379) : l'utilisateur décide. Le seuil de profit vient des paramètres de la Roue (lecture seule ici).
function renderPosAlerts(d) {
  const p = d.positionAlerts || { enabled: true, kinds: {}, email: true };
  document.getElementById('app-posalerts-enabled').checked = !!p.enabled;
  for (const k of ['echeance', 'profit', 'stop']) document.getElementById('app-posalerts-' + k).checked = !!(p.kinds || {})[k];
  document.getElementById('app-posalerts-email').checked = !!p.email;
  document.getElementById('app-posalerts-seuil').textContent = d.profitTakeMin ?? 50;
  refreshPosAlertsControls();
}
function refreshPosAlertsControls() {
  const on = document.getElementById('app-posalerts-enabled').checked;
  document.getElementById('app-posalerts-detail').querySelectorAll('input').forEach((i) => { i.disabled = !on; });
  document.getElementById('app-posalerts-detail').style.opacity = on ? '' : '0.5';
}
function collectPosAlerts() {
  const kinds = {};
  for (const k of ['echeance', 'profit', 'stop']) kinds[k] = document.getElementById('app-posalerts-' + k).checked;
  return { enabled: document.getElementById('app-posalerts-enabled').checked, kinds, email: document.getElementById('app-posalerts-email').checked };
}
async function saveAppSettings() {
  const st = document.getElementById('app-settings-status');
  // Chaîne séparée par des virgules envoyée telle quelle : le serveur la découpe et la valide.
  const emails = document.getElementById('app-alert-emails').value;
  try {
    await fetchJSON('/api/app-settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sweepAuto: document.getElementById('app-sweep-auto').checked, publishCloud: document.getElementById('app-publish-cloud').checked, alertEmails: emails, positionAlerts: collectPosAlerts() }) });
    st.textContent = 'Enregistré.';
    loadAppSettings().then(() => { st.textContent = 'Enregistré.'; });
    if (typeof loadSweepNews === 'function') loadSweepNews();
  } catch (err) { st.textContent = err.message; }
}
async function loadSectorSetups() {
  const host = document.getElementById('sector-setups-host');
  if (!host) return;
  try {
    const d = await fetchJSON('/api/sweep/sectors');
    const max = Math.max(1, ...d.sectors.map((s) => s.total));
    const age = d.ageSeconds < 3600 ? `${Math.round(d.ageSeconds / 60)} min` : d.ageSeconds < 172800 ? `${Math.round(d.ageSeconds / 3600)} h` : `${Math.round(d.ageSeconds / 86400)} j`;
    const chips = (l) => l.map((t) => `<span class="ds-badge">${esc(t)}</span>`).join(' ');
    host.innerHTML = `<p class="metric-sub" style="text-align:left;">Balayage d'il y a ${age} · ${d.retainedSize} retenu(s) sur ${d.universeSize}.</p>` +
      d.sectors.map((s) => `<div style="display:grid; grid-template-columns:190px 1fr 140px; gap:10px; align-items:center; padding:4px 0;" title="${s.pretCount} prêt · ${s.surveillerCount} à surveiller · ${s.total} titres dans le secteur">
        <div><strong>${esc(s.label)}</strong></div>
        <div style="position:relative; height:16px; background:var(--surface-2); border-radius:4px; overflow:hidden; width:${(s.total / max * 100).toFixed(0)}%; min-width:30px;">
          <div style="position:absolute; inset:0 auto 0 0; width:${(s.pretCount / s.total * 100).toFixed(1)}%; background:var(--green);"></div>
          <div style="position:absolute; inset:0 auto 0 ${(s.pretCount / s.total * 100).toFixed(1)}%; width:${(s.surveillerCount / s.total * 100).toFixed(1)}%; background:var(--amber); opacity:.8;"></div>
        </div>
        <div class="metric-sub" style="text-align:right;"><span style="color:var(--green);font-weight:700;">${s.pretCount}</span> prêt · <span style="color:var(--amber);font-weight:700;">${s.surveillerCount}</span> à surv. / ${s.total}</div>
      </div>${s.pretCount ? `<div style="padding:0 0 6px 200px;">${chips(s.pret)}</div>` : ''}`).join('') +
      '<div class="opt-legend"><span class="opt-legend-item"><i class="opt-legend-sw" style="background:var(--green)"></i>Prêt</span><span class="opt-legend-item"><i class="opt-legend-sw" style="background:var(--amber)"></i>À surveiller</span><span class="opt-legend-item"><i class="opt-legend-sw" style="background:var(--surface-2)"></i>Reste du secteur (largeur = taille du secteur)</span></div>';
  } catch (err) {
    host.innerHTML = err.code === 'NO_SWEEP' ? '<p>Aucun balayage enregistré : lance-le dans Réglages → TradingView.</p>' : `<p>Indisponible : ${esc(err.message)}</p>`;
  }
}
async function loadSweepNews() {
  const host = document.getElementById('sweep-news-host');
  if (!host) return;
  try {
    const { news, last, autoDaily } = await fetchJSON('/api/sweep/news');
    const auto = autoDaily ? 'Balayage automatique : activé (après 17 h à New York).' : 'Balayage automatique : désactivé (Réglages → TradingView).';
    if (!news) { host.innerHTML = `<p>Aucun balayage enregistré pour l'instant. ${esc(auto)}</p>`; return; }
    const when = new Date(news.at).toLocaleString('fr-CA');
    const chips = (list) => list.length ? list.map((t) => `<span class="ds-badge ds-badge--accent" style="margin:2px;cursor:pointer;">${esc(t)}</span>`).join('') : '<span class="ds-text-muted">aucun</span>';
    const mail = news.scheduled ? (news.email && news.email.sent ? ' · courriel envoyé' : ` · courriel non envoyé (${esc((news.email && news.email.reason) || '?')})`) : '';
    host.innerHTML = `<p class="metric-sub" style="text-align:left;">Dernier balayage : ${esc(when)} · source ${esc(news.source || '?')} · ${news.retainedSize} retenu(s) sur ${news.universeSize}${mail}. ${esc(auto)}</p>` + (news.baseline
      ? `<p>Premier balayage enregistré : ${news.ready.length} candidat(s) « prêt ». Les nouveautés apparaîtront au prochain balayage.</p><div>${chips(news.ready)}</div>`
      : `<div><strong>Nouveaux (${news.nouveautes.length})</strong> : ${chips(news.nouveautes)}</div><div style="margin-top:6px;"><strong>Sortis (${news.sorties.length})</strong> : ${chips(news.sorties)}</div>`);
  } catch (err) { host.textContent = 'Indisponible : ' + err.message; }
}
async function tvSweepStart() {
  try { await fetchJSON('/api/sweep/start', { method: 'POST' }); } catch (err) { document.getElementById('tv-sweep-status').textContent = err.message; return; }
  tvLocalRefresh();
}
async function tvSweepCancel() { await fetchJSON('/api/sweep/cancel', { method: 'POST' }).catch(() => {}); tvLocalRefresh(); }
function initTvLocal() {
  const r = new URLSearchParams(location.search).get('tv');
  if (r) history.replaceState(null, '', location.pathname);
  tvLocalRefresh().then(() => {
    const msg = { ok: 'TradingView connecté.', refuse: 'Connexion refusée côté TradingView.', erreur: 'La connexion TradingView a échoué (réessaie).' }[r];
    if (msg) { openSettings(); switchSettingsTab('tradingview'); document.getElementById('tv-local-status').textContent = msg; }
  });
}
// Libellés par univers (T5, 12/9/2026) — un seul endroit à étendre le jour
// où une vraie gestion de plusieurs listes personnalisées est construite
// (voir CLAUDE.md, feature future), plutôt qu'un enchaînement de ternaires.
const UNIVERS_LABELS = {
  watchlist: 'Ma watchlist : tous les titres suivis sont affichés, en setup ou non. Lance le screening.',
  elargi: "Univers élargi : 210 titres balayés, seuls ceux en setup d'entrée sont retenus. Lance le screening.",
  mag7: 'MAG7 : Apple, Microsoft, Alphabet, Amazon, Nvidia, Meta, Tesla — tous affichés, en setup ou non. Lance le screening.',
  sp500: "S&P 500 : résultat du dernier balayage local (Réglages → TradingView), seuls les titres en setup d'entrée sont retenus. Lance d'abord le balayage, puis le screening.",
};
const UNIVERS_EN_COURS = {
  watchlist: 'Screening en cours… (~2 s)',
  elargi: 'Screening de 210 titres en cours… (~5 s)',
  mag7: 'Screening de 7 titres en cours… (~1 s)',
  sp500: 'Lecture du dernier balayage S&P 500…',
};
function screeningExplainError(err) {
  const msg = err && err.message ? err.message : String(err);
  if (err && err.code === 'NO_SWEEP') {
    const hasSettings = typeof openSettings === 'function' && document.getElementById('tv-sweep-card');
    return { text: "Aucun balayage du S&P 500 n'a encore été fait. Lance-le d'abord (Réglages → TradingView → Balayage du S&P 500), puis reviens ici.",
      action: hasSettings ? ['Ouvrir le balayage', () => { openSettings(); switchSettingsTab('tradingview'); }] : null };
  }
  if (err instanceof TypeError || /Failed to fetch|NetworkError|Load failed/i.test(msg)) {
    return { text: 'Le serveur castellana ne répond pas. Est-il toujours lancé ? (npm start, ou recharge la page.)' };
  }
  if (err && err.status === 503) return { text: `Données de marché indisponibles : ${msg}${err.detail && !msg.includes(err.detail) ? ' — ' + err.detail : ''}. Réessaie dans un instant.` };
  if (err && err.status === 429) return { text: 'Trop de requêtes pour le moment : attends une minute puis réessaie.' };
  if (err && err.status >= 500) return { text: `Erreur du serveur pendant le screening : ${msg}` };
  return { text: msg };
}
async function runScreening(force) {
  const btn = document.getElementById('scr-btn-screen');
  const btnForce = document.getElementById('scr-btn-screen-force');
  const status = document.getElementById('scr-screen-status');
  const tbody = document.getElementById('screen-tbody');
  btn.disabled = true;
  btnForce.disabled = true;
  // Durées mesurées le 11/9/2026 : ~2 s sur la watchlist, ~5 s sur les 219
  // titres de l'univers élargi. L'ancien message annonçait « 45-60 s »,
  // hérité du temps où chaque titre passait par le sidecar Python.
  status.textContent = UNIVERS_EN_COURS[universCourant] ?? UNIVERS_EN_COURS.watchlist;
  screeningBanner(null);
  tbody.innerHTML = '';
  try {
    const params = new URLSearchParams({ universe: universCourant });
    if (force) params.set('force', 'true');
    const data = await fetchJSON('/api/screening?' + params);
    lastScreeningRows = data.rows;
    if (data.signalAge) signalAgeSeuils = data.signalAge;
    renderScreeningRows();
    // Fire-and-forget (21/9/2026) : le graphique a sa propre gestion
    // d'erreur (voir loadScreeningPerformance) — un second appel réseau ne
    // doit ni bloquer ni retarder l'affichage du tableau ci-dessus.
    loadScreeningPerformance(data.rows);

    // Bug "univers élargi" (12/9/2026) : nommer la vraie cause quand le
    // plafond de sous-requêtes Cloudflare Workers a empêché d'analyser une
    // partie de l'univers, plutôt que de laisser un résultat maigre passer
    // pour "aucun setup aujourd'hui". `subrequestLimitCount` est absent en
    // local (jamais concerné) — `> 0` reste faux sur `undefined`.
    const subWarning = document.getElementById('scr-subrequest-warning');
    if (data.subrequestLimitCount > 0) {
      subWarning.textContent = `⚠ ${data.subrequestLimitCount} titre(s) sur ${data.universeSize} n'ont pas pu être analysés — limite de sous-requêtes Cloudflare Workers atteinte, pas un manque de setup. Réessaie dans quelques minutes (le cache se réchauffe progressivement), ou relance plus tard.`;
      subWarning.style.display = 'block';
    } else {
      subWarning.style.display = 'none';
    }

    // Balayage S&P 500 ancien : le résultat reste consultable, mais ses prix ont l'âge du balayage.
    if (data.universe === 'sp500' && data.cacheAgeSeconds > 3 * 3600) {
      screeningBanner(`Ce résultat vient d'un balayage vieux de ${Math.round(data.cacheAgeSeconds / 3600)} h : les prix et signaux ont cet âge. Relance le balayage (Réglages → TradingView) pour des données fraîches.`, 'watch');
    }
    const errCount = data.rows.filter((r) => r.verdict === 'erreur').length;
    const prets = data.rows.filter((r) => r.verdict === 'prêt').length;
    const heure = new Date(data.generatedAt).toLocaleTimeString('fr-CA');
    // Dire d'où sortent les lignes : « 18 candidats » n'a pas le même sens
    // selon qu'ils viennent de 22 titres ou de 219.
    const provenance = data.universeSize != null && data.retainedSize != null && data.universeSize !== data.retainedSize
      ? ` — ${data.retainedSize} retenu(s) sur ${data.universeSize} balayé(s)`
      : ` — ${data.rows.length} titre(s)`;
    status.textContent = `Screening du ${heure}`
      + (data.cached ? ' (cache)' : '')
      + provenance
      + (prets ? `, dont ${prets} « prêt »` : '')
      + (errCount ? ` — ${errCount} sans donnée.` : '.');
  } catch (err) {
    const why = screeningExplainError(err);
    status.textContent = 'Échec du screening.';
    screeningBanner(why.text, 'notready', why.action && why.action[0], why.action && why.action[1]);
    resetScreenChart(); // pas de graphique orphelin sur un screening en échec
  } finally {
    btn.disabled = false;
    btnForce.disabled = false;
  }
}
// ---- Témoin de statut backend (header) ----
async function checkStatus() {
  const dotBackend = document.getElementById('dot-backend');
  const dotMcp = document.getElementById('dot-mcp');
  const dotYahoo = document.getElementById('dot-yahoo');
  const lastCheck = document.getElementById('status-lastcheck');
  const issues = document.getElementById('status-issues');
  [dotBackend, dotMcp, dotYahoo].forEach((d) => { d.className = 'status-dot is-checking'; });
  try {
    const data = await fetchJSON('/api/status');
    dotBackend.className = 'status-dot ' + (data.backend ? 'is-ok' : 'is-down');
    // Trois états pour le sidecar, pas deux : connecté / en panne /
    // DÉSACTIVÉ. Sans le troisième, un testeur qui n'a jamais installé
    // Python — le cas par défaut depuis le 7/9/2026 — voyait une pastille
    // rouge permanente pour un composant dont l'app n'a plus besoin.
    if (data.tradingviewMcpDisabled) {
      dotMcp.className = 'status-dot is-off';
      dotMcp.title = data.tradingviewMcpDetail || 'Sidecar désactivé (optionnel)';
    } else {
      dotMcp.className = 'status-dot ' + (data.tradingviewMcp ? 'is-ok' : 'is-down');
      dotMcp.title = data.tradingviewMcp ? 'tradingview-mcp connecté' : (data.tradingviewMcpDetail || 'tradingview-mcp injoignable');
    }
    const techSidecar = document.getElementById('tech-sidecar');
    if (techSidecar) techSidecar.textContent = data.tradingviewMcpDisabled ? 'désactivé' : (data.tradingviewMcp ? 'actif' : 'erreur');
    dotYahoo.className = 'status-dot ' + (data.homemade ? 'is-ok' : 'is-down');
    dotYahoo.title = data.homemade ? 'Données de marché OK (Yahoo Finance)' : (data.homemadeDetail || 'Yahoo Finance injoignable');
    lastCheck.textContent = 'Vérifié à ' + new Date(data.checkedAt).toLocaleTimeString('fr-CA');

    // Détail explicite des pannes — un point rouge seul ne dit pas pourquoi.
    const problems = [];
    if (!data.db) problems.push(`Base de données : ${data.dbDetail || 'erreur inconnue'}`);
    // Un sidecar désactivé n'est pas un problème à signaler.
    if (!data.tradingviewMcp && !data.tradingviewMcpDisabled) problems.push(`tradingview-mcp : ${data.tradingviewMcpDetail || 'erreur inconnue'}`);
    if (!data.homemade) problems.push(`Données de marché (Yahoo Finance) : ${data.homemadeDetail || 'erreur inconnue'}`);
    if (problems.length) {
      issues.innerHTML = '<strong>⚠ Problème(s) technique(s) détecté(s) :</strong><br>' + problems.map((p) => '— ' + optEsc(p)).join('<br>');
      issues.style.display = 'block';
    } else {
      issues.style.display = 'none';
    }
  } catch (err) {
    [dotBackend, dotMcp, dotYahoo].forEach((d) => { d.className = 'status-dot is-down'; });
    // Deux pannes DIFFÉRENTES qu'il ne faut pas confondre (feature 351) :
    // le serveur ne répond pas du tout (réseau), ou il répond autre chose
    // que ce qu'on attend (page HTML, route inconnue). L'ancien message
    // annonçait « injoignable » dans les deux cas, ce qui envoyait chercher
    // un serveur éteint alors qu'il tournait parfaitement.
    const injoignable = err instanceof TypeError || /Failed to fetch|NetworkError|Load failed/i.test(err.message);
    if (injoignable) {
      lastCheck.textContent = 'Backend injoignable';
      issues.innerHTML = '<strong>⚠ Backend Express injoignable :</strong><br>'
        + `— ${optEsc(err.message)}<br>— Le serveur est-il lancé ? Double-clic sur <code>demarrer.command</code> (macOS) `
        + 'ou <code>demarrer.bat</code> (Windows), ou <code>npm start</code> dans le dossier castellana.';
    } else {
      lastCheck.textContent = 'Réponse inattendue du backend';
      issues.innerHTML = '<strong>⚠ Le backend répond, mais pas ce qui est attendu :</strong><br>'
        + `— ${optEsc(err.message)}`;
    }
    issues.style.display = 'block';
  }
}
// ---- Version installée et mise à jour ----
// Le zip téléchargé depuis iecho.ca devenait périmé EN SILENCE : un testeur
// n'avait aucun moyen de savoir que sa copie datait de trois semaines.
// Vérification tolérante : si le manifeste est injoignable, on n'affiche
// rien du tout — l'app fonctionne parfaitement sans, et un bandeau d'erreur
// pour ça serait du bruit.
let pendingUpdate = null;
async function checkVersion() {
  const banner = document.getElementById('update-banner');
  try {
    const info = await fetchJSON('/api/version?check=true');
    window.CASTELLANA_VERSION = info.version;
    // Carte « Cette installation » de Réglages → Technique : de quoi
    // répondre à « quelle version tournes-tu ? » sans ouvrir un terminal.
    const setTech = (id, value) => { const e = document.getElementById(id); if (e) e.textContent = value; };
    setTech('tech-version', info.version || '?');
    setTech('tech-url', location.host);
    if (!info.updateAvailable) { banner.style.display = 'none'; return; }
    pendingUpdate = info;
    banner.innerHTML =
      '<span class="update-banner__text">⬆ <strong>Version ' + optEsc(info.latest) + ' disponible</strong> '
      + '(vous utilisez la ' + optEsc(info.version || '?') + ').'
      + (info.notes ? '<br><span class="update-banner__notes">' + optEsc(info.notes) + '</span>' : '')
      + '</span>'
      + '<button type="button" class="ds-btn ds-btn--primary" onclick="applyUpdateNow(this)">Mettre à jour</button>';
    banner.style.display = 'flex';
  } catch {
    banner.style.display = 'none';
  }
}
async function applyUpdateNow(btn) {
  const banner = document.getElementById('update-banner');
  // Confirmation explicite : l'app va se réécrire elle-même et redémarrer.
  if (!confirm(
    'Installer la version ' + (pendingUpdate?.latest ?? '') + ' ?\n\n'
    + 'castellana va se mettre à jour puis redémarrer.\n'
    + 'Votre journal de trades et vos réglages ne sont pas touchés, et la '
    + 'version actuelle est conservée en sauvegarde.'
  )) return;
  btn.disabled = true;
  btn.textContent = 'Mise à jour…';
  try {
    const result = await fetchJSON('/api/update/apply', { method: 'POST' });
    banner.innerHTML = '<span class="update-banner__text">✅ <strong>Version ' + result.version
      + ' installée.</strong> castellana redémarre — cette page va se recharger.</span>';
    // Le serveur s'arrête juste après avoir répondu ; le watchdog du
    // launcher (port 4750) le relance. On sonde jusqu'à ce qu'il réponde
    // plutôt que de recharger à l'aveugle sur un serveur encore éteint.
    let attempts = 0;
    const poll = setInterval(async () => {
      attempts += 1;
      try {
        await fetch('/api/health', { cache: 'no-store' });
        clearInterval(poll);
        location.reload();
      } catch {
        if (attempts > 30) {
          clearInterval(poll);
          banner.innerHTML = '<span class="update-banner__text">✅ Mise à jour installée, mais castellana '
            + 'n\'a pas redémarré tout seul. Relancez <strong>demarrer.command</strong> '
            + '(macOS) ou <strong>demarrer.bat</strong> (Windows).</span>';
        }
      }
    }, 2000);
  } catch (err) {
    banner.innerHTML = '<span class="update-banner__text">❌ <strong>Mise à jour annulée :</strong> '
      + optEsc(err.message) + '<br><span class="update-banner__notes">Rien n\'a été modifié — '
      + 'castellana continue de fonctionner normalement.</span></span>';
  }
}

// Étapes de démarrage propres à la version locale (voir js/app-demarrage.js pour les points d'accroche).
const MODE_LOCAL = {
  apresLoadWeights: () => { checkVersion(); },
  apresInitLaboStrategies: () => { initTvLocal(); loadSweepNews(); },
  apresInitAiVisibility: () => {
    initRadarVisibility(); // révèle l'onglet Radar si radar_tab est ON
    initListAlertsTab(); // alertes sur les listes (local)
    initBacktestTab(); // backtest du signal (local)
  },
};
