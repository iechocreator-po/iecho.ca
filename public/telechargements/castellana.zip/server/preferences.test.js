// Tests des réglages utilisateur (feature 351). Utilise la vraie base, avec
// remise à l'état initial après coup pour ne pas laisser les préférences de
// JP modifiées par une exécution de tests.

import test from 'node:test';
import assert from 'node:assert/strict';
import { getPreferences, setPreferences, resetPreferences, indicatorOptions, DEFAULTS } from './preferences.js';

const initial = getPreferences();
test.after(() => { resetPreferences(); setPreferences(initial); });

test('sans réglage enregistré, on obtient les valeurs par défaut', () => {
  resetPreferences();
  assert.deepEqual(getPreferences(), DEFAULTS);
});

test('les valeurs par défaut sont celles demandées dans la feature 351', () => {
  // 9 / 21 / 50 et RSI 14 — la lente à 50 est un écart assumé avec le
  // document de design (qui dit 100), demandé explicitement par JP.
  assert.deepEqual(DEFAULTS, { smaFast: 9, smaMedium: 21, smaSlow: 50, rsiPeriod: 14 });
});

test('un réglage valide est enregistré et relu', () => {
  resetPreferences();
  const out = setPreferences({ smaFast: 5, smaMedium: 20, smaSlow: 60, rsiPeriod: 21 });
  assert.deepEqual(out, { smaFast: 5, smaMedium: 20, smaSlow: 60, rsiPeriod: 21 });
  assert.deepEqual(getPreferences(), out);
});

test('un ordre incohérent est refusé avec un message explicite', () => {
  // Sans ce contrôle, rapide > moyenne rendrait l'alignement haussier
  // silencieusement inatteignable — un réglage accepté qui casse un signal.
  resetPreferences();
  assert.throws(() => setPreferences({ smaFast: 50, smaMedium: 21, smaSlow: 9 }), /plus courte à la plus longue/);
  assert.deepEqual(getPreferences(), DEFAULTS, 'rien ne doit avoir été écrit');
});

test('une valeur non entière ou hors bornes est refusée', () => {
  resetPreferences();
  for (const patch of [{ rsiPeriod: 'abc' }, { rsiPeriod: 0 }, { rsiPeriod: 1 }, { smaFast: 9999 }, { smaFast: -3 }]) {
    assert.throws(() => setPreferences(patch), /n'est pas un entier/);
  }
  assert.deepEqual(getPreferences(), DEFAULTS);
});

test('une clé inconnue est ignorée sans faire échouer le reste', () => {
  resetPreferences();
  const out = setPreferences({ rsiPeriod: 20, couleurPreferee: 'bleu' });
  assert.equal(out.rsiPeriod, 20);
  assert.ok(!('couleurPreferee' in out));
});

test('réinitialiser efface les réglages plutôt que d’y réécrire les défauts', () => {
  // Nuance qui compte : si les défauts changent un jour, un utilisateur qui
  // a « réinitialisé » doit suivre le NOUVEAU défaut, pas rester figé.
  setPreferences({ smaFast: 3, smaMedium: 8, smaSlow: 30 });
  assert.deepEqual(resetPreferences(), DEFAULTS);
});

test('indicatorOptions produit la forme attendue par getHomemadeIndicators', () => {
  resetPreferences();
  assert.deepEqual(indicatorOptions(), {
    periods: { fast: 9, medium: 21, slow: 50 },
    rsiPeriod: 14,
  });
});
