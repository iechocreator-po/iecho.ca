import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeSearchQuery, mapSearchResults } from './symbol-search.js';

test('normalizeSearchQuery convertit la notation TradingView en notation Yahoo', () => {
  assert.equal(normalizeSearchQuery('BRK.B'), 'BRK-B');
  assert.equal(normalizeSearchQuery(' brk.a '), 'BRK-A');
  assert.equal(normalizeSearchQuery('BF/B'), 'BF-B');
});
test('normalizeSearchQuery ne touche ni les suffixes de bourse ni les noms', () => {
  assert.equal(normalizeSearchQuery('XEQT.TO'), 'XEQT.TO');
  assert.equal(normalizeSearchQuery('SHOP.V'), 'SHOP.V');
  assert.equal(normalizeSearchQuery('berkshire'), 'berkshire');
  assert.equal(normalizeSearchQuery(null), '');
});
test('mapSearchResults écarte options, contrats à terme et lignes vides', () => {
  const quotes = [
    { symbol: 'BRK-B', shortname: 'Berkshire', quoteType: 'EQUITY', exchDisp: 'NYSE' },
    { symbol: 'SBRKB=F', quoteType: 'FUTURE' },
    { symbol: 'BRKB261016C00510000', quoteType: 'OPTION' },
    { symbol: 'OMAH', shortname: 'Target 15', quoteType: 'ETF', exchDisp: 'NYSEArca' },
    {},
  ];
  const all = mapSearchResults(quotes, 'all');
  assert.deepEqual(all.map((r) => r.symbol), ['BRK-B', 'OMAH']);
  assert.equal(all[0].typeLabel, 'Action');
  assert.deepEqual(mapSearchResults(quotes, 'stocks').map((r) => r.symbol), ['BRK-B']);
  assert.deepEqual(mapSearchResults(quotes, 'funds').map((r) => r.symbol), ['OMAH']);
  assert.deepEqual(mapSearchResults(quotes, 'indices'), []);
});
