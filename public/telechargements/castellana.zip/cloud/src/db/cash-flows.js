// cloud/src/db/cash-flows.js — portage D1 de server/cash-flows.js (voir ce fichier), isolé par user_id.
// Table créée par scripts/migrate-roue.mjs (#433).
import { isValidTicker, TICKER_ERROR } from '../lib/ticker-format.js';

export const CASH_FLOW_TYPES = ['depart', 'depot', 'retrait', 'dividende', 'autre_revenu'];
const COMPTES = ['RRSP', 'margin', 'corporatif'];
const SOURCES = ['saisie', 'import_sheets'];

export function validateCashFlow(d = {}) {
  const errors = [];
  if (!COMPTES.includes(d.compte)) errors.push(`compte doit être l'un de : ${COMPTES.join(', ')}`);
  if (!CASH_FLOW_TYPES.includes(d.type)) errors.push(`type doit être l'un de : ${CASH_FLOW_TYPES.join(', ')}`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(d.date || '')) || !Number.isFinite(Date.parse(d.date))) errors.push('date doit être au format AAAA-MM-JJ');
  if (!(Number(d.montant) > 0)) errors.push('montant doit être positif (le type donne le signe)');
  if (d.ticker != null && d.ticker !== '' && !isValidTicker(String(d.ticker))) errors.push(TICKER_ERROR);
  if (d.cycle_id != null && d.cycle_id !== '' && !(Number.isInteger(Number(d.cycle_id)) && Number(d.cycle_id) > 0)) errors.push('cycle_id invalide');
  if (d.source != null && !SOURCES.includes(d.source)) errors.push(`source doit être l'un de : ${SOURCES.join(', ')}`);
  return errors;
}

function clean(d) {
  return {
    compte: d.compte, date: d.date, type: d.type, montant: Number(d.montant),
    ticker: d.ticker ? String(d.ticker).trim().toUpperCase() : null,
    cycle_id: d.cycle_id == null || d.cycle_id === '' ? null : Number(d.cycle_id),
    notes: d.notes ? String(d.notes) : null,
    source: d.source || 'saisie',
  };
}

export async function listCashFlows(db, userId, { compte } = {}) {
  const { results } = compte
    ? await db.prepare('SELECT * FROM cash_flows WHERE user_id = ? AND compte = ? ORDER BY date ASC, id ASC').bind(userId, compte).all()
    : await db.prepare('SELECT * FROM cash_flows WHERE user_id = ? ORDER BY date ASC, id ASC').bind(userId).all();
  return results;
}

export async function createCashFlow(db, userId, raw) {
  const errors = validateCashFlow(raw);
  if (errors.length) throw Object.assign(new Error(errors.join(' ')), { status: 400 });
  const d = clean(raw);
  if (d.cycle_id != null) {
    const own = await db.prepare('SELECT id FROM option_cycles WHERE id = ? AND user_id = ?').bind(d.cycle_id, userId).first();
    if (!own) throw Object.assign(new Error('Cycle introuvable'), { status: 404 });
  }
  const info = await db.prepare('INSERT INTO cash_flows (user_id, compte, date, type, montant, ticker, cycle_id, notes, source) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .bind(userId, d.compte, d.date, d.type, d.montant, d.ticker, d.cycle_id, d.notes, d.source).run();
  return db.prepare('SELECT * FROM cash_flows WHERE id = ? AND user_id = ?').bind(info.meta.last_row_id, userId).first();
}

export async function deleteCashFlow(db, userId, id) {
  const info = await db.prepare('DELETE FROM cash_flows WHERE id = ? AND user_id = ?').bind(id, userId).run();
  return info.meta.changes > 0;
}
