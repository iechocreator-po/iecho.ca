// Journal de la Roue (#433) — calculs repris du Google Sheets du club, recoupés avec ses
// formules (colonnes O, P, R du JOURNAL ; RAPPORT HEBDO ; DASHBOARD ; PORTFOLIO C28 à C34).
import test from 'node:test';
import assert from 'node:assert/strict';
import {
  optLegPnl, optLegReturn, optLegIssues, optWeekStart, optWeekYear, optWeeklyReport,
  optAccountSnapshot, optAnnualDashboard, optMaxPricePerTicker, optCycleBilan,
} from './options-analytics.js';
import { validateOptionTrade } from './option-trades.js';

const near = (a, b, eps = 1e-9) => assert.ok(Math.abs(a - b) < eps, `${a} ≠ ${b}`);
// Ligne d'exemple LULU du Sheets, dates corrigées (le Sheets portait 26/12/2026 → 02/01/2026).
const LULU = { type: 'put', ticker: 'LULU', strike: 205, contrats: 1, prime_recue: 1.4, commission_ouverture: 1, statut: 'expire', date_ouverture: '2025-12-26', echeance: '2026-01-02', date_cloture: '2026-01-02' };

test('P/L net d\'une jambe = colonne O du Sheets : (prime − rachat) × 100 × qté − commissions', () => {
  assert.equal(optLegPnl(LULU), 139);                                         // Sheets : 139
  const rachetee = { ...LULU, statut: 'rachete', prime_cloture: 0.4, commission_cloture: 1 };
  near(optLegPnl(rachetee), 140 - 40 - 2);                                    // le Sheets oubliait la 2e commission
  assert.equal(optLegPnl({ ...LULU, commission_ouverture: null }), 140);      // commission non renseignée : rien retiré
});

test('rendement annualisé = colonne P : P/L ÷ (strike × 100 × qté) × 365 ÷ jours', () => {
  const r = optLegReturn(LULU);
  assert.equal(r.jours, 7);
  assert.equal(r.capital, 20500);
  near(r.rendementAnnualise, (139 / 20500) * (365 / 7));
});

test('dates incohérentes : signalées, et pas de rendement annualisé (le Sheets forçait 1 jour)', () => {
  const faute = { ...LULU, date_ouverture: '2026-12-26' };                   // la vraie ligne du Sheets
  assert.deepEqual(optLegIssues(faute), ['échéance avant l\'ouverture', 'clôture avant l\'ouverture']);
  assert.equal(optLegReturn(faute).rendementAnnualise, null);
  assert.deepEqual(optLegIssues(LULU), []);
  assert.deepEqual(optLegIssues({ ...LULU, date_cloture: null }), ['jambe close sans date de clôture']);
});

test('semaine dimanche → samedi, rattachée à l\'année de son vendredi (table Semaines du Sheets)', () => {
  assert.equal(optWeekStart('2026-01-02'), '2025-12-28');                    // « Semaine 1 : 28 déc. au 3 janv. »
  assert.equal(optWeekStart('2025-12-28'), '2025-12-28');
  assert.equal(optWeekStart('2026-01-03'), '2025-12-28');
  assert.equal(optWeekStart('2026-01-04'), '2026-01-04');
  assert.equal(optWeekYear('2025-12-28'), 2026);
  assert.equal(optWeekStart('pas une date'), null);
});

test('rapport hebdo : semaine 1 du Sheets → profit 139, valeur 100 139, ROI 0,139 %', () => {
  const cashFlows = [{ type: 'depart', date: '2025-12-28', montant: 100000 }];
  const [s1] = optWeeklyReport({ legs: [LULU], cashFlows });
  assert.equal(s1.semaine, '2025-12-28');
  assert.equal(s1.profitNet, 139);
  assert.equal(s1.valeurCompteRealisee, 100139);                              // RAPPORT HEBDO O5 : 100139
  near(s1.roiHebdo, 139 / 100000);
  assert.equal(s1.nbTrades, 1);
  assert.equal(s1.nbAssignations, 0);
  assert.equal(s1.pctAssignation, 0);
  assert.equal(s1.valeurPutsVendus, 20500);
  assert.equal(s1.commissions, 1);
});

test('rapport hebdo : semaines vides comblées, dépôts/retraits signés, dividendes, assignations, jambe ouverte exclue', () => {
  const legs = [
    LULU,
    { type: 'put', ticker: 'AMD', strike: 100, contrats: 2, prime_recue: 1, statut: 'assigne', date_ouverture: '2026-01-12', echeance: '2026-01-16', date_cloture: '2026-01-16' },
    { type: 'put', ticker: 'AMD', strike: 90, contrats: 1, prime_recue: 2, statut: 'ouvert', date_ouverture: '2026-01-13', echeance: '2026-02-20' },
  ];
  const cashFlows = [
    { type: 'depart', date: '2025-12-28', montant: 100000 },
    { type: 'depot', date: '2026-01-12', montant: 1000 },
    { type: 'retrait', date: '2026-01-13', montant: 500 },                    // montant positif, le type donne le signe
    { type: 'dividende', date: '2026-01-14', montant: 20, ticker: 'AMD' },
    { type: 'autre_revenu', date: '2026-01-15', montant: 5 },
  ];
  const w = optWeeklyReport({ legs, cashFlows });
  assert.deepEqual(w.map((x) => x.semaine), ['2025-12-28', '2026-01-04', '2026-01-11']);
  assert.equal(w[1].profitNet, 0);
  assert.equal(w[1].valeurCompteRealisee, 100139);
  const s3 = w[2];
  assert.equal(s3.depotsRetraits, 500);
  assert.equal(s3.profitOptions, 200);                                        // la jambe ouverte n'y est pas
  assert.equal(s3.dividendes, 20);
  assert.equal(s3.profitNet, 220);
  assert.equal(s3.nbAssignations, 1);
  assert.equal(s3.pctAssignation, 1);
  near(s3.roiHebdo, 220 / (100139 + 500));                                    // Sheets : D ÷ (valeur préc. + dépôts)
  assert.equal(s3.valeurCompteRealisee, 100139 + 500 + 220 + 5);
  assert.equal(s3.profitCumule, 359);
});

test('sans capital de départ saisi : valeur et ROI null (N/D), le profit reste calculé', () => {
  const [s1] = optWeeklyReport({ legs: [LULU] });
  assert.equal(s1.profitNet, 139);
  assert.equal(s1.valeurCompteRealisee, null);
  assert.equal(s1.roiHebdo, null);
  assert.deepEqual(optWeeklyReport({}), []);
});

test('gain sur actions revendues dans le profit de la semaine, commissions d\'achat et de vente déduites', () => {
  const stock = [{ ticker: 'AMD', prix_entree: 100, taille_position: 100, date_sortie: '2026-02-20', prix_sortie: 105, commission_entree: 1, commission_sortie: 1 }];
  const [s] = optWeeklyReport({ stockTrades: stock });
  assert.equal(s.profitActions, 498);
  assert.equal(s.commissions, 2);
});

test('capital : puts ouverts + actions au coût = immobilisé ; disponible et valeur du compte', () => {
  const legs = [{ type: 'put', ticker: 'AMD', strike: 90, contrats: 1, prime_recue: 2, statut: 'ouvert', date_ouverture: '2026-01-13', echeance: '2026-02-20' }];
  const stock = [{ ticker: 'LULU', prix_entree: 200, taille_position: 100, date_sortie: null }];
  const cashFlows = [{ type: 'depart', date: '2026-01-04', montant: 50000 }];
  const sans = optAccountSnapshot({ legs, stockTrades: stock, cashFlows });
  assert.equal(sans.capitalImmobilise, 9000 + 20000);
  assert.equal(sans.capitalDisponible, 50000 - 29000);
  assert.equal(sans.latentActions, null);                                      // pas de cours : N/D
  assert.equal(sans.valeurCompte, null);
  const avec = optAccountSnapshot({ legs, stockTrades: stock, cashFlows, prices: { LULU: 190 } });
  assert.equal(avec.latentActions, -1000);
  assert.equal(avec.valeurCompte, 49000);
});

test('tableau annuel : profit réalisé, réel ajusté (call dans la monnaie), taux, mois, ticker, secteur', () => {
  const legs = [
    LULU,
    { type: 'put', ticker: 'AMD', strike: 100, contrats: 1, prime_recue: 1, statut: 'assigne', date_ouverture: '2026-01-12', echeance: '2026-01-16', date_cloture: '2026-01-16' },
    { type: 'call', ticker: 'AMD', strike: 105, contrats: 1, prime_recue: 1, statut: 'ouvert', date_ouverture: '2026-01-20', echeance: '2026-02-20' },
  ];
  const stock = [{ ticker: 'AMD', prix_entree: 100, taille_position: 100, date_sortie: null }];
  const cashFlows = [{ type: 'depart', date: '2025-12-28', montant: 100000 }];
  const d = optAnnualDashboard({ legs, stockTrades: stock, cashFlows, year: 2026, prices: { AMD: 110 }, sectors: { AMD: 'Technology' }, today: '2026-03-01' });
  assert.equal(d.profitRealise, 239);
  assert.equal(d.excesCallsDansLaMonnaie, 500);                               // (110 − 105) × 100
  assert.equal(d.profitReelAjuste, 239 + 1000 - 500);
  assert.equal(d.tauxSucces, 1);
  assert.equal(d.tauxAssignation, 0.5);
  assert.equal(d.profitMensuel[0], 239);
  assert.deepEqual(d.parTicker.map((x) => x.cle), ['LULU', 'AMD']);
  assert.deepEqual(d.parSecteur.map((x) => x.cle).sort(), ['Non renseigné', 'Technology']);
  assert.equal(d.rendementAnnualiseProjete, null);                            // 3 semaines seulement (< 4)
  assert.equal(optAnnualDashboard({ legs, stockTrades: stock, cashFlows, year: 2026, today: '2026-03-01' }).profitReelAjuste, null);
});

test('prix maximum par titre = PORTFOLIO C32 : capital × % × baisse ÷ (100 × (1 − (1 − baisse)^(n+1)))', () => {
  const r = optMaxPricePerTicker({ capital: 100000, pctMax: 0.1, nbAverage: 2, pctBaisse: 0.1 });
  near(r.prixMax, (100000 * 0.1 * 0.1) / (100 * (1 - 0.9 ** 3)));            // ≈ 36,90 $
  near(r.capitalTotal, 10000, 1e-6);                                           // C33 retombe sur le budget
  near(r.coutMoyen, 10000 / 300, 1e-6);                                        // C34
  assert.equal(r.paliers.length, 3);
  near(optMaxPricePerTicker({ capital: 100000, pctMax: 0.1, nbAverage: 0, pctBaisse: 0 }).prixMax, 100);
  assert.equal(optMaxPricePerTicker({ capital: 0, pctMax: 0.1, pctBaisse: 0.1 }), null);
  assert.equal(optMaxPricePerTicker({ capital: 1000, pctMax: 0.1, nbAverage: 1.5, pctBaisse: 0.1 }), null);
});

test('bilan de cycle : pnl et vsHold inchangés, frais et dividendes dans pnlNet et coutDeBaseNet', () => {
  const cycle = { statut: 'actif', legs: [{ type: 'put', strike: 100, contrats: 1, prime_recue: 3, statut: 'assigne', date_ouverture: '2026-01-02', date_cloture: '2026-02-01', commission_ouverture: 1, commission_cloture: 4 }] };
  const stock = [{ prix_entree: 100, taille_position: 100, date_sortie: null, commission_entree: null }];
  const b = optCycleBilan(cycle, { stockTrades: stock, priceStart: 100, priceEnd: 96, today: '2026-04-02', cashFlows: [{ type: 'dividende', montant: 25 }, { type: 'depot', montant: 999 }] });
  assert.equal(b.pnl, -100);                                                   // comme avant #433
  assert.equal(b.coutDeBase, 97);
  assert.equal(b.commissions, 5);
  assert.equal(b.dividendes, 25);                                              // le dépôt n'est pas un dividende
  assert.equal(b.pnlNet, -80);
  assert.equal(b.coutDeBaseNet, (10000 - (300 - 5 + 25)) / 100);              // coût moyen par action du Sheets
});

test('validation : commissions ≥ 0 ou absentes, source connue', () => {
  const V = { type: 'put', ticker: 'AMD', compte: 'margin', strike: 100, echeance: '2026-10-16', prime_recue: 1.5, date_ouverture: '2026-09-22' };
  assert.deepEqual(validateOptionTrade({ ...V, commission_ouverture: 0.65, source: 'import_sheets' }), []);
  assert.deepEqual(validateOptionTrade({ ...V, commission_ouverture: null }), []);
  assert.ok(validateOptionTrade({ ...V, commission_ouverture: -1 }).length > 0);
  assert.ok(validateOptionTrade({ ...V, source: 'excel' }).length > 0);
});

test('flux de trésorerie : montant positif, type et compte connus, date AAAA-MM-JJ', async () => {
  const { validateCashFlow } = await import('./cash-flows.js');
  const ok = { compte: 'margin', type: 'depart', date: '2026-01-04', montant: 100000 };
  assert.deepEqual(validateCashFlow(ok), []);
  assert.ok(validateCashFlow({ ...ok, montant: -500 }).length > 0);             // un retrait se saisit en type, pas en signe
  assert.ok(validateCashFlow({ ...ok, type: 'frais' }).length > 0);
  assert.ok(validateCashFlow({ ...ok, compte: 'CELI' }).length > 0);
  assert.ok(validateCashFlow({ ...ok, date: '04/01/2026' }).length > 0);
  assert.ok(validateCashFlow({ ...ok, cycle_id: 'abc' }).length > 0);
});
