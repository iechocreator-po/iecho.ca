#!/usr/bin/env node
// Migration idempotente (13/10/2026, bilbao #433) — Journal de la Roue du club : commissions,
// lien de roulement et provenance sur option_trades et trades (ALTER, précédé de PRAGMA table_info
// pour rester rejouable), et la table cash_flows (CREATE TABLE IF NOT EXISTS). Aucune donnée
// existante n'est touchée ; schema.sql reste la source de vérité pour une installation neuve.
//
// ⚠️ À lancer en --remote AVANT `wrangler deploy`, puis vérifier avec la sortie PRAGMA/sqlite_master
// affichée à la fin — pas sur le seul message « Terminé ».
//
// Usage :
//   node scripts/migrate-roue.mjs             (D1 local)
//   node scripts/migrate-roue.mjs --remote    (vrai D1)

import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const remote = process.argv.includes('--remote');
const flag = remote ? '--remote' : '--local';

function run(sql, { json = false } = {}) {
  const args = ['wrangler', 'd1', 'execute', 'castellana-db', flag, '--command', sql];
  if (json) args.push('--json');
  const result = spawnSync('npx', args, { cwd: ROOT, stdio: json ? ['ignore', 'pipe', 'pipe'] : 'inherit' });
  if (result.status !== 0) {
    console.error(json ? result.stderr?.toString() : '');
    throw new Error(`Échec de la commande wrangler (SQL: ${sql})`);
  }
  return json ? JSON.parse(result.stdout.toString()) : null;
}

function existingColumns(table) {
  const out = run(`PRAGMA table_info(${table})`, { json: true });
  return new Set(out[0].results.map((c) => c.name));
}

const AJOUTS = {
  option_trades: { commission_ouverture: 'REAL', commission_cloture: 'REAL', roule_vers_id: 'INTEGER', source: 'TEXT' },
  trades: { commission_entree: 'REAL', commission_sortie: 'REAL', source: 'TEXT' },
};

console.log(`\nMigration Journal de la Roue (${remote ? 'D1 distant' : 'D1 local'})...`);
for (const [table, cols] of Object.entries(AJOUTS)) {
  const existantes = existingColumns(table);
  for (const [nom, type] of Object.entries(cols)) {
    if (existantes.has(nom)) { console.log(`- ${table}.${nom} : déjà présente`); continue; }
    console.log(`- ${table}.${nom} : ajout`);
    run(`ALTER TABLE ${table} ADD COLUMN ${nom} ${type}`);
  }
}

console.log('- création de cash_flows (si absente)');
run(`CREATE TABLE IF NOT EXISTS cash_flows (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  compte TEXT NOT NULL CHECK (compte IN ('RRSP','margin','corporatif')),
  date TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('depart','depot','retrait','dividende','autre_revenu')),
  montant REAL NOT NULL,
  ticker TEXT,
  cycle_id INTEGER REFERENCES option_cycles(id),
  notes TEXT,
  source TEXT,
  date_creation TEXT NOT NULL DEFAULT (datetime('now'))
)`);
run('CREATE INDEX IF NOT EXISTS idx_cash_flows_user ON cash_flows(user_id, compte, date)');

let ok = true;
for (const [table, cols] of Object.entries(AJOUTS)) {
  const presentes = existingColumns(table);
  for (const nom of Object.keys(cols)) if (!presentes.has(nom)) { ok = false; console.error(`MANQUANTE : ${table}.${nom}`); }
}
const t = run("SELECT name FROM sqlite_master WHERE name IN ('cash_flows','idx_cash_flows_user')", { json: true });
if (t[0].results.length !== 2) { ok = false; console.error('MANQUANTE : cash_flows ou son index'); }
console.log(ok ? 'Vérifié : toutes les colonnes et la table cash_flows sont présentes.' : 'ÉCHEC de la vérification (voir ci-dessus).');
process.exit(ok ? 0 : 1);
