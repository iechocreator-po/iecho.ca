# Pièges de castellana (lus par la skill `/revue-code`)

Fichier propre à ce produit. La méthode (passes, notes, rapport) est dans la skill commune
`2000_DigitalProducts/skills/revue-code/`. Chaque piège ci-dessous est une erreur **réellement arrivée** ici ;
les détails sont dans `CLAUDE.md` (6 300 lignes : chercher avec `grep`, ne pas lire en entier).

## Commandes mécaniques

Dossier de travail : `trading-assistant/`. Un échec est un constat à 100.

```bash
npm test                                    # server/*.test.js ET cloud/src/**/*.test.js (inclut browser-globals.test.js)
node scripts/sync-cloud-copies.mjs --check  # copies cloud générées en retard ? (sort en 1 si dérive)
npm run test:smoke                          # vrai Chrome : pages chargées, onglets cliqués, pannes injectées détectées (~45 s)
```

- `npm run test:smoke` est **à lancer si le diff touche `index.html`, `cloud/public/index.html` ou un fichier de `js/`** (c'est
  lui qui voit une accolade en trop ou un nom global dupliqué). Il est ignoré, avec un message, si Chrome est introuvable :
  « ignoré » n'est pas « réussi », à signaler dans « Non vérifié ».

- Si `cloud/` est touché : `cd cloud && npx wrangler deploy --dry-run` (ne déploie rien).
- Ne pas démarrer le serveur ni toucher au port 4700 (l'app locale de JP tourne peut-être). Ne pas lire `data/`.

## Avant de pousser (bloc du rapport avant-push)

- Migration distante à lancer d'abord (`cloud/scripts/migrate-*.mjs --remote`, puis vérifier par `sqlite_master`) : oui/non, laquelle.
- Repères d'interface décalés (carte ajoutée ou retirée) : oui/non.
- Copie cloud : à synchroniser (`npm run sync:cloud`) / faite / sans objet.
- Déploiement : `wrangler deploy` est un geste séparé, jamais fait par la revue.

- Si le diff touche la séquence de démarrage : `node scripts/snapshot-boot.mjs <fichier.json>` avant puis après, puis `--compare` (ordre
  d'émission des appels d'API ; tout écart doit être voulu et expliqué). Une étape propre à un mode s'accroche à `demarrerApp()`
  (`js/app-demarrage.js`), jamais en recopiant la séquence.
- Si le diff déplace du code entre fichiers JS : `node scripts/snapshot-globals.mjs <fichier.json>` avant puis après, puis `--compare` ;
  0 différence attendue pour un déplacement pur.
- Si le diff touche le CSS ou la structure des pages : photographier les styles avant/après avec
  `node scripts/snapshot-styles.mjs <fichier.json>` (puis `--compare`) ; 0 différence attendue pour un refactor.

## Pièges (passe A)

1. **Copie cloud oubliée.** castellana existe en deux versions : local (`index.html`, `js/`, `server/`) et cloud
   (`cloud/public/index.html`, `cloud/public/js/`, `cloud/src/`). Un changement d'interface fait d'un côté seulement est
   un oubli, sauf fonctionnalité « local seulement » (S&P 500, Radar, IA, balayage planifié). Les copies générées passent
   par `npm run sync:cloud` ; ne jamais éditer à la main `cloud/src/lib/{labo-schema,concepts-data,options-analytics}.js` ni
   `cloud/public/css/app.css` (copie de `css/app.css`). Les règles CSS propres à un mode vont dans `css/mode-local.css` ou
   `css/mode-cloud.css` ; plus aucun bloc `<style>` dans les pages (`server/css-parity.test.js`).
2. **Route avalée.** Express (`server/index.js`) et Hono (`cloud/src/routes/*.js`) résolvent par **ordre d'enregistrement** :
   une route fixe (`/api/options/premium-screener`, `/api/labo/params`, `/api/option-cycles/bilans`) doit être déclarée
   **avant** la route à paramètre (`/:ticker`, `/:id`). Vérifier les deux côtés.
3. **Réponse reconstruite.** Les routes `/api/sectors` (et d'autres) **reconstruisent** la réponse : un champ ajouté à la
   fonction source est perdu en silence si la route ne le recopie pas. Vérifier qu'un champ nouveau traverse la route
   **Express et Hono**.
4. **Clé de cache non versionnée.** Si la FORME d'un objet mis en cache change, la clé doit changer (`fundamentals:v2:`,
   `sectors:perf:v2:`). Chercher aussi les lectures « en brut » de la clé (`routes/market.js`, `server/index.js`).
5bis. **Ordre de chargement des scripts.** Le code des pages est dans des scripts classiques : `js/mode-*.js` d'abord, puis `js/app-*.js`,
    puis `js/app-init.js` (énoncés exécutés au chargement), puis le démarrage en ligne. Une déclaration de fonction n'est plus « hissée »
    d'un fichier à l'autre : un énoncé exécuté au chargement ne peut nommer que ce qui est déjà chargé (cas `renderSectorTopRows`,
    20/10). Les fichiers communs `js/app-*.js` se modifient dans `js/` seulement (copie cloud par `npm run sync:cloud`).
5. **Nom global dupliqué.** Les fichiers `js/` sont des **scripts classiques** à portée globale partagée : deux
   déclarations de même nom (ou un `const x` après un `function x`) cassent un fichier entier sans erreur visible (cas
   `optNum`, 13/10). `browser-globals.test.js` l'attrape seulement pour les scripts listés dans les `<script src>` des
   deux `index.html` : **un nouveau fichier JS doit être ajouté aux deux pages**.
6. **Syntaxe cassée dans un script d'onglet.** L'onglet disparaît alors que les tests unitaires passent (cas `roue-tab.js`, 17/10).
7. **Repères d'interface.** Dérivés de l'ordre réel du DOM : insérer ou retirer une carte décale tous les repères
   suivants (à noter dans `CLAUDE.md`). Rendus en CSS pur (`::before` piloté par un attribut) : ne pas ajouter de nœud
   enfant, plusieurs cartes réécrivent leur `innerHTML`.
8. **Un 0 qui ment.** Une donnée absente affiche « N/D » / « — » / `null`, **jamais 0** ni une valeur de démonstration
   en dur. Chercher `|| 0`, `?? 0`, `Number(x) || 0` sur des prix, cours, IV, rendements.
9. **Approximation non étiquetée.** Tout chiffre estimé (ATR, expected move, P/E d'industrie, delta) est étiqueté comme
   tel à l'écran. Aucune « donnée de marché » inventée.
10. **Secrets.** Rien de `.env`, `.dev.vars`, clé Resend/Claude/TradingView, jeton, mot de passe, courriel de testeur, ni
    donnée des membres du club (`anticipation/*.xlsx|csv`) dans le code. Les clés ne partent jamais dans une URL ni un
    `console.log`. Le plan envoyé à l'IA reste en pourcentages (aucun montant).
11. **Drapeaux et comptes.** Un nouvel onglet ou une fonction à risque passe par un feature flag **OFF par défaut**,
    surchargeable par compte (`user_feature_flags`), sauf demande contraire de JP.
12. **Suppression = désactivation.** Un compte n'est jamais supprimé en dur (clés étrangères D1 sur
    trades/watchlist/preferences).
    **Et désactiver = tout fermer** : `disableUserAndRevoke` / `resetPasswordAndRevoke` (`cloud/src/db/users.js`) ferment les sessions
    ouvertes et invalident les liens de connexion ; `findSession` refuse un compte désactivé. Une route d'admin qui ne fait que
    `setDisabled` / `resetPassword` laisse une session vivre 30 jours (audit cloud-comptes, 20/10/2026).
13. **Erreurs avalées.** `catch {}` vide, ou `JSON.parse` sur une réponse qui peut être la page HTML d'Express
    (« Unexpected token '<' »). Un `catch` doit gérer ou remonter.
14. **Cloudflare.** Plan gratuit : 50 sous-requêtes par invocation. Une boucle de `fetch` Yahoo sur un univers large côté
    `cloud/` est un bug (d'où « local seulement » pour Radar et S&P 500). Yahoo depuis un Worker : instance par requête.
15. **Design system.** Pas de modification de `tokens.css` (surcharge locale à la place) ; classes `.ds-*` plutôt que du
    CSS dupliqué ; couleurs via variables sémantiques.
16. **`.gitignore`.** Un motif de dossier sans `/` de tête attrape aussi les dossiers enfants. Vérifier avec
    `git check-ignore -v` qu'aucun fichier servi n'est exclu.
17. **Règles de trading.** Latent mesuré contre le **coût de base net des primes**, jamais contre le strike ; un dépôt
    n'est pas du rendement ; annualisation seulement à partir de 30 jours ; rendement d'une option calculé sur la valeur
    **extrinsèque**, pas le bid brut ; aucun « taux de succès » affiché.
    **La taille d'une position est plafonnée par le capital** (`CFG.sizing.positionMaxPct`, défaut 100 % ; `computeSizing` dans
    `js/sizing.js`, seule source) : le risque seul ne borne pas la position, un titre calme sortait à 133 % du capital (audit
    formules, 20/10/2026). Tout nouveau calcul de taille doit passer par `computeSizing`, jamais le recalculer à côté.
    **Les « années » du tableau de bord de la Roue : une seule définition, `optPeriodOf` (js/options-analytics.js)** = année ET mois du
    VENDREDI de la semaine (convention du Sheets du club). Toute carte qui range un événement par année ou par mois doit l'utiliser, jamais
    `getUTCFullYear()` / `getUTCMonth()` sur la date brute : autour du 1er janvier, les cartes se contredisaient (audit formules, constat 2).
21. **Étiquette de l'OBV.** Source unique : `obvTrendFrom` dans `server/obv-trend.js` (copie cloud octet pour octet), utilisée par
    `classifyOBV` (serveur et cloud) et par `server/dataset.js`. Accumulation = prix ET OBV montent ; distribution = le prix monte mais
    l'OBV baisse ; neutre = le reste, prix en baisse compris. Avant (audit donnees-marche, 20/10/2026), « même signe = accumulation »
    classait un repli avec OBV qui baisse en accumulation (+1 au contexte, verdict « prêt »). Ne jamais recopier la comparaison de signes.
18. **Noms d'utilisateur.** Règle unique : lettres, chiffres, `.`, `-`, `_`, 2 à 30 caractères, minuscules. Elle vit dans
    `cloud/src/routes/admin.js` **et** `cloud/scripts/create-user.mjs` : les deux doivent rester alignés.

19. **Fichiers servis par le serveur local.** `server/http-guard.js` : `hostGuard()` (403 si l'en-tête Host n'est pas 127.0.0.1 / localhost / [::1],
    anti « DNS rebinding ») et `publicFiles()` (liste explicite : `PUBLIC_FILES`, `PUBLIC_DIRS`). Jamais `express.static(<racine du projet>)` :
    il exposait la base de données du journal, `settings.json`, le code et les fichiers du club (audit parite-routes, 20/10/2026).
    Un nouveau fichier que le NAVIGATEUR doit charger s'ajoute à cette liste ; `server/http-guard.test.js` le verrouille.

20. **Tests de `cloud/`.** Les tests de la couche D1 vivent dans `server/` (ex. `server/account-revocation.test.js`, vrai schéma
    `cloud/schema.sql` dans SQLite en mémoire) : le `better-sqlite3` installé sous `cloud/node_modules` provoque une erreur de segmentation
    sous Node. Les routes d'admin ne s'importent pas telles quelles en Node (`lib/anticipation.js` importe des `.html` et un `.json`
    sans attribut) : isoler la logique dans `cloud/src/db/` pour la tester.

22. **Gestionnaires en ligne et échappement.** `optEsc` ne protège PAS à l'intérieur d'un `onclick="f('${x}')"` : le navigateur décode `&#39;`
    en `'` avant d'exécuter le JavaScript. Données dans un attribut de gestionnaire : `data-*` + écouteur délégué, ou
    `onclick="f(${optEsc(JSON.stringify(x))})"`. Tout texte venu d'une donnée (ticker, compte, date, nom de liste, message d'erreur)
    passe par `optEsc` avant `innerHTML`. Les tickers sont de plus validés à l'écriture (`js/ticker-format.js`, copie serveur et cloud) ;
    l'import de la Roue marque « symbole invalide » au lieu de l'inclure. `scripts/smoke-flags.test.js` charge toutes les pages avec
    tous les drapeaux allumés et des données piégées : c'est lui qui trouve ce défaut dans les onglets cachés (audit onglets, 20/10/2026).
    Une injection par CSV a été vérifiée non atteignable (aucune cellule exportée n'est interprétée comme formule dans l'app).

23. **État partagé entre fichiers du navigateur.** `lastTickerInstance` (la carte Symbole qui alimente la Fiche), `contexteScreeningPrepare`
    (scores joints à un trade) et `laboTickerData` (données du Labo) sont lus et écrits depuis plusieurs fichiers. Règles : un rafraîchissement
    qui n'est pas un geste de l'utilisateur passe par `refreshSelectionsPassively` ; « Préparer » met `lastTickerInstance` à `null` ; le contexte
    préparé est consommé à l'enregistrement et jamais joint à une modification ; toute donnée rattachée à un symbole porte ce symbole et
    n'est utilisée que s'il correspond au champ. Côté cloud, un 401 hors `/api/auth/` recharge la page (`sessionPerdue`) et `appDemarree`
    garde les minuteries muettes avant la connexion. `scripts/smoke-etat.test.js` enchaîne ces gestes dans un vrai Chrome (audit app-js, 21/10/2026).

24. **Ce que le serveur exécute ou accepte d'une source externe.** (a) Mise à jour en un clic (`server/update.js`) : l'URL du manifeste et celle de
    l'archive sont en https et l'empreinte sha256 publiée (`PUBLISHED_SHA256` du Worker de télémétrie) est comparée AVANT d'écrire l'archive; sans
    empreinte, pas de mise à jour. (b) Le serveur local refuse (403) toute écriture dont l'en-tête `Origin` n'est pas la machine locale
    (`originGuard`) : un POST sans corps venu d'une autre page web passait. (c) Nombres et dates : `js/trade-rules.js` (copie cloud générée) est la
    seule source; `null`, `''` et `[]` valent `>= 0` en JavaScript, ne jamais valider un montant par `x >= 0` seul. (d) Écritures liées (clôture
    d'une jambe + position créée) : une transaction en local, un `UPDATE ... AND statut = 'ouvert'` contrôlé par `meta.changes` et une compensation
    en D1; un jeton à usage unique se consomme par un UPDATE conditionnel, jamais « vérifier puis consommer ». (e) `server/cloud-isolation.test.js`
    : tout nouveau module `cloud/src/db/` qui touche une donnée personnelle y reçoit un test à deux comptes (audit routes, 21/10/2026).

25. **Une panne ne doit jamais s'afficher comme un succès.** Un scan du Radar compte ses titres RÉUSSIS (pas ses titres traités) et passe en `erreur` si aucun
    n'a pu être lu; un titre dont les fondamentaux ont échoué est écarté (`resultats_inconnus`), jamais traité comme « aucun résultat prévu »; une réponse
    IA rejetée a été facturée : le coût s'écrit AVANT la validation (`result_json = ''` marque « rejetée », filtrée par `getLastAnalysis` et `findRecentAnalysisId`).
    Une carte qui arrive de façon asynchrone compare le symbole demandé au champ avant d'écrire (`aiCurrentTicker`). La clé de cache d'une analyse inclut le plan.
    Une barre sans haut ou bas est écartée de l'historique (null - null = 0 faussait l'ATR). Après un changement de code cloud, lancer `wrangler deploy --dry-run` :
    `node --check` n'a pas vu une apostrophe mal placée dans une requête SQL (audit onglets locaux, 21/10/2026).

26. **Couche routes et démarrage du serveur local.** Le serveur refuse aussi les LECTURES `/api` venues d'un autre site (`Sec-Fetch-Site: cross-site`, `originGuard`); une instance
    secondaire (le service tourne déjà) ne démarre pas les planificateurs (alertes, scan, balayage) : leurs gardes « déjà en cours » sont en mémoire par processus; le processus
    journalise les rejets non gérés et sort sur une exception non interceptée. Un PATCH/PUT ne peut pas VIDER un champ obligatoire; un patch de réglages est entièrement validé
    avant la première écriture (`planAppSettingsWrites`); changer les périodes vide TOUS les screenings en cache sauf le balayage S&P 500, que ni les périodes ni la source de
    données ne recalculent. Un corps JSON illisible est un 400, jamais un 500 (audit routes locales, 21/10/2026).

27. **Distribution et collecte.** Le paquet téléchargeable se construit par INCLUSION (`git ls-files`), jamais par exclusion : un `.env` ou une base ajoutés plus tard ne doivent pas
    pouvoir partir (`zip -x` n'ancre que la racine). `scripts/package-zip.sh` supprime l'archive si elle contient un secret ou une donnée, et un test vérifie que git ne suit aucun
    de ces fichiers. Le jeton d'ingestion de la télémétrie est PUBLIC : tout ce que le Worker accepte est borné (taille, forme, débit par IP, rétention); la télémétrie n'envoie
    jamais de montant (ni capital ni risque). Le lanceur applique la même garde que le serveur (`launcher/guard.js`). Un assainisseur HTML parcourt un nœud AVANT de le déplier.
    Un texte pédagogique qui cite un seuil ou une période doit lire la valeur du code, pas la recopier (audit périphérie, 22/10/2026).

## Zones d'audit

Format : `nom` : chemins (taille approximative). Une zone par appel ; ne jamais auditer tout le dépôt d'un coup.

| Zone | Chemins | Taille | Pourquoi d'abord |
|---|---|---|---|
| `parite-routes` | `server/index.js` (99 routes) face à `cloud/src/routes/*.js` | 1 404 + 1 645 lignes | là que se sont concentrés les bugs passés (pièges 2, 3, 4) |
| `formules` | `js/options-analytics.js`, `server/options-analytics.js`, `server/scoring.js`, `js/sizing.js`, `server/cycle-bilan.js`, `server/premium-screener.js` | 1 272 lignes | de l'argent (piège 17) |
| `donnees-marche` | `server/indicators.js`, `fundamentals.js`, `quotes.js`, `sectors.js`, `cache.js`, `fetch-retry.js`, `screening.js` | 1 796 lignes | pièges 4, 8, 9, 13 |
| `cloud-comptes` | `cloud/src/auth.js`, `routes/auth.js`, `routes/admin.js`, `db/users.js`, `lib/password-rules.js`, `cloud/scripts/create-user.mjs` | 676 lignes | sécurité (pièges 10, 12, 18) |
| `onglets` | `js/roue-tab.js`, `journal-a-tab.js`, `options-tab-a.js`, `anticipation-tab.js` (cloud) | 2 775 lignes | pièges 5, 6, 7 |
| `pages` | `index.html` (1 551 lignes) et `cloud/public/index.html` (1 461) + `css/` | ≈ 3 000 lignes | possible depuis le découpage (phases 1-2) |
| `app-js` | `js/app-*.js` (11 fichiers), `js/mode-local.js`, `cloud/public/js/mode-cloud.js` | 3 791 lignes | l'ancien script en ligne, jamais audité |

## Règles de notation propres à castellana

- Une violation des pièges 8, 17 ou 18 avec preuve vaut au moins 90 (elle affiche ou calcule un chiffre faux).
- Un champ ajouté à une réponse d'API mais absent d'une des deux routes (Express ou Hono) vaut au moins 85.
- Une différence local/cloud **déclarée** dans `CLAUDE.md` (« local seulement ») n'est pas un constat.
