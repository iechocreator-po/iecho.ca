// Tests de la simulation du signal d'alignement (server/backtest.js) — barres
// synthétiques, résultats calculés à la main.
import test from 'node:test';
import assert from 'node:assert/strict';
import { simulateSignal, summarizeTrades, buildRegime, MIN_TRADES_FOR_CONCLUSION } from './backtest.js';

// Marche plate à 100 pendant 30 barres (aucun alignement), puis une hausse régulière.
function bars(prices, { spread = 1 } = {}) {
  return prices.map((p, i) => ({ date: new Date(2026, 0, 1 + i), open: p, high: p + spread, low: p - spread, close: p }));
}
const OPTS = { fast: 3, medium: 5, slow: 8, atrPeriod: 3, atrMult: 1.5 };

test('entrée à l\'OUVERTURE de la barre suivant le signal, pas à la clôture du signal', () => {
  const prices = [...Array(12).fill(100), 101, 103, 106, 110, 115, 121, 128];
  const b = bars(prices);
  const { trades, open } = simulateSignal(b, OPTS);
  const t = trades[0] ?? open;
  assert.ok(t, 'un signal doit être trouvé sur une hausse après une marche plate');
  // le prix d'entrée est l'ouverture d'une barre, jamais une clôture décalée
  assert.ok(b.some((x) => x.open === t.entry));
});

test('stop touché : sortie au stop, R = -1 ; gap sous le stop : sortie à l\'ouverture (pire que -1)', () => {
  const up = [...Array(12).fill(100), 101, 103, 106, 110];
  const stopBars = bars([...up, 111]);
  stopBars.push({ date: new Date(2026, 5, 1), open: 111, high: 111, low: 80, close: 85 });
  const r1 = simulateSignal(stopBars, OPTS);
  assert.equal(r1.trades.length, 1);
  assert.equal(r1.trades[0].reason, 'stop');
  assert.ok(Math.abs(r1.trades[0].r + 1) < 1e-9);

  const gapBars = bars([...up, 111]);
  gapBars.push({ date: new Date(2026, 5, 1), open: 70, high: 71, low: 60, close: 65 });
  const r2 = simulateSignal(gapBars, OPTS);
  assert.ok(r2.trades[0].r < -1, 'un gap sous le stop coûte plus que 1 R');
});

test('position encore ouverte à la fin : rapportée à part, jamais comptée comme trade fermé', () => {
  const b = bars([...Array(12).fill(100), 101, 103, 106, 110, 115, 121, 128]);
  const { trades, open } = simulateSignal(b, OPTS);
  assert.equal(trades.length, 0);
  assert.ok(open && open.rOpen > 0);
});

test('historique trop court ou sans signal : aucun trade, pas d\'erreur', () => {
  assert.deepEqual(simulateSignal(bars([100, 101, 102]), OPTS), { trades: [], open: null });
  assert.equal(simulateSignal(bars(Array(40).fill(100)), OPTS).trades.length, 0);
});

test('summarizeTrades : moyennes, facteur de profit, drawdown en R, seuil de significativité', () => {
  const mk = (r, d) => ({ r, bars: 5, reason: r < 0 ? 'stop' : 'sma', exitDate: new Date(2026, 0, d) });
  const s = summarizeTrades([mk(2, 1), mk(-1, 2), mk(-1, 3), mk(1, 4)]);
  assert.equal(s.n, 4);
  assert.equal(s.winRate, 0.5);
  assert.equal(s.avgR, 0.25);
  assert.equal(s.totalR, 1);
  assert.equal(s.profitFactor, 1.5);
  assert.equal(s.maxDrawdownR, 2); // 2 → 1 → 0 : creux de 2 R depuis le sommet
  assert.equal(s.enough, false);
  assert.equal(summarizeTrades([]).n, 0);
  assert.equal(summarizeTrades(Array.from({ length: MIN_TRADES_FOR_CONCLUSION }, () => mk(1, 1))).enough, true);
});

const RISE = [...Array(12).fill(100), 101, 103, 106, 110, 115, 121, 128, 120, 100];

test('frais + glissement : le R net = R brut − coût aller-retour ÷ risque planifié', () => {
  const b = bars(RISE);
  const gross = simulateSignal(b, OPTS).trades[0];
  const net = simulateSignal(b, { ...OPTS, costPct: 0.5 }).trades[0];
  assert.ok(gross && net);
  const risk = gross.entry - gross.stop;
  const expected = gross.r - (gross.exit * 0.005 + gross.entry * 0.005) / risk;
  assert.ok(Math.abs(net.r - expected) < 1e-9);
  assert.ok(net.r < gross.r);
});

test('filtre de régime : régime faux ou inconnu = signal ignoré ; vrai = inchangé', () => {
  const b = bars(RISE);
  const base = simulateSignal(b, OPTS);
  assert.ok(base.trades.length + (base.open ? 1 : 0) > 0);
  const off = simulateSignal(b, { ...OPTS, regimeOk: () => false });
  assert.equal(off.trades.length + (off.open ? 1 : 0), 0);
  assert.equal(simulateSignal(b, { ...OPTS, regimeOk: () => null }).trades.length, 0);
  assert.deepEqual(simulateSignal(b, { ...OPTS, regimeOk: () => true }).trades, base.trades);
});

test('buildRegime : SPY au-dessus de sa SMA, VIX plafonné, date sans donnée = null', () => {
  const spy = bars([...Array(10).fill(100), 110, 90]);
  const vix = bars([...Array(10).fill(15), 15, 40]);
  const ok = buildRegime(spy, vix, { smaPeriod: 5, vixMax: 0 });
  assert.equal(ok(spy[10].date), true);   // 110 > moyenne
  assert.equal(ok(spy[11].date), false);  // 90 < moyenne
  assert.equal(ok(spy[2].date), null);    // SMA pas encore calculable
  const withVix = buildRegime(spy, vix, { smaPeriod: 5, vixMax: 20 });
  assert.equal(withVix(spy[10].date), true);
  assert.equal(buildRegime(spy, [], { smaPeriod: 5, vixMax: 20 })(spy[10].date), null); // VIX voulu mais absent
});
