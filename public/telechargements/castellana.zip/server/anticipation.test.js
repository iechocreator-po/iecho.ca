// Onglet Anticipation (12/10/2026, bilbao #418) — règles pures de vote et de proposition.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { votesRemaining, checkVote, checkProposal, isOpen, MAX_VOTES, STATUTS } from '../cloud/src/lib/anticipation-logic.js';

const cards = [
  { id: 'a', statut: 'maquette' }, { id: 'b', statut: 'planifiee' }, { id: 'c', statut: 'maquette' },
  { id: 'd', statut: 'maquette' }, { id: 'e', statut: 'maquette' }, { id: 'f', statut: 'maquette' },
  { id: 'livree', statut: 'livree' }, { id: 'rejetee', statut: 'rejetee' },
];

test('cinq votes au départ, un vote en moins par carte ouverte votée', () => {
  assert.equal(votesRemaining(cards, []), MAX_VOTES);
  assert.equal(votesRemaining(cards, ['a', 'b']), 3);
});

test('une carte livrée ou rejetée rend son vote', () => {
  assert.equal(votesRemaining(cards, ['a', 'livree', 'rejetee']), MAX_VOTES - 1);
});

test('voter puis reprendre son vote', () => {
  assert.deepEqual(checkVote(cards, [], 'a', true), { ok: true, noop: false });
  assert.deepEqual(checkVote(cards, ['a'], 'a', false), { ok: true, noop: false });
});

test('voter deux fois pour la même carte est sans effet, pas une erreur', () => {
  assert.deepEqual(checkVote(cards, ['a'], 'a', true), { ok: true, noop: true });
  assert.deepEqual(checkVote(cards, [], 'a', false), { ok: true, noop: true });
});

test('le sixième vote est refusé, et la reprise d\'un vote le rend possible', () => {
  const five = ['a', 'b', 'c', 'd', 'e'];
  assert.equal(checkVote(cards, five, 'f', true).code, 'NO_VOTES_LEFT');
  assert.equal(checkVote(cards, five.slice(1), 'f', true).ok, true);
});

test('carte close ou inconnue : aucun vote, mais on peut toujours retirer un vote ancien', () => {
  assert.equal(checkVote(cards, [], 'livree', true).code, 'CLOSED');
  assert.equal(checkVote(cards, [], 'zzz', true).code, 'UNKNOWN_CARD');
  assert.equal(checkVote(cards, ['livree'], 'livree', false).code, 'CLOSED'); // close : plus aucune écriture
  assert.equal(checkVote(cards, [], 'a', 'oui').code, 'BAD_INPUT');
});

test('isOpen : les statuts connus', () => {
  assert.deepEqual(STATUTS.filter((s) => isOpen({ statut: s })), ['maquette', 'planifiee', 'en_construction']);
  assert.equal(isOpen(undefined), false);
});

test('proposition : normalise les espaces, exige titre et description', () => {
  const ok = checkProposal({ titre: '  Heure   des résultats ', onglet: 'Option Lab', description: ' Voir avant ouverture ' });
  assert.deepEqual(ok, { ok: true, value: { titre: 'Heure des résultats', onglet: 'Option Lab', description: 'Voir avant ouverture' } });
  assert.equal(checkProposal({ titre: '', description: 'x' }).ok, false);
  assert.equal(checkProposal({ titre: 'x', description: '  ' }).ok, false);
  assert.equal(checkProposal({ titre: 'x', description: 'y' }).value.onglet, 'Autre');
});

test('proposition : bornes de longueur et limite quotidienne', () => {
  assert.equal(checkProposal({ titre: 'x'.repeat(121), description: 'y' }).ok, false);
  assert.equal(checkProposal({ titre: 'x', description: 'y'.repeat(2001) }).ok, false);
  assert.equal(checkProposal({ titre: 'x', description: 'y' }, 5).ok, false);
  assert.equal(checkProposal({ titre: 'x', description: 'y' }, 4).ok, true);
});

test('cards.json : identifiants uniques, statuts connus, maquette présente', () => {
  const dir = new URL('../anticipation/', import.meta.url);
  const { cards: real } = JSON.parse(fs.readFileSync(new URL('cards.json', dir), 'utf8'));
  assert.equal(new Set(real.map((c) => c.id)).size, real.length);
  for (const c of real) {
    assert.ok(STATUTS.includes(c.statut), `statut inconnu : ${c.statut}`);
    assert.ok(fs.existsSync(new URL(c.maquette, dir)), `maquette absente : ${c.maquette}`);
    assert.ok(Number.isInteger(c.featureId), 'featureId bilbao requis');
  }
});
