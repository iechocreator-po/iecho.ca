// Onglet Anticipation (12/10/2026, bilbao #418) — réservé aux comptes pour lesquels le drapeau
// anticipation_tab est ACTIF (global ⊕ surcharge du compte, réglée dans bilbao). Le contrôle est fait
// ici, côté serveur, à chaque appel : cacher l'onglet dans le navigateur ne protège rien.
import { getEffectiveFlagsForUser } from '../db/flags.js';
import { getAnticipationState, setVote, addProposal, listMyProposals } from '../db/anticipation.js';
import { getMaquette } from '../lib/anticipation.js';

const STATUS = { UNKNOWN_CARD: 404, BAD_INPUT: 400, CLOSED: 409, NO_VOTES_LEFT: 409 };

export function registerAnticipationRoutes(app) {
  app.use('/api/anticipation/*', async (c, next) => {
    const flags = await getEffectiveFlagsForUser(c.env.DB, c.get('userId'));
    if (flags.anticipation_tab !== true) return c.json({ error: "L'onglet Anticipation n'est pas activé pour ce compte.", code: 'FLAG_OFF' }, 403);
    return next();
  });
  app.use('/api/anticipation', async (c, next) => {
    const flags = await getEffectiveFlagsForUser(c.env.DB, c.get('userId'));
    if (flags.anticipation_tab !== true) return c.json({ error: "L'onglet Anticipation n'est pas activé pour ce compte.", code: 'FLAG_OFF' }, 403);
    return next();
  });

  app.get('/api/anticipation', async (c) => c.json(await getAnticipationState(c.env.DB, c.get('userId'))));

  // Déclarée AVANT /:id/... : « proposals » ne doit pas être pris pour un identifiant de carte.
  app.get('/api/anticipation/proposals', async (c) => c.json({ proposals: await listMyProposals(c.env.DB, c.get('userId')) }));

  app.post('/api/anticipation/proposals', async (c) => {
    const body = await c.req.json().catch(() => ({}));
    try {
      return c.json({ proposal: await addProposal(c.env.DB, c.get('userId'), body) }, 201);
    } catch (err) {
      return c.json({ error: err.message, code: err.code || 'ERROR' }, STATUS[err.code] || 500);
    }
  });

  app.put('/api/anticipation/:id/vote', async (c) => {
    const body = await c.req.json().catch(() => ({}));
    try {
      return c.json(await setVote(c.env.DB, c.get('userId'), c.req.param('id'), body.on));
    } catch (err) {
      return c.json({ error: err.message, code: err.code || 'ERROR' }, STATUS[err.code] || 500);
    }
  });

  // HTML autonome de la maquette, à afficher dans une iframe sandbox (jamais injecté dans la page).
  app.get('/api/anticipation/:id/maquette', (c) => {
    const html = getMaquette(c.req.param('id'));
    if (!html) return c.json({ error: 'Maquette inconnue.' }, 404);
    return c.body(html, 200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  });
}
