#!/bin/bash
# scripts/package-zip.sh — construit castellana.zip pour distribution
# (téléchargement gated depuis iecho.ca, 6/9/2026).
#
# Zéro dépendance npm ajoutée : utilise `zip`, déjà présent sur macOS.
# Exclut tout ce qui est dans .gitignore (node_modules/, data/,
# .venv-mcp/, __pycache__/, .DS_Store, .wrangler/) plus .git/ — l'archive
# ne contient que le code source, demarrer.command/demarrer.bat font
# l'installation réelle (npm install, venv Python) au premier lancement
# chez le testeur.
#
# Usage : npm run package  (depuis la racine de trading-assistant/)
# Résultat : castellana.zip à la racine du repo, JAMAIS committé
# (voir .gitignore) — à copier manuellement vers
# iecho.ca/public/telechargements/castellana.zip puis committer/pousser
# iecho.ca pour redéployer. Voir CLAUDE.md, section "Paquet téléchargeable".

set -e
cd "$(dirname "$0")/.."

rm -f castellana.zip

# version.json — estampille le paquet (7/9/2026). Sans lui, un testeur n'a
# aucun moyen de savoir que sa copie a trois semaines de retard : le zip
# devenait périmé en silence. L'app lit ce fichier et le compare à la version
# publiée (voir /api/version et le bandeau de mise à jour).
VERSION="$(node -p "require('./package.json').version")"
cat > version.json <<JSON
{
  "version": "$VERSION",
  "buildDate": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
}
JSON
echo "version.json : $VERSION"

zip -rq castellana.zip . \
  -x "node_modules/*" \
  -x "data/*" \
  -x ".venv-mcp/*" \
  -x "__pycache__/*" \
  -x "*/__pycache__/*" \
  -x ".DS_Store" \
  -x "*/.DS_Store" \
  -x ".wrangler/*" \
  -x "*/.wrangler/*" \
  -x ".git/*" \
  -x "castellana.zip" \
  -x "telemetry-worker/node_modules/*" \
  -x ".claude/settings.local.json" \
  -x ".claude/scheduled_tasks.lock" \
  -x ".claude/*.lock"

echo "castellana.zip créé ($(du -h castellana.zip | cut -f1)) — version $VERSION."
echo "Prochaine étape : copier ce fichier vers iecho.ca/public/telechargements/castellana.zip"
