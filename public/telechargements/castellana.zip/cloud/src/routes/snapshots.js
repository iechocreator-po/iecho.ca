// Instantanés quotidiens (17/10/2026). Écriture : PUT /api/admin/snapshots/:kind, protégée par
// le Basic Auth admin (registerAdminAuthMiddleware couvre /api/admin/*), appelée par l'app
// LOCALE après un balayage. Lecture : GET /api/snapshots/:kind/latest, sessions connectées
// (middleware général), en lecture seule pour tous les comptes.
import { SNAPSHOT_KINDS, validateSnapshot, snapshotStale } from '../lib/snapshots.js';
import { saveSnapshot, latestSnapshot, listSnapshots } from '../db/snapshots.js';
import { getEffectiveFlagsForUser } from '../db/flags.js';

export function registerSnapshotRoutes(app) {
  app.put('/api/admin/snapshots/:kind', async (c) => {
    const kind = c.req.param('kind');
    if (!SNAPSHOT_KINDS[kind]) return c.json({ error: `Type d'instantané inconnu : « ${kind} ».` }, 404);
    const declared = Number(c.req.header('Content-Length'));
    if (declared > SNAPSHOT_KINDS[kind].maxBytes) return c.json({ error: 'Corps trop gros.' }, 413);
    const raw = await c.req.text();
    const bytes = new TextEncoder().encode(raw).length;
    let body;
    try {
      if (bytes > SNAPSHOT_KINDS[kind].maxBytes) return c.json({ error: `Corps trop gros (${bytes} octets).` }, 413);
      body = JSON.parse(raw);
    } catch { return c.json({ error: 'JSON invalide.' }, 400); }
    try { validateSnapshot(kind, body, bytes); }
    catch (err) { return c.json({ error: err.message }, err.status || 400); }
    await saveSnapshot(c.env.DB, kind, body.date, raw);
    return c.json({ ok: true, kind, date: body.date, bytes, rows: body.rows.length });
  });

  app.get('/api/admin/snapshots/:kind', async (c) => {
    const kind = c.req.param('kind');
    if (!SNAPSHOT_KINDS[kind]) return c.json({ error: 'Type inconnu.' }, 404);
    return c.json({ kind, snapshots: await listSnapshots(c.env.DB, kind) });
  });

  app.get('/api/snapshots/:kind/latest', async (c) => {
    const kind = c.req.param('kind');
    if (!SNAPSHOT_KINDS[kind]) return c.json({ error: 'Type inconnu.' }, 404);
    const flags = await getEffectiveFlagsForUser(c.env.DB, c.get('userId'));
    if (flags.sp500_sweep !== true) return c.json({ error: "Le balayage S&P 500 n'est pas activé pour ce compte.", code: 'FLAG_OFF' }, 403);
    const snap = await latestSnapshot(c.env.DB, kind);
    if (!snap) return c.json({ error: 'Aucun instantané reçu du poste local.', code: 'NO_SNAPSHOT' }, 404);
    return c.json({ ...snap.value, receivedAt: snap.receivedAt, stale: snapshotStale(snap.date), ageSeconds: Math.max(0, Math.round((Date.now() - Date.parse(snap.value.computedAt)) / 1000)) });
  });
}
