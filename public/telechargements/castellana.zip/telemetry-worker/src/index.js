// castellana-telemetry — collecteur de télémétrie (6/9/2026)
//
// Contexte : castellana tourne en local chez chaque testeur (aucun serveur
// partagé, décision JP), donc ce petit Worker est le SEUL point de collecte
// centralisé. Le navigateur de chaque testeur poste directement ici
// (js/telemetry.js de castellana) — server/index.js n'est pas impliqué.
//
// Worker natif, zéro framework (Hono, itty-router, etc.) — 3 routes, pas
// besoin d'un routeur pour ça, cohérent avec la discipline zéro-dépendance
// du reste du portfolio pour ce type d'outil (voir launcher/server.js).
//
// Sécurité — À NE PAS SURESTIMER : `TELEMETRY_TOKEN` (wrangler.jsonc `vars`,
// doit rester identique à CFG.telemetry.sharedToken dans config.js côté
// castellana) n'est PAS une vraie authentification. C'est un filtre
// anti-bruit pour qu'un bot qui découvrirait cette URL publique (par
// définition, tout Worker Cloudflare est joignable depuis Internet) ne
// pollue pas la base avec des faux événements. Le jeton est visible dans le
// code source du navigateur de castellana — quiconque a accès à castellana
// peut le lire. Si un vrai contrôle d'accès devient nécessaire un jour,
// voir T3 (login) dans CLAUDE.md — ce Worker n'en fait pas partie pour
// l'instant.

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*', // chaque testeur a une origine locale différente (127.0.0.1:4700 chez l'un, localhost:4700 chez l'autre) — le filtrage se fait par jeton, pas par origine
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, X-Telemetry-Token',
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...CORS_HEADERS },
  });
}

function checkToken(request, env, url) {
  const header = request.headers.get('X-Telemetry-Token');
  const queryToken = url.searchParams.get('token');
  const provided = header || queryToken;
  return Boolean(env.TELEMETRY_TOKEN) && provided === env.TELEMETRY_TOKEN;
}

const KNOWN_EVENT_TYPES = new Set(['app_loaded', 'ticker_selected', 'param_changed']);

function validateEvent(ev) {
  if (!ev || typeof ev !== 'object') return 'événement absent ou invalide';
  if (typeof ev.who !== 'string' || !ev.who) return 'champ "who" manquant';
  if (typeof ev.event_type !== 'string' || !KNOWN_EVENT_TYPES.has(ev.event_type)) {
    return `event_type inconnu : ${JSON.stringify(ev.event_type)}`;
  }
  return null;
}

async function handleEvents(request, env, ip) {
  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: 'JSON invalide' }, 400);
  }
  const events = Array.isArray(body?.events) ? body.events : [body];
  if (events.length === 0) return json({ error: 'aucun événement' }, 400);
  if (events.length > 50) return json({ error: 'trop d\'événements dans un seul envoi (max 50)' }, 400);

  const now = new Date().toISOString();
  const stmt = env.DB.prepare(
    'INSERT INTO telemetry_events (created_at, who, ip, event_type, payload_json, user_agent) VALUES (?, ?, ?, ?, ?, ?)'
  );
  const batch = [];
  for (const ev of events) {
    const err = validateEvent(ev);
    if (err) return json({ error: err }, 400);
    batch.push(stmt.bind(now, ev.who, ip, ev.event_type, JSON.stringify(ev.payload ?? {}), ev.ua ?? null));
  }
  await env.DB.batch(batch);
  return json({ ok: true, inserted: batch.length });
}

function csvEscape(v) {
  if (v == null) return '';
  const s = String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

async function handleCsv(env) {
  const { results } = await env.DB
    .prepare('SELECT id, created_at, who, ip, event_type, payload_json, user_agent FROM telemetry_events ORDER BY id DESC LIMIT 5000')
    .all();
  const cols = ['id', 'created_at', 'who', 'ip', 'event_type', 'payload_json', 'user_agent'];
  const lines = [cols.join(',')];
  for (const row of results) lines.push(cols.map((c) => csvEscape(row[c])).join(','));
  return new Response(lines.join('\n'), {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="castellana-telemetry-${Date.now()}.csv"`,
      ...CORS_HEADERS,
    },
  });
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// ---- Dashboard (6/9/2026, enrichi) — activité par jour, tickers populaires,
// filtre par testeur. Palette et specs de marque repris du skill dataviz du
// portfolio (bleu catégoriel slot 1, mode sombre — voir palette.md) : une
// seule teinte par graphique (une seule série à la fois, pas de comparaison
// catégorielle), gridlines hairline récessives, barres <=24px avec coin
// arrondi 4px côté données, écart de 2px entre barres adjacentes,
// info-bulle au survol plutôt qu'une valeur sur chaque barre.
const DASH_COLORS = {
  surface: '#1a1a19',
  page: '#0d0d0d',
  ink: '#ffffff',
  ink2: '#c3c2b7',
  muted: '#898781',
  grid: '#2c2c2a',
  baseline: '#383835',
  series: '#3987e5',
};

// Graphique en barres verticales — activité par jour (une série, magnitude
// dans le temps). Pas de valeur sur chaque barre (jusqu'à 90 barres selon le
// filtre de période) — l'info-bulle au survol porte le détail, les
// graduations Y portent l'ordre de grandeur.
function dailyActivitySVG(rows) {
  const width = 720;
  const height = 220;
  const padL = 36;
  const padB = 28;
  const padT = 12;
  const padR = 12;
  const plotW = width - padL - padR;
  const plotH = height - padT - padB;
  const maxN = Math.max(1, ...rows.map((r) => r.n));
  const yMax = Math.ceil(maxN / 5) * 5 || 1;
  const n = rows.length || 1;
  const bandW = plotW / n;
  const barW = Math.max(2, Math.min(24, bandW - 2));

  const yTicks = [0, yMax / 2, yMax].map((v) => Math.round(v));
  const gridLines = yTicks
    .map((t) => {
      const y = padT + plotH - (t / yMax) * plotH;
      return `<line x1="${padL}" y1="${y.toFixed(1)}" x2="${width - padR}" y2="${y.toFixed(1)}" stroke="${DASH_COLORS.grid}" stroke-width="1"/>
        <text x="${padL - 6}" y="${(y + 3).toFixed(1)}" font-size="10" fill="${DASH_COLORS.muted}" text-anchor="end">${t}</text>`;
    })
    .join('');

  // Étiquettes X : espacées pour ne jamais se chevaucher (max ~8 visibles).
  const labelEvery = Math.max(1, Math.ceil(n / 8));
  const bars = rows
    .map((r, i) => {
      const x = padL + i * bandW + (bandW - barW) / 2;
      const h = (r.n / yMax) * plotH;
      const y = padT + plotH - h;
      const label = i % labelEvery === 0 ? `<text x="${(x + barW / 2).toFixed(1)}" y="${height - 8}" font-size="9" fill="${DASH_COLORS.muted}" text-anchor="middle">${escapeHtml(r.jour.slice(5))}</text>` : '';
      return `<rect class="dash-bar" data-jour="${escapeHtml(r.jour)}" data-n="${r.n}" x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${barW.toFixed(1)}" height="${Math.max(0, h).toFixed(1)}" rx="4" fill="${DASH_COLORS.series}"/>${label}`;
    })
    .join('');

  return `<svg viewBox="0 0 ${width} ${height}" width="100%" style="max-width:${width}px" role="img" aria-label="Activité par jour">
    ${gridLines}
    <line x1="${padL}" y1="${padT + plotH}" x2="${width - padR}" y2="${padT + plotH}" stroke="${DASH_COLORS.baseline}" stroke-width="1"/>
    ${bars}
  </svg>`;
}

// Graphique en barres horizontales — tickers les plus sélectionnés (classement,
// jusqu'à 15). Valeur au bout de chaque barre : liste courte, contrairement au
// graphique quotidien, donc labeller chaque ligne reste lisible et utile ici.
function topTickersSVG(rows) {
  if (rows.length === 0) return '<p class="dash-empty">Aucun ticker sélectionné sur cette période.</p>';
  const width = 360;
  const rowH = 24;
  const gap = 6;
  const height = rows.length * (rowH + gap) - gap + 8;
  const labelW = 64;
  const valueW = 34;
  const barMaxW = width - labelW - valueW - 8;
  const maxN = Math.max(1, ...rows.map((r) => r.n));

  const bars = rows
    .map((r, i) => {
      const y = i * (rowH + gap);
      const w = Math.max(2, (r.n / maxN) * barMaxW);
      return `
        <text x="${labelW - 8}" y="${(y + rowH / 2 + 4).toFixed(1)}" font-size="12" fill="${DASH_COLORS.ink2}" text-anchor="end" font-family="ui-monospace, monospace">${escapeHtml(r.ticker ?? '—')}</text>
        <rect class="dash-bar" data-ticker="${escapeHtml(r.ticker ?? '—')}" data-n="${r.n}" x="${labelW}" y="${y.toFixed(1)}" width="${w.toFixed(1)}" height="${rowH - 4}" rx="4" fill="${DASH_COLORS.series}"/>
        <text x="${(labelW + w + 6).toFixed(1)}" y="${(y + rowH / 2 + 4).toFixed(1)}" font-size="11" fill="${DASH_COLORS.ink}" font-variant-numeric="tabular-nums">${r.n}</text>
      `;
    })
    .join('');

  return `<svg viewBox="0 0 ${width} ${height}" width="100%" style="max-width:${width}px" role="img" aria-label="Tickers les plus sélectionnés">${bars}</svg>`;
}

async function handleDashboard(env, url) {
  const days = Math.min(Math.max(parseInt(url.searchParams.get('days') || '30', 10) || 30, 1), 365);
  const who = url.searchParams.get('who') || 'all';
  const token = url.searchParams.get('token');

  const whoClause = who !== 'all' ? 'AND who = ?' : '';
  const whoBind = who !== 'all' ? [who] : [];
  const periodeArg = `-${days} days`;

  const [testeursRes, dailyRes, tickersRes, recentRes] = await Promise.all([
    env.DB.prepare('SELECT DISTINCT who FROM telemetry_events ORDER BY who').all(),
    env.DB
      .prepare(
        `SELECT substr(created_at,1,10) AS jour, COUNT(*) AS n FROM telemetry_events
         WHERE created_at >= datetime('now', ?) ${whoClause}
         GROUP BY jour ORDER BY jour`
      )
      .bind(periodeArg, ...whoBind)
      .all(),
    env.DB
      .prepare(
        `SELECT json_extract(payload_json,'$.ticker') AS ticker, COUNT(*) AS n FROM telemetry_events
         WHERE event_type = 'ticker_selected' AND created_at >= datetime('now', ?) ${whoClause}
         GROUP BY ticker ORDER BY n DESC LIMIT 15`
      )
      .bind(periodeArg, ...whoBind)
      .all(),
    env.DB
      .prepare(
        `SELECT id, created_at, who, ip, event_type, payload_json FROM telemetry_events
         WHERE created_at >= datetime('now', ?) ${whoClause}
         ORDER BY id DESC LIMIT 200`
      )
      .bind(periodeArg, ...whoBind)
      .all(),
  ]);

  const testeurOptions = testeursRes.results
    .map((r) => `<option value="${escapeHtml(r.who)}"${r.who === who ? ' selected' : ''}>${escapeHtml(r.who)}</option>`)
    .join('');

  const dayPresets = [7, 30, 90]
    .map((d) => `<option value="${d}"${d === days ? ' selected' : ''}>${d} derniers jours</option>`)
    .join('');

  const totalPeriode = dailyRes.results.reduce((sum, r) => sum + r.n, 0);

  const rows = recentRes.results
    .map(
      (r) => `<tr><td>${r.id}</td><td>${escapeHtml(r.created_at)}</td><td>${escapeHtml(r.who)}</td><td>${escapeHtml(r.ip ?? '')}</td><td>${escapeHtml(r.event_type)}</td><td><code>${escapeHtml(r.payload_json)}</code></td></tr>`
    )
    .join('\n');

  const html = `<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><title>castellana — télémétrie</title>
<style>
  :root { color-scheme: dark; }
  body { font-family: system-ui, -apple-system, "Segoe UI", sans-serif; margin: 0; padding: 2rem; background: ${DASH_COLORS.page}; color: ${DASH_COLORS.ink}; }
  h1 { font-size: 18px; margin: 0 0 4px; }
  .sub { color: ${DASH_COLORS.ink2}; font-size: 13px; margin: 0 0 1.2rem; }
  .filtres { display: flex; align-items: center; gap: 10px; margin-bottom: 1.4rem; flex-wrap: wrap; }
  .filtres select, .filtres button { font: inherit; font-size: 13px; background: ${DASH_COLORS.surface}; color: ${DASH_COLORS.ink}; border: 1px solid ${DASH_COLORS.baseline}; border-radius: 8px; padding: 6px 10px; }
  .filtres button { cursor: pointer; }
  .filtres button:hover { border-color: ${DASH_COLORS.series}; }
  .grille { display: grid; grid-template-columns: 1fr 1fr; gap: 1.2rem; margin-bottom: 1.4rem; }
  @media (max-width: 800px) { .grille { grid-template-columns: 1fr; } }
  .carte { background: ${DASH_COLORS.surface}; border: 1px solid ${DASH_COLORS.baseline}; border-radius: 12px; padding: 1rem 1.1rem; }
  .carte h2 { font-size: 13px; font-weight: 600; color: ${DASH_COLORS.ink2}; text-transform: uppercase; letter-spacing: 0.04em; margin: 0 0 10px; }
  .carte .stat { font-size: 22px; font-weight: 700; margin: 0 0 2px; }
  .dash-empty { color: ${DASH_COLORS.muted}; font-size: 13px; }
  .dash-bar { transition: filter 0.1s; cursor: default; }
  .dash-bar:hover { filter: brightness(1.3); }
  #dash-tooltip { position: fixed; pointer-events: none; background: ${DASH_COLORS.surface}; border: 1px solid ${DASH_COLORS.baseline}; border-radius: 6px; padding: 4px 8px; font-size: 12px; color: ${DASH_COLORS.ink}; display: none; z-index: 10; white-space: nowrap; }
  #dash-tooltip strong { font-variant-numeric: tabular-nums; }
  table { border-collapse: collapse; width: 100%; font-size: 13px; }
  th, td { border: 1px solid ${DASH_COLORS.baseline}; padding: 4px 8px; text-align: left; vertical-align: top; }
  th { background: ${DASH_COLORS.surface}; position: sticky; top: 0; }
  code { font-size: 11px; color: #9fd3ff; }
  a { color: ${DASH_COLORS.series}; }
</style></head>
<body>
  <h1>castellana — télémétrie</h1>
  <p class="sub"><strong>${totalPeriode}</strong> événement(s) sur la période — export complet : <code>/events.csv?token=...</code></p>

  <form class="filtres" method="get">
    <input type="hidden" name="token" value="${escapeHtml(token ?? '')}">
    <select name="days">${dayPresets}</select>
    <select name="who">
      <option value="all"${who === 'all' ? ' selected' : ''}>Tous les testeurs</option>
      ${testeurOptions}
    </select>
    <button type="submit">Filtrer</button>
  </form>

  <div class="grille">
    <div class="carte">
      <h2>Activité par jour</h2>
      ${dailyActivitySVG(dailyRes.results)}
    </div>
    <div class="carte">
      <h2>Tickers les plus sélectionnés</h2>
      ${topTickersSVG(tickersRes.results)}
    </div>
  </div>

  <div class="carte" style="margin-bottom:1.4rem;">
    <h2>Derniers événements (200 max, période filtrée)</h2>
    <table>
      <thead><tr><th>id</th><th>quand (serveur)</th><th>qui</th><th>ip</th><th>type</th><th>détail</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
  </div>

  <div id="dash-tooltip"></div>
  <script>
    const tooltip = document.getElementById('dash-tooltip');
    document.querySelectorAll('.dash-bar').forEach((bar) => {
      bar.addEventListener('pointermove', (e) => {
        const jour = bar.dataset.jour;
        const ticker = bar.dataset.ticker;
        const n = bar.dataset.n;
        tooltip.textContent = '';
        const strong = document.createElement('strong');
        strong.textContent = n;
        tooltip.appendChild(strong);
        tooltip.appendChild(document.createTextNode(' — ' + (jour || ticker)));
        tooltip.style.display = 'block';
        tooltip.style.left = (e.clientX + 12) + 'px';
        tooltip.style.top = (e.clientY + 12) + 'px';
      });
      bar.addEventListener('pointerleave', () => { tooltip.style.display = 'none'; });
    });
  </script>
</body></html>`;
  return new Response(html, { headers: { 'Content-Type': 'text/html; charset=utf-8', ...CORS_HEADERS } });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: CORS_HEADERS });
    }

    if (request.method === 'POST' && url.pathname === '/events') {
      if (!checkToken(request, env, url)) return json({ error: 'jeton invalide ou absent' }, 401);
      const ip = request.headers.get('cf-connecting-ip') || 'inconnue';
      return handleEvents(request, env, ip);
    }

    if (request.method === 'GET' && url.pathname === '/events.csv') {
      if (!checkToken(request, env, url)) return json({ error: 'jeton invalide ou absent' }, 401);
      return handleCsv(env);
    }

    // Manifeste de version (7/9/2026) — publique et SANS jeton, à dessein :
    // c'est l'app installée chez un testeur qui l'interroge au démarrage
    // pour savoir si sa copie est à jour, et elle ne révèle rien de plus
    // que ce qui est déjà téléchargeable depuis iecho.ca.
    //
    // ⚠️ À BUMPER À LA MAIN à chaque publication d'un nouveau zip, en même
    // temps que "version" dans ../package.json — rien ne synchronise les
    // deux (même limite que TELEMETRY_TOKEN / CFG.telemetry.sharedToken).
    // Publier un zip sans toucher à PUBLISHED_VERSION laisse simplement les
    // testeurs sur leur version : c'est silencieux, pas cassé.
    if (request.method === 'GET' && url.pathname === '/version') {
      return json({
        version: env.PUBLISHED_VERSION ?? null,
        url: env.PUBLISHED_URL ?? null,
        notes: env.PUBLISHED_NOTES ?? null,
      });
    }

    if (request.method === 'GET' && url.pathname === '/dashboard') {
      if (!checkToken(request, env, url)) return json({ error: 'jeton invalide ou absent (ajouter ?token=...)' }, 401);
      return handleDashboard(env, url);
    }

    return json({ error: 'not found' }, 404);
  },
};
