// js/app-screening.js — Screening : cellules, univers, tableau, tri, filtres, export
// Extrait de l'ancien script en ligne des index.html (découpage phase 2, 20/10/2026) : code déplacé tel quel, sans réécriture.
// Fichier COMMUN aux versions locale et cloud : source ici ; cloud/public/js/app-screening.js en est la copie (npm run sync:cloud).
// Script classique : ses noms de premier niveau sont globaux et partagés avec les autres scripts de la page.

// Colore un score d'axe selon son propre seuil : ce qui compte n'est pas le
// signe mais le franchissement du seuil qui fait basculer le verdict.
function axisClass(score, seuil) {
  if (score == null) return '';
  if (score >= seuil) return 'ok';
  if (score < 0) return 'bad';
  return 'warn';
}
// Âge du signal. Les seuils viennent du serveur (`signalAge` dans la réponse
// du screening) plutôt que d'être redupliqués ici — une quatrième source de
// vérité à resynchroniser à la main serait exactement le piège déjà
// documenté pour SCORE_BANDS et SCREEN_FILTERS.
let signalAgeSeuils = { fraisMax: 5, vieuxMin: 20 };
function signalCell(age) {
  if (age == null) return '<span style="color:var(--text-3)">—</span>';
  const cls = age <= signalAgeSeuils.fraisMax ? 'ok' : (age > signalAgeSeuils.vieuxMin ? 'bad' : 'warn');
  return `<span class="${cls}">${age} j</span>`;
}
function obvBadge(obvTrend) {
  if (obvTrend === 'accumulation') return '<span class="ds-badge ds-badge--success">Accumulation</span>';
  if (obvTrend === 'distribution') return '<span class="ds-badge ds-badge--danger">Distribution</span>';
  if (obvTrend === 'neutre') return '<span class="ds-badge">Neutre</span>';
  return '—';
}
let lastScreeningRows = []; // conservé pour le filtrage client (feature 322)

function fmtVolume(v) {
  if (v == null) return '—';
  if (v >= 1e9) return (v / 1e9).toFixed(1) + ' G';
  if (v >= 1e6) return (v / 1e6).toFixed(1) + ' M';
  if (v >= 1e3) return (v / 1e3).toFixed(0) + ' k';
  return String(v);
}
function fmtFloat(shares) {
  if (shares == null) return '—';
  if (shares >= 1e9) return (shares / 1e9).toFixed(2) + ' G';
  return (shares / 1e6).toFixed(0) + ' M';
}
// Colore une valeur fondamentale selon son drapeau pass/fail (feature 322).
// Price-to-Sales (2/10/2026). Vert quand il est dans le repère de JP (CFG.fondamentaux.psBon,
// 1 à 2), sans jamais présenter le reste comme mauvais.
function psInGoodBand(ps) {
  const b = CFG.fondamentaux.psBon;
  return ps != null && ps >= b.min && ps <= b.max;
}
function psCellHTML(r) {
  if (r.priceToSales == null) return '<td class="is-num">—</td>';
  const txt = r.priceToSales.toFixed(2);
  return `<td class="is-num" title="Price-to-Sales : capitalisation ÷ revenus (12 mois)">${psInGoodBand(r.priceToSales) ? `<span style="color:var(--green)">${txt}</span>` : txt}</td>`;
}
// Comparaison du P/S d'un titre à la médiane de son secteur (pairs du dernier screening).
function psSectorText(m) {
  if (m?.priceToSales == null) return '';
  if (m.sectorPS == null) return m.sector ? `Médiane du secteur ${m.sector} indisponible : lance le screening (au moins 3 titres du secteur)` : '';
  return `Médiane du secteur ${m.sector} : ${m.sectorPS.toFixed(2)} (${m.sectorPSPeerCount} titres du dernier screening) — ce titre : ${(m.priceToSales / m.sectorPS).toFixed(1)}× la médiane`;
}
function sectorPsCellHTML(r) {
  if (r.sectorPS != null) {
    const rel = r.priceToSales != null && r.sectorPS > 0 ? ` — ce titre : ${(r.priceToSales / r.sectorPS).toFixed(1)}× la médiane` : '';
    return `<td class="is-num" title="Médiane sur ${r.sectorPSPeerCount} titre(s) du secteur ${optEsc(r.secteur || '')} de ce tableau — approximation par pairs${rel}">${r.sectorPS.toFixed(2)}</td>`;
  }
  const n = r.sectorPSPeerCount;
  return `<td class="is-num"${n != null ? ` title="${n} titre(s) seulement dans ce secteur : au moins 3 sont nécessaires pour une comparaison"` : ''}>—</td>`;
}
function flagCell(text, flag) {
  if (flag === true) return `<td class="is-num"><span style="color:var(--green)">${text}</span></td>`;
  if (flag === false) return `<td class="is-num"><span class="num-dim">${text}</span></td>`;
  return `<td class="is-num">${text}</td>`;
}
// Contexte de screening du dernier candidat « préparé » — mémorisé pour que
// l'enregistrement du trade porte le RAISONNEMENT qui a fait retenir le
// titre, pas seulement ses chiffres. Sans ça, impossible de répondre plus
// tard à « le score prédisait-il quoi que ce soit ? » : on ne peut pas
// analyser après coup une donnée jamais collectée.
let contexteScreeningPrepare = null;
// Univers courant du screening. `watchlist` par défaut — l'écran garde
// donc exactement le comportement qu'il avait avant le 11/9/2026 tant que
// JP ne bascule pas lui-même.
let universCourant = 'watchlist';
function setUnivers(u) {
  universCourant = u;
  document.querySelectorAll('.univers-switch .ds-btn').forEach((b) => {
    b.classList.toggle('is-active', b.dataset.univers === u);
  });
  // On vide le tableau plutôt que de laisser les lignes de l'autre univers
  // à l'écran sous un libellé qui ne leur correspond plus.
  listEditorOpen = false;
  { const w = document.getElementById('scr-watchlist-editor'); if (w) w.style.display = 'none'; }
  lastScreeningRows = [];
  document.getElementById('screen-tbody').innerHTML = '';
  resetScreenChart(); // idem pour le graphique de performance (21/9/2026)
  // Listes personnalisées (12/9/2026) — univers dynamique `list:<id>`, pas
  // dans UNIVERS_LABELS (fixe). Le libellé se construit depuis customLists.
  if (u.startsWith('list:')) {
    const list = currentListObj();
    document.getElementById('scr-screen-status').textContent = list
      ? `${list.nom} : ${list.tickers.length} titre(s), tous affichés, en setup ou non. Lance le screening.`
      : 'Liste introuvable.';
  } else {
    document.getElementById('scr-screen-status').textContent = UNIVERS_LABELS[u] ?? UNIVERS_LABELS.watchlist;
  }
  renderListEditor();
}
// Bandeau d'erreur/avertissement du Screener (7/10/2026) : le message « Erreur : … » ne
// vivait que dans la ligne d'état, coincée dans une colonne étroite tout en bas de la carte —
// invisible, d'où « il ne se passe rien ». Le bandeau est large, coloré, avec une action.
function screeningBanner(text, kind = 'notready', actionLabel = null, actionFn = null) {
  const el = document.getElementById('scr-screen-error');
  if (!el) return;
  if (!text) { el.style.display = 'none'; el.innerHTML = ''; return; }
  el.className = `banner ${kind}`;
  el.textContent = text;
  if (actionLabel && actionFn) {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'ds-btn'; b.style.marginLeft = '10px'; b.textContent = actionLabel; b.onclick = actionFn;
    el.appendChild(b);
  }
  el.style.display = 'block';
  el.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}
// Chiffre ce que coûterait l'entrée sur un candidat du screening, avec les
// paramètres RÉELLEMENT saisis dans la Fiche de trade (capital, risque de
// base, charge déjà engagée, multiplicateur d'ATR, VIX). Sans ça, le
// screening présenterait un menu sans prix — et passer de 2 à ~19 candidats
// par jour pousserait mécaniquement à sur-trader.
//
// Appelle `computeSizing` (js/sizing.js), la MÊME fonction que la Fiche de
// trade : aucune formule n'est réécrite ici.
//
// ⚠️ Une hypothèse assumée : `correlated: false`. L'app ne sait pas si un
// candidat est corrélé à une position déjà ouverte — c'est un jugement de
// JP, posé dans la Fiche de trade. La taille affichée ici est donc un
// PLAFOND : elle ne peut que baisser une fois la corrélation déclarée,
// jamais monter.
function sizingForCandidate(row) {
  if (row.price == null || row.atr == null || row.atr <= 0) return null;
  // VIX, RSI ou OBV absents : pas de taille. Avant, 17 / 50 / « neutre » étaient inventés sans le dire (audit app-js, piège 8).
  if (currentVix == null || row.rsi == null || row.obvTrend == null) return null;
  const num = (id, fallback) => {
    const el = document.getElementById(id);
    const v = el ? Number(el.value) : NaN;
    return Number.isFinite(v) ? v : fallback;
  };
  try {
    return computeSizing({
      capital: num('capital', CFG.defauts.capital),
      riskPct: num('riskpct', CFG.sizing.risquePctBase.defaut),
      heatExist: num('heatexist', 0),
      entry: row.price,
      atr: row.atr,
      atrMult: num('atrmult', CFG.sizing.atrMultiplicateur.defaut),
      correlated: false,
      // VIX vient de la pastille globale du header, plus d'un champ de la Fiche (retiré le 28/9/2026).
      vix: currentVix,
      rsi: row.rsi,
      obv: row.obvTrend,
    });
  } catch { return null; }
}
// Bascule vers la Fiche de trade avec le candidat, ses indicateurs ET son
// raisonnement de screening. Évite la ressaisie, et surtout garantit que ce
// qui sera enregistré au journal correspond bien à ce que le screening
// affichait — pas à des valeurs retapées de mémoire quelques minutes plus
// tard.
function prepareTradeFrom(ticker) {
  // Les deux tableaux (Screener et « top du secteur ») portent ce bouton
  // depuis le 11/9/2026 — on cherche dans celui qui a la ligne.
  const r = lastScreeningRows.find((x) => x.ticker === ticker)
         || lastSectorTopRows.find((x) => x.ticker === ticker);
  if (!r) return;

  contexteScreeningPrepare = {
    ticker,
    setup_score: r.setupScore ?? null,
    contexte_score: r.contexteScore ?? null,
    alignement_a_entree: r.smaAlignment ?? null,
    signal_age_a_entree: r.alignmentAge ?? null,
  };

  // La Fiche désigne désormais CE titre : aucune carte Symbole ne doit le remplacer au prochain retour sur l'onglet.
  lastTickerInstance = null;
  // Bascule AVANT de remplir, et non l'inverse : `switchTab('fiche')`
  // recopie le ticker de la dernière carte Ticker utilisée dans le
  // formulaire. Remplir d'abord aurait donc été silencieusement écrasé par
  // le titre précédent — le bouton aurait eu l'air de marcher tout en
  // préparant le mauvais trade.
  switchTab('fiche');

  const set = (id, v) => { const el = document.getElementById(id); if (el && v != null) el.value = v; };
  set('ticker', ticker);
  set('entry', r.price);
  if (r.price != null) {
    entryAutoFilled = { ticker };
    setEntryNote(`Prix du screening (cours au moment de la récupération) pour ${ticker} — PAS la clôture de la veille. Remplace-le par ton prix d'entrée prévu.`);
  }
  set('atr', r.atr != null ? r.atr.toFixed(2) : null);
  set('rsi', r.rsi != null ? r.rsi.toFixed(1) : null);
  set('obv', r.obvTrend);
  // Le journal, en bas du même parcours.
  set('j-ticker', ticker);
  set('j-prix_entree', r.price);
  set('j-rsi_a_entree', r.rsi != null ? r.rsi.toFixed(1) : null);
  set('j-obv_a_entree', r.obvTrend);

  calcFiche();
  const hint = document.getElementById('sma-live-hint');
  if (hint) {
    const age = r.alignmentAge != null ? `${r.alignmentAge} j` : '—';
    hint.textContent = `Depuis le screening : ${ticker} — Setup ${r.setupScore ?? '—'}, Contexte ${r.contexteScore ?? '—'}, `
      + `alignement ${r.smaAlignment ?? '—'} (signal ${age}). Ces valeurs seront enregistrées avec le trade.`;
  }
}
// Rendu d'UNE ligne du tableau de screening — partagé depuis le 11/9/2026
// entre l'onglet Screener et la carte « Titres les plus performants du
// secteur » (Secteurs), à qui JP a demandé les mêmes colonnes. Le markup
// n'existe qu'ICI : deux tableaux censés être identiques et écrits à deux
// endroits divergent à la première retouche qu'on oublie d'un côté (c'est
// exactement ce qui était arrivé aux deux cartes « Ticker », voir T7).
//
// `pairsLabel` : le « P/E industrie » est une moyenne sur les pairs du LOT
// screené — la watchlist d'un côté, les candidats du secteur de l'autre.
// L'infobulle doit dire lequel, sinon elle affirme quelque chose de faux.

// Encadré "Comment lire les colonnes" (T1/T2, 12/9/2026) — injecté au-dessus
// des DEUX tableaux qui partagent ces 4 colonnes (Screener et "Titres les
// plus performants du secteur"). Une seule fonction, deux points d'injection
// (#screen-legend / #sector-top-legend) — jamais le texte recopié à la main
// aux deux endroits, qui diverge à la première retouche oubliée d'un côté.
function columnLegendHTML() {
  return `
    <div class="column-legend">
      <div class="column-legend-title">Comment lire les colonnes Variation / Contexte / Setup / Signal</div>
      <dl class="column-legend-grid">
        <dt>Variation</dt>
        <dd>Variation du prix depuis la clôture de la veille (aujourd'hui, en %) — c'est elle qui classe A4 par défaut ; dans B4 elle s'affiche aussi, et un clic sur l'en-tête trie.</dd>
        <dt>Contexte</dt>
        <dd>Le titre vaut-il la peine d'être suivi ? — Golden Cross, force relative vs S&amp;P 500, OBV. Ça juge la qualité du titre, mais ne valide pas une entrée à lui seul (un excellent titre peut ne pas être en Setup).</dd>
        <dt>Setup</dt>
        <dd>Est-ce que ça se déclenche maintenant ? — alignement des moyennes mobiles (SMA rapide &gt; moyenne &gt; lente, la porte d'entrée), RSI en zone, prix au-dessus du VWAP. C'est le signal d'entrée.</dd>
        <dt>Prêt / À surveiller</dt>
        <dd><strong>Prêt</strong> : l'alignement haussier est en place, le signal n'a pas plus de 20 séances, Setup ≥ 2 <em>et</em> Contexte ≥ 1. <strong>À surveiller</strong> : l'alignement est là, mais le Setup est &lt; 2 ou le Contexte &lt; 1 (ou l'alignement n'a pas pu être calculé). Ce n'est donc pas un autre score : c'est le <em>verdict</em> tiré de Setup et Contexte. Les autres verdicts : « trop tard » (signal de plus de 20 séances) et « pas de setup » (pas d'alignement).</dd>
        <dt>Signal</dt>
        <dd>Depuis combien de séances l'alignement haussier dure sans interruption. 1 jour = le signal vient tout juste de se déclencher ; plus c'est vieux, plus le mouvement est probablement déjà fait (d'où le verdict « trop tard » sur un Signal ancien même avec un bon score).</dd>
      </dl>
    </div>
  `;
}
function screeningRowHTML(r, { onclick, pairsLabel, leadCell = '' }) {
    const f = r.flags || {};
    const sz = sizingForCandidate(r);
    // Grisé, jamais masqué : l'app dit ce que coûte le trade, JP décide.
    // Même discipline que les verdicts de la checklist, qui ne cochent
    // jamais une case à sa place.
    const trop = sz && sz.depasseAlerte;
    const rowStyle = trop ? ' style="opacity:.45"' : '';
    const rowTitle = trop
      ? ` title="Ce trade porterait la charge du portefeuille à ${sz.totalHeat.toFixed(1)} %, au-delà du seuil d'alerte de ${CFG.sizing.chargePortefeuille.alerte} %."`
      : '';
    const vwapCell = r.aboveVwap == null ? '—'
      : (r.aboveVwap ? '<span class="ds-badge ds-badge--success">&gt; VWAP</span>' : '<span class="ds-badge ds-badge--danger">&lt; VWAP</span>');
    return `
      <tr data-ticker="${optEsc(r.ticker)}"${rowStyle}${rowTitle} onclick="${onclick}(${optEsc(JSON.stringify(r.ticker))})">
        <td><strong>${optEsc(r.ticker)}</strong>${r.suivi ? ' <span class="ds-badge" style="font-size:10px">suivi</span>' : ''}</td>
        ${leadCell}
        <td class="is-num"${r.contexteParts?.length ? ` title="${optEsc(r.contexteParts.join(' · '))}"` : ''}><span class="${axisClass(r.contexteScore, 1)}">${r.contexteScore ?? '—'}</span></td>
        <td class="is-num"${r.setupParts?.length ? ` title="${optEsc(r.setupParts.join(' · '))}"` : ''}><strong class="${axisClass(r.setupScore, 2)}">${r.setupScore ?? '—'}</strong></td>
        <td>${signalCell(r.alignmentAge)}</td>
        <td>${r.rsi != null ? r.rsi.toFixed(1) : '—'}</td>
        <td>${r.forceRelative != null ? (r.forceRelative > 0 ? '+' : '') + r.forceRelative.toFixed(1) + ' pts' : '—'}</td>
        <td>${r.goldenCross == null ? '—' : (r.goldenCross ? '<span class="ds-badge ds-badge--success">Oui</span>' : '<span class="ds-badge ds-badge--danger">Non</span>')}</td>
        <td>${obvBadge(r.obvTrend)}</td>
        ${flagCell(r.price != null ? '$' + r.price.toFixed(2) : '—', f.passPrix)}
        ${flagCell(fmtVolume(r.volume), f.passVolume)}
        ${flagCell(fmtFloat(r.floatShares), f.passFloat)}
        <td class="is-num">${sz ? fmt(sz.stopDist) + '<br><span style="color:var(--text-3);font-size:11px">→ ' + fmt(sz.stopPrice) + '</span>' : `<span title="Taille non calculable : une donnée manque (ATR, VIX, RSI ou OBV). Rien n'est inventé.">N/D</span>`}</td>
        <td class="is-num">${sz ? sz.shares + ' act.<br><span class="' + (sz.depasseAlerte ? 'bad' : sz.depasseAvertissement ? 'warn' : 'ok') + '" style="font-size:11px">charge ' + sz.totalHeat.toFixed(1) + ' %</span>' + (sz.plafonneParCapital ? '<br><span class="warn" style="font-size:11px" title="' + sizingCapNote(sz).replace(/[&<>"]/g, '') + '">plafonné au capital</span>' : '') : `<span title="Taille non calculable : une donnée manque (ATR, VIX, RSI ou OBV). Rien n'est inventé.">N/D</span>`}</td>
        ${flagCell(r.daysToEarnings != null ? r.daysToEarnings + ' j' : '—', f.passEarnings)}
        <td class="is-num">${r.peRatio != null ? r.peRatio.toFixed(1) : '—'}</td>
        <td class="is-num"${r.industryPeerCount != null ? ` title="Moyenne sur ${r.industryPeerCount} titre(s) ${pairsLabel}"` : ''}>${r.industryPE != null ? r.industryPE.toFixed(1) : '—'}</td>
        ${flagCell(r.pegRatio != null ? r.pegRatio.toFixed(2) : '—', f.passPeg)}
        ${psCellHTML(r)}
        ${sectorPsCellHTML(r)}
        ${flagCell(r.beta != null ? r.beta.toFixed(2) : '—', f.passBeta)}
        <td>${vwapCell}</td>
        <td style="font-size:12px;color:var(--text-2)">${optEsc(r.secteur || '—')}</td>
        <td>${optEsc(r.industry || '—')}</td>
        <td><button type="button" class="ds-btn" style="font-size:11px;padding:3px 8px" onclick="event.stopPropagation(); prepareTradeFrom(${optEsc(JSON.stringify(r.ticker))})">Préparer</button></td>
      </tr>`;
}
function renderScreeningRows() {
  const tbody = document.getElementById('screen-tbody');
  tbody.innerHTML = lastScreeningRows
    .map((r) => screeningRowHTML(r, { onclick: 'selectScreeningRow', pairsLabel: 'de la watchlist', leadCell: pctCell(r.changePercent) }))
    .join('');
  applyScreenFilters();
}
// ---- Tri par en-tête de colonne (T5, 12/9/2026) — générique pour les deux
// tableaux (Screening et "Titres les plus performants du secteur"), qui
// partagent déjà leurs lignes via screeningRowHTML(). Trie le tableau JS en
// mémoire (lastScreeningRows/lastSectorTopRows) et redessine — aucun
// refetch, comme le filtrage côté client déjà en place. ----
const tableSortState = {}; // { 'screen-table': {field, dir}, 'sector-top-table': {field, dir} }

function compareForSort(a, b, type) {
  if (type === 'str') return String(a).localeCompare(String(b));
  if (type === 'bool') return (a === b) ? 0 : (a ? -1 : 1); // Oui avant Non par défaut
  return a - b;
}
function sortRows(rows, field, type, dir) {
  return [...rows].sort((ra, rb) => {
    const a = ra[field];
    const b = rb[field];
    // Valeurs manquantes toujours en dernier, quel que soit le sens du tri —
    // sinon inverser le tri ferait remonter les « — » en premier, ce qui
    // n'aide jamais à lire un classement.
    if (a == null && b == null) return 0;
    if (a == null) return 1;
    if (b == null) return -1;
    return dir * compareForSort(a, b, type);
  });
}
function initSortableHeaders(tableId, getRows, setRows, render) {
  document.querySelectorAll(`#${tableId} th.sortable-th`).forEach((th) => {
    th.addEventListener('click', () => {
      const field = th.dataset.field;
      const type = th.dataset.type || 'num';
      const state = tableSortState[tableId] || (tableSortState[tableId] = { field: null, dir: 1 });
      state.dir = (state.field === field) ? -state.dir : 1;
      state.field = field;
      setRows(sortRows(getRows(), field, type, state.dir));
      render();
      document.querySelectorAll(`#${tableId} th.sortable-th .sort-arrow`).forEach((el) => { el.textContent = ''; });
      th.querySelector('.sort-arrow').textContent = state.dir === 1 ? ' ▲' : ' ▼';
    });
  });
}
// Plages Prix/Float configurables (T5/T6, 6/9/2026) — préremplies depuis
// config.js, mais RECALCULÉES en direct à partir des champs si JP les
// change (contrairement aux autres filtres, à seuil fixe, ceux-ci n'ont
// plus besoin de rejouer un screening pour changer de plage).
function initScreenFilterRanges() {
  document.getElementById('filter-prix-min').value = CFG.screening.prix.min;
  document.getElementById('filter-prix-max').value = CFG.screening.prix.max;
  document.getElementById('filter-float-min').value = CFG.screening.floatMin;
  document.getElementById('filter-float-max').value = CFG.screening.floatMax;
  updateFilterRangeLabels();
}
function updateFilterRangeLabels() {
  const pMin = document.getElementById('filter-prix-min').value;
  const pMax = document.getElementById('filter-prix-max').value;
  const fMin = document.getElementById('filter-float-min').value;
  const fMax = document.getElementById('filter-float-max').value;
  document.getElementById('filter-prix-label').textContent = `${pMin}$ – ${pMax}$`;
  document.getElementById('filter-float-label').textContent = `${fMin}M – ${fMax}M`;
}
function onFilterRangeChange() {
  updateFilterRangeLabels();
  applyScreenFilters();
}
// Filtres 322 côté client — atténue (n'enlève pas) les lignes ne passant pas
// TOUS les critères cochés. null (donnée absente) ne fait pas échouer un
// filtre : on n'atténue que sur un fail explicite (false). passPrix/
// passFloat sont recalculés ICI à partir des plages configurables
// ci-dessus (pas depuis row.flags, figé au moment du screening) — les 4
// autres filtres restent ceux calculés côté serveur (seuils fixes, non
// demandés configurables).
function applyScreenFilters() {
  const active = [...document.querySelectorAll('#screen-filters input[type=checkbox]:checked')].map((c) => c.dataset.filter);
  const prixMin = +document.getElementById('filter-prix-min').value;
  const prixMax = +document.getElementById('filter-prix-max').value;
  const floatMin = +document.getElementById('filter-float-min').value;
  const floatMax = +document.getElementById('filter-float-max').value;
  document.querySelectorAll('#screen-tbody tr').forEach((tr) => {
    const ticker = tr.dataset.ticker;
    const row = lastScreeningRows.find((r) => r.ticker === ticker);
    if (!row) return;
    const floatM = row.floatShares != null ? row.floatShares / 1_000_000 : null;
    const flags = {
      ...row.flags,
      passPrix: row.price != null ? (row.price >= prixMin && row.price <= prixMax) : null,
      passFloat: floatM != null ? (floatM >= floatMin && floatM <= floatMax) : null,
    };
    const filtered = active.some((f) => flags[f] === false);
    tr.classList.toggle('row-filtered', filtered);
  });
}
function selectScreeningRow(ticker) {
  // Le tableau de screening (21 titres fixes) ne vit désormais que dans
  // l'onglet Screener — cible toujours l'instance 'scr'.
  document.getElementById(SELECTION_INSTANCES.scr.ticker).value = ticker;
  fetchLiveSelectionFor('scr');
  // Rend visible le fait que le ticker a été "déplacé" dans la section
  // Ticker — sinon, sur un écran où le tableau de screening occupe tout le
  // viewport, le changement de valeur passe inaperçu (hors du champ visuel).
  const card = document.getElementById(SELECTION_INSTANCES.scr.tickerCard);
  card.scrollIntoView({ behavior: 'smooth', block: 'center' });
  card.classList.remove('flash-highlight');
  void card.offsetWidth; // force le reflow pour pouvoir rejouer l'animation sur des clics répétés
  card.classList.add('flash-highlight');
}
async function downloadScreeningCSV() {
  try {
    const resp = await fetch('/api/screening.csv');
    if (!resp.ok) {
      const err = await resp.json();
      document.getElementById('scr-screen-status').textContent = err.error || 'Export impossible.';
      return;
    }
    const blob = await resp.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'screening-castellana.csv';
    a.click();
    URL.revokeObjectURL(url);
  } catch (err) {
    document.getElementById('scr-screen-status').textContent = 'Export impossible : ' + err.message;
  }
}
