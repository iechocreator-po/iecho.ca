# Installation — Windows et macOS

Ce document s'adresse à quelqu'un qui découvre castellana et veut simplement
la faire tourner sur sa machine. Aucune connaissance du projet n'est
supposée.

> **Révisé le 7/9/2026.** Deux choses ont beaucoup changé :
> **Python n'est plus nécessaire** (tous les indicateurs sont calculés par
> l'application elle-même), et **un seul programme tourne** au lieu de deux.
> Si vous aviez déjà installé castellana avec l'ancienne procédure, tout
> continue de fonctionner : le dossier `.venv-mcp` devient simplement inutile
> et peut être supprimé.

---

## Le chemin le plus court

Si vous avez téléchargé **castellana.zip** :

1. Décompressez le fichier où vous voulez (Bureau, Documents…).
2. **macOS** : clic droit sur `demarrer.command` → **Ouvrir** → *Ouvrir*.
   **Windows** : double-cliquez sur `demarrer.bat`.
3. Attendez. Le script vérifie ce qui manque, installe ce qu'il faut, démarre
   l'application et ouvre votre navigateur.

C'est tout. Le reste de ce document sert si quelque chose bloque, ou si vous
préférez passer par le dépôt Git.

> **macOS — pourquoi le clic droit la première fois ?** Un fichier
> téléchargé depuis un navigateur est marqué « en quarantaine » par macOS,
> qui refuse alors de l'ouvrir au double-clic (« développeur non identifié »).
> Le clic droit → Ouvrir est la façon officielle d'autoriser l'exception, une
> seule fois. Ensuite, le script lève lui-même la quarantaine sur le reste du
> dossier. Signer l'application supprimerait cette étape, mais demande un
> compte Apple Developer payant.

---

## Prérequis

**Node.js version 20 ou plus récente** — et c'est le seul.

Pour vérifier ce que vous avez déjà :

```bash
node --version
```

Si la commande est introuvable ou affiche moins que `v20`, installez la
version **LTS** depuis [nodejs.org](https://nodejs.org/). Les scripts de
démarrage ouvrent cette page tout seuls le cas échéant.

**Python n'est plus requis.** Il l'était jusqu'au 7/9/2026 pour un composant
annexe (le « sidecar » tradingview-mcp) qui fournissait le RSI, le Golden
Cross et le VIX. Ces valeurs sont désormais calculées directement par
l'application à partir des données qu'elle télécharge de toute façon —
vérifiées identiques à la décimale. L'installation est passée d'environ
223 Mo à 53 Mo.

---

## Installation depuis le dépôt Git

À faire seulement si vous n'utilisez pas le zip.

### 1. Cloner

```bash
git clone https://github.com/iechocreator-po/trading-assistant.git
cd trading-assistant
```

Le dépôt est privé : GitHub demandera une authentification. Le mot de passe
de compte ne fonctionne plus depuis 2021 — utilisez un **jeton d'accès
personnel** (GitHub → Settings → Developer settings → Personal access tokens)
comme mot de passe, ou installez [GitHub CLI](https://cli.github.com/) et
faites `gh auth login`.

### 2. Installer les dépendances

```bash
npm install
```

Identique sur Windows et macOS. Une minute environ la première fois.

### 3. Vérifier que tout est en place

```bash
npm run doctor
```

Cette commande contrôle un par un : la version de Node, les dépendances, la
base de données, les droits d'écriture, le port, et la joignabilité de Yahoo
Finance. **Chaque ligne en échec indique quoi faire.** C'est le premier
réflexe quand quelque chose ne va pas — avant de chercher dans ce document.

### 4. Lancer

```bash
npm start
```

L'adresse s'affiche dans le terminal (`http://127.0.0.1:4700` en général).
Ouvrez-la dans votre navigateur.

Si le port 4700 est déjà occupé, l'application en choisit un autre toute
seule (4711 à 4715) et annonce lequel — il n'y a rien à configurer.

---

## Le sidecar Python — facultatif, et déconseillé

Le composant `tradingview-mcp` n'est **plus nécessaire**. Il n'apporte aucune
donnée que l'application ne calcule déjà, coûte environ 170 Mo, ajoute un
second programme à garder en vie, et dépend d'une source de données qui
refusait périodiquement de répondre (elle perdait environ 14 % des titres
lors d'un screening).

Il reste installable pour qui veut **comparer** les deux sources :

- **macOS** : double-cliquez sur `installer-sidecar.command`
- **Windows** : double-cliquez sur `installer-sidecar.bat`

Le script demande confirmation, installe le composant et l'active dans
`settings.json`. Il faut ensuite lancer **deux** programmes : `npm start` et
`npm run sidecar`, dans deux terminaux séparés.

Pour revenir en arrière : remettre `"enabled": false` dans la section
`tradingviewMcp` de `settings.json`. Le dossier `.venv-mcp` peut être
supprimé.

---

## Mises à jour

L'application vérifie au démarrage si une version plus récente est publiée.
Le cas échéant, un bandeau apparaît en haut de la page avec un bouton
**Mettre à jour**.

Un clic télécharge et installe la nouvelle version, puis redémarre
l'application. **Votre journal de trades, vos réglages et votre watchlist ne
sont pas touchés**, et la version précédente est conservée en sauvegarde dans
`data/.update/`. Si quoi que ce soit échoue pendant le téléchargement ou la
vérification, rien n'est modifié.

Si l'application ne se relance pas d'elle-même après la mise à jour,
relancez `demarrer.command` / `demarrer.bat`.

---

## Dépannage

**Commencez toujours par `npm run doctor`.** La plupart des cas ci-dessous y
sont diagnostiqués directement, avec le remède.

### `npm install` échoue sur `better-sqlite3` (Windows)

C'est le seul composant de l'application qui peut nécessiter une compilation.
Il télécharge normalement une version précompilée ; si aucune ne correspond à
votre machine, il tente de compiler et a alors besoin d'outils absents par
défaut.

Installez **Visual Studio Build Tools** (charge de travail « Développement
Desktop en C++ »), depuis
[visualstudio.microsoft.com/downloads](https://visualstudio.microsoft.com/downloads/),
puis relancez `npm install`.

### `npm install` échoue avec une erreur `EACCES` (macOS)

Le cache npm appartient à un autre utilisateur. Deux options :

```bash
npm install --cache /tmp/npm-cache-castellana
```

ou, définitivement :

```bash
sudo chown -R $(id -u):$(id -g) ~/.npm
```

### Le port est déjà utilisé

Normalement, il n'y a rien à faire : l'application se replie automatiquement
sur un autre port et annonce lequel.

Si vous voulez quand même libérer le 4700 — par exemple parce qu'une ancienne
instance de castellana tourne encore :

```bash
# macOS
lsof -ti:4700 -sTCP:LISTEN | xargs kill
```

```powershell
# Windows (PowerShell)
Get-NetTCPConnection -LocalPort 4700 -State Listen | Select-Object -ExpandProperty OwningProcess | ForEach-Object { Stop-Process -Id $_ }
```

### La page s'affiche mais tous les chiffres sont vides

L'application est ouverte, mais son serveur ne répond plus. Le témoin en haut
de page l'indique en clair, avec la cause.

Relancez `demarrer.command` / `demarrer.bat`, ou `npm start`.

### Le témoin « tradingview-mcp » est gris

C'est normal, et voulu : gris signifie **désactivé**, pas en panne. Ce
composant est optionnel depuis le 7/9/2026 et l'application n'en a pas
besoin. Seul un point **rouge** signale un vrai problème, toujours accompagné
de son explication.

### `git clone` demande un mot de passe et le refuse

GitHub n'accepte plus les mots de passe de compte en ligne de commande. Voir
la section « Cloner » plus haut : jeton d'accès personnel, ou `gh auth login`.

### Rien de tout ça n'a marché

Envoyez à Jean-Pierre la sortie complète de `npm run doctor` : elle contient
l'essentiel de ce qu'il faut pour diagnostiquer.
