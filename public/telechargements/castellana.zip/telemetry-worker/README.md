# castellana-telemetry

Petit collecteur de télémétrie pour castellana. **Ce n'est pas castellana
lui-même** — castellana reste une app 100% locale, lancée par chaque
testeur sur sa propre machine (voir [`../SETUP.md`](../SETUP.md)). Ce
Worker est le seul morceau de castellana déployé publiquement : il reçoit
les événements que chaque instance locale lui envoie directement depuis le
navigateur (ticker sélectionné, paramètre modifié, chargement de l'app).

Voir `../CLAUDE.md`, section « Télémétrie testeurs », pour le contexte
complet et le détail des événements capturés.

## Déploiement (geste manuel, une seule fois)

Prérequis : un compte Cloudflare (déjà utilisé ailleurs dans le portfolio),
`wrangler` (installé via `npm install` dans ce dossier).

```bash
cd telemetry-worker
npm install
npx wrangler login          # une seule fois, ouvre le navigateur

# 1. Créer la base D1
npx wrangler d1 create castellana-telemetry-db
# → copier le "database_id" affiché dans la sortie de cette commande
#   et le coller dans wrangler.jsonc, champ d1_databases[0].database_id

# 2. Appliquer le schéma à la base fraîchement créée
npx wrangler d1 execute castellana-telemetry-db --remote --file=schema.sql

# 3. Déployer le Worker
npx wrangler deploy
# → l'URL affichée (ex: https://castellana-telemetry.<sous-domaine>.workers.dev)
#   est à coller dans ../config.js, champ CFG.telemetry.endpoint
```

## Après le déploiement

1. Coller l'URL du Worker dans `../config.js` → `CFG.telemetry.endpoint`.
2. Vérifier que `CFG.telemetry.sharedToken` (dans `../config.js`) est
   identique à `TELEMETRY_TOKEN` (dans `wrangler.jsonc`, section `vars`) —
   ce sont deux copies manuelles du même jeton, aucune synchronisation
   automatique.
3. Tester : lancer castellana en local, choisir un nom dans le sélecteur du
   header, changer un ticker → dans `wrangler.jsonc` remplacé par la vraie
   URL, ouvrir `https://<votre-url>.workers.dev/dashboard?token=<le jeton>`
   et confirmer que l'événement apparaît.

## Consulter les événements

- Tableau de bord (activité par jour, tickers les plus sélectionnés, filtre
  par testeur et par plage de jours 7/30/90, + les 200 derniers événements
  de la période filtrée) : `GET /dashboard?token=<jeton>` — paramètres
  optionnels `&who=<nom>` et `&days=<7|30|90>`.
- Export CSV complet (5000 derniers, non filtré) : `GET /events.csv?token=<jeton>`
- Requête SQL directe (sans passer par le Worker) :
  ```bash
  npx wrangler d1 execute castellana-telemetry-db --remote --command \
    "SELECT * FROM telemetry_events ORDER BY id DESC LIMIT 20"
  ```

## Mettre à jour le schéma ou le code

Après toute modification de `schema.sql` ou `src/index.js` :
```bash
npx wrangler d1 execute castellana-telemetry-db --remote --file=schema.sql   # si schéma changé
npx wrangler deploy                                                          # à chaque changement de code
```

## Limites assumées (voir `../CLAUDE.md`)

- `TELEMETRY_TOKEN` n'est **pas** une vraie sécurité — juste un filtre
  anti-bruit. N'importe qui avec accès à castellana peut le lire dans le
  code source du navigateur.
- Aucune authentification des testeurs (T3, login, est explicitement
  reporté) — le champ « who » est une auto-déclaration, pas une identité
  vérifiée. L'IP capturée par le Worker est un complément, pas une preuve.
