// Onglet « Anticipation » (12/10/2026, bilbao #418) — CLOUD SEULEMENT, derrière le drapeau
// anticipation_tab (OFF par défaut, activé par compte depuis bilbao). Les maquettes de fonctionnalités à
// venir : on vote (5 votes actifs, reprenables), on ouvre la maquette, on propose une amélioration.
//
// Rien ici n'est une fonctionnalité : chaque maquette est du HTML autonome avec des chiffres d'exemple,
// servi par l'API (authentifiée, drapeau vérifié) et affiché dans une iframe `sandbox` sans aucune
// permission — jamais injecté dans la page. Les règles de vote sont côté serveur (lib/anticipation-logic.js) ;
// l'écran ne fait que les afficher. Pas de copie locale : l'app locale n'a ni comptes ni base partagée.

let anticState = null;
let anticFilter = 'toutes';
let anticSort = 'votes';
let anticOpenId = null;

const ANTIC_STATUT = {
  maquette: { label: 'Maquette', cls: '' },
  planifiee: { label: 'Planifiée', cls: 'ds-badge--warning' },
  en_construction: { label: 'En construction', cls: 'ds-badge--warning' },
  livree: { label: 'Livrée', cls: 'ds-badge--success' },
  rejetee: { label: 'Rejetée', cls: 'ds-badge--danger' },
};

function anticEsc(t) { return String(t ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function anticDate(iso) {
  const d = new Date(iso + 'T12:00:00');
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleDateString('fr-CA', { day: 'numeric', month: 'short', year: 'numeric' });
}

// Révèle l'onglet seulement si le serveur confirme le drapeau pour CE compte.
async function initAnticipationVisibility() {
  const btn = document.getElementById('tab-btn-anticipation');
  try {
    const { flags } = await fetchJSON('/api/flags');
    if (flags && flags.anticipation_tab === true) {
      if (btn) btn.style.display = '';
      await loadAnticipation();
      loadAnticipationProposals();
    }
  } catch { /* l'onglet reste caché */ }
}

async function loadAnticipation() {
  const box = document.getElementById('antic-content');
  if (!box) return;
  try {
    anticState = await fetchJSON('/api/anticipation');
    renderAnticipation();
  } catch (err) {
    box.innerHTML = `<p class="metric-sub" style="text-align:left;">Impossible de charger l'onglet : ${anticEsc(err.message)}</p>`;
  }
}

// Aucun gestionnaire en ligne : les identifiants passent par des attributs de données et un écouteur délégué posé UNE fois.
// (Un texte placé dans `onclick="f('…')"` sort de son échappement HTML au moment où le navigateur le décode : voir l'audit
// onglets, 20/10/2026, constat 1. Ici les identifiants viennent du serveur, mais l'habitude est la même que celle qui a fait l'erreur.)
function anticBind(box) {
  if (box.dataset.anticBound) return;
  box.dataset.anticBound = '1';
  box.addEventListener('click', (e) => {
    const el = e.target.closest ? e.target.closest('[data-antic]') : null;
    if (!el || !box.contains(el)) return;
    const a = el.dataset.antic;
    if (a === 'filter') anticSetFilter(el.dataset.value);
    else if (a === 'vote') anticToggleVote(el.dataset.id, el.dataset.on === 'true');
    else if (a === 'maquette') anticToggleMaquette(el.dataset.id);
  });
  box.addEventListener('change', (e) => { if (e.target.dataset && e.target.dataset.antic === 'sort') anticSetSort(e.target.value); });
}

function renderAnticipation() {
  const box = document.getElementById('antic-content');
  if (!box || !anticState) return;
  anticBind(box);
  const s = anticState;
  const present = [...new Set(s.cards.map((c) => c.statut))];
  const chips = ['toutes', ...Object.keys(ANTIC_STATUT).filter((k) => present.includes(k))].map((k) => {
    const on = anticFilter === k;
    const n = k === 'toutes' ? s.cards.length : s.cards.filter((c) => c.statut === k).length;
    const label = k === 'toutes' ? 'Toutes' : ANTIC_STATUT[k].label;
    return `<button type="button" class="antic-chip${on ? ' is-on' : ''}" aria-pressed="${on}" data-antic="filter" data-value="${anticEsc(k)}">${label} (${n})</button>`;
  }).join('');
  let cards = s.cards.filter((c) => anticFilter === 'toutes' || c.statut === anticFilter);
  cards = [...cards].sort((a, b) => anticSort === 'date'
    ? b.date.localeCompare(a.date) || b.votes - a.votes
    : b.votes - a.votes || b.date.localeCompare(a.date));
  const list = cards.map((c) => {
    const st = ANTIC_STATUT[c.statut] || ANTIC_STATUT.maquette;
    const closed = c.statut === 'livree' || c.statut === 'rejetee';
    const canVote = c.voted || (!closed && s.remaining > 0);
    const label = c.voted ? 'Voté' : closed ? 'Close' : s.remaining > 0 ? 'Voter' : 'Plus de vote';
    const open = anticOpenId === c.id;
    return `<article class="antic-card" data-card="${anticEsc(c.id)}">
      <div class="antic-vote">
        <button type="button" class="antic-vote-btn${c.voted ? ' is-on' : ''}" aria-pressed="${c.voted}" ${canVote ? '' : 'disabled'}
          aria-label="${c.voted ? 'Retirer mon vote pour' : 'Voter pour'} ${anticEsc(c.titre)}" data-antic="vote" data-id="${anticEsc(c.id)}" data-on="${!c.voted}">
          <svg aria-hidden="true" width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l4-4 4 4"/></svg>
          <span>${c.votes}</span>
        </button>
        <span class="metric-sub">${label}</span>
      </div>
      <div class="antic-main">
        <div><span class="ds-badge ${st.cls}">${st.label}</span> <span class="metric-sub">Onglet concerné : ${anticEsc(c.onglet)}</span></div>
        <h3 class="antic-title">${anticEsc(c.titre)}</h3>
        <p class="antic-desc">${anticEsc(c.description)}</p>
        <div class="metric-sub">
          <button type="button" class="ds-btn ds-btn--sm" aria-expanded="${open}" data-antic="maquette" data-id="${anticEsc(c.id)}">${open ? 'Fermer la maquette' : 'Ouvrir la maquette'}</button>
          <span style="margin-left:10px;">Proposée le ${anticEsc(anticDate(c.date))}</span>
        </div>
        ${open ? `<div class="antic-frame-wrap"><p class="metric-sub" style="text-align:left;">Maquette non fonctionnelle, chiffres d'exemple.</p>
          <iframe id="antic-frame-${anticEsc(c.id)}" class="antic-frame" sandbox="" title="Maquette : ${anticEsc(c.titre)}"></iframe></div>` : ''}
      </div>
    </article>`;
  }).join('') || '<p class="metric-sub" style="text-align:left;">Aucune carte dans ce statut.</p>';
  box.innerHTML = `
    <div class="antic-toolbar">
      <div class="antic-chips" role="group" aria-label="Filtrer par statut">${chips}</div>
      <label class="metric-sub">Trier par
        <select class="ds-select" data-antic="sort" style="width:auto;display:inline-block;">
          <option value="votes"${anticSort === 'votes' ? ' selected' : ''}>Les plus votées</option>
          <option value="date"${anticSort === 'date' ? ' selected' : ''}>Les plus récentes</option>
        </select></label>
    </div>
    <p class="metric-sub antic-remaining" style="text-align:left;"><strong>${s.remaining}</strong> vote${s.remaining > 1 ? 's' : ''} restant${s.remaining > 1 ? 's' : ''} sur ${s.maxVotes}. Un vote se reprend à tout moment ; une carte livrée ou rejetée rend ses votes.</p>
    <div class="antic-list">${list}</div>`;
  if (anticOpenId) anticLoadFrame(anticOpenId);
}

function anticSetFilter(k) { anticFilter = k; renderAnticipation(); }
function anticSetSort(v) { anticSort = v; renderAnticipation(); }

async function anticToggleVote(id, on) {
  try {
    anticState = await fetchJSON(`/api/anticipation/${encodeURIComponent(id)}/vote`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ on }),
    });
    renderAnticipation();
  } catch (err) {
    const s = document.getElementById('antic-status');
    if (s) s.textContent = err.message;
    await loadAnticipation(); // recale l'écran sur ce que le serveur a vraiment enregistré
  }
}

function anticToggleMaquette(id) {
  anticOpenId = anticOpenId === id ? null : id;
  renderAnticipation();
}

// Le HTML de la maquette vient de l'API (authentifiée) ; il va dans `srcdoc` d'une iframe sans aucune
// permission (`sandbox=""`) : ni script, ni formulaire, ni accès à la page ou aux cookies.
async function anticLoadFrame(id) {
  const frame = document.getElementById('antic-frame-' + id);
  if (!frame) return;
  try {
    const res = await fetch(`/api/anticipation/${encodeURIComponent(id)}/maquette`, { credentials: 'same-origin' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    frame.srcdoc = await res.text();
  } catch (err) {
    frame.srcdoc = '<p style="font:14px sans-serif;padding:16px;">Maquette indisponible : ' + anticEsc(err.message) + '</p>';
  }
}

async function loadAnticipationProposals() {
  const box = document.getElementById('antic-mine');
  if (!box) return;
  try {
    const { proposals } = await fetchJSON('/api/anticipation/proposals');
    box.innerHTML = proposals.length
      ? '<p class="metric-sub" style="text-align:left;"><strong>Vos propositions</strong></p><ul class="metric-sub" style="text-align:left;margin:4px 0 0 18px;">'
        + proposals.map((p) => `<li>${anticEsc(p.titre)} <span class="ds-badge">${anticEsc(p.statut)}</span></li>`).join('') + '</ul>'
      : '';
  } catch { box.innerHTML = ''; }
}

async function anticSubmitProposal(ev) {
  ev.preventDefault();
  const status = document.getElementById('antic-status');
  const f = ev.target;
  const body = { titre: f.titre.value, onglet: f.onglet.value, description: f.description.value };
  status.textContent = 'Envoi…';
  try {
    await fetchJSON('/api/anticipation/proposals', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    f.reset();
    status.textContent = 'Proposition enregistrée. JP la lira.';
    loadAnticipationProposals();
  } catch (err) {
    status.textContent = err.message;
  }
}
