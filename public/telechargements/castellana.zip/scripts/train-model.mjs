// Évalue la régression logistique P(R > 1) en progression dans le temps (#399) et dit si elle
// mérite d'être adoptée. Usage : node scripts/train-model.mjs [data/dataset-elargi.csv] [lambda=1]
import { readFileSync, writeFileSync } from 'node:fs';
import { walkForward, topQuantileRows, bootstrapMeanDiff, auc, brier, calibration, FEATURE_NAMES, fitPreprocessor, fitLogistic } from '../server/ml-logistic.js';

const file = process.argv[2] || 'data/dataset-elargi.csv';
const lambda = Number(process.argv[3]) || 1;
const [head, ...lines] = readFileSync(file, 'utf8').trim().split('\n');
const cols = head.split(',');
const rows = lines.map((l) => Object.fromEntries(l.split(',').map((c, i) => [cols[i], c])));
rows.forEach((r) => { r.r_net = +r.r_net; r.win_1r = +r.win_1r; });

const years = [...new Set(rows.map((r) => +r.signal_date.slice(0, 4)))].sort();
const testYears = years.slice(2); // au moins deux années d'entraînement avant le premier test
const folds = walkForward(rows, { testYears, lambda });
if (!folds.length) { console.error('Pas assez de données pour un fold.'); process.exit(1); }

const pct = (x) => (x == null ? '—' : (x * 100).toFixed(1) + ' %');
const f3 = (x) => (x == null ? '—' : x.toFixed(3));
console.log(`\n${rows.length} trades, folds de test : ${folds.map((f) => f.year).join(', ')} (λ=${lambda})\n`);
console.log('Année  entr.  test   P(R>1) base  AUC     Brier modèle / base');
for (const f of folds) {
  const y = f.test.map((t) => t.win_1r);
  console.log(`${f.year}  ${String(f.trainN).padStart(5)} ${String(f.testN).padStart(5)}   ${pct(f.baseRate).padStart(7)}  ${f3(auc(f.p, y))}  ${f3(brier(f.p, y))} / ${f3(brier(f.p.map(() => f.baseRate), y))}`);
}

const p = folds.flatMap((f) => f.p), y = folds.flatMap((f) => f.test.map((t) => t.win_1r));
const allTest = folds.flatMap((f) => f.test);
const pooledAuc = auc(p, y);
const brierModel = brier(p, y);
const brierBase = brier(folds.flatMap((f) => f.test.map(() => f.baseRate)), y);
console.log(`\nAgrégé hors échantillon : AUC ${f3(pooledAuc)} · Brier ${f3(brierModel)} (base ${f3(brierBase)})`);

console.log('\nCalibration (probabilité prédite → fréquence observée) :');
for (const c of calibration(p, y, 5)) console.log(`  ${pct(c.predicted).padStart(7)} → ${pct(c.observed).padStart(7)}   (n=${c.n})`);

const meanR = (a) => a.reduce((s, r) => s + r.r_net, 0) / a.length;
const top = topQuantileRows(folds, 0.2);
const diff = bootstrapMeanDiff(top.map((r) => r.r_net), allTest.map((r) => r.r_net));
console.log(`\nR net moyen — tous les trades du test : ${f3(meanR(allTest))} (n=${allTest.length})`);
console.log(`R net moyen — 20 % meilleures probabilités : ${f3(meanR(top))} (n=${top.length})`);
console.log(`Écart : ${f3(diff.mean)}  IC 95 % [${f3(diff.lo)} ; ${f3(diff.hi)}] (bootstrap par trade, optimiste)`);

// Règle d'adoption fixée AVANT de regarder : discrimination réelle, mieux que la base en Brier,
// et un écart de R net dont la borne basse est > 0.
const checks = {
  'AUC agrégé ≥ 0,55': pooledAuc >= 0.55,
  'Brier meilleur que la base': brierModel < brierBase,
  'AUC > 0,5 dans au moins 3/4 des années': folds.filter((f) => auc(f.p, f.test.map((t) => t.win_1r)) > 0.5).length >= Math.ceil(folds.length * 0.75),
  "Écart de R net du top 20 % : borne basse > 0": diff.lo > 0,
};
console.log('\nRègle d\'adoption :');
for (const [k, v] of Object.entries(checks)) console.log(`  ${v ? '✓' : '✗'} ${k}`);
const adopt = Object.values(checks).every(Boolean);
console.log(`\nVERDICT : ${adopt ? 'ADOPTION POSSIBLE (à confirmer sur le S&P 500)' : 'NON ADOPTÉ — ne pas afficher de probabilité'}`);

// Coefficients du modèle sur toutes les données (lecture seulement, pas pour la prédiction).
const prep = fitPreprocessor(rows);
const full = fitLogistic(rows.map(prep.transform), rows.map((r) => r.win_1r), { lambda });
console.log('\nCoefficients (variables standardisées, modèle sur tout le jeu — pour lecture) :');
FEATURE_NAMES.map((n, i) => [n, full.coefs[i]]).sort((a, b) => Math.abs(b[1]) - Math.abs(a[1])).forEach(([n, c]) => console.log(`  ${n.padEnd(22)} ${c >= 0 ? '+' : ''}${c.toFixed(3)}`));

writeFileSync('data/model-report.json', JSON.stringify({ generatedAt: new Date().toISOString(), file, lambda, n: rows.length, folds: folds.map((f) => ({ year: f.year, trainN: f.trainN, testN: f.testN, auc: auc(f.p, f.test.map((t) => t.win_1r)) })), pooledAuc, brierModel, brierBase, topMeanR: meanR(top), allMeanR: meanR(allTest), diff, checks, adopt }, null, 2));
