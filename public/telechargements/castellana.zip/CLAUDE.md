# castellana — Assistant de swing trading (screening, sizing, exécution, journal)

> **Nom de code :** castellana — **Dossier :** `trading-assistant/`
> (convention portfolio : le dossier porte un nom fonctionnel, le nom de code
> — ville espagnole/portugaise — vit dans le code, les configs et les
> conversations. Voir la table « Dossier local » du `CLAUDE.md` racine.)
>
> **Dernière vérification factuelle :** 2026-09-07, 2e session (**refonte
> de fiabilité et d'installation, à partir d'un audit**). JP veut mettre
> castellana « dans les mains de personnes sérieuses ». Point de départ : un
> audit fonctionnel et technique mené sur l'instance en marche (8 constats,
> F1→F8), dont le constat structurant était que **le sidecar Python ne
> fournit rien que l'app ne puisse recalculer depuis l'historique Yahoo
> qu'elle télécharge déjà**. Revérifié moi-même avant de coder, puis sur les
> 21 titres de la watchlist : **zéro écart** au-delà de l'arrondi sur les 19
> titres que le sidecar sait traiter, et les 2 qu'il ne résolvait pas du tout
> (PLTR, XEQT.TO) sont désormais couverts. Décision de JP : le sidecar n'est
> pas supprimé mais **rendu optionnel et désactivé par défaut**. Résultats
> mesurés : screening **37 s → 1,99 s** (0,37 s cache de données chaud,
> 0,02 s cache de screening), **21/21 titres complets** contre 18/21,
> installation **223 Mo → 53 Mo** et **2 prérequis → 1** (Python sort du
> chemin par défaut), **32 tests** contre 7. **Deux recommandations de
> l'audit corrigées en les mesurant** : `node:sqlite` n'existe pas sur le
> Node 22.12 de JP (il faut `--experimental-sqlite`) donc `better-sqlite3`
> est conservé ; et un cache long (12-24 h) aurait figé des prix
> intrajournaliers, donc les TTL sont courts. Voir la section « Refonte de
> fiabilité » plus bas pour le détail complet.
>
> Vérification précédente : 2026-09-07 (**tableau de bord de
> télémétrie enrichi**). JP a demandé de pouvoir « récupérer la télémétrie
> et en faire un dashboard » — plutôt qu'un nouvel outil séparé ou un
> Artifact Claude (**écarté** : le pare-feu réseau des Artifacts bloque
> tout `fetch()` vers un hôte externe comme le Worker de télémétrie),
> décision d'enrichir directement la route `/dashboard` déjà déployée
> (`telemetry-worker/src/index.js`) — accès direct à D1, déjà protégée par
> le même jeton. Ajouté : activité par jour (barres verticales, SVG à la
> main, skill `dataviz` du portfolio consultée), tickers les plus
> sélectionnés (barres horizontales classées, `json_extract` sur le
> payload), filtre par testeur + plage de jours (7/30/90), info-bulle au
> survol. **Découverte en testant** : la base contenait déjà de la vraie
> télémétrie (JP avait utilisé castellana après le déploiement précédent)
> — le nettoyage post-test a dû cibler précisément les lignes de test
> ajoutées cette session (`WHERE id >= 9`) pour préserver ces 7 événements
> réels, plutôt qu'un nettoyage global qui les aurait détruits. Vérifié en
> direct dans le navigateur (filtre, info-bulles, état vide). Voir section
> « Télémétrie testeurs » plus bas pour le détail complet. **Même session,
> séparation des stratégies Labo** : « La Roue & Debit Spreads » (une seule
> entrée depuis le 5/9/2026) devient deux entrées distinctes, `roue` et
> `debit-spreads` — pur réarrangement du contenu existant, aucun nouveau
> calcul. Voir section « Séparation La Roue / Debit Spreads » plus bas.
>
> Vérification précédente : 2026-09-06 (**télémétrie testeurs**).
> JP prépare la mise dans les mains de 2 testeurs (chacun lance castellana en
> local, comme lui — décidé après avoir vérifié que l'app entière ne peut PAS
> aller sur Cloudflare telle quelle : Express persistant + `better-sqlite3`
> natif + sidecar Python, incompatibles avec le modèle Workers). Un nouveau
> Cloudflare Worker + D1 (`telemetry-worker/`, **premier composant de
> castellana jamais déployé publiquement** — mais seulement ce collecteur,
> pas l'app) capture 3 événements envoyés directement par le navigateur de
> chaque testeur (`app_loaded`, `ticker_selected`, `param_changed`) — qui,
> quand, quel ticker, quel paramètre changé (ancienne/nouvelle valeur). Pas
> un vrai login (T3 reporté) — juste un sélecteur de nom + l'IP capturée
> côté Worker. `server/index.js` non touché. Détail complet dans la section
> « Télémétrie testeurs » plus bas. **Worker déployé le 6/9/2026** —
> https://castellana-telemetry.iechocreator.workers.dev, testé en direct
> (événement de test inséré puis retiré, jeton invalide bien rejeté en 401,
> `/dashboard` et `/events.csv` vérifiés). **Même session, ajout d'un
> bouton « Partager une idée »** — popup repris tel quel du popup public
> iecho.ca (`FeedbackWidget.astro`), même formulaire Formspree (les idées
> des deux produits atterrissent dans la même boîte de réception), seule
> différence : « Produit concerné » est pré-sélectionné sur `castellana` au
> lieu de vide. **Nouvel onglet « Concepts » dans Réglages** — guide de 15
> concepts de trading transcrit d'un fichier `madrid`
> (`investment-dashboard/indicateur/GUIDE_15_CONCEPTS_TRADING.md`, texte +
> 15 images copiés, aucun lien dynamique entre les deux repos). Voir
> sections dédiées plus bas.
>
> Vérification précédente : 2026-09-05 (**nouvel onglet Labo —
> stratégies d'options**). 5 onglets désormais (Secteurs/Screener/Fiche de
> trade/Journal/**Labo**). Le Labo laisse choisir une stratégie d'options
> (sélecteur), saisir un ticker, et affiche la séquence pas-à-pas à suivre
> pour l'appliquer, avec des données réelles du titre (prix, ATR, beta,
> volume — `GET /api/labo/:ticker`, Yahoo Finance direct, indépendant du
> sidecar tradingview-mcp et de son rate-limit). Deux stratégies
> implémentées, deux marquées « bientôt disponible » (Iron Condor, Credit
> Spreads) plutôt que masquées — même discipline que le hub essen
> (« ne jamais pousser un lien avant que le contenu réponde »). **Écart
> réel trouvé et clarifié avant de coder** : le fichier fourni par JP,
> `strategy/PoorManCoveredCall.md.rtf`, ne décrit PAS la stratégie Poor
> Man's Covered Call (LEAPS call + call court vendu contre) malgré son nom
> — il décrit un système différent, « La Roue & Debit Spreads » (Cash-
> Secured Put → Covered Call, puis Bull Call/Bear Put Spread). Signalé à JP
> avant d'implémenter (`AskUserQuestion`) : décision de garder les deux,
> distinctes, dans le sélecteur — le contenu réel du fichier sous son
> propre nom, et une vraie PMCC selon la définition standard, écrite sans
> dépendre du fichier. **Aucune donnée d'options réelle (chaîne, delta,
> prime) n'est branchée dans cette app** — les « zones de strike » de la
> séquence sont une estimation ATR autour du prix, explicitement étiquetée
> comme telle partout où elle apparaît (disclaimer dédié + note par étape),
> jamais présentée comme une vraie donnée de marché. Détail complet dans la
> section dédiée plus bas.
>
> Vérification précédente : 2026-09-02 (**secteurs USD/CAD,
> nouvel onglet Screener, top titres par secteur** — 4 onglets désormais
> (Secteurs/Screener/Fiche de trade/Journal), sélecteur de devise sur la
> carte Performance des secteurs (USD/CAD, tickers BMO vérifiés en direct),
> clic sur un secteur affiche ses titres les plus performants (liste
> curatée par secteur, pas un scan de marché — l'endpoint screener
> personnalisé de Yahoo Finance s'est révélé bloqué en test réel pour un
> usage anonyme, 429 systématique sur un endpoint probablement réservé aux
> comptes connectés, non contourné conformément au principe déjà en place
> dans ce fichier sur les vrais anti-bots). Le mode CAD "couvert contre le
> risque de change" envisagé en cadrage a été abandonné en cours de route :
> vérifié en direct qu'aucun des 11 ETF sectoriels BMO n'a de version
> couverte listée sur Yahoo. Détail complet dans la section dédiée plus
> bas.)
>
> Vérification précédente : 2026-08-31
> **Statut :** cadrage initial — document de design consolidé, design system
> vendoré, les deux prototypes fusionnés en une seule app à onglets
> (`index.html`), fichier de réglages (`config.js`) créé, repo GitHub créé et
> poussé, produit ajouté au `CLAUDE.md` racine (table sommaire, fiche
> détaillée, mapping code→dossier). Stack backend tranchée et **scaffoldée**
> (Node Express + better-sqlite3, `http://127.0.0.1:4700/`) ; `tradingview-mcp`
> **branché** (sidecar Python) — fiable pour VIX/RSI/Golden Cross/force
> relative. **Frontend câblé sur les données temps réel** (boutons
> « Récupérer en direct » + tableau de screening 20 titres, testés en
> direct). **Rate-limit non documenté confirmé à deux reprises** sur
> `coin_analysis` (RSI/Golden Cross) — l'app reste utilisable en dégradé
> grâce à la résilience par source. **Tous les calculs maison livrés**
> (`server/indicators.js` : OBV réel, SMA 9/21/100, ATR réel, volume vs
> moyenne 20j — historique Yahoo Finance direct via `yahoo-finance2`,
> indépendant de `coin_analysis`) — score du screening à 4 colonnes
> complètes, Fiche de trade entièrement câblée sur les données en direct.
> **Témoin de statut backend** (header, 3 indicateurs : Express/
> tradingview-mcp/calculs maison, auto-actualisé) ajouté. **P/E ratio,
> industrie et P/E moyen de l'industrie ajoutés au tableau de screening**, et
> **carte « Performance des secteurs »** (tableau + line graph interactif
> 11 secteurs/S&P 500, période 1 semaine à 12 mois) ajoutée au-dessus du
> screening (29/8/2026, demandes de JP). **Terminologie et calcul du filtre
> de tendance corrigés (29/8/2026)** : c'était une SMMA (moyenne lissée/RMA)
> présentée tantôt comme « SMMA » tantôt comme « MM » selon l'écran — JP a
> demandé une vraie SMA (Simple Moving Average) partout, code et texte ;
> fait, `computeSMA()` en fenêtre glissante remplace `computeSMMA()` pour le
> filtre 9/21/100 (l'ATR garde son propre lissage RMA, correct par
> définition, renommé `computeRMA()` pour ne plus prêter à confusion).
> **Menu Réglages plein écran** (⚙, même principe que essen/
> nemesis-retaliation) remplace l'ancien bloc d'aide replié. **Bug réel
> trouvé et corrigé** : `fetchJSON()` ignorait silencieusement les options
> `POST`/`PUT` depuis le début — `addWatchlist()` et la clôture d'un trade
> (`closeTrade()`) ne faisaient donc jamais ce qu'ils semblaient faire.
> **`README.md`/`SETUP.md` réécrits pour un tiers (30/8/2026)** — un
> collègue de JP, ajouté comme collaborateur GitHub, n'arrivait pas à
> lancer le projet ; l'ancien `README.md` ne contenait que des commandes
> macOS non expliquées. Au passage, un vrai bug Windows trouvé et corrigé :
> le script `npm run sidecar` codait en dur un chemin Unix
> (`.venv-mcp/bin/...`), impossible à trouver sur un venv créé côté Windows
> (`.venv-mcp\Scripts\...`) — remplacé par `scripts/run-sidecar.mjs`
> (détection de `process.platform`, zéro dépendance ajoutée). Voir section
> « Documentation d'installation pour un tiers » plus bas. **Corrigé côté
> code et testé sur macOS ; pas testé sur une vraie machine Windows.**
> **Statut technique désormais explicite (30/8/2026)** : un point rouge
> dans le témoin de statut affiche maintenant la vraie cause en clair
> (ex. « Sidecar non démarré ou injoignable sur http://127.0.0.1:4701/mcp »)
> au lieu d'un simple point rouge muet — demande directe de JP après avoir
> vu une pastille rouge sans explication. **PEG moyen ajouté à la carte
> Performance des secteurs** — approximation par pairs de watchlist (Yahoo
> n'expose aucun PEG au niveau ETF/secteur), couverture partielle assumée
> et affichée honnêtement (7 des 11 secteurs n'ont aucun titre suivi dans
> la watchlist actuelle, donc « — »). **Disclaimer bilingue FR/EN** ajouté
> en haut de page (même patron que marbella). **Confirmé à JP** : aucun
> compte TradingView n'est nécessaire, à aucune étape — documenté
> explicitement dans `README.md`/`SETUP.md`.
> **Trois pistes d'amélioration planifiées et livrées (31/8/2026)** :
> watchlist élargie à **XEQT.TO** (repère diversifié, PAS un comblement des
> trous sectoriels — RSI/Golden Cross indisponibles pour ce titre via
> tradingview-mcp, limite documentée) ; **édition d'un trade existant**
> dans le journal (bouton Modifier, réutilise le PUT déjà existant) + **export
> CSV du journal** ; **tests automatisés** (`node:test` natif, 7 tests sur
> `server/indicators.js`, `npm test`). Ajoutées au roadmap bilbao (features
> #345-347, statut `Planifie`) avant implémentation. Reste à construire :
> les feature flags (en attente d'une session bilbao — voir Checklist
> portfolio en bas de fichier), les trous sectoriels du P/E industrie/PEG
> moyen avec de vrais titres individuels (pas scopé, JP n'a demandé que
> XEQT).

## Démarrage de session — features en attente

Décision portfolio (R24, 2026-07-20) : **bilbao** (`../feature-factory/`) est
l'**unique source de vérité** des features/roadmap de ce produit — pas de
roadmap locale (la section « Feuille de route suggérée » plus bas n'est qu'un
résumé d'orientation, pas la liste vivante). **À chaque nouvelle session sur
castellana, commencer par présenter la liste des features/idées/questions dont
le statut n'est ni `Livre` ni `Rejete`**, lue directement dans l'export JSON
(pas besoin que bilbao tourne) :

```bash
python3 -c "
import json
d = json.load(open('../feature-factory/data/castellana/features.json'))
for f in d['features']:
    if f['statut'] not in ('Livre', 'Rejete'):
        print(f['id'], f['statut'], f['votes'], f['titre'])
"
```

Pour marquer une feature complétée, en ajouter une nouvelle, ou assembler une
release note, passer par l'API de bilbao (`npm start` dans
`feature-factory/`, 127.0.0.1:4600) — jamais éditer `features.json` /
`releases.json` à la main (artefacts possédés par bilbao, régénérés à chaque
mutation, toute édition manuelle serait écrasée).

## Pourquoi

JP est un investisseur autodirigé (Québec, comptes REER/non-enregistré/
corporatif) pratiquant le swing trading à haute fréquence (250-570
transactions/mois observées, principalement tech/IA : MSFT, META, GOOG,
AMZN, AMD, ADBE, PYPL, RDDT, JD, SMCI, ASML, CRWV). Problèmes observés :
timing de screening peu fiable, pas de mécanisme systématique de
sizing/stop-loss, aucun suivi de la valeur ajoutée réelle des indicateurs
utilisés, saisie manuelle des données de marché.

**Contrainte de compte non négociable** : le REER ne permet aucune déduction
de perte en capital (contrairement au non-enregistré) — l'outil doit
toujours savoir dans quel compte un trade est logé, pour toute logique de
sizing, de journal ou de statistiques.

**Distinct du projet « La Roue »** (simulateur Wheel options, = **barcelona**
`learning-finance/`) — contextes et code base à garder séparés, aucune
dépendance entre les deux.

## Objectif — trois briques

1. **Écran de sélection de titres** — décide quels titres suivre activement.
2. **Fiche de trade** — calcule sizing, stop, cible à chaque entrée.
3. **Automatisation & suivi** — données de marché en direct, journal de
   trades, statistiques post-trade (l'indicateur X a-t-il réellement aidé ?).

## Document de référence

[`design_assistant_swing_trading.md`](design_assistant_swing_trading.md)
contient le détail complet déjà validé avec JP : formules de sizing, code
Pine Script de l'alerte TradingView, bandes de couleur par indicateur,
schéma de données du journal. Ce `CLAUDE.md` n'en est qu'un résumé
d'orientation — se référer au document de design pour les valeurs exactes,
ne pas les redupliquer/dériver ici de mémoire.

## Application — [`index.html`](index.html) (écrans fusionnés, à onglets)

Décision prise (22/7/2026, JP) : **pas deux écrans séparés à naviguer
manuellement — un seul parcours à onglets.** `index.html` (racine du
dossier) est désormais l'app réelle. Charge `config.js` (voir section
Nouvelles exigences → Configurabilité) avant sa propre logique, et consomme
la copie vendorée de `design-system/tokens.css`/`components.css` via les
composants `.ds-card`/`.ds-badge`/`.ds-metric`/`.ds-input`/`.ds-select`.

**5 onglets depuis le 5/9/2026** (voir sections dédiées plus bas pour le
détail complet) : **Secteurs** (`#tab-secteurs`, ex-« Écran de sélection »,
recentré sur les secteurs) → **Screener** (`#tab-screener`) → **Fiche de
trade** → **Journal & stats** → **Labo** (`#tab-labo`, nouvel onglet —
stratégies d'options, indépendant du parcours actions ci-dessus). Les cartes Ticker / Force
relative vs indice / Golden Cross existent en DEUX exemplaires
**indépendants** (un par onglet Secteurs et Screener, IDs préfixés
`sec-`/`scr-`, logique partagée via `calcSelectionFor(instanceKey)`/
`fetchLiveSelectionFor(instanceKey)` plutôt que dupliquée) — un pointeur
`lastTickerInstance` retient laquelle des deux a été utilisée en dernier,
c'est elle qui alimente la Fiche de trade au changement d'onglet.

**Hors onglets, visibles en permanence dans le header** (22-23/7/2026) :
- **Témoin de statut backend** (3 pastilles : Backend Express / tradingview-mcp
  / calculs maison) — `GET /api/status`, auto-actualisé toutes les 30s +
  bouton manuel. Voir section « Calculs maison » plus bas pour le détail.
- **Menu Réglages** (bouton ⚙, overlay plein écran — remplace depuis le
  29/8/2026 l'ancien `<details>` d'aide replié dans le flux de la page,
  demande de JP de reprendre le principe du menu Réglages de essen/
  nemesis-retaliation, voir `SettingsPage.tsx` de ce jeu). Commandes de
  relance backend/sidecar et dépannage, contenu recopié de la section
  « Lancer l'application » ci-dessous (à garder synchronisé si cette section
  change).

**Import multi-titres de l'écran de sélection** (tableau, score composite,
top 20 — design doc section 5) : **fait** (22/7/2026, voir section
« Screening 20 titres » plus bas) ; l'onglet single-ticker reste
disponible en dessous du tableau pour l'analyse détaillée d'un titre.

Les deux prototypes HTML d'origine sont conservés tels quels, à titre de
référence historique, dans [`prototypes/`](prototypes/)
(`fiche_trade_sizing_stop.html`, `ecran_selection_titres.html`) — **ne plus
les éditer**, `index.html` est la seule source de vérité du comportement de
l'app désormais.

## Logique métier à préserver (déjà validée avec JP)

Résumé — détail complet et non-négociable dans le document de design :

- **Filtre de tendance** : SMA 9/21/100 (paramétrable, ne pas remplacer par
  EMA 50/100/200 — révisé 29/8/2026, était une SMMA/RMA lissée), signal au
  premier alignement haussier uniquement, sortie sous SMA21. Alerte
  TradingView Pine Script v5 déjà fournie (mise à jour en conséquence — à
  reproduire à la main dans l'alerte réelle sur TradingView).
- **Checklist pré-trade** (gate obligatoire, 6 items) avant tout engagement.
- **Indicateurs retenus** : VIX, RSI(14), OBV, force relative vs indice,
  Golden Cross — bandes vert/amber/rouge décidées avec JP. **Ne pas ajouter
  MACD ni Stochastic RSI** (redondance déjà écartée avec JP, RSI seul comme
  momentum).
- **Sizing** : distance du stop = ATR(14) × multiplicateur ; risque de base
  (défaut 1%) réduit par des discounts multiplicatifs cumulatifs
  (corrélation, VIX, RSI>70, OBV distribution) ; alerte si charge de
  portefeuille agrégée > 6%.
- **Type d'ordre** selon liquidité du titre (3 paliers).
- **Objectifs** : R-multiples et extensions Fibonacci affichés côte à côte.

## Nouvelles exigences (cadrage 22/7/2026)

- **Serveur MCP TradingView — décidé (22/7/2026)** : adoption de
  [`tradingview-mcp`](https://github.com/atilaahmettaner/tradingview-mcp)
  (projet tiers open source, MIT, non affilié à TradingView) pour
  VIX/RSI/ATR/Volume/Golden Cross. **Ne couvre pas tout** — OBV réel et
  SMA 9/21/100 restent à calculer maison. Détail complet (mapping des
  indicateurs, limites, intégration au backend) dans la section
  « Intégration données de marché — tradingview-mcp » ci-dessous.
- **Intuitivité + pédagogie** : chaque indicateur affiché doit pouvoir
  expliquer ce qu'il signifie et pourquoi il est dans telle bande de couleur
  (pas juste la valeur brute). **Décision prise (voir État 22/7/2026)** :
  glossaire JS statique (`js/glossaire-indicateurs.js`), pas d'appel modèle
  à la volée — texte pré-rédigé par indicateur et par bande, calqué sur les
  bandes déjà définies dans le design doc section 4.4.
- **Configurabilité** : toute période d'indicateur (SMA 9/21/100, ATR(14),
  RSI(14), EMA si JP veut en substituer) doit être un paramètre exposé à
  l'utilisateur, jamais une constante en dur dans le code — même principe
  que `config.js` de madrid (`investment-dashboard/`). **Fait (22/7/2026)** :
  [`config.js`](config.js) à la racine, chargé avant la logique de
  `index.html`. Couvre les périodes affichées (SMA/ATR/RSI), les bandes de
  couleur (VIX/RSI/force relative/Golden Cross), les discounts de sizing, les
  seuils de charge de portefeuille et les valeurs par défaut (capital,
  ticker) — plus aucun de ces nombres n'est en dur dans le HTML/JS de l'app.
- **Journal + statistiques** : voir schéma de données section 7 du document
  de design (trade_id, dates, compte, ticker, prix, taille, stop, valeurs
  d'indicateurs à l'entrée, checklist complétée, R réalisé, résultat).
  Objectif analytique : mesurer après coup la valeur prédictive réelle de
  chaque indicateur pour les trades de JP.

## Intégration données de marché — tradingview-mcp (branché 22/7/2026)

Décision de JP après évaluation du repo (README + code source lu, pas
seulement la description marketing) : adopter
[`atilaahmettaner/tradingview-mcp`](https://github.com/atilaahmettaner/tradingview-mcp)
pour la partie qu'il couvre bien, compléter le reste à la main. **Branché et
testé en direct** le jour même (données réelles, pas de mock).

**Légitimité (vérifiée avant adoption)** : ne se connecte à aucun compte
TradingView, n'automatise aucune session/navigateur. S'appuie sur les
endpoints publics **non officiels** de TradingView via les librairies
communautaires `tradingview_ta`/`tradingview-screener` — zone grise côté
CGU (l'auteur le dit lui-même : *"you are responsible for ensuring your own
use complies with the terms of any data source you point it at"*), mais
sans risque de compte JP dans la boucle. Plus sûr qu'un scraper de session,
pas un statut « officiel » pour autant — à garder en tête si la posture
légale devient sensible plus tard.

**Version installée (0.7.1, PyPI) ≠ README GitHub** : le paquet publié sur
PyPI est en retard sur la branche `main` du repo — beaucoup d'outils
documentés dans le README (`get_technical_analysis`, `screen_stocks`,
options, futures, EGX…) **n'existent pas** dans la version installée. Le
vrai outil qui retourne RSI/ATR/SMA/EMA/OBV pour castellana s'appelle
**`coin_analysis`** (pas `get_technical_analysis`), et wrappe la même
fonction `extract_extended_indicators()` déjà analysée avant l'adoption.

**Ce qu'il couvre réellement pour castellana** (vérifié par appel MCP réel
sur AMD/NASDAQ le 22/7/2026, pas seulement en lisant le code) :

| Indicateur castellana | Outil `tradingview-mcp` | Statut |
|---|---|---|
| VIX | `market_snapshot` (`indices[].symbol == "^VIX"`) | ✅ réel — confirmé 16.64 le 22/7/2026 |
| RSI(14) | `coin_analysis` (`rsi.value`) | ✅ réel — confirmé 56.09 |
| Golden Cross (SMA50/SMA200) | `coin_analysis` (`sma.signals` contient `"Golden Cross (SMA50 > SMA200)"`) | ✅ réel, correspond exactement à la définition du design doc |
| **ATR(14)** | `coin_analysis` (`atr.value`) | ⚠️ **revenu `null` en test réel sur AMD** — la librairie sous-jacente `tradingview_ta` ne demande pas ce champ par défaut pour ce couple titre/timeframe. Pas fiable tel quel, malgré le champ qui existe dans le code. **Reclassé en calcul maison.** |
| **Volume vs moyenne 20j** | `coin_analysis` (`volume_analysis.ratio`) | ⚠️ **revenu `null` en test réel** (même cause — `volume.SMA20` absent du dict brut renvoyé par `tradingview_ta` pour ce cas). Le volume courant brut est disponible (`price_data.volume`), pas la moyenne 20j. **Reclassé en calcul maison.** |
| **OBV** | `coin_analysis` (`obv`) | ❌ **faux** — heuristique « clôture > ouverture de la bougie du jour », pas le vrai OBV cumulatif. **Calcul maison.** |
| SMA 9/21/100 | — | ❌ pas exposé à ces périodes précises (seulement SMA/EMA 10/20/30/50/100/200). **Calcul maison.** |
| Force relative vs indice | — | ❌ pas un champ direct, mais dérivable de 2 appels `yahoo_price` (titre + indice de référence). |

**Bilan révisé après test réel** : seuls **VIX, RSI et Golden Cross** sont
vraiment couverts de façon fiable par `tradingview-mcp`. ATR et Volume vs
moyenne 20j, qu'on pensait acquis, se sont révélés absents en pratique — la
liste des calculs maison est donc plus longue que prévu au moment de la
décision d'adoption (voir ci-dessous).

**Implémentation livrée** :
- Sidecar Python installé dans un venv dédié **non commité**
  (`.venv-mcp/`, gitignoré) : `pip install tradingview-mcp-server` (0.7.1,
  Python 3.13). Lancé via `npm run sidecar` → `streamable-http` sur
  `127.0.0.1:4701` (port choisi dans `settings.json`, clé
  `tradingviewMcp`).
- `server/tradingview.js` — client MCP (`@modelcontextprotocol/sdk`),
  connexion **paresseuse** (pas au boot d'Express, pour ne pas planter tout
  le serveur si le sidecar n'est pas encore démarré), fonctions
  `getMarketSnapshot()`, `getTechnicalAnalysis(ticker)`, `getPrice(symbol)`.
- `GET /api/market-data/:ticker` dans `server/index.js` — combine VIX +
  RSI/ATR/Golden Cross/volume pour un titre, `503` propre si le sidecar est
  injoignable (même patron que le `GITHUB_TOKEN` absent chez bilbao —
  jamais planter le serveur pour une dépendance externe indisponible).
  Testé de bout en bout : `curl http://127.0.0.1:4700/api/market-data/AMD`
  → `{"ticker":"AMD","vix":16.64,"rsi":56.09,"atr":null,"volumeRatio":null,
  "goldenCross":true,"sma50":505.39,"sma200":302.21}`.

**Calculs maison** : ~~ATR(14) réel~~, ~~volume vs moyenne 20j~~, ~~OBV
réel~~, ~~SMMA 9/21/100~~ — **tous livrés** (23/7/2026), voir section
« Calculs maison — OBV réel, SMMA 9/21/100, ATR réel, volume vs moyenne
20j » plus bas. Plus aucun indicateur du design doc encore manquant.

## Rate-limit non documenté de `coin_analysis` (confirmé 22/7/2026)

**Constat central, qui façonne tout le design ci-dessous** : une rafale de
~5-6 appels rapprochés à l'outil `coin_analysis` de `tradingview-mcp`
(RSI/SMA/Golden Cross) suffit à déclencher un rate-limit **non documenté**
côté API non officielle de TradingView (réponse vide, `JSON.parse` échoue
côté `tradingview_ta`). **Persistant plus de 5 minutes** en test réel, et
**re-déclenché** par un deuxième screening complet lancé juste après le
premier. Aucune indication de durée ni de mécanisme de retry côté
TradingView — c'est une limite externe, hors de notre contrôle.

**`yahoo_price`/`market_snapshot` ne sont PAS affectés** — vérifié en test
réel qu'ils continuent de répondre normalement pendant que `coin_analysis`
est bloqué. Ce sont deux sources de données distinctes (Yahoo Finance vs
scanner TradingView) à l'intérieur du même serveur MCP. **Conséquence de
design directe** : partout où c'est possible, la donnée qui peut venir de
Yahoo (VIX, cotations, % de variation → force relative) est sourcée
séparément de la donnée qui ne peut venir que du scanner TradingView
(RSI, Golden Cross), avec des `Promise.allSettled` (jamais `Promise.all`)
pour qu'un échec de l'un n'emporte pas l'autre. Voir `server/tradingview.js`.

**À surveiller à l'usage** : si ce rate-limit se déclenche souvent en usage
réel (JP relance le screening plusieurs fois de suite), il faudra soit
espacer davantage (`delayMs` dans `screenWatchlist`), soit mettre en cache
les résultats du screening (ex. 15-30 min) plutôt que tout re-fetcher à
chaque clic — non fait pour l'instant, cache absent.

## Frontend câblé sur les données temps réel (22/7/2026)

Trois ajouts dans `index.html`, tous testés en direct (données réelles, pas
mockées) :

1. **Onglet Fiche de trade** — bouton « Récupérer VIX + RSI en direct »
   (carte Climat de marché) : appelle `GET /api/market-data/:ticker` (le
   ticker de la carte « Le titre »), remplit `#vix`/`#rsi`, relance
   `calcFiche()`. Message de statut inline (« Récupéré avec succès » /
   « Récupéré partiellement — RSI indisponible (tradingview-mcp) » / erreur).
2. **Onglet Écran de sélection, section Ticker** — bouton « Récupérer en
   direct » : 3 appels en parallèle (`Promise.allSettled`) —
   `GET /api/quote/:ticker` (force relative titre), `GET /api/quote/SPY`
   (indice de référence, benchmark fixe), `GET /api/market-data/:ticker`
   (Golden Cross via SMA50/SMA200) — remplit `perfTitre`/`perfIndice`/
   `mm50`/`mm200`, relance `calcSelection()`. Dégradation par champ, pas
   binaire : si Golden Cross échoue (rate-limit), la force relative se
   remplit quand même (source Yahoo indépendante).
3. **Onglet Écran de sélection, nouvelle carte « Screening — univers de
   titres (20) »** — bouton « Lancer le screening » → `GET /api/screening`,
   tableau `.ds-table` trié par score décroissant (Ticker/RSI/Force
   relative/Golden Cross/Score/Verdict), badges colorés, ~30-60s (appels
   séquentiels espacés côté backend). **Cliquer une ligne** copie le ticker
   dans la section Ticker et relance `fetchLiveSelection()` automatiquement
   — enchaîne screening → sélection → (bascule d'onglet) → fiche de trade
   sans ressaisir le ticker.

## Performance des secteurs — `server/sectors.js` + `GET /api/sectors` (29/8/2026)

Nouvelle carte au-dessus du screening dans l'écran de sélection (demande de
JP, inspirée d'un tableau de performance sectorielle vu ailleurs) : les 11
ETF SPDR Select Sector (State Street) — même famille que SPY, déjà utilisé
partout ailleurs dans ce projet comme indice de référence
(`server/tradingview.js`) — plus SPY lui-même en ligne de repère tout en bas.

**Une seule requête `yahooFinance.quote()` par ETF** (pas `quoteSummary`)
donne à la fois la performance du jour (`regularMarketChangePercent`) et le
P/E trailing (`trailingPE`) — 12 appels séquentiels espacés de 150ms par
politesse (même discipline que `fundamentals.js`/`indicators.js`), ~2.5s au
total en test réel, aucun rate-limit observé (c'est `quote()`, pas
`coin_analysis` — sans lien avec le rate-limit documenté plus bas).

**Différence importante avec le "P/E industrie" du screening** : ici le P/E
est celui de l'ETF sectoriel lui-même — un vrai agrégat de marché calculé
par le fournisseur de l'ETF sur ses constituants réels, **pas** une
approximation par pairs de watchlist comme le "P/E industrie" du tableau de
screening (section précédente). Documenté explicitement en tooltip sur
l'en-tête de colonne pour éviter toute confusion entre les deux.

Chargement **automatique** au démarrage de la page (`loadSectors()`, comme
`checkStatus()`) — contrairement au screening, volontairement pas derrière
un bouton "Lancer" : rapide, pas de rate-limit à ménager. Bouton
« Actualiser » disponible pour forcer un rafraîchissement. Tri par
performance décroissante côté client, couleur verte/rouge selon le signe.
**Vérifié en direct dans le navigateur** : 11 secteurs + SPY, données
réelles, tri correct, ligne SPY mise en évidence (gras, bordure) en bas de
tableau.

### Line graph de performance sectorielle (29/8/2026)

Demande de JP après avoir vu la carte ci-dessus : un graphique en ligne de
la performance de **tous** les secteurs, période sélectionnable (1 semaine,
1/2/3/6/12 mois — défaut **12 mois**), placé au-dessus du tableau. Skill
`dataviz` du portfolio consultée avant d'écrire le code (forme, couleur,
marks, interaction — voir `references/*.md` du skill).

**Backend** : `getSectorHistory()` (`server/sectors.js`) — un seul
`yahooFinance.chart()` par ETF (~385 jours calendaires, marge au-delà de 12
mois pour le calendrier boursier), route `GET /api/sectors/history`.
**Un seul fetch pour toutes les périodes** : le frontend reçoit tout
l'historique une fois (`loadSectorHistory()`, appelé au chargement de la
page) et découpe/normalise en % côté client (`sliceAndNormalize()`) à
chaque changement de période — aucun refetch au clic sur un bouton de
période. Pas de cache serveur (comme `/api/sectors` — rapide, ~1,2s pour 12
titres en test réel, aucun rate-limit observé sur `chart()`).

**Rendu** : SVG écrit à la main (pas de librairie de charting — cohérent
avec le reste du portfolio, zéro dépendance frontend ajoutée), 2px lignes
arrondies, grille hairline recessive, axe Y en %, 3 repères de date sur
l'axe X. **Étiquettes directes en bout de ligne** (ticker à droite de
chaque courbe) — c'est le mécanisme d'identité principal, pas la seule
couleur (règle du skill dataviz : « never color alone »), important ici
car **11 secteurs + 1 benchmark dépassent la palette catégorielle validée
CVD du skill (8 teintes max)** — voir note dédiée ci-dessous.
Survol : ligne de mire verticale (crosshair) qui suit le pointeur, infobulle
listant tous les secteurs visibles à cette date triés par performance.
Légende cliquable sous le graphique : cliquer un secteur le masque/l'isole
(`toggleSectorSeries()`), utile vu le nombre de courbes.

**Le S&P 500 (SPY) est traité comme un repère, pas un secteur de plus** :
encre neutre (`var(--text-2)`, pas une teinte catégorielle) + trait
pointillé plus épais — cohérent avec son rôle de benchmark dans tout le
reste de l'app (déjà `SPY` = référence dans le screening et la Fiche de
trade).

**Écart documenté au skill dataviz — 11 couleurs catégorielles, pas 8** :
la palette de référence du skill (`references/palette.md`) ne valide
CVD-safe que 8 teintes. Avec 11 secteurs à distinguer simultanément (le
graphique montre « tous les secteurs », demande explicite de JP — pas
d'option pour replier certains en « Autre »), les 8 premières couleurs
(`--sc-1` à `--sc-8`) reprennent exactement la palette validée du skill ;
les 3 suivantes (`--sc-9` à `--sc-11`, pour XLE/XLC/XLB) sont ajoutées sans
être passées par le validateur CVD. Mitigation appliquée (recommandée par
le skill pour ce cas précis — « fold to Other, small multiples, ou
composite encoding » n'était pas compatible avec la demande) : identité
jamais portée par la seule teinte — légende toujours visible, étiquette de
ticker en bout de ligne sur CHAQUE courbe, infobulle listant nom complet +
valeur au survol. Variables CSS `--sc-1`..`--sc-11` déclarées en dual
clair/sombre dans `index.html` (pas dans `design-system/tokens.css` — ce
sont des teintes de graphique propres à ce composant, pas des jetons
sémantiques partagés).

**Vérifié en direct dans le navigateur** (fonctionnellement, via
inspection DOM/JS — le rendu visuel par capture d'écran n'a pas pu être
confirmé cette session, la tuile du navigateur restant vide sur les
captures malgré un DOM et des logs corrects) : historique réel chargé (265
barres/titre sur 12 mois), changement de période (365→30 jours) qui met à
jour le bouton actif et redessine sans refetch, `toggleSectorSeries('XLK')`
qui retire effectivement la courbe et l'étiquette XLK du SVG puis les
restaure.

## Screening 20 titres — `server/watchlist.js` + `GET /api/screening`

Implémente la section 5 du design doc (tableau multi-titres, score
composite, verdict par ligne), avec deux écarts délibérés documentés
ci-dessous plutôt que cachés.

**Univers de titres (`server/watchlist.js`)** : 12 titres réellement suivis
par JP (design doc section 1 : MSFT, META, GOOG, AMZN, AMD, ADBE, PYPL,
RDDT, JD, SMCI, ASML, CRWV) + 8 grands noms tech/IA liquides ajoutés par
Claude pour atteindre 20 (AAPL, NVDA, TSLA, AVGO, CRM, ORCL, PLTR, NFLX) —
**pas** un scan générique « top gainers » (testé et rejeté : ramène des
micro-caps spéculatives à +3000%/jour, hors sujet pour une stratégie
tech/IA liquide). Liste éditable directement dans le fichier, à ajuster
librement.

**Score composite — écart au design doc** : la section 5 prévoit 4
colonnes (RSI, Force relative, Golden Cross, **OBV**). L'OBV n'étant pas
disponible de façon fiable via `tradingview-mcp` au moment de l'adoption, le
score était initialement calculé sur 3 colonnes — **revenu à 4 colonnes**
(RSI, Force relative, Golden Cross, OBV) depuis l'ajout du calcul maison
d'OBV réel ci-dessous (22/7/2026). `server/index.js`, `scoreRow()` : vert =
+1, rouge = -1, amber = 0 par colonne, `verdict` = `ajouter` (score ≥ 2) /
`surveiller` (score ≥ 0) / `ne pas ajouter` (score < 0) / `erreur` (aucune
donnée récupérée du tout — distinct d'un score simplement bas). Seuils
dupliqués de `config.js` (`CFG.bandes`) dans `SCORE_BANDS`, faute de format
de module commun entre le frontend classique et ce backend ESM — à
reporter à la main si les bandes de `config.js` changent.

**`screenWatchlist()`** (`server/tradingview.js`) : boucle séquentielle
avec délai (`delayMs = 1500` par défaut), jamais `Promise.all`. `changePercent`
vient de `yahoo_price` par titre (résilient), `rsi`/`goldenCross` de
`coin_analysis` par titre (sujet au rate-limit ci-dessus) — un titre peut
donc ressortir avec force relative seule si le scanner est bloqué. `SPY`
(benchmark) fetché une seule fois en tête de fonction. La route
`GET /api/screening` (`server/index.js`) compose ce résultat avec une
seconde passe indépendante — `getHomemadeIndicatorsBatch()`
(`server/indicators.js`) — pour l'OBV réel, fusionnée par ticker avant le
scoring.

### Screening — P/E ratio et industrie (29/8/2026)

Demande de JP : afficher le P/E ratio, la famille d'industrie et le P/E de
cette famille dans le tableau de screening. Source : `server/fundamentals.js`
(déjà utilisé pour Float/PEG/Beta/VWAP), module Yahoo Finance
`summaryProfile` ajouté à l'appel `quoteSummary` existant — `peRatio` vient
de `summaryDetail.trailingPE`, `industry` de `summaryProfile.industry`
(classification GICS sub-industry de Yahoo, ex. « Semiconductors »,
« Software - Infrastructure »).

**P/E de l'industrie — approximation assumée, pas un vrai agrégat
sectoriel** : aucune source gratuite fiable identifiée pour un P/E moyen
d'industrie à l'échelle du marché. Calculé à la place dans `server/index.js`
(route `/api/screening`) comme la **moyenne des P/E des titres de LA
WATCHLIST** (20 titres) qui partagent la même industrie — donc un chiffre
utile pour comparer un titre à ses quelques pairs déjà suivis, pas un
benchmark de marché externe. Sur 20 titres, une industrie n'a parfois qu'1
seul titre (« P/E industrie » = son propre P/E) : `industryPeerCount` est
exposé par l'API et affiché en tooltip sur la cellule pour ne jamais laisser
croire à un agrégat plus large qu'il ne l'est réellement — même principe que
partout ailleurs dans le portfolio (jamais un chiffre silencieux qui ment
sur sa propre fiabilité, voir le piège documenté dans le `CLAUDE.md` racine).
**Vérifié en direct** : Semiconductors (AVGO/NVDA/AMD) → P/E industrie
70.8 (moyenne des 3), `industryPeerCount: 3` ; AAPL seul dans « Consumer
Electronics » → P/E industrie = son propre P/E (36.1), `industryPeerCount: 1`.
Colonnes ajoutées au tableau HTML (`index.html`) et à l'export CSV
(`/api/screening.csv`). Aucun filtre/score ajouté sur ces champs — JP n'a
demandé que l'affichage.

## Calculs maison — OBV réel, SMA 9/21/100, ATR réel, volume vs moyenne 20j

Résout le point ouvert depuis l'adoption de `tradingview-mcp` (celui-ci ne
fournit ni un vrai OBV cumulatif, ni cette moyenne mobile — voir section
précédente). *(Terminologie et calcul de la moyenne mobile révisés le
29/8/2026 : c'était une SMMA/RMA lissée, standardisée sur une vraie SMA —
voir « État » en bas de fichier pour le détail de la demande de JP.)*

**Source de données OHLC brute — tranchée** : `yahoo-finance2` (npm),
historique quotidien direct (`chart()`, ~300 jours calendaires ≈ 200+
barres). Non officiel mais légitime (même famille que `yahoo_price`/
`market_snapshot` de tradingview-mcp) — **zéro dépendance à
`coin_analysis`**, donc pas affecté par son rate-limit ; testé pendant que
celui-ci était bloqué, a continué de répondre normalement. Alpha Vantage
(`TIME_SERIES_DAILY`, déjà connecté côté JP) écarté pour cet usage : quota
25 req/jour bien trop bas pour un screening de 20 titres.

**`server/indicators.js`** — module autonome, ne dépend pas du sidecar
Python :
- `computeSMA(closes, period)` — SMA standard, fenêtre glissante (design doc
  section 4.1, révisé 29/8/2026) : `SMA[i] = moyenne des period dernières
  clôtures`. Remplace l'ancienne `computeSMMA` (RMA lissée) pour le filtre
  de tendance.
- `computeOBV(bars)` — cumul classique (design doc section 4.4) : +volume
  si clôture > veille, -volume si <, inchangé si =.
- `classifyOBV()` — **approximation** de « confirme »/« diverge »/« neutre »
  (pas une détection formelle de divergence sur pics/creux) : compare la
  variation de l'OBV et celle du prix sur les 10 dernières barres — même
  signe → `accumulation`, signes opposés → `distribution`. Documenté comme
  approximation, à affiner si l'usage réel montre des faux signaux.
- `computeTrueRange(bars)` + `computeATR(bars, period=14)` — True Range
  standard puis lissage Wilder, qui **est** une RMA appliquée au TR
  (fonction `computeRMA` dédiée, gardée séparée de `computeSMA` depuis la
  révision du 29/8/2026 — l'ATR reste correctement en RMA par définition,
  ce n'est pas concerné par le passage du filtre de tendance à la SMA).
  Période dupliquée en dur (`ATR_PERIOD`), à reporter à la main si
  `CFG.indicateurs.atrPeriode` change dans `config.js`.
- `computeVolumeVs20d(bars)` — volume du jour ÷ moyenne des 20 jours
  **précédents** (jour courant exclu de sa propre moyenne, sinon un jour à
  fort volume gonflerait sa référence).
- `getHomemadeIndicators(symbol)` — un seul appel Yahoo Finance, tout
  (SMA/OBV/ATR/volume) calculé dessus ; lève si historique < 100 barres
  (SMA100 impossible) ou Yahoo injoignable.
- `getHomemadeIndicatorsBatch(tickers)` — séquentiel, délai léger
  (400ms/titre — Yahoo Finance direct n'a pas montré le rate-limit du
  scanner TradingView, mais reste poli plutôt que d'enchaîner à pleine
  vitesse), tolérant aux échecs par titre.
- `checkYahooConnection()` — cotation SPY minimale, pour le témoin de
  statut du frontend (voir section dédiée plus bas).

**Branché sur** :
- `GET /api/market-data/:ticker` — 3ᵉ branche `Promise.allSettled`
  (`sma9`/`sma21`/`sma100`/`smaAlignment`/`obv`/`obvTrend`/`atr`/
  `volumeRatio`/`volumeSMA20`), indépendante de `coin_analysis` et
  `market_snapshot`. `atr`/`volumeRatio` de la réponse préfèrent
  maintenant le calcul maison (`hm?.atr ?? ta?.atr?.value ?? null`) — celui
  de `tradingview-mcp` reste en repli, gardé au cas où l'outil tiers
  l'exposerait un jour pour un titre/timeframe donné.
- `GET /api/screening` — OBV réintégré comme 4ᵉ colonne du score (voir
  section précédente). ATR/volume n'y figurent pas : ce ne sont pas des
  colonnes du score composite (section 5 du design doc), seulement des
  champs de la fiche de trade individuelle.
- Frontend Fiche de trade — bouton « Récupérer VIX + RSI + ATR + OBV en
  direct » remplit maintenant aussi le champ ATR (`toFixed(2)`) et le
  sélecteur OBV (`accumulation`/`distribution`/`neutre`) ; affiche
  l'alignement SMA **et** le ratio de volume vs moyenne 20j en texte
  (« haussier ✓ · Volume vs moyenne 20j : 44% (en-dessous) ») à côté de la
  checklist — **sans cocher aucune case automatiquement**, l'engagement de
  la checklist reste un geste manuel de JP.
- Frontend Écran de sélection — colonne OBV ajoutée au tableau de
  screening (badges Accumulation/Distribution/Neutre).

**Vérifié en direct le 22/7/2026** (AMD, données réelles — *valeurs figées
au moment du test, obtenues avec l'ancien calcul RMA/SMMA, avant la révision
SMA du 29/8/2026 ; ne pas les relire comme les valeurs SMA actuelles*) :
`smma9=528.16 > smma21=501.20 > smma100=345.31`, prix 552.33 au-dessus →
`smmaAlignment: "haussier"`, cohérent avec le Golden Cross déjà confirmé
par `tradingview-mcp`
(SMA50=505 > SMA200=302). `obv` réel (valeur cumulative ~1.26 milliard,
grandeur brute peu lisible en soi — c'est `obvTrend` qui compte pour
l'app) → `accumulation`. `atr=36.44$` (≈6.6% du prix, plausible pour un
titre volatil), `volumeRatio=0.42` (volume du jour à 42% de sa moyenne
20j) — les deux remplis dans la Fiche de trade via le bouton. Screening
complet re-testé avec le score à 4
colonnes : résultats cohérents, verdicts `ajouter`/`surveiller`/`ne pas
ajouter` bien répartis sur les 20 titres.

## Intégration données de marché — Alpha Vantage (état des tests)

- Connecteur MCP installé et connecté côté JP.
- **GLOBAL_QUOTE fonctionne** (confirmé sur AMD : prix, volume, variation).
- **RSI a échoué** (`No approval received.`) — cause non confirmée, à
  investiguer (flux d'approbation manquant pour les indicateurs calculés vs
  les cotations brutes).
- **Palier gratuit** : 25 requêtes/jour, 5/minute, données décalées de 15
  min — un rafraîchissement complet du tableau de 20 titres dépasse
  largement ce quota en une passe. Architecture à prévoir : rotation d'un
  sous-ensemble prioritaire par jour, et/ou palier payant (49,99$/mois, 75
  req/min, sans plafond quotidien) si l'usage réel le justifie. Prévoir une
  couche de cache/persistance dans tous les cas.
- **Statut depuis l'adoption de tradingview-mcp (22/7/2026)** : `tradingview-mcp`
  devient la voie principale pour VIX/RSI/ATR/Volume/Golden Cross (RSI y
  fonctionne, contrairement au blocage Alpha Vantage ci-dessus). Alpha
  Vantage reste un candidat pour `TIME_SERIES_DAILY` (historique OHLC brut
  nécessaire au calcul maison de l'OBV réel et de la SMMA 9/21/100 — voir
  section précédente), à confirmer une fois cette brique construite.

## Hors scope pour cette phase

- **Exécution automatique de trades** — jamais d'ordre envoyé au courtier
  par l'outil.
- **Conseil en investissement personnalisé** — l'outil est un outil d'aide à
  la décision et de journalisation pour JP, pas un système qui recommande
  des trades de façon prescriptive à un tiers.
- Intégration avec « La Roue » (barcelona, projet séparé).
- Rebalancement de portefeuille long terme (couvert par madrid/
  `investment-dashboard`, hors de ce projet).

## Architecture

**Stack — tranchée (22/7/2026, JP)** : backend, pas frontend statique +
service à part. Raisonnement de JP : le serveur MCP TradingView doit de
toute façon être un backend, donc autant y loger aussi le journal de trades
et les statistiques plutôt que de garder deux couches. Patron retenu : Node
Express + better-sqlite3 (même patron que valencia/bilbao). Le frontend
(`index.html`/`config.js`) reste tel quel — zéro build, servi statiquement
par ce backend (comme `feature-factory/public/` pour bilbao).

**Scaffold livré (22/7/2026)** : `package.json` (ESM, `express` +
`better-sqlite3`), `settings.json` (port 4700, host 127.0.0.1, chemin DB —
voir section Lancer l'application), `server/db.js` (ouvre/crée
`data/castellana.sqlite`, WAL, schéma table `trades` — journal de trades,
section 7 du design doc, CHECK sur les enums `compte`/`obv_a_entree`/
`resultat`, idempotent), `server/index.js` (Express écoute
**127.0.0.1 uniquement** — même garde-fou sécurité que bilbao — sert le
frontend statique en racine, route `GET /api/health`). Vérifié : boot,
`/api/health` retourne `{status:"ok",trades:0}`, `index.html` servi
correctement en `http://127.0.0.1:4700/` (design system, onglets, calculs —
identique au test en `file://`).

**Reste à faire** : décider quelle partie de la logique actuelle du
frontend (sizing, checklist) migre côté serveur vs reste côté client ;
implémenter les calculs maison ATR/Volume/OBV/SMMA (liste allongée après
test réel de `tradingview-mcp`, voir section Intégration données de
marché) ; construire les routes API du journal de trades (CRUD) — la table
existe, aucune route ne l'utilise encore ; faire consommer les données
temps réel (`/api/market-data/:ticker`) par le frontend (`index.html` ne
les appelle pas encore, les champs restent saisis à la main).

Points déjà tranchés (voir section État pour le détail) :
- Design system : copie vendorée en place dans `design-system/` (22/7/2026).
- Explications pédagogiques par indicateur : glossaire JS statique, pas
  d'appel modèle (22/7/2026).
- Configurabilité : `config.js` (22/7/2026).
- Écrans fusionnés en une seule app à onglets, `index.html` (22/7/2026).
- Source de données MCP TradingView : `tradingview-mcp` adopté **et
  branché** — sidecar Python (`npm run sidecar`) + client
  `server/tradingview.js` + route `GET /api/market-data/:ticker`, testé
  avec des données réelles (22/7/2026 — voir section « Intégration données
  de marché — tradingview-mcp »). Fiable pour VIX/RSI/Golden Cross
  seulement ; ATR/Volume rejoignent la liste des calculs maison.
- Scaffold du backend Express + better-sqlite3 (22/7/2026, ci-dessus).

Ce qui reste réellement ouvert : la **source de données OHLC brute** pour
les calculs maison (ATR réel, volume vs moyenne 20j, OBV réel, SMMA
9/21/100 — voir section Intégration données de marché), et le branchement
effectif du journal de trades au backend (le scaffold est prêt à le
recevoir, rien n'est encore
câblé).

## Lancer l'application

```bash
cd trading-assistant
npm install --cache /tmp/npm-cache-castellana   # --cache si EACCES (piège connu, voir CLAUDE.md racine)
npm start
# → http://127.0.0.1:4700/
```

La base SQLite (`data/castellana.sqlite`, gitignorée) est créée
automatiquement au premier démarrage si absente.

### Sidecar tradingview-mcp (optionnel — requis seulement pour `/api/market-data/*`)

```bash
cd trading-assistant
python3 -m venv .venv-mcp        # une seule fois
source .venv-mcp/bin/activate
pip install tradingview-mcp-server
deactivate
npm run sidecar
# → sidecar sur http://127.0.0.1:4701 (Python, streamable-http)
```

Deux process séparés (`npm start` + `npm run sidecar`), deux terminaux.
Le backend Express ne lance pas le sidecar automatiquement — s'il n'est pas
démarré, `/api/market-data/:ticker` répond `503` proprement, tout le reste
de l'app continue de fonctionner normalement.

**Documentation d'installation pour un tiers (30/8/2026)** — JP a ajouté un
collègue comme collaborateur GitHub, qui n'arrivait pas à lancer le projet.
En regardant ce qui existait, deux problèmes réels trouvés (pas juste un
manque de documentation) :
1. `README.md` (à la racine du repo, distinct de ce `CLAUDE.md`) ne
   contenait que des commandes macOS non expliquées, aucune vue d'ensemble
   du projet, aucune mention de `npm install`, du clonage, ni des
   prérequis. Réécrit en présentation générale du projet (pourquoi, les 3
   écrans, l'architecture à 2 serveurs + SQLite, un diagramme Mermaid) —
   renvoie vers un nouveau `SETUP.md` pour l'installation détaillée.
2. **Bug réel, pas seulement documentaire** : le script npm `sidecar`
   codait en dur `./.venv-mcp/bin/tradingview-mcp` — un chemin Unix/macOS.
   Un venv Python créé sur Windows range ses exécutables dans
   `.venv-mcp\Scripts\` avec l'extension `.exe`, donc cette commande ne
   pouvait **jamais** fonctionner sur Windows, quoi que le collègue ait
   fait. Corrigé par `scripts/run-sidecar.mjs` (zéro dépendance ajoutée —
   `node:child_process`/`node:fs` natifs) qui détecte `process.platform` et
   choisit le bon chemin, avec un message d'erreur explicite (pas un crash
   opaque) si le venv n'existe pas encore. `package.json` pointe maintenant
   dessus (`"sidecar": "node scripts/run-sidecar.mjs"`). **Testé en
   direct sur macOS** (le sidecar démarre, répond sur le port 4701) — **pas
   testé sur une vraie machine Windows**, seulement par lecture de code et
   raisonnement sur `process.platform`.

Nouveau `SETUP.md` (racine du repo) : prérequis (Git/Node 20+/Python 3.10+),
étapes numérotées **séparément Windows/macOS** à chaque commande (clonage
d'un repo privé — authentification GitHub requise, plus de mot de passe en
ligne de commande —, `npm install`, création du venv, lancement des deux
serveurs), et une section Dépannage couvrant les échecs les plus probables
pour quelqu'un de nouveau sur le projet : port déjà utilisé (commande par
OS), échec de compilation native de `better-sqlite3` sur Windows (piste
Visual Studio Build Tools), erreur `EACCES` npm, `python` introuvable côté
Windows vs `python3` côté macOS. Ce fichier est pour un tiers qui découvre
le projet — ne pas le confondre avec ce `CLAUDE.md`, qui reste le journal
de bord destiné à JP et aux futures sessions de travail sur ce produit.

## Feuille de route suggérée

1. **Phase 1** — ~~Consolider les deux prototypes HTML en un seul workflow
   cohérent~~ (fait) ; ~~scaffold du backend Express + better-sqlite3~~
   (fait) ; ~~brancher `tradingview-mcp` en sidecar~~ (fait) ; ~~câbler le
   frontend sur les données temps réel~~ (fait) ; ~~calculs maison OBV réel,
   SMMA 9/21/100, ATR réel, volume vs moyenne 20j~~ (fait, 22-23/7/2026 —
   `server/indicators.js`, Yahoo Finance direct). **Phase 1 terminée.**
2. **Phase 2** — ~~Tableau de sélection multi-titres, score composite~~
   (fait, 22/7/2026 — **4 colonnes complètes** RSI/Force relative/Golden
   Cross/OBV depuis l'ajout du calcul maison ; import CSV en bloc de la
   section 5 du design doc pas fait, univers fixé dans
   `server/watchlist.js`). Reste : cache des résultats de screening
   (mitiger le rate-limit `coin_analysis` en cas de relances rapprochées —
   voir section dédiée plus haut).
3. **Phase 3** — Journal de trades automatisé (schéma section 7 du design
   doc) + requêtes analytiques post-trade, explorer le webhook TradingView
   pour rapprocher l'alerte du signal réel.

## Onglet Labo — stratégies d'options (5/9/2026)

Nouvel onglet, hors du parcours Secteurs→Screener→Fiche→Journal : demande de
JP de pouvoir tester différentes stratégies d'options (wheel, iron condor,
poor man covered call…) sur un titre donné, avec la séquence à suivre pour
l'appliquer.

**Écart trouvé avant d'implémenter, signalé et clarifié avec JP** : le
fichier fourni, `strategy/PoorManCoveredCall.md.rtf`, décrit en réalité un
système « La Roue & Debit Spreads » (Cash-Secured Put → Covered Call, puis
Bull Call Spread / Bear Put Spread pour la gestion du risque) — **pas** la
vraie Poor Man's Covered Call (achat d'un LEAPS Call profondément ITM en
remplacement des 100 actions, vente répétée de Calls courts contre). Plutôt
que de deviner, question posée à JP via `AskUserQuestion` : garder les
**deux stratégies, distinctes**, dans le sélecteur — le contenu réel du
fichier sous son propre nom (`roue-debit-spreads`), et une vraie PMCC
écrite selon la définition standard de la stratégie (`pmcc`), indépendante
du fichier. Les deux sont documentées comme telles dans le code
(`js/strategies-labo.js`, champ `sourceNote` de chaque stratégie, affiché
dans l'UI) pour qu'aucune des deux ne soit prise pour l'autre.

**Architecture** :
- `js/strategies-labo.js` (nouveau, chargé en `<script>` comme
  `glossaire-indicateurs.js`) — catalogue `STRATEGIES_LABO` (id, nom,
  statut `disponible`/`a-venir`, résumé, note de source, fonction
  `build(ctx)` qui génère la séquence pas-à-pas à partir du ticker et des
  données réelles chargées). **À l'origine** (5/9/2026), deux stratégies
  `disponible` (`roue-debit-spreads`, `pmcc`) et deux `a-venir` (Iron
  Condor, Credit Spreads) — **séparée en deux le 7/9/2026** (voir section
  « Séparation La Roue / Debit Spreads » plus bas) : `roue-debit-spreads`
  n'existe plus, remplacée par `roue` et `debit-spreads`, donc 3
  stratégies `disponible` désormais. Affichées dans le sélecteur avec le
  suffixe « (bientôt disponible) » pour les `a-venir` et un bandeau
  explicite plutôt que masquées, même discipline que le hub essen
  (« ne jamais pousser un lien avant que le contenu réponde »).
- `GET /api/labo/:ticker` (`server/index.js`) — combine `getFundamentals()`
  (`server/fundamentals.js` : prix, volume, beta, P/E, industrie, secteur)
  et `getHomemadeIndicators()` (`server/indicators.js` : ATR réel, SMA
  9/21/100, alignement, OBV) sur un `Promise.allSettled`. **Choix
  délibéré : aucune dépendance à `tradingview-mcp`/`coin_analysis`** — ces
  deux sources sont du Yahoo Finance direct, donc jamais affectées par le
  rate-limit déjà documenté sur le scanner TradingView (voir section
  dédiée plus haut). 503 explicite si Yahoo est injoignable pour le ticker
  saisi (ticker invalide, etc.), jamais un objet vide qui laisserait croire
  à des données à zéro.
- `config.js` — nouvelle section `CFG.labo` (DTE/Delta cibles pour Put et
  Call, bornes de prise de profit, multiplicateurs d'ATR pour les zones de
  strike, paramètres PMCC — profondeur ITM du LEAPS, seuil de roulement).
  Même principe que le reste du projet : aucune de ces valeurs n'est en dur
  dans le HTML/JS.

**Discipline centrale, à ne jamais relâcher en étendant cet onglet** :
**aucune donnée d'options réelle (chaîne, strike, delta, prime) n'existe
dans cette app** — aucune source de ce type n'y est branchée. Les « zones
de strike » affichées dans la séquence sont une **estimation grossière**
(prix ± 1 à 2×ATR réel du titre), explicitement étiquetée comme telle à
chaque occurrence (« PAS une vraie donnée d'options ») et rappelée dans un
encart dédié en bas de l'onglet — jamais présentée comme un vrai chiffre de
marché. Un futur ajout de stratégie doit préserver ce principe plutôt que
d'inventer des deltas/primes plausibles.

**Vérifié en direct** (serveur redémarré pour charger le code, données
réelles AMD) : `GET /api/labo/AMD` → prix 477.57$, ATR 22.51$, beta 2.48,
secteur Technology ; `GET /api/labo/ZZZZZZINVALID` → 503 explicite (pas de
donnée inventée). Dans le navigateur (Browser pane) : bascule vers l'onglet
Labo, chargement des données réelles AMD, séquence « La Roue & Debit
Spreads » rendue avec zones de strike calculées (432.55$–455.06$ pour le
Put, 500.08$–522.59$ pour le Call), bascule vers « Poor Man's Covered Call
(PMCC) » → séquence différente rendue correctement (LEAPS ~382.06$, Call
court même zone), bascule vers « Iron Condor » → bandeau « bientôt
disponible » affiché, séquence vidée. Aucune erreur console JS. Serveur de
test arrêté après vérification — rien ne tourne en arrière-plan.

### Terminologie clarifiée (5/9/2026, questions de JP après premier essai)

JP a testé l'onglet et posé 4 questions qui ont révélé un vrai problème
d'utilisabilité, pas juste un manque de documentation : les termes
« LEAPS », « Delta cible », et le mot opaque « neutre » pour l'alignement
SMA n'étaient jamais expliqués dans l'app elle-même.

- **T0/T1 (LEAPS)** : LEAPS = *Long-term Equity AnticiPation Securities* —
  PAS un instrument différent d'un Call/Put, juste une option à échéance
  longue (9 mois à 2-3 ans). « LEAPS Call » = « Call à longue échéance ».
  Nouvelle entrée `leaps` dans `js/glossaire-indicateurs.js` (même popover
  `showGlossaire()` que les indicateurs techniques — réutilisé plutôt que
  dupliqué), bouton d'aide (i) posé sur chaque mention de LEAPS dans
  `js/strategies-labo.js`, et le titre de l'étape 2 du PMCC reformulé en
  verbe-sujet actif (« Acheter un Call à longue échéance (LEAPS)... ») pour
  matcher le style « Vendre un Put/Call... » déjà utilisé côté La Roue —
  c'était l'incohérence de formulation que JP pointait en T1.
- **T3 (Delta cible)** : nouvelle entrée `delta` dans le même glossaire —
  explique les deux sens usuels (sensibilité prix-pour-prix ET
  approximation de probabilité ITM), avec les deux cas d'usage réels de
  l'app (Put vendu à delta bas = probabilité OTM élevée ; LEAPS Call acheté
  à delta haut = comportement proche de l'action). Bouton d'aide posé sur
  chaque mention de « Delta cible » dans les deux stratégies.
- **T2 (validation de l'alignement SMA)** : le mot « neutre » à lui seul ne
  permettait pas à JP de vérifier le calcul. Deux ajouts : (1) la carte
  « Données réelles du titre » de l'onglet Labo affiche maintenant SMA9/
  SMA21/SMA100 en plus du prix (avec un texte rappelant la règle exacte —
  haussier si prix>SMA9>SMA21>SMA100 dans cet ordre, baissier l'inverse
  strict, neutre sinon — server/indicators.js) ; (2) la fonction
  `laboSmaDetail()` (`js/strategies-labo.js`) injecte ces mêmes 4 valeurs
  directement dans le texte de l'étape 1 du PMCC, pour que JP puisse
  vérifier l'ordre lui-même sans quitter la séquence. Réutilise la clé
  `sma` déjà existante du glossaire (bouton d'aide posé aussi ici).
- **DTE**, mentionné dans les deux stratégies sans être défini, est
  maintenant explicité en clair au premier usage de chaque stratégie
  (« DTE = jours restants avant l'échéance ») plutôt que laissé comme
  acronyme nu.

**Vérifié en direct** (fichiers statiques, pas de redémarrage serveur
nécessaire) : bouton (i) sur « LEAPS » et « Delta cible » ouvre le bon
popover (texte confirmé par lecture directe du DOM) ; carte de métriques
Labo affiche SMA9 469.28$/SMA21 475.59$/SMA100 466.56$ pour AMD avec
« neutre » correctement coloré en amber (`warn`) — cohérent avec l'ordre
réel (prix 477.57$ > SMA9 mais SMA9 < SMA21, donc pas haussier). Aucune
erreur console JS.

### Statique vs dynamique, Black-Scholes, SMA réellement configurables (5/9/2026, 3e passe — T1/T2/T3)

JP a testé une deuxième fois et posé 3 nouvelles demandes, plus profondes
que la première passe de clarification terminologique.

**T1 — distinguer visuellement le texte statique du texte dynamique.**
Exemple donné par JP : dans « Zone de strike estimée : 75,19 $ US –
78,02 $ US », seule la seconde partie doit se distinguer visuellement.
Nouvelle classe CSS `.labo-dyn` (accent, gras, chiffres tabulaires) et
fonction `laboDyn(texte)` (`js/strategies-labo.js`) qui l'enveloppe —
appliquée à CHAQUE valeur calculée à partir du ticker/des données chargées
dans les deux stratégies (prix, zones de strike, DTE, Delta, SMA, etc.),
jamais au texte de règle qui ne change pas d'un titre à l'autre.

**T2 — « pourquoi choisir 75,19 $ par exemple… » : aller plus loin sur
l'analyse.** Ce retour a révélé un vrai défaut de méthode, pas seulement un
manque d'explication : la version précédente calculait les zones de strike
par un multiple arbitraire de l'ATR (1 à 2×ATR), **sans AUCUN lien
mathématique** avec le Delta cible affiché juste à côté (ex. « Delta cible
0.15-0.25 » à côté d'un nombre qui n'avait jamais été calculé à partir
d'un delta). Corrigé en profondeur plutôt que rustiné :
- **Volatilité historique réelle du titre**, calculée serveur
  (`computeHistoricalVolatility()`, `server/indicators.js` — écart-type des
  rendements logarithmiques quotidiens sur 60 jours de bourse, annualisé
  ×√252), exposée par `GET /api/labo/:ticker` (champ `historicalVolatility`).
  **Avertissement central, documenté à 3 endroits** (code, config.js, UI) :
  c'est une volatilité **historique** (réalisée sur les prix passés), un
  PROXY de la volatilité **implicite** que le marché utilise réellement
  pour pricer les options (qui intègre les attentes futures — résultats
  trimestriels, etc. — que l'historique ne voit pas) — jamais présentée
  comme équivalente.
- **Black-Scholes minimal implémenté en JS pur** (`js/strategies-labo.js` :
  `laboNormCdf`/`laboNormInv` — approximation d'Abramowitz-Stegun pour erf,
  algorithme rationnel de Peter Acklam pour l'inverse — puis
  `laboStrikeForDelta()`, résout K tel que le delta Black-Scholes du strike
  ≈ le Delta cible réel de la stratégie). Remplace l'heuristique ATR : le
  strike affiché correspond maintenant VRAIMENT au delta annoncé, sous
  l'hypothèse de volatilité ci-dessus.
- **Panneau « Comment ces prix sont calculés » (Black-Scholes)**, un
  `<details>` natif sous chaque stratégie (`laboRenderAnalyse()`),
  entièrement déplié à la demande : montre Prix/Volatilité historique/Taux
  sans risque utilisés, la formule complète en clair, et pour chaque jambe
  (Put vendu, Call vendu, LEAPS acheté…) le d1 et le strike obtenus à
  CHAQUE borne du Delta — de quoi vérifier l'arithmétique à la main plutôt
  que de faire confiance à un chiffre opaque.
- Taux sans risque : nouvelle constante `CFG.labo.riskFreeRate` (4%,
  approximation — aucune source de taux en direct dans cette app).
  `CFG.labo.atrMultiplier` et `leapsProfondeurItmPct` retirés de
  `config.js` (devenus inutiles, l'ATR ne sert plus au calcul de strike du
  Labo — il reste utilisé ailleurs dans l'app, Fiche de trade/screening).
  `leapsDteTypiqueJours` (365 jours, ~1 an) ajouté pour donner un T concret
  au calcul Black-Scholes du LEAPS, distinct de `leapsDteMinJours` (180,
  le minimum annoncé dans le texte).

**T3 — rendre les périodes SMA 9/21/100 réellement configurables, visibles
en haut de l'écran.** En creusant cette demande, un vrai écart a été
trouvé : `CFG.indicateurs.smaRapide/Moyenne/Lente` (config.js) ne pilotait
QUE les libellés affichés — `getHomemadeIndicators()` calculait toujours
sur 9/21/100 en dur, peu importe ce que config.js contenait. Le commentaire
du fichier l'annonçait d'ailleurs lui-même (« informatif pour l'instant »),
mais ce n'était plus vrai depuis que les SMA sont calculées maison (pas
juste lues sur TradingView) — un écart de documentation devenu trompeur.
Corrigé pour l'onglet Labo spécifiquement (pas les autres écrans, qui
gardent 9/21/100 fixes pour l'instant — changement scopé à la demande
réelle) :
- `getHomemadeIndicators(symbol, { periods })` (`server/indicators.js`)
  accepte maintenant `{ fast, medium, slow }`, défaut 9/21/100 inchangé
  pour tous les appelants existants (screening, `/api/market-data`).
- `GET /api/labo/:ticker?smaFast=&smaMedium=&smaSlow=` (`server/index.js`)
  lit ces query params (validés positifs entiers, repli sur 9/21/100
  sinon) et les transmet ; la réponse échoue `smaPeriods` pour confirmer
  les valeurs réellement utilisées.
- 3 champs numériques ajoutés **tout en haut de l'onglet Labo**
  (`index.html`, avant même le sélecteur de stratégie), préremplis depuis
  `CFG.indicateurs` mais modifiables — `loadLaboTicker()` les lit et les
  passe en query params à chaque clic sur « Charger les données en
  direct ». Les libellés de la carte de métriques et du texte de séquence
  (`laboSmaDetail()`) affichent les périodes RÉELLEMENT utilisées
  (`data.smaPeriods`), pas une valeur supposée.

**Vérifié en direct** (serveur redémarré pour charger le code) :
`GET /api/labo/AMD` → volatilité historique 72.1% (titre volatil, plausible
pour AMD), zone de Put 387,15$–421,16$ pour Delta 0.15-0.25 (contre
432,55$–455,06$ avec l'ancienne heuristique ATR — les deux méthodes
divergent, ce qui confirme qu'elles ne mesuraient pas la même chose) ;
`GET /api/labo/AMD?smaFast=5&smaMedium=10&smaSlow=20` → SMA effectivement
recalculées sur ces nouvelles périodes (valeurs différentes de l'appel par
défaut, confirmées différentes à la décimale). Dans le navigateur : 15
valeurs `.labo-dyn` détectées dans la séquence PMCC ; panneau d'analyse
déplié montre le détail complet (d1, strike par jambe) pour les deux
stratégies ; champs SMA changés dans l'UI (5/10/20) → libellés de la carte
de métriques et texte de séquence mis à jour en conséquence
(« Alignement SMA 5/10/20 »). Aucune erreur console JS à aucune étape.
Serveur de test arrêté après vérification — rien ne tourne en
arrière-plan.

## Corrections UI Labo/Secteurs + relanceur React (5/9/2026, 4e passe)

Six demandes de JP : trois retouches d'utilisabilité dans le Labo, deux
ajouts dans l'onglet Secteurs, et un outil de secours pour ne plus dépendre
de Claude Code pour relancer castellana après une panne.

**T1 — ticker par défaut du Labo → TQQQ.** `CFG.labo.defaultTicker`
(`config.js`), distinct de `CFG.defauts.ticker` (AMD, utilisé par Secteurs/
Screener/Fiche de trade) — `applyConfig()` et le repli de
`renderLaboSequence()` (`index.html`) le lisent séparément.

**T2 — statique vs dynamique illisible dans "Données réelles du titre".**
Cause réelle trouvée : cette carte utilisait des `<span>`/`<strong>` bruts
au lieu des classes `.ds-metric__label`/`.ds-metric__value` du design
system (déjà utilisées correctement ailleurs, ex. Fiche de trade) — sans
ces classes, aucun style ne s'appliquait, d'où l'absence totale de
distinction visuelle. Corrigé par simple adoption des bonnes classes ;
`alignEl.className` (JS) corrigé au passage — il écrasait
`ds-metric__value` par `ok`/`warn`/`bad` au lieu de les cumuler.

**T3 — les 3 champs SMA pas au même niveau.** Cause réelle : `.row label`
donne 260px au premier label, les deux labels suivants portaient un
`style="width:auto"` en ligne — largeurs incohérentes, le premier champ
finissait sur sa propre ligne. Remplacé par `.labo-sma-params` (grille 3
colonnes égales, label au-dessus du champ) dédiée, plutôt que de rafistoler
`.row`.

**T4/T5 — fusion Force relative + Golden Cross dans "Ticker", + fondamentaux
(OBV/Volume/Float/P/E/Industrie/P-E industrie/PEG/Beta/VWAP).** Scopé
UNIQUEMENT à l'onglet **Secteurs** (demande explicite de JP) — l'onglet
Screener garde sa disposition en 3 cartes séparées, les deux onglets restent
donc volontairement différents désormais (avant cette session ils étaient
identiques par construction). `GET /api/market-data/:ticker`
(`server/index.js`) gagne une 4ᵉ branche `Promise.allSettled` :
`getFundamentals(ticker, {withVwap:true})`. Le "P/E industrie" pour un
ticker hors watchlist (ex. saisir un titre non suivi) est calculé depuis le
**dernier screening en cache** (`industryPeerStatsFromScreeningCache()`) —
pas un nouveau batch de 20 appels Yahoo à chaque clic ; affiche `—`/0 pair
si aucun screening n'a encore tourné, jamais un chiffre inventé. Nouveau
`renderSecFundamentals()` (`index.html`) peuple la grille `.grid-3` (9
tuiles `.ds-metric`), réutilise `fmtVolume()`/`fmtFloat()`/`obvBadge()` déjà
écrits pour le tableau de screening plutôt que de les redéfinir.

**T6 — outil de relance (`launcher/`), en React, indépendant de
castellana.** Contexte : plusieurs sessions consécutives où JP devait
demander à Claude Code de relancer manuellement le serveur/sidecar après
une panne ou un redémarrage du Mac — aucun mécanisme ne permettait de le
faire soi-même sans terminal. Décision d'architecture explicitée avec JP
au préalable (`AskUserQuestion`, dismissée puis reformulée directement en
"une appli React pour castellana") : outil **séparé**, pas une extension du
mécanisme de relance déjà existant de bilbao (R9a/R9b, actuellement scopé à
valencia) — le mot "React" et le nom explicite "castellana" tranchaient la
question.

Contrainte de conception centrale : cet outil doit rester lui-même stable
et disponible précisément quand castellana ne l'est plus — il tourne donc
sur son **propre port (4750)**, totalement indépendant du serveur Express
de castellana (4700) et de son sidecar (4701).
- `launcher/server.js` — **zéro dépendance npm** (`node:http`, pas Express
  — un framework de plus est une source de panne de plus pour l'outil censé
  nous sortir de la panne), lié à **127.0.0.1 uniquement** (même garde que
  castellana). `GET /api/status` (TCP connect sur les 2 ports),
  `POST /api/restart` (`{target: 'node'|'sidecar'|'both'}`) — cible
  toujours parmi 2 valeurs fixes, jamais une commande/un chemin arbitraire
  venant de la requête (les commandes réelles sont codées en dur, ports lus
  depuis le vrai `../settings.json` pour ne pas diverger). Tue via
  `lsof -ti:PORT -sTCP:LISTEN` puis `spawn(..., {detached:true}).unref()`.
- `launcher/public/index.html` — React 18 UMD (CDN), **sans JSX ni Babel**
  (composants écrits avec `React.createElement` directement) — page unique,
  aucune étape de build, cohérent avec la discipline zéro-dépendance du
  reste du portfolio pour ce type d'outil (coimbra). 3 boutons (Node,
  sidecar, les deux), statuts en direct (poll 10s), journal des actions,
  lien direct vers castellana une fois les deux services actifs.

**Bug réel trouvé et corrigé en testant** (pas en relisant le code) :
`killPort()` utilisait `lsof -ti:PORT` sans `-sTCP:LISTEN` — cette commande
matche aussi les connexions **clientes** vers ce port, pas seulement le
process qui l'écoute en serveur. Comme `server/tradingview.js` (castellana)
ouvre une connexion cliente sortante vers le sidecar sur le port 4701,
cliquer "Relancer le sidecar" tuait **aussi** le serveur Node de castellana
lui-même — repéré uniquement parce que le journal de l'outil listait le PID
du serveur Node parmi les PID "arrêtés" d'une relance du sidecar seul.
Corrigé (`-sTCP:LISTEN` ajouté), reproduit et re-vérifié après correction :
relancer le sidecar seul, puis le serveur Node seul, ne perturbe plus
l'autre service dans un sens comme dans l'autre.

**Vérifié en direct, de bout en bout** : les 4 corrections UI (T1-T5)
vérifiées dans le navigateur (Browser pane) et par lecture directe du DOM ;
le relanceur testé avec de VRAIS kill/respawn (pas des mocks) — relance
Node seul (ancien PID tué, nouveau confirmé répondant), relance sidecar
seul (après correction du bug ci-dessus, confirmé n'affecte plus le
serveur Node), relance des deux ensemble, et rejet propre en 400 d'une
cible invalide (testé avec une chaîne `"rm -rf /"` comme cible — confirme
qu'aucune commande arbitraire ne peut être injectée, la cible est toujours
validée contre l'enum fixe avant tout `exec`/`spawn`). **Laissé actif** au
port 4750 — c'est tout l'intérêt de l'outil, JP peut l'utiliser directement
via `http://127.0.0.1:4750` sans repasser par une session Claude Code.

## Contexte, plages configurables, refactor partagé, onglets Réglages (6/9/2026, 5e passe)

Huit demandes de JP après avoir utilisé les corrections de la 4e passe.

**T1 — bannière "un signal sur deux" pas assez explicite.** `calcSelectionFor()`
(`index.html`) nomme désormais explicitement lequel des deux signaux
(Force relative / Golden Cross) est positif et lequel ne l'est pas, plutôt
que « un signal positif sur deux » sans préciser lequel. Précise aussi que
le ticker affiché est simplement celui saisi dans « Ticker évalué » — pas
une recommandation automatique de l'app (réponse à « pourquoi présenter
TGT ? »).

**T2 — libellé "Devise" pas assez explicite.** Clarifié avec JP avant de
coder (le renommer en "Secteur" aurait rendu la phrase incohérente,
"Secteur : USD / CAD") : l'intention réelle était de préciser qu'on choisit
la devise des **ETF sectoriels** proposés, pas de renommer le concept.
Libellé → « Devise des ETF sectoriels (USD ou CAD) : ».

**T3/T4 — période de référence et indice de référence non précisés.**
Chaque valeur de la grille "Fondamentaux" (carte Ticker, onglet Secteurs)
porte maintenant sa période : OBV (tendance, 10j), Volume (jour), P/E
(trailing), Beta (5 ans), VWAP (séance en cours) — voir
`js/ticker-section.js`. Section "Force relative" renommée
« Force relative vs indice de référence (S&P 500 — SPY) », et le champ
"Performance de l'indice" précise directement "Performance du S&P 500
(SPY)" — l'indice de référence (SPY, en dur dans `server/tradingview.js`
et `js/ticker-section.js`) n'était mentionné nulle part dans l'UI
auparavant. Le champ "Performance du titre" précise aussi que la valeur
récupérée en direct est celle du **jour** (Yahoo `change_pct`), pas une
période arbitraire, tout en restant éditable à la main pour une autre
période si JP le souhaite.

**T5/T6 — plages Prix/Float des filtres du Screener pas explicites, pas
configurables.** Les filtres "Volume > 1M"/"PEG ≤ 1"/"Beta > 1" affichaient
déjà leur seuil ; "Prix dans la plage" et "Float dans la plage" ne
disaient pas laquelle. Ajouté en haut de "Filtres supplémentaires" : deux
paires de champs (`filter-prix-min/max`, `filter-float-min/max`),
préremplis depuis `CFG.screening` (`initScreenFilterRanges()`) mais
**réellement modifiables en direct** — `applyScreenFilters()` recalcule
`passPrix`/`passFloat` CÔTÉ CLIENT à partir de `row.price`/`row.floatShares`
(déjà présents dans chaque ligne) plutôt que de rejouer un screening
complet ; les 4 autres filtres restent sur leurs seuils fixes calculés
côté serveur (non demandés configurables). Libellés des cases à cocher
mis à jour en direct (`updateFilterRangeLabels()`) pour toujours refléter
la plage actuellement configurée.

**T7 — dupliquer la section "Ticker" entre Secteurs et Screener n'est plus
tenable, propose un mécanisme.** La carte "Ticker" de Secteurs a grossi
(fusion Force relative/Golden Cross + 9 champs fondamentaux, 5/9/2026)
pendant que celle de Screener restait plus simple — les deux étaient
écrites à la main dans `index.html`, donc vouées à diverger à la prochaine
retouche oubliée d'un côté. Nouveau `js/ticker-section.js` :
`tickerSectionHTML(instanceKey, {withFundamentals})` génère le markup
complet, `renderTickerSectionInto(instanceKey, options)` l'injecte dans
`#${instanceKey}-ticker-card` — appelé une fois par instance
(`renderTickerSectionInto('sec', {withFundamentals:true})` /
`('scr', {withFundamentals:false})`) avant `applyConfig()`. Les deux
cartes `sec-ticker-card`/`scr-ticker-card` dans `index.html` sont
maintenant des conteneurs vides ; `calcSelectionFor()`/
`fetchLiveSelectionFor()` n'ont pas changé (mêmes IDs générés,
`${instanceKey}-xxx`, cohérent avec `SELECTION_INSTANCES` déjà existant).
Un futur ajout à cette section se fait donc UNE fois, dans le template,
et s'applique aux deux onglets (ou à un seul, via l'option
`withFundamentals`).

**T8 — onglets dans "Réglages".** Panneau Réglages réorganisé en 2 onglets
internes (`.settings-tab-btn`/`.settings-tab-panel`, mécanisme séparé de
`switchTab()` pour ne pas interférer avec les onglets principaux de
l'app) : **Technique** reprend tel quel le contenu de dépannage existant
(Backend/Sidecar/BD), plus une nouvelle carte pointant vers l'outil de
relance (`launcher/`, port 4750). **Valeur personnalisée** est un espace
réservé, vide pour l'instant (aucun réglage éditable directement dans
l'app aujourd'hui — tout reste dans `config.js`) — JP n'a pas précisé ce
qui doit y aller, cet onglet prépare juste la structure pour de futurs
réglages éditables sans passer par un fichier.

**Vérifié en direct** (fichiers statiques, pas de redémarrage serveur —
aucun changement backend ce tour-ci) : bannière T1 testée en forçant un
scénario "1 signal sur 2" (TGT, Force relative positive/Golden Cross
absent) → message nommant explicitement les deux ; carte Fondamentaux
confirmée identique fonctionnellement après le refactor T7 (P/E
industrie, VWAP, etc. toujours peuplés) ; `sec-ticker-card` contient bien
les champs fondamentaux, `scr-ticker-card` non à ce moment-là (options du
template respectées — **revu le lendemain, voir juste en dessous**) ;
plages Prix/Float testées avec de fausses lignes (AAA à 50$ dans
[10$,100$] → non atténuée, BBB à 500$ → atténuée, recalcul confirmé après
changement des bornes) ; onglets Réglages testés (bascule Valeur
personnalisée ↔ Technique, contenu technique intact). Aucune erreur
console JS à aucune étape.

## Bornes Prix/Float resserrées + standard "Ticker" unifié (6/9/2026, 6e passe)

Deux demandes le lendemain de la 5e passe, en usage réel de l'app.

**Nouvelles bornes par défaut des filtres Screener** (JP, univers suivi
visiblement plus small/mid-cap que prévu à l'origine) : Prix 5$-1000$
(était 1$-10000$), Float 10M-20M actions (était 0-100000M). Mis à jour aux
DEUX endroits qui doivent rester synchronisés (pas de format de module
commun entre le `<script>` classique et le backend ESM, voir le
commentaire déjà en place) : `CFG.screening` (`config.js`) et
`SCREEN_FILTERS` (`server/index.js`). Comme ces plages sont maintenant
éditables en direct depuis l'UI (T5/T6, 5e passe), ces valeurs ne sont que
le point de départ affiché à l'ouverture — JP peut toujours les ajuster
sans redémarrer le serveur.

**"Ticker" doit être identique dans Secteurs ET Screener** — revirement
sur la décision du 5/9/2026 (qui scopait volontairement les fondamentaux à
Secteurs seul). JP a remarqué l'incohérence en utilisant l'app et a
tranché : même standard partout. Grâce au refactor T7 de la 5e passe
(`js/ticker-section.js`), ce changement tient en **une ligne** —
`renderTickerSectionInto('scr', {withFundamentals:false})` →
`{withFundamentals:true}` — exactement la promesse du refactor (« un futur
ajout se fait une fois, dans le template »). Seul ajustement de code
supplémentaire nécessaire : `renderSecFundamentals(m)` (nommée pour
l'instance `sec` uniquement) généralisée en
`renderFundamentalsFor(instanceKey, m)`, appelée sans condition
`instanceKey === 'sec'` dans `fetchLiveSelectionFor()` — sinon `scr`
aurait eu les tuiles vides à l'affichage mais jamais peuplées au clic sur
« Récupérer en direct ».

**Vérifié en direct** : serveur redémarré (changement backend
`SCREEN_FILTERS`) — `/api/screening` confirme des flags `passPrix`/
`passFloat` calculés sur les nouvelles bornes (5-1000$, 10-20M) ; champs
`filter-prix-min/max`/`filter-float-min/max` préremplis à 5/1000/10/20
côté UI. `fetchLiveSelectionFor('scr')` sur AMD peuple bien
`scr-m-obv`/`scr-m-volume`/`scr-m-pe` (confirmé par lecture DOM,
identique à `sec`). Aucune erreur console JS.

## Télémétrie testeurs (6/9/2026)

JP veut mettre castellana dans les mains de 2 testeurs. Trois décisions
prises avec lui (`AskUserQuestion`, plusieurs tours) avant de coder :

1. **Hébergement de l'app** : chacun lance castellana en local, comme JP
   (réutilise [SETUP.md](SETUP.md), déjà écrit le 30/8 pour l'onboarding
   d'un collègue). **Aucun hébergement partagé** — castellana reste 100%
   locale, comme documenté partout ailleurs dans ce fichier.
2. **JP a demandé si l'app entière pouvait aller sur Cloudflare** (il y a
   déjà un compte) — **réponse : pas telle quelle**. Castellana a 3 choses
   incompatibles avec le modèle Workers (assets statiques, patron déjà
   utilisé par barcelona/porto/essen-hub) : un process Express persistant,
   `better-sqlite3` (module natif compilé), et le sidecar Python
   `tradingview-mcp` — Workers ne supporte ni process long-terme, ni
   module natif, ni Python. Un vrai portage existerait (Cloudflare D1 à la
   place de better-sqlite3, routes réécrites en handlers Workers,
   abandon du sidecar Python) mais c'est un chantier séparé et important,
   **pas fait cette session** — JP a choisi de garder l'app locale plutôt
   que d'ouvrir ce chantier maintenant.
3. **Identité pour la télémétrie** : un sélecteur de nom + l'IP capturée
   côté serveur, en complément l'un de l'autre — **pas un login** (T3
   explicitement reporté à plus tard, mais le sélecteur sert de socle pour
   quand ce sera construit).

**Architecture retenue** : comme l'app tourne en local chez chaque
testeur, aucune vue d'ensemble n'est possible sans un point de collecte
externe. Un petit **Cloudflare Worker + D1** (`telemetry-worker/`) reçoit
les événements directement du navigateur de chaque testeur — **`server/
index.js` n'est pas impliqué, aucune route ajoutée côté backend local**.
C'est le premier Worker du portfolio avec du vrai code serveur (`main`) et
une base D1 — tous les autres Workers du portfolio (barcelona/porto/
essen-hub) ne servent que des assets statiques. **Conséquence à retenir** :
c'est **le premier élément de castellana jamais déployé publiquement**,
mais seulement ce collecteur — l'app elle-même reste locale.

**3 types d'événements, correspondant exactement aux 4 demandes de JP**
(ticker sélectionné, paramètres modifiés, quand, qui) :
- `app_loaded` — un par chargement de page (qui + quand, horodatage
  serveur pas client, pour rester fiable même si l'horloge d'un testeur
  dérive).
- `ticker_selected` — `{tab, ticker, instance}`. **Pas un `oninput`
  générique** (trouvé en explorant le code : `calcSelectionFor()`/
  `calcFiche()` tournent sur beaucoup de champs non liés au ticker,
  auraient noyé le signal) — hooké sur 4 points d'action réellement
  significatifs à la place : fin de `fetchLiveSelectionFor(instanceKey)`
  (couvre à la fois le bouton « Récupérer en direct » ET les clics de
  ligne `selectScreeningRow`/`selectSectorTopRow`, qui l'appellent en
  interne), fin de `fetchLiveFiche()`, succès de `saveTrade()` (Journal),
  succès de `loadLaboTicker()` (Labo). Les 5 onglets sont donc couverts.
- `param_changed` — `{param, tab, oldValue, newValue}`. Instrumente
  uniquement les **9 champs réellement modifiables à l'exécution**
  (`#atrmult`, `#riskpct`, `#capital`, les 4 bornes de filtre Screener,
  les 3 champs SMA du Labo) — trouvé en explorant `config.js` que la
  grande majorité de ses valeurs ne pilotent que des libellés/valeurs par
  défaut, jamais éditées par l'utilisateur (donc rien à instrumenter
  là-dessus). Écoute sur l'événement `change` (pas `input`), pour ne pas
  spammer à chaque pixel de glissement d'un slider.

**Fichiers** :
- `js/telemetry.js` (nouveau) — `sendTelemetryEvent()`, `trackTickerSelected()`
  (dédoublonné par onglet), `initParamTelemetry()`, `initIdentityPicker()`
  (injecte un `<select class="ds-select">` dans `.status-bar`, persisté en
  `localStorage`), `initTelemetry()` (point d'entrée, appelé une fois à la
  fin de l'init de `index.html`, après `renderTickerSectionInto()`/
  `applyConfig()`/`initScreenFilterRanges()` pour que les champs suivis
  existent déjà). Fire-and-forget total : `try/catch` silencieux, jamais de
  blocage UI ni d'erreur visible si le Worker est injoignable ou pas encore
  déployé (`CFG.telemetry.endpoint` vide au premier lancement).
- `config.js` — section `CFG.telemetry` (`enabled`, `endpoint` — vide tant
  que JP n'a pas déployé le Worker —, `sharedToken`, `testeurs`).
- `telemetry-worker/` (nouveau composant déployé, hors app) — Worker natif
  (`fetch(request, env)`, zéro framework), 3 routes : `POST /events`
  (ingestion, jeton requis), `GET /events.csv?token=` (export, même patron
  d'échappement que `GET /api/screening.csv`/`GET /api/trades.csv`),
  `GET /dashboard?token=` (tableau HTML des 200 derniers événements, pour
  consulter sans repasser par `wrangler d1 execute`). D1 : table unique
  `telemetry_events` (voir `schema.sql`). Voir
  [`telemetry-worker/README.md`](telemetry-worker/README.md) pour les
  commandes de déploiement exactes.
- `index.html` — `<script src="js/telemetry.js">`, conteneur
  `#who-picker` dans `.status-bar`, `initTelemetry()` ajouté à la séquence
  d'init de fin de fichier, 4 appels `trackTickerSelected(...)` insérés
  dans les fonctions listées ci-dessus. **`server/index.js`/`server/db.js`
  non touchés.**

**Sécurité — volontairement limitée, documentée comme telle** :
`CFG.telemetry.sharedToken` (dupliqué à la main dans
`telemetry-worker/wrangler.jsonc`, aucune synchronisation automatique,
même limite déjà documentée pour `SCORE_BANDS`/`SCREEN_FILTERS`) n'est
**pas** une vraie authentification — juste un filtre anti-bruit pour
qu'un bot qui découvrirait l'URL publique du Worker ne pollue pas la
base. Il est visible dans le code source du navigateur par construction.
Le champ « who » est une auto-déclaration (pas un login), l'IP capturée
côté Worker est un complément, pas une preuve d'identité — cohérent avec
le report explicite de T3 (vrai login) à plus tard.

**Non fait cette session** (hors scope, confirmé avec JP) : aucun vrai
login, aucun changement à l'hébergement de l'app, aucune route ajoutée au
serveur Express local.

**Worker déployé le 6/9/2026** (session suivante) —
https://castellana-telemetry.iechocreator.workers.dev. `wrangler login`
(OAuth navigateur, complété par JP), `wrangler d1 create` (id
`3647b572-e88e-45c1-9401-df62e5e46e12`), schéma appliqué en `--remote`,
`wrangler deploy`. `CFG.telemetry.endpoint` mis à jour en conséquence.
**Testé en direct** : `POST /events` avec le bon jeton → 200 + ligne
insérée (confirmée via `/dashboard` et `/events.csv`) ; avec un mauvais
jeton → 401 ; ligne de test retirée de la base après vérification
(`DELETE FROM telemetry_events WHERE who = '...'`) pour ne pas polluer les
vraies données des testeurs.

**Tableau de bord enrichi (7/9/2026)** — JP a demandé de pouvoir
« récupérer la télémétrie et en faire un dashboard ». Décision : enrichir
directement la route `/dashboard` déjà déployée (accès direct à D1, pas de
CORS/latence) plutôt qu'un Artifact Claude (**écarté** : le pare-feu réseau
des Artifacts bloque tout `fetch()` vers un hôte externe comme ce Worker —
impossible d'y afficher des données en direct depuis cette source) ou un
nouvel outil séparé. Skill `dataviz` du portfolio consultée avant d'écrire
le SVG à la main (palette catégorielle slot 1 bleu, mode sombre — voir
`references/palette.md` du skill).

Ajouté à `handleDashboard()` (`telemetry-worker/src/index.js`) :
- **Filtre par testeur** + **plage de jours** (7/30/90, défaut 30) — un
  formulaire GET classique (pas de JS de filtrage côté client), qui scope
  les 2 graphiques et le tableau détaillé en une seule requête cohérente.
- **Activité par jour** — barres verticales (une série, magnitude dans le
  temps), `json_extract` non nécessaire ici (`substr(created_at,1,10)`
  pour grouper par jour). Pas de valeur affichée sur chaque barre (jusqu'à
  90 barres selon le filtre) — info-bulle au survol + graduations Y
  portent le détail, conforme à la règle du skill (« jamais un nombre sur
  chaque point »).
- **Tickers les plus sélectionnés** — barres horizontales classées,
  `json_extract(payload_json,'$.ticker')` filtré sur
  `event_type='ticker_selected'`, top 15. Valeur affichée au bout de
  chaque barre ici (liste courte, contrairement au graphique quotidien —
  labelliser reste lisible).
- Info-bulle au survol (JS minimal, `pointermove`/`pointerleave`,
  `textContent` — jamais `innerHTML` — pour les valeurs qui viennent de
  données utilisateur comme le nom du testeur ou le ticker).

**Bug réel évité en testant, pas juste en relisant le code** : le premier
lot de données de test envoyé via `curl` (12 événements JP/Louis/
Guillaume) partageait tous le même horodatage serveur (`new Date()` au
moment de l'insertion), donc le graphique « activité par jour » n'aurait
montré qu'une seule barre — insuffisant pour vérifier visuellement un
graphique à plusieurs jours. Corrigé en insérant un second lot directement
en SQL (`INSERT ... VALUES` avec des `created_at` explicites sur 5 jours
différents) pour un test visuel réaliste.

**Découverte en testant, pas anticipée** : la base contenait déjà de la
**vraie télémétrie** (7 événements, `user_agent` Chrome/macOS réel,
IP réelle) — JP avait dû utiliser castellana pour de vrai après le
déploiement de la session précédente. Le nettoyage post-test a donc dû
être chirurgical : `DELETE FROM telemetry_events WHERE id >= 9` (ciblant
précisément les données de test insérées cette session), **en préservant**
les 7 événements réels antérieurs (ids 2-8) plutôt qu'un nettoyage global
qui les aurait détruits — un `DELETE FROM telemetry_events` sans clause
aurait été une perte de données réelle, pas juste de bruit de test.

**Vérifié en direct dans le navigateur** : filtre par testeur (isolé sur
`inconnu` → 2 événements, état vide correct sur le graphique tickers —
« Aucun ticker sélectionné sur cette période », jamais un graphique
vide sans explication) ; info-bulle au survol sur les deux graphiques
(barre quotidienne → « 7 — 2026-09-06 », barre ticker → « 1 — TQQQ ») ;
aucune erreur console. Redéployé (`wrangler deploy`), URL inchangée.

## Refonte de fiabilité et d'installation (7/9/2026, 2e session)

Point de départ : un audit de l'app en marche, commandé par JP avec l'objectif
explicite de « mettre ce produit dans les mains de personnes sérieuses ».
8 constats (F1→F8) et un budget de requêtes mesuré. Plan approuvé via
`EnterPlanMode`/`ExitPlanMode` (`~/.claude/plans/robust-honking-yeti.md`).

### Le constat structurant, revérifié avant d'y toucher

L'audit affirmait que le sidecar Python ne fournit rien d'irremplaçable.
**Revérifié en direct contre le sidecar en marche**, d'abord sur AMD puis sur
les 21 titres de la watchlist (`rsi`/`sma50`/`sma200`/`goldenCross`, maison
vs `coin_analysis`) : **aucun écart au-delà de l'arrondi**. Mieux — PLTR et
XEQT.TO, que le sidecar ne résout pas du tout, ressortent maintenant
complets. C'est le taux d'échec de 14 % relevé par l'audit, tombé à 0.

**Décision de JP** : le sidecar n'est pas supprimé, il devient **optionnel et
désactivé par défaut** (`settings.tradingviewMcp.enabled`, défaut `false`).
Il reste branchable pour comparer les deux sources.

### Ce qui a changé, par constat

| | Constat | Traitement |
|---|---|---|
| **F1** | Session MCP jamais invalidée : un sidecar redémarré restait mort jusqu'au redémarrage d'Express | `clientPromise` jeté au premier échec de **transport** (pas sur une erreur métier « No data found », où la session est saine). Corrigé bien que le sidecar soit désormais éteint par défaut |
| **F2** | Rien ne surveille les processus | Watchdog dans `launcher/server.js` : sondage 15 s, relance automatique, **backoff** et **plafond de 5 tentatives** pour ne pas boucler sur une panne permanente, compteur remis à zéro dès que le service répond, journal consultable. Bascule via `POST /api/watchdog` |
| **F3** | Aucun retry, aucun timeout nulle part | `server/fetch-retry.js` — `withRetry` (2 tentatives, backoff, temporisation 10 s) sur **tous** les appels externes, + `mapWithConcurrency` |
| **F4** | Rate-limit TradingView en usage normal | Sans objet sur le chemin par défaut : plus aucun appel au scanner |
| **F5** | PLTR bloqué sur `exchange: NYSE` (migré au NASDAQ en 2024) | Corrigé dans le seed **et** dans la base déjà semée de JP (le seed seul n'aurait rien changé chez lui). Sans effet sur le chemin par défaut, Yahoo résolvant le ticker sans bourse |
| **F6** | Les cotations transitaient par le sidecar | `server/quotes.js` — Yahoo direct, **requête groupée** (1 appel pour 21 titres + SPY) |
| **F7** | `/api/screening` accusait « tradingview-mcp injoignable » quelle que soit la cause | `Promise.allSettled` + `passErrors` : chaque passe rapporte son propre échec, comme le fait déjà `/api/status` |
| **F8** | Caches en mémoire, perdus à chaque redémarrage | `server/cache.js` — cache persistant en SQLite. Les deux caches mémoire (`screeningCache`, `sectorTopCache`) ont disparu |

### Deux recommandations de l'audit corrigées en les mesurant

1. **`node:sqlite` n'est pas utilisable ici.** L'audit recommandait de
   remplacer `better-sqlite3` pour supprimer la compilation native. Sur le
   Node **v22.12.0** de JP, `require('node:sqlite')` échoue (`No such
   built-in module`) : il faut `--experimental-sqlite`, avec une API
   annoncée instable. Et `better-sqlite3@11.10` installe via
   `prebuild-install || node-gyp rebuild` — il **télécharge un binaire
   précompilé** et ne compile qu'en dernier recours. Le remède était pire
   que le mal. **`better-sqlite3` conservé** ; `npm run doctor` teste
   désormais son chargement réel et donne le remède exact s'il échoue.
   À revoir quand Node 24 sera la base.
2. **Les TTL longs auraient figé des prix.** Le plan prévoyait 12 h pour un
   historique quotidien et 24 h pour un bêta. Faux dans les deux cas : la
   **dernière barre** d'un historique quotidien est celle du jour en cours,
   encore en mouvement, et `quoteSummary` mêle dans un seul objet des champs
   trimestriels et des champs intrajournaliers. Servir un prix figé à un
   outil de trading est bien pire que d'être lent. TTL courts partout où la
   réponse contient un champ intrajournalier — avertissement en tête de
   `server/cache.js`, à ne pas « rétablir » par inadvertance.

### Installation

- **Python sort du chemin par défaut.** `demarrer.command`/`demarrer.bat`
  n'installent plus de venv. Deux nouveaux scripts `installer-sidecar.*`
  l'installent pour qui le veut (avec confirmation, et bascule automatique de
  `enabled` à `true`). **223 Mo → 53 Mo, 2 prérequis → 1.**
- **Version de Node vérifiée** (≥ 20), pas seulement sa présence.
- **Repli de port** : 4700 puis 4711-4715, avec le port retenu écrit dans
  `data/runtime.json`. Un port occupé produisait avant un `EADDRINUSE` non
  intercepté — sous Windows, la fenêtre se refermait sans explication. Les
  lanceurs **attendent ce fichier** au lieu d'un `sleep` fixe, et ouvrent le
  navigateur sur la bonne adresse.
- **`npm run doctor`** (`scripts/doctor.mjs`, zéro dépendance, tourne avant
  `npm install`) : Node, dépendances, module natif, droits d'écriture, port,
  Yahoo. Chaque ligne en échec porte son remède.
- **Gatekeeper** : `demarrer.command` lève lui-même la quarantaine du reste
  du dossier une fois autorisé. Le clic droit → Ouvrir reste nécessaire pour
  lui-même — sans compte Apple Developer, il n'y a pas d'échappatoire.
  **⚠️ Toujours pas testé avec un vrai téléchargement navigateur.**

### Bandeau de version et mise à jour en un clic

Le zip devenait périmé **en silence** : un testeur n'avait aucun moyen de
savoir que sa copie datait. Ajouté : `version.json` estampillé par
`npm run package`, route `/version` sur le Worker de télémétrie déjà déployé
(publique, sans jeton), bandeau dans l'app, et bouton **Mettre à jour**.

`server/update.js` est **le code le plus risqué de l'app** — il réécrit
l'application pendant qu'elle tourne. Garde-fous, à ne pas alléger : tout est
téléchargé, extrait et **vérifié dans un dossier de travail** avant que quoi
que ce soit ne bouge ; la bascule n'est **que des renommages** ; `data/`,
`node_modules/` et `settings.json` ne sont **jamais** touchés ; l'ancienne
version est conservée dans `data/.update/backup-<horodatage>`.

⚠️ **`PUBLISHED_VERSION` (telemetry-worker/wrangler.jsonc) doit être bumpé à
la main** en même temps que `version` dans `package.json`, à chaque
publication d'un zip — rien ne synchronise les deux (même limite déjà
documentée pour `TELEMETRY_TOKEN`). Publier un zip sans toucher à cette
variable laisse simplement les testeurs sur leur version : silencieux, pas
cassé.

**Worker redéployé le 7/9/2026** (`wrangler deploy`, version
`da7148df-fc65-408c-874c-0b4ddb5fdd26`) : la route `/version` répond en
ligne, publiquement et sans jeton. Vérifié après coup que `/events.csv` et
`/dashboard` refusent toujours une requête sans jeton (401), et que les
**31 événements de télémétrie réels ont survécu** — un déploiement ne touche
pas D1. `PUBLISHED_VERSION` vaut 1.0.0, soit la version installée : aucun
bandeau de mise à jour n'est donc proposé, ce qui est le comportement voulu
tant que le zip n'est pas publié sur iecho.ca.

### Télémétrie d'erreurs

4ᵉ type d'événement (`error`), branché sur `fetchJSON()` — le point de
passage unique de tous les appels API du frontend. Dédoublonné par
(route + message). N'envoie que la route et le message : **aucune donnée de
marché, aucun trade, aucun montant**. JP voit désormais quand un testeur
heurte un mur, au lieu de l'apprendre par message.

### Vérifié en direct cette session

- **Comparaison maison vs sidecar sur les 21 titres** : 0 écart (tableau
  complet dans la sortie de session).
- **Screening chronométré** : 37 s → **1,99 s** à froid, 0,37 s données en
  cache, 0,023 s screening en cache. **21/21 titres sans trou**, `passErrors`
  vide.
- **Cache persistant** : 65 entrées, screening et export CSV toujours servis
  **après un redémarrage du serveur** (l'export répondait 409 avant).
- **Retry/timeout/parallélisme** : échec puis succès, temporisation qui rend
  la main sur un appel qui ne revient jamais, 12 tâches de 100 ms en 204 ms
  avec une limite de 6.
- **Watchdog** : castellana **réellement tué**, détecté, relancé
  automatiquement, récupération confirmée (journal à l'appui).
- **Repli de port** : 4700 occupé → bascule sur 4711 annoncée + `runtime.json`.
- **Mise à jour, sur une copie jetable**, trois cas : archive tronquée →
  refus, rien modifié, journal intact ; archive qui n'est pas castellana →
  refus, rien modifié ; **vraie mise à jour 1.0.0 → 1.0.1** → version
  basculée, fichier nouveau présent, **sentinelle du journal de trades
  intacte**, `node_modules` préservé, sauvegarde de 22 entrées récupérable,
  processus arrêté puis redémarré en 1.0.1.
- **Navigateur** : 5 onglets, pastille sidecar **grise** (désactivé, pas
  rouge), 21 lignes au Screener avec **PLTR et XEQT.TO complets**, secteurs,
  Labo, Journal, bandeau de mise à jour rendu avec son bouton. **Aucune
  erreur console.**
- **`npm test` : 32/32** (7 auparavant).

### Deux erreurs faites et corrigées en cours de route

1. **Suppression accidentelle d'un bloc d'`index.js`** : une ancre de
   remplacement (`try { const watchlist = getWatchlist();`) matchait
   `/api/sectors` avant `/api/screening`, emportant tout ce qui se trouvait
   entre les deux. Repéré par un crash au démarrage (`screeningCache is not
   defined`), restauré depuis git, réappliqué avec des ancres relatives à la
   route, puis **vérifié par un diff de la liste des routes contre HEAD** —
   identiques.
2. **Un test faux, pas un code faux** : j'avais écrit que le RSI de Wilder
   vaut exactement 50 sur une alternance +1/-1. C'est vrai de l'**amorce**
   seulement ; au-delà, le lissage oscille autour de 50 et la dernière
   variation décide du côté. Test corrigé (égalité exacte sur `period+1`
   clôtures, encadrement sur la série longue), code inchangé.

Au passage, un **vrai bug trouvé par un test** : `readCache` utilisait
`age > ttl`, ce qui servait une entrée pile à son TTL — avec un TTL de 0
(« ne jamais mettre en cache »), l'entrée était servie tant qu'on la relisait
dans la même milliseconde. Corrigé en `>=`, ici et dans `purgeExpiredCache`.

### Non fait, et à savoir

- **Rien n'a été testé sur une vraie machine Windows** — `demarrer.bat` et
  `installer-sidecar.bat` sont vérifiés par lecture de code et cohérence avec
  leurs équivalents macOS uniquement. Limite déjà connue et inchangée.
- **Gatekeeper non testé avec un vrai téléchargement navigateur.**
- **Le zip n'a pas été publié sur iecho.ca** — le lien de téléchargement sert
  encore la version qui réclame Python. Choix de JP le 7/9/2026 : utiliser
  la nouvelle version lui-même quelques jours avant de l'envoyer à Louis et
  Guillaume. (Le Worker, lui, **a** été redéployé — voir plus haut.)
- La `getFundamentals` mêle toujours champs lents et intrajournaliers dans un
  seul appel : les séparer permettrait un cache 24 h sur bêta/flottant/
  secteur, au prix d'un appel réseau de plus par titre. Non fait, gain jugé
  nul au vu des temps mesurés.


## Feature 351 — correctifs (7/9/2026)

Lot de 4 points relevés par JP après la refonte de fiabilité.

### 1 et 2 — « Unexpected token '<', "<!DOCTYPE "... is not valid JSON »

Deux symptômes (en-tête et carte Performance des secteurs), **une seule
cause**, reproduite au caractère près : une requête vers une route `/api/`
que le serveur ne connaît pas reçoit la **page d'erreur HTML par défaut
d'Express**, que `fetchJSON` passait telle quelle à `JSON.parse`. Le message
qui en sort ne peut être relié à sa cause par personne.

Déclencheur typique : un onglet resté ouvert sur une version du frontend plus
récente que le serveur qui tourne — exactement ce qui arrive pendant un
redémarrage ou après une mise à jour.

Corrigé aux deux bouts, pour que ce message ne puisse plus réapparaître :
- **Serveur** : `app.use('/api', …)` en fin de chaîne renvoie un **404 JSON**
  nommant la route, plus un gestionnaire d'erreurs `/api` qui renvoie du JSON
  au lieu du HTML par défaut d'Express sur une exception non interceptée.
- **Frontend** : `fetchJSON` lit le corps en **texte** avant de le parser ;
  s'il commence par `<` ou porte un `content-type` HTML, il lève un message
  en clair (« Le serveur a renvoyé une page HTML au lieu de données… recharge
  la page »).
- **`checkStatus`** distingue enfin deux pannes qu'il confondait :
  « injoignable » (erreur réseau) et « répond, mais pas ce qui est attendu ».
  L'ancien message envoyait chercher un serveur éteint alors qu'il tournait.

### 3 — Ménage dans Réglages → Technique

Trois cartes étaient devenues **fausses** depuis que le sidecar est optionnel :
elles envoyaient diagnostiquer un composant dont l'app n'a plus besoin
(« témoin rouge malgré un sidecar démarré », rate-limit TradingView), et
affirmaient que sans lui « les champs concernés restent en saisie manuelle » —
ce n'est plus vrai, ils sont calculés.

Pire, la carte de relance proposait `lsof -ti:4700 | xargs kill` **sans
`-sTCP:LISTEN`** — la commande exacte qui avait fait tuer le mauvais
processus dans le launcher le 5/9/2026. Corrigée, avec l'explication du
pourquoi.

Onglet réécrit en 7 cartes : **Cette installation** (version, adresse et état
du sidecar en direct — de quoi répondre à « quelle version tournes-tu ? »
sans terminal), `npm run doctor` en premier réflexe, relance (avec le repli
de port), watchdog du launcher, sidecar présenté comme optionnel et inutile,
données locales (et le fait qu'une mise à jour ne touche jamais `data/`),
mises à jour.

### 4 — Réglages → Valeur personnalisée : périodes éditables + réinitialisation

L'onglet était un espace réservé vide. Il porte maintenant les 4 périodes
demandées (SMA rapide 9, moyenne 21, **lente 50**, RSI 14), un bouton
Enregistrer et un bouton **Réinitialiser aux valeurs par défaut**.

**Ces valeurs pilotent réellement le calcul**, ce qui est le point important :
`config.js` ne changeait longtemps que les **libellés** pendant que le serveur
calculait toujours sur 9/21/100 (écart déjà corrigé pour le seul onglet Labo
le 5/9/2026 — il l'est ici pour toute l'app). Nouveau `server/preferences.js` :
- stockage **en base**, pas dans `settings.json` — les réglages appartiennent
  à l'utilisateur et **survivent à une mise à jour** (`server/update.js` ne
  touche jamais `data/`, alors qu'il remplace les fichiers de code) ;
- validation : entier entre 2 et 250, **et** ordre rapide < moyenne < lente —
  sans ce dernier contrôle, 50/21/9 serait accepté et l'alignement haussier
  deviendrait silencieusement inatteignable ;
- `resetPreferences()` **supprime** les lignes au lieu d'y réécrire les
  défauts, pour qu'un utilisateur ayant réinitialisé suive un futur
  changement de défaut plutôt que de rester figé sur l'ancien ;
- branché sur `/api/screening`, `/api/market-data` et `/api/labo` (dont les
  3 champs partent désormais des préférences au lieu de 9/21/100 en dur —
  deux écrans affichant des périodes différentes pour le même indicateur
  auraient garanti la confusion) ;
- un changement **vide le cache de screening** : le garder afficherait des RSI
  calculés avec les anciennes périodes sous des libellés annonçant les
  nouvelles.

Le glossaire (`js/glossaire-indicateurs.js`), qui annonçait « SMA 9/21/100 »
en dur, parle maintenant de rapide/moyenne/lente.

**⚠️ Écart assumé avec le document de design** : celui-ci fixe le filtre de
tendance à 9/21/**100**, et ce fichier demandait explicitement de ne pas y
toucher. JP a demandé **50** dans la feature 351, à deux reprises (valeurs
initiales *et* valeurs du bouton de réinitialisation) — c'est donc délibéré.
Noté dans `design_assistant_swing_trading.md`, qui porte désormais 9/21/50.
**Le Pine Script de ce document n'a PAS été modifié** (il calcule toujours
`sma100`) : l'alerte réellement configurée sur TradingView ne peut être
changée que par JP à la main, et réécrire le script sans qu'il le reporte
créerait un écart silencieux entre l'app et l'alerte.

### Vérifié en direct

- Cause des points 1-2 **reproduite** avant correction : une route API
  inconnue renvoyait bien `text/html` et produisait le message exact de JP.
- Après correction : route inconnue → `{"error":"Route API inconnue : …"}` en
  JSON ; `fetchJSON` sur une page HTML → message en clair ; backend simulé
  injoignable → message « injoignable » distinct, et le bandeau disparaît au
  rétablissement.
- Préférences : refus de l'ordre incohérent et de la valeur non entière avec
  message lisible, enregistrement, **libellés et champs du Labo qui suivent**,
  bouton Réinitialiser qui rétablit 9/21/50 et RSI 14.
- **Le calcul suit vraiment** : AMD `rsi=49.3262` en période 21 contre
  `49.6732` en 14, SMA recalculées sur 7/25/60 — et le screening rapporte les
  préférences appliquées.
- Onglet Technique : 7 cartes, « Cette installation » peuplée en direct
  (1.0.0 | 127.0.0.1:4700 | désactivé).
- Chargement à froid dans le navigateur : **toutes les requêtes en 200**,
  aucune erreur console (les 400/404 observés venaient de mes propres tests
  d'erreur volontaires).
- `npm test` : **40/40** (32 auparavant), dont 8 nouveaux sur les préférences.


## Statuts bilbao remis à jour (7/9/2026)

En marquant la feature 351 livrée, un écart est apparu : **#346 (journal —
modifier + export CSV) et #347 (tests automatisés) étaient livrés depuis le
31/8/2026 et encore marqués `Planifie`** — exactement la dérive à deux
sources de vérité que bilbao existe pour éviter. Vérifiés un par un avant de
les marquer (`editTrade()` présent, `GET /api/trades.csv` → 200, `npm test`
vert) plutôt que sur la foi du journal de bord.

**#345 scindée en deux** plutôt que marquée livrée en bloc : son titre
couvrait « XEQT comme repère diversifié **+ trous sectoriels du P/E
industrie/PEG moyen** », dont seule la première moitié est faite. #345 est
recadrée sur XEQT.TO et passée à `Livre` ; la seconde moitié devient
**#352** (`Planifie`). Ce qui la bloque n'est pas technique : choisir des
titres individuels représentatifs par secteur est une décision de JP. Noté
aussi dans #352 que XEQT.TO ne comble PAS ces trous — Yahoo ne lui donne ni
`sector` ni `industry`, vérifié le 31/8/2026.

Toutes ces mutations sont passées par l'API de bilbao
(`PATCH /api/feedbacks/:id`, `POST /api/feedbacks`), jamais par une édition
à la main de `features.json` — artefact possédé par bilbao et régénéré à
chaque mutation. **Seule #352 reste ouverte** pour castellana.


## État

- 2026-07-22 : cadrage initial. Document de design consolidé
  (`design_assistant_swing_trading.md`), nom de code **castellana** assigné,
  ce `CLAUDE.md` créé (remplace un contenu erroné — copie de celui de bilbao
  — collé par erreur dans ce dossier). Architecture, périmètre MCP et
  intégration au portfolio (bilbao, root `CLAUDE.md`) encore à faire.
- 2026-07-22 : les deux prototypes HTML (`fiche_trade_sizing_stop.html`,
  `ecran_selection_titres.html`) confirmés présents à la racine du dossier
  (déposés par JP). Copie vendorée de `design-system/tokens.css` et
  `components.css` ajoutée dans `design-system/` — résout le point
  « Design system » de la section Architecture.
- 2026-07-22 : les deux prototypes rendus conformes au design system, à la
  demande de JP — liens vers `design-system/tokens.css`/`components.css`,
  suppression des `:root` locaux dupliqués/dérivés (`--surface2` →
  `--surface-2`, etc.), adoption des composants `.ds-card`/`.ds-badge`/
  `.ds-metric`/`.ds-input`/`.ds-select`. Comportement/calculs inchangés,
  vérifié en navigateur. Repo Git initialisé, premier commit, repo GitHub
  privé créé et poussé
  ([iechocreator-po/trading-assistant](https://github.com/iechocreator-po/trading-assistant)).
  Produit ajouté au `CLAUDE.md` racine (table sommaire, fiche détaillée,
  table de consommation du design system) et à `REPOS` dans
  `portfolio-checkin.sh`.
- 2026-07-22 : décision prise sur les explications pédagogiques
  d'indicateurs — pas d'appel dynamique à un modèle Claude. Structure
  retenue : `js/glossaire-indicateurs.js`, objet JS statique par indicateur
  (`label`, `pourquoi`, `bandes.{vert,amber,rouge}`), calqué sur les bandes
  de la section 4.4 du design doc. Une seule fonction de rendu lit ce
  glossaire pour le tooltip/popover. Aucune clé API, aucun credential.
  Résout le point « Explications d'indicateurs » de la section Architecture.
- 2026-07-22 : les deux prototypes fusionnés en une seule app à onglets. À
  la demande de JP (« c'est le même produit », « les écrans devraient être
  fusionnés avec un système d'onglet ») : `index.html` créé à la racine,
  onglets « Écran de sélection » / « Fiche de trade », transfert automatique
  du ticker de l'un vers l'autre au changement d'onglet. `config.js` créé en
  parallèle (fichier de réglages demandé par JP) — voir entrée
  Configurabilité plus haut. Les anciens fichiers `fiche_trade_sizing_stop.html`
  et `ecran_selection_titres.html` déplacés (`git mv`) dans
  [`prototypes/`](prototypes/), conservés à titre de référence historique
  uniquement, ne sont plus la source de vérité. Vérifié en navigateur :
  bascule d'onglet, transfert du ticker, libellés/bornes pilotés par
  `config.js` (SMMA 9>21>100, RSI(14), capital 50000$, risque 1%), calculs
  de sizing inchangés.
- 2026-07-22 : décision d'architecture de JP — le stack sera un backend
  (pas frontend statique + service à part), puisque le serveur MCP
  TradingView en nécessite un de toute façon. Patron retenu : Node Express +
  better-sqlite3 (même patron que valencia/bilbao). Résout le point
  « Stack » de la section Architecture ; le backend lui-même reste à
  scaffolder (pas encore de `package.json`/`server/` dans ce dossier).
- 2026-07-22 : demande de JP sur les feature flags — pas de
  `bilbao.features.json` créé à la main : ce fichier est, par convention
  établie dans tout le portfolio (voir `CLAUDE.md` racine, section
  « Convention — fichiers standards par produit »), écrit exclusivement par
  la Console de bilbao (`PUT /api/console/:code/flags`), jamais à la main —
  règle qui évite justement d'avoir deux sources de vérité qui dérivent
  (même leçon que R16/R20/R24 chez bilbao). Reste en attente d'une session
  bilbao dédiée (voir Checklist portfolio ci-dessous).
- 2026-07-22 : adoption de `tradingview-mcp` comme serveur MCP TradingView,
  après évaluation par Claude (README + code source
  `core/services/indicators.py` du projet, pas seulement la description
  marketing) et décision de JP (« adopte-le pour ça et documente le
  reste »). Couvre VIX/RSI(14)/ATR(14)/Volume-vs-moyenne-20j/Golden Cross
  avec de vraies valeurs calculées, correspondant à la logique déjà validée
  du design doc. Deux lacunes identifiées et documentées plutôt
  qu'ignorées : son champ « OBV » est une fausse heuristique (clôture vs
  ouverture de la bougie, pas un vrai cumul), et la SMMA 9/21/100 n'est pas
  exposée (seulement SMA/EMA) — les deux resteront des calculs maison sur
  historique OHLC brut, source encore à choisir. Résout le point « Serveur
  MCP TradingView » de la section Nouvelles exigences et le point
  « périmètre MCP » de la section Architecture ; **n'implémente rien
  encore** — pas de sidecar lancé, pas de dépendance ajoutée au projet, la
  décision est documentée en amont du scaffold du backend.
- 2026-07-22 : scaffold du backend livré (Node Express + better-sqlite3,
  patron valencia/bilbao). `package.json`, `settings.json` (port 4700),
  `server/db.js` (schéma `trades` — journal de trades, section 7 du design
  doc), `server/index.js` (écoute 127.0.0.1 uniquement, sert `index.html`
  statiquement, route `GET /api/health`). Piège npm connu du CLAUDE.md
  racine rencontré et contourné (`npm install --cache
  /tmp/npm-cache-castellana`, EACCES sur le cache root-owned). Vérifié :
  boot, `/api/health` → `{status:"ok",trades:0}`, app identique en
  `http://127.0.0.1:4700/` à ce qu'elle était en `file://`. Serveur de test
  arrêté après vérification — rien ne tourne en arrière-plan. Résout le
  point « scaffold du backend » de la section Architecture. Reste ouvert :
  brancher `tradingview-mcp`, les calculs maison OBV/SMMA, et des routes
  API pour la table `trades` (elle existe, rien ne l'utilise encore).
- 2026-07-22 : `tradingview-mcp` branché en sidecar Python (demande de JP).
  Installé dans un venv dédié non commité (`.venv-mcp/`), lancé en
  `streamable-http` sur `127.0.0.1:4701` (`npm run sidecar`).
  `server/tradingview.js` (client `@modelcontextprotocol/sdk`, connexion
  paresseuse) + route `GET /api/market-data/:ticker` dans `server/index.js`
  (503 propre si le sidecar est injoignable, même patron que le
  `GITHUB_TOKEN` absent chez bilbao). **Testé avec des données réelles**,
  pas des mocks : `curl .../api/market-data/AMD` → VIX 16.64, RSI 56.09,
  Golden Cross confirmé. **Correction importante découverte en testant** :
  ATR et volume-vs-moyenne-20j, évalués « ✅ réel » lors de la décision
  d'adoption sur la seule lecture du code source, reviennent en fait `null`
  en usage réel (la librairie sous-jacente `tradingview_ta` ne demande pas
  ces champs par défaut) — reclassés en calcul maison aux côtés d'OBV réel
  et de la SMMA 9/21/100. Découverte additionnelle : la version PyPI
  installée (0.7.1) est en retard sur le README du repo GitHub — plusieurs
  outils documentés n'existent pas dans le paquet publié ; le bon outil
  pour l'analyse technique s'appelle `coin_analysis`, pas
  `get_technical_analysis` comme supposé initialement. Section « Intégration
  données de marché — tradingview-mcp » corrigée en conséquence. Serveurs
  de test (Express + sidecar) arrêtés après vérification — rien ne tourne
  en arrière-plan. Le frontend (`index.html`) ne consomme pas encore cette
  route — les champs y restent saisis à la main pour l'instant.
- 2026-07-22 : JP demande de lancer les deux process pour usage réel (pas
  juste un test) — backend + sidecar démarrés et **laissés actifs** cette
  fois (contrairement aux vérifications précédentes où ils étaient arrêtés
  après coup). Vérifié : `/api/health`, `/api/market-data/AMD` (données
  réelles), rendu de l'app dans le navigateur — tout fonctionne.
- 2026-07-22 : câblage du frontend sur les données temps réel + tableau de
  screening 20 titres (demande de JP). **Rate-limit de `coin_analysis`
  découvert en testant** (confirmé deux fois, persistant plus de 5 minutes,
  re-déclenché par un screening lancé juste après un autre — voir section
  dédiée « Rate-limit non documenté »). Réponse de conception : résilience
  par source dans `server/tradingview.js`/`server/index.js`
  (`Promise.allSettled`, jamais `Promise.all` ; force relative sourcée de
  `yahoo_price`, indépendante du scanner TradingView rate-limité). Livré :
  `server/watchlist.js` (20 titres — 12 de JP + 8 ajoutés par Claude,
  `top_gainers` testé et rejeté car ramène des micro-caps spéculatives sans
  rapport avec la stratégie) ; `screenWatchlist()` séquentiel espacé
  (1.5s/titre, ~30-60s pour 20) ; route `GET /api/screening` (score sur 3
  colonnes RSI/Force relative/Golden Cross — OBV exclu, pas fiable ; verdict
  `ajouter`/`surveiller`/`ne pas ajouter`/`erreur`) ; route
  `GET /api/quote/:symbol` (cotation Yahoo simple, résiliente) ; correction
  de résilience sur `GET /api/market-data/:ticker` (était `Promise.all`,
  donc perdait le VIX — pourtant disponible — quand `coin_analysis`
  échouait ; passé à `Promise.allSettled`). Frontend (`index.html`) : bouton
  « Récupérer en direct » sur les deux onglets, carte « Screening — univers
  de titres (20) » avec tableau cliquable (sélectionner une ligne charge le
  titre dans la section Ticker). **Vérifié en direct de bout en bout, deux
  fois** : une première fois en dégradé pendant le rate-limit (force
  relative seule disponible, RSI/Golden Cross vides, table affichée sans
  planter), une seconde fois après résorption du rate-limit (~5-10 min plus
  tard) avec RSI/Golden Cross/scores réels et corrects dans le tableau
  trié. Aucune donnée inventée à aucun moment — soit la vraie valeur, soit
  `null`/`erreur` explicite. Serveurs laissés actifs (voir entrée
  précédente).
- 2026-07-23 : OBV réel et SMMA 9/21/100 livrés (demande de JP : « Attaque
  les calculs maison »). Source OHLC brute tranchée : `yahoo-finance2`
  (npm), historique quotidien direct — écarté Alpha Vantage
  (`TIME_SERIES_DAILY`, déjà connecté côté JP) pour cet usage précis, quota
  25 req/jour trop bas pour un screening de 20 titres. Nouveau
  `server/indicators.js` : `computeSMMA()` (RMA standard), `computeOBV()`
  (cumul classique), `classifyOBV()` (approximation confirme/diverge sur
  fenêtre de 10 barres — documentée comme approximation, pas une détection
  formelle de divergence), `getHomemadeIndicators()` +
  `getHomemadeIndicatorsBatch()`. Module autonome, aucune dépendance à
  `tradingview-mcp`. Branché sur `GET /api/market-data/:ticker` (3ᵉ branche
  `Promise.allSettled`, indépendante des deux autres sources) et
  `GET /api/screening` (OBV réintégré comme 4ᵉ colonne du score, résout
  l'écart au design doc noté lors du lancement de la fonctionnalité de
  screening). Frontend : sélecteur OBV de la Fiche de trade auto-rempli par
  « Récupérer VIX + RSI en direct » (sans cocher la checklist
  automatiquement — reste un geste manuel de JP), indice d'alignement SMMA
  affiché en texte à côté de la checklist, colonne OBV ajoutée au tableau
  de screening. **Vérifié en direct** (AMD, données réelles) : SMMA
  9>21>100 cohérente avec le prix et le Golden Cross déjà confirmé par
  `tradingview-mcp`, OBV réel calculé et classifié `accumulation` ;
  screening à 4 colonnes re-testé, verdicts cohérents sur les 20 titres.
  Reste ouvert : ATR réel et volume vs moyenne 20j (même approche à
  étendre sur `server/indicators.js`, non demandé cette session).
- 2026-07-23 : session interrompue (« ta session est morte en cours de
  travail ») puis reprise — état vérifié avant de continuer : les deux
  serveurs tournaient toujours (Express 4700, sidecar 4701), aucun commit
  perdu, `git log` cohérent des deux côtés. Les commits `194752f`
  (trading-assistant) et `27cf6ab` (portfolio-meta) de la session
  précédente poussés à ce moment-là.
- 2026-07-23 : ATR réel et volume vs moyenne 20j livrés (demande de JP :
  « Attaque l'ATR réel et le volume vs moyenne 20j »), même module
  `server/indicators.js`. `computeTrueRange()` + `computeATR()` (Wilder —
  réutilise `computeSMMA()` sur le True Range, l'ATR de Wilder EST une
  SMMA) ; `computeVolumeVs20d()` (volume du jour ÷ moyenne des 20 jours
  **précédents**, jour courant exclu de sa propre référence). Branché sur
  `/api/market-data/:ticker` (préfère le calcul maison, `tradingview-mcp`
  en repli) ; le bouton Fiche de trade renommé « Récupérer VIX + RSI + ATR
  + OBV en direct » remplit maintenant aussi le champ ATR, et le hint
  texte combine alignement SMMA + ratio de volume. **Vérifié en direct**
  (AMD) : `atr=36.44$` (≈6.6% du prix), `volumeRatio=0.42` (42% de la
  moyenne 20j) — tous les indicateurs du design doc sont maintenant
  calculés à partir de vraies données, plus aucun `null` structurel.
  **En cours de route, découverte que le sidecar tradingview-mcp était
  mort** (crash pendant l'interruption de session ci-dessus) — relancé
  (`npm run sidecar`), et la connexion MCP côté Express s'est rétablie
  automatiquement sans redémarrage d'Express (le transport
  `streamable-http` n'est pas une socket persistante à re-répondre à la
  main). Cet incident a directement motivé la demande suivante de JP
  (témoin de statut + aide au dépannage), traitée dans la foulée.
- 2026-07-23 : témoin de statut backend + zone d'aide repliable ajoutés
  (demande de JP, suite à l'incident sidecar ci-dessus). `GET /api/status`
  (`server/index.js`) agrège 3 vérifications : `db` (`SELECT 1`),
  `tradingviewMcp` (`checkSidecarConnection()` dans `tradingview.js` —
  `listTools()`, poignée de main MCP qui n'appelle **aucun** outil, donc ne
  consomme jamais le quota du scanner rate-limité), `homemade`
  (`checkYahooConnection()` dans `indicators.js` — cotation SPY minimale,
  teste `yahoo-finance2` directement plutôt que de transiter par le
  sidecar). **Erreur corrigée en cours de session** : premier jet du
  contrôle "homemade" appelait `getPrice('SPY')` de `tradingview.js` — ça
  testait le sidecar une deuxième fois, pas `yahoo-finance2` ; remplacé par
  `checkYahooConnection()`, un vrai test indépendant. Frontend
  (`index.html`) : 3 pastilles colorées (vert/rouge/amber `is-checking`)
  dans le header, hors des onglets (visibles peu importe l'onglet actif),
  actualisées au chargement + toutes les 30s + bouton manuel. Zone
  `<details>`/`<summary>` native (repliée par défaut, zéro JS requis pour
  le pli) juste en dessous, avec les commandes de relance (`npm start`,
  `npm run sidecar`, `lsof -ti:PORT | xargs kill` si port occupé) et le
  rappel du rate-limit `coin_analysis`. **Vérifié en navigateur** : les 3
  pastilles passent au vert avec les deux serveurs actifs, la zone d'aide
  s'ouvre/se referme correctement, le contenu affiché correspond à la
  section « Lancer l'application » de ce fichier (pas de divergence entre
  les deux).
- 2026-08-29 : P/E ratio, industrie et P/E moyen de l'industrie ajoutés au
  tableau de screening (demande de JP). `server/fundamentals.js` : module
  Yahoo `summaryProfile` ajouté à l'appel `quoteSummary` existant,
  `peRatio`/`industry` extraits sans appel réseau supplémentaire. P/E de
  l'industrie calculé dans `server/index.js` comme la moyenne des P/E des
  titres de la watchlist (20) partageant la même industrie — **pas un vrai
  agrégat sectoriel de marché**, documenté comme tel (voir section
  « Screening — P/E ratio et industrie » plus haut), avec
  `industryPeerCount` exposé et affiché en tooltip pour ne jamais laisser
  croire à un échantillon plus large qu'il ne l'est. Colonnes ajoutées au
  tableau HTML et à l'export CSV. **Vérifié en direct** (backend redémarré
  pour charger le code, données réelles) : Semiconductors (AVGO/NVDA/AMD)
  → P/E industrie 70.8 sur 3 pairs ; AAPL seul dans Consumer Electronics →
  P/E industrie = son propre P/E, `industryPeerCount: 1`. Rendu vérifié
  dans le navigateur (tableau, tooltip).
- 2026-08-29 : carte « Performance des secteurs » ajoutée au-dessus du
  screening dans l'écran de sélection (demande de JP, inspirée d'un tableau
  de performance sectorielle). Nouveau `server/sectors.js` : 11 ETF SPDR
  Select Sector + SPY en repère, un seul appel `yahooFinance.quote()` par
  ETF (performance + P/E trailing en un coup, pas besoin de `quoteSummary`).
  Route `GET /api/sectors`, pas de cache (rapide, ~2.5s pour 12 titres, pas
  affecté par le rate-limit de `coin_analysis`). Chargement automatique au
  démarrage de la page (`loadSectors()`), tri par performance décroissante,
  couleur verte/rouge, ligne S&P 500 mise en évidence en bas. **Vérifié en
  direct dans le navigateur** (backend redémarré pour charger le code) :
  11 secteurs + SPY, tri et couleurs corrects, données réelles cohérentes
  avec un aperçu de marché externe pris comme référence.
- 2026-08-29 (deuxième round) : six demandes traitées dans la foulée. **(1)
  Line graph de performance sectorielle** — voir section dédiée plus haut ;
  skill `dataviz` du portfolio consultée avant d'écrire le SVG à la main
  (pas de librairie ajoutée). **(2) Menu Réglages** en overlay plein écran
  (⚙), remplace l'ancien `<details>` d'aide — repris du principe de
  `SettingsPage.tsx` chez essen/nemesis-retaliation (topbar titre+fermer,
  cartes de contenu). **(3) Clic sur une ligne du screening** — déjà câblé
  fonctionnellement (`selectScreeningRow()` remplissait déjà le champ
  Ticker), mais invisible sur un tableau qui occupe tout le viewport ;
  ajouté un `scrollIntoView` + flash de surbrillance (`.flash-highlight`,
  animation CSS) pour rendre le déplacement du ticker réellement visible.
  **(4) Terminologie SMMA/MM → SMA** — voir section « Calculs maison » et
  entrée dédiée ci-dessous. **(5) Capsules d'aide manquantes sur
  « Objectifs — Multiples de R vs Fibonacci »** — deux nouvelles entrées
  `rMultiples`/`fibonacci` dans `js/glossaire-indicateurs.js`, boutons `i`
  ajoutés à côté des deux `colhead`. **(6) Confusion sur « ajouter à la
  liste de suivi active »** — JP a signalé, à raison, qu'aucune liste
  réelle n'était derrière ce texte du banner (c'était une formule
  d'intention, pas une fonctionnalité). Clarifié en deux temps : le texte du
  banner ne parle plus de "liste" mais d'un "candidat à suivre au screening
  quotidien" ; et un vrai bouton **« + Ajouter à la watchlist »** apparaît
  sur un verdict ✓ (2/2), branché sur la VRAIE watchlist
  (`server/watchlist.js`, déjà utilisée par le screening) — désactivé avec
  le libellé « ✓ Déjà dans la watchlist » si le ticker y est déjà.
  **Bug réel trouvé en construisant ce bouton** : `fetchJSON(url)` dans
  `index.html` n'acceptait qu'un seul argument et ignorait silencieusement
  toute option passée en second paramètre — `fetch(url, options)` devenait
  `fetch(url)`. Deux call sites l'utilisaient déjà ainsi sans jamais
  fonctionner : `addWatchlist()` (le bouton "Ajouter" de l'éditeur de
  watchlist ne postait donc jamais rien, il refaisait juste un GET) et
  `closeTrade()` (cliquer "Clôturer" sur un trade ne le clôturait jamais
  réellement, le PUT n'était jamais envoyé). Corrigé une fois pour toutes
  (`fetchJSON(url, options)`), ce qui répare ces deux bugs préexistants au
  passage. **Vérifié en direct** (backend redémarré) : `addCurrentTickerToWatchlist()`
  poste réellement sur `/api/watchlist` (confirmé par lecture de la base
  après coup, puis nettoyé), légende du graphique sectoriel cliquable
  (`toggleSectorSeries('XLK')` retire effectivement la courbe et
  l'étiquette du SVG), capsules R-multiples/Fibonacci lisibles au clic,
  menu Réglages s'ouvre/se ferme. **Non vérifié visuellement par capture
  d'écran** cette session (la tuile du navigateur est restée vide sur
  toutes les captures malgré un DOM/JS confirmé correct par inspection
  directe) — vérification fonctionnelle uniquement pour cette partie.

### Terminologie et calcul du filtre de tendance : SMMA → SMA (29/8/2026)

JP a relevé que les capsules d'aide parlaient tantôt de « SMMA » (filtre de
tendance 9/21/100) tantôt de « MM » (Golden Cross 50/200) pour ce qui
ressemblait au même type de moyenne — une incohérence de vocabulaire. Sa
demande allait au-delà du texte : « je veux que l'on utilise les simple
moving average » et « assure-toi que les données reçues sont bien les
Simple Moving Average (SMA) » — un changement d'algorithme, pas seulement
de libellé.

**Constat** : le filtre de tendance (9/21/100) était bien une SMMA (Smoothed
Moving Average / RMA de Wilder), pas une SMA — vérifié dans le code
(`computeSMMA()`, lissage exponentiel `(prev × (n-1) + close) / n`), pas une
moyenne de fenêtre glissante. Le Golden Cross (50/200), lui, utilisait déjà
une vraie SMA (fournie telle quelle par `tradingview-mcp`/`coin_analysis`,
champ `sma.sma50`/`sma.sma200`) — seul son libellé « MM » (moyenne mobile,
générique) était sous-spécifié, pas le calcul.

**Changements** :
- `server/indicators.js` : nouvelle `computeSMA(closes, period)` (fenêtre
  glissante, somme courante ajustée par soustraction/addition — testée sur
  `[1..10]` avec période 3, résultats exacts). L'ancienne fonction RMA est
  conservée mais renommée `computeRMA()` (non exportée) et réservée à
  `computeATR()` — l'ATR de Wilder reste correctement en RMA par
  définition, ce n'est pas concerné par cette révision.
- Champs renommés partout (API, config, HTML, JS) : `smma9`/`smma21`/
  `smma100`/`smmaAlignment` → `sma9`/`sma21`/`sma100`/`smaAlignment` ;
  `CFG.indicateurs.smmaRapide/smmaMoyenne/smmaLente` →
  `smaRapide`/`smaMoyenne`/`smaLente` ; ids HTML `mm50`/`mm200` →
  `sma50`/`sma200`, `lbl-smma` → `lbl-sma`, `smma-live-hint` →
  `sma-live-hint`. `js/glossaire-indicateurs.js` : clé `smma` → `sma`,
  texte corrigé (« Trois moyennes mobiles SIMPLES », plus de mention RMA) ;
  capsule `goldenCross` : « MM50/MM200 » → « SMA50/SMA200 ».
  `design_assistant_swing_trading.md` (section 4.1/4.2/4.4) mis à jour en
  conséquence, y compris le Pine Script (`ta.rma()` → `ta.sma()`) — **JP
  doit reproduire ce changement à la main dans l'alerte réellement
  configurée sur TradingView**, cet outil ne peut pas la modifier à
  distance.
- **Vérifié en direct** (AMD) : `computeSMA([1..10], 3)` → `[null, null, 2,
  3, 4, 5, 6, 7, 8, 9]`, exact. `getHomemadeIndicators('AMD')` retourne
  `sma9/sma21/sma100` cohérents (valeurs différentes de l'ancien calcul RMA,
  comme attendu — une SMA et une RMA sur les mêmes données ne convergent
  pas vers le même nombre), `atr` inchangé (toujours RMA, comme voulu).

### Statut technique explicite (30/8/2026)

JP a vu une pastille rouge « tradingview-mcp » sans explication et a
demandé que l'app soit explicite sur la nature d'un problème technique
plutôt que d'afficher un point rouge muet. `checkSidecarConnection()`
(`server/tradingview.js`) et `checkYahooConnection()`
(`server/indicators.js`) retournaient un simple booléen, avalant l'erreur
réelle — retournent maintenant `{ ok, detail }`. **Piège trouvé en
implémentant** : l'erreur `fetch` masque la vraie cause système derrière
un message générique `"fetch failed"` — le code réel (`ECONNREFUSED`,
etc.) vit dans `err.cause.code`, pas `err.message` ; vérifié en réel
(sidecar arrêté puis relancé) avant de coder le message utilisateur.
`GET /api/status` expose `tradingviewMcpDetail`/`homemadeDetail`/`dbDetail`.
Frontend (`index.html`) : nouveau bandeau `#status-issues` (rouge, sous la
barre de statut), affiché uniquement si au moins un check échoue, listant
la cause exacte de chacun (ex. « tradingview-mcp : Sidecar non démarré ou
injoignable sur http://127.0.0.1:4701/mcp (npm run sidecar) »). **Vérifié
en direct** : sidecar arrêté → bandeau affiché avec le bon message ;
sidecar relancé + clic Actualiser → bandeau disparaît, 3 pastilles vertes.
`SETUP.md` mis à jour (section dépannage) pour refléter ce nouveau
comportement et corriger une inexactitude qui y trainait : ce témoin teste
la joignabilité du sidecar (poignée de main MCP), **pas** le rate-limit de
`coin_analysis` — les deux sont des problèmes différents, l'ancien texte
laissait croire au même.

### PEG moyen — carte Performance des secteurs (30/8/2026)

Demande de JP. **Vérifié avant d'implémenter** : contrairement au P/E
(exposé nativement au niveau de chaque ETF sectoriel, voir section
précédente), Yahoo Finance n'expose **aucun** PEG au niveau ETF — testé en
direct sur XLK/XLF/SPY via `quote()` et `quoteSummary` (module
`defaultKeyStatistics`) : `pegRatio` revient `undefined` dans les deux cas.
Un PEG n'a d'ailleurs pas de définition standard au niveau d'un secteur
entier (c'est un ratio par entreprise, croissance des bénéfices incluse).

**Calculé à la place** comme la moyenne des PEG des titres de LA WATCHLIST
partageant le même secteur GICS large — même principe d'approximation par
pairs que le « P/E industrie » du screening, mais au niveau du secteur
large (`summaryProfile.sector`, ex. « Technology », « Consumer Cyclical »)
plutôt que de l'industrie fine (`summaryProfile.industry`, ex.
« Semiconductors »). Nouveau champ `sector` ajouté à
`server/fundamentals.js` (même appel `quoteSummary` existant, aucune
requête réseau supplémentaire). Mapping ETF→secteur Yahoo
(`SECTOR_ETF_TO_YAHOO_SECTOR`, `server/sectors.js`) vérifié en direct sur
un titre connu par secteur (XOM→Energy, NEE→Utilities, PLD→Real Estate,
LIN→Basic Materials, UNH→Healthcare, HON→Industrials, PG→Consumer
Defensive) — les noms Yahoo diffèrent parfois du nom SPDR de l'ETF (ex.
« Consumer Cyclical » chez Yahoo = « Consumer Discretionary » côté
XLY/SPDR, même catégorie).

**Couverture nécessairement partielle, assumée et affichée comme telle** :
la watchlist (20 titres tech/IA) n'a aucun titre dans 7 des 11 secteurs
(Énergie, Services publics, Santé, Immobilier, Conso. de base, Industriel,
Matériaux) — ces lignes affichent « — », jamais un chiffre inventé.
`pegPeerCount` exposé et affiché en tooltip (même discipline que
« P/E industrie »). `/api/sectors` fait maintenant `Promise.all` entre
`getSectorPerformance()` (ETF, rapide) et `getFundamentalsBatch()` sur la
watchlist (`withVwap:false`, 20 titres) — **vérifié en direct** :
Technologie 11 pairs (PEG moyen 1.30), Conso. discr. 3 pairs (2.41),
Finance 1 pair (1.13), Services de comm. 4 pairs (1.14), les 7 autres à
0 pair (`null`/« — »), cohérent avec la composition réelle de la
watchlist.

### Disclaimer bilingue (30/8/2026)

Demande de JP : reprendre le disclaimer FR/EN de marbella
(`calc-retirement/calculatrice_retraite_swr_v2.html`) — texte identique
mot pour mot, même structure visuelle (deux blocs côte à côte, fond
amber), adapté aux variables déjà vendorées de castellana
(`--ds-radius-sm`, `--amber`/`--amber-bg` — pas de variables redérivées
comme chez marbella, castellana vendore déjà `tokens.css` correctement).
Placé juste sous le header, avant le témoin de statut. **Vérifié en
direct dans le navigateur** : rendu correct en thème sombre, responsive
(passe en une colonne sous 620px comme chez marbella).

## Trois pistes d'amélioration — roadmap + implémentation (31/8/2026)

JP a demandé de formaliser dans le roadmap bilbao les 3 pistes proposées en
fin de session précédente, avec un plan d'implémentation. Passé par
`EnterPlanMode`/`ExitPlanMode` (approuvé par JP) avant de coder — voir
`~/.claude/plans/glowing-zooming-hejlsberg.md` pour le plan complet.

**Roadmap (bilbao)** : 3 features ajoutées via `POST
http://127.0.0.1:4600/api/feedbacks` (`produit_vise: castellana`,
`type_feedback: Amelioration`, `statut: Planifie`) — ids **345, 346, 347**.
Jamais édité `feature-factory/data/castellana/features.json` à la main
(convention portfolio).

### Watchlist — XEQT.TO comme repère diversifié

JP a demandé d'ajouter XEQT (iShares Core Equity ETF Portfolio) à la
watchlist. **Investigation avant d'implémenter** (pas d'ajout à l'aveugle) :
- Le ticker plain `XEQT` ne résout pas chez Yahoo Finance — il faut
  `XEQT.TO` (Bourse de Toronto). Vérifié en direct.
- `XEQT.TO` n'a **ni `sector` ni `industry`** chez Yahoo (`summaryProfile`
  renvoie `undefined` pour les deux) — normal pour un FNB diversifié
  détenant des milliers de titres. **Ne comblera donc PAS** les trous du
  P/E industrie / PEG moyen. Signalé à JP avant d'implémenter (via
  `AskUserQuestion`), qui a confirmé : l'intention réelle est d'avoir un
  **point de comparaison contre un FNB ultra-diversifié**, pas de combler
  les secteurs — objectif de la feature #345 recadré en conséquence.
- **Limite technique confirmée en direct** : `tradingview-mcp`
  (`coin_analysis`) ne résout pas `XEQT.TO`, quel que soit l'exchange passé
  (`TSX` testé) — erreur *"No data found for XEQT.TO on KUCOIN"* (la
  librairie tierce part sur une bourse crypto par défaut pour ce symbole
  non reconnu). **RSI et Golden Cross resteront donc indisponibles pour
  XEQT.TO** — mais tout le reste fonctionne : prix/force relative
  (`yahoo_price`), P/E réel (21.65), et les calculs maison
  (SMA9/21/100/OBV/ATR/volume, tous via Yahoo direct). État dégradé déjà
  géré nativement (`Promise.allSettled`, colonnes à `—`), aucun code
  spécial nécessaire.

**Implémenté** : `SEED_WATCHLIST` (`server/watchlist.js`) +
`XEQT.TO`/`TSX`/`source: jp`, avec le contexte ci-dessus en commentaire.
Ajouté aussi à la base **actuelle** de JP via `POST /api/watchlist` (éditer
le seed seul n'a aucun effet sur une base déjà semée). Option `TSX` ajoutée
au menu déroulant de l'éditeur de watchlist (`index.html`, `#wl-exchange` —
n'affecte aucun calcul, Yahoo ignore ce champ et tradingview-mcp ne le
résout pas correctement de toute façon pour ce symbole). **Vérifié en
direct** : `GET /api/screening?force=true` (21 titres, XEQT.TO inclus) ne
plante pas — XEQT.TO ressort avec `rsi: null`, `goldenCross: null`,
`error` explicite, mais `price: 45.92`, `peRatio: 21.65`,
`forceRelative: 0.06`, `obvTrend: "accumulation"` tous corrects,
`industry`/`industryPE` à `null` (exclus proprement de l'agrégation),
`verdict: "surveiller"` calculé sur les données partielles disponibles —
comportement identique à tout autre titre en dégradé, pas un cas spécial.
**Trous sectoriels du P/E industrie/PEG moyen** (Énergie, Santé,
Immobilier, Industriel, Matériaux…) : **pas traités** dans cette session —
JP n'a demandé que XEQT explicitement, choisir des titres individuels
reste sa décision, à rouvrir séparément s'il le souhaite.

### Journal de trades — modifier un trade existant + export CSV

**Constat avant d'implémenter** : le CRUD backend (`server/trades.js`,
`PUT /api/trades/:id`) acceptait déjà une mise à jour partielle de
n'importe quel champ — aucun gap backend. Le vrai manque était uniquement
frontend : aucun bouton « Modifier » dans le journal (seulement
Clôturer/Suppr.), et pas d'export CSV du journal (existait déjà pour le
screening, `/api/screening.csv`).

**Implémenté** :
- `server/trades.js` — `COLUMNS` exporté (était un const local) pour être
  réutilisé par l'export CSV.
- `server/index.js` — nouvelle route `GET /api/trades.csv`, même patron
  que `GET /api/screening.csv` (échappement identique), mais **sans
  cache** — lit la base directement à chaque appel (contrairement au
  screening, pas de rate-limit externe à ménager ici).
- `index.html` — bouton « Modifier » ajouté à chaque ligne du journal
  (`editTrade(id)` : pré-remplit le formulaire « Nouveau trade » avec les
  valeurs existantes, bascule le libellé du bouton en « Mettre à jour le
  trade #id », affiche un bouton « Annuler la modification »).
  `addTrade()` renommé `saveTrade()` : POST si `editingTradeId` est `null`,
  sinon PUT vers `/api/trades/:id` — **aucun changement backend requis**,
  le PUT partiel existait déjà. Champs de clôture (date/prix de
  sortie, résultat) volontairement **non éditables** via ce formulaire —
  restent le rôle du bouton « Clôturer » existant, pour ne pas dupliquer
  deux chemins vers le même état. Bouton « Exporter CSV » ajouté dans la
  carte « Trades », même emplacement relatif que pour le screening.
- **Vérifié en direct** (trade de test créé puis supprimé après coup) :
  `editTrade(8)` pré-remplit correctement le formulaire et bascule le
  bouton ; modifier la taille de position (10→25) et `saveTrade()` PUT
  bien vers `/api/trades/8` (vérifié par re-fetch, `taille_position: 25`) ;
  état réinitialisé après sauvegarde (`editingTradeId` revient à `null`,
  libellé du bouton revient à « Enregistrer le trade ») ; export CSV
  contient bien le trade avec sa valeur modifiée.

### Tests automatisés — server/indicators.js

**Décision** : `node:test` natif (Node 22, zéro dépendance ajoutée) plutôt
que Jest/Vitest — cohérent avec la discipline zéro-dépendance du reste du
portfolio pour ce type de besoin (voir coimbra). Script `"test": "node
--test server/*.test.js"` dans `package.json` — **piège trouvé en le
configurant** : `node --test server/` (sans le glob) essaie de charger
TOUS les fichiers `.js` du dossier comme suites de test, y compris
`server/index.js` lui-même, qui démarre alors un vrai serveur Express et
plante avec `EADDRINUSE` si le vrai serveur tourne déjà (ce qui était le
cas) — corrigé en ciblant explicitement `server/*.test.js`.

**`server/indicators.test.js`** (7 tests, uniquement sur les fonctions
**pures**, aucun appel réseau ni mock) : `computeSMA` (fenêtre glissante
sur `[1..10]`/période 3, cas déjà vérifié à la main en session précédente,
plus le cas historique trop court) ; `computeOBV` (hausse/baisse/plat
connus) ; `computeVolumeVs20d` (le jour courant exclu de sa propre
moyenne, plus le cas <21 barres → `null` explicite) ; `computeTrueRange`
et `computeATR` (série OHLC choisie à la main, valeurs de lissage Wilder
calculées et vérifiées manuellement : TR=`[2,3,2,3]` →
ATR(période=2)=`[null,2.5,2.25,2.625]`). Les fonctions réseau
(`getHomemadeIndicators`, `fetchDailyHistory`, `checkYahooConnection`…)
restent hors périmètre — testées manuellement en direct, comme le reste du
projet (pas d'infrastructure de mock ici). **`npm test` → 7/7 verts.**

## Secteurs USD/CAD, onglet Screener, top 30 par secteur (2/9/2026)

Trois demandes de JP, cadrées via `EnterPlanMode`/`ExitPlanMode` (plan
approuvé : `~/.claude/plans/voici-plusieurs-am-liorations-graceful-dewdrop.md`)
puis ajustées en cours d'implémentation quand deux hypothèses du plan se
sont révélées fausses en test réel (voir « Écarts au plan approuvé »
ci-dessous).

### Architecture finale — 4 onglets

`index.html` passe de 3 à 4 onglets, dans cet ordre :

1. **« Secteurs »** (`#tab-secteurs`, renommé depuis « Écran de sélection ») :
   bannière → carte **Performance des secteurs** (sélecteur USD/CAD, voir
   T1) → carte **« Titres les plus performants du secteur »** (voir T2b,
   remplace l'ancienne carte de screening 21-titres qui vivait ici) →
   cartes Ticker/Force relative/Golden Cross (préfixe `sec-`).
2. **« Screener »** (`#tab-screener`, nouvel onglet) : carte
   « Screening — univers de titres (21) » (identique à l'ancienne, même
   route `/api/screening`, mêmes filtres/éditeur de watchlist/export CSV —
   **relocalisée** ici, pas dupliquée) + cartes Ticker/Force relative/
   Golden Cross (préfixe `scr-`, dupliquées de l'onglet Secteurs à la
   demande explicite de JP — « garder une copie dans les deux onglets »,
   pas déplacées).
3. **« Fiche de trade »** — inchangé.
4. **« Journal & stats »** — inchangé.

**Refactor JS partagé** (`SELECTION_INSTANCES` dans `index.html`) : les
deux jeux de cartes Ticker/FR/GC sont rendus par les MÊMES fonctions
(`calcSelectionFor(instanceKey)`, `fetchLiveSelectionFor(instanceKey)`,
`instanceKey` ∈ `{sec, scr}`) plutôt que par du code copié-collé — évite
que les deux instances divergent silencieusement à la prochaine
modification. Les deux champs Ticker sont **volontairement indépendants**
(saisir un titre dans un onglet n'écrase pas l'autre) ; seul un pointeur
`lastTickerInstance`, mis à jour à chaque interaction (saisie, clic
« Récupérer en direct », clic sur une ligne de tableau), détermine lequel
des deux alimente `#ticker` au passage vers l'onglet Fiche de trade
(`switchTab('fiche')`). L'éditeur de watchlist (ajout/suppression de
titres) ne vit plus que dans l'onglet Screener — c'est lui le propriétaire
réel de la watchlist fixe de 21 titres désormais.

### T1 — Sélecteur USD/CAD sur la carte Performance des secteurs

`server/sectors.js` : `SECTOR_ETFS`/`BENCHMARK` (tableaux plats) remplacés
par `SECTOR_DEFS`/`BENCHMARK_DEFS` (objets `{key, label, usd, cad}`, `key`
= toujours le ticker USD, stable). `getSectorPerformance()`/
`getSectorHistory()` prennent un paramètre `mode` (`'usd'`|`'cad'`) et
choisissent `def[mode]` — une seule implémentation pour les deux devises,
pas de code triplé. `/api/sectors` et `/api/sectors/history`
(`server/index.js`) lisent `?mode=` (400 si invalide). La jointure PEG par
secteur utilise désormais `s.key` (pas `s.ticker`, qui peut être un ticker
`.TO` en mode CAD) pour rester correcte peu importe le mode affiché.
Frontend : toolbar 2 boutons USD/CAD (`setSectorCurrency()`), relance les
deux fetches secteurs au clic. `SECTOR_COLORS`/`sectorChartHidden`/
`toggleSectorSeries()` (line graph, légende) réindexés sur `s.key` plutôt
que `s.ticker` pour que les secteurs masqués/isolés dans la légende
survivent à un changement de devise.

**Tickers CAD (BMO)** — fournis par JP puis **vérifiés en direct sur
Yahoo Finance** avant intégration (`yahooFinance.quote()` sur chacun) :

| Secteur | USD | CAD |
|---|---|---|
| Technologie | XLK | ZXLK.TO |
| Conso. discr. | XLY | ZXLY.TO |
| Industriel | XLI | ZXLI.TO |
| Finance | XLF | ZXLF.TO |
| Services publics | XLU | ZXLU.TO |
| Santé | XLV | ZXLV.TO |
| Immobilier | XLRE | **ZRE.TO** (pas ZXRE.TO — voir écart ci-dessous) |
| Conso. de base | XLP | ZXLP.TO |
| Énergie | XLE | ZXLE.TO |
| Services de comm. | XLC | ZXLC.TO |
| Matériaux | XLB | ZXLB.TO |
| Benchmark (S&P 500) | SPY | ZSP.TO |

### T2b — « Titres les plus performants du secteur » (onglet Secteurs)

Clic sur une ligne de `#sectors-tbody` (pas sur la ligne benchmark) →
`selectSectorForTop(sectorKey, label)` → peuple la carte juste en dessous
avec les titres les plus performants du secteur, triés par variation du
jour, avec un choix **top brut / top filtré** (cap. boursière > 2 G$ et
volume > 1M — seuils dans `config.js` `CFG.sectorTop`, dupliqués côté
serveur en `SECTOR_TOP_FILTERS`, `server/sectors.js`).

**Ce n'est PAS une requête de marché en direct** — voir « Écarts au plan
approuvé » ci-dessous pour pourquoi. `SECTOR_TOP_CANDIDATES`
(`server/sectors.js`) est une liste **curatée à la main par secteur**
(16 à 20 titres liquides et connus par secteur, 207 au total), **chaque
ticker vérifié en direct le 2/9/2026** contre la vraie classification
`summaryProfile.sector` de Yahoo Finance (pas seulement supposé) — 4
candidats initiaux ont été écartés à cette étape faute de correspondre :
ADP et PARA sont classés « Technology » chez Yahoo (pas dans leur secteur
« attendu ») ; AVY/PKG/IP/BALL (emballage) sont classés
« Consumer Cyclical » plutôt que « Basic Materials » ; HES/CTRA/IPG ne
résolvent plus du tout (probablement des fusions/acquisitions closes
depuis la connaissance du modèle). `getTopMoversForSector(sectorKey, {mode})`
fait un appel `quoteSummary` par titre de la liste (prix, variation,
cap. boursière, P/E, bourse — **aucun** appel vers `coin_analysis`/
indicateurs maison, pour ne jamais re-déclencher le rate-limit déjà
documenté sur 30 titres à la fois), trie par variation, filtre si demandé,
plafonne à 30. Nouvelle route `GET /api/sectors/:sectorKey/top?mode=raw|filtered`,
cache mémoire par `(secteur, mode)` (`settings.sectorTopCacheMinutes`,
défaut 20 min, `?force=true` bypass), `503` explicite (jamais un `200`
avec `rows:[]`) si Yahoo est injoignable.

**Le compte de titres varie par secteur (16 à 20), et c'est honnête, pas
un bug** : `totalCandidates` est toujours affiché à côté du nombre de
lignes réellement montrées (ex. « 5 sur 16 titre(s) suivis » en mode
filtré sur Matériaux) — jamais un « top 30 » qui laisserait croire à un
univers plus large qu'il ne l'est. Constaté en test réel sur Matériaux
(mode filtré) : plusieurs très grandes capitalisations (LIN, 225 G$)
échouent quand même le filtre de **volume** (moins d'1M d'actions/jour,
prix par action élevé) — comportement attendu du seuil, pas une erreur.

### Écarts au plan approuvé — deux hypothèses fausses trouvées en testant

**1. Le screener personnalisé de Yahoo Finance ne fonctionne pas pour un
usage anonyme.** Le plan prévoyait d'interroger l'endpoint
`v1/finance/screener` (hors `/predefined/saved`) avec une requête filtrée
par secteur, en réutilisant le crumb/cookie déjà géré par `yahoo-finance2`.
**Spike réalisé, résultat négatif, de façon révélatrice** : le screener
**prédéfini** (`day_gainers` etc., déjà supporté par la librairie) répond
normalement avec ce crumb/cookie ; le screener **personnalisé** répond
**429 Too Many Requests** de façon systématique — en GET et en POST, sur
`query1` et `query2`, à plusieurs minutes d'écart, sans aucune rafale de
requêtes. Ce n'est pas un vrai rate-limit (un seul appel isolé suffit à le
déclencher, alors que l'endpoint voisin avec les mêmes identifiants répond
instantanément) — tout indique un endpoint réservé aux comptes connectés
de Yahoo Finance (fonction « créer mon propre screener »), pas une limite
de trafic. **Conformément au principe déjà documenté plus haut dans ce
fichier** (« un vrai anti-bot ne se contourne pas », leçon valencia/
idealista), la barrière n'a pas été forcée — JP a choisi l'alternative
« liste maintenue par secteur » (voir T2b ci-dessus) plutôt que de
persister sur des en-têtes/empreintes de navigateur plus élaborés.

**2. Aucune version CAD "couverte contre le risque de change" n'existe
pour les 11 ETF sectoriels BMO.** Le plan prévoyait un sélecteur à 3 voies
(USD / CAD non couvert / CAD couvert, tickers `.F.TO`). **Vérifié en
direct** : les 10 tickers `.F.TO` testés échouent TOUS sur Yahoo Finance
(`Cannot read properties of undefined`), alors que leurs équivalents non
couverts résolvent tous. Seul le S&P 500 a une vraie version couverte
chez BMO, sous un ticker de racine différente (`ZUE.TO`, pas `ZSP.F.TO`)
— cohérent avec le fait que BMO ne semble tout simplement pas offrir de
version couverte pour ses ETF sectoriels étroits, seulement pour ses
produits larges. JP a choisi de retirer le mode CAD couvert plutôt que de
proposer un sélecteur à 3 voies dont 10 des 11 secteurs pointeraient vers
des tickers inexistants — le dropdown reste à 2 voies (USD/CAD).

### Vérifié en direct (2/9/2026)

Backend : `curl` sur `/api/sectors?mode=usd|cad` (11/11 secteurs résolus
dans les deux modes, aucune erreur), `/api/sectors?mode=bogus` → 400,
`/api/sectors/XLK/top?mode=raw` (20/20 candidats résolus, triés), `/api/sectors/XLB/top?mode=filtered`
(5/16, tous ≥ 2 G$ cap.), cache confirmé (`cached:true` au second appel),
`/api/sectors/SPY/top` → 400 (SPY n'est pas un secteur). Navigateur (via
le Browser pane, JS exécuté directement) : bascule USD→CAD (tableau ET
graphique se remettent à jour, `ZRE.TO`/`ZSP.TO` corrects) ; clic sur
« Énergie » → carte du bas peuplée (18/18 titres, HAL en tête) ; clic sur
une ligne (HAL) → charge dans la carte Ticker de l'onglet Secteurs avec
flash de mise en évidence ; `sec-ticker`/`scr-ticker` confirmés
indépendants (`HAL` vs `AMD` par défaut) ; bascule vers Fiche de trade →
`#ticker` suit bien `HAL` (dernière instance touchée) ; bascule top
brut/filtré sur Matériaux → 16/16 puis 5/16, cohérent. Screening 21-titres
de l'onglet Screener relancé après le refactor — toujours fonctionnel
(voir aussi la note sur le témoin de statut, section dédiée plus haut).
Aucune erreur console JS à aucune étape. Serveur de test arrêté après
vérification — rien ne tourne en arrière-plan (le sidecar tradingview-mcp,
déjà actif avant cette session, n'a pas été touché).
- 2026-09-05 : nouvel onglet **Labo** (stratégies d'options), demande de JP.
  **Écart trouvé et clarifié avant d'implémenter** : le fichier fourni
  (`strategy/PoorManCoveredCall.md.rtf`) décrit en réalité « La Roue &
  Debit Spreads », pas la vraie PMCC — signalé via `AskUserQuestion`, JP a
  choisi de garder les deux, distinctes, dans le sélecteur. Livré :
  `js/strategies-labo.js` (catalogue de stratégies + génération de
  séquence pas-à-pas), `GET /api/labo/:ticker` (`server/index.js` — prix/
  ATR/beta/volume réels via `fundamentals.js`+`indicators.js`, Yahoo direct,
  aucune dépendance à `tradingview-mcp`), section `CFG.labo` (`config.js`).
  4 stratégies au sélecteur (2 `disponible` : La Roue & Debit Spreads, PMCC ;
  2 `a-venir` : Iron Condor, Credit Spreads). Voir section dédiée plus haut
  pour le détail complet et la vérification en direct (AMD, données
  réelles, 3 stratégies testées dans le navigateur, aucune erreur console).
  Serveur redémarré pour charger le code puis arrêté après vérification —
  rien ne tourne en arrière-plan.
- 2026-09-05 (même jour) : terminologie du Labo clarifiée suite à 4
  questions de JP après son premier essai (LEAPS pas défini, formulation
  incohérente entre les deux stratégies, alignement SMA « neutre » non
  vérifiable, Delta cible non expliqué). Nouvelles entrées `leaps`/`delta`
  dans `js/glossaire-indicateurs.js` (même popover que les indicateurs
  techniques), boutons d'aide posés sur chaque mention dans
  `js/strategies-labo.js`, titre de l'étape LEAPS reformulé en verbe-sujet
  actif pour matcher le style de l'autre stratégie, carte de métriques Labo
  (`index.html`) enrichie des valeurs SMA9/21/100 réelles pour que
  l'alignement soit vérifiable à l'œil plutôt qu'un mot opaque. Voir section
  dédiée plus haut. Fichiers statiques uniquement, pas de redémarrage
  serveur nécessaire — vérifié en direct par lecture du DOM (popovers,
  valeurs SMA AMD).
- 2026-09-05 (3e passe, même jour) : trois demandes plus profondes de JP
  (T1 distinction visuelle statique/dynamique, T2 "pourquoi ce prix ?",
  T3 SMA réellement configurables). **Écart de méthode réel trouvé et
  corrigé** : les zones de strike étaient calculées par un multiple d'ATR
  sans AUCUN lien avec le Delta cible affiché à côté — remplacé par un
  vrai calcul Black-Scholes (`js/strategies-labo.js` : normCdf/normInv/
  strikeForDelta, JS pur) à partir de la volatilité HISTORIQUE réelle du
  titre (`computeHistoricalVolatility()`, `server/indicators.js`,
  documentée comme proxy de la volatilité implicite, jamais équivalente).
  Panneau "Comment ces prix sont calculés" ajouté (détail complet, d1 +
  strike par jambe). **Écart de configuration réel trouvé et corrigé** :
  `CFG.indicateurs.smaRapide/Moyenne/Lente` ne pilotait que des libellés,
  jamais le calcul réel (toujours 9/21/100 en dur côté serveur) — corrigé
  pour l'onglet Labo (`getHomemadeIndicators(symbol, {periods})`,
  `GET /api/labo/:ticker?smaFast=&smaMedium=&smaSlow=`), avec 3 champs
  désormais visibles tout en haut de l'onglet. `.labo-dyn` (CSS) distingue
  maintenant chaque valeur calculée du texte de règle statique. Voir
  section dédiée plus haut pour le détail complet et la vérification en
  direct (AMD, volatilité 72.1%, zones Black-Scholes vs ancien calcul ATR
  confirmées différentes, SMA recalculées sur 5/10/20). Serveur redémarré
  pour charger le code backend puis arrêté après vérification.
- 2026-09-06 (4e passe) : 6 demandes — ticker Labo par défaut → TQQQ (T1),
  carte "Données réelles du titre" corrigée (T2, vraie cause : `<span>`/
  `<strong>` bruts au lieu de `.ds-metric__label`/`__value`, aucun style ne
  s'appliquait), 3 champs SMA réalignés en grille dédiée (T3), Force
  relative + Golden Cross fusionnés dans "Ticker" et 9 champs fondamentaux
  ajoutés (OBV/Volume/Float/P-E/Industrie/P-E industrie/PEG/Beta/VWAP) —
  **onglet Secteurs uniquement**, pas Screener (T4/T5). Et
  **`launcher/`** : outil de relance de castellana (Node + sidecar) en
  React 18 UMD (sans build, sans JSX), backend zéro dépendance
  (`node:http`) sur son propre port (4750) — répond à une frustration
  répétée de JP (devoir demander à Claude Code de relancer le serveur après
  chaque panne/redémarrage du Mac). **Bug réel trouvé et corrigé en
  testant, pas en relisant le code** : `killPort()` sans `-sTCP:LISTEN`
  tuait aussi le serveur Node de castellana en relançant le sidecar seul
  (une connexion cliente sortante de castellana vers le sidecar matchait le
  filtre par port) — corrigé, reproduit puis re-vérifié après le correctif.
  Voir section dédiée plus haut pour le détail complet. Vérifié en direct,
  vrais kill/respawn (pas des mocks) : relance Node seul, sidecar seul,
  les deux ensemble, rejet 400 d'une cible invalide (`"rm -rf /"` testé
  explicitement). Le relanceur est **laissé actif** (port 4750, l'intérêt
  de l'outil est justement qu'il reste disponible) ; castellana
  (4700/4701) aussi.
- 2026-09-06 (5e passe) : 8 demandes après usage réel des passes
  précédentes. Bannière "1 signal sur 2" nomme désormais lequel des deux
  (Force relative/Golden Cross) est positif (T1) ; libellé "Devise" clarifié
  en "Devise des ETF sectoriels" après clarification avec JP — "Secteur"
  aurait rendu la phrase incohérente (T2) ; périodes de référence ajoutées
  partout (OBV 10j, Volume jour, P/E trailing, Beta 5 ans, VWAP séance en
  cours — T3) et indice de référence S&P 500 (SPY) enfin nommé dans l'UI,
  jamais mentionné auparavant (T4) ; plages Prix/Float des filtres du
  Screener rendues explicites ET configurables en direct côté client, sans
  rejouer de screening (T5/T6) ; **refactor T7** — nouveau
  `js/ticker-section.js` (`tickerSectionHTML`/`renderTickerSectionInto`)
  génère la section "Ticker" pour les 2 instances (Secteurs avec
  fondamentaux, Screener sans) depuis un seul template, remplaçant la
  duplication manuelle qui menaçait de diverger ; onglets "Valeur
  personnalisée"/"Technique" dans Réglages (T8), le second reprenant le
  contenu existant, le premier laissé en espace réservé (JP n'a pas précisé
  son contenu). Aucun changement backend — vérifié en direct sur les
  fichiers statiques (bannière forcée en scénario mixte, plages de filtre
  testées avec de fausses lignes, bascule des onglets Réglages), aucune
  erreur console. Voir section dédiée plus haut pour le détail complet.
- 2026-09-06 (6e passe, le lendemain) : bornes par défaut des filtres
  Screener resserrées (Prix 5$-1000$, Float 10M-20M actions — étaient
  1$-10000$/0-100000M), mises à jour aux deux endroits synchronisés
  (`CFG.screening` + `SCREEN_FILTERS`). Et revirement sur le scope de la
  section "Ticker" : JP veut le même standard (avec fondamentaux) dans
  Secteurs ET Screener — la décision de la veille qui le limitait à
  Secteurs est annulée. Grâce au refactor T7 (`js/ticker-section.js`), ce
  changement a tenu en une ligne (`withFundamentals:false` →
  `true` pour l'instance `scr`) plus la généralisation de
  `renderSecFundamentals()` en `renderFundamentalsFor(instanceKey, m)`
  (sinon les tuiles de Screener restaient vides au clic "Récupérer en
  direct"). Voir section dédiée plus haut. Vérifié en direct (serveur
  redémarré pour le changement backend) : nouvelles bornes reflétées dans
  `/api/screening` et préremplies dans l'UI, fondamentaux de Screener
  peuplés correctement sur AMD. Aucune erreur console.
- 2026-09-06 (7e passe) : télémétrie testeurs (voir section dédiée plus
  haut) — JP veut mettre castellana dans les mains de 2 testeurs. Avant de
  coder, clarifié avec lui (`AskUserQuestion`, `EnterPlanMode`/
  `ExitPlanMode`) que l'app entière ne peut PAS être déployée sur
  Cloudflare telle quelle (Express persistant + `better-sqlite3` natif +
  sidecar Python, tous incompatibles avec le modèle Workers) — un vrai
  portage existerait mais reste un chantier séparé, pas fait cette
  session. Décision retenue : app en local chez chaque testeur (comme JP),
  télémétrie centralisée via un nouveau Cloudflare Worker + D1
  (`telemetry-worker/`) — **premier composant de castellana jamais
  déployé publiquement**, `server/index.js` non touché. Livré :
  `js/telemetry.js` (3 événements — `app_loaded`/`ticker_selected`/
  `param_changed` — fire-and-forget, jamais bloquant), section
  `CFG.telemetry` dans `config.js`, sélecteur d'identité dans
  `.status-bar` (pas un login, T3 reporté), 4 points d'accroche pour le
  ticker (`fetchLiveSelectionFor`, `fetchLiveFiche`, `saveTrade`,
  `loadLaboTicker` — trouvés en explorant le code plutôt qu'un `oninput`
  générique trop bruyant), listeners `change` sur les 9 champs réellement
  modifiables à l'exécution (le reste de `config.js` ne pilote que des
  libellés, jamais éditable par l'utilisateur). **Vérification partielle
  cette session** : syntaxe validée (`node --check` sur `telemetry.js`,
  `config.js`, le script inline de `index.html`, et
  `telemetry-worker/src/index.js`), tous les 4 appels
  `trackTickerSelected` et les 10 ids de champs suivis confirmés présents
  par grep, `npm test` toujours 7/7 vert (aucun fichier serveur touché).
  **Pas de test en direct dans le navigateur** — le port 4700 était
  occupé par le serveur d'une autre session Claude Code en cours,
  injoignable depuis le Browser pane de celle-ci (isolation entre
  sessions).
- 2026-09-06 (8e passe, même session) : bouton « Partager une idée » (voir
  section dédiée plus haut) — repris tel quel du popup public d'iecho.ca
  (`FeedbackWidget.astro`), même formulaire Formspree partagé, seule
  différence demandée par JP : « Produit concerné » pré-sélectionné sur
  `castellana`. Livré : CSS dans `index.html`, markup bouton+`<dialog>`,
  `js/feedback-widget.js` (nouveau). **Vérifié visuellement** (serveur
  statique temporaire, 4700 étant occupé par une autre session) : rendu
  correct, `castellana` bien pré-sélectionné, aucune erreur console liée
  au widget. **Envoi réel testé par JP juste après, en conditions réelles
  (castellana lancée normalement) — confirmé fonctionnel**, la soumission
  est bien arrivée dans la boîte Formspree partagée avec iecho.ca.
- 2026-09-06 (9e passe, session suivante) : Worker de télémétrie déployé,
  à la demande de JP. `wrangler login` (OAuth navigateur, complété par
  JP), `wrangler d1 create castellana-telemetry-db` (id
  `3647b572-e88e-45c1-9401-df62e5e46e12`), schéma appliqué en `--remote`,
  `wrangler deploy` →
  https://castellana-telemetry.iechocreator.workers.dev.
  `CFG.telemetry.endpoint` mis à jour. **Testé en direct** : `curl POST
  /events` avec le bon jeton → 200 + ligne insérée (confirmée via
  `/dashboard?token=...` et `/events.csv?token=...`) ; avec un mauvais
  jeton → 401 (rejet confirmé) ; ligne de test retirée de la base après
  vérification pour ne pas polluer les vraies données des testeurs. La
  télémétrie est maintenant pleinement active pour les 3 événements
  (`app_loaded`/`ticker_selected`/`param_changed`).
- 2026-09-06 (10e passe, même session) : onglet « Concepts » dans Réglages
  (voir section dédiée plus haut) — guide de 15 concepts de trading
  transcrit d'un fichier `madrid` (`investment-dashboard/indicateur/
  GUIDE_15_CONCEPTS_TRADING.md`), texte + 15 images copiés dans
  `js/concepts-content.js`/`img/concepts/`, aucun lien dynamique entre les
  deux repos. Chaque concept garde sa structure propre (conseil/piège/
  listes ✅❌ selon le cas) plutôt que d'être forcé dans un schéma rigide.
  **Vérifié visuellement** (serveur statique temporaire, 4700 occupé par
  une autre session) : les 15 fiches se déplient, les 15 images se
  chargent, tableau récapitulatif correct en bas, aucune erreur console
  liée au contenu.

## Bouton "Partager une idée" (6/9/2026)

JP a demandé de reprendre le popup « Partager une idée » d'iecho.ca
(`iecho.ca/src/components/FeedbackWidget.astro`) dans castellana, avec une
seule différence : « Produit concerné » pré-sélectionné sur `castellana`
au lieu de vide (« Général / aucun en particulier »).

**Porté tel quel, pas réinventé** : bouton flottant bas-droite → `<dialog>`
natif (pas de librairie modale) → envoi `fetch(...,{method:'POST',
body:new FormData(form)})` vers **le même formulaire Formspree que
iecho.ca** (`mwvdgqgy`) — décision délibérée de réutiliser le même
formulaire plutôt que d'en créer un séparé pour castellana, puisque le
champ `produit` sert justement à distinguer la provenance dans la même
boîte de réception. Mêmes noms de champs (`message`, `produit`, `email`,
`page`, `langue`), même comportement de succès/échec (message vert/amber,
fermeture auto après 1.8s en cas de succès, dialogue qui reste ouvert en
cas d'échec pour permettre de réessayer).

**Différences volontaires par rapport au composant original** (adaptées au
contexte castellana, pas des oublis) :
- Pas d'Astro/i18n FR/EN/ES — castellana est mono-langue (français), les
  libellés sont écrits en dur dans `index.html`/`js/feedback-widget.js`.
- Le champ caché `page` capture l'**onglet actif** (`.tab-btn.is-active`)
  plutôt que `window.location.pathname` — castellana est une app à page
  unique (pas de routes), l'URL serait toujours la même peu importe
  l'onglet ; l'onglet est l'information réellement utile ici.
- La liste des produits du `<select>` (identique à celle d'iecho.ca) est
  **dupliquée à la main** dans `index.html` — castellana n'a pas accès au
  fichier `iecho.ca/src/data/produits.config.json` (repos séparés). À
  mettre à jour manuellement si cette liste change côté hub.
- Style adapté aux jetons de castellana (`--surface`/`--text`/`--accent`
  déjà vendorés) plutôt qu'aux variables propres au thème d'iecho.ca
  (`--fond`/`--texte`/`--accent-vif`, qui n'existent pas ici) ; les champs
  du formulaire réutilisent `.ds-input`/`.ds-select`/`.ds-textarea`/
  `.ds-btn`/`.ds-btn--primary` déjà vendorés, plutôt que de recopier le CSS
  `.bouton-primaire`/`.bouton-secondaire` propre à iecho.ca.

**Fichiers** : CSS ajouté dans le `<style>` de `index.html` (bloc
`.feedback-*`), markup (bouton + `<dialog>`) inséré juste après
`#settings-overlay`, `js/feedback-widget.js` (nouveau —
`openFeedback()`/`closeFeedback()`/`initFeedbackWidget()`), script tag +
appel `initFeedbackWidget()` ajoutés à la séquence d'init de fin de
fichier. Aucun changement serveur.

**Vérifié visuellement** (serveur statique temporaire sur un port libre,
4700 étant occupé par une autre session Claude Code — voir la limite déjà
documentée pour la télémétrie ci-dessus) : bouton visible en bas à droite,
clic ouvre le dialogue avec `castellana` bien pré-sélectionné dans
« Produit concerné », style cohérent avec le thème sombre de l'app, bouton
Fermer ferme proprement, aucune erreur console liée au widget (les 404
observés viennent de l'absence des routes `/api/*` sur ce serveur statique
temporaire, sans rapport). **Envoi réel du formulaire testé par JP en
conditions réelles depuis castellana lancée normalement (pas le serveur
statique temporaire ci-dessus) — confirmé fonctionnel**, la soumission est
bien arrivée dans la boîte Formspree partagée avec iecho.ca.

## Onglet "Concepts" dans Réglages (6/9/2026)

JP a demandé d'intégrer un guide qu'il avait déjà écrit —
`investment-dashboard/indicateur/GUIDE_15_CONCEPTS_TRADING.md` (un autre
produit du portfolio, `madrid`) — dans un nouvel onglet « Concepts » du
panneau Réglages de castellana.

**Contenu transcrit, pas lié dynamiquement** : les deux repos sont
indépendants (pas de fichier partagé), donc le texte des 15 concepts
(EMA, RSI, MACD, Stochastic RSI, Volume, OBV, VWAP, Bandes de Bollinger,
ATR, Fibonacci, Force relative, Breakout, Gaps, Golden Cross, Support &
Résistance) a été copié dans `js/concepts-content.js`, et les 15 images
qui les accompagnent copiées dans `img/concepts/` (renommées en minuscules
plutôt que les noms originaux `1 DTrading_EMA.JPG` etc.). **Si le guide
source change côté `madrid`, il faut reporter les changements ici à la
main** — même limite déjà documentée ailleurs dans ce fichier pour
d'autres contenus dupliqués entre repos (produits.config.json pour le
bouton Partager une idée, par exemple).

**Attribution des images (6/9/2026, signalé par JP)** : les 15 images
proviennent en réalité de la page Facebook de **dtrading.net**
(cohérent avec leur nom de fichier d'origine, `1 DTrading_EMA.JPG` etc.).
Un avertissement d'attribution (« Origine des images ») a été ajouté en
tout premier dans `renderConceptsTab()`, avant même le rappel pédagogique,
avec un lien vers https://dtrading.net/ — crédit explicite, usage
présenté comme purement éducatif.

**Pas de schéma rigide forcé** : le guide source a une structure qui varie
d'un concept à l'autre (la plupart ont un « conseil du pro », RSI et
Breakout ont un « piège à éviter » à la place ou en plus, Golden Cross a
deux listes ✅/❌, Gaps n'a pas de liste « à retenir » mais « les 4
types »). Plutôt que d'inventer un schéma de données qui aurait aplati ou
perdu ces nuances, chaque concept porte directement son corps en HTML
pré-écrit dans le tableau `CONCEPTS_TRADING` — fidèle au texte source, pas
une réinterprétation.

**Rendu** : `renderConceptsTab()` génère un `<details class="ds-card">`
repliable par concept (résumé + image + texte), plus une carte finale pour
le tableau récapitulatif « comment ces 15 outils travaillent ensemble ».
Appelé une seule fois au chargement (contenu statique, pas de
recalcul) — même patron que `initTelemetry()`/`initFeedbackWidget()`.
Nouvel onglet ajouté à la grille déjà existante de Réglages (« Valeur
personnalisée » / « Technique » / **Concepts**) via le mécanisme générique
`switchSettingsTab()` déjà en place (T8, 6/9/2026) — aucune modification
de ce mécanisme nécessaire.

**Vérifié visuellement** (serveur statique temporaire, 4700 occupé par une
autre session) : les 15 fiches se déplient correctement, les 15 images se
chargent, le tableau récapitulatif et l'avertissement final s'affichent en
bas de l'onglet, aucune erreur console liée au contenu (les 404 observés
viennent des routes `/api/*` absentes sur ce serveur statique, sans
rapport).

## Paquet téléchargeable self-install (6/9/2026)

JP veut donner accès à castellana à Louis et Guillaume sans passer par un
accès collaborateur GitHub privé — un lien de téléchargement direct sur
iecho.ca (voir aussi la Partie B de ce changement dans `iecho.ca/CLAUDE.md`).
Décisions confirmées par JP : (1) le sidecar Python est **inclus** dans
l'installation automatique, pas seulement Node ; (2) le lien est protégé
par un mot de passe simple (« tomate »), pas un accès restreint par compte
GitHub — voir la fiche iecho.ca pour le détail du mécanisme de mot de
passe.

**Castellana n'est pas une page statique** — Express + `better-sqlite3`
(module natif) + sidecar Python optionnel. Un « lien téléchargeable » veut
donc dire un zip du code source + des scripts de lancement par OS qui
font l'installation eux-mêmes au premier double-clic — pas un simple
fichier statique comme les démos autonomes de porto.

**Livré** :
- [`demarrer.command`](demarrer.command) (macOS) et
  [`demarrer.bat`](demarrer.bat) (Windows), calqués sur
  `devops-dashboard/demarrer.bat` (vérification Node, redirection vers
  nodejs.org) étendus avec la vérification/installation Python (sidecar
  optionnel — s'il est absent, castellana démarre quand même en mode
  dégradé, comportement déjà géré nativement par l'app). Réutilisent les
  mêmes conventions que `scripts/run-sidecar.mjs` déjà en place (nom du
  dossier `.venv-mcp`, `Scripts\` vs `bin/`, suffixe `.exe`) — à ne pas
  faire diverger si l'un des deux change.
- [`scripts/package-zip.sh`](scripts/package-zip.sh) (`npm run package`) —
  construit `castellana.zip` à la racine, excluant tout ce qui est dans
  `.gitignore` plus `.git/`. **Bug réel trouvé en testant** : le premier
  jet incluait aussi `.claude/settings.local.json` et
  `.claude/scheduled_tasks.lock` (état interne de session Claude Code,
  non suivi par git mais pas non plus dans `.gitignore` de ce repo) — ces
  fichiers n'ont rien à faire dans un paquet destiné à des testeurs,
  exclusions ajoutées explicitement dans `package-zip.sh`. `*.zip` ajouté
  à `.gitignore` (l'archive elle-même ne se committe jamais ici).
- `SETUP.md` — encart en haut renvoyant vers le double-clic comme
  alternative au clonage manuel, avec l'avertissement Gatekeeper (voir
  ci-dessous).

**Process de mise à jour du zip — volontairement manuel, pas de CI** :
`npm run package` dans `trading-assistant/`, copier `castellana.zip` vers
`iecho.ca/public/telechargements/castellana.zip`, committer+pousser
`iecho.ca` pour redéployer. Rien n'automatise cette étape — si le code de
castellana change, le zip existant sur iecho.ca devient périmé jusqu'à la
prochaine reconstruction manuelle.

**⚠️ Limite réelle non résolue — Gatekeeper macOS** : un script `.command`
téléchargé depuis un navigateur reçoit l'attribut `com.apple.quarantine`.
Sans signature Apple Developer (hors scope), macOS peut refuser de
l'exécuter au double-clic ou afficher « développeur non identifié ».
Mitigation documentée dans `SETUP.md` (clic droit → Ouvrir la première
fois), mais **jamais testée avec un vrai téléchargement navigateur** dans
cette session — impossible à reproduire ici (pas de vrai flux HTTP de
téléchargement + Gatekeeper). À vérifier par JP avant de considérer le
flux "sans friction" pour Louis/Guillaume.

**Vérifié en direct cette session** :
- `npm run package` → `castellana.zip` de 3.1 Mo, confirmé sans
  `node_modules`/`data`/`.venv-mcp`/`.git`/`.claude/settings.local.json`
  (via `unzip -l`).
- Permission d'exécution de `demarrer.command` confirmée survivre à un
  aller-retour zip/dézip sur cette machine (`-rwxr-xr-x` après `unzip`).
- **`demarrer.command` exécuté pour de vrai** dans une copie dézippée
  isolée (`/tmp`, sans `node_modules`/`.venv-mcp` préexistants) :
  détection Node ✅, détection Python 3 ✅, déclenchement correct de
  `npm install` (absent au départ). L'installation a échoué sur cette
  machine précise à cause du **bug de cache npm root-owned déjà documenté**
  dans le `CLAUDE.md` racine (`EACCES`, historique à cette machine, pas un
  bug du script) — le script a géré l'échec proprement (message clair
  pointant vers `SETUP.md`, pas de plantage silencieux, pas de port
  démarré donc aucun conflit avec l'instance castellana d'une autre
  session déjà active sur 4700/4701). **La suite du flux (installation du
  sidecar, démarrage réel des serveurs, ouverture du navigateur) n'a pas
  pu être testée de bout en bout** à cause de ce blocage local — à
  reprendre sur une machine sans ce problème de cache, ou après
  `sudo chown -R 501:20 "~/.npm"` sur celle-ci.
- `demarrer.bat` : **non testé sur une vraie machine Windows** — vérifié
  par lecture de code et cohérence avec `scripts/run-sidecar.mjs`
  uniquement, même limite déjà documentée pour ce dernier avant sa
  correction (voir plus haut dans ce fichier).
- 2026-09-07 : tableau de bord de télémétrie enrichi (voir section
  « Télémétrie testeurs » plus haut) — activité par jour, tickers les plus
  sélectionnés, filtre par testeur + plage de jours, sur la route
  `/dashboard` déjà déployée (Artifact Claude écarté : pare-feu réseau
  bloque le `fetch()` externe nécessaire). Skill `dataviz` consultée avant
  d'écrire le SVG. **Vraie télémétrie découverte dans la base pendant les
  tests** (JP avait utilisé castellana réellement) — nettoyage ciblé
  (`WHERE id >= 9`) pour préserver ces 7 événements réels plutôt qu'un
  nettoyage global destructeur. Vérifié en direct dans le navigateur :
  filtre par testeur (état vide correct sur « inconnu »), info-bulles au
  survol sur les deux graphiques, aucune erreur console. Redéployé,
  URL du Worker inchangée.

## Séparation La Roue / Debit Spreads (7/9/2026)

JP a demandé de séparer les 2 stratégies « La Roue & Debit Spreads »
(fusionnées en une seule entrée du sélecteur depuis le 5/9/2026, voir
section « Onglet Labo » plus haut) en deux entrées distinctes.

**Pur réarrangement, aucun nouveau calcul introduit** : `roue-debit-spreads`
(une entrée `STRATEGIES_LABO`) devient `roue` (Cash-Secured Put → Covered
Call, étapes 1-3 + règles de sortie de l'ancienne séquence) et
`debit-spreads` (Bull Call Spread / Bear Put Spread, ex-étape 4 de
l'ancienne séquence, + ses propres règles de sortie adaptées — un spread a
un risque déjà limité au montant payé, donc pas de « rouler » comme pour
un Put/Call vendu seul). Même texte, mêmes chiffres, juste réorganisés en
deux séquences pédagogiques complètes plutôt qu'une seule qui mélangeait
deux techniques différentes.

**Un choix explicite plutôt que deviné** : `debit-spreads` a besoin de sa
propre jambe vendue calculée par Black-Scholes pour son panneau « Comment
ces prix sont calculés » (avant, l'étape 4 de l'ancienne séquence
réutilisait simplement les zones déjà calculées pour le Put/Call vendu de
La Roue). Plutôt que d'inventer un Delta cible propre aux spreads (non
fourni par `strategy/PoorManCoveredCall.md.rtf`, qui ne détaille pas cette
partie), `debit-spreads` recalcule sa jambe vendue avec **exactement la
même formule et les mêmes bornes de Delta** (`cfg.put`/`cfg.call` de
`config.js`) que La Roue — documenté explicitement en commentaire dans le
code pour que ce choix ne soit pas pris pour un oubli. La jambe achetée
reste "proche du prix" en texte, comme dans le fichier source, sans zone
Black-Scholes calculée (aucun Delta cible fourni pour elle non plus).

**Fichier touché** : `js/strategies-labo.js` uniquement — le sélecteur de
`index.html` génère ses options dynamiquement depuis `STRATEGIES_LABO`
(`initLaboStrategies()`), donc aucune modification de `index.html`
n'était nécessaire pour que les 2 nouvelles entrées apparaissent.

**Vérifié en direct** (serveur castellana réel relancé, sidecar actif,
données réelles AMD) : le sélecteur liste bien 5 stratégies (`La Roue
(Wheel Strategy)`, `Debit Spreads (Bull Call / Bear Put)`, `Poor Man's
Covered Call (PMCC)`, 2× « bientôt disponible ») ; bascule entre `roue` et
`debit-spreads` → deux séquences indépendantes et complètes, mêmes zones
de strike (387,15$–421,16$ pour la jambe Put, 576,43$–627,07$ pour la
jambe Call) cohérentes entre les deux puisqu'elles réutilisent
délibérément la même formule ; `pmcc` non affecté par le changement.
Aucune erreur console à aucune étape. Serveur arrêté après vérification —
rien ne tourne en arrière-plan.

## Checklist portfolio restante (voir `CLAUDE.md` racine, section
« Checklist — ajouter un nouveau produit »)

- [x] Créer le repo Git dédié + repo GitHub sous `iechocreator-po` (22/7/2026
  — [iechocreator-po/trading-assistant](https://github.com/iechocreator-po/trading-assistant), privé).
- [x] Ajouter `castellana` à la table sommaire et écrire sa fiche détaillée
  dans `2000_DigitalProducts/CLAUDE.md` (22/7/2026).
- [x] Ajouter `castellana → trading-assistant/` au mapping code→dossier
  (table « Dossier local » du `CLAUDE.md` racine, lu par bilbao) (22/7/2026)
  — bilbao peut désormais suivre ses features/releases une fois une première
  session de travail avec lui déclenchée.
- [x] Ajouter `trading-assistant` à `REPOS` dans
  `~/.claude/scripts/portfolio-checkin.sh` (22/7/2026).
- [x] Une fois un `bilbao.features.json` généré via la Console de bilbao,
  mettre à jour la section « Démarrage de session » de ce fichier pour lire
  `feature-factory/data/castellana/features.json` (même patron que madrid)
  (2026-07-25 — section « Démarrage de session — features en attente » ajoutée
  en haut du fichier ; `feature-factory/data/castellana/features.json` existe
  et contient 5 features en attente).
