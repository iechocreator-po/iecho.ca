// Tests de la validation pure de server/option-trades.js. Le CRUD/les effets
// de bord (création/clôture liée au Journal actions) touchent la vraie base
// — vérifiés en direct (curl contre un serveur temporaire), même discipline
// que server/trades.js dans ce projet (pas de trades.test.js non plus).
import test from 'node:test';
import assert from 'node:assert/strict';
import { validateOptionTrade } from './option-trades.js';

const VALID = { type: 'put', ticker: 'AMD', compte: 'margin', strike: 100, echeance: '2026-10-16', prime_recue: 1.5, date_ouverture: '2026-09-22' };

test('une jambe valide ne produit aucune erreur', () => {
  assert.deepEqual(validateOptionTrade(VALID), []);
});

test('les champs requis manquent → erreurs explicites', () => {
  const errors = validateOptionTrade({});
  for (const f of ['type', 'ticker', 'compte', 'strike', 'echeance', 'prime_recue', 'date_ouverture']) {
    assert.ok(errors.some((e) => e.startsWith(f)), `${f} devrait être signalé manquant`);
  }
});

test('type/compte hors énumération sont refusés', () => {
  assert.ok(validateOptionTrade({ ...VALID, type: 'stock' }).length > 0);
  assert.ok(validateOptionTrade({ ...VALID, compte: 'CELI' }).length > 0);
});

test('strike doit être positif, prime_recue peut être 0 mais pas négative', () => {
  assert.ok(validateOptionTrade({ ...VALID, strike: 0 }).length > 0);
  assert.ok(validateOptionTrade({ ...VALID, strike: -10 }).length > 0);
  assert.deepEqual(validateOptionTrade({ ...VALID, prime_recue: 0 }), []); // prime nulle réelle, valide
  assert.ok(validateOptionTrade({ ...VALID, prime_recue: -1 }).length > 0);
});

test('contrats doit être un entier positif quand fourni', () => {
  assert.deepEqual(validateOptionTrade({ ...VALID, contrats: 3 }), []);
  assert.ok(validateOptionTrade({ ...VALID, contrats: 0 }).length > 0);
  assert.ok(validateOptionTrade({ ...VALID, contrats: 1.5 }).length > 0);
});

test('mode partiel (mise à jour) : aucun champ requis, seules les énumérations sont vérifiées', () => {
  assert.deepEqual(validateOptionTrade({ notes: 'test' }, { partial: true }), []);
  assert.ok(validateOptionTrade({ type: 'invalide' }, { partial: true }).length > 0);
});
