// Votes et propositions de l'onglet Anticipation, par compte (12/10/2026, bilbao #418).
// Les règles (limite de votes, cartes closes, validation) sont dans lib/anticipation-logic.js.
import { CARDS } from '../lib/anticipation.js';
import { votesRemaining, checkVote, checkProposal, MAX_VOTES } from '../lib/anticipation-logic.js';

async function myVotedIds(db, userId) {
  const { results } = await db.prepare('SELECT card_id FROM anticipation_votes WHERE user_id = ?').bind(userId).all();
  return results.map((r) => r.card_id);
}

// Cartes + total de votes de chacune + ce que CE compte a voté. Aucun nom d'autre compte n'est exposé.
export async function getAnticipationState(db, userId) {
  const [{ results: counts }, mine] = await Promise.all([
    db.prepare('SELECT card_id, COUNT(*) AS n FROM anticipation_votes GROUP BY card_id').all(),
    myVotedIds(db, userId),
  ]);
  const byCard = Object.fromEntries(counts.map((r) => [r.card_id, r.n]));
  return {
    maxVotes: MAX_VOTES,
    remaining: votesRemaining(CARDS, mine),
    cards: CARDS.map((c) => ({
      id: c.id, featureId: c.featureId, titre: c.titre, description: c.description, onglet: c.onglet,
      statut: c.statut, date: c.date, votes: byCard[c.id] || 0, voted: mine.includes(c.id),
    })),
  };
}

export async function setVote(db, userId, cardId, on) {
  const mine = await myVotedIds(db, userId);
  const check = checkVote(CARDS, mine, cardId, on);
  if (!check.ok) throw Object.assign(new Error(check.error), { code: check.code });
  if (!check.noop) {
    if (on) await db.prepare('INSERT OR IGNORE INTO anticipation_votes (user_id, card_id) VALUES (?, ?)').bind(userId, cardId).run();
    else await db.prepare('DELETE FROM anticipation_votes WHERE user_id = ? AND card_id = ?').bind(userId, cardId).run();
  }
  return getAnticipationState(db, userId);
}

export async function addProposal(db, userId, body) {
  const recent = await db.prepare(
    "SELECT COUNT(*) AS n FROM anticipation_proposals WHERE user_id = ? AND created_at >= datetime('now', '-1 day')",
  ).bind(userId).first();
  const check = checkProposal(body, recent?.n ?? 0);
  if (!check.ok) throw Object.assign(new Error(check.error), { code: 'BAD_INPUT' });
  const { titre, onglet, description } = check.value;
  const r = await db.prepare('INSERT INTO anticipation_proposals (user_id, titre, onglet, description) VALUES (?, ?, ?, ?)')
    .bind(userId, titre, onglet, description).run();
  return { id: r.meta?.last_row_id ?? null, titre, onglet, statut: 'nouvelle' };
}

export async function listMyProposals(db, userId) {
  const { results } = await db.prepare(
    'SELECT id, titre, onglet, statut, created_at FROM anticipation_proposals WHERE user_id = ? ORDER BY id DESC LIMIT 50',
  ).bind(userId).all();
  return results;
}

// Vue d'administration (bilbao) : toutes les propositions avec le nom du compte, et les votes par carte.
export async function listAnticipationAdmin(db) {
  const [{ results: proposals }, { results: votes }] = await Promise.all([
    db.prepare(`SELECT p.id, u.username, p.titre, p.onglet, p.description, p.statut, p.created_at
                FROM anticipation_proposals p JOIN users u ON u.id = p.user_id ORDER BY p.id DESC`).all(),
    db.prepare(`SELECT v.card_id, u.username, v.created_at FROM anticipation_votes v
                JOIN users u ON u.id = v.user_id ORDER BY v.card_id, v.created_at`).all(),
  ]);
  return { cards: CARDS.map((c) => ({ id: c.id, featureId: c.featureId, titre: c.titre, statut: c.statut })), votes, proposals };
}
