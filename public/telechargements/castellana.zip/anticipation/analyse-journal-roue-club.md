# Journal de la Roue du club → castellana : analyse et plan d'intégration

## Contexte

Le club de trading de JP tient un Google Sheets « NOUVEAU TEMPLATE — Journal de la Roue »
(copie : `trading-assistant/anticipation/Copie de NOUVEAU TEMPLATE — Journal de la Roue.xlsx`).
Il contient un journal de trades, un rapport hebdo, un portfolio et un tableau de bord annuel, tous
centrés sur la Roue. castellana fait déjà une partie de ce travail : Journal & stats (D), Screener
Prime (G : cycles, bilan par cycle) et la carte « Revenu de primes réalisé » (E4, dans Option Lab).
Il faut décider ce qu'on garde, ce qu'on supprime, ce qu'on fusionne et ce qu'on améliore, des deux côtés.

Décisions de JP (13/10/2026) : **utilisé par JP et les membres du club, en cloud** (parité
local/cloud obligatoire) ; **nouvel onglet**, avec la liste explicite de ce qui devient redondant et
doit être supprimé ; **import de l'onglet JOURNAL** du Sheets.

---

## 1. Ce que fait le Sheets (analyse des formules)

| Onglet | Rôle | Calculs clés (relus dans les formules) |
|---|---|---|
| JOURNAL (25 col.) | 1 ligne = 1 transaction. Types PUT, CALL, **ACHAT**, **VENTE** (actions en direct) | Premium = prix×qté×100 ; P/L net = (prime − rachat)×100×qté − commission + dividendes ; rendement annualisé = P/L ÷ (strike×100×qté) × 365/jours ; **assignation déduite** : PUT assigné si clôture à l'échéance < strike (GOOGLEFINANCE) ; ID cycle = ticker + date de début ; coût moyen = (coût d'assignation − crédits) ÷ actions |
| RAPPORT HEBDO | 1 ligne par semaine (sélectionnée à la main dans le Journal) | profit net, ROI hebdo = profit ÷ (valeur précédente + dépôts), nb trades, nb et % d'assignations, capital utilisé, commissions, dividendes, **autres revenus**, **dépôts/retraits** (seule saisie), valeur du compte (réévalue les actions détenues au cours de la semaine), primes cumulées |
| PORTFOLIO | Positions assignées, générées automatiquement | quantité, prix d'achat, prix de revient, P/L action, primes totales, P/L total, % annualisé ; résumé : capital de départ, total, **immobilisé**, **disponible** ; convertisseur CAD→USD ; **calculateur « prix maximum par titre »** (capital × % max, n moyennes à la baisse de x %) |
| DASHBOARD ANNUEL | 12 indicateurs + 5 graphiques | capital actuel, profit réalisé, **profit réel ajusté** (retire le gain plafonné des calls dans la monnaie), rendement composé (produit des 1+r hebdo), taux de succès, taux d'assignation, pertes latentes, dividendes, rendement annualisé projeté ; profit mensuel ; répartition par ticker et par secteur ; courbe du compte |
| Semaines, Secteurs, Instructions | tables de référence | 52 semaines 2026 en dur ; secteur tiré de stockanalysis.com par IMPORTHTML |

### Défauts relevés dans le Sheets (à ne pas reproduire)
1. **Assignation devinée** par la clôture à l'échéance : rate l'assignation anticipée, le cas clôture = strike, et dépend de GOOGLEFINANCE. castellana la fait déclarer, c'est plus juste.
2. **Pas de « roulé »** : un roll = un rachat + une nouvelle ligne sans lien entre les deux.
3. **Commission à l'ouverture seulement** ; celle du rachat se perd.
4. **Semaine choisie à la main** alors qu'elle se déduit de la date. La ligne d'exemple LULU est d'ailleurs incohérente (ouverture 26/12/2026, fermeture 02/01/2026, début de cycle 06/06/2026) : rien ne valide les dates.
5. **Instructions décalées** : une colonne « Earnings » a été insérée en K, le guide décrit toujours Premium en K, Rachat en L, Dividendes en M (réellement L, M, N) ; Dépôts/Retraits annoncé en L, réellement N.
6. **Colonnes de débogage oubliées** (PORTFOLIO AB à AK, qui détournent `MIRR`, une fonction financière, comme une fonction de texte).
7. **Une seule année, un seul compte, USD seulement** : table Semaines 2026 en dur, conversion CAD manuelle.
8. Valeur du compte recalculée par un appel historique GOOGLEFINANCE par position et par semaine : lent et fragile.

### Bonnes idées du Sheets que castellana n'a pas
Commissions, dividendes, achat/vente d'actions **hors option** rattachés à un cycle, capital de départ +
dépôts/retraits → valeur du compte, capital immobilisé et disponible, rapport hebdo, tableau annuel
(profit réel ajusté, rendement composé, taux de succès et d'assignation), répartition par ticker et
par secteur, calculateur de prix maximum par titre.

---

## 2. Comparaison avec castellana

| Besoin | Sheets | castellana aujourd'hui | Verdict |
|---|---|---|---|
| Jambes put/call, statuts | PUT/CALL, assignation déduite | `option_trades` : ouvert/expiré/assigné/**roulé**/racheté, delta et IV d'ouverture (`server/option-trades.js`, `cloud/src/db/option-trades.js`) | **Garder castellana** |
| Cycle | ID texte ticker+date | `option_cycles` (id, compte, statut) | **Garder castellana** |
| Assignation → actions | onglet PORTFOLIO calculé | `closeOptionTrade()` crée/clôture une ligne `trades` (Journal actions) | **Garder**, mais l'**afficher** dans le nouvel onglet |
| Bilan par cycle | PORTFOLIO (coût de revient, P/L total, % annualisé) | `optCycleBilan()` (`js/options-analytics.js:159`) : primes nettes, coût de base, rendement, annualisé à partir de 30 j, **comparaison à la détention** | **Garder castellana**, ajouter commissions + dividendes |
| Commissions, dividendes | oui | non | **Ajouter** |
| ACHAT/VENTE d'actions hors option | oui | possible dans Journal & stats mais sans lien au cycle | **Ajouter** (jambe de type action, liée au cycle) |
| Capital, dépôts/retraits, valeur du compte | oui | non (la tuile « Trésorerie » concerne le bilan des entreprises) | **Ajouter**, par compte |
| Rapport hebdo | oui | non | **Ajouter**, semaine dérivée de la date |
| Tableau annuel | oui | E4 « Revenu de primes réalisé » (partiel) | **Fusionner** E4 dans le tableau annuel |
| Prix maximum par titre | calculateur | maquette Anticipation #422 « Plan de match » (non construite) | **Fusionner** : la formule du Sheets alimente #422 |
| Coût moyen après assignation | coût moyen par action | maquette #423 « Position assignée en perte » | **Fusionner** : réutiliser `coutDeBase` de `optCycleBilan` |
| Secteur | IMPORTHTML (scraping) | secteur Yahoo déjà présent (`server/fundamentals.js`, `server/sectors.js`) | **Ne pas reprendre** la table Secteurs du Sheets |
| CAD→USD | convertisseur | — | **Améliorer** : devise par compte (USD par défaut), sans convertisseur dans un premier temps |
| Screener, calculateur de vente, alertes | — | Screener Prime G1-G4 | **Garder** dans Screener Prime |

---

## 3. Nouvel onglet « Roue » et liste de ce qui devient redondant

Screener Prime reste l'onglet **de recherche** ; le nouvel onglet **Roue** devient celui **du suivi**.
Derrière un drapeau par compte `roue_tab` (OFF par défaut, surchargeable depuis bilbao, même patron que
`journal_a_tab`), placé juste après Screener Prime pour ne pas décaler les lettres A à G.

Cartes de l'onglet Roue (lettre H) :
1. **Comptes et capital** : capital de départ, dépôts/retraits datés, devise ; capital total, immobilisé, disponible.
2. **Journal des jambes** : tableau de toutes les jambes (options + actions liées), colonnes du Sheets (prime, commission, rachat, dividendes, P/L net, rendement annualisé, jours, capital immobilisé), saisie et clôture.
3. **Positions de la Roue** (= PORTFOLIO) : cycles actifs avec actions détenues, coût de base, cours actuel, P/L action, primes, P/L total.
4. **Bilan par cycle** : déplacé tel quel depuis Screener Prime.
5. **Rapport hebdo** : une ligne par semaine (lundi-dimanche, depuis la date de clôture), mêmes colonnes que le Sheets.
6. **Tableau annuel** : les indicateurs du Dashboard + profit mensuel + répartition par ticker et par secteur, sélecteur d'année (graphiques SVG faits main, comme ailleurs dans castellana).
7. **Import du Sheets** : fichier XLSX/CSV, aperçu, confirmation.

**Aucune section existante n'est supprimée dans ce chantier** (consigne de JP). À la place :

- Chaque section existante concernée reçoit **une ligne d'état** visible en tête de carte (petit texte
  `ds-text-hint`, même style que les numéros « (#378) » déjà affichés), de l'une de deux formes :
  - « Améliorée : voir H4 — Bilan par cycle (commissions et dividendes inclus). »
  - « Visée pour suppression : <raison>. Remplacée par H… Voir feature bilbao #… »
- Chaque section visée pour suppression a **sa propre feature bilbao** (statut `Idee`), créée par
  l'API, qui décrit la suppression et sa raison. La suppression elle-même est une décision ultérieure de JP.

| Section existante | Ligne d'état | Feature bilbao |
|---|---|---|
| G — « Cycles & positions ouvertes » (#5) | **Visée pour suppression** : doublon de H2 (journal des jambes) et H3 (positions), qui ajoutent commissions, dividendes et actions hors option. | 1 feature « Retirer G Cycles & positions ouvertes » |
| G — « Bilan de la Roue par cycle » (#378) | **Visée pour suppression** : même bilan affiché en H4, enrichi des commissions et dividendes (même fonction `optCycleBilan`). | 1 feature « Retirer G Bilan par cycle » |
| E4 — « Revenu de primes réalisé » (Option Lab) | **Visée pour suppression** : chiffres repris et détaillés par H6 (tableau annuel). | 1 feature « Retirer E4 Revenu de primes réalisé » |
| G — Calculateur « Vendre une option » (#4) | **Améliorée** : enregistre aussi la commission ; la jambe apparaît dans H2. | — |
| G — Screener de primes, alertes de roulement, alertes de positions | Inchangées (recherche et surveillance, pas du suivi). Pas de ligne. | — |
| D — Journal & stats | **Améliorée** : les positions issues d'une assignation renvoient vers leur cycle dans H3. Reste le journal du swing trading. | — |
| Maquettes Anticipation #422 et #423 | Notées « formule reprise du Journal de la Roue du club » dans `cards.json`. | — |

Les lignes d'état sont écrites dans le HTML de chaque carte (pas une table JS), dans la même étape que
la section H qui les remplace ou les améliore, pour qu'une ligne ne pointe jamais vers une section qui
n'existe pas encore.

---

## 4. Modèle de données (local SQLite + D1, migrations additives)

- `option_trades` : + `commission_ouverture REAL`, `commission_cloture REAL`, `dividendes REAL`, `roule_vers_id INTEGER` (lien vers la jambe ouverte par le roll), `source TEXT` ('saisie' | 'import_sheets').
  Le CHECK de `type` passe à `('put','call','achat','vente')` : reconstruction de table sur le patron
  déjà utilisé dans castellana (local) ; côté D1 via un script de migration comme `migrate-anticipation.mjs`.
  Pour achat/vente : `strike` = prix par action, `prime_recue` = 0, `contrats` = nombre de lots de 100
  (même convention que le Sheets, pour que l'import tombe juste).
- Nouvelle table `cash_flows` (user_id en cloud) : `compte`, `date`, `montant` (+ dépôt, − retrait), `type` ('depart','depot','retrait','autre_revenu'), `notes`.
- Nouvelle table `account_settings` (ou une clé de `preferences`) : devise par compte.
- Rien n'est jamais déduit en silence : un cours indisponible donne « N/D », jamais 0 (règle du portfolio).

## 5. Calculs (purs, partagés, testés)

Ajouter dans `js/options-analytics.js` (déjà chargé côté navigateur et réexporté par `server/options-analytics.js`) :
- `optLegPnl(leg)` : P/L net d'une jambe, avec commissions et dividendes.
- `optCycleBilan` : y intégrer commissions, dividendes et jambes achat/vente (modifier, pas dupliquer).
- `optWeeklyReport(legs, cashFlows, { weekStart })` : colonnes du rapport hebdo.
- `optAnnualDashboard(legs, cashFlows, positions, prices, year)` : indicateurs annuels, dont « profit réel ajusté » (gain au-dessus du strike d'un call ouvert dans la monnaie retiré) et rendement composé.
- `optMaxPricePerTicker({ capital, pctMax, nbAverage, pctBaisse })` : formule du Sheets (`C32` : capital × % × baisse ÷ (100 × (1 − (1 − baisse)^(n+1))))), pour #422.
Chaque fonction a ses tests (`server/*.test.js`), dont un **cas recalculé à partir des formules du Sheets** pour vérifier qu'on retombe sur les mêmes chiffres.

## 6. Import du Sheets

- Lecture de l'onglet JOURNAL (XLSX via une petite dépendance de lecture, ou CSV exporté de Google Sheets en repli) **dans le navigateur**, pour que le même code serve en local et en cloud.
- Correspondances : PUT/CALL/ACHAT/VENTE → `type` ; regroupement par la colonne « ID cycle » → un `option_cycles` par ID ; statut déduit (Rachat rempli → racheté ; « Assigné » = OUI → assigné ; échéance passée sinon → expiré ; sinon ouvert), **chaque statut déduit affiché dans l'aperçu, modifiable avant import**.
- Lignes incohérentes signalées, pas corrigées (ex. fermeture avant ouverture, comme la ligne LULU).
- Compte demandé à l'import (le Sheets n'en a pas). Dépôts/retraits lus dans RAPPORT HEBDO col. N, capital de départ dans PORTFOLIO C9.
- Ré-import idempotent : clé = ticker + type + strike + date + échéance ; jamais d'écrasement d'une ligne saisie dans castellana.

## 7. Étapes de livraison (une feature bilbao par étape)

1. Schéma + calculs purs + tests (local et cloud).
2. Onglet Roue : cartes H1 à H4 (comptes, journal, positions, bilan déplacé), derrière `roue_tab`.
3. H5 rapport hebdo + H6 tableau annuel.
4. H7 import du Sheets, testé sur la copie XLSX fournie.
5. Lignes d'état sur les sections existantes (au fil des étapes 2 à 4) + 3 features bilbao « Retirer … » + note dans `cards.json` pour #422/#423. **Aucune suppression.**
6. Déploiement cloud, activation du drapeau pour le compte de JP, puis pour les membres du club.

Features créées dans bilbao par son API (`POST /api/feedbacks`, produit `castellana`), jamais à la main :
une par étape de livraison, plus les 3 features de suppression du tableau de la section 3.

## Fichiers principaux

- `trading-assistant/server/db.js`, `cloud/schema.sql`, `cloud/scripts/` (nouvelle migration)
- `trading-assistant/server/option-trades.js`, `cloud/src/db/option-trades.js`, `cloud/src/routes/option-trades.js`
- `trading-assistant/js/options-analytics.js` (+ `server/options-analytics.js`), `server/cycle-bilan.js`
- nouveau `trading-assistant/js/roue-tab.js` ; `js/journal-a-tab.js` (lignes d'état seulement) ; `index.html` (onglet, section, lignes d'état)
- `trading-assistant/anticipation/cards.json` (statuts #422/#423)
- `trading-assistant/CLAUDE.md`

## Vérification

- `npm test` dans `trading-assistant` : nouveaux tests + les 293 existants verts.
- Cas de référence : ressaisir 3 ou 4 lignes du Sheets (dont la ligne LULU corrigée) et comparer P/L net, rendement annualisé, coût moyen et rapport hebdo aux valeurs calculées par les formules du Sheets.
- Import de la copie XLSX : aperçu, import, ré-import sans doublon.
- Navigateur (local `npm start`, puis cloud `wrangler dev --local` sur D1 jetable) : saisie d'un cycle complet put → assigné → call → assigné, avec commissions et dividendes ; vérifier H2 à H6 et l'absence d'erreur console.
- Après l'étape 5 : toutes les sections existantes toujours présentes et fonctionnelles, chacune avec sa ligne d'état ; repères A à G inchangés (aucune carte retirée) ; les 3 features « Retirer … » visibles dans `feature-factory/data/castellana/features.json`.
