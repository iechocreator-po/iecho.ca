// js/roue-tab.js — onglet « Roue » (13/10/2026, bilbao #434, flag roue_tab, défaut OFF) : le journal
// de la Roue repris du Google Sheets du club (analyse : anticipation/analyse-journal-roue-club.md).
// Repères réels (dérivés du DOM, js/ui-ids.js) : H1 = « À propos », puis
//   H2 Semaine              : options de la semaine choisie (‹ ›), distance au strike, résultats,
//                            positions assignées (coût de base net), semaine suivante, à surveiller (#443).
//   H3 Tableau de bord annuel : valeur réalisée vs apports + primes, dénouement expirée / rachetée /
//                            assignée, primes par mois, titre et secteur, positions, capital (#444).
//   H4 Comptes et capital  : capital de départ, dépôts, retraits, dividendes, autres revenus ;
//                            capital immobilisé et disponible (optAccountSnapshot).
//   H5 Journal des positions : toutes les jambes d'options du compte, avec commissions, P/L net,
//                            rendement annualisé (optLegReturn) ; saisie, clôture, roulement lié.
//   H6 Positions de la Roue : actions détenues par cycle, coût moyen net, cours, P/L total.
//   H7 Bilan par cycle      : bilan de la Roue par cycle, avec frais et dividendes (le bilan de Screener Prime a été retiré, #440).
//   H8 Rapport hebdo        : une ligne par semaine (optWeeklyReport), comme RAPPORT HEBDO du Sheets.
//   H9 Import du Sheets    : .xlsx ou .csv du club, aperçu modifiable, stops par cycle (#436) ;
//                            lecture et plan dans js/roue-import.js, exécution ici (appels à l'API).
// Tous les calculs sont dans js/options-analytics.js (testés, recoupés avec le Sheets) ; ce fichier
// ne fait que charger, filtrer par compte et afficher. Règle du portfolio : une donnée inconnue
// s'affiche « — » (N/D), jamais 0.

const ROUE_COMPTES = ['margin', 'RRSP', 'corporatif'];
const ROUE_FLOW_LABELS = { depart: 'Capital de départ', depot: 'Dépôt', retrait: 'Retrait', dividende: 'Dividende', autre_revenu: 'Autre revenu' };
const ROUE_STATUT_LABELS = { ouvert: 'ouvert', expire: 'expiré', assigne: 'assigné', roule: 'roulé', rachete: 'racheté' };
const roueState = { compte: 'margin', cycles: [], legs: [], stock: [], flows: [], prices: {}, bilans: [], sectors: {}, earnings: {}, spy: null, weekStart: null, year: new Date().getFullYear(), selLegs: new Set(), selFlows: new Set(),
  // Filtre par compte de chaque carte H2, H3 et H5 à H8 ('tout' = tous les comptes), indépendant du compte de H4
  // (qui reste la destination des saisies et de l'import). Mémorisé par navigateur.
  filtres: { semaine: 'tout', annuel: 'tout', legs: 'tout', positions: 'tout', bilans: 'tout', weeks: 'tout' } };
try {
  const saved = JSON.parse(localStorage.getItem('castellana-roue-filtres') || '{}');
  for (const k of Object.keys(roueState.filtres)) if (['tout', ...ROUE_COMPTES].includes(saved[k])) roueState.filtres[k] = saved[k];
} catch { /* défauts */ }

function roueFilterHTML(key) {
  const v = roueState.filtres[key];
  return `<label class="metric-sub" style="display:flex; align-items:center; gap:6px;">Compte <select class="ds-select roue-filter" data-filter="${key}" style="width:auto;">${['tout', ...ROUE_COMPTES].map((c) => `<option value="${c}"${c === v ? ' selected' : ''}>${c === 'tout' ? 'Tout' : c}</option>`).join('')}</select></label>`;
}

function roueSize() { return typeof janlContractSize === 'function' ? janlContractSize() : 100; }
function roueToday() { return new Date().toISOString().slice(0, 10); }
function roueMoney(v, d = 2) {
  if (v == null || !Number.isFinite(v)) return '—';
  return v.toLocaleString('fr-CA', { minimumFractionDigits: d, maximumFractionDigits: d }) + ' $';
}
function rouePct(v, d = 1) { return v == null || !Number.isFinite(v) ? '—' : (v * 100).toFixed(d) + ' %'; }
function roueSignedPct(v, d = 1) { return v == null || !Number.isFinite(v) ? '—' : (v >= 0 ? '+' : '') + (v * 100).toFixed(d) + ' %'; }
function roueField(label, html) { return `<div class="field"><label>${label}</label>${html}</div>`; }
// Compte de destination d'une saisie ou d'un import : jamais « Tout ». Par défaut, celui choisi en H4.
function roueDefaultCompte() { return roueState.compte === 'tout' ? ROUE_COMPTES[0] : roueState.compte; }
function roueCompteSelect(id) { return `<select class="ds-select roue-dest" id="${id}">${ROUE_COMPTES.map((c) => `<option value="${c}">${c}</option>`).join('')}</select>`; }

// ---- Squelette ----

function roueShellHTML() {
  const comptes = ['tout', ...ROUE_COMPTES].map((c) => `<option value="${c}">${c === 'tout' ? 'Tout' : c}</option>`).join('');
  return `${roueWeekShellHTML()}${roueDashShellHTML()}
    <div class="ds-card">
      <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; flex-wrap:wrap; margin-bottom:0.5rem;">
        <div class="section-title" style="margin-bottom:0;">Comptes et capital</div>
        <label class="metric-sub" style="display:flex; align-items:center; gap:6px;">Compte <select class="ds-select" id="roue-compte" style="width:auto;">${comptes}</select></label>
      </div>
      <p class="metric-sub" style="text-align:left;">Le capital de départ et les dépôts/retraits viennent de cette carte ; les profits, des positions closes. Les actions sont comptées à leur coût d'achat dans la valeur réalisée, puis réévaluées au dernier cours dans la valeur du compte.</p>
      <div class="metric-band" id="roue-capital-metrics" style="--cols:7;"></div>
      <details class="roue-add" style="margin-top:0.75rem;">
        <summary class="ds-btn ds-btn--primary roue-add__btn"><span class="roue-add__open">＋ Ajouter un mouvement</span><span class="roue-add__close">− Fermer le formulaire</span></summary>
        <span class="metric-sub roue-add__hint">Capital de départ, dépôt, retrait, dividende ou autre revenu.</span>
        <div class="field-grid" style="margin-top:0.5rem;">
          ${roueField('Compte *', roueCompteSelect('roue-flow-compte'))}
          ${roueField('Type', `<select class="ds-select" id="roue-flow-type">${Object.entries(ROUE_FLOW_LABELS).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select>`)}
          ${roueField('Date', '<input class="ds-input" type="date" id="roue-flow-date">')}
          ${roueField('Montant ($, positif)', '<input class="ds-input" type="number" step="0.01" min="0" id="roue-flow-montant">')}
          ${roueField('Symbole (dividende)', '<input class="ds-input" type="text" id="roue-flow-ticker" style="text-transform:uppercase;">')}
          ${roueField('Cycle (dividende)', '<select class="ds-select" id="roue-flow-cycle"></select>')}
          ${roueField('Note', '<input class="ds-input" type="text" id="roue-flow-notes">')}
        </div>
        <div class="journal-actions"><button type="button" class="ds-btn ds-btn--primary" id="roue-flow-save">Ajouter</button><span class="metric-sub" id="roue-flow-status"></span></div>
      </details>
      <div class="metric-sub" style="text-align:left; font-weight:500; margin-top:0.75rem;">Par compte</div>
      <div id="roue-accounts-host"></div>
      <div class="metric-sub" style="text-align:left; font-weight:500; margin-top:0.75rem;">Mouvements</div>
      <div id="roue-flows-host"></div>
    </div>

    <div class="ds-card">
      <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; flex-wrap:wrap; margin-bottom:0.5rem;">
        <div class="section-title" style="margin-bottom:0;">Journal des positions</div>
        ${roueFilterHTML('legs')}
      </div>
      <p class="metric-sub" style="text-align:left;">Une ligne par option vendue. P/L net = (prime − rachat) × actions − commissions. Le rendement annualisé est calculé sur le strike, de l'ouverture à la clôture (ou à l'échéance) ; une ligne aux dates incohérentes est signalée ⚠ et n'a pas de rendement annualisé. Une position ouverte n'entre dans aucun profit réalisé.</p>
      <details class="roue-add">
        <summary class="ds-btn ds-btn--primary roue-add__btn"><span class="roue-add__open">＋ Saisir une position</span><span class="roue-add__close">− Fermer le formulaire</span></summary>
        <span class="metric-sub roue-add__hint">Une option vendue (put ou call), ouverte ou déjà close.</span>
        <div class="field-grid" style="margin-top:0.5rem;">
          ${roueField('Compte *', roueCompteSelect('roue-leg-compte'))}
          ${roueField('Symbole *', '<input class="ds-input" type="text" id="roue-leg-ticker" style="text-transform:uppercase;">')}
          ${roueField('Type *', '<select class="ds-select" id="roue-leg-type"><option value="put">put vendu</option><option value="call">call vendu</option></select>')}
          ${roueField('Cycle', '<select class="ds-select" id="roue-leg-cycle"></select>')}
          ${roueField('Strike *', '<input class="ds-input" type="number" step="0.01" id="roue-leg-strike">')}
          ${roueField('Contrats *', '<input class="ds-input" type="number" step="1" min="1" value="1" id="roue-leg-contrats">')}
          ${roueField('Prime / action *', '<input class="ds-input" type="number" step="0.01" min="0" id="roue-leg-prime">')}
          ${roueField('Commission ($)', '<input class="ds-input" type="number" step="0.01" min="0" id="roue-leg-commission">')}
          ${roueField('Ouverture *', '<input class="ds-input" type="date" id="roue-leg-ouverture">')}
          ${roueField('Échéance *', '<input class="ds-input" type="date" id="roue-leg-echeance">')}
        </div>
        <div class="journal-actions"><button type="button" class="ds-btn ds-btn--primary" id="roue-leg-save">Enregistrer</button><span class="metric-sub" id="roue-leg-status"></span></div>
      </details>
      <div id="roue-legs-host" style="margin-top:0.5rem;"><p class="ds-text-muted">Chargement…</p></div>
    </div>

    <div class="ds-card">
      <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:0.5rem;">
        <div class="section-title" style="margin-bottom:0;">Positions de la Roue</div>
        <span style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">${roueFilterHTML('positions')}<button type="button" class="ds-btn ds-btn--shine ds-btn--sm" id="roue-prices-refresh">Actualiser les cours</button></span>
      </div>
      <p class="metric-sub" style="text-align:left;">Les actions détenues après une assignation, cycle par cycle. Coût moyen net = prix d'achat moins les primes nettes de frais et les dividendes du cycle, par action : tant que le cours reste au-dessus, la Roue est gagnante sur ce titre.</p>
      <div id="roue-positions-host"><p class="ds-text-muted">Chargement…</p></div>
    </div>

    <div class="ds-card">
      <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:0.5rem;">
        <div class="section-title" style="margin-bottom:0;">Bilan par cycle</div>
        <span style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">${roueFilterHTML('bilans')}<button type="button" class="ds-btn ds-btn--shine ds-btn--sm" id="roue-bilan-refresh">Actualiser</button></span>
      </div>
      <p class="metric-sub" style="text-align:left;">Résultat net = primes nettes − commissions + dividendes + action (réalisée et latente). La comparaison à la simple détention du titre reste <strong>sans</strong> frais ni dividendes, des deux côtés, pour comparer sur la même base. Annualisé seulement à partir de 30 jours.</p>
      <div id="roue-bilan-host"><p class="ds-text-muted">Chargement…</p></div>
    </div>

    <div class="ds-card">
      <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; flex-wrap:wrap; margin-bottom:0.5rem;">
        <div class="section-title" style="margin-bottom:0;">Rapport hebdo</div>
        <span style="display:flex; align-items:center; gap:12px; flex-wrap:wrap;">${roueFilterHTML('weeks')}<label class="metric-sub" style="display:flex; align-items:center; gap:6px;">Année <select class="ds-select roue-year" style="width:auto;"></select></label><button type="button" class="ds-btn ds-btn--pulse ds-btn--sm" onclick="openTableOverlay('roue-weeks-host','roue-weeks-anchor','Rapport hebdo')" title="Agrandir le tableau en plein écran">⤢ Agrandir</button></span>
      </div>
      <p class="metric-sub" style="text-align:left;">Semaine du dimanche au samedi ; une position compte dans la semaine de sa clôture (plus de semaine à choisir à la main). ROI hebdo = profit net ÷ (valeur de la semaine précédente + dépôts de la semaine), comme le Sheets. Profit net = options + actions revendues + dividendes, frais déduits ; les autres revenus entrent dans la valeur du compte, pas dans le profit.</p>
      <span id="roue-weeks-anchor"></span><div id="roue-weeks-host"><p class="ds-text-muted">Chargement…</p></div>
    </div>

    <div class="ds-card">
      <div class="section-title">Importer le Journal de la Roue du club</div>
      <p class="metric-sub" style="text-align:left;">Fichier <strong>.xlsx</strong> (Google Sheets → Fichier → Télécharger → Microsoft Excel) ou <strong>.csv</strong> de l'onglet JOURNAL. Rien n'est écrit avant « Importer ». Le statut de chaque option est <strong>déduit</strong> (rachat rempli, cours de clôture contre strike, échéance passée) : vérifie-le, il rate une assignation anticipée. Une ligne aux dates incohérentes est décochée ; une position déjà présente est ignorée. Choisis le compte de destination à côté du fichier.</p>
      <div class="journal-actions">
        <label class="metric-sub" style="display:inline-flex; align-items:center; gap:6px;">Compte de destination ${roueCompteSelect('roue-imp-compte')}</label>
        <input type="file" id="roue-imp-file" accept=".xlsx,.csv" class="ds-input" style="max-width:340px;">
        <span class="metric-sub" id="roue-imp-status"></span>
      </div>
      <div id="roue-imp-host"></div>
    </div>

    <dialog id="roue-close-dialog" style="max-width:560px; background:var(--surface); color:var(--text); border:1px solid var(--border); border-radius:12px; padding:1rem 1.25rem;">
      <form method="dialog" id="roue-close-form">
        <div class="section-title" id="roue-close-title">Clôturer</div>
        <div class="field-grid">
          ${roueField('Dénouement', `<select class="ds-select" id="roue-close-statut">${['expire', 'assigne', 'rachete', 'roule'].map((s) => `<option value="${s}">${ROUE_STATUT_LABELS[s]}</option>`).join('')}</select>`)}
          ${roueField('Date', '<input class="ds-input" type="date" id="roue-close-date">')}
          ${roueField('Prime de rachat / action', '<input class="ds-input" type="number" step="0.01" min="0" id="roue-close-prime">')}
          ${roueField('Commission de clôture ($)', '<input class="ds-input" type="number" step="0.01" min="0" id="roue-close-commission">')}
          <div class="field" id="roue-close-stop-wrap">${'<label>Stop initial de l\'action *</label><input class="ds-input" type="number" step="0.01" id="roue-close-stop">'}</div>
        </div>
        <div id="roue-close-roll" style="margin-top:0.5rem;">
          <p class="metric-sub" style="text-align:left;">Nouvelle position qui remplace celle-ci (même cycle, ouverte à la date de clôture) :</p>
          <div class="field-grid">
            ${roueField('Strike *', '<input class="ds-input" type="number" step="0.01" id="roue-roll-strike">')}
            ${roueField('Échéance *', '<input class="ds-input" type="date" id="roue-roll-echeance">')}
            ${roueField('Prime / action *', '<input class="ds-input" type="number" step="0.01" min="0" id="roue-roll-prime">')}
            ${roueField('Commission ($)', '<input class="ds-input" type="number" step="0.01" min="0" id="roue-roll-commission">')}
          </div>
        </div>
        <p class="metric-sub" id="roue-close-status" style="text-align:left;"></p>
        <div class="journal-actions">
          <button type="button" class="ds-btn ds-btn--primary" id="roue-close-ok">Clôturer</button>
          <button type="button" class="ds-btn" id="roue-close-cancel">Annuler</button>
        </div>
      </form>
    </dialog>
  `;
}

// ---- Données ----

async function roueLoadData() {
  const [c, o, t, f] = await Promise.all([
    fetchJSON('/api/option-cycles'),
    fetchJSON('/api/option-trades'),
    fetchJSON('/api/trades'),
    fetchJSON('/api/cash-flows').catch(() => ({ cashFlows: [] })),
  ]);
  roueState.cycles = c.cycles || [];
  roueState.legs = o.trades || [];
  roueState.stock = (t.trades || []).filter((x) => x.option_cycle_id != null);
  roueState.flows = f.cashFlows || [];
}

// `k` = un compte, ou 'tout' (aucun filtre). Sans argument : le compte de H4.
function roueView(k = roueState.compte) {
  const tout = k === 'tout';
  const cycles = roueState.cycles.filter((c) => tout || c.compte === k);
  const cycleIds = new Set(cycles.map((c) => c.id));
  return {
    cycles,
    legs: roueState.legs.filter((l) => tout || l.compte === k),
    stock: roueState.stock.filter((s) => (tout || s.compte === k) && cycleIds.has(s.option_cycle_id)),
    flows: roueState.flows.filter((f) => tout || f.compte === k),
  };
}

async function roueLoadPrices() {
  const { stock, legs } = roueView('tout');
  const tickers = [...new Set([...stock.filter((s) => !s.date_sortie).map((s) => s.ticker), ...legs.filter((l) => l.statut === 'ouvert').map((l) => l.ticker)])];
  await Promise.all(tickers.map(async (tk) => {
    try { const q = await fetchJSON(`/api/quote/${encodeURIComponent(tk)}`); if (Number.isFinite(q.price)) roueState.prices[tk] = q.price; } catch { /* cours indisponible : N/D */ }
  }));
}

// ---- H4 Comptes et capital ----

function roueRenderCapital() {
  const { legs, stock, flows, cycles } = roueView();
  const snap = optAccountSnapshot({ legs, stockTrades: stock, cashFlows: flows, contractSize: roueSize(), prices: roueState.prices });
  const sum = (t) => flows.filter((f) => f.type === t).reduce((a, f) => a + Number(f.montant), 0);
  const metric = (label, value, sub = '') => `<div class="ds-metric"><div class="ds-metric__label">${label}</div><div class="ds-metric__value">${value}</div>${sub ? `<div class="ds-metric__sub">${sub}</div>` : ''}</div>`;
  const sansDepart = !flows.some((f) => f.type === 'depart');
  document.getElementById('roue-capital-metrics').innerHTML = [
    metric('Capital de départ', sansDepart ? '—' : roueMoney(sum('depart'), 0), sansDepart ? 'à saisir ci-dessous' : ''),
    metric('Dépôts − retraits', roueMoney(sum('depot') - sum('retrait'), 0)),
    metric('Valeur réalisée', roueMoney(snap.valeurRealisee, 0), 'actions au coût'),
    metric('Capital immobilisé', roueMoney(snap.capitalImmobilise, 0), `puts ${roueMoney(snap.capitalPuts, 0)} · actions ${roueMoney(snap.capitalActions, 0)}`),
    metric('Disponible', roueMoney(snap.capitalDisponible, 0)),
    metric('Latent des actions', roueMoney(snap.latentActions, 0), snap.latentConnu ? 'au dernier cours' : 'cours manquant'),
    metric('Valeur du compte', roueMoney(snap.valeurCompte, 0)),
  ].join('');

  roueRefreshFlowCycleOptions();
  roueRenderAccounts();

  const rows = [...flows].sort((a, b) => (a.date < b.date ? 1 : -1));
  roueKeepVisible(roueState.selFlows, rows);
  document.getElementById('roue-flows-host').innerHTML = rows.length
    ? `${roueSelBarHTML('flows', roueState.selFlows.size)}<div style="overflow-x:auto"><table class="ds-table"><thead><tr>${roueSelAllTH('flows', rows, roueState.selFlows)}<th>Date</th><th>Compte</th><th>Type</th><th class="is-num">Montant</th><th>Symbole</th><th>Cycle</th><th>Note</th></tr></thead><tbody>${rows.map((f) => `<tr>
        ${roueSelTD('flows', f.id, roueState.selFlows)}<td>${optEsc(f.date)}</td><td>${optEsc(f.compte)}</td><td>${optEsc(ROUE_FLOW_LABELS[f.type] || f.type)}</td>
        <td class="is-num">${f.type === 'retrait' ? '−' : ''}${roueMoney(Number(f.montant))}</td>
        <td>${optEsc(f.ticker || '')}</td><td>${f.cycle_id ? '#' + f.cycle_id : ''}</td><td>${optEsc(f.notes || '')}</td></tr>`).join('')}</tbody></table></div>`
    : '<p class="ds-text-muted">Aucun mouvement pour ce compte. Commence par le capital de départ : sans lui, la valeur du compte et les rendements restent « — ».</p>';
}

// Une ligne par compte (le compte choisi, ou avec « Tout » chaque compte qui a des données, plus le total).
// Un compte sans capital de départ garde sa valeur à « — » : on ne l'invente pas.
function roueRenderAccounts() {
  const tout = roueState.compte === 'tout';
  const has = (k) => { const v = roueView(k); return v.flows.length || v.legs.length || v.stock.length || v.cycles.length; };
  const comptes = tout ? ROUE_COMPTES.filter(has) : [roueState.compte];
  const row = (label, v, strong) => {
    const snap = optAccountSnapshot({ legs: v.legs, stockTrades: v.stock, cashFlows: v.flows, contractSize: roueSize(), prices: roueState.prices });
    const sum = (t) => v.flows.filter((f) => f.type === t).reduce((a, f) => a + Number(f.montant), 0);
    const depart = v.flows.some((f) => f.type === 'depart');
    const ouvertes = v.legs.filter((l) => l.statut === 'ouvert').length;
    const td = (x) => `<td class="is-num">${strong ? `<strong>${x}</strong>` : x}</td>`;
    return `<tr><td>${strong ? `<strong>${optEsc(label)}</strong>` : optEsc(label)}</td>
      ${td(depart ? roueMoney(sum('depart'), 0) : '<span class="ds-text-hint" title="capital de départ à saisir ci-dessus">—</span>')}
      ${td(roueMoney(sum('depot') - sum('retrait'), 0))}${td(String(ouvertes))}${td(String(v.stock.filter((x) => !x.date_sortie).length))}
      ${td(roueMoney(snap.valeurRealisee, 0))}${td(roueMoney(snap.capitalImmobilise, 0))}${td(roueMoney(snap.capitalDisponible, 0))}${td(roueMoney(snap.valeurCompte, 0))}</tr>`;
  };
  const rows = comptes.map((k) => row(k, roueView(k), false));
  if (tout && comptes.length > 1) rows.push(row('Total', roueView('tout'), true));
  document.getElementById('roue-accounts-host').innerHTML = comptes.length
    ? `<div style="overflow-x:auto"><table class="ds-table"><thead><tr><th>Compte</th><th class="is-num">Capital de départ</th><th class="is-num">Dépôts − retraits</th>
        <th class="is-num">Options ouvertes</th><th class="is-num">Actions détenues</th><th class="is-num">Valeur réalisée</th><th class="is-num">Capital immobilisé</th>
        <th class="is-num">Disponible</th><th class="is-num">Valeur du compte</th></tr></thead><tbody>${rows.join('')}</tbody></table></div>
      ${comptes.some((k) => !roueView(k).flows.some((f) => f.type === 'depart')) ? '<p class="metric-sub" style="text-align:left;">Un compte sans capital de départ garde sa valeur à « — » : ajoute-le dans « Ajouter un mouvement ».</p>' : ''}`
    : '<p class="ds-text-muted">Aucun compte n\'a encore de données.</p>';
}

function roueRefreshFlowCycleOptions() {
  const k = document.getElementById('roue-flow-compte').value;
  const opts = roueView(k).cycles.map((c) => `<option value="${c.id}">${optEsc(c.ticker)} #${c.id}</option>`).join('');
  document.getElementById('roue-flow-cycle').innerHTML = `<option value="">—</option>${opts}`;
}

async function roueSaveFlow() {
  const status = document.getElementById('roue-flow-status');
  const body = {
    compte: document.getElementById('roue-flow-compte').value,
    type: document.getElementById('roue-flow-type').value,
    date: document.getElementById('roue-flow-date').value,
    montant: parseFloat(document.getElementById('roue-flow-montant').value),
    ticker: document.getElementById('roue-flow-ticker').value.trim() || null,
    cycle_id: document.getElementById('roue-flow-cycle').value || null,
    notes: document.getElementById('roue-flow-notes').value.trim() || null,
  };
  if (!body.date || !(body.montant > 0)) { status.textContent = 'Date et montant positif requis.'; return; }
  try {
    await fetchJSON('/api/cash-flows', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    status.textContent = '✓ Ajouté.';
    document.getElementById('roue-flow-montant').value = '';
    document.getElementById('roue-flow-notes').value = '';
    await roueRefresh();
  } catch (err) { status.textContent = 'Échec : ' + err.message; }
}

// ---- Sélection multiple et suppression (positions et mouvements) ----

function roueSelSet(kind) { return kind === 'legs' ? roueState.selLegs : roueState.selFlows; }
// Une sélection ne garde que les lignes affichées (changer de compte ne laisse rien de caché coché).
function roueKeepVisible(set, rows) { const ids = new Set(rows.map((r) => r.id)); for (const id of [...set]) if (!ids.has(id)) set.delete(id); }
function roueSelTD(kind, id, set) {
  return `<td><input type="checkbox" class="roue-sel" data-kind="${kind}" data-id="${id}"${set.has(id) ? ' checked' : ''} aria-label="Sélectionner"></td>`;
}
function roueSelAllTH(kind, rows, set) {
  const all = rows.length > 0 && rows.every((r) => set.has(r.id));
  return `<th><input type="checkbox" class="roue-sel-all" data-kind="${kind}"${all ? ' checked' : ''} title="Tout sélectionner" aria-label="Tout sélectionner"></th>`;
}
function roueSelBarHTML(kind, n) {
  return `<div class="journal-actions" style="margin:0 0 0.4rem;">
    <button type="button" class="ds-btn ds-btn--sm" data-roue-del="${kind}"${n ? '' : ' disabled'}>Supprimer la sélection${n ? ` (${n})` : ''}</button>
    ${n ? `<button type="button" class="ds-btn ds-btn--sm" data-roue-clear="${kind}">Tout désélectionner</button>` : '<span class="metric-sub">Coche des lignes pour les supprimer.</span>'}
  </div>`;
}

function roueRerenderSel(kind) { if (kind === 'legs') roueRenderLegs(); else roueRenderCapital(); }

const ROUE_FILTER_RENDER = { semaine: () => roueRenderWeek(), annuel: () => roueRenderDashboard(), legs: () => roueRenderLegs(), positions: () => roueRenderPositions(), bilans: () => roueRenderBilans(), weeks: () => roueRenderWeeks() };

function roueOnSelChange(ev) {
  const el = ev.target;
  if (el.classList.contains('roue-filter')) {
    roueState.filtres[el.dataset.filter] = el.value;
    try { localStorage.setItem('castellana-roue-filtres', JSON.stringify(roueState.filtres)); } catch { /* sans effet */ }
    ROUE_FILTER_RENDER[el.dataset.filter]();
  } else if (el.classList.contains('roue-sel')) {
    const set = roueSelSet(el.dataset.kind);
    const id = Number(el.dataset.id);
    if (el.checked) set.add(id); else set.delete(id);
    roueRerenderSel(el.dataset.kind);
  } else if (el.classList.contains('roue-sel-all')) {
    const kind = el.dataset.kind;
    const set = roueSelSet(kind);
    const rows = kind === 'legs' ? roueView(roueState.filtres.legs).legs : roueView().flows;
    if (el.checked) rows.forEach((r) => set.add(r.id)); else set.clear();
    roueRerenderSel(kind);
  }
}

function roueOnSelClick(ev) {
  const del = ev.target.closest('[data-roue-del]');
  const clr = ev.target.closest('[data-roue-clear]');
  if (clr) { roueSelSet(clr.dataset.roueClear).clear(); roueRerenderSel(clr.dataset.roueClear); }
  if (del) roueDeleteSelection(del.dataset.roueDel);
}

async function roueDeleteSelection(kind) {
  const set = roueSelSet(kind);
  if (!set.size) return;
  const legIds = kind === 'legs' ? [...set] : [];
  const flowIds = kind === 'flows' ? [...set] : [];
  // Même plan que le serveur : on annonce exactement ce qui partira.
  const plan = optRoueDeletionPlan({ legIds, flowIds, legs: roueState.legs, cycles: roueState.cycles, stock: roueState.stock, flows: roueState.flows });
  const lines = [];
  if (plan.legIds.length) lines.push(`• ${plan.legIds.length} position(s) d'options`);
  if (plan.cycleIds.length) {
    const noms = plan.cycleIds.map((id) => { const c = roueState.cycles.find((x) => x.id === id); return c ? `${c.ticker} #${id}` : `#${id}`; }).join(', ');
    lines.push(`• ${plan.cycleIds.length} cycle(s) devenu(s) vide(s) : ${noms}`);
  }
  if (plan.stockIds.length) lines.push(`• ${plan.stockIds.length} ligne(s) d'actions de ces cycles (Journal & stats compris)`);
  if (plan.flowIds.length) lines.push(`• ${plan.flowIds.length} mouvement(s) (dividendes et mouvements de ces cycles compris)`);
  if (!confirm(`Supprimer définitivement :\n${lines.join('\n')}\n\nCette action ne peut pas être annulée.`)) return;
  try {
    await fetchJSON('/api/roue/delete', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ legIds, flowIds }) });
    roueState.selLegs.clear();
    roueState.selFlows.clear();
    await roueRefresh();
  } catch (err) { alert('Échec de la suppression : ' + err.message); }
}

// ---- H5 Journal des positions ----

function roueLegRowHTML(l, cycleById) {
  const r = optLegReturn(l, roueSize());
  const issues = optLegIssues(l);
  const sh = l.contrats * roueSize();
  const rachat = l.statut === 'roule' || l.statut === 'rachete' ? (Number(l.prime_cloture) || 0) * sh : null;
  const commissions = l.commission_ouverture == null && l.commission_cloture == null ? null : (Number(l.commission_ouverture) || 0) + (Number(l.commission_cloture) || 0);
  const ouvert = l.statut === 'ouvert';
  const c = l.cycle_id ? cycleById.get(l.cycle_id) : null;
  const roll = l.roule_vers_id ? ` → #${l.roule_vers_id}` : '';
  return `<tr>
    ${roueSelTD('legs', l.id, roueState.selLegs)}<td>${optEsc(l.date_ouverture)}</td><td>${optEsc(l.compte)}</td><td><strong>${optEsc(l.ticker)}</strong></td><td>${optEsc(l.type)}</td>
    <td class="is-num">${optNum(l.strike)}</td><td class="is-num">${l.contrats}</td><td>${optEsc(l.echeance)}</td>
    <td class="is-num">${roueMoney(l.prime_recue * sh)}</td>
    <td class="is-num" title="${commissions == null ? 'non renseignées' : ''}">${roueMoney(commissions)}</td>
    <td class="is-num">${rachat == null ? '' : roueMoney(rachat)}</td>
    <td class="is-num"${ouvert ? ' title="prime encaissée, pas encore réalisée"' : ''}><strong>${roueMoney(r ? r.pnl : null)}</strong>${ouvert ? ' <span class="ds-text-hint">(ouvert)</span>' : ''}</td>
    <td class="is-num">${r && r.jours != null ? r.jours : '—'}</td>
    <td class="is-num">${rouePct(r ? r.rendementAnnualise : null)}</td>
    <td class="is-num">${l.type === 'put' ? roueMoney(l.strike * sh, 0) : ''}</td>
    <td>${optEsc(ROUE_STATUT_LABELS[l.statut] || l.statut)}${l.date_cloture ? ` <span class="ds-text-hint">${optEsc(l.date_cloture)}</span>` : ''}${roll}</td>
    <td>${c ? '#' + c.id : '<span class="ds-text-hint">—</span>'}</td>
    <td>${issues.length ? `<span title="${optEsc(issues.join(' ; '))}" style="color:var(--amber);">⚠</span>` : ''}</td>
    <td>${ouvert ? `<button type="button" class="ds-btn ds-btn--sm" onclick="roueOpenClose(${l.id})">Clôturer</button>` : ''}</td>
  </tr>`;
}

function roueRenderLegs() {
  const { legs, cycles } = roueView(roueState.filtres.legs);
  const cycleById = new Map(cycles.map((c) => [c.id, c]));
  const rows = [...legs].sort((a, b) => (a.date_ouverture < b.date_ouverture ? 1 : a.date_ouverture > b.date_ouverture ? -1 : b.id - a.id));
  roueKeepVisible(roueState.selLegs, rows);
  document.getElementById('roue-legs-host').innerHTML = rows.length
    ? `${roueSelBarHTML('legs', roueState.selLegs.size)}<div style="overflow-x:auto"><table class="ds-table"><thead><tr>
        ${roueSelAllTH('legs', rows, roueState.selLegs)}<th>Ouverture${glossInfoBtn('roueOuverture')}</th><th>Compte${glossInfoBtn('roueCompte')}</th><th>Symbole</th><th>Type${glossInfoBtn('roueType')}</th><th class="is-num">Strike${glossInfoBtn('optStrike')}</th><th class="is-num">Contrats${glossInfoBtn('roueQte')}</th><th>Échéance${glossInfoBtn('roueEcheance')}</th>
        <th class="is-num">Prime${glossInfoBtn('rouePrime')}</th><th class="is-num">Commissions${glossInfoBtn('roueCommissions')}</th><th class="is-num">Rachat${glossInfoBtn('roueRachat')}</th><th class="is-num">P/L net${glossInfoBtn('rouePl')}</th>
        <th class="is-num">Jours${glossInfoBtn('roueJours')}</th><th class="is-num">Annualisé${glossInfoBtn('roueAnnualise')}</th><th class="is-num">Capital${glossInfoBtn('roueCapital')}</th><th>Statut${glossInfoBtn('roueStatut')}</th><th>Cycle${glossInfoBtn('roueCycle')}</th><th></th><th></th>
      </tr></thead><tbody>${rows.map((l) => roueLegRowHTML(l, cycleById)).join('')}</tbody></table></div>`
    : '<p class="ds-text-muted">Aucune position pour ce filtre. Saisis-en une ci-dessus, ou depuis le calculateur de Screener Prime.</p>';
}

function roueRefreshLegCycleOptions() {
  const ticker = document.getElementById('roue-leg-ticker').value.trim().toUpperCase();
  const { cycles } = roueView(document.getElementById('roue-leg-compte').value);
  const opts = cycles.filter((c) => c.statut === 'actif' && (!ticker || c.ticker === ticker))
    .map((c) => `<option value="${c.id}">${optEsc(c.ticker)} #${c.id}</option>`).join('');
  document.getElementById('roue-leg-cycle').innerHTML = `<option value="__new__">+ Nouveau cycle</option><option value="">Sans cycle</option>${opts}`;
}

async function roueSaveLeg() {
  const status = document.getElementById('roue-leg-status');
  const v = (id) => document.getElementById(id).value;
  const ticker = v('roue-leg-ticker').trim().toUpperCase();
  const body = {
    type: v('roue-leg-type'), ticker, compte: v('roue-leg-compte'),
    strike: parseFloat(v('roue-leg-strike')), contrats: parseInt(v('roue-leg-contrats'), 10) || 1,
    prime_recue: parseFloat(v('roue-leg-prime')), date_ouverture: v('roue-leg-ouverture'), echeance: v('roue-leg-echeance'),
    commission_ouverture: v('roue-leg-commission') === '' ? null : parseFloat(v('roue-leg-commission')),
    source: 'saisie',
  };
  if (!ticker || !(body.strike > 0) || !(body.prime_recue >= 0) || !body.date_ouverture || !body.echeance) {
    status.textContent = 'Symbole, strike, prime, ouverture et échéance sont requis.'; return;
  }
  const issues = optLegIssues(body);
  if (issues.length && !confirm(`Attention : ${issues.join(' ; ')}. Enregistrer quand même ?`)) return;
  try {
    let cycleSel = v('roue-leg-cycle');
    if (cycleSel === '__new__') cycleSel = (await fetchJSON('/api/option-cycles', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ticker, compte: body.compte, notes: '' }) })).id;
    body.cycle_id = cycleSel ? Number(cycleSel) : null;
    await fetchJSON('/api/option-trades', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    status.textContent = '✓ Position enregistrée.';
    ['roue-leg-strike', 'roue-leg-prime', 'roue-leg-commission'].forEach((id) => { document.getElementById(id).value = ''; });
    await roueRefresh();
  } catch (err) { status.textContent = 'Échec : ' + err.message; }
}

// Clôture : dialogue unique. Un roulement crée d'abord la nouvelle jambe (même cycle), puis clôture
// l'ancienne avec le lien roule_vers_id ; si la clôture échoue, la nouvelle jambe est supprimée.
let roueClosingId = null;

function roueSyncCloseForm() {
  const statut = document.getElementById('roue-close-statut').value;
  const leg = roueState.legs.find((l) => l.id === roueClosingId);
  document.getElementById('roue-close-prime').disabled = statut === 'expire' || statut === 'assigne';
  document.getElementById('roue-close-stop-wrap').style.display = statut === 'assigne' && leg && leg.type === 'put' ? '' : 'none';
  document.getElementById('roue-close-roll').style.display = statut === 'roule' ? '' : 'none';
  if (statut === 'expire' && leg) document.getElementById('roue-close-date').value = leg.echeance;
}

function roueOpenClose(id) {
  const leg = roueState.legs.find((l) => l.id === id);
  if (!leg) return;
  roueClosingId = id;
  document.getElementById('roue-close-title').textContent = `Clôturer ${leg.ticker} ${leg.type} ${leg.strike} (${leg.echeance})`;
  document.getElementById('roue-close-statut').value = leg.echeance <= roueToday() ? 'expire' : 'rachete';
  document.getElementById('roue-close-date').value = leg.echeance <= roueToday() ? leg.echeance : roueToday();
  ['roue-close-prime', 'roue-close-commission', 'roue-close-stop', 'roue-roll-strike', 'roue-roll-echeance', 'roue-roll-prime', 'roue-roll-commission'].forEach((x) => { document.getElementById(x).value = ''; });
  document.getElementById('roue-close-status').textContent = '';
  roueSyncCloseForm();
  document.getElementById('roue-close-dialog').showModal();
}

async function roueConfirmClose() {
  const leg = roueState.legs.find((l) => l.id === roueClosingId);
  const status = document.getElementById('roue-close-status');
  if (!leg) return;
  const v = (id) => document.getElementById(id).value;
  const statut = v('roue-close-statut');
  const body = { statut, dateCloture: v('roue-close-date'), primeCloture: statut === 'expire' || statut === 'assigne' ? 0 : parseFloat(v('roue-close-prime')) };
  if (v('roue-close-commission') !== '') body.commissionCloture = parseFloat(v('roue-close-commission'));
  if (!body.dateCloture) { status.textContent = 'Date requise.'; return; }
  if ((statut === 'rachete' || statut === 'roule') && !(body.primeCloture >= 0)) { status.textContent = 'Prime de rachat requise.'; return; }
  if (statut === 'assigne' && leg.type === 'put') {
    body.stopInitial = parseFloat(v('roue-close-stop'));
    if (!(body.stopInitial > 0)) { status.textContent = 'Un stop initial positif est requis pour créer l\'action dans le Journal actions (jamais déduit automatiquement).'; return; }
  }
  let newLeg = null;
  try {
    if (statut === 'roule') {
      const roll = {
        cycle_id: leg.cycle_id, type: leg.type, ticker: leg.ticker, compte: leg.compte, contrats: leg.contrats,
        strike: parseFloat(v('roue-roll-strike')), echeance: v('roue-roll-echeance'), prime_recue: parseFloat(v('roue-roll-prime')),
        date_ouverture: body.dateCloture, source: 'saisie',
        commission_ouverture: v('roue-roll-commission') === '' ? null : parseFloat(v('roue-roll-commission')),
      };
      if (!(roll.strike > 0) || !roll.echeance || !(roll.prime_recue >= 0)) { status.textContent = 'Strike, échéance et prime de la nouvelle position sont requis.'; return; }
      newLeg = await fetchJSON('/api/option-trades', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(roll) });
      body.rouleVersId = newLeg.id;
    }
    const result = await fetchJSON(`/api/option-trades/${leg.id}/close`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    document.getElementById('roue-close-dialog').close();
    if (result.effect.type === 'trade_cree') alert(`Action créée dans le Journal actions (trade #${result.effect.tradeId}).`);
    if (result.effect.type === 'trade_ferme') alert(`Action du cycle revendue au strike (trade #${result.effect.tradeId}, ${result.effect.resultat}).`);
    if (result.effect.type === 'aucune_position_liee') alert('Aucune action liée trouvée pour ce cycle : rien de fermé dans le Journal actions.');
    await roueRefresh();
  } catch (err) {
    if (newLeg) { try { await fetchJSON(`/api/option-trades/${newLeg.id}`, { method: 'DELETE' }); } catch { /* signalé ci-dessous */ } }
    status.textContent = 'Échec : ' + err.message;
  }
}

// ---- H6 Positions de la Roue ----

function roueRenderPositions() {
  const { cycles, legs, stock, flows } = roueView(roueState.filtres.positions);
  const rows = [];
  for (const c of cycles) {
    const open = stock.filter((s) => s.option_cycle_id === c.id && !s.date_sortie);
    if (!open.length) continue;
    const cycleLegs = legs.filter((l) => l.cycle_id === c.id);
    const price = roueState.prices[c.ticker];
    const b = optCycleBilan({ ...c, legs: cycleLegs }, { contractSize: roueSize(), stockTrades: stock.filter((s) => s.option_cycle_id === c.id), priceEnd: Number.isFinite(price) ? price : null, cashFlows: flows.filter((f) => f.cycle_id === c.id) });
    const qty = open.reduce((a, s) => a + s.taille_position, 0);
    const cost = open.reduce((a, s) => a + s.prix_entree * s.taille_position, 0);
    const call = cycleLegs.find((l) => l.type === 'call' && l.statut === 'ouvert');
    rows.push(`<tr>
      <td><strong>${optEsc(c.ticker)}</strong> #${c.id}</td><td>${optEsc(c.compte)}</td><td class="is-num">${qty}</td>
      <td class="is-num">${optNum(cost / qty)}</td>
      <td class="is-num" title="coût moyen par action après primes nettes de frais et dividendes"><strong>${b && b.coutDeBaseNet != null ? optNum(b.coutDeBaseNet) : '—'}</strong></td>
      <td class="is-num">${Number.isFinite(price) ? optNum(price) : '—'}</td>
      <td class="is-num">${b ? roueMoney(b.latentAction, 0) : '—'}</td>
      <td class="is-num">${b ? roueMoney(b.primesNettes - b.commissions + b.dividendes, 0) : '—'}</td>
      <td class="is-num"><strong>${b && b.latentConnu ? roueMoney(b.pnlNet, 0) : '—'}</strong></td>
      <td>${call ? `call ${optNum(call.strike)} (${optEsc(call.echeance)})` : '<span class="ds-text-hint">aucun call ouvert</span>'}</td>
    </tr>`);
  }
  document.getElementById('roue-positions-host').innerHTML = rows.length
    ? `<div style="overflow-x:auto"><table class="ds-table"><thead><tr><th>Cycle</th><th>Compte</th><th class="is-num">Actions</th><th class="is-num">Prix d'achat</th><th class="is-num">Coût moyen net</th><th class="is-num">Cours</th><th class="is-num">P/L action</th><th class="is-num">Primes nettes</th><th class="is-num">P/L total</th><th>Call couvert</th></tr></thead><tbody>${rows.join('')}</tbody></table></div>`
    : '<p class="ds-text-muted">Aucune action détenue pour ce filtre. Une action apparaît ici quand un put d\'un cycle est clôturé « assigné ».</p>';
}

// ---- H7 Bilan par cycle ----

async function roueLoadBilans() {
  const host = document.getElementById('roue-bilan-host');
  try {
    const { bilans } = await fetchJSON('/api/option-cycles/bilans');
    roueState.bilans = bilans || [];
    roueRenderBilans();
  } catch (err) { host.innerHTML = `<p class="ds-text-muted">Échec du chargement des bilans : ${optEsc(err.message)}</p>`; }
}

function roueRenderBilans() {
  const host = document.getElementById('roue-bilan-host');
  const cyc = new Map(roueView(roueState.filtres.bilans).cycles.map((c) => [c.id, c]));
  const ids = new Set(cyc.keys());
  const rows = roueState.bilans.filter((x) => x.bilan && ids.has(x.cycleId));
  if (!rows.length) { host.innerHTML = '<p class="ds-text-muted">Aucun cycle avec des positions pour ce filtre.</p>'; return; }
  host.innerHTML = `<div style="overflow-x:auto"><table class="ds-table"><thead><tr>
    <th>Cycle</th><th>Compte</th><th>Statut</th><th class="is-num">Jours</th><th class="is-num">Primes nettes</th><th class="is-num">Commissions</th><th class="is-num">Dividendes</th>
    <th class="is-num">Action réalisée</th><th class="is-num">Action latente</th><th class="is-num">Résultat net</th><th class="is-num">Capital</th>
    <th class="is-num">Rendement net</th><th class="is-num">Annualisé</th><th class="is-num">Détention</th><th class="is-num">Écart (sans frais)</th><th class="is-num">Coût moyen net</th></tr></thead><tbody>${
    rows.map((x) => { const b = x.bilan; const ann = b.rendementNet != null && b.jours >= 30 ? b.rendementNet * 365 / b.jours : null; return `<tr>
      <td><strong>${optEsc(x.ticker)}</strong> #${x.cycleId}</td><td>${optEsc(cyc.get(x.cycleId)?.compte || '')}</td><td>${optEsc(x.statut)}</td><td class="is-num">${b.jours}</td>
      <td class="is-num">${roueMoney(b.primesNettes, 0)}</td><td class="is-num">${roueMoney(b.commissions)}</td><td class="is-num">${roueMoney(b.dividendes)}</td>
      <td class="is-num">${roueMoney(b.realiseAction, 0)}</td><td class="is-num">${roueMoney(b.latentAction, 0)}</td>
      <td class="is-num"><strong>${roueMoney(b.pnlNet, 0)}</strong>${b.latentConnu ? '' : ' <span class="ds-text-hint" title="latent non évalué">*</span>'}</td>
      <td class="is-num">${roueMoney(b.capital, 0)}</td><td class="is-num">${roueSignedPct(b.rendementNet)}</td>
      <td class="is-num" title="à partir de 30 jours">${roueSignedPct(ann)}</td><td class="is-num">${roueSignedPct(b.holdReturn)}</td>
      <td class="is-num">${b.vsHold == null ? '—' : (b.vsHold >= 0 ? '+' : '') + (b.vsHold * 100).toFixed(1) + ' pts'}</td>
      <td class="is-num">${b.coutDeBaseNet == null ? '—' : optNum(b.coutDeBaseNet)}</td></tr>`; }).join('')
  }</tbody></table></div>${rows.some((x) => x.prixIndisponibles) ? '<p class="metric-sub" style="text-align:left;">Certains cours étaient indisponibles : latent et détention marqués « — ».</p>' : ''}`;
}

// ---- H8 Rapport hebdo ----

function roueYears() {
  const { legs, stock, flows } = roueView('tout');
  const ys = new Set(optWeeklyReport({ legs, stockTrades: stock, cashFlows: flows, contractSize: roueSize() }).map((w) => w.annee));
  ys.add(new Date().getFullYear());
  return [...ys].sort((a, b) => b - a);
}

function roueSyncYearSelects() {
  const years = roueYears();
  if (!years.includes(roueState.year)) roueState.year = years[0];
  document.querySelectorAll('.roue-year').forEach((sel) => {
    sel.innerHTML = years.map((y) => `<option value="${y}">${y}</option>`).join('');
    sel.value = String(roueState.year);
  });
}

// Une ligne par semaine ET par compte : le ROI et la valeur du compte n'ont de sens que pour un compte.
// Filtre « Tout » : les comptes sont calculés séparément, et seules leurs semaines actives sont montrées.
function roueRenderWeeks() {
  const f = roueState.filtres.weeks;
  const comptes = f === 'tout' ? ROUE_COMPTES : [f];
  const actif = (w) => w.nbTrades || w.profitNet || w.depotsRetraits || w.depart || w.dividendes || w.autresRevenus;
  let flows = [];
  let weeks = [];
  for (const k of comptes) {
    const v = roueView(k);
    flows = flows.concat(v.flows);
    const ws = optWeeklyReport({ legs: v.legs, stockTrades: v.stock, cashFlows: v.flows, contractSize: roueSize() })
      .filter((w) => w.annee === roueState.year && (f !== 'tout' || actif(w)))
      .map((w) => ({ ...w, compte: k }));
    weeks = weeks.concat(ws);
  }
  weeks.sort((a, b) => (a.semaine === b.semaine ? ROUE_COMPTES.indexOf(a.compte) - ROUE_COMPTES.indexOf(b.compte) : (a.semaine < b.semaine ? 1 : -1)));
  const fmt = (d) => new Date(`${d}T00:00:00Z`).toLocaleDateString('fr-CA', { day: 'numeric', month: 'short', timeZone: 'UTC' });
  const host = document.getElementById('roue-weeks-host');
  host.innerHTML = weeks.length
    ? `<div style="overflow-x:auto; max-height:420px; overflow-y:auto;"><table class="ds-table"><thead><tr>
        <th>Semaine</th><th>Compte</th><th class="is-num">Positions</th><th class="is-num">Assign.</th><th class="is-num">Puts vendus</th><th class="is-num">Commissions</th>
        <th class="is-num">Dividendes</th><th class="is-num">Autres rev.</th><th class="is-num">Dépôts/retraits</th><th class="is-num">Profit net</th><th class="is-num">ROI hebdo</th>
        <th class="is-num">Valeur du compte</th><th class="is-num">Profit cumulé</th></tr></thead><tbody>${weeks.map((w) => `<tr${actif(w) ? '' : ' style="opacity:.55"'}>
        <td>${fmt(w.semaine)} – ${fmt(w.fin)}</td><td>${optEsc(w.compte)}</td><td class="is-num">${w.nbTrades}</td>
        <td class="is-num">${w.nbAssignations}${w.pctAssignation != null && w.nbAssignations ? ` <span class="ds-text-hint">(${rouePct(w.pctAssignation, 0)})</span>` : ''}</td>
        <td class="is-num">${w.valeurPutsVendus ? roueMoney(w.valeurPutsVendus, 0) : ''}</td><td class="is-num">${w.commissions ? roueMoney(w.commissions) : ''}</td>
        <td class="is-num">${w.dividendes ? roueMoney(w.dividendes) : ''}</td><td class="is-num">${w.autresRevenus ? roueMoney(w.autresRevenus) : ''}</td>
        <td class="is-num">${w.depotsRetraits || w.depart ? roueMoney(w.depotsRetraits + w.depart, 0) : ''}</td>
        <td class="is-num"><strong>${roueMoney(w.profitNet)}</strong></td><td class="is-num">${roueSignedPct(w.roiHebdo, 2)}</td>
        <td class="is-num">${roueMoney(w.valeurCompteRealisee, 0)}</td><td class="is-num">${roueMoney(w.profitCumule, 0)}</td></tr>`).join('')}</tbody></table></div>
      ${f === 'tout' ? '<p class="metric-sub" style="text-align:left;">Filtre « Tout » : une ligne par compte et par semaine active ; le ROI et la valeur sont ceux de chaque compte.</p>' : ''}
      ${comptes.every((k) => flows.some((x) => x.compte === k && x.type === 'depart')) ? '' : '<p class="metric-sub" style="text-align:left;">Un compte sans capital de départ (carte H4) garde sa valeur et son ROI à « — ».</p>'}`
    : '<p class="ds-text-muted">Aucune position close, aucun mouvement pour ce filtre cette année.</p>';
}

// Barres verticales signées (profit mensuel) — SVG fait main, même principe que le reste de l'app.
function roueBarsSVG(values, labels) {
  const W = 360; const H = 150; const pad = 18; const max = Math.max(1, ...values.map((v) => Math.abs(v)));
  const hasNeg = values.some((v) => v < 0);
  const zero = hasNeg ? pad + (H - 2 * pad) / 2 : H - pad;
  const scale = (hasNeg ? (H - 2 * pad) / 2 : H - 2 * pad) / max;
  const bw = (W - 10) / values.length;
  const bars = values.map((v, i) => {
    const h = Math.abs(v) * scale; const x = 5 + i * bw + bw * 0.15; const y = v >= 0 ? zero - h : zero;
    return `<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${(bw * 0.7).toFixed(1)}" height="${Math.max(v ? 1 : 0, h).toFixed(1)}" rx="2" fill="${v < 0 ? 'var(--red)' : 'var(--accent)'}"><title>${labels[i]} : ${roueMoney(v)}</title></rect>
      <text x="${(5 + i * bw + bw / 2).toFixed(1)}" y="${H - 3}" font-size="9" text-anchor="middle" fill="var(--text-2)">${labels[i]}</text>`;
  }).join('');
  return `<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="Profit net par mois"><line x1="0" x2="${W}" y1="${zero}" y2="${zero}" stroke="var(--border)"/>${bars}</svg>`;
}

function roueLineSVG(points) {
  if (points.length < 2) return '<p class="ds-text-muted">Pas assez de semaines (ou pas de capital de départ).</p>';
  const W = 360; const H = 150; const pad = 14;
  const ys = points.map((p) => p.v); const min = Math.min(...ys); const max = Math.max(...ys); const span = max - min || 1;
  const xy = points.map((p, i) => [pad + (i * (W - 2 * pad)) / (points.length - 1), H - pad - ((p.v - min) / span) * (H - 2 * pad)]);
  const d = xy.map(([x, y], i) => `${i ? 'L' : 'M'}${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
  const last = xy[xy.length - 1];
  return `<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="Valeur du compte par semaine">
    <path d="${d}" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>
    <circle cx="${last[0].toFixed(1)}" cy="${last[1].toFixed(1)}" r="4" fill="var(--accent)"/>
    <text x="${pad}" y="11" font-size="10" fill="var(--text-2)">${roueMoney(max, 0)}</text><text x="${pad}" y="${H - 2}" font-size="10" fill="var(--text-2)">${roueMoney(min, 0)}</text></svg>`;
}

function roueHBarsHTML(rows) {
  if (!rows.length) return '<p class="ds-text-muted">Rien de réalisé cette année.</p>';
  const max = Math.max(1, ...rows.map((r) => Math.abs(r.profit)));
  return rows.slice(0, 10).map((r) => `<div style="display:grid; grid-template-columns:110px 1fr 90px; gap:8px; align-items:center; font-size:12px; margin:3px 0;">
    <span style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${optEsc(r.cle)}">${optEsc(r.cle)}</span>
    <span style="background:var(--surface-2); border-radius:3px; height:10px;"><span style="display:block; height:10px; border-radius:3px; width:${(Math.abs(r.profit) / max * 100).toFixed(1)}%; background:${r.profit < 0 ? 'var(--red)' : 'var(--accent)'};"></span></span>
    <span style="text-align:right; white-space:nowrap;">${roueMoney(r.profit, 0)}</span></div>`).join('')
    + (rows.length > 10 ? `<p class="metric-sub" style="text-align:left;">+ ${rows.length - 10} autre(s)</p>` : '');
}

// Secteurs (Yahoo, mis en cache) et jours avant les résultats, par lots de 20, titres ouverts d'abord.
// Les résultats des positions ouvertes sont relus à chaque actualisation (ils changent chaque jour).
async function roueLoadSectors() {
  const { legs, stock } = roueView('tout');
  const ouverts = [...new Set([...legs.filter((l) => l.statut === 'ouvert').map((l) => l.ticker), ...stock.filter((s) => !s.date_sortie).map((s) => s.ticker)])];
  const autres = [...new Set(legs.map((l) => l.ticker))].filter((t) => !ouverts.includes(t) && !(t in roueState.sectors));
  const tickers = [...ouverts, ...autres].slice(0, 60);
  for (let i = 0; i < tickers.length; i += 20) {
    try {
      const { sectors, earnings } = await fetchJSON(`/api/ticker-sectors?tickers=${encodeURIComponent(tickers.slice(i, i + 20).join(','))}`);
      Object.assign(roueState.sectors, sectors);
      if (earnings) Object.assign(roueState.earnings, earnings);
    } catch { /* secteurs indisponibles : « Non renseigné », résultats « — » */ }
  }
}

// ---- H2 Semaine / H3 Tableau de bord annuel (16/10/2026, bilbao #443, #444) ----
// Tous les calculs viennent de js/options-analytics.js (optWeekLegs, optRouePositions,
// optLegOutcomes, optPremiumBreakdown, optValueSeries, optRoueActivity, optStrikeDistance).

const ROUE_MOIS = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];

function roueWeekShellHTML() {
  return `
    <div class="ds-card">
      <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; flex-wrap:wrap; margin-bottom:0.5rem;">
        <div class="section-title" style="margin-bottom:0;">Semaine</div>
        <span style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
          ${roueFilterHTML('semaine')}
          <button type="button" class="ds-btn ds-btn--sm" id="roue-wk-prev" title="Semaine précédente">‹</button>
          <strong id="roue-wk-label" style="font-size:13px;"></strong>
          <button type="button" class="ds-btn ds-btn--sm" id="roue-wk-next" title="Semaine suivante">›</button>
          <button type="button" class="ds-btn ds-btn--shine ds-btn--sm" id="roue-wk-today">Aujourd'hui</button>
        </span>
      </div>
      <p class="metric-sub" style="text-align:left;">Les options dont l'échéance tombe dans la semaine (dimanche → samedi) ou qui y ont été vendues. Primes nettes = prime encaissée − rachat − commissions. Règle de prime : ${OPTA_RULE_DEFAULT.pct} % du strike par ${OPTA_RULE_DEFAULT.days} jours de durée. Distance = écart du strike au dernier cours (négatif = dans la monnaie, assignation probable). Earning (résultats) : vert au-delà de 10 jours, orange à 10 jours ou moins, rouge à 5 ou moins.</p>
      <div class="metric-band" id="roue-wk-metrics" style="--cols:6;"></div>
      <div id="roue-wk-legs" style="margin-top:0.5rem;"></div>
      <div class="metric-sub" style="text-align:left; font-weight:500; margin-top:0.75rem;">Positions assignées</div>
      <p class="metric-sub" style="text-align:left;">Coût de base net = prix d'achat − primes nettes de frais et dividendes du cycle, par action. Le latent se mesure au dernier cours contre ce coût, jamais contre le strike. Un call vendu sous ce coût verrouille une perte s'il est assigné.</p>
      <div id="roue-wk-positions"></div>
      <div class="roue-wk-bottom">
        <div class="roue-wk-main">
          <div class="metric-sub" style="text-align:left; font-weight:500; margin:0 0 4px;">Semaine suivante</div>
          <div id="roue-wk-next-host"></div>
        </div>
        <aside id="roue-wk-alerts"></aside>
      </div>
    </div>`;
}

function roueDashShellHTML() {
  const card = (title, id, extra = '') => `<div><div class="metric-sub" style="text-align:left; font-weight:500; margin-bottom:4px;">${title}</div><div id="${id}"></div>${extra}</div>`;
  return `
    <div class="ds-card">
      <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; flex-wrap:wrap; margin-bottom:0.5rem;">
        <div class="section-title" style="margin-bottom:0;">Tableau de bord annuel</div>
        <span style="display:flex; align-items:center; gap:12px; flex-wrap:wrap;">${roueFilterHTML('annuel')}<label class="metric-sub" style="display:flex; align-items:center; gap:6px;">Année <select class="ds-select roue-year" style="width:auto;"></select></label></span>
      </div>
      <p class="metric-sub" style="text-align:left;">Rendement réalisé = rendement composé des semaines terminées (pondéré dans le temps : un dépôt n'y compte pas comme un gain) ; projeté sur un an seulement à partir de 4 semaines. Les options closes se lisent en expirées, rachetées (roulées comprises) et assignées : une assignation fait partie de la Roue. Latent = au dernier cours, contre le coût de base net des primes.</p>
      <div class="metric-band metric-band--rows" id="roue-dash-metrics" style="--cols:5;"></div>
      <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(min(320px, 100%), 1fr)); gap:1rem; margin-top:0.75rem;">
        ${card('Valeur du compte : réalisée vs apports + primes', 'roue-dash-value')}
        ${card('Dénouement des options par mois', 'roue-dash-outcomes')}
      </div>
      <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(min(240px, 100%), 1fr)); gap:1rem; margin-top:0.75rem;">
        ${card('Primes nettes par mois', 'roue-dash-months')}
        ${card('Primes par titre', 'roue-dash-tickers')}
        ${card('Primes par secteur', 'roue-dash-sectors')}
      </div>
      <div class="metric-sub" style="text-align:left; font-weight:500; margin-top:0.75rem;">Positions en cours</div>
      <div id="roue-dash-positions"></div>
      <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(min(300px, 100%), 1fr)); gap:1rem; margin-top:0.75rem;">
        ${card('Capital', 'roue-dash-capital')}
        ${card('Activité de l\'année', 'roue-dash-activity')}
      </div>
    </div>`;
}

function roueMetric(label, value, sub = '', cls = '') {
  return `<div class="ds-metric"><div class="ds-metric__label">${label}</div><div class="ds-metric__value${cls ? ' ' + cls : ''}">${value}</div>${sub ? `<div class="ds-metric__sub">${sub}</div>` : ''}</div>`;
}
function roueSignCls(v) { return v == null ? '' : v < 0 ? 'bad' : v > 0 ? 'ok' : ''; }
function roueDayMonth(d) { return d ? `${d.slice(8, 10)}-${d.slice(5, 7)}` : '—'; }
function roueDaysUntil(d) { const a = optDateMs(roueToday()); const b = optDateMs(d); return a == null || b == null ? null : Math.round((b - a) / 86400000); }
function roueWeekOf(d) { return optWeekStart(d || roueToday()); }
function roueAddDays(d, n) { return optIsoDay(optDateMs(d) + n * 86400000); }
function roueTag(text, kind, title = '') {
  const c = { ok: 'var(--green)', warn: 'var(--amber)', bad: 'var(--red)', n: 'var(--text-2)' }[kind] || 'var(--text-2)';
  return `<span class="ds-badge" style="color:${c}; white-space:nowrap;"${title ? ` title="${optEsc(title)}"` : ''}>${optEsc(text)}</span>`;
}
// Feu des résultats : rouge ≤ 5 j, orange ≤ 10 j, vert au-delà ; « — » si la date est inconnue.
function roueEarningsTag(tk) {
  const d = roueState.earnings[tk];
  if (d == null || !Number.isFinite(d) || d < 0) return '<span class="ds-text-hint">—</span>';
  return roueTag(`● ${d} j`, d <= 5 ? 'bad' : d <= 10 ? 'warn' : 'ok', 'jours avant la publication des résultats');
}
function roueDistanceTag(l) {
  const S = roueState.prices[l.ticker];
  const d = optStrikeDistance(l.type, S, l.strike);
  if (d == null) return '<span class="ds-text-hint">—</span>';
  const txt = `${Math.abs(d * 100).toFixed(1)} % ${d < 0 ? 'ITM' : 'OTM'}`;
  return roueTag(txt, d < 0 ? 'bad' : d < 0.02 ? 'warn' : 'ok');
}
function roueLegRule(l) {
  const o = optDateMs(l.date_ouverture); const e = optDateMs(l.echeance);
  const dte = o != null && e != null ? Math.max(1, Math.round((e - o) / 86400000)) : null;
  return dte == null ? null : optPremiumRule(l.type, null, l.strike, Number(l.prime_recue), dte, OPTA_RULE_DEFAULT.pct, OPTA_RULE_DEFAULT.days);
}

function rouePositionsHTML(pos, { compact = false } = {}) {
  if (!pos.rows.length) return '<p class="ds-text-muted">Aucune action détenue pour ce filtre.</p>';
  const verif = (r) => ({
    sous_cout: roueTag('Call sous le coût de base', 'bad', 'une assignation verrouillerait une perte'),
    plafonne: roueTag('Plafonné : cours au-dessus du strike', 'warn'),
    ok: roueTag('OK', 'ok'),
    sans_call: roueTag('Aucun call ouvert', 'n'),
  }[r.verif]);
  const body = pos.rows.map((r) => `<tr>
    <td><strong>${optEsc(r.ticker)}</strong> <span class="ds-text-hint">#${r.cycleId}${r.depuis ? ' · depuis ' + roueDayMonth(r.depuis) : ''}</span></td><td>${optEsc(r.compte)}</td>
    <td class="is-num">${r.qty}</td>${compact ? '' : `<td class="is-num">${optNum(r.prixAchat)}</td>`}
    <td class="is-num"><strong>${optNum(r.coutDeBaseNet)}</strong></td><td class="is-num">${r.cours == null ? '—' : optNum(r.cours)}</td>
    <td class="is-num ${roueSignCls(r.latentNet)}">${r.latentNet == null ? '—' : roueMoney(r.latentNet)}</td>
    ${compact ? '' : `<td class="is-num">${r.call ? `${optNum(r.call.strike)} <span class="ds-text-hint">(${roueDayMonth(r.call.echeance)})</span>` : '—'}</td>`}
    <td>${verif(r)}</td></tr>`).join('');
  const total = `<tr><td colspan="${compact ? 5 : 6}"><strong>Latent net</strong> <span class="ds-text-hint">dont positions en perte ${roueMoney(pos.latentNegatif, 0)}</span></td>
    <td class="is-num ${roueSignCls(pos.latentNet)}"><strong>${pos.latentNet == null ? '— (cours manquant)' : roueMoney(pos.latentNet, 0)}</strong></td><td colspan="${compact ? 1 : 2}"></td></tr>`;
  return `<div style="overflow-x:auto"><table class="ds-table"><thead><tr><th>Titre</th><th>Compte</th><th class="is-num">Actions</th>${compact ? '' : '<th class="is-num">Prix d\'achat</th>'}
    <th class="is-num">Coût de base net</th><th class="is-num">Cours</th><th class="is-num">Latent</th>${compact ? '' : '<th class="is-num">Call vendu</th>'}<th>Vérification</th></tr></thead><tbody>${body}${total}</tbody></table></div>`;
}

function roueRenderWeek() {
  const host = document.getElementById('roue-wk-legs');
  if (!host) return;
  const k = roueState.filtres.semaine;
  const v = roueView(k);
  const ws = roueState.weekStart || roueWeekOf();
  const we = roueAddDays(ws, 6);
  const enCours = roueWeekOf() === ws;
  const fmt = (d) => new Date(`${d}T00:00:00Z`).toLocaleDateString('fr-CA', { day: 'numeric', month: 'long', timeZone: 'UTC' });
  document.getElementById('roue-wk-label').textContent = `Semaine du ${fmt(ws)} au ${fmt(we)}${enCours ? ' · en cours' : ''}`;

  const legs = optWeekLegs(v.legs, ws).sort((a, b) => (a.echeance < b.echeance ? -1 : a.echeance > b.echeance ? 1 : a.ticker < b.ticker ? -1 : 1));
  const size = roueSize();
  const primes = legs.reduce((a, l) => a + optLegPnl(l, size), 0);
  const comm = legs.reduce((a, l) => a + optLegCommissions(l), 0);
  const putsCap = legs.filter((l) => l.type === 'put').reduce((a, l) => a + l.strike * l.contrats * size, 0);
  const report = optWeeklyReport({ legs: v.legs, stockTrades: v.stock, cashFlows: v.flows, contractSize: size });
  const prev = [...report].reverse().find((w) => w.semaine < ws);
  const cur = report.find((w) => w.semaine === ws);
  const snap = optAccountSnapshot({ legs: v.legs, stockTrades: v.stock, cashFlows: v.flows, contractSize: size, prices: roueState.prices });
  const base = prev && prev.valeurCompteRealisee != null ? prev.valeurCompteRealisee : snap.valeurRealisee;
  const valeur = enCours ? (snap.valeurCompte ?? snap.valeurRealisee) : (cur ? cur.valeurCompteRealisee : prev ? prev.valeurCompteRealisee : null);
  const delta = cur && prev && cur.valeurCompteRealisee != null && prev.valeurCompteRealisee != null ? cur.valeurCompteRealisee - prev.valeurCompteRealisee : null;
  const apports = cur ? cur.depart + cur.depotsRetraits : 0;
  const nCalls = legs.filter((l) => l.type === 'call').length;
  document.getElementById('roue-wk-metrics').innerHTML = [
    roueMetric('Primes nettes', roueMoney(primes), 'options de la semaine, frais déduits', roueSignCls(primes)),
    roueMetric('Rendement hebdo', base > 0 ? rouePct(primes / base, 2) : '—', base > 0 ? 'sur la valeur réalisée d\'avant' : 'capital de départ à saisir'),
    roueMetric('Options', String(legs.length), `${nCalls} call${nCalls > 1 ? 's' : ''} · ${legs.length - nCalls} put${legs.length - nCalls > 1 ? 's' : ''}`),
    roueMetric('Capital engagé', roueMoney(enCours ? snap.capitalImmobilise : putsCap, 0), enCours ? `dont puts ${roueMoney(snap.capitalPuts, 0)}` : 'puts de la semaine'),
    roueMetric('Commissions', roueMoney(comm)),
    roueMetric('Valeur du compte', roueMoney(valeur, 0), `${delta == null ? '' : `${delta >= 0 ? '+' : ''}${roueMoney(delta, 0)} vs sem. préc. · `}apports ${roueMoney(apports, 0)}`),
  ].join('');

  host.innerHTML = legs.length ? `<div style="overflow-x:auto"><table class="ds-table"><thead><tr>
      <th>Titre</th><th>Compte${glossInfoBtn('roueCompte')}</th><th>Type${glossInfoBtn('roueType')}</th><th>Vendu → échéance${glossInfoBtn('roueDates')}</th><th class="is-num">Strike${glossInfoBtn('optStrike')}</th><th class="is-num">Prime${glossInfoBtn('rouePrime')}</th><th class="is-num">Prime/strike${glossInfoBtn('rouePrimeStrike')}</th>
      <th class="is-num">Qté${glossInfoBtn('roueQte')}</th><th class="is-num">Cours${glossInfoBtn('roueCours')}</th><th>Distance${glossInfoBtn('roueDistance')}</th><th>Earning${glossInfoBtn('roueEarning')}</th><th class="is-num">P/L net${glossInfoBtn('rouePl')}</th><th>Statut${glossInfoBtn('roueStatut')}</th></tr></thead><tbody>${legs.map((l) => {
        const rule = roueLegRule(l);
        const ratio = l.strike > 0 ? Number(l.prime_recue) / l.strike : null;
        const pl = optLegPnl(l, size);
        const ouvert = l.statut === 'ouvert';
        return `<tr>
          <td><strong>${optEsc(l.ticker)}</strong></td><td>${optEsc(l.compte)}</td><td>${l.type === 'put' ? 'PUT' : 'CALL'}</td>
          <td>${roueDayMonth(l.date_ouverture)} → ${roueDayMonth(l.echeance)}</td><td class="is-num">${optNum(l.strike)}</td><td class="is-num">${optNum(Number(l.prime_recue))}</td>
          <td class="is-num"${rule && !rule.ok ? ` style="color:var(--amber);" title="sous la règle : ${rule.requiredPct.toFixed(2)} % exigés pour cette durée"` : ''}>${rouePct(ratio, 2)}${rule && !rule.ok ? ' ⚠' : ''}</td>
          <td class="is-num">${l.contrats}</td><td class="is-num">${Number.isFinite(roueState.prices[l.ticker]) ? optNum(roueState.prices[l.ticker]) : '—'}</td>
          <td>${ouvert ? roueDistanceTag(l) : ''}</td><td>${ouvert ? roueEarningsTag(l.ticker) : ''}</td>
          <td class="is-num ${roueSignCls(pl)}">${roueMoney(pl)}</td><td>${roueTag(ROUE_STATUT_LABELS[l.statut] || l.statut, ouvert ? 'n' : l.statut === 'assigne' ? 'warn' : 'ok')}</td></tr>`;
      }).join('')}<tr><td colspan="11"><strong>${legs.length} option${legs.length > 1 ? 's' : ''}</strong> <span class="ds-text-hint">· ${roueMoney(putsCap, 0)} garantis par des puts</span></td><td class="is-num"><strong>${roueMoney(primes)}</strong></td><td></td></tr></tbody></table></div>`
    : '<p class="ds-text-muted">Aucune option n\'arrive à échéance ni n\'a été vendue cette semaine-là, pour ce filtre.</p>';

  const pos = optRouePositions({ cycles: v.cycles, legs: v.legs, stockTrades: v.stock, cashFlows: v.flows, contractSize: size, prices: roueState.prices });
  document.getElementById('roue-wk-positions').innerHTML = rouePositionsHTML(pos);

  // Semaine suivante et points à surveiller (toujours calculés sur les options OUVERTES).
  const nextWs = roueAddDays(ws, 7);
  const nextLegs = optWeekLegs(v.legs, nextWs).filter((l) => l.statut === 'ouvert' && optWeekStart(l.echeance) === nextWs);
  const openWeek = legs.filter((l) => l.statut === 'ouvert');
  const itm = openWeek.filter((l) => { const d = optStrikeDistance(l.type, roueState.prices[l.ticker], l.strike); return d != null && d < 0; });
  const libere = openWeek.filter((l) => l.type === 'put').reduce((a, l) => a + l.strike * l.contrats * size, 0);
  const earnBefore = v.legs.filter((l) => l.statut === 'ouvert').filter((l) => { const e = roueState.earnings[l.ticker]; const t = roueDaysUntil(l.echeance); return e != null && t != null && e >= 0 && e <= t; });
  const uniq = (a) => [...new Set(a)];
  const legName = (l) => `${optEsc(l.ticker)} ${optNum(l.strike)} ${l.type === 'put' ? 'P' : 'C'}`;
  document.getElementById('roue-wk-next-host').innerHTML = `<div style="overflow-x:auto"><table class="ds-table"><tbody>
    <tr><td>Échéances du ${fmt(roueAddDays(nextWs, 5))}</td><td class="is-num">${nextLegs.length ? nextLegs.map(legName).join(' · ') : 'aucune position ouverte'}</td></tr>
    <tr><td>Capital libéré si les puts expirent</td><td class="is-num">${roueMoney(libere, 0)}</td></tr>
    <tr><td>Dans la monnaie (assignation ou roulement probable)</td><td class="is-num">${itm.length ? itm.map(legName).join(' · ') : 'aucune'}</td></tr>
    <tr><td>Résultats avant l'échéance</td><td class="is-num">${earnBefore.length ? uniq(earnBefore.map((l) => `${optEsc(l.ticker)} (${roueState.earnings[l.ticker]} j)`)).join(' · ') : 'aucun connu'}</td></tr></tbody></table></div>`;

  const year = optWeekYear(ws);
  const yrLegs = v.legs.filter((l) => { const per = optPeriodOf(l.date_ouverture); return per != null && per.year === year; });
  const yrRules = yrLegs.map(roueLegRule).filter(Boolean);
  const weekBad = legs.filter((l) => { const r = roueLegRule(l); return r && !r.ok; });
  const sousCout = pos.rows.filter((r) => r.verif === 'sous_cout');
  const pertes = pos.rows.filter((r) => r.latentNet != null && r.latentNet < 0).sort((a, b) => a.latentNet - b.latentNet);
  const valeurC = snap.valeurCompte ?? snap.valeurRealisee;
  const items = [];
  if (pertes.length) items.push(`<strong>Latent ${roueMoney(pos.latentNet, 0)}</strong> (vs coût de base net) : ${pertes.map((r) => `${optEsc(r.ticker)} ${roueMoney(r.latentNet, 0)}`).join(', ')}.`);
  sousCout.forEach((r) => items.push(`<strong>${optEsc(r.ticker)} : call à ${optNum(r.call.strike)} sous le coût de base net (${optNum(r.coutDeBaseNet)})</strong> : une assignation verrouille une perte.`));
  if (yrRules.length) items.push(`<strong>Règle des ${OPTA_RULE_DEFAULT.pct} %</strong> : ${weekBad.length} prime${weekBad.length > 1 ? 's' : ''} sous le seuil cette semaine${weekBad.length ? ` (${weekBad.map((l) => optEsc(l.ticker)).join(', ')})` : ''} ; ${yrRules.filter((r) => !r.ok).length} sur ${yrRules.length} depuis janvier.`);
  if (earnBefore.length) items.push(`<strong>Résultats avant l'échéance</strong> : ${uniq(earnBefore.map((l) => `${optEsc(l.ticker)} dans ${roueState.earnings[l.ticker]} j`)).join(', ')}.`);
  if (valeurC > 0 && pos.capitalActions > 0) items.push(`<strong>Concentration</strong> : ${rouePct(pos.capitalActions / valeurC, 0)} du compte en actions assignées.`);
  document.getElementById('roue-wk-alerts').innerHTML = `<div class="roue-watch">
    <div class="roue-watch__title">À surveiller${items.length ? ` <span class="ds-text-hint">(${items.length})</span>` : ''}</div>${items.length ? `<ul>${items.map((i) => `<li>${i}</li>`).join('')}</ul>` : '<p class="metric-sub" style="text-align:left; margin:0;">Rien à signaler.</p>'}</div>`;
}

// Deux traits : valeur réalisée (actions au coût) et apports + primes nettes cumulées ; un dépôt
// (après le capital de départ) est marqué d'un trait vertical.
function roueValueLinesSVG(points) {
  if (points.length < 2) return '<p class="ds-text-muted">Pas assez de semaines (ou pas de capital de départ).</p>';
  const W = 640; const H = 220; const L = 46; const R = 84; const T = 12; const B = 22;
  const vals = points.flatMap((p) => [p.valeurRealisee, p.apportsPlusPrimes]).filter((x) => x != null);
  const min = Math.min(...vals); const max = Math.max(...vals); const span = max - min || 1;
  const X = (i) => L + (i * (W - L - R)) / (points.length - 1);
  const Y = (v) => T + (1 - (v - min) / span) * (H - T - B);
  const path = (key) => points.map((p, i) => (p[key] == null ? '' : `${i ? 'L' : 'M'}${X(i).toFixed(1)},${Y(p[key]).toFixed(1)}`)).join(' ');
  const last = points[points.length - 1];
  let y1 = Y(last.valeurRealisee); let y2 = Y(last.apportsPlusPrimes);
  if (Math.abs(y1 - y2) < 14) { const up = y1 <= y2; y1 += up ? -7 : 7; y2 += up ? 7 : -7; }
  const deposits = points.map((p, i) => (i > 0 && p.apport ? `<line x1="${X(i).toFixed(1)}" x2="${X(i).toFixed(1)}" y1="${T}" y2="${H - B}" stroke="var(--amber)" stroke-dasharray="2 3"><title>${p.apport > 0 ? 'Dépôt' : 'Retrait'} ${roueMoney(p.apport, 0)}</title></line>` : '')).join('');
  const ticks = [0, Math.floor((points.length - 1) / 2), points.length - 1].map((i) => `<text x="${X(i).toFixed(1)}" y="${H - 6}" font-size="9" text-anchor="middle" fill="var(--text-2)">${roueDayMonth(points[i].semaine)}</text>`).join('');
  return `<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="Valeur du compte et apports plus primes">
    <line x1="${L}" x2="${W - R}" y1="${T}" y2="${T}" stroke="var(--border)" stroke-dasharray="3 3"/><line x1="${L}" x2="${W - R}" y1="${H - B}" y2="${H - B}" stroke="var(--border)" stroke-dasharray="3 3"/>
    <text x="${L - 4}" y="${T + 4}" font-size="9" text-anchor="end" fill="var(--text-2)">${Math.round(max / 1000)}k</text><text x="${L - 4}" y="${H - B + 3}" font-size="9" text-anchor="end" fill="var(--text-2)">${Math.round(min / 1000)}k</text>
    ${deposits}${ticks}
    <path d="${path('apportsPlusPrimes')}" fill="none" stroke="var(--green)" stroke-width="1.5" stroke-dasharray="5 4"/>
    <path d="${path('valeurRealisee')}" fill="none" stroke="var(--accent)" stroke-width="1.75" stroke-linejoin="round"/>
    <text x="${W - R + 5}" y="${(y1 + 4).toFixed(1)}" font-size="10" font-weight="600" fill="var(--accent)">${roueMoney(last.valeurRealisee, 0)}</text>
    <text x="${W - R + 5}" y="${(y2 + 4).toFixed(1)}" font-size="10" font-weight="600" fill="var(--green)">${roueMoney(last.apportsPlusPrimes, 0)}</text></svg>
    <div class="metric-sub" style="text-align:left; display:flex; gap:14px; flex-wrap:wrap;"><span><span style="display:inline-block; width:16px; border-top:2px solid var(--accent); vertical-align:middle;"></span> Valeur réalisée (actions au coût)</span><span><span style="display:inline-block; width:16px; border-top:2px dashed var(--green); vertical-align:middle;"></span> Apports + primes nettes</span><span><span style="display:inline-block; height:10px; border-left:1px dashed var(--amber); vertical-align:middle;"></span> dépôt ou retrait</span></div>
    <p class="metric-sub" style="text-align:left;">Un dépôt fait monter les deux traits : il ne passe pas pour du rendement. L'écart = actions revendues, dividendes et autres revenus. Le latent n'est pas historisé (pas d'historique des cours ici) : il est dans « Valeur du compte » ci-dessus.</p>`;
}

function roueOutcomesHTML(o) {
  const rows = o.parMois.map((m, i) => ({ m, i, t: m.expire + m.rachete + m.assigne })).filter((r) => r.t);
  if (!rows.length) return '<p class="ds-text-muted">Aucune option close cette année.</p>';
  const seg = (n, t, c) => (n ? `<span style="display:block; width:${(n / t * 100).toFixed(1)}%; background:${c};"></span>` : '');
  return `${rows.map(({ m, i, t }) => `<div style="display:grid; grid-template-columns:80px 1fr 70px; gap:8px; align-items:center; font-size:12px; margin:4px 0;">
      <span>${ROUE_MOIS[i]}</span><span style="display:flex; height:10px; border-radius:3px; overflow:hidden; background:var(--surface-2);">${seg(m.expire, t, 'var(--green)')}${seg(m.rachete, t, 'var(--accent)')}${seg(m.assigne, t, 'var(--amber)')}</span>
      <span style="text-align:right; white-space:nowrap;" title="expirées · rachetées · assignées">${m.expire} · ${m.rachete} · ${m.assigne}</span></div>`).join('')}
    <div class="metric-sub" style="text-align:left; display:flex; gap:14px; flex-wrap:wrap; margin-top:4px;"><span style="color:var(--green);">■ expirées</span><span style="color:var(--accent);">■ rachetées (roulées comprises)</span><span style="color:var(--amber);">■ assignées</span></div>`;
}

function roueRankHTML(rows, total, n, autres) {
  if (!rows.length) return '<p class="ds-text-muted">Rien de réalisé cette année.</p>';
  const head = rows.slice(0, n);
  const rest = rows.slice(n);
  const reste = rest.reduce((a, r) => a + r.profit, 0);
  return roueHBarsHTML(head) + (rest.length ? `<div style="display:grid; grid-template-columns:110px 1fr 90px; gap:8px; font-size:12px; margin:3px 0;" class="ds-text-hint"><em>${rest.length} ${autres}</em><span></span><span style="text-align:right;">${roueMoney(reste, 0)}</span></div>` : '')
    + `<div style="display:grid; grid-template-columns:110px 1fr 90px; gap:8px; font-size:12px; margin-top:4px; border-top:1px solid var(--border); padding-top:4px;"><strong>Total</strong><span></span><strong style="text-align:right;">${roueMoney(total, 0)}</strong></div>`;
}

// Rendement de SPY sur la même période que le rendement composé (première semaine terminée de l'année → aujourd'hui).
function roueSpyReturn(fromDate) {
  const h = roueState.spy;
  if (!h || !h.length || !fromDate) return null;
  const start = optCloseOnOrBefore(h, roueAddDays(fromDate, -1));
  const end = h[h.length - 1].close;
  return start > 0 && end > 0 ? end / start - 1 : null;
}

async function roueLoadSpy() {
  if (roueState.spy) return;
  try {
    const { series } = await fetchJSON('/api/screening/history?tickers=SPY');
    const s = (series || []).find((x) => x.ticker === 'SPY');
    if (s && s.history && s.history.length) roueState.spy = s.history;
  } catch { /* comparaison indisponible : « — » */ }
}

function roueRenderDashboard() {
  const host = document.getElementById('roue-dash-metrics');
  if (!host) return;
  const v = roueView(roueState.filtres.annuel);
  const size = roueSize();
  const year = roueState.year;
  const d = optAnnualDashboard({ legs: v.legs, stockTrades: v.stock, cashFlows: v.flows, contractSize: size, year, prices: roueState.prices, sectors: roueState.sectors, today: roueToday() });
  const pos = optRouePositions({ cycles: v.cycles, legs: v.legs, stockTrades: v.stock, cashFlows: v.flows, contractSize: size, prices: roueState.prices });
  const out = optLegOutcomes(v.legs, year);
  const prem = optPremiumBreakdown(v.legs, year, { contractSize: size, sectors: roueState.sectors });
  const act = optRoueActivity(v.legs, year);
  const series = optValueSeries({ legs: v.legs, stockTrades: v.stock, cashFlows: v.flows, contractSize: size });
  const yrSeries = series.filter((w) => w.annee === year && w.semaine <= roueToday());
  const snap = d.capital;
  const valeur = snap.valeurCompte ?? snap.valeurRealisee;
  const apports = series.length ? series[series.length - 1].apports : null;
  const finies = d.semaines.filter((w) => w.roiHebdo != null && w.fin < roueToday());
  const spy = finies.length ? roueSpyReturn(finies[0].semaine) : null;
  const vsSpy = d.rendementCompose != null && spy != null ? d.rendementCompose - spy : null;
  const autres = d.profitRealise - prem.total;

  host.innerHTML = [
    roueMetric('Valeur du compte', roueMoney(valeur, 0), apports == null ? 'capital de départ à saisir' : `dont apports ${roueMoney(apports, 0)}${snap.valeurCompte == null ? ' · cours manquant' : ''}`),
    roueMetric('Profit réalisé', roueMoney(d.profitRealise, 0), `primes ${roueMoney(prem.total, 0)} · actions et dividendes ${roueMoney(autres, 0)}`, roueSignCls(d.profitRealise)),
    roueMetric('Rendement réalisé', roueSignedPct(d.rendementCompose, 2), d.rendementAnnualiseProjete == null ? 'projection : 4 semaines min.' : `projeté ${roueSignedPct(d.rendementAnnualiseProjete)}/an`, roueSignCls(d.rendementCompose)),
    roueMetric('Options closes', String(out.closes), `<span style="color:var(--green);">${out.expire} expirées</span> · <span style="color:var(--accent);">${out.rachete} rachetées</span> · <span style="color:var(--amber);">${out.assigne} assignées</span>`),
    roueMetric('Vs S&P 500', vsSpy == null ? '—' : `${vsSpy >= 0 ? '+' : ''}${(vsSpy * 100).toFixed(1)} pts`, spy == null ? 'historique SPY indisponible' : `SPY ${roueSignedPct(spy)} même période`, roueSignCls(vsSpy)),
    roueMetric('Profit réel ajusté', roueMoney(d.profitReelAjuste, 0), d.profitReelAjuste == null ? 'cours manquant' : 'réalisé + latent − call plafonné'),
    roueMetric('Latent des positions', pos.latentNet == null ? '—' : roueMoney(pos.latentNet, 0), `vs coût de base net · en perte ${roueMoney(pos.latentNegatif, 0)}`, roueSignCls(pos.latentNet)),
    roueMetric('Capital assigné', valeur > 0 ? rouePct(pos.capitalActions / valeur) : '—', `${roueMoney(pos.capitalActions, 0)} en actions`),
    roueMetric("Taux d'assignation", out.closes ? rouePct(out.assigne / out.closes) : '—', `${out.assigne} sur ${out.closes} closes`),
    roueMetric('Commissions', roueMoney(d.commissions), `dividendes ${roueMoney(d.dividendes, 0)}`),
  ].join('');

  document.getElementById('roue-dash-value').innerHTML = roueValueLinesSVG(yrSeries);
  document.getElementById('roue-dash-outcomes').innerHTML = roueOutcomesHTML(out)
    + '<p class="metric-sub" style="text-align:left;">Remplace le « taux de succès » : une assignation fait partie de la Roue, ce n\'est pas un échec.</p>';
  const mois = prem.parMois.map((p, i) => ({ cle: ROUE_MOIS[i], profit: p })).filter((r, i) => r.profit || prem.parMois.slice(0, i).some(Boolean) && prem.parMois.slice(i).some(Boolean));
  document.getElementById('roue-dash-months').innerHTML = roueRankHTML(mois, prem.total, 12, 'autres mois');
  document.getElementById('roue-dash-tickers').innerHTML = roueRankHTML(prem.parTicker, prem.total, 6, 'autres titres');
  const sansSecteur = prem.parTicker.filter((r) => roueState.sectors[r.cle] == null).length;
  document.getElementById('roue-dash-sectors').innerHTML = roueRankHTML(prem.parSecteur, prem.total, 5, 'autres secteurs')
    + (sansSecteur ? `<p class="metric-sub" style="text-align:left;">${sansSecteur} titre(s) sans secteur connu (Yahoo).</p>` : '');
  document.getElementById('roue-dash-positions').innerHTML = rouePositionsHTML(pos, { compact: true });
  document.getElementById('roue-dash-capital').innerHTML = `<table class="ds-table"><tbody>
    <tr><td>Actions détenues (au coût)</td><td class="is-num">${roueMoney(snap.capitalActions, 0)}</td></tr>
    <tr><td>Puts vendus (garantie)</td><td class="is-num">${roueMoney(snap.capitalPuts, 0)}</td></tr>
    <tr><td><strong>Utilisé</strong></td><td class="is-num"><strong>${roueMoney(snap.capitalImmobilise, 0)}</strong></td></tr>
    <tr><td>Restant (valeur réalisée − utilisé)</td><td class="is-num">${roueMoney(snap.capitalDisponible, 0)}</td></tr></tbody></table>
    <p class="metric-sub" style="text-align:left;">Vue cash-secured. Liquidité excédentaire sur marge : feature #442.</p>`;
  document.getElementById('roue-dash-activity').innerHTML = `<div class="metric-band" style="--cols:4;">
    ${roueMetric('Options', String(act.options), 'vendues dans l\'année')}${roueMetric('Put / call', `${act.puts} / ${act.calls}`)}
    ${roueMetric('Titres', String(act.titres))}${roueMetric('Durée moyenne', act.dureeMoyenne == null ? '—' : `${act.dureeMoyenne.toFixed(1)} j`, 'options closes')}</div>`;
}

// ---- H9 Import du Google Sheets du club (#436) ----

let roueImpState = null; // { plan, flows, fichier }

async function roueImpOnFile(ev) {
  const file = ev.target.files && ev.target.files[0];
  const status = document.getElementById('roue-imp-status');
  const host = document.getElementById('roue-imp-host');
  if (!file) return;
  status.textContent = 'Lecture…';
  host.innerHTML = '';
  try {
    let journalRows; let flows = [];
    if (/\.xlsx$/i.test(file.name)) {
      const sheets = await roueImpReadXlsx(await file.arrayBuffer());
      if (!sheets.JOURNAL) throw new Error('Onglet « JOURNAL » introuvable dans ce fichier.');
      journalRows = sheets.JOURNAL;
      flows = roueImpFlowsFromXlsx(sheets).map((f) => ({ ...f, include: true }));
    } else {
      journalRows = roueImpParseCsv(await file.text());
    }
    const journal = roueImpJournalRows(journalRows);
    await roueLoadData();
    const compte = document.getElementById('roue-imp-compte').value;
    const plan = roueImpPlan(journal, { today: roueToday(), compte, contractSize: roueSize(), existingLegs: roueState.legs, existingTrades: (await fetchJSON('/api/trades')).trades || [] });
    const existants = roueState.flows.filter((f) => f.compte === compte);
    for (const f of flows) if (existants.some((e) => e.type === f.type && e.date === f.date && Number(e.montant) === f.montant)) { f.include = false; f.doublon = true; }
    roueImpState = { plan, flows, fichier: file.name, stops: Object.create(null), compte };
    status.textContent = `${file.name} : ${journal.length} ligne(s) lue(s).`;
    roueImpRender();
  } catch (err) {
    status.textContent = 'Échec : ' + err.message;
  }
}

function roueImpBesoinStop(c) {
  return c.ops.some((o) => o.include && ((o.kind === 'jambe' && o.leg.type === 'put' && o.statut === 'assigne') || o.kind === 'achat'));
}

function roueImpRender() {
  const host = document.getElementById('roue-imp-host');
  if (!roueImpState) { host.innerHTML = ''; return; }
  const { plan, flows } = roueImpState;
  const r = plan.resume;
  const statutSel = (ci, oi, o) => `<select class="ds-select" style="width:auto;" onchange="roueImpSet(${ci},${oi},'statut',this.value)">${['ouvert', 'expire', 'assigne', 'rachete'].map((s) => `<option value="${s}"${s === o.statut ? ' selected' : ''}>${ROUE_STATUT_LABELS[s]}</option>`).join('')}</select>`;
  const rows = plan.cycles.map((c, ci) => {
    c.besoinStop = roueImpBesoinStop(c);
    const stop = c.besoinStop ? `<label class="metric-sub" style="display:inline-flex; gap:6px; align-items:center;">Stop de l'action * <input class="ds-input" type="number" step="0.01" style="width:100px;" value="${optEsc(roueImpState.stops[c.key] ?? '')}" data-stop-key="${optEsc(c.key)}"></label>` : '';
    const head = `<tr><td colspan="11" style="background:var(--surface-2);"><strong>${optEsc(c.ticker)}</strong> <span class="ds-text-hint">cycle ${optEsc(c.key)}${c.dejaCycleId ? ` · rattaché au cycle castellana #${c.dejaCycleId}` : ''}</span> ${stop}</td></tr>`;
    const ops = c.ops.map((o, oi) => {
      const flags = [o.doublon ? '<span class="ds-text-hint">déjà présente</span>' : '', o.issues && o.issues.length ? `<span style="color:var(--amber);" title="${optEsc(o.issues.join(' ; '))}">⚠ ${optEsc(o.issues.join(' ; '))}</span>` : ''].filter(Boolean).join(' ');
      const check = `<input type="checkbox"${o.include ? ' checked' : ''}${o.kind === 'inconnu' ? ' disabled' : ''} onchange="roueImpSet(${ci},${oi},'include',this.checked)">`;
      if (o.kind === 'jambe') {
        const l = o.leg;
        return `<tr><td>${check}</td><td class="is-num">${o.ligne}</td><td>${l.type}</td><td>${optEsc(l.date_ouverture || '—')}</td><td>${optEsc(l.echeance || '—')}</td>
          <td class="is-num">${l.strike ?? '—'}</td><td class="is-num">${l.contrats ?? '—'}</td><td class="is-num">${l.prime_recue ?? '—'}</td><td class="is-num">${l.commission_ouverture ?? ''}</td>
          <td>${statutSel(ci, oi, o)} <span class="ds-text-hint"${o.aVerifier ? ' style="color:var(--amber);"' : ''}>${optEsc(o.raison)}</span></td><td>${flags}</td></tr>`;
      }
      return `<tr><td>${check}</td><td class="is-num">${o.ligne}</td><td>${o.kind === 'inconnu' ? '?' : o.kind}</td><td colspan="2">${optEsc(o.date || '—')}</td>
        <td class="is-num">${o.prix ?? '—'}</td><td class="is-num">${o.actions ? o.actions + ' act.' : '—'}</td><td></td><td class="is-num">${o.commission ?? ''}</td><td></td><td>${flags}</td></tr>`;
    }).join('');
    return head + ops;
  }).join('');
  const flowsHTML = flows.length ? `<div class="metric-sub" style="text-align:left; font-weight:500; margin-top:0.75rem;">Capital et mouvements (onglets PORTFOLIO et RAPPORT HEBDO)</div>
    <table class="ds-table"><tbody>${flows.map((f, i) => `<tr><td><input type="checkbox"${f.include ? ' checked' : ''} onchange="roueImpState.flows[${i}].include=this.checked"></td><td>${optEsc(f.date)}</td><td>${optEsc(ROUE_FLOW_LABELS[f.type])}</td><td class="is-num">${roueMoney(f.montant)}</td><td class="ds-text-hint">${optEsc(f.source)}${f.doublon ? ' · déjà présent' : ''}</td></tr>`).join('')}</tbody></table>` : '';
  host.innerHTML = `
    <p class="metric-sub" style="text-align:left;">${r.lignes} ligne(s) : <strong>${r.aImporter} cochée(s)</strong>, ${r.doublons} déjà présente(s), ${r.incoherentes} incohérente(s), ${r.aVerifier} statut(s) à vérifier. Destination : compte <strong>${optEsc(roueImpState.compte)}</strong> (pour en changer, choisis le compte puis relis le fichier).</p>
    <div class="journal-actions" style="margin-bottom:0.5rem;">
      <label class="metric-sub" style="display:inline-flex; gap:6px; align-items:center;">Remplir les stops vides à <input class="ds-input" type="number" step="1" min="1" max="90" id="roue-imp-stop-pct" style="width:70px;"> % sous le prix d'achat</label>
      <button type="button" class="ds-btn" onclick="roueImpFillStops()">Remplir</button>
    </div>
    <div style="overflow-x:auto; max-height:520px; overflow-y:auto;"><table class="ds-table"><thead><tr><th></th><th class="is-num">Ligne</th><th>Type</th><th>Ouverture</th><th>Échéance</th><th class="is-num">Strike / prix</th><th class="is-num">Contrats</th><th class="is-num">Prime</th><th class="is-num">Commission</th><th>Statut (déduit)</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>
    ${flowsHTML}
    <div class="journal-actions" style="margin-top:0.75rem;"><button type="button" class="ds-btn ds-btn--primary" id="roue-imp-go" onclick="roueImpExecute()">Importer</button><button type="button" class="ds-btn" onclick="roueImpState=null; roueImpRender(); document.getElementById('roue-imp-file').value=''; document.getElementById('roue-imp-status').textContent='';">Annuler</button><span class="metric-sub" id="roue-imp-run"></span></div>
    <div id="roue-imp-report"></div>`;
}

function roueImpSet(ci, oi, field, value) {
  const o = roueImpState.plan.cycles[ci].ops[oi];
  o[field] = value;
  if (field === 'statut' && value !== 'rachete') o.primeCloture = 0;
  const ops = roueImpState.plan.cycles.flatMap((c) => c.ops);
  roueImpState.plan.resume.aImporter = ops.filter((x) => x.include).length;
  roueImpRender();
}

function roueImpFillStops() {
  const pct = parseFloat(document.getElementById('roue-imp-stop-pct').value);
  if (!(pct > 0 && pct < 100)) { alert('Indique un pourcentage entre 1 et 99.'); return; }
  for (const c of roueImpState.plan.cycles) {
    if (!roueImpBesoinStop(c) || roueImpState.stops[c.key]) continue;
    const ref = c.ops.find((o) => o.include && ((o.kind === 'jambe' && o.leg.type === 'put' && o.statut === 'assigne') || o.kind === 'achat'));
    const prix = ref.kind === 'achat' ? ref.prix : ref.leg.strike;
    roueImpState.stops[c.key] = (prix * (1 - pct / 100)).toFixed(2);
  }
  roueImpRender();
}

// Exécution : un cycle à la fois, opérations dans l'ordre chronologique (ouverture, clôture, achat,
// vente). Une erreur n'arrête pas le reste : elle est listée dans le compte rendu.
async function roueImpExecute() {
  const st = roueImpState;
  const compte = st.compte;
  const manque = st.plan.cycles.filter((c) => roueImpBesoinStop(c) && !(Number(st.stops[c.key]) > 0));
  if (manque.length) { alert(`Stop manquant pour : ${manque.map((c) => c.key).join(', ')}. Le Journal actions exige un stop pour chaque action ; il n'est jamais inventé.`); return; }
  if (!confirm(`Importer ${st.plan.resume.aImporter} ligne(s) dans le compte ${compte} ?`)) return;
  const btn = document.getElementById('roue-imp-go'); btn.disabled = true;
  const run = document.getElementById('roue-imp-run');
  const json = (method, body) => ({ method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const errors = []; const done = { cycles: 0, jambes: 0, clotures: 0, actions: 0, ventes: 0, dividendes: 0, mouvements: 0 };
  for (const c of st.plan.cycles) {
    const ops = c.ops.filter((o) => o.include && o.kind !== 'inconnu');
    if (!ops.length) continue;
    run.textContent = `Import de ${c.key}…`;
    let cycleId = c.dejaCycleId;
    try {
      if (!cycleId) { cycleId = (await fetchJSON('/api/option-cycles', json('POST', { ticker: c.ticker, compte, notes: `Importé du Journal de la Roue du club (${c.key})` }))).id; done.cycles++; }
    } catch (err) { errors.push(`${c.key} : création du cycle impossible — ${err.message}`); continue; }
    const stop = Number(st.stops[c.key]);
    const events = [];
    for (const o of ops) {
      if (o.kind === 'jambe') {
        events.push({ date: o.leg.date_ouverture, rang: 0, o, quoi: 'ouvrir' });
        if (o.statut !== 'ouvert') events.push({ date: o.leg.echeance, rang: 1, o, quoi: 'clore' });
      } else events.push({ date: o.date, rang: o.kind === 'achat' ? 2 : 3, o, quoi: o.kind });
    }
    events.sort((a, b) => (a.date === b.date ? a.rang - b.rang : (a.date < b.date ? -1 : 1)));
    for (const e of events) {
      const o = e.o;
      try {
        if (e.quoi === 'ouvrir') {
          o.id = (await fetchJSON('/api/option-trades', json('POST', { ...o.leg, cycle_id: cycleId, compte, source: 'import_sheets' }))).id; done.jambes++;
        } else if (e.quoi === 'clore') {
          if (!o.id) continue;
          const body = { statut: o.statut, dateCloture: o.leg.echeance, primeCloture: o.statut === 'rachete' ? (o.primeCloture || 0) : 0 };
          if (o.statut === 'assigne' && o.leg.type === 'put') body.stopInitial = stop;
          await fetchJSON(`/api/option-trades/${o.id}/close`, json('POST', body)); done.clotures++;
        } else if (e.quoi === 'achat') {
          await fetchJSON('/api/trades', json('POST', { date_entree: o.date, compte, ticker: o.ticker, prix_entree: o.prix, taille_position: o.actions, stop_initial: stop, option_cycle_id: cycleId, commission_entree: o.commission, source: 'import_sheets' })); done.actions++;
        } else if (e.quoi === 'vente') {
          const open = ((await fetchJSON(`/api/trades?open=true&ticker=${encodeURIComponent(o.ticker)}`)).trades || []).find((t) => t.option_cycle_id === cycleId);
          if (!open) { errors.push(`ligne ${o.ligne} (VENTE ${o.ticker}) : aucune action ouverte dans ce cycle à revendre`); continue; }
          const risque = open.prix_entree - open.stop_initial;
          await fetchJSON(`/api/trades/${open.id}`, json('PUT', { date_sortie: o.date, prix_sortie: o.prix, commission_sortie: o.commission, r_realise: risque ? (o.prix - open.prix_entree) / risque : null, resultat: o.prix >= open.prix_entree ? 'gagnant' : 'perdant' })); done.ventes++;
        }
      } catch (err) { errors.push(`ligne ${o.ligne} (${e.quoi}) : ${err.message}`); }
    }
    for (const o of ops) {
      if (!(o.dividendes > 0)) continue;
      try { await fetchJSON('/api/cash-flows', json('POST', { compte, type: 'dividende', date: o.kind === 'jambe' ? o.leg.echeance : o.date, montant: o.dividendes, ticker: c.ticker, cycle_id: cycleId, source: 'import_sheets' })); done.dividendes++; } catch (err) { errors.push(`ligne ${o.ligne} (dividende) : ${err.message}`); }
    }
    // Cycle clos si plus rien d'ouvert : aucune option ouverte, aucune action détenue (un cycle fait
    // seulement d'un achat puis d'une vente se ferme aussi).
    try {
      const cyc = await fetchJSON(`/api/option-cycles/${cycleId}`);
      const actionsOuvertes = ((await fetchJSON(`/api/trades?open=true&ticker=${encodeURIComponent(c.ticker)}`)).trades || []).some((t) => t.option_cycle_id === cycleId);
      if (cyc.legs.every((l) => l.statut !== 'ouvert') && !actionsOuvertes) await fetchJSON(`/api/option-cycles/${cycleId}`, json('PATCH', { statut: 'clos' }));
    } catch { /* le cycle reste actif, sans conséquence */ }
  }
  for (const f of st.flows.filter((x) => x.include)) {
    try { await fetchJSON('/api/cash-flows', json('POST', { compte, type: f.type, date: f.date, montant: f.montant, notes: f.source, source: 'import_sheets' })); done.mouvements++; } catch (err) { errors.push(`${f.source} : ${err.message}`); }
  }
  run.textContent = '';
  document.getElementById('roue-imp-host').innerHTML = `<p class="metric-sub" style="text-align:left;"><strong>Import terminé.</strong> ${done.cycles} cycle(s) créé(s), ${done.jambes} option(s), ${done.clotures} clôture(s), ${done.actions} achat(s), ${done.ventes} vente(s), ${done.dividendes} dividende(s), ${done.mouvements} mouvement(s).</p>`
    + (errors.length ? `<p class="metric-sub" style="text-align:left; color:var(--red);">${errors.length} erreur(s) :</p><ul class="metric-sub" style="text-align:left;">${errors.map((x) => `<li>${optEsc(x)}</li>`).join('')}</ul>` : '');
  roueImpState = null;
  await roueRefresh();
}

// ---- Orchestration ----

function roueRenderAll() {
  roueRenderCapital();
  roueRenderLegs();
  roueRenderPositions();
  roueRenderBilans();
  roueRefreshLegCycleOptions();
  roueSyncYearSelects();
  roueRenderWeeks();
  roueRenderWeek();
  roueRenderDashboard();
}

async function roueRefresh() {
  try {
    await roueLoadData();
    roueRenderAll();
    await Promise.all([roueLoadPrices(), roueLoadSectors(), roueLoadSpy()]);
    roueRenderCapital();
    roueRenderPositions();
    roueRenderWeek();
    roueRenderDashboard();
    roueLoadBilans();
  } catch (err) {
    document.getElementById('roue-legs-host').innerHTML = `<p class="ds-text-muted">Échec du chargement : ${optEsc(err.message)}</p>`;
  }
}

async function renderRoueTab() {
  const host = document.getElementById('roue-content');
  host.innerHTML = roueShellHTML();
  if (typeof uiIdsNumber === 'function') uiIdsNumber();
  try { const saved = localStorage.getItem('castellana-roue-compte'); if (saved === 'tout' || ROUE_COMPTES.includes(saved)) roueState.compte = saved; } catch { /* navigation privée */ }
  const sel = document.getElementById('roue-compte');
  sel.value = roueState.compte;
  const syncDest = () => ['roue-flow-compte', 'roue-leg-compte', 'roue-imp-compte'].forEach((id) => { document.getElementById(id).value = roueDefaultCompte(); });
  syncDest();
  document.getElementById('roue-flow-compte').addEventListener('change', roueRefreshFlowCycleOptions);
  document.getElementById('roue-leg-compte').addEventListener('change', roueRefreshLegCycleOptions);
  sel.addEventListener('change', async () => {
    roueState.compte = sel.value;
    syncDest();
    try { localStorage.setItem('castellana-roue-compte', sel.value); } catch { /* sans effet */ }
    roueRenderAll();
    await Promise.all([roueLoadPrices(), roueLoadSectors()]);
    roueRenderCapital();
    roueRenderPositions();
    roueRenderWeek();
    roueRenderDashboard();
  });
  document.querySelectorAll('.roue-year').forEach((ys) => ys.addEventListener('change', () => {
    roueState.year = Number(ys.value);
    roueSyncYearSelects();
    roueRenderWeeks();
    roueRenderDashboard();
  }));
  roueState.weekStart = roueWeekOf();
  document.getElementById('roue-wk-prev').addEventListener('click', () => { roueState.weekStart = roueAddDays(roueState.weekStart, -7); roueRenderWeek(); });
  document.getElementById('roue-wk-next').addEventListener('click', () => { roueState.weekStart = roueAddDays(roueState.weekStart, 7); roueRenderWeek(); });
  document.getElementById('roue-wk-today').addEventListener('click', () => { roueState.weekStart = roueWeekOf(); roueRenderWeek(); });
  document.getElementById('roue-flow-date').value = roueToday();
  document.getElementById('roue-leg-ouverture').value = roueToday();
  document.getElementById('roue-flow-save').addEventListener('click', roueSaveFlow);
  document.getElementById('roue-leg-save').addEventListener('click', roueSaveLeg);
  document.getElementById('roue-leg-ticker').addEventListener('change', roueRefreshLegCycleOptions);
  document.getElementById('roue-close-statut').addEventListener('change', roueSyncCloseForm);
  document.getElementById('roue-close-ok').addEventListener('click', roueConfirmClose);
  document.getElementById('roue-close-cancel').addEventListener('click', () => document.getElementById('roue-close-dialog').close());
  document.getElementById('roue-bilan-refresh').addEventListener('click', roueLoadBilans);
  document.getElementById('roue-imp-file').addEventListener('change', roueImpOnFile);
  // Stops de l'import : la clé du cycle vient du FICHIER, elle ne passe donc jamais par un gestionnaire en ligne
  // (l'échappement HTML ne protège pas un texte placé dans du JavaScript) : attribut de données + écouteur délégué.
  document.getElementById('roue-imp-host').addEventListener('input', (e) => {
    const k = e.target && e.target.dataset ? e.target.dataset.stopKey : undefined;
    if (k !== undefined && roueImpState) roueImpState.stops[k] = e.target.value;
  });
  host.addEventListener('change', roueOnSelChange);
  host.addEventListener('click', roueOnSelClick);
  document.getElementById('roue-prices-refresh').addEventListener('click', async () => { roueState.prices = {}; await roueLoadPrices(); roueRenderCapital(); roueRenderPositions(); roueRenderWeek(); roueRenderDashboard(); });
  await roueRefresh();
}

// Flag roue_tab (défaut OFF) : révèle l'onglet, et les lignes d'état des sections de Screener Prime
// qu'il améliore ou remplace (classe .roue-etat, visible seulement sous html.roue-on).
async function initRoueVisibility() {
  try {
    const { flags } = await fetchJSON('/api/flags');
    if (flags && flags.roue_tab === true) {
      const btn = document.getElementById('tab-btn-roue');
      if (btn) btn.style.display = '';
      document.documentElement.classList.add('roue-on');
      renderRoueTab();
    }
  } catch { /* onglet caché */ }
}
