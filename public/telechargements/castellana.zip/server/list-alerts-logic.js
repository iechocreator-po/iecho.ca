// Alertes sur les listes — LOGIQUE PURE (aucun accès base, réseau ni horloge
// cachée), testée dans server/list-alerts.test.js. L'orchestration (base,
// screening, courriel) vit dans server/list-alerts.js.
//
// Principe : une alerte se déclenche sur une TRANSITION, jamais sur un état
// continu. Pour chaque (règle, titre) on garde le dernier état connu ; on
// notifie quand l'état passe de « pas déclenché » à « déclenché ». Sans ça, un
// titre « prêt » depuis trois jours renverrait un courriel à chaque passage.
//
//   - Le PREMIER passage d'une règle enregistre l'état actuel SANS alerter
//     (`baselined` faux) : créer la règle ne doit pas noyer l'utilisateur sous
//     les titres qui sont déjà dans la situation décrite.
//   - Un titre absent de l'état précédent (ajouté à la liste depuis) est traité
//     de la même façon : première observation, aucune alerte.
//   - Une donnée manquante (état null) ne modifie JAMAIS l'état mémorisé : un
//     trou de données ne doit pas faire croire à un franchissement.

const fmt = (v, d = 1) => (v == null ? '—' : Number(v).toFixed(d));

export const ALERT_TYPES = {
  setup_pret: {
    label: 'Le setup devient « prêt »',
    needs: 'screening',
    defaults: {},
    validate: () => ({}),
    stateOf: (r) => r.verdict ?? null,
    fires: (prev, cur) => cur === 'prêt' && prev != null && prev !== 'prêt',
    message: (r) => `${r.ticker} : setup « prêt » (Setup ${fmt(r.setupScore, 0)}, Contexte ${fmt(r.contexteScore, 0)}${r.alignmentAge != null ? `, signal de ${r.alignmentAge} séance(s)` : ''})`,
  },
  alignement_perdu: {
    label: 'L\'alignement des moyennes est perdu (sortie)',
    needs: 'screening',
    defaults: {},
    validate: () => ({}),
    stateOf: (r) => r.smaAlignment ?? null,
    fires: (prev, cur) => prev === 'haussier' && cur != null && cur !== 'haussier',
    message: (r) => `${r.ticker} : l'alignement haussier des moyennes est perdu (maintenant « ${r.smaAlignment} ») — signal de sortie de la stratégie`,
  },
  rsi_seuil: {
    label: 'Le RSI franchit un seuil',
    needs: 'screening',
    defaults: { sens: 'above', seuil: 70 },
    validate: (p) => {
      const sens = p?.sens === 'below' ? 'below' : p?.sens === 'above' ? 'above' : null;
      const seuil = Number(p?.seuil);
      if (!sens) throw new Error('RSI : le sens doit être « au-dessus » ou « en dessous ».');
      if (!Number.isFinite(seuil) || seuil <= 0 || seuil >= 100) throw new Error('RSI : le seuil doit être entre 0 et 100.');
      return { sens, seuil };
    },
    stateOf: (r, p) => (r.rsi == null ? null : (r.rsi >= p.seuil ? 'above' : 'below')),
    fires: (prev, cur, p) => prev != null && cur === p.sens && prev !== p.sens,
    message: (r, p) => `${r.ticker} : RSI ${fmt(r.rsi)} — passé ${p.sens === 'above' ? 'au-dessus' : 'sous'} ${p.seuil}`,
  },
  resultats_imminents: {
    label: 'Résultats trimestriels imminents',
    needs: 'screening',
    defaults: { jours: 7 },
    validate: (p) => {
      const jours = Number(p?.jours);
      if (!Number.isInteger(jours) || jours < 1 || jours > 60) throw new Error('Résultats : le nombre de jours doit être un entier entre 1 et 60.');
      return { jours };
    },
    stateOf: (r, p) => (r.daysToEarnings == null ? null : (r.daysToEarnings <= p.jours ? 'in' : 'out')),
    fires: (prev, cur) => prev === 'out' && cur === 'in',
    message: (r) => `${r.ticker} : résultats dans ${r.daysToEarnings} jour(s)`,
  },
  prime_put: {
    label: 'Un put offre un rendement annualisé élevé',
    needs: 'premiums',
    defaults: { rendementMin: 25 },
    validate: (p) => {
      const rendementMin = Number(p?.rendementMin);
      if (!Number.isFinite(rendementMin) || rendementMin <= 0 || rendementMin > 1000) throw new Error('Prime : le rendement annualisé minimal doit être entre 0 et 1000 %.');
      return { rendementMin };
    },
    // Ici `r` est la ligne du screener de primes (meilleur put dans la plage de delta de la Roue) ;
    // un titre sans put exploitable est « out », pas une donnée manquante.
    stateOf: (r, p) => (r && r.annualizedYield != null && r.annualizedYield >= p.rendementMin ? 'in' : 'out'),
    fires: (prev, cur) => prev === 'out' && cur === 'in',
    message: (r) => `${r.ticker} : put ${r.strike} $ échéance ${r.expiry} (${r.dte} j) — rendement annualisé ${fmt(r.annualizedYield)} % (delta ${fmt(r.delta, 2)}, prime ${fmt(r.premium, 2)} $)`,
  },
};

export function validateRuleParams(type, params) {
  const def = ALERT_TYPES[type];
  if (!def) throw new Error(`Type d'alerte inconnu : « ${type} ».`);
  return def.validate({ ...def.defaults, ...(params || {}) });
}

// Une liste de référence valide : watchlist, mag7 ou liste perso. L'univers
// élargi est refusé (219 titres : trop lourd pour une évaluation planifiée).
export function isValidListRef(ref) {
  return ref === 'watchlist' || ref === 'mag7' || /^list:\d+$/.test(String(ref));
}

/**
 * Évalue UNE règle.
 * @param rule        { type, params, baselined }
 * @param rowsByTicker Map ticker → ligne (screening, ou screener de primes selon le type)
 * @param prevStates  Map ticker → dernier état enregistré
 * @returns { states: Map ticker → état à enregistrer, notifications: [{ticker, message}] }
 */
export function evaluateRule(rule, rowsByTicker, prevStates, tickers) {
  const def = ALERT_TYPES[rule.type];
  const states = new Map();
  const notifications = [];
  for (const ticker of tickers) {
    const row = rowsByTicker.get(ticker);
    const prev = prevStates.get(ticker) ?? null;
    const cur = def.needs === 'premiums' ? def.stateOf(row ? { ...row, ticker } : null, rule.params) : (row ? def.stateOf(row, rule.params) : null);
    if (cur == null) { if (prev != null) states.set(ticker, prev); continue; } // donnée manquante : on garde l'état
    states.set(ticker, cur);
    if (rule.baselined && def.fires(prev, cur, rule.params)) {
      notifications.push({ ticker, message: def.message({ ...row, ticker }, rule.params) });
    }
  }
  return { states, notifications };
}

// Le passage automatique ne tourne que pendant les heures d'activité des marchés
// (jours ouvrables, 9 h à 17 h, heure de New York) : hors de cette fenêtre, les
// données ne bougent pas et chaque passage coûterait des appels pour rien.
export function isMarketWindow(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', weekday: 'short', hour: 'numeric', hour12: false }).formatToParts(date);
  const wd = parts.find((p) => p.type === 'weekday').value;
  const hour = Number(parts.find((p) => p.type === 'hour').value) % 24;
  return !['Sat', 'Sun'].includes(wd) && hour >= 9 && hour < 17;
}

// Corps du courriel groupé (texte simple) : une section par liste.
export function buildDigest(groups) {
  const total = groups.reduce((n, g) => n + g.items.length, 0);
  const lines = [`castellana — ${total} alerte(s)`, ''];
  for (const g of groups) {
    lines.push(`■ ${g.listLabel} — ${g.ruleLabel}`);
    for (const it of g.items) lines.push(`  • ${it}`);
    lines.push('');
  }
  lines.push('Données Yahoo Finance différées d\'environ 15 minutes. Outil d\'aide à la décision, pas un conseil en investissement.');
  return { subject: `castellana : ${total} alerte(s)`, text: lines.join('\n') };
}
