// Paramètres de l'app locale (8/10/2026) : balayage S&P 500 planifié (case à cocher,
// DÉSACTIVÉ par défaut) et destinataires des alertes par courriel (0, 1 ou n adresses).
// Stockés dans la table `preferences` sous des clés `app_*` (préservées par la
// réinitialisation des périodes, voir preferences.js).
import { db } from './db.js';
import { alertRecipient } from './alert-email.js';

const get = db.prepare('SELECT value FROM preferences WHERE key = ?');
const put = db.prepare('INSERT INTO preferences (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
export const MAX_EMAILS = 10;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/**
 * Pure : normalise des adresses (trim, minuscules, sans doublon). Lève si invalide.
 * Accepte une CHAÎNE séparée par des virgules (format de l'écran : « a@x.com, b@y.ca »; point-virgule
 * et saut de ligne tolérés aussi) ou un tableau. La chaîne est découpée ici, côté serveur : l'API n'a
 * pas à faire confiance au découpage du navigateur.
 */
export function normalizeEmails(input) {
  const list = typeof input === 'string' ? input.split(/[,;\n]+/) : input;
  if (!Array.isArray(list)) throw new Error('La liste de courriels est invalide.');
  const out = [];
  for (const raw of list) {
    const e = String(raw ?? '').trim().toLowerCase();
    if (!e) continue;
    if (!EMAIL_RE.test(e)) throw new Error(`Adresse invalide : « ${e} ».`);
    if (!out.includes(e)) out.push(e);
  }
  if (out.length > MAX_EMAILS) throw new Error(`Maximum ${MAX_EMAILS} adresses.`);
  return out;
}

export function getSweepAuto() { return get.get('app_sweep_auto')?.value === '1'; }

// Destinataires : la liste enregistrée dans l'app fait foi (même vide = aucun courriel).
// Tant qu'elle n'a jamais été enregistrée, on retombe sur ALERT_EMAIL du .env (comportement d'avant).
export function getAlertEmails() {
  const row = get.get('app_alert_emails');
  if (row) { try { return normalizeEmails(JSON.parse(row.value)); } catch { return []; } }
  const legacy = alertRecipient();
  return legacy ? [legacy] : [];
}

// Publication du balayage vers la version en ligne (17/10/2026) — décochée par défaut.
export function getPublishCloud() { return get.get('app_publish_cloud')?.value === '1'; }

// Alertes de positions (#379) — décision de l'utilisateur (Réglages) : tout activer ou couper, choisir chaque situation, et dire si le
// courriel part ou si l'alerte reste seulement dans la boîte de l'app. Tout est ACTIVÉ par défaut (comportement d'avant la case).
export const POSITION_ALERT_KINDS = ['echeance', 'profit', 'stop'];
export const POSITION_ALERT_DEFAULTS = { enabled: true, kinds: { echeance: true, profit: true, stop: true }, email: true };

/** Pure : fusionne un patch partiel dans l'état courant; seuls des booléens sont acceptés. */
export function normalizePositionAlerts(patch, current = POSITION_ALERT_DEFAULTS) {
  if (patch == null || typeof patch !== 'object' || Array.isArray(patch)) throw new Error('Réglages d\'alertes de positions invalides.');
  const out = { enabled: current.enabled, kinds: { ...current.kinds }, email: current.email };
  for (const k of ['enabled', 'email']) {
    if (k in patch) { if (typeof patch[k] !== 'boolean') throw new Error(`« ${k} » doit être vrai ou faux.`); out[k] = patch[k]; }
  }
  if ('kinds' in patch) {
    if (patch.kinds == null || typeof patch.kinds !== 'object') throw new Error('« kinds » doit être un objet.');
    for (const [k, v] of Object.entries(patch.kinds)) {
      if (!POSITION_ALERT_KINDS.includes(k)) throw new Error(`Situation inconnue : « ${k} ».`);
      if (typeof v !== 'boolean') throw new Error(`« ${k} » doit être vrai ou faux.`);
      out.kinds[k] = v;
    }
  }
  return out;
}

/** Pure : les situations qui VIENNENT d'être (ré)activées. Leur état mémorisé est périmé : la prochaine observation redevient la référence. */
export function kindsReenabled(before, after) {
  return POSITION_ALERT_KINDS.filter((k) => {
    const wasOn = before.enabled && before.kinds[k];
    const isOn = after.enabled && after.kinds[k];
    return isOn && !wasOn;
  });
}

export function getPositionAlertSettings() {
  const row = get.get('app_position_alerts');
  if (!row) return { ...POSITION_ALERT_DEFAULTS, kinds: { ...POSITION_ALERT_DEFAULTS.kinds } };
  try { return normalizePositionAlerts(JSON.parse(row.value)); } catch { return { ...POSITION_ALERT_DEFAULTS, kinds: { ...POSITION_ALERT_DEFAULTS.kinds } }; }
}

export function getAppSettings() {
  const row = get.get('app_alert_emails');
  return { sweepAuto: getSweepAuto(), publishCloud: getPublishCloud(), alertEmails: getAlertEmails(), emailsFromEnv: !row && getAlertEmails().length > 0, positionAlerts: getPositionAlertSettings() };
}

/**
 * Pure : valide TOUT le patch et rend la liste des écritures [clé, valeur] — lève avant d'avoir écrit quoi que ce soit.
 * Un courriel invalide ne doit pas laisser le balayage automatique ou la publication en ligne activés par la moitié de la requête
 * (audit routes locales, 21/10/2026).
 */
export function planAppSettingsWrites(rawPatch, currentPositionAlerts = POSITION_ALERT_DEFAULTS) {
  const patch = rawPatch || {};
  const writes = [];
  if ('sweepAuto' in patch) writes.push(['app_sweep_auto', patch.sweepAuto === true ? '1' : '0']);
  if ('publishCloud' in patch) writes.push(['app_publish_cloud', patch.publishCloud === true ? '1' : '0']);
  if ('alertEmails' in patch) writes.push(['app_alert_emails', JSON.stringify(normalizeEmails(patch.alertEmails))]);
  if ('positionAlerts' in patch) writes.push(['app_position_alerts', JSON.stringify(normalizePositionAlerts(patch.positionAlerts, currentPositionAlerts))]);
  return writes;
}

export function setAppSettings(rawPatch) {
  const writes = planAppSettingsWrites(rawPatch, getPositionAlertSettings());
  db.transaction(() => { for (const [k, v] of writes) put.run(k, v); })();
  return getAppSettings();
}
