// Tests unitaires sur les fonctions PURES de indicators.js (aucun appel
// réseau, aucun mock) — amélioration demandée par JP (31/8/2026) après que
// deux bugs réels aient été trouvés uniquement en testant à la main cette
// session (fetchJSON cassé, script sidecar cassé sur Windows). `node:test`
// natif (Node 22), zéro dépendance ajoutée — cohérent avec le reste du
// projet. Lancer avec `npm test`.
//
// Les fonctions qui appellent Yahoo Finance (getHomemadeIndicators,
// fetchDailyHistory, getHomemadeIndicatorsBatch, checkYahooConnection)
// restent hors périmètre : pas d'infrastructure de mock dans ce projet,
// testées manuellement en direct comme le reste de l'app.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { computeSMA, computeOBV, computeTrueRange, computeATR, computeVolumeVs20d, computeRSI, computeAlignmentSeries, alignmentAgeFrom, computeAverageVolume, VOLUME_AVG_PERIOD, computePreviousClose } from './indicators.js';

test('computeSMA — fenêtre glissante sur une série connue', () => {
  const closes = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  assert.deepEqual(computeSMA(closes, 3), [null, null, 2, 3, 4, 5, 6, 7, 8, 9]);
});

test('computeSMA — historique plus court que la période retourne tout null', () => {
  assert.deepEqual(computeSMA([1, 2], 5), [null, null]);
});

test('computeOBV — cumul +volume/-volume/inchangé selon la clôture', () => {
  const bars = [
    { close: 10, volume: 100 },
    { close: 12, volume: 100 }, // hausse -> +100
    { close: 11, volume: 100 }, // baisse -> -100
    { close: 11, volume: 100 }, // inchangé -> +0
    { close: 13, volume: 100 }, // hausse -> +100
  ];
  assert.deepEqual(computeOBV(bars), [0, 100, 0, 0, 100]);
});

test('computeVolumeVs20d — le jour courant est exclu de sa propre moyenne', () => {
  const bars = [
    ...Array.from({ length: 20 }, () => ({ volume: 1000 })),
    { volume: 3000 }, // 21e barre, jour courant
  ];
  assert.deepEqual(computeVolumeVs20d(bars), { ratio: 3, volumeSMA20: 1000 });
});

test('computeVolumeVs20d — moins de 21 barres retourne null explicite (pas 0)', () => {
  const bars = Array.from({ length: 5 }, () => ({ volume: 1000 }));
  assert.deepEqual(computeVolumeVs20d(bars), { ratio: null, volumeSMA20: null });
});

test('computeTrueRange — max(high-low, |high-clôture veille|, |low-clôture veille|)', () => {
  const bars = [
    { high: 10, low: 8, close: 9 },
    { high: 12, low: 9, close: 11 },
    { high: 13, low: 11, close: 12 },
    { high: 15, low: 12, close: 14 },
  ];
  assert.deepEqual(computeTrueRange(bars), [2, 3, 2, 3]);
});

test('computeATR — lissage Wilder (RMA) appliqué au True Range, pas une SMA', () => {
  const bars = [
    { high: 10, low: 8, close: 9 },
    { high: 12, low: 9, close: 11 },
    { high: 13, low: 11, close: 12 },
    { high: 15, low: 12, close: 14 },
  ];
  // TR = [2,3,2,3] (vérifié par le test précédent). RMA(period=2) à la main :
  // out[1] = (2+3)/2 = 2.5 ; out[2] = (2.5*1+2)/2 = 2.25 ; out[3] = (2.25*1+3)/2 = 2.625
  assert.deepEqual(computeATR(bars, 2), [null, 2.5, 2.25, 2.625]);
});

// --- RSI (ajouté le 7/9/2026, repris du sidecar tradingview-mcp) --------
// Les cas ci-dessous sont DÉRIVABLES à la main plutôt que recopiés d'une
// exécution : un test qui fige la sortie du code qu'il teste ne prouve rien.

test('computeRSI vaut 100 quand il n\'y a que des hausses', () => {
  // loss = 0 → RS infini → RSI = 100, par définition de Wilder.
  const closes = Array.from({ length: 30 }, (_, i) => 100 + i);
  assert.equal(computeRSI(closes, 14), 100);
});

test('computeRSI vaut exactement 50 sur l\'amorce quand gains et pertes se compensent', () => {
  // Exactement period+1 clôtures : seule l'amorce (moyenne simple sur 14
  // variations) est utilisée, la boucle de lissage ne s'exécute pas.
  // 7 hausses de +1 et 7 baisses de -1 → RS = 1 → RSI = 100 - 100/2 = 50.
  const closes = Array.from({ length: 15 }, (_, i) => (i % 2 === 0 ? 100 : 101));
  assert.ok(Math.abs(computeRSI(closes, 14) - 50) < 1e-9);
});

test('computeRSI reste proche de 50 sur une longue alternance', () => {
  // Au-delà de l'amorce, le lissage de Wilder OSCILLE autour de 50 sans
  // jamais y revenir exactement : la dernière variation penche d'un côté.
  // C'est le comportement correct de Wilder, pas une imprécision — d'où une
  // assertion d'encadrement plutôt que d'égalité.
  const closes = Array.from({ length: 41 }, (_, i) => (i % 2 === 0 ? 100 : 101));
  const rsi = computeRSI(closes, 14);
  assert.ok(Math.abs(rsi - 50) < 5, `RSI ${rsi} trop éloigné de 50`);
  assert.ok(rsi < 50, 'la série se termine sur une baisse, le RSI doit passer sous 50');
});

test('computeRSI tend vers 0 quand il n\'y a que des baisses', () => {
  const closes = Array.from({ length: 30 }, (_, i) => 100 - i);
  assert.ok(computeRSI(closes, 14) < 1e-9);
});

test('computeRSI reste borné entre 0 et 100 sur une série irrégulière', () => {
  const closes = [44, 44.3, 44.1, 44.6, 43.4, 44.1, 44.2, 44.5, 43.4, 43.6, 44.3, 44.8, 45.1, 45.6, 45.9, 46.2, 45.7, 46.4, 46.2, 45.6, 46.2];
  const rsi = computeRSI(closes, 14);
  assert.ok(rsi > 0 && rsi < 100, `RSI hors bornes : ${rsi}`);
});

test('computeRSI répond null plutôt que d\'inventer sur un historique trop court', () => {
  // « Pas calculable » doit rester distinct de « valeur neutre » : c'est
  // exactement la confusion que l'audit reprochait aux trous silencieux.
  assert.equal(computeRSI([1, 2, 3], 14), null);
  assert.equal(computeRSI(Array.from({ length: 14 }, (_, i) => i), 14), null);
  assert.ok(computeRSI(Array.from({ length: 15 }, (_, i) => i), 14) !== null);
});

test('computeRSI respecte réellement la période demandée', () => {
  // Le sidecar imposait 14 ; le calcul maison rend la période configurable.
  // Deux périodes différentes sur la même série doivent diverger.
  const closes = [44, 44.3, 44.1, 44.6, 43.4, 44.1, 44.2, 44.5, 43.4, 43.6, 44.3, 44.8, 45.1, 45.6, 45.9, 46.2, 45.7, 46.4, 46.2, 45.6, 46.2];
  assert.notEqual(computeRSI(closes, 7), computeRSI(closes, 14));
});

// --- Alignement de tendance et fraîcheur du signal (11/9/2026) ---------

const PER = { fast: 3, medium: 5, slow: 10 };

test('une série strictement croissante est alignée à la hausse', () => {
  const closes = Array.from({ length: 40 }, (_, i) => 100 + i);
  const serie = computeAlignmentSeries(closes, PER);
  assert.equal(serie[serie.length - 1], 'haussier');
});

test('une série strictement décroissante est alignée à la baisse', () => {
  const closes = Array.from({ length: 40 }, (_, i) => 200 - i);
  const serie = computeAlignmentSeries(closes, PER);
  assert.equal(serie[serie.length - 1], 'baissier');
  assert.equal(alignmentAgeFrom(serie), null, 'un alignement BAISSIER n’a pas d’âge haussier');
});

test('la série vaut null tant que la moyenne lente n’existe pas', () => {
  const closes = Array.from({ length: 40 }, (_, i) => 100 + i);
  const serie = computeAlignmentSeries(closes, PER);
  assert.equal(serie[PER.slow - 2], null, 'avant la 10e barre, rien n’est calculable');
  assert.notEqual(serie[PER.slow - 1], null);
});

test('l’âge du signal ne peut pas précéder le retournement qui l’a créé', () => {
  // 30 barres en baisse, puis 12 en hausse franche : l’alignement haussier
  // ne peut pas dater d’avant la 30e barre.
  const closes = [
    ...Array.from({ length: 30 }, (_, i) => 200 - i),
    ...Array.from({ length: 12 }, (_, i) => 170 + i * 4),
  ];
  const age = alignmentAgeFrom(computeAlignmentSeries(closes, PER));
  assert.ok(age != null && age <= 12, `âge ${age} : impossible, le retournement date de 12 barres`);
});

test('un alignement interrompu puis repris repart à un âge court', () => {
  // C’est tout l’intérêt du champ : distinguer un signal qui vient de se
  // (re)former d’un signal ancien et continu.
  const monte = (dep, n, pas = 3) => Array.from({ length: n }, (_, i) => dep + i * pas);
  const closes = [...monte(100, 25), ...Array.from({ length: 6 }, (_, i) => 175 - i * 6), ...monte(140, 8)];
  const age = alignmentAgeFrom(computeAlignmentSeries(closes, PER));
  assert.ok(age == null || age <= 8, `âge ${age} : la rupture au milieu doit avoir remis le compteur à zéro`);
});

// ---- computeAverageVolume (20/9/2026) ----
test('computeAverageVolume : moyenne des N séances précédentes, jour courant exclu', () => {
  // 5 barres de volume 10,20,30,40 puis la barre du jour à 1000 (en cours).
  const bars = [10, 20, 30, 40, 1000].map((volume) => ({ volume }));
  // Fenêtre de 4 : (10+20+30+40)/4 = 25 — le 1000 du jour ne doit pas gonfler la référence.
  assert.equal(computeAverageVolume(bars, 4), 25);
  // Fenêtre de 2 : les deux séances complètes les plus récentes, (30+40)/2 = 35.
  assert.equal(computeAverageVolume(bars, 2), 35);
});

test("computeAverageVolume : null plutôt qu'une moyenne sur moins de séances qu'annoncé", () => {
  const bars = [10, 20, 30].map((volume) => ({ volume }));
  assert.equal(computeAverageVolume(bars, 3), null); // il faut period + 1 barres (le jour + 3)
  assert.equal(computeAverageVolume(bars, 2), 15);
  assert.equal(computeAverageVolume([], 100), null);
  // Une barre au volume manquant invalide la moyenne au lieu de la fausser.
  assert.equal(computeAverageVolume([{ volume: 10 }, { volume: null }, { volume: 5 }], 2), null);
});

test('computeAverageVolume : la période par défaut est 100', () => {
  assert.equal(VOLUME_AVG_PERIOD, 100);
  const bars = Array.from({ length: 101 }, (_, i) => ({ volume: i < 100 ? 200 : 999 }));
  assert.equal(computeAverageVolume(bars), 200);
  assert.equal(computeAverageVolume(bars.slice(1)), null); // 100 barres : il en manque une
});

// ---- computePreviousClose (20/9/2026) ----
// Barres à 13:30 UTC (= 9:30 à New York), comme les barres quotidiennes de Yahoo.
const bar = (iso, close) => ({ date: new Date(`${iso}T13:30:00Z`), close });
const SEMAINE = [bar('2026-09-14', 100), bar('2026-09-15', 101), bar('2026-09-16', 102), bar('2026-09-17', 103), bar('2026-09-18', 104)]; // lun→ven

test('computePreviousClose : en séance, la barre du jour est exclue → la veille', () => {
  const bars = [...SEMAINE, bar('2026-09-21', 999)]; // lundi en cours, volume/prix partiels
  const now = new Date('2026-09-21T15:00:00Z'); // lundi 11 h à New York
  assert.deepEqual(computePreviousClose(bars, now), { close: 104, date: '2026-09-18' });
});

test('computePreviousClose : le week-end retombe sur le vendredi (pas le jeudi)', () => {
  const now = new Date('2026-09-19T15:00:00Z'); // samedi
  assert.deepEqual(computePreviousClose(SEMAINE, now), { close: 104, date: '2026-09-18' });
});

test('computePreviousClose : le matin avant l\'ouverture, la dernière barre est déjà « la veille »', () => {
  const now = new Date('2026-09-22T11:00:00Z'); // mardi 7 h à New York, avant l'ouverture
  const bars = [...SEMAINE, bar('2026-09-21', 105)];
  assert.deepEqual(computePreviousClose(bars, now), { close: 105, date: '2026-09-21' });
});

test('computePreviousClose : une barre à 23 h à New York reste à SA date (fuseau, pas UTC)', () => {
  // 2026-09-18 23:30 à New York = 2026-09-19 03:30 UTC : ne doit pas compter pour le 19.
  const tard = { date: new Date('2026-09-19T03:30:00Z'), close: 50 };
  const now = new Date('2026-09-19T16:00:00Z'); // samedi
  assert.deepEqual(computePreviousClose([tard], now), { close: 50, date: '2026-09-18' });
});

test('computePreviousClose : null plutôt qu\'un prix inventé', () => {
  assert.equal(computePreviousClose([], new Date()), null);
  assert.equal(computePreviousClose([{ date: null, close: 10 }, { date: new Date(), close: NaN }], new Date()), null);
  // Seule la barre du jour existe : aucune séance antérieure connue.
  assert.equal(computePreviousClose([bar('2026-09-21', 1)], new Date('2026-09-21T15:00:00Z')), null);
});

// Corrélation réelle (#397) — alignée par DATE, null sous 20 rendements communs.
import { computeReturnCorrelation, buildCorrelationReport } from './indicators.js';
const mkBars = (closes, startDay = 1) => closes.map((c, i) => ({ date: new Date(Date.UTC(2026, 0, startDay + i)), close: c }));
const walk = (n, f) => { const out = [100]; for (let i = 1; i < n; i++) out.push(out[i - 1] * (1 + f(i))); return out; };

test('corrélation : identique → 1, inverse → −1', () => {
  const a = walk(60, (i) => Math.sin(i) * 0.02);
  const b = a.map((x) => x * 3); // mêmes rendements
  assert.ok(Math.abs(computeReturnCorrelation(mkBars(a), mkBars(b)).correlation - 1) < 1e-9);
  const inv = walk(60, (i) => -Math.sin(i) * 0.02);
  assert.ok(computeReturnCorrelation(mkBars(a), mkBars(inv)).correlation < -0.95);
});

test('corrélation : alignement par DATE, jamais par position (jours décalés ignorés)', () => {
  const a = walk(60, (i) => Math.sin(i) * 0.02);
  const full = mkBars(a);
  const sansJours = full.filter((_, i) => i % 7 !== 3); // l'autre titre manque quelques séances
  const r = computeReturnCorrelation(full, sansJours);
  assert.ok(r.n >= 20 && r.correlation > 0.5);
});

test('corrélation : sous 20 rendements communs → null, pas un chiffre', () => {
  const a = mkBars(walk(15, (i) => Math.sin(i) * 0.02));
  assert.equal(computeReturnCorrelation(a, a).correlation, null);
  assert.equal(computeReturnCorrelation(a, a).n, 14);
});

test('rapport : aucune position → non corrélé ; seuil ; historique insuffisant → null', () => {
  const a = mkBars(walk(80, (i) => Math.sin(i) * 0.02));
  assert.equal(buildCorrelationReport(a, []).correlated, false);
  const r = buildCorrelationReport(a, [{ ticker: 'X', bars: a }, { ticker: 'Y', bars: [] }], { threshold: 0.7 });
  assert.equal(r.correlated, true);
  assert.equal(r.max.ticker, 'X');
  const seul = buildCorrelationReport(a, [{ ticker: 'Y', bars: [] }]);
  assert.equal(seul.correlated, null);
});
