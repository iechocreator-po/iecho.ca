// Alertes sur les listes — orchestration (base SQLite locale, screening,
// courriel). La logique de décision est PURE et vit dans list-alerts-logic.js.
//
// LOCAL uniquement, comme le Radar : l'évaluation tourne sur ce Mac, pendant
// que castellana est lancé. Rien ne s'évalue si l'app est fermée — l'interface
// le dit. Le passage automatique (toutes les N minutes, heures de marché) est
// démarré par startListAlertsScheduler().

import { db } from './db.js';
import { buildScreening } from './screening.js';
import { screenPremiums } from './premium-screener.js';
import { getListById } from './lists.js';
import { ALERT_TYPES, validateRuleParams, isValidListRef, evaluateRule, isMarketWindow, buildDigest } from './list-alerts-logic.js';
import { emailAvailable, sendAlertEmail } from './alert-email.js';
import { runPositionAlerts, hasOpenPositions } from './position-alerts.js';

db.exec(`
  CREATE TABLE IF NOT EXISTS list_alert_rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    list_ref TEXT NOT NULL,
    type TEXT NOT NULL,
    params_json TEXT NOT NULL DEFAULT '{}',
    email TEXT,
    enabled INTEGER NOT NULL DEFAULT 1,
    baselined INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS list_alert_state (
    rule_id INTEGER NOT NULL REFERENCES list_alert_rules(id),
    ticker TEXT NOT NULL,
    value TEXT NOT NULL,
    PRIMARY KEY (rule_id, ticker)
  );
  CREATE TABLE IF NOT EXISTS list_alert_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rule_id INTEGER NOT NULL REFERENCES list_alert_rules(id),
    ticker TEXT NOT NULL,
    message TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    read_at TEXT
  );
`);

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function ruleFromRow(r) {
  return { id: r.id, listRef: r.list_ref, type: r.type, typeLabel: ALERT_TYPES[r.type]?.label ?? r.type, params: JSON.parse(r.params_json), email: r.email, enabled: r.enabled === 1, baselined: r.baselined === 1, createdAt: r.created_at };
}

export function listRules() {
  return db.prepare('SELECT * FROM list_alert_rules ORDER BY id').all().map(ruleFromRow);
}

export function createRule({ listRef, type, params, email }) {
  if (!isValidListRef(listRef)) throw new Error('Liste invalide (watchlist, MAG7 ou une liste personnalisée).');
  if (listRef.startsWith('list:') && !getListById(Number(listRef.slice(5)))) throw new Error('Liste personnalisée introuvable.');
  const clean = validateRuleParams(type, params);
  const to = email ? String(email).trim() : null;
  if (to && !EMAIL_RE.test(to)) throw new Error('Adresse courriel invalide.');
  const r = db.prepare('INSERT INTO list_alert_rules (list_ref, type, params_json, email) VALUES (?, ?, ?, ?)').run(listRef, type, JSON.stringify(clean), to);
  return ruleFromRow(db.prepare('SELECT * FROM list_alert_rules WHERE id = ?').get(r.lastInsertRowid));
}

export function setRuleEnabled(id, enabled) {
  return db.prepare('UPDATE list_alert_rules SET enabled = ? WHERE id = ?').run(enabled ? 1 : 0, id).changes > 0;
}

export function deleteRule(id) {
  db.prepare('DELETE FROM list_alert_state WHERE rule_id = ?').run(id);
  db.prepare('DELETE FROM list_alert_events WHERE rule_id = ?').run(id);
  return db.prepare('DELETE FROM list_alert_rules WHERE id = ?').run(id).changes > 0;
}

export function listEvents({ unreadOnly = false, limit = 100 } = {}) {
  return db.prepare(`
    SELECT e.id, e.ticker, e.message, e.created_at AS createdAt, e.read_at AS readAt, r.list_ref AS listRef, r.type
    FROM list_alert_events e JOIN list_alert_rules r ON r.id = e.rule_id
    ${unreadOnly ? 'WHERE e.read_at IS NULL' : ''} ORDER BY e.id DESC LIMIT ?`).all(limit);
}

export function markEventsRead(ids) {
  const stmt = db.prepare("UPDATE list_alert_events SET read_at = datetime('now') WHERE read_at IS NULL AND (? IS NULL OR id = ?)");
  const tx = db.transaction((list) => { for (const id of list) stmt.run(id, id); });
  tx(ids && ids.length ? ids : [null]);
}

function listLabel(ref) {
  if (ref === 'watchlist') return 'Ma watchlist';
  if (ref === 'mag7') return 'MAG7';
  const l = getListById(Number(ref.slice(5)));
  return l ? l.nom : ref;
}

let running = false;
export const isAlertRunActive = () => running;

/**
 * Évalue toutes les règles actives : un seul screening par liste (et un seul
 * screener de primes si une règle « prime » existe), puis les transitions.
 * Renvoie un résumé honnête : erreurs par liste, courriels envoyés ou ignorés.
 */
export async function runListAlerts() {
  if (running) throw Object.assign(new Error('Une évaluation est déjà en cours.'), { status: 409 });
  running = true;
  const summary = { rules: 0, newAlerts: 0, errors: [], email: { sent: 0, skipped: null } };
  try {
    const rules = listRules().filter((r) => r.enabled);
    summary.rules = rules.length;
    const byList = new Map();
    for (const r of rules) { if (!byList.has(r.listRef)) byList.set(r.listRef, []); byList.get(r.listRef).push(r); }

    const digestByEmail = new Map();
    for (const [ref, listRules_] of byList) {
      const label = listLabel(ref);
      let screening = null;
      let premiums = null;
      try {
        if (listRules_.some((r) => ALERT_TYPES[r.type].needs === 'screening')) screening = await buildScreening(ref);
        if (listRules_.some((r) => ALERT_TYPES[r.type].needs === 'premiums')) premiums = await screenPremiums(ref);
      } catch (err) {
        summary.errors.push(`${label} : ${err.message}`);
        continue; // aucune règle de cette liste n'est évaluée : leurs états restent intacts
      }
      const tickers = screening ? screening.rows.map((r) => r.ticker) : [];
      const screenRows = new Map((screening?.rows || []).map((r) => [r.ticker, r]));
      const premRows = new Map((premiums?.rows || []).map((r) => [r.ticker, r]));
      const premTickers = premiums ? [...premiums.rows.map((r) => r.ticker), ...premiums.skipped.map((s) => s.ticker)] : [];

      for (const rule of listRules_) {
        const needsPrem = ALERT_TYPES[rule.type].needs === 'premiums';
        const rows = needsPrem ? premRows : screenRows;
        const set = needsPrem ? premTickers : tickers;
        const prev = new Map(db.prepare('SELECT ticker, value FROM list_alert_state WHERE rule_id = ?').all(rule.id).map((x) => [x.ticker, x.value]));
        const { states, notifications } = evaluateRule(rule, rows, prev, set);

        const save = db.transaction(() => {
          const up = db.prepare('INSERT INTO list_alert_state (rule_id, ticker, value) VALUES (?, ?, ?) ON CONFLICT(rule_id, ticker) DO UPDATE SET value = excluded.value');
          for (const [t, v] of states) up.run(rule.id, t, v);
          const ins = db.prepare('INSERT INTO list_alert_events (rule_id, ticker, message) VALUES (?, ?, ?)');
          for (const n of notifications) ins.run(rule.id, n.ticker, n.message);
          if (!rule.baselined) db.prepare('UPDATE list_alert_rules SET baselined = 1 WHERE id = ?').run(rule.id);
        });
        save();

        summary.newAlerts += notifications.length;
        if (notifications.length && rule.email) {
          if (!digestByEmail.has(rule.email)) digestByEmail.set(rule.email, []);
          digestByEmail.get(rule.email).push({ listLabel: label, ruleLabel: rule.typeLabel, items: notifications.map((n) => n.message) });
        }
      }
    }

    if (digestByEmail.size) {
      if (!emailAvailable()) summary.email.skipped = 'clé Resend absente (RESEND_API_KEY dans .env) — les alertes sont dans la boîte de l\'app';
      else {
        for (const [to, groups] of digestByEmail) {
          try { await sendAlertEmail(to, buildDigest(groups)); summary.email.sent += 1; } catch (err) { summary.errors.push(`courriel vers ${to} : ${err.message}`); }
        }
      }
    }
    return summary;
  } finally {
    running = false;
  }
}

// Passage automatique : vérifie chaque minute, exécute toutes les `minutes`
// minutes pendant les heures de marché, seulement s'il existe une règle active.
// Désactivé si minutes <= 0 (settings.json → listAlerts.autoRunMinutes).
export function startListAlertsScheduler(minutes) {
  if (!(minutes > 0)) return null;
  let last = 0;
  const timer = setInterval(async () => {
    if (running || Date.now() - last < minutes * 60_000 || !isMarketWindow()) return;
    const hasRules = listRules().some((r) => r.enabled);
    const hasPositions = hasOpenPositions();
    if (!hasRules && !hasPositions) return;
    last = Date.now();
    if (hasRules) {
      try {
        const s = await runListAlerts();
        if (s.newAlerts || s.errors.length) console.log(`alertes : ${s.newAlerts} nouvelle(s), ${s.errors.length} erreur(s)`);
      } catch (err) { console.error('alertes : évaluation en échec —', err.message); }
    }
    if (hasPositions) {
      try {
        const s = await runPositionAlerts();
        if (s.newAlerts || s.errors.length) console.log(`alertes de positions : ${s.newAlerts} nouvelle(s), ${s.errors.length} erreur(s)`);
      } catch (err) { console.error('alertes de positions : évaluation en échec —', err.message); }
    }
  }, 60_000);
  timer.unref();
  return timer;
}
