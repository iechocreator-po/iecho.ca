// IA étape 1 (#398) — « Claude analyste de contexte », LOCAL seulement.
// Rassemble des données déjà calculées (fondamentaux, signal, actualités Yahoo, plan en %)
// et demande à Claude un résumé structuré. N'influence ni Setup/Contexte ni le sizing.
//
// La clé ANTHROPIC_API_KEY vit dans le .env local (comme RESEND_API_KEY) : jamais dans
// settings.json, jamais renvoyée au navigateur, jamais journalisée. Aucune donnée
// personnelle n'est envoyée : symbole, données de marché, plan en pourcentages.
import { readFileSync } from 'node:fs';
import YahooFinance from 'yahoo-finance2';
import { db } from './db.js';
import { envValue } from './alert-email.js';
import { readCache, writeCache } from './cache.js';
import { getFundamentals } from './fundamentals.js';
import { getHomemadeIndicators } from './indicators.js';
import { getPreferences, indicatorOptions } from './preferences.js';
import { scoreRow } from './scoring.js';
import { withRetry } from './fetch-retry.js';
import {
  MODELS, PROVIDERS, DEFAULT_PROVIDER, DEFAULT_OLLAMA_URL, DEFAULT_MODEL, ollamaRequest, extractOllamaInput, DEFAULT_BUDGET_USD, MAX_OUTPUT_TOKENS, SYSTEM_PROMPT, ANALYSIS_TOOL,
  estimateCost, monthKey, dayKeyNY, checkBudget, validateSettings, sanitizePlan, normalizeNews,
  buildContext, validateAnalysis, extractToolInput, cacheKey,
} from './ai-analyst-logic.js';

const yahooFinance = new YahooFinance({ suppressNotices: ['yahooSurvey'] });

db.exec(`
  CREATE TABLE IF NOT EXISTS ai_analyses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    month TEXT NOT NULL,
    model TEXT NOT NULL,
    input_tokens INTEGER,
    output_tokens INTEGER,
    cost_usd REAL,
    result_json TEXT NOT NULL,
    sources_json TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_ai_analyses_ticker ON ai_analyses (ticker, id);
`);

const getPref = db.prepare('SELECT value FROM preferences WHERE key = ?');
const putPref = db.prepare('INSERT INTO preferences (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');

const OLLAMA_URL = (() => { try { return JSON.parse(readFileSync(new URL('../settings.json', import.meta.url))).ai?.ollamaUrl || DEFAULT_OLLAMA_URL; } catch { return DEFAULT_OLLAMA_URL; } })();

export async function listOllamaModels() {
  try {
    const res = await fetch(OLLAMA_URL + '/api/tags', { signal: AbortSignal.timeout(3000) });
    if (!res.ok) return { available: false, models: [] };
    return { available: true, models: ((await res.json()).models || []).map((m) => m.name) };
  } catch { return { available: false, models: [] }; }
}

export function aiKeyAvailable() { return !!envValue('ANTHROPIC_API_KEY'); }

export function getAiSettings() {
  const model = getPref.get('app_ai_model')?.value;
  const budget = getPref.get('app_ai_budget')?.value;
  const spent = monthSpent();
  const budgetUsd = budget != null ? Number(budget) : DEFAULT_BUDGET_USD;
  const provider = PROVIDERS[getPref.get('app_ai_provider')?.value] ? getPref.get('app_ai_provider').value : DEFAULT_PROVIDER;
  return {
    provider,
    providers: Object.entries(PROVIDERS).map(([id, label]) => ({ id, label })),
    ollamaModel: getPref.get('app_ai_ollama_model')?.value || null,
    model: MODELS[model] ? model : DEFAULT_MODEL,
    budgetUsd,
    spentUsd: spent,
    models: Object.entries(MODELS).map(([id, m]) => ({ id, label: m.label })),
    keyAvailable: aiKeyAvailable(),
  };
}

export function setAiSettings(patch) {
  const v = validateSettings(patch || {});
  if ('provider' in v) putPref.run('app_ai_provider', v.provider);
  if ('ollamaModel' in v) putPref.run('app_ai_ollama_model', v.ollamaModel);
  if ('model' in v) putPref.run('app_ai_model', v.model);
  if ('budgetUsd' in v) putPref.run('app_ai_budget', String(v.budgetUsd));
  return getAiSettings();
}

function monthSpent() {
  return db.prepare('SELECT COALESCE(SUM(cost_usd), 0) AS s FROM ai_analyses WHERE month = ?').get(monthKey()).s;
}

export function getLastAnalysis(ticker) {
  const row = db.prepare("SELECT * FROM ai_analyses WHERE ticker = ? AND result_json != '' ORDER BY id DESC LIMIT 1").get(ticker);
  if (!row) return null;
  return { id: row.id, ticker, createdAt: row.created_at, model: row.model, costUsd: row.cost_usd,
    inputTokens: row.input_tokens, outputTokens: row.output_tokens,
    analysis: JSON.parse(row.result_json), fromCache: false };
}

async function fetchNews(ticker) {
  try {
    const r = await withRetry('actualités', () => yahooFinance.search(ticker, { quotesCount: 0, newsCount: 10 }));
    return normalizeNews(r.news);
  } catch { return null; } // null = source en échec (≠ liste vide) → dit dans non_disponible
}

async function callOllama(model, context) {
  let res;
  try {
    res = await fetch(OLLAMA_URL + '/api/chat', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify(ollamaRequest(model, context)), signal: AbortSignal.timeout(180000),
    });
  } catch {
    throw Object.assign(new Error(`Ollama injoignable sur ${OLLAMA_URL} : lance Ollama puis réessaie.`), { code: 'API_ERROR' });
  }
  if (!res.ok) throw Object.assign(new Error(`Ollama a refusé la requête (HTTP ${res.status}${res.status === 404 ? ' — modèle non installé ?' : ''}).`), { code: 'API_ERROR' });
  return res.json();
}

async function callClaude(model, context) {
  const key = envValue('ANTHROPIC_API_KEY');
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({
      model, max_tokens: MAX_OUTPUT_TOKENS, system: SYSTEM_PROMPT,
      tools: [ANALYSIS_TOOL], tool_choice: { type: 'tool', name: ANALYSIS_TOOL.name },
      messages: [{ role: 'user', content: JSON.stringify(context) }],
    }),
    signal: AbortSignal.timeout(60000),
  });
  if (!res.ok) {
    const hint = res.status === 401 ? 'clé refusée' : res.status === 429 ? 'limite de débit' : res.status === 404 ? 'modèle introuvable' : 'erreur du service';
    throw Object.assign(new Error(`L'API Claude a refusé la requête (HTTP ${res.status} — ${hint}).`), { code: 'API_ERROR' });
  }
  return res.json();
}

/** Analyse un symbole. `force` = « Réanalyser ». Lève avec `code` : NO_KEY, BUDGET, API_ERROR, BAD_RESPONSE. */
export async function analyseTicker(rawTicker, { plan: rawPlan, force = false } = {}) {
  const ticker = String(rawTicker || '').toUpperCase();
  if (!/^[A-Z0-9.\-^]{1,15}$/.test(ticker)) throw Object.assign(new Error('Symbole invalide.'), { code: 'BAD_INPUT' });
  const settings = getAiSettings();
  const useOllama = settings.provider === 'ollama';
  if (useOllama && !settings.ollamaModel) throw Object.assign(new Error('Choisis un modèle Ollama dans Réglages → TradingView.'), { code: 'NO_MODEL' });
  if (!useOllama && !aiKeyAvailable()) throw Object.assign(new Error("Clé ANTHROPIC_API_KEY absente : ajoute-la dans le fichier .env local, puis relance castellana."), { code: 'NO_KEY' });

  const plan = sanitizePlan(rawPlan);
  const today = dayKeyNY();

  const prefs = getPreferences();
  const [fundamentals, indicators, news] = await Promise.all([
    getFundamentals(ticker, { withVwap: true }).catch(() => null),
    getHomemadeIndicators(ticker, indicatorOptions(prefs)).catch(() => null),
    fetchNews(ticker),
  ]);
  if (!fundamentals && !indicators) throw Object.assign(new Error(`Données de marché indisponibles pour ${ticker}.`), { code: 'NO_DATA' });

  const modelId = useOllama ? 'ollama:' + settings.ollamaModel : settings.model;
  const key = cacheKey(ticker, today, fundamentals?.daysToEarnings, modelId, plan);
  if (!force) {
    const c = readCache(key);
    if (c.hit) return { ...c.value, fromCache: true };
  }

  // Le plafond en $ ne vaut que pour l'API payante ; le LLM local ne coûte rien.
  const budget = useOllama ? { ok: true } : checkBudget(settings.spentUsd, settings.budgetUsd);
  if (!budget.ok) throw Object.assign(new Error(budget.reason), { code: 'BUDGET' });

  const scoring = indicators ? scoreRow({ ...indicators, aboveVwap: fundamentals?.aboveVwap ?? null }) : null;
  const context = buildContext({ ticker, today, fundamentals, indicators, scoring, news, plan });
  if (news === null) context.actualites_indisponibles = "La source d'actualités n'a pas répondu.";

  const response = useOllama ? await callOllama(settings.ollamaModel, context) : await callClaude(settings.model, context);
  // Le coût est écrit AVANT la validation (audit onglets locaux, 21/10/2026) : une réponse rejetée (actualité hors liste, réponse coupée)
  // a quand même été facturée, et ne doit pas échapper au plafond mensuel. result_json = '' marque « rejetée » (jamais affichée ni liée à un trade).
  // Sans `usage` dans la réponse, on compte une estimation prudente (contexte envoyé + sortie maximale) plutôt que 0 $.
  const usage = useOllama ? null : response.usage;
  const inTok = (useOllama ? response.prompt_eval_count : usage?.input_tokens) ?? (useOllama ? 0 : Math.ceil(JSON.stringify(context).length / 3));
  const outTok = (useOllama ? response.eval_count : usage?.output_tokens) ?? (useOllama ? 0 : MAX_OUTPUT_TOKENS);
  const costUsd = useOllama ? 0 : estimateCost(settings.model, inTok, outTok);
  const info = db.prepare(`INSERT INTO ai_analyses (ticker, month, model, input_tokens, output_tokens, cost_usd, result_json, sources_json)
              VALUES (?, ?, ?, ?, ?, ?, '', ?)`)
    .run(ticker, monthKey(), modelId, inTok, outTok, costUsd, JSON.stringify(news || []));
  let analysis;
  try { analysis = validateAnalysis(useOllama ? extractOllamaInput(response) : extractToolInput(response), news || []); }
  catch (e) { throw Object.assign(e, { code: 'BAD_RESPONSE' }); }
  db.prepare('UPDATE ai_analyses SET result_json = ? WHERE id = ?').run(JSON.stringify(analysis), Number(info.lastInsertRowid));

  const out = { id: Number(info.lastInsertRowid), ticker, createdAt: new Date().toISOString(), model: modelId, costUsd, inputTokens: inTok, outputTokens: outTok, analysis, fromCache: false };
  writeCache(key, out, 24 * 3600);
  return out;
}
