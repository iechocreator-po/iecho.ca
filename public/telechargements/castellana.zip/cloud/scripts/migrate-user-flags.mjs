#!/usr/bin/env node
// Migration idempotente (22/9/2026) — surcharges de flags PAR UTILISATEUR
// (user_feature_flags, nouvelle table). CREATE TABLE IF NOT EXISTS :
// rejouable sans erreur, aucune donnée existante touchée. `schema.sql`
// reste la source de vérité pour une installation neuve.
//
// ⚠️ À lancer en --remote AVANT `wrangler deploy` : le code déployé lit
// cette table, et sans elle GET /api/flags répondrait 500 pour tout le
// monde (même piège que feature_flags/concept_overrides le 20/9/2026).
// Vérifier ensuite avec sqlite_master — ne pas se fier au seul message de fin.
//
// Usage :
//   node scripts/migrate-user-flags.mjs             (D1 local)
//   node scripts/migrate-user-flags.mjs --remote    (vrai D1)

import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const flag = process.argv.includes('--remote') ? '--remote' : '--local';

function run(sql) {
  const r = spawnSync('npx', ['wrangler', 'd1', 'execute', 'castellana-db', flag, '--command', sql], {
    cwd: ROOT, encoding: 'utf8', stdio: 'inherit',
  });
  if (r.status !== 0) process.exit(r.status || 1);
}

console.log(`Migration user_feature_flags (${flag})…`);
run(`CREATE TABLE IF NOT EXISTS user_feature_flags (
  user_id INTEGER NOT NULL REFERENCES users(id),
  key TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, key)
)`);
console.log('OK — table créée (ou déjà présente). Vérifier avec sqlite_master avant de déployer.');
