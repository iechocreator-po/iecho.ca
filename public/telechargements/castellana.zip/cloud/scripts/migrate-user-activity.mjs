#!/usr/bin/env node
// Migration idempotente (18/10/2026) — users.last_login_at et users.last_seen_at,
// lues par la console des comptes de bilbao (carte G3).
//
// Pourquoi : « dernière connexion » était dérivée de MAX(sessions.created_at).
// Une session dure 30 jours, donc un compte resté connecté ne « se connecte »
// plus jamais, et une déconnexion efface la ligne (le compte retombait à
// « Jamais »). Les deux dates vivent maintenant sur users.
//
// last_login_at est rempli depuis les sessions encore en base (la meilleure
// trace disponible). last_seen_at reste NULL : l'activité passée n'a jamais
// été mesurée, et un NULL dit « non mesuré » là où une date inventée mentirait.
//
// Usage :
//   node scripts/migrate-user-activity.mjs             (D1 local)
//   node scripts/migrate-user-activity.mjs --remote    (vrai D1, AVANT wrangler deploy)

import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const remote = process.argv.includes('--remote');
const flag = remote ? '--remote' : '--local';

function run(sql, { json = false } = {}) {
  const args = ['wrangler', 'd1', 'execute', 'castellana-db', flag, '--command', sql];
  if (json) args.push('--json');
  const result = spawnSync('npx', args, { cwd: ROOT, stdio: json ? ['ignore', 'pipe', 'pipe'] : 'inherit' });
  if (result.status !== 0) {
    console.error(json ? result.stderr?.toString() : '');
    throw new Error(`Échec de la commande wrangler (SQL: ${sql})`);
  }
  return json ? JSON.parse(result.stdout.toString()) : null;
}

const columns = () => new Set(run('PRAGMA table_info(users)', { json: true })[0].results.map((c) => c.name));

console.log(`\nMigration users.last_login_at / last_seen_at (${remote ? 'D1 distant' : 'D1 local'})...`);
const cols = columns();
for (const col of ['last_login_at', 'last_seen_at']) {
  if (cols.has(col)) { console.log(`- users.${col} déjà présente, ignorée`); continue; }
  console.log(`- ajout de la colonne users.${col}`);
  run(`ALTER TABLE users ADD COLUMN ${col} TEXT`);
}
console.log('- remplissage de last_login_at depuis les sessions encore en base');
run(`UPDATE users SET last_login_at = (SELECT MAX(s.created_at) FROM sessions s WHERE s.user_id = users.id)
     WHERE last_login_at IS NULL`);

const after = columns();
for (const col of ['last_login_at', 'last_seen_at']) {
  if (!after.has(col)) throw new Error(`users.${col} absente après migration`);
}
console.log(`\nMigration terminée et vérifiée (${flag}). Rejouable sans erreur.`);
