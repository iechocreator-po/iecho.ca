// Calculs maison — OBV réel, SMA 9/21/100, ATR réel et volume vs moyenne
// 20j, aucun fourni de façon fiable par tradingview-mcp (voir CLAUDE.md,
// section « Reste à calculer maison »). Source de données : Yahoo Finance
// directement, via `yahoo-finance2` (npm, non officiel mais légitime —
// même famille que `yahoo_price`/`market_snapshot` côté tradingview-mcp,
// qui se sont montrés non affectés par le rate-limit du scanner
// TradingView en test réel).
//
// Aucune dépendance à tradingview-mcp ici : ce module marche même si le
// sidecar Python est arrêté.

import YahooFinance from 'yahoo-finance2';
import { withRetry, mapWithConcurrency } from './fetch-retry.js';
import { cached, TTL } from './cache.js';

const yahooFinance = new YahooFinance({ suppressNotices: ['yahooSurvey'] });

// Période ATR — dupliquée de config.js (CFG.indicateurs.atrPeriode) faute
// de format de module commun entre le frontend classique et ce backend
// ESM, même limitation que SCORE_BANDS dans server/index.js.
const ATR_PERIOD = 14;

// Vérif de connectivité pour l'indicateur de statut du frontend — appel
// Yahoo Finance minimal (cotation SPY, pas un historique complet), pour
// tester ce module directement plutôt que de passer par le sidecar MCP
// (yahoo_price y transiterait par tradingview-mcp, ce qui ne testerait pas
// vraiment `yahoo-finance2`). Retourne le détail de l'erreur (30/8/2026,
// demande de JP d'être explicite sur la nature du problème technique)
// plutôt qu'un simple booléen qui masque la cause.
export async function checkYahooConnection() {
  try {
    await withRetry('cotation SPY (test de connectivité)', () => yahooFinance.quote('SPY'), { tries: 1, timeoutMs: 6000 });
    return { ok: true, detail: null };
  } catch (err) {
    return { ok: false, detail: err.message };
  }
}

// `lookbackDays` = 420 depuis le 7/9/2026 (audit) : 300 jours calendaires ne
// donnaient que ~205 barres, soit 5 de marge sur les 200 requises par la
// SMA200 (mesuré en direct sur AMD). 420 jours en donnent ~290. La SMA200 et
// le Golden Cross sont calculés ici depuis le 7/9/2026 — ils venaient
// auparavant du sidecar tradingview-mcp.
export async function fetchDailyHistory(symbol, lookbackDays = 420, { force = false } = {}) {
  // TTL court (15 min) et NON 12 h : la dernière barre de l'historique est
  // celle du jour en cours, encore en mouvement pendant la séance — la figer
  // gèlerait le prix, l'ATR et le volume du jour. Voir l'avertissement en
  // tête de server/cache.js.
  return cached(
    `history:${symbol}:${lookbackDays}`,
    TTL.HISTORY,
    async () => {
      const now = new Date();
      const start = new Date(now.getTime() - lookbackDays * 24 * 3600 * 1000);
      const result = await withRetry(`historique ${symbol}`, () =>
        yahooFinance.chart(symbol, { period1: start, period2: now, interval: '1d' }));
      return result.quotes.filter((q) => q.close != null && q.volume != null);
    },
    {
      force,
      // JSON ne porte pas les `Date` : sans cette reconstruction, une valeur
      // relue du cache n'aurait pas la même forme qu'une valeur fraîche, et
      // l'écart ne se verrait qu'au deuxième appel.
      revive: (bars) => bars.map((b) => ({ ...b, date: b.date ? new Date(b.date) : null })),
    },
  );
}

// SMA (Simple Moving Average) — moyenne mobile SIMPLE, fenêtre glissante :
// SMA[i] = moyenne des `period` dernières clôtures. C'est la moyenne utilisée
// pour le filtre de tendance 9/21/100 (design_assistant_swing_trading.md
// section 4.1, révisé 29/8/2026 — JP a demandé de standardiser sur SMA après
// avoir relevé une incohérence de terminologie dans les capsules d'aide,
// SMMA d'un côté et MM de l'autre pour ce qui devait être le même type de
// moyenne). Retourne un tableau aligné sur `closes` (null tant que la
// fenêtre n'est pas encore remplie).
export function computeSMA(closes, period) {
  const out = new Array(closes.length).fill(null);
  if (closes.length < period) return out;
  let sum = 0;
  for (let i = 0; i < period; i++) sum += closes[i];
  out[period - 1] = sum / period;
  for (let i = period; i < closes.length; i++) {
    sum += closes[i] - closes[i - period];
    out[i] = sum / period;
  }
  return out;
}

// RMA (Wilder/smoothed) — PAS une SMA, gardée séparée et réservée au lissage
// de l'ATR (section suivante), qui est standard en RMA par définition
// (l'ATR de Wilder EST une RMA appliquée au True Range). Ne sert plus au
// filtre de tendance depuis la révision ci-dessus.
function computeRMA(closes, period) {
  const out = new Array(closes.length).fill(null);
  if (closes.length < period) return out;
  let sum = 0;
  for (let i = 0; i < period; i++) sum += closes[i];
  out[period - 1] = sum / period;
  for (let i = period; i < closes.length; i++) {
    out[i] = (out[i - 1] * (period - 1) + closes[i]) / period;
  }
  return out;
}

// RSI (Relative Strength Index) de Wilder — ajouté le 7/9/2026 pour reprendre
// maison ce que fournissait `coin_analysis` du sidecar tradingview-mcp.
// Vérifié identique à la décimale contre le sidecar sur AMD avant bascule
// (49.67 des deux côtés, voir CLAUDE.md).
//
// Moyennes des gains/pertes lissées en RMA (Wilder), PAS en SMA — c'est la
// définition standard, et c'est ce que calcule TradingView. La première
// valeur est une moyenne simple sur `period` barres, puis le lissage prend
// le relais. Retourne `null` si l'historique est trop court.
//
// `period` est un vrai paramètre (contrairement au sidecar, qui imposait 14) :
// CFG.indicateurs.rsiPeriode peut désormais réellement le piloter.
export function computeRSI(closes, period = 14) {
  if (closes.length < period + 1) return null;
  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = closes[i] - closes[i - 1];
    if (d > 0) gain += d;
    else loss -= d;
  }
  gain /= period;
  loss /= period;
  for (let i = period + 1; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    gain = (gain * (period - 1) + (d > 0 ? d : 0)) / period;
    loss = (loss * (period - 1) + (d < 0 ? -d : 0)) / period;
  }
  if (loss === 0) return gain === 0 ? 50 : 100;
  return 100 - 100 / (1 + gain / loss);
}

// OBV réel (cumulatif) — design_assistant_swing_trading.md section 4.4.
// +volume si clôture > veille, -volume si <, inchangé si =.
export function computeOBV(bars) {
  const out = new Array(bars.length).fill(0);
  for (let i = 1; i < bars.length; i++) {
    if (bars[i].close > bars[i - 1].close) out[i] = out[i - 1] + bars[i].volume;
    else if (bars[i].close < bars[i - 1].close) out[i] = out[i - 1] - bars[i].volume;
    else out[i] = out[i - 1];
  }
  return out;
}

// True Range puis ATR (Wilder) — lissage RMA (computeRMA ci-dessus, PAS
// computeSMA : l'ATR de Wilder est une RMA appliquée au True Range, pas une
// coïncidence de notation, et ce n'est pas concerné par la révision
// SMMA→SMA du filtre de tendance). TR[0] = high-low faute de clôture veille.
export function computeTrueRange(bars) {
  const out = new Array(bars.length).fill(null);
  if (bars.length === 0) return out;
  out[0] = bars[0].high - bars[0].low;
  for (let i = 1; i < bars.length; i++) {
    const h = bars[i].high;
    const l = bars[i].low;
    const pc = bars[i - 1].close;
    out[i] = Math.max(h - l, Math.abs(h - pc), Math.abs(l - pc));
  }
  return out;
}

export function computeATR(bars, period = ATR_PERIOD) {
  return computeRMA(computeTrueRange(bars), period);
}

// Volume du jour vs moyenne des 20 jours PRÉCÉDENTS (jour courant exclu de
// sa propre moyenne, sinon un jour à fort volume gonflerait sa propre
// référence) — même principe que le champ `volume.SMA20` que
// tradingview-mcp tente de fournir sans succès en pratique.
export function computeVolumeVs20d(bars) {
  const n = bars.length;
  if (n < 21) return { ratio: null, volumeSMA20: null };
  const window = bars.slice(n - 21, n - 1).map((b) => b.volume);
  const avg = window.reduce((a, b) => a + b, 0) / window.length;
  const current = bars[n - 1].volume;
  return { ratio: avg > 0 ? current / avg : null, volumeSMA20: avg };
}

// Volatilité historique annualisée (écart-type des rendements logarithmiques
// quotidiens × racine(252) jours de bourse) — utilisée par l'onglet Labo
// (server/index.js, /api/labo/:ticker) pour estimer un strike correspondant
// à un delta cible via Black-Scholes (js/strategies-labo.js).
//
// AVERTISSEMENT IMPORTANT, à ne jamais perdre en modifiant ce code : c'est
// une volatilité HISTORIQUE (réalisée, calculée sur les prix passés), pas
// la volatilité IMPLICITE que le marché utilise réellement pour pricer les
// options (celle-ci intègre les attentes futures — earnings à venir,
// événements macro — que l'historique ne voit pas). C'est un PROXY
// couramment utilisé faute de source de volatilité implicite dans cette
// app, jamais un remplacement exact.
//
// `lookback` = nombre de jours de bourse utilisés (60 ≈ 3 mois de
// négociation) — fixe pour l'instant, pas encore exposé comme paramètre UI.
export function computeHistoricalVolatility(closes, lookback = 60) {
  const n = closes.length;
  const start = Math.max(1, n - lookback);
  const returns = [];
  for (let i = start; i < n; i++) {
    if (closes[i - 1] > 0 && closes[i] > 0) returns.push(Math.log(closes[i] / closes[i - 1]));
  }
  if (returns.length < 10) return null;
  const mean = returns.reduce((a, b) => a + b, 0) / returns.length;
  const variance = returns.reduce((a, b) => a + (b - mean) ** 2, 0) / (returns.length - 1);
  return Math.sqrt(variance) * Math.sqrt(252);
}

// Approxime "accumulation" (OBV confirme la tendance) / "distribution"
// (diverge) / "neutre" (design doc section 4.4) : compare la variation de
// l'OBV et celle du prix sur les `window` dernières barres. Même signe =
// confirme, signes opposés = diverge. C'est une approximation raisonnable,
// pas la détection de divergence formelle (pics/creux) — documenté comme
// tel, à affiner si l'usage réel montre des faux signaux.
function classifyOBV(obv, closes, window = 10) {
  const n = obv.length;
  if (n < window + 1) return 'neutre';
  const priceChange = closes[n - 1] - closes[n - 1 - window];
  const obvChange = obv[n - 1] - obv[n - 1 - window];
  if (Math.abs(priceChange) < 1e-9 || Math.abs(obvChange) < 1e-9) return 'neutre';
  return (priceChange > 0) === (obvChange > 0) ? 'accumulation' : 'distribution';
}

// Point d'entrée — un seul appel Yahoo Finance (historique), tout calculé
// localement dessus. Lève si Yahoo est injoignable ou l'historique trop
// court ; à l'appelant de gérer (503 / ligne "erreur" selon le contexte).
//
// `periods` (5/9/2026, demande de JP T3 — onglet Labo) : les 3 périodes du
// filtre de tendance sont surchageables par l'appelant, avec 9/21/100 en
// défaut (comportement inchangé pour tous les appelants existants —
// screening, market-data — qui n'en passent pas). Seule la route
// GET /api/labo/:ticker (server/index.js) les passe explicitement,
// reflétant les valeurs saisies dans l'onglet Labo. Avant cette révision,
// CFG.indicateurs.smaRapide/Moyenne/Lente (config.js) changeait les
// LIBELLÉS affichés sans jamais changer ce calcul — écart réel corrigé ici,
// pas seulement un ajout.
export async function getHomemadeIndicators(symbol, { periods, rsiPeriod = 14 } = {}) {
  const { fast = 9, medium = 21, slow = 100 } = periods || {};
  const bars = await fetchDailyHistory(symbol);
  if (bars.length === 0) {
    throw new Error(`aucun historique renvoyé par Yahoo Finance pour ${symbol}`);
  }
  const closes = bars.map((b) => b.close);
  const n = closes.length;

  // Chaque indicateur est calculé SI l'historique le permet, et vaut `null`
  // sinon. Avant le 7/9/2026 cette fonction LEVAIT quand l'historique était
  // plus court que la SMA la plus lente — ce qui faisait échouer toute la
  // ligne d'un titre récemment introduit (CRWV) alors que son RSI, son ATR et
  // son OBV étaient parfaitement calculables. Un `null` explicite est la
  // bonne réponse ici : « pas calculable », pas « erreur ».
  const last = (series) => (series[n - 1] ?? null);
  const smaAt = (period) => (n >= period ? last(computeSMA(closes, period)) : null);

  const sF = smaAt(fast);
  const sM = smaAt(medium);
  const sS = smaAt(slow);
  const close = closes[n - 1];

  // SMA 50/200 et Golden Cross — repris du sidecar tradingview-mcp le
  // 7/9/2026 (`coin_analysis`, champs sma.sma50/sma200/signals). Définition
  // identique à celle du design doc : Golden Cross = SMA50 > SMA200.
  // Vérifié valeur par valeur contre le sidecar avant la bascule.
  const sma50 = smaAt(50);
  const sma200 = smaAt(200);
  const goldenCross = sma50 != null && sma200 != null ? sma50 > sma200 : null;

  let smaAlignment = null;
  if (sF != null && sM != null && sS != null) {
    if (close > sF && sF > sM && sM > sS) smaAlignment = 'haussier';
    else if (close < sF && sF < sM && sM < sS) smaAlignment = 'baissier';
    else smaAlignment = 'neutre';
  }

  const atrSeries = computeATR(bars);
  const volumeInfo = computeVolumeVs20d(bars);
  const historicalVolatility = computeHistoricalVolatility(closes);
  const obv = computeOBV(bars);

  return {
    sma9: sF,
    sma21: sM,
    sma100: sS,
    smaPeriods: { fast, medium, slow },
    smaAlignment,
    sma50,
    sma200,
    goldenCross,
    rsi: computeRSI(closes, rsiPeriod),
    rsiPeriod,
    price: close,
    obv: obv[n - 1],
    obvTrend: classifyOBV(obv, closes),
    atr: last(atrSeries),
    volumeRatio: volumeInfo.ratio,
    volumeSMA20: volumeInfo.volumeSMA20,
    historicalVolatility,
    barsUsed: n,
  };
}

// Version batch pour le screening — parallélisme BORNÉ (6 appels en vol)
// depuis le 7/9/2026. C'était auparavant une boucle séquentielle espacée de
// 400 ms par titre : une prudence héritée du rate-limit du scanner
// TradingView, appliquée par précaution à Yahoo qui, lui, a encaissé 20
// appels parallèles sans un seul échec pendant l'audit. On reste borné
// plutôt qu'illimité : c'est une source non officielle, dont rien ne
// documente la tolérance réelle.
//
// Un titre en échec ressort avec `error` rempli, sans interrompre le reste.
export async function getHomemadeIndicatorsBatch(tickers, { concurrency = 6, periods, rsiPeriod } = {}) {
  return mapWithConcurrency(tickers, async (ticker) => {
    try {
      const data = await getHomemadeIndicators(ticker, { periods, rsiPeriod });
      return { ticker, ...data, error: null };
    } catch (err) {
      return {
        ticker,
        sma9: null,
        sma21: null,
        sma100: null,
        smaPeriods: null,
        smaAlignment: null,
        sma50: null,
        sma200: null,
        goldenCross: null,
        rsi: null,
        price: null,
        obv: null,
        obvTrend: null,
        atr: null,
        volumeRatio: null,
        volumeSMA20: null,
        historicalVolatility: null,
        error: err.message,
      };
    }
  }, { limit: concurrency });
}
