// Recherche de symboles par nom (feature « recherche à la TradingView »,
// 3/10/2026) : taper « berkshire » ou « BRK.B » doit mener à BRK-B.
//
// Source : `yahooFinance.search()` — le même fournisseur que le reste de
// l'app, aucune nouvelle dépendance. Vérifié en direct : « berkshire »
// renvoie BRK-B et BRK-A en tête ; « BRK.B » (notation TradingView) ne
// renvoie PAS l'action (options et FNB seulement), d'où la conversion
// point → tiret avant la recherche.
//
// ⚠️ Copie cloud : cloud/src/lib/symbol-search.js (même logique, seul
// l'accès à Yahoo diffère). Les fonctions pures sont testées ici.

import YahooFinance from 'yahoo-finance2';
import { withRetry } from './fetch-retry.js';

const yahooFinance = new YahooFinance({ suppressNotices: ['yahooSurvey'] });

// Types Yahoo retenus par filtre. Options, contrats à terme, devises et
// cryptos sont écartés : l'app n'analyse que des actions, FNB et indices.
export const SEARCH_FILTERS = {
  all: ['EQUITY', 'ETF', 'MUTUALFUND', 'INDEX'],
  stocks: ['EQUITY'],
  funds: ['ETF', 'MUTUALFUND'],
  indices: ['INDEX'],
};

const TYPE_LABELS = { EQUITY: 'Action', ETF: 'FNB', MUTUALFUND: 'Fonds', INDEX: 'Indice' };

// « BRK.B » / « brk.a » / « BRK/B » (notation TradingView) → « BRK-B »
// (notation Yahoo). Les suffixes de bourse (.TO, .V, .L…) ne sont pas
// touchés : seule une classe d'actions d'UNE lettre est convertie.
export function normalizeSearchQuery(q) {
  const s = String(q ?? '').trim();
  const m = s.match(/^([A-Za-z]{1,5})[./]([A-Za-z])$/);
  if (m && !/^(TO|V|L|NE|CN)$/i.test(m[2])) return `${m[1].toUpperCase()}-${m[2].toUpperCase()}`;
  return s;
}

export function mapSearchResults(quotes, filter = 'all') {
  const allowed = SEARCH_FILTERS[filter] || SEARCH_FILTERS.all;
  return (quotes || [])
    .filter((x) => x && x.symbol && allowed.includes(x.quoteType))
    .map((x) => ({
      symbol: x.symbol,
      name: x.longname || x.shortname || '',
      type: x.quoteType,
      typeLabel: TYPE_LABELS[x.quoteType] || x.quoteType,
      exchange: x.exchDisp || x.exchange || '',
    }));
}

export async function searchSymbols(query, filter = 'all') {
  const q = normalizeSearchQuery(query);
  if (q.length < 1) return { query: q, results: [] };
  const r = await withRetry('recherche de symbole', () =>
    yahooFinance.search(q, { quotesCount: 20, newsCount: 0 }));
  return { query: q, results: mapSearchResults(r.quotes, filter) };
}
