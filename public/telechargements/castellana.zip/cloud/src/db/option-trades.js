// cloud/src/db/option-trades.js — portage D1 de server/option-trades.js
// (voir ce fichier pour le raisonnement complet). Isolé par user_id comme
// custom_lists/strategy_params.
import { createTrade, updateTrade, getTrade } from './trades.js';
import { isValidTicker, TICKER_ERROR } from '../lib/ticker-format.js';
import { tradeIsNonNegative, tradeIsIsoDate } from '../lib/trade-rules.js';
import { getEffectiveParams } from './labo-params.js';
import { optRoueDeletionPlan } from '../lib/options-analytics.js';

const COMPTES = ['RRSP', 'margin', 'corporatif'];
const TYPES = ['put', 'call'];
const STATUTS_CLOTURE = ['expire', 'assigne', 'roule', 'rachete'];
const SOURCES = ['saisie', 'import_sheets'];

function fail(message, status = 400) {
  const err = new Error(message);
  err.status = status;
  return err;
}

async function contractSize(db, userId) {
  const p = await getEffectiveParams(db, userId, 'roue');
  return (p && p.contractSize) || 100;
}

export function validateOptionTrade(data, { partial = false } = {}) {
  const errors = [];
  const required = ['type', 'ticker', 'compte', 'strike', 'echeance', 'prime_recue', 'date_ouverture'];
  if (!partial) {
    for (const f of required) if (data[f] === undefined || data[f] === null || data[f] === '') errors.push(`${f} est requis`);
  }
  if (data.ticker != null && data.ticker !== '' && !isValidTicker(String(data.ticker))) errors.push(TICKER_ERROR);
  if (data.type != null && !TYPES.includes(data.type)) errors.push(`type doit être l'un de : ${TYPES.join(', ')}`);
  if (data.compte != null && !COMPTES.includes(data.compte)) errors.push(`compte doit être l'un de : ${COMPTES.join(', ')}`);
  if (data.strike != null && !(Number(data.strike) > 0)) errors.push('strike doit être positif');
  if (data.prime_recue != null && !(Number(data.prime_recue) >= 0)) errors.push('prime_recue doit être ≥ 0 (0 = prime nulle réelle, distinct d\'une absence)');
  if (data.contrats !== undefined && !(Number.isInteger(Number(data.contrats)) && Number(data.contrats) > 0)) errors.push('contrats doit être un entier positif');
  // Journal de la Roue (#433) : une commission absente reste NULL (« non renseignée »), jamais 0.
  for (const f of ['commission_ouverture', 'commission_cloture']) {
    if (data[f] != null && data[f] !== '' && !(Number(data[f]) >= 0)) errors.push(`${f} doit être ≥ 0`);
  }
  if (data.source != null && !SOURCES.includes(data.source)) errors.push(`source doit être l'un de : ${SOURCES.join(', ')}`);
  for (const f of ['echeance', 'date_ouverture', 'date_cloture']) {
    if (data[f] != null && data[f] !== '' && !tradeIsIsoDate(data[f])) errors.push(`${f} doit être une date AAAA-MM-JJ`);
  }
  return errors;
}

export async function createCycle(db, userId, { ticker, compte, notes }) {
  if (!ticker || !COMPTES.includes(compte)) throw fail('ticker et compte (RRSP/margin/corporatif) sont requis');
  if (!isValidTicker(String(ticker))) throw fail(TICKER_ERROR);
  const info = await db.prepare('INSERT INTO option_cycles (user_id, ticker, compte, notes) VALUES (?, ?, ?, ?)')
    .bind(userId, String(ticker).trim().toUpperCase(), compte, notes || null).run();
  return getCycle(db, userId, info.meta.last_row_id);
}

export async function listCycles(db, userId) {
  const { results: cycles } = await db.prepare('SELECT * FROM option_cycles WHERE user_id = ? ORDER BY date_creation DESC').bind(userId).all();
  const { results: legs } = await db.prepare('SELECT * FROM option_trades WHERE user_id = ? ORDER BY date_ouverture ASC, id ASC').bind(userId).all();
  const byCycle = new Map();
  for (const l of legs) {
    if (l.cycle_id == null) continue;
    if (!byCycle.has(l.cycle_id)) byCycle.set(l.cycle_id, []);
    byCycle.get(l.cycle_id).push(l);
  }
  const taille = await contractSize(db, userId);
  return cycles.map((c) => {
    const cycleLegs = byCycle.get(c.id) || [];
    const primeTotale = cycleLegs.reduce((sum, l) => sum + l.prime_recue * l.contrats * taille, 0);
    return { ...c, legs: cycleLegs, primeTotale };
  });
}

export async function getCycle(db, userId, id) {
  const cycle = await db.prepare('SELECT * FROM option_cycles WHERE id = ? AND user_id = ?').bind(id, userId).first();
  if (!cycle) return null;
  const { results: legs } = await db.prepare('SELECT * FROM option_trades WHERE cycle_id = ? AND user_id = ? ORDER BY date_ouverture ASC, id ASC').bind(id, userId).all();
  return { ...cycle, legs };
}

export async function updateCycle(db, userId, id, { statut, notes }) {
  if (statut !== undefined && !['actif', 'clos'].includes(statut)) throw fail('statut de cycle invalide (actif/clos)'); // null refusé aussi : colonne NOT NULL
  if (!(await getCycle(db, userId, id))) throw fail('Cycle introuvable', 404);
  const cols = [];
  const vals = [];
  if (statut !== undefined) { cols.push('statut = ?'); vals.push(statut); }
  if (notes !== undefined) { cols.push('notes = ?'); vals.push(notes); }
  if (cols.length) await db.prepare(`UPDATE option_cycles SET ${cols.join(', ')} WHERE id = ? AND user_id = ?`).bind(...vals, id, userId).run();
  return getCycle(db, userId, id);
}

export async function createOptionTrade(db, userId, rawData) {
  const errors = validateOptionTrade(rawData);
  if (errors.length) throw fail(errors.join(' '));
  if (rawData.cycle_id != null && rawData.cycle_id !== '') {
    const own = await db.prepare('SELECT id FROM option_cycles WHERE id = ? AND user_id = ?').bind(rawData.cycle_id, userId).first();
    if (!own) throw fail('Cycle introuvable', 404); // le cycle d'un autre compte n'est pas un lien valide (audit routes, 21/10/2026)
  }
  const data = { ...rawData, ticker: rawData.ticker.trim().toUpperCase(), contrats: rawData.contrats ?? 1, statut: 'ouvert' };
  const cols = ['cycle_id', 'type', 'ticker', 'compte', 'strike', 'echeance', 'contrats', 'prime_recue', 'date_ouverture', 'delta_ouverture', 'iv_ouverture', 'statut', 'commission_ouverture', 'source'].filter((c) => data[c] !== undefined);
  const info = await db.prepare(`INSERT INTO option_trades (user_id, ${cols.join(', ')}) VALUES (?, ${cols.map(() => '?').join(', ')})`)
    .bind(userId, ...cols.map((c) => data[c])).run();
  return getOptionTrade(db, userId, info.meta.last_row_id);
}

export async function listOptionTrades(db, userId, { statut, cycleId } = {}) {
  let sql = 'SELECT * FROM option_trades WHERE user_id = ?';
  const params = [userId];
  if (statut) {
    const list = String(statut).split(',').map((s) => s.trim()).filter(Boolean);
    sql += ` AND statut IN (${list.map(() => '?').join(',')})`;
    params.push(...list);
  }
  if (cycleId) { sql += ' AND cycle_id = ?'; params.push(cycleId); }
  sql += ' ORDER BY date_ouverture DESC, id DESC';
  const { results } = await db.prepare(sql).bind(...params).all();
  return results;
}

export async function getOptionTrade(db, userId, id) {
  return db.prepare('SELECT * FROM option_trades WHERE id = ? AND user_id = ?').bind(id, userId).first();
}

export async function deleteOptionTrade(db, userId, id) {
  // Pas de clé étrangère sur roule_vers_id : on détache les jambes qui y pointaient (audit routes locales, 21/10/2026).
  try { await db.prepare('UPDATE option_trades SET roule_vers_id = NULL WHERE roule_vers_id = ? AND user_id = ?').bind(id, userId).run(); }
  catch (err) { if (!/no such column/i.test(String(err.message))) throw err; } // base d'avant la migration de la Roue
  const info = await db.prepare('DELETE FROM option_trades WHERE id = ? AND user_id = ?').bind(id, userId).run();
  return info.meta.changes > 0;
}

export async function closeOptionTrade(db, userId, id, { statut, dateCloture, primeCloture, stopInitial, vixAEntree, rsiAEntree, obvAEntree, commissionCloture, rouleVersId } = {}) {
  const ot = await getOptionTrade(db, userId, id);
  if (!ot) throw fail('Position introuvable', 404);
  if (ot.statut !== 'ouvert') throw fail(`Cette position est déjà « ${ot.statut} »`);
  if (!STATUTS_CLOTURE.includes(statut)) throw fail(`statut doit être l'un de : ${STATUTS_CLOTURE.join(', ')}`);
  if (!dateCloture) throw fail('dateCloture est requise');
  if (!tradeIsIsoDate(dateCloture)) throw fail('dateCloture doit être une date AAAA-MM-JJ');
  // null, '' et [] valent >= 0 en JavaScript : un rachat sans prime était compté à 0 $ (audit routes, 21/10/2026).
  if (statut !== 'expire' && !tradeIsNonNegative(primeCloture)) throw fail('primeCloture (≥ 0) est requise sauf pour une expiration sans valeur');
  // Validé AVANT toute écriture — voir server/option-trades.js pour le bug
  // réel qu'évite cet ordre (position bloquée en « assigne » sans stop).
  if (ot.type === 'put' && statut === 'assigne' && !(Number(stopInitial) > 0)) {
    throw fail('stopInitial (> 0) est requis pour créer la position résultant de l\'assignation d\'un put');
  }
  if (commissionCloture != null && commissionCloture !== '' && !(Number(commissionCloture) >= 0)) throw fail('commissionCloture doit être ≥ 0');
  if (rouleVersId != null && statut !== 'roule') throw fail('rouleVersId n\'a de sens que pour une jambe roulée');

  // Colonnes #433 écrites seulement si fournies : un Worker déployé avant scripts/migrate-roue.mjs
  // continue de clôturer normalement tant qu'on ne lui envoie pas de commission ni de roulement.
  const sets = ['statut = ?', 'date_cloture = ?', 'prime_cloture = ?'];
  const vals = [statut, dateCloture, statut === 'expire' ? 0 : primeCloture];
  if (commissionCloture != null && commissionCloture !== '') { sets.push('commission_cloture = ?'); vals.push(Number(commissionCloture)); }
  if (rouleVersId != null) { sets.push('roule_vers_id = ?'); vals.push(Number(rouleVersId)); }
  // La clôture ne vaut que si la jambe est encore ouverte : deux requêtes simultanées ne créent pas deux actions (audit routes, 21/10/2026).
  const maj = await db.prepare(`UPDATE option_trades SET ${sets.join(', ')} WHERE id = ? AND user_id = ? AND statut = 'ouvert'`).bind(...vals, id, userId).run();
  if ((maj.meta?.changes ?? 0) === 0) throw fail('Cette position vient d\'être clôturée', 409);

  let effect = { type: 'aucun' };
  try {

  if (ot.type === 'put' && statut === 'assigne') {
    const taille = await contractSize(db, userId);
    const trade = await createTrade(db, userId, {
      date_entree: dateCloture,
      compte: ot.compte,
      ticker: ot.ticker,
      prix_entree: ot.strike,
      taille_position: ot.contrats * taille,
      stop_initial: Number(stopInitial),
      vix_a_entree: vixAEntree ?? null,
      rsi_a_entree: rsiAEntree ?? null,
      obv_a_entree: obvAEntree ?? null,
      option_cycle_id: ot.cycle_id ?? null,
    });
    effect = { type: 'trade_cree', tradeId: trade.id };
  } else if (ot.type === 'call' && statut === 'assigne' && ot.cycle_id != null) {
    const open = await db.prepare('SELECT * FROM trades WHERE option_cycle_id = ? AND user_id = ? AND date_sortie IS NULL ORDER BY id DESC LIMIT 1').bind(ot.cycle_id, userId).first();
    if (open) {
      const risque = open.prix_entree - open.stop_initial;
      const rRealise = risque !== 0 ? (ot.strike - open.prix_entree) / risque : null;
      const resultat = ot.strike >= open.prix_entree ? 'gagnant' : 'perdant';
      await updateTrade(db, userId, open.id, { date_sortie: dateCloture, prix_sortie: ot.strike, r_realise: rRealise, resultat });
      effect = { type: 'trade_ferme', tradeId: open.id, rRealise, resultat };
    } else {
      effect = { type: 'aucune_position_liee' };
    }
  }

  } catch (err) {
    // D1 n'a pas de transaction interactive : si la position liée n'a pas pu s'écrire, la jambe redevient ouverte plutôt que de rester « assignée » sans position.
    await db.prepare("UPDATE option_trades SET statut = 'ouvert', date_cloture = NULL, prime_cloture = NULL WHERE id = ? AND user_id = ?").bind(id, userId).run();
    throw err;
  }

  return { optionTrade: await getOptionTrade(db, userId, id), effect };
}

// Suppression multiple (onglet Roue) — voir server/option-trades.js. Limité au compte connecté
// (user_id) : les identifiants d'un autre utilisateur sont inconnus du plan, donc ignorés.
export async function deleteRoueEntries(db, userId, { legIds = [], flowIds = [] } = {}) {
  if (!Array.isArray(legIds) || !Array.isArray(flowIds)) throw fail('legIds et flowIds doivent être des listes');
  if (legIds.length + flowIds.length === 0) throw fail('Rien à supprimer');
  if (legIds.length + flowIds.length > 500) throw fail('500 entrées au plus par suppression');
  const q = (sql) => db.prepare(sql).bind(userId).all().then((r) => r.results || []);
  const [legs, cycles, stock, flows] = await Promise.all([
    q('SELECT id, cycle_id, roule_vers_id FROM option_trades WHERE user_id = ?'),
    q('SELECT id FROM option_cycles WHERE user_id = ?'),
    q('SELECT id, option_cycle_id FROM trades WHERE user_id = ? AND option_cycle_id IS NOT NULL'),
    q('SELECT id, cycle_id FROM cash_flows WHERE user_id = ?'),
  ]);
  const plan = optRoueDeletionPlan({ legIds, flowIds, legs, cycles, stock, flows });
  // Une seule instruction par table (json_each) : reste sous le plafond de sous-requêtes D1.
  const del = (table, ids) => db.prepare(`DELETE FROM ${table} WHERE user_id = ? AND id IN (SELECT value FROM json_each(?))`).bind(userId, JSON.stringify(ids));
  const stmts = [];
  if (plan.flowIds.length) stmts.push(del('cash_flows', plan.flowIds));
  if (plan.stockIds.length) stmts.push(del('trades', plan.stockIds));
  if (plan.rollRefs.length) stmts.push(db.prepare('UPDATE option_trades SET roule_vers_id = NULL WHERE user_id = ? AND id IN (SELECT value FROM json_each(?))').bind(userId, JSON.stringify(plan.rollRefs)));
  if (plan.legIds.length) stmts.push(del('option_trades', plan.legIds));
  if (plan.cycleIds.length) stmts.push(del('option_cycles', plan.cycleIds));
  if (stmts.length) await db.batch(stmts);
  return plan;
}
