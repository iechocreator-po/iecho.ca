// js/roue-import.js — import du « Journal de la Roue » du club (Google Sheets) dans l'onglet Roue
// (13/10/2026, bilbao #436). Lit un .xlsx (téléchargé depuis Google Sheets) ou un .csv de l'onglet
// JOURNAL, DANS LE NAVIGATEUR et sans dépendance : un .xlsx est un zip de fichiers XML, décompressé
// avec DecompressionStream('deflate-raw') (natif navigateur et Node ≥ 18). Le même code sert donc en
// local et en cloud, et les tests Node le lisent tel quel (server/roue-import.js).
//
// Principes (voir anticipation/analyse-journal-roue-club.md, section 6) :
//   - colonnes repérées par leur EN-TÊTE, jamais par leur lettre (le Sheets a déjà inséré une colonne
//     « Earnings » qui a décalé son propre guide d'une lettre) ;
//   - statut DÉDUIT (rachat rempli, cours de clôture vs strike, échéance passée), toujours montré avec
//     sa raison dans l'aperçu, et modifiable avant import ;
//   - ligne incohérente (ex. LULU ouverte le 26/12/2026, fermée le 02/01/2026) SIGNALÉE et décochée
//     par défaut, jamais corrigée en silence ;
//   - ré-import sans doublon : une position déjà présente (même symbole, type, strike, ouverture,
//     échéance) est ignorée ; rien de saisi dans castellana n'est jamais écrasé ;
//   - le stop d'une action (exigé par le Journal actions) n'existe pas dans le Sheets : il est demandé
//     par cycle, jamais inventé.

// ---- Lecture des fichiers ----

function roueImpNorm(s) {
  return String(s == null ? '' : s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
}

function roueImpXmlText(s) {
  return String(s).replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n))).replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16))).replace(/&amp;/g, '&');
}

async function roueImpInflate(bytes) {
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

// Fichiers d'un zip : { nom: Uint8Array } pour les noms demandés seulement.
async function roueImpUnzip(buffer, wanted) {
  const bytes = new Uint8Array(buffer);
  const view = new DataView(buffer);
  let eocd = -1;
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) if (view.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('Fichier .xlsx illisible (zip sans répertoire central).');
  const count = view.getUint16(eocd + 10, true);
  let p = view.getUint32(eocd + 16, true);
  const dec = new TextDecoder();
  const out = {};
  for (let k = 0; k < count; k++) {
    if (view.getUint32(p, true) !== 0x02014b50) throw new Error('Fichier .xlsx illisible (entrée de zip corrompue).');
    const method = view.getUint16(p + 10, true);
    const csize = view.getUint32(p + 20, true);
    const nlen = view.getUint16(p + 28, true); const elen = view.getUint16(p + 30, true); const clen = view.getUint16(p + 32, true);
    const local = view.getUint32(p + 42, true);
    const name = dec.decode(bytes.subarray(p + 46, p + 46 + nlen));
    p += 46 + nlen + elen + clen;
    if (!wanted(name)) continue;
    const start = local + 30 + view.getUint16(local + 26, true) + view.getUint16(local + 28, true);
    const data = bytes.subarray(start, start + csize);
    if (method === 0) out[name] = data;
    else if (method === 8) out[name] = await roueImpInflate(data);
    else throw new Error(`Compression non prise en charge (${method}) pour ${name}.`);
  }
  return out;
}

function roueImpColIndex(ref) {
  const letters = /^[A-Z]+/.exec(ref)[0];
  let n = 0;
  for (const ch of letters) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
}

// { 'JOURNAL': [[…], …], … } — valeurs EN CACHE des cellules (le résultat des formules, pas la formule).
async function roueImpReadXlsx(buffer, sheetNames = ['JOURNAL', 'RAPPORT HEBDO', 'PORTFOLIO', 'Semaines']) {
  const files = await roueImpUnzip(buffer, (n) => n === 'xl/workbook.xml' || n === 'xl/_rels/workbook.xml.rels' || n === 'xl/sharedStrings.xml' || /^xl\/worksheets\/sheet\d+\.xml$/.test(n));
  const txt = (n) => (files[n] ? new TextDecoder().decode(files[n]) : '');
  const rels = {};
  for (const m of txt('xl/_rels/workbook.xml.rels').matchAll(/<Relationship\b[^>]*>/g)) {
    const id = /Id="([^"]+)"/.exec(m[0]); const target = /Target="([^"]+)"/.exec(m[0]);
    if (id && target) rels[id[1]] = 'xl/' + target[1].replace(/^\/?xl\//, '');
  }
  const shared = [...txt('xl/sharedStrings.xml').matchAll(/<si>([\s\S]*?)<\/si>/g)].map((m) => roueImpXmlText([...m[1].matchAll(/<t[^>]*>([\s\S]*?)<\/t>/g)].map((t) => t[1]).join('')));
  const out = {};
  for (const m of txt('xl/workbook.xml').matchAll(/<sheet\b[^>]*>/g)) {
    const name = roueImpXmlText((/name="([^"]*)"/.exec(m[0]) || [])[1] || '');
    const rid = (/r:id="([^"]+)"/.exec(m[0]) || [])[1];
    if (!sheetNames.includes(name) || !rels[rid]) continue;
    const rows = [];
    for (const r of txt(rels[rid]).matchAll(/<row\b[^>]*\br="(\d+)"[^>]*>([\s\S]*?)<\/row>/g)) {
      const row = [];
      for (const c of r[2].matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
        const ref = (/\br="([A-Z]+\d+)"/.exec(c[1]) || [])[1];
        if (!ref) continue;
        const t = (/\bt="([^"]+)"/.exec(c[1]) || [])[1];
        const inner = c[2] || '';
        const v = (/<v>([\s\S]*?)<\/v>/.exec(inner) || [])[1];
        let val = null;
        if (t === 's') val = v != null ? shared[Number(v)] ?? null : null;
        else if (t === 'inlineStr') val = roueImpXmlText([...inner.matchAll(/<t[^>]*>([\s\S]*?)<\/t>/g)].map((x) => x[1]).join(''));
        else if (t === 'str' || t === 'e') val = v != null ? roueImpXmlText(v) : null;
        else if (t === 'b') val = v === '1';
        else val = v != null && v !== '' ? Number(v) : null;
        row[roueImpColIndex(ref)] = val;
      }
      rows[Number(r[1]) - 1] = row;
    }
    out[name] = Array.from(rows, (x) => x || []);
  }
  return out;
}

// CSV exporté de Google Sheets (« Fichier → Télécharger → CSV » sur l'onglet JOURNAL). Séparateur
// virgule ou point-virgule, guillemets doublés.
function roueImpParseCsv(text) {
  const src = String(text).replace(/^﻿/, '');
  const firstLine = src.split(/\r?\n/, 1)[0];
  const sep = (firstLine.match(/;/g) || []).length > (firstLine.match(/,/g) || []).length ? ';' : ',';
  const rows = []; let row = []; let cell = ''; let q = false;
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (q) {
      if (ch === '"' && src[i + 1] === '"') { cell += '"'; i++; } else if (ch === '"') q = false; else cell += ch;
    } else if (ch === '"') q = true;
    else if (ch === sep) { row.push(cell); cell = ''; }
    else if (ch === '\n' || ch === '\r') { if (ch === '\r' && src[i + 1] === '\n') i++; row.push(cell); rows.push(row); row = []; cell = ''; }
    else cell += ch;
  }
  if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
  return rows.map((r) => r.map((c) => (c === '' ? null : c)));
}

// ---- Valeurs ----

function roueImpNumber(v) {
  if (v == null || v === '') return null;
  if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  let s = String(v).replace(/[\s $€%]/g, '');
  if (s.includes(',') && !s.includes('.')) s = s.replace(',', '.');
  else s = s.replace(/,/g, '');
  const n = Number(s);
  return s !== '' && Number.isFinite(n) ? n : null;
}

// Date ISO depuis un numéro de série (xlsx), « AAAA-MM-JJ[ hh:mm:ss] » ou « JJ/MM/AAAA » (Sheets en français).
function roueImpDate(v) {
  if (v == null || v === '') return null;
  if (typeof v === 'number') {
    if (!(v > 20000 && v < 80000)) return null;
    return new Date(Date.UTC(1899, 11, 30) + Math.floor(v) * 86400000).toISOString().slice(0, 10);
  }
  const s = String(v).trim();
  let m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
  if (m) return `${m[1]}-${m[2]}-${m[3]}`;
  m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(s);
  if (m) return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
  return null;
}

// ---- Onglet JOURNAL ----

const ROUE_IMP_COLUMNS = {
  ticker: ['ticker'], semaine: ['semaine'], type: ['type'], date: ['date'], debut: ['debut cycle'], fermeture: ['fermeture'],
  strike: ['strike'], qte: ['qte'], prix: ['prix option'], commission: ['commission'], rachat: ['rachat'], dividendes: ['dividendes'],
  close: ['close'], assigne: ['assigne / en position'], idCycle: ['id cycle'], notes: ['notes'],
};

// Lignes du JOURNAL → objets normalisés. L'en-tête est la première ligne qui contient « Ticker » et « Type ».
function roueImpJournalRows(rows) {
  const h = rows.findIndex((r) => r && r.some((c) => roueImpNorm(c) === 'ticker') && r.some((c) => roueImpNorm(c) === 'type'));
  if (h < 0) throw new Error('En-tête introuvable : aucune ligne ne contient « Ticker » et « Type ». Est-ce bien l\'onglet JOURNAL ?');
  const header = rows[h].map(roueImpNorm);
  const col = {};
  for (const [key, names] of Object.entries(ROUE_IMP_COLUMNS)) col[key] = header.findIndex((x) => names.includes(x));
  const manquantes = ['ticker', 'type', 'strike', 'qte', 'fermeture'].filter((k) => col[k] < 0);
  if (manquantes.length) throw new Error(`Colonnes introuvables dans l'en-tête : ${manquantes.join(', ')}.`);
  const get = (r, k) => (col[k] >= 0 ? r[col[k]] : null);
  const out = [];
  rows.slice(h + 1).forEach((r, i) => {
    if (!r) return;
    const ticker = String(get(r, 'ticker') ?? '').trim().toUpperCase();
    if (!ticker) return;
    const tickerInvalide = !isValidTicker(ticker);
    const qte = roueImpNumber(get(r, 'qte'));
    out.push({
      ligne: h + 2 + i, ticker, tickerInvalide, type: roueImpNorm(get(r, 'type')).toUpperCase(),
      date: roueImpDate(get(r, 'date')), debut: roueImpDate(get(r, 'debut')), fermeture: roueImpDate(get(r, 'fermeture')),
      strike: roueImpNumber(get(r, 'strike')), contrats: qte, prix: roueImpNumber(get(r, 'prix')),
      commission: roueImpNumber(get(r, 'commission')), rachat: roueImpNumber(get(r, 'rachat')), dividendes: roueImpNumber(get(r, 'dividendes')),
      close: roueImpNumber(get(r, 'close')), assigne: roueImpNorm(get(r, 'assigne')) === 'oui',
      idCycle: get(r, 'idCycle') ? String(get(r, 'idCycle')).trim() : null, notes: get(r, 'notes') ? String(get(r, 'notes')) : null,
    });
  });
  return out;
}

// Statut d'une ligne PUT/CALL, avec sa raison. Même règle que le Sheets (assignation déduite du
// cours de clôture à l'échéance), mais affichée et modifiable : elle rate l'assignation anticipée.
function roueImpDeduce(r, today) {
  if (r.rachat != null && r.rachat > 0) return { statut: 'rachete', raison: `Rachat rempli (${r.rachat})` };
  if (!r.fermeture || r.fermeture > today) return { statut: 'ouvert', raison: 'Échéance à venir' };
  if (r.close == null) return { statut: 'expire', raison: 'Cours de clôture absent : supposé expiré, à vérifier', aVerifier: true };
  if (r.close === r.strike) return { statut: 'expire', raison: `Clôture ${r.close} = strike : à vérifier`, aVerifier: true };
  const dans = r.type === 'PUT' ? r.close < r.strike : r.close > r.strike;
  return dans
    ? { statut: 'assigne', raison: `Clôture ${r.close} ${r.type === 'PUT' ? '<' : '>'} strike ${r.strike}` }
    : { statut: 'expire', raison: `Clôture ${r.close}, hors de la monnaie` };
}

function roueImpLegKey(o) { return [o.ticker, o.type, Number(o.strike), o.date_ouverture, o.echeance].join('|'); }

// Plan d'import : cycles → opérations, avec doublons, incohérences et besoin de stop.
//   existingLegs   : jambes déjà présentes (tous comptes) — clé de doublon ;
//   existingTrades : lignes du Journal actions — pour ne pas recréer un achat.
function roueImpPlan(journal, { today, compte, contractSize = 100, existingLegs = [], existingTrades = [] } = {}) {
  const seen = new Map(existingLegs.filter((l) => !compte || l.compte === compte).map((l) => [roueImpLegKey(l), l]));
  const cycles = new Map();
  for (const r of journal) {
    const debut = r.debut || r.date || r.fermeture;
    const key = r.idCycle || `${r.ticker}-${(debut || '').replace(/-/g, '')}`;
    if (!cycles.has(key)) cycles.set(key, { key, ticker: r.ticker, debut, ops: [], dejaCycleId: null });
    const c = cycles.get(key);
    if (debut && (!c.debut || debut < c.debut)) c.debut = debut;
    if (r.type === 'PUT' || r.type === 'CALL') {
      const leg = { type: r.type.toLowerCase(), ticker: r.ticker, strike: r.strike, contrats: r.contrats, prime_recue: r.prix, date_ouverture: r.date || r.debut, echeance: r.fermeture, commission_ouverture: r.commission };
      const d = roueImpDeduce(r, today);
      const issues = [];
      if (r.tickerInvalide) issues.push('symbole invalide');
      if (!(r.strike > 0)) issues.push('strike manquant');
      if (!(r.contrats > 0)) issues.push('quantité manquante');
      if (r.prix == null) issues.push('prime manquante');
      if (!leg.date_ouverture) issues.push('date d\'ouverture manquante');
      issues.push(...optLegIssues({ ...leg, statut: d.statut, date_cloture: d.statut === 'ouvert' ? null : r.fermeture }).filter((x) => x !== 'jambe close sans date de clôture'));
      const doublon = seen.get(roueImpLegKey(leg));
      if (doublon && doublon.cycle_id) c.dejaCycleId = doublon.cycle_id;
      c.ops.push({ kind: 'jambe', ligne: r.ligne, leg, statut: d.statut, raison: d.raison, aVerifier: !!d.aVerifier, primeCloture: d.statut === 'rachete' ? r.rachat : 0, issues, doublon: !!doublon, include: !doublon && !issues.length, dividendes: r.dividendes });
    } else if (r.type === 'ACHAT' || r.type === 'VENTE') {
      const date = r.fermeture || r.date;
      const issues = [];
      if (r.tickerInvalide) issues.push('symbole invalide');
      if (!(r.strike > 0)) issues.push('prix manquant');
      if (!(r.contrats > 0)) issues.push('quantité manquante');
      if (!date) issues.push('date manquante');
      const actions = (r.contrats || 0) * contractSize;
      const memeCompte = (t) => t.ticker === r.ticker && (!compte || t.compte === compte);
      const doublon = r.type === 'ACHAT'
        ? existingTrades.some((t) => memeCompte(t) && t.date_entree === date && Number(t.prix_entree) === Number(r.strike))
        : existingTrades.some((t) => memeCompte(t) && t.date_sortie === date && Number(t.prix_sortie) === Number(r.strike));
      c.ops.push({ kind: r.type === 'ACHAT' ? 'achat' : 'vente', ligne: r.ligne, ticker: r.ticker, date, prix: r.strike, actions, commission: r.commission, issues, doublon, include: !doublon && !issues.length, dividendes: r.dividendes });
    } else {
      c.ops.push({ kind: 'inconnu', ligne: r.ligne, ticker: r.ticker, issues: [...(r.tickerInvalide ? ['symbole invalide'] : []), `type « ${r.type || 'vide'} » inconnu`], include: false });
    }
  }
  const list = [...cycles.values()].map((c) => ({
    ...c,
    besoinStop: c.ops.some((o) => o.include && ((o.kind === 'jambe' && o.leg.type === 'put' && o.statut === 'assigne') || o.kind === 'achat')),
  })).sort((a, b) => ((a.debut || '') < (b.debut || '') ? -1 : 1));
  const ops = list.flatMap((c) => c.ops);
  return {
    cycles: list,
    resume: {
      lignes: ops.length, aImporter: ops.filter((o) => o.include).length, doublons: ops.filter((o) => o.doublon).length,
      incoherentes: ops.filter((o) => o.issues && o.issues.length).length, aVerifier: ops.filter((o) => o.aVerifier).length,
    },
  };
}

// Capital de départ (PORTFOLIO C9 « Capital de départ »), dépôts/retraits et autres revenus (RAPPORT
// HEBDO), datés par la table Semaines (colonne « Expiration réelle », le vendredi). Le capital de départ
// est daté du dimanche de la semaine 1.
function roueImpFlowsFromXlsx(sheets) {
  const flows = [];
  const weekDate = new Map();
  for (const r of sheets.Semaines || []) if (r && /^semaine \d+$/.test(roueImpNorm(r[0])) && roueImpDate(r[2])) weekDate.set(roueImpNorm(r[0]), roueImpDate(r[2]));
  const sem1 = weekDate.get('semaine 1');
  const portfolio = sheets.PORTFOLIO || [];
  for (const r of portfolio) {
    const i = (r || []).findIndex((c) => roueImpNorm(c) === 'capital de depart');
    if (i >= 0) {
      const v = roueImpNumber(r[i + 1]);
      if (v > 0 && sem1) flows.push({ type: 'depart', date: new Date(Date.parse(sem1) - 5 * 86400000).toISOString().slice(0, 10), montant: v, source: 'PORTFOLIO, capital de départ' });
      break;
    }
  }
  const rapport = sheets['RAPPORT HEBDO'] || [];
  const h = rapport.findIndex((r) => r && r.some((c) => roueImpNorm(c) === 'semaine'));
  if (h >= 0) {
    const hdr = rapport[h].map(roueImpNorm);
    const cs = hdr.indexOf('semaine'); const cd = hdr.indexOf('depots / retraits'); const ca = hdr.indexOf('autres revenus');
    for (const r of rapport.slice(h + 1)) {
      const date = weekDate.get(roueImpNorm(r && r[cs]));
      if (!date) continue;
      const dep = cd >= 0 ? roueImpNumber(r[cd]) : null;
      if (dep) flows.push({ type: dep > 0 ? 'depot' : 'retrait', date, montant: Math.abs(dep), source: `RAPPORT HEBDO, ${r[cs]}` });
      const aut = ca >= 0 ? roueImpNumber(r[ca]) : null;
      if (aut) flows.push({ type: 'autre_revenu', date, montant: Math.abs(aut), source: `RAPPORT HEBDO, ${r[cs]}` });
    }
  }
  return flows;
}
