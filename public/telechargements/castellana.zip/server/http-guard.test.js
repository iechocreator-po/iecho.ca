// Garde HTTP du serveur local (audit parite-routes, constat 1). On monte les VRAIS middlewares sur la VRAIE racine du projet
// (lecture seule, port libre sur 127.0.0.1, aucune base ouverte) et on vérifie ce qui est servi et ce qui ne l'est plus.
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { readFileSync, readdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import express from 'express';
import { hostGuard, originGuard, publicFiles, hostnameOf, PUBLIC_FILES, PUBLIC_DIRS } from './http-guard.js';

const ROOT = fileURLToPath(new URL('..', import.meta.url));

function startApp() {
  const app = express();
  app.use(hostGuard());
  app.use(express.json());
  app.use(publicFiles(ROOT));
  app.get('/api/ping', (req, res) => res.json({ ok: true }));
  app.use('/api', (req, res) => res.status(404).json({ error: 'inconnue' }));
  return new Promise((ok) => { const s = app.listen(0, '127.0.0.1', () => ok(s)); });
}
function get(server, path, host) {
  return new Promise((ok, ko) => {
    const req = http.request({ host: '127.0.0.1', port: server.address().port, path, method: 'GET', headers: host === null ? {} : { Host: host ?? `127.0.0.1:${server.address().port}` } }, (res) => {
      let body = ''; res.on('data', (d) => { body += d; }); res.on('end', () => ok({ status: res.statusCode, type: res.headers['content-type'] || '', body }));
    });
    req.on('error', ko); req.end();
  });
}

test('hostnameOf : extrait le nom d\'hôte sans port, y compris IPv6', () => {
  assert.equal(hostnameOf('127.0.0.1:4700'), '127.0.0.1');
  assert.equal(hostnameOf('LOCALHOST:4700'), 'localhost');
  assert.equal(hostnameOf('[::1]:4700'), '::1');
  assert.equal(hostnameOf('evil.example.com'), 'evil.example.com');
  assert.equal(hostnameOf(''), null);
  assert.equal(hostnameOf(undefined), null);
});

test('ce dont la page a besoin est servi', async () => {
  const s = await startApp();
  try {
    for (const p of ['/', '/index.html', '/config.js', '/favicon.svg', '/css/app.css', '/css/mode-local.css', '/js/app-base.js', '/js/mode-local.js', '/design-system/tokens.css', '/design-system/components.css']) {
      const r = await get(s, p);
      assert.equal(r.status, 200, `${p} devrait être servi (HTTP ${r.status})`);
    }
    assert.match((await get(s, '/')).type, /text\/html/);
    assert.match((await get(s, '/js/app-base.js')).type, /javascript/);
    assert.match((await get(s, '/css/app.css')).type, /css/);
  } finally { s.close(); }
});

test('tout fichier chargé par index.html est dans la liste publique', () => {
  const html = readFileSync(`${ROOT}index.html`, 'utf8');
  const refs = [...html.matchAll(/(?:src|href)="([^"#?]+)"/g)].map((m) => m[1]).filter((r) => !/^(https?:|data:|\/\/)/.test(r));
  assert.ok(refs.length > 20, 'peu de références trouvées : la regex a-t-elle cassé ?');
  for (const r of refs) {
    const ok = PUBLIC_FILES.includes(r) || PUBLIC_DIRS.some((d) => r.startsWith(`${d}/`));
    assert.ok(ok, `${r} est chargé par index.html mais n'est pas servi : l'ajouter à PUBLIC_FILES/PUBLIC_DIRS (server/http-guard.js)`);
  }
});

test('la base, les réglages, le code et les fichiers du club ne sont PLUS servis', async () => {
  const s = await startApp();
  try {
    const interdits = [
      '/data/castellana.sqlite', '/data/castellana.sqlite-wal', '/data/castellana.sqlite-shm', '/data/runtime.json',
      '/settings.json', '/package.json', '/CLAUDE.md', '/SETUP.md', '/version.json',
      '/server/index.js', '/server/db.js', '/cloud/wrangler.jsonc', '/cloud/src/index.js', '/scripts/doctor.mjs', '/docs/plan-decoupage-index-html.md',
      '/anticipation/cards.json', '/.env', '/.git/config', '/launcher/server.js', '/node_modules/express/package.json',
    ];
    for (const p of interdits) { const r = await get(s, p); assert.equal(r.status, 404, `${p} ne doit pas être servi (HTTP ${r.status})`); }
    // Les fichiers du club (xlsx/csv, ignorés par git mais présents sur le disque) : testés s'ils existent.
    for (const f of readdirSync(`${ROOT}anticipation`).filter((n) => /\.(xlsx|csv)$/i.test(n))) {
      const r = await get(s, `/anticipation/${encodeURIComponent(f)}`);
      assert.equal(r.status, 404, `/anticipation/${f} ne doit pas être servi`);
    }
    // Évasions classiques
    for (const p of ['/js/../data/castellana.sqlite', '/js/%2e%2e/data/castellana.sqlite', '/css/..%2fsettings.json', '/js/', '/design-system/']) {
      const r = await get(s, p); assert.notEqual(r.status, 200, `${p} ne doit pas répondre 200`);
    }
  } finally { s.close(); }
});

test('Host : l\'ordinateur local passe, tout autre hôte est refusé (anti « DNS rebinding »), API comprise', async () => {
  const s = await startApp();
  try {
    const port = s.address().port;
    for (const h of [`127.0.0.1:${port}`, `localhost:${port}`, `LOCALHOST:${port}`, `[::1]:${port}`]) {
      assert.equal((await get(s, '/api/ping', h)).status, 200, `Host ${h} devrait passer`);
    }
    for (const h of ['evil.example.com', `evil.example.com:${port}`, `127.0.0.1.evil.example.com:${port}`, 'localhost.evil.com', '192.168.1.20:4700', '0.0.0.0:4700']) {
      for (const p of ['/api/ping', '/', '/js/app-base.js']) {
        const r = await get(s, p, h);
        assert.equal(r.status, 403, `Host ${h} sur ${p} devrait être refusé (HTTP ${r.status})`);
      }
    }
    // Sans en-tête Host (Node en ajoute un tout seul à une requête http.request : on teste donc le middleware directement).
    let code = null; let passed = false;
    hostGuard()({ headers: {} }, { status(c) { code = c; return { json() {} }; } }, () => { passed = true; });
    assert.equal(code, 403, 'sans en-tête Host : refusé'); assert.equal(passed, false);
  } finally { s.close(); }
});

test('hostGuard accepte un hôte supplémentaire explicite (settings.host)', async () => {
  const app = express();
  app.use(hostGuard(['mon-mac.local']));
  app.get('/x', (req, res) => res.json({ ok: 1 }));
  const s = await new Promise((ok) => { const x = app.listen(0, '127.0.0.1', () => ok(x)); });
  try {
    assert.equal((await get(s, '/x', 'mon-mac.local:4700')).status, 200);
    assert.equal((await get(s, '/x', 'autre.local:4700')).status, 403);
  } finally { s.close(); }
});

test('server/index.js utilise la garde et ne sert plus la racine entière', () => {
  const src = readFileSync(new URL('./index.js', import.meta.url), 'utf8');
  assert.ok(!/express\.static\(\s*ROOT\s*\)/.test(src), 'express.static(ROOT) est revenu dans server/index.js : il expose la base de données et le code');
  const iGuard = src.indexOf('app.use(hostGuard(');
  const iJson = src.indexOf('app.use(express.json()');
  const iFiles = src.indexOf('app.use(publicFiles(ROOT))');
  assert.ok(iGuard > 0 && iFiles > 0, 'hostGuard et publicFiles doivent être montés dans server/index.js');
  assert.ok(iGuard < iJson && iGuard < iFiles, 'hostGuard doit être le PREMIER middleware (avant json et les fichiers)');
  assert.ok(iGuard < src.indexOf("app.get('/api/health'"), 'hostGuard doit précéder toutes les routes');
});

// Audit routes (21/10/2026) : une page web quelconque ne doit pas pouvoir écrire dans l'API locale, même sans corps JSON.
function startOriginApp() {
  const app = express();
  app.use(hostGuard());
  app.use(originGuard());
  app.use(express.json());
  app.post('/api/action', (req, res) => res.json({ ok: true }));
  app.get('/api/lire', (req, res) => res.json({ ok: true }));
  return new Promise((ok) => { const s = app.listen(0, '127.0.0.1', () => ok(s)); });
}
function send(server, method, path, headers = {}) {
  return new Promise((ok, ko) => {
    const req = http.request({ host: '127.0.0.1', port: server.address().port, path, method, headers: { Host: `127.0.0.1:${server.address().port}`, ...headers } }, (res) => {
      res.resume(); res.on('end', () => ok(res.statusCode));
    });
    req.on('error', ko); req.end();
  });
}
test('originGuard : une écriture venue d\'un autre site est refusée, la page locale et les outils sans Origin passent', async () => {
  const server = await startOriginApp();
  try {
    assert.equal(await send(server, 'POST', '/api/action', { Origin: 'https://evil.example' }), 403, 'autre site');
    assert.equal(await send(server, 'POST', '/api/action', { Origin: 'null' }), 403, 'origine opaque');
    assert.equal(await send(server, 'DELETE', '/api/action', { Origin: 'http://192.168.0.9:4700' }), 403, 'autre machine');
    assert.equal(await send(server, 'POST', '/api/action', { Origin: `http://127.0.0.1:${server.address().port}` }), 200, 'la page locale');
    assert.equal(await send(server, 'POST', '/api/action', { Origin: 'http://localhost:4700' }), 200, 'localhost');
    assert.equal(await send(server, 'POST', '/api/action'), 200, 'curl / webhook sans Origin');
    assert.equal(await send(server, 'GET', '/api/lire', { Origin: 'https://evil.example' }), 200, 'une lecture n\'est pas touchée (CORS la protège)');
  } finally { server.close(); }
});

test('originGuard : une lecture /api venue d\'un autre site (Sec-Fetch-Site: cross-site) est refusée', async () => {
  const server = await startOriginApp();
  try {
    assert.equal(await send(server, 'GET', '/api/lire', { 'Sec-Fetch-Site': 'cross-site' }), 403, 'un <img> d\'une autre page');
    assert.equal(await send(server, 'GET', '/api/lire', { 'Sec-Fetch-Site': 'same-origin' }), 200, 'la page castellana elle-même');
    assert.equal(await send(server, 'GET', '/api/lire', { 'Sec-Fetch-Site': 'none' }), 200, 'barre d\'adresse');
    assert.equal(await send(server, 'GET', '/api/lire'), 200, 'curl / navigateurs sans l\'en-tête');
  } finally { server.close(); }
});
