// Évalue js/roue-import.js pour les tests Node — même patron que server/options-analytics.js : le
// navigateur et les tests partagent ainsi UN lecteur xlsx/csv et UN planificateur d'import (#436).
// roue-import.js utilise optLegIssues (js/options-analytics.js, chargé avant lui dans la page).
import { readFileSync } from 'node:fs';
import { optLegIssues } from './options-analytics.js';
import { isValidTicker } from './ticker-format.js';

const source = readFileSync(new URL('../js/roue-import.js', import.meta.url), 'utf8');
export const {
  roueImpReadXlsx, roueImpParseCsv, roueImpJournalRows, roueImpPlan, roueImpFlowsFromXlsx, roueImpDate, roueImpNumber, roueImpDeduce,
} = new Function('optLegIssues', 'isValidTicker', `${source}; return { roueImpReadXlsx, roueImpParseCsv, roueImpJournalRows, roueImpPlan, roueImpFlowsFromXlsx, roueImpDate, roueImpNumber, roueImpDeduce };`)(optLegIssues, isValidTicker);
