#!/bin/bash
# castellana comme service macOS (launchd) — 17/10/2026.
#
# Pourquoi : lancé depuis un terminal ou une session Claude Code, le serveur meurt avec
# eux. Un LaunchAgent le démarre à l'ouverture de session et le RELANCE tout seul s'il
# s'arrête (KeepAlive), sans terminal ouvert. Rien n'est installé hors de ~/Library/LaunchAgents.
#
#   npm run service:install     installe et démarre
#   npm run service:restart     relance (après un git pull, par exemple)
#   npm run service:status      état et dernières lignes du journal
#   npm run service:uninstall   arrête et retire
#
# Journal : data/castellana-service.log (data/ est gitignoré).
set -euo pipefail

LABEL="ca.iecho.castellana"
DIR="$(cd "$(dirname "$0")/.." && pwd)"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
LOG="$DIR/data/castellana-service.log"
DOMAIN="gui/$(id -u)"
NODE="$(command -v node || true)"

# Échappement XML des chemins écrits dans le plist (audit périphérie, 22/10/2026) : un dossier contenant « & » ou « < » le cassait.
xml() { printf '%s' "$1" | sed -e 's/&/\&amp;/g' -e 's/</\&lt;/g' -e 's/>/\&gt;/g'; }
XDIR="$(xml "$DIR")"; XNODE="$(xml "$NODE")"; XLOG="$(xml "$LOG")"; XNODEDIR="$(xml "$(dirname "$NODE")")"

case "${1:-}" in
  install)
    [ -n "$NODE" ] || { echo "Node introuvable dans le PATH."; exit 1; }
    mkdir -p "$DIR/data" "$HOME/Library/LaunchAgents"
    # Un serveur déjà lancé à la main tient le port 4700 : on l'arrête pour que le service le reprenne.
    PIDS="$(lsof -ti:4700 -sTCP:LISTEN || true)"
    [ -n "$PIDS" ] && { echo "Arrêt du serveur lancé à la main (PID $PIDS)."; kill $PIDS || true; sleep 1; }
    cat > "$PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key><array><string>$XNODE</string><string>$XDIR/server/index.js</string></array>
  <key>WorkingDirectory</key><string>$XDIR</string>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>ThrottleInterval</key><integer>10</integer>
  <key>StandardOutPath</key><string>$XLOG</string>
  <key>StandardErrorPath</key><string>$XLOG</string>
  <key>EnvironmentVariables</key><dict><key>PATH</key><string>$XNODEDIR:/usr/bin:/bin:/usr/sbin:/sbin</string></dict>
</dict>
</plist>
EOF
    launchctl bootout "$DOMAIN/$LABEL" 2>/dev/null || true
    launchctl bootstrap "$DOMAIN" "$PLIST"
    sleep 2
    echo "Service installé. castellana : http://127.0.0.1:4700/ (journal : $LOG)"
    ;;
  restart)
    launchctl kickstart -k "$DOMAIN/$LABEL" && echo "castellana relancé."
    ;;
  status)
    if launchctl print "$DOMAIN/$LABEL" >/dev/null 2>&1; then
      launchctl print "$DOMAIN/$LABEL" | grep -E "state =|pid =|last exit code" || true
    else
      echo "Service non installé (npm run service:install)."
    fi
    [ -f "$LOG" ] && { echo "--- $LOG"; tail -n 5 "$LOG"; }
    ;;
  uninstall)
    launchctl bootout "$DOMAIN/$LABEL" 2>/dev/null || true
    rm -f "$PLIST"
    echo "Service retiré. Pour lancer à la main : npm start"
    ;;
  *)
    echo "Usage : $0 install|restart|status|uninstall"; exit 1
    ;;
esac
