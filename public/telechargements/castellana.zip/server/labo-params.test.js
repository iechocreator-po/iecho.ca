// Tests des paramètres de stratégies d'options (onglet Labo).
//
// Les règles de validation vivent dans js/labo-schema.js (pur, partagé avec
// le navigateur et le Worker) — on les teste directement, sans base. La
// persistance locale est testée sur la vraie base, avec restauration de
// l'état initial (même discipline que preferences.test.js).

import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import {
  schema, getAllOverrides, setStrategyParams, resetStrategyParams, resetAllStrategyParams,
} from './labo-params.js';
import { db } from './db.js';

const { LABO_SCHEMA, laboDefaults, laboEffectiveParams, laboMergeOverrides } = schema;

test('les quatre stratégies disponibles ont chacune leurs paramètres, sans clé en double', () => {
  assert.deepEqual(Object.keys(LABO_SCHEMA.strategies).sort(), ['credit-spreads', 'debit-spreads', 'pmcc', 'roue']);
  for (const [id, def] of Object.entries(LABO_SCHEMA.strategies)) {
    const keys = def.params.map((p) => p.key);
    assert.equal(new Set(keys).size, keys.length, `${id} : clé en double`);
    for (const p of def.params) {
      assert.ok(p.default >= p.min && p.default <= p.max, `${id}.${p.key} : défaut hors bornes`);
      if (p.lte) assert.ok(keys.includes(p.lte), `${id}.${p.key} : lte vers une clé inconnue`);
    }
  }
});

test('les défauts reprennent les anciennes valeurs de config.js (DTE 5-10 j depuis le 3/10/2026, delta 0.15-0.25, 50-80 %)', () => {
  const d = laboDefaults('roue');
  assert.equal(d.putDteMin, 5);
  assert.equal(d.putDteMax, 10);
  assert.equal(d.putDeltaMin, 0.15);
  assert.equal(d.putDeltaMax, 0.25);
  assert.equal(d.profitTakeMin, 50);
  assert.equal(d.profitTakeMax, 80);
  assert.equal(d.riskFreePct, 4);
  assert.equal(d.contractSize, 100);
  assert.equal(laboDefaults('pmcc').leapsDeltaMax, 0.85);
});

test('une valeur valide devient une surcharge, les autres restent aux défauts', () => {
  const { errors, overrides } = laboMergeOverrides('roue', {}, { putDteMin: 8 });
  assert.deepEqual(errors, []);
  assert.deepEqual(overrides, { putDteMin: 8 });
  const eff = laboEffectiveParams('roue', overrides);
  assert.equal(eff.putDteMin, 8);
  assert.equal(eff.putDteMax, 10);
});

test('remettre une valeur à son défaut la retire des surcharges', () => {
  const { overrides } = laboMergeOverrides('roue', { putDteMin: 8 }, { putDteMin: 5 });
  assert.deepEqual(overrides, {});
});

test('refus : hors bornes, non entier, non numérique, clé inconnue', () => {
  assert.match(laboMergeOverrides('roue', {}, { putDeltaMin: 1.5 }).errors[0], /entre 0.01 et 0.99/);
  assert.match(laboMergeOverrides('roue', {}, { putDteMin: 20.5 }).errors[0], /entier attendu/);
  assert.match(laboMergeOverrides('roue', {}, { putDteMin: 'abc' }).errors[0], /nombre attendu/);
  assert.match(laboMergeOverrides('roue', {}, { putDteMin: '' }).errors[0], /nombre attendu/);
  assert.match(laboMergeOverrides('roue', {}, { bidon: 1 }).errors[0], /Paramètre inconnu/);
});

test("refus : une plage à l'envers, jugée sur les valeurs effectives (min vs max existant)", () => {
  // putDteMax reste à 45 ; passer min à 60 inverse la plage.
  const r = laboMergeOverrides('roue', {}, { putDteMin: 60 });
  assert.match(r.errors[0], /ne peut pas dépasser/);
  // Baisser le max sous un min déjà surchargé est refusé aussi.
  const r2 = laboMergeOverrides('roue', { putDteMin: 8 }, { putDteMax: 7 });
  assert.equal(r2.errors.length, 1);
  // Déplacer toute la plage en un seul appel est accepté.
  assert.deepEqual(laboMergeOverrides('roue', {}, { putDteMin: 60, putDteMax: 90 }).errors, []);
});

test('les stratégies « à venir » ou inconnues sont refusées', () => {
  assert.match(laboMergeOverrides('iron-condor', {}, { x: 1 }).errors[0], /inconnue ou sans paramètres/);
  assert.equal(laboEffectiveParams('iron-condor', {}), null);
});

test('stratégie personnalisée : la même mécanique fonctionne à partir d\'une définition fournie', () => {
  const def = { params: [{ key: 'a', label: 'A', group: 'g', type: 'int', default: 5, min: 1, max: 10, step: 1, unit: '' }] };
  assert.deepEqual(laboEffectiveParams('custom:x', {}, def), { a: 5 });
  assert.deepEqual(laboMergeOverrides('custom:x', {}, { a: 7 }, def).overrides, { a: 7 });
  assert.match(laboMergeOverrides('custom:x', {}, { a: 11 }, def).errors[0], /entre 1 et 10/);
});

// ---- Persistance locale (vraie base, état restauré) ----
const initial = db.prepare('SELECT * FROM strategy_params').all();
test.after(() => {
  db.prepare('DELETE FROM strategy_params').run();
  const ins = db.prepare('INSERT INTO strategy_params (strategy_id, kind, params_json, definition_json, schema_version, updated_at) VALUES (?,?,?,?,?,?)');
  for (const r of initial) ins.run(r.strategy_id, r.kind, r.params_json, r.definition_json, r.schema_version, r.updated_at);
});

test('enregistrement puis relecture, une stratégie à la fois', () => {
  resetAllStrategyParams();
  setStrategyParams('roue', { putDteMin: 8, putDeltaMax: 0.3 });
  setStrategyParams('pmcc', { leapsDteMinJours: 200 });
  assert.deepEqual(getAllOverrides(), {
    roue: { putDteMin: 8, putDeltaMax: 0.3 },
    pmcc: { leapsDteMinJours: 200 },
  });
  // Les stratégies sont indépendantes : rien ne fuit de roue vers debit-spreads.
  assert.equal(getAllOverrides()['debit-spreads'], undefined);
});

test('une modification invalide ne touche pas la base', () => {
  resetAllStrategyParams();
  setStrategyParams('roue', { putDteMin: 8 });
  assert.throws(() => setStrategyParams('roue', { putDteMin: 999999 }), (e) => e.code === 'INVALID_LABO_PARAMS');
  assert.deepEqual(getAllOverrides(), { roue: { putDteMin: 8 } });
});

test('remettre toutes les valeurs au défaut supprime la ligne', () => {
  resetAllStrategyParams();
  setStrategyParams('roue', { putDteMin: 8 });
  setStrategyParams('roue', { putDteMin: 5 });
  assert.deepEqual(getAllOverrides(), {});
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM strategy_params').get().n, 0);
});

test('reset d\'une stratégie puis de toutes', () => {
  resetAllStrategyParams();
  setStrategyParams('roue', { putDteMin: 8 });
  setStrategyParams('pmcc', { rouleAvantJours: 60 });
  assert.deepEqual(resetStrategyParams('roue'), { pmcc: { rouleAvantJours: 60 } });
  assert.deepEqual(resetAllStrategyParams(), {});
  assert.deepEqual(getAllOverrides(), {});
  assert.throws(() => resetStrategyParams('bidon'), (e) => e.code === 'INVALID_LABO_PARAMS');
});

test('une clé retirée du schéma n\'est plus renvoyée (pas de valeur orpheline)', () => {
  resetAllStrategyParams();
  db.prepare("INSERT INTO strategy_params (strategy_id, params_json, schema_version) VALUES ('roue', ?, 1)")
    .run(JSON.stringify({ putDteMin: 8, ancienneCle: 9 }));
  assert.deepEqual(getAllOverrides(), { roue: { putDteMin: 8 } });
});

// ---- build() de js/strategies-labo.js avec des surcharges ----
// Le fichier est un script de navigateur (globaux) : on l'évalue comme le
// ferait la page, avec les deux fichiers dans l'ordre de chargement.
function loadBuilders() {
  globalThis.CFG = { labo: { defaultTicker: 'TQQQ' }, indicateurs: { smaRapide: 9, smaMoyenne: 21, smaLente: 50 } };
  const a = readFileSync(new URL('../js/labo-schema.js', import.meta.url), 'utf8');
  const b = readFileSync(new URL('../js/strategies-labo.js', import.meta.url), 'utf8');
  return new Function(`${a}\n${b}\nreturn { STRATEGIES_LABO, laboEffectiveParams };`)();
}

test('build() : le texte suit les paramètres, chaque champ porte sa clé', () => {
  const { STRATEGIES_LABO, laboEffectiveParams: eff } = loadBuilders();
  const roue = STRATEGIES_LABO.find((s) => s.id === 'roue');
  const out = roue.build({ ticker: 'TQQQ', data: null, params: eff('roue', { putDteMin: 21, putDteMax: 28 }) });
  const html = out.steps.map((s) => s.points.join(' ')).join(' ');
  assert.match(html, /data-strat="roue" data-key="putDteMin" value="21"/);
  assert.match(html, /data-key="putDteMax" value="28"/);
  // Une valeur modifiée est marquée, une valeur intacte non.
  assert.match(html, /is-modified"><input[^>]*data-key="putDteMin"/);
  assert.doesNotMatch(html, /is-modified"><input[^>]*data-key="callDteMin"/);
  // Les trois anciennes valeurs codées en dur sont désormais des champs.
  assert.match(html, /data-key="probOtmMin"/);
  assert.match(html, /data-key="contractSize"/);
  // Le DTE de calcul suit la plage : (21+28)/2 arrondi = 25 (24.5 → 25).
  assert.equal(out.legs[0].dteJours, 25);
});

test('build() : sans params, retombe sur les défauts (aucune dépendance à CFG.labo)', () => {
  const { STRATEGIES_LABO } = loadBuilders();
  for (const s of STRATEGIES_LABO.filter((x) => x.statut === 'disponible')) {
    const out = s.build({ ticker: 'AMD', data: null });
    assert.ok(out.steps.length >= 3, s.id);
  }
});

test('build() : les zones de strike réagissent au delta paramétré', () => {
  const { STRATEGIES_LABO, laboEffectiveParams: eff } = loadBuilders();
  const roue = STRATEGIES_LABO.find((s) => s.id === 'roue');
  const data = { price: 100, historicalVolatility: 0.4 };
  const a = roue.build({ ticker: 'X', data, params: eff('roue', {}) }).legs[0];
  const b = roue.build({ ticker: 'X', data, params: eff('roue', { putDeltaMin: 0.30, putDeltaMax: 0.40 }) }).legs[0];
  // Un delta plus élevé rapproche le strike du Put vendu du prix.
  assert.ok(b.atMax.K > a.atMax.K);
});

// ---- Parité des copies ----
// Le schéma existe en trois exemplaires (navigateur, serveur local, Worker).
// Une dérive silencieuse ferait valider un même réglage différemment selon
// l'environnement — ce test la rend bruyante.
test('les copies ESM du Worker sont à jour (npm run sync:cloud)', async () => {
  const { COPIES, buildEsm } = await import('../scripts/sync-cloud-copies.mjs');
  for (const copy of COPIES) {
    const current = readFileSync(new URL(`../${copy.target}`, import.meta.url), 'utf8');
    assert.equal(current, buildEsm(copy), `${copy.target} a dérivé — lance : npm run sync:cloud`);
  }
});

test('les fichiers front de cloud/public sont identiques à leurs sources', () => {
  for (const f of ['js/labo-schema.js', 'js/strategies-labo.js', 'js/concepts-data.js', 'js/concepts-content.js', 'js/ticker-section.js', 'js/symbol-search.js', 'js/options-common.js', 'js/options-analytics.js', 'js/options-tab-a.js', 'js/table-styles.js', 'js/journal-a-tab.js', 'js/roue-tab.js', 'js/roue-import.js', 'js/fcf-card.js', 'js/labo-real-chain.js', 'js/ui-ids.js', 'js/ai-analyst-tab.js', 'config.js']) {
    const a = readFileSync(new URL(`../${f}`, import.meta.url), 'utf8');
    const b = readFileSync(new URL(`../cloud/public/${f}`, import.meta.url), 'utf8');
    assert.equal(b, a, `cloud/public/${f} a dérivé de ${f}`);
  }
});
