// Bilan de la Roue par cycle (#378) — chiffres calculés à la main.
import test from 'node:test';
import assert from 'node:assert/strict';
import { optCycleBilan, optCloseOnOrBefore } from './options-analytics.js';

const put = (o) => ({ type: 'put', strike: 100, contrats: 1, prime_recue: 2, prime_cloture: null, statut: 'ouvert', date_ouverture: '2026-01-02', date_cloture: null, ...o });

test('cycle complet : put assigné puis call couvert assigné (action revendue au strike)', () => {
  const cycle = { statut: 'clos', legs: [
    put({ strike: 100, prime_recue: 2, statut: 'assigne', date_cloture: '2026-02-01' }),
    { ...put({ type: 'call', strike: 105, prime_recue: 1.5, statut: 'assigne', date_ouverture: '2026-02-02', date_cloture: '2026-03-03' }) },
  ] };
  const stock = [{ prix_entree: 100, taille_position: 100, date_sortie: '2026-03-03', prix_sortie: 105 }];
  const b = optCycleBilan(cycle, { stockTrades: stock, priceStart: 100, priceEnd: 108 });
  assert.equal(b.primesEncaissees, 350);          // (2 + 1,5) × 100
  assert.equal(b.rachats, 0);
  assert.equal(b.realiseAction, 500);             // (105 − 100) × 100
  assert.equal(b.pnl, 850);
  assert.equal(b.capital, 10000);                 // strike 100 × 100
  assert.ok(Math.abs(b.rendement - 0.085) < 1e-12);
  assert.equal(b.jours, 60);                      // 2 janv. → 3 mars
  assert.ok(Math.abs(b.rendementAnnualise - 0.085 * 365 / 60) < 1e-12);
  assert.ok(Math.abs(b.holdReturn - 0.08) < 1e-12);
  assert.ok(Math.abs(b.vsHold - 0.005) < 1e-12);  // +0,5 point vs détention
});

test('rachat ou roulement : le coût de rachat réduit les primes nettes', () => {
  const cycle = { statut: 'clos', legs: [put({ prime_recue: 2, statut: 'rachete', prime_cloture: 0.5, date_cloture: '2026-01-20' })] };
  const b = optCycleBilan(cycle, {});
  assert.equal(b.primesNettes, 150);              // (2 − 0,5) × 100
});

test('action encore détenue : latent au dernier cours, coût de base réduit des primes ; inconnu sans cours', () => {
  const cycle = { statut: 'actif', legs: [put({ statut: 'assigne', date_cloture: '2026-02-01', prime_recue: 3 })] };
  const stock = [{ prix_entree: 100, taille_position: 100, date_sortie: null, prix_sortie: null }];
  const b = optCycleBilan(cycle, { stockTrades: stock, priceStart: 100, priceEnd: 96, today: '2026-04-02' });
  assert.equal(b.latentAction, -400);
  assert.equal(b.coutDeBase, 97);                 // (10 000 − 300) / 100
  assert.equal(b.pnl, -100);                      // 300 de primes − 400 latents
  const sansCours = optCycleBilan(cycle, { stockTrades: stock, today: '2026-04-02' });
  assert.equal(sansCours.latentAction, null);
  assert.equal(sansCours.latentConnu, false);
  assert.equal(sansCours.holdReturn, null);
});

test('moins de 30 jours : rendement affiché mais jamais annualisé ; cycle sans jambe : null', () => {
  const cycle = { statut: 'clos', legs: [put({ statut: 'expire', date_cloture: '2026-01-12', prime_recue: 1 })] };
  const b = optCycleBilan(cycle, {});
  assert.equal(b.jours, 10);
  assert.ok(b.rendement > 0);
  assert.equal(b.rendementAnnualise, null);
  assert.equal(optCycleBilan({ statut: 'actif', legs: [] }, {}), null);
});

test('cours à une date : dernier cours du jour ou avant (week-end), null si rien avant', () => {
  const bars = [{ date: '2026-01-02', close: 10 }, { date: '2026-01-05', close: 11 }];
  assert.equal(optCloseOnOrBefore(bars, '2026-01-03'), 10);   // samedi → vendredi
  assert.equal(optCloseOnOrBefore(bars, '2026-01-05'), 11);
  assert.equal(optCloseOnOrBefore(bars, '2025-12-31'), null);
  assert.equal(optCloseOnOrBefore([], '2026-01-05'), null);
});
