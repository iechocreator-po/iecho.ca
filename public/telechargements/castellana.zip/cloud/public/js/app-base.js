// js/app-base.js — Base : config, instances Symbole, onglets, Réglages (fenêtre), disclaimer, thème, largeur, glossaire
// Extrait de l'ancien script en ligne des index.html (découpage phase 2, 20/10/2026) : code déplacé tel quel, sans réécriture.
// Fichier COMMUN aux versions locale et cloud : source ici ; cloud/public/js/app-base.js en est la copie (npm run sync:cloud).
// Script classique : ses noms de premier niveau sont globaux et partagés avec les autres scripts de la page.

function fmt(n) { return new Intl.NumberFormat('fr-CA', { style:'currency', currency:'CAD', maximumFractionDigits:2 }).format(n); }
// ---- Réglages (config.js) appliqués aux libellés, bornes et valeurs par défaut ----
function applyConfig() {
  const ind = CFG.indicateurs;
  document.getElementById('lbl-sma').textContent = `SMA ${ind.smaRapide} > ${ind.smaMoyenne} > ${ind.smaLente}`;
  document.getElementById('lbl-rsi-period').textContent = ind.rsiPeriode;
  document.getElementById('lbl-atr-period').textContent = ind.atrPeriode;

  const atrCfg = CFG.sizing.atrMultiplicateur;
  const atrEl = document.getElementById('atrmult');
  atrEl.min = atrCfg.min; atrEl.max = atrCfg.max; atrEl.step = atrCfg.step; atrEl.value = atrCfg.defaut;

  const riskCfg = CFG.sizing.risquePctBase;
  const riskEl = document.getElementById('riskpct');
  riskEl.min = riskCfg.min; riskEl.max = riskCfg.max; riskEl.step = riskCfg.step; riskEl.value = riskCfg.defaut;

  document.getElementById('capital').value = CFG.defauts.capital;
  document.getElementById('ticker').value = CFG.defauts.ticker;
  document.getElementById('sec-ticker').value = CFG.defauts.ticker;
  document.getElementById('scr-ticker').value = CFG.defauts.ticker;
  document.getElementById('labo-ticker').value = CFG.labo.defaultTicker;
}
// ---- Deux instances Symbole/Force relative/Golden Cross (onglets Secteurs
// et Screener, 2/9/2026) — dupliquées à la demande de JP plutôt que
// déplacées, et volontairement INDÉPENDANTES (pas de synchro en direct
// entre les deux champs Symbole) : l'onglet Screener doit rester un
// espace de travail autonome, où on peut avoir un titre chargé sans
// écraser celui de l'onglet Secteurs. `lastTickerInstance` retient
// laquelle des deux cartes a été utilisée en dernier (saisie, clic sur
// "Récupérer en direct", ou clic sur une ligne de tableau) — c'est elle
// qui alimente la Fiche de trade au changement d'onglet.
const SELECTION_INSTANCES = {
  sec: {
    ticker: 'sec-ticker', tickerCard: 'sec-ticker-card',
    perfTitre: 'sec-perfTitre', perfIndice: 'sec-perfIndice',
    sma50: 'sec-sma50', sma200: 'sec-sma200',
    frBadge: 'sec-fr-badge', frNote: 'sec-fr-note',
    gcBadge: 'sec-gc-badge', gcNote: 'sec-gc-note',
    liveStatus: 'sec-live-status',
  },
  scr: {
    ticker: 'scr-ticker', tickerCard: 'scr-ticker-card',
    perfTitre: 'scr-perfTitre', perfIndice: 'scr-perfIndice',
    sma50: 'scr-sma50', sma200: 'scr-sma200',
    frBadge: 'scr-fr-badge', frNote: 'scr-fr-note',
    gcBadge: 'scr-gc-badge', gcNote: 'scr-gc-note',
    liveStatus: 'scr-live-status',
  },
  // 20/9/2026 — Fiche de trade (fic) et Labo (lab) rejoignent le standard.
  // Leur champ symbole garde son id historique (`ticker`, `labo-ticker`).
  fic: {
    ticker: 'ticker', tickerCard: 'fic-ticker-card',
    perfTitre: 'fic-perfTitre', perfIndice: 'fic-perfIndice',
    sma50: 'fic-sma50', sma200: 'fic-sma200',
    frBadge: 'fic-fr-badge', frNote: 'fic-fr-note',
    gcBadge: 'fic-gc-badge', gcNote: 'fic-gc-note',
    liveStatus: 'fic-live-status',
  },
  lab: {
    ticker: 'labo-ticker', tickerCard: 'lab-ticker-card',
    perfTitre: 'lab-perfTitre', perfIndice: 'lab-perfIndice',
    sma50: 'lab-sma50', sma200: 'lab-sma200',
    frBadge: 'lab-fr-badge', frNote: 'lab-fr-note',
    gcBadge: 'lab-gc-badge', gcNote: 'lab-gc-note',
    liveStatus: 'lab-live-status',
  },
};
// Seules Secteurs et Screener alimentent la Fiche au changement d'onglet
// (`lastTickerInstance`) : la Fiche et le Labo ont chacun leur symbole propre.
const LINKED_INSTANCES = ['sec', 'scr'];
let lastTickerInstance = 'sec';
// Faux tant que l'application n'est pas démarrée (cloud : avant la connexion) : les minuteries ne doivent rien appeler.
let appDemarree = false;
// Symbole pour lequel les champs d'une instance ont été REMPLIS par un
// « Récupérer en direct ». Si le symbole change ensuite, ces valeurs sont
// celles d'un AUTRE titre : on les efface plutôt que de les laisser sous le
// nouveau symbole (un verdict faux et crédible). La Fiche avait déjà ce
// garde-fou ; il vaut désormais partout.
const selectionFetchedFor = {};
// Cibles de la bannière de verdict (force relative + Golden Cross), une par
// onglet portant un titre — 11/9/2026, demande de JP de la déplacer dans la
// section « Symbole » des trois onglets. Séparé de SELECTION_INSTANCES
// exprès : `fiche` n'est PAS une instance de carte Symbole (pas de champs de
// saisie, pas de badges), et l'y mettre ferait croire à switchTab() et à
// `lastTickerInstance` qu'il en existe une troisième.
const BANNER_TARGETS = {
  sec: { ticker: 'sec-ticker', banner: 'sec-banner', text: 'sec-banner-text', btn: 'sec-banner-btn',
         fetchLabel: '« Récupérer en direct » (ou une ligne de tableau)', champTicker: '« Symbole évalué »' },
  scr: { ticker: 'scr-ticker', banner: 'scr-banner', text: 'scr-banner-text', btn: 'scr-banner-btn',
         fetchLabel: '« Récupérer en direct » (ou une ligne de tableau)', champTicker: '« Symbole évalué »' },
  fic: { ticker: 'ticker', banner: 'fic-banner', text: 'fic-banner-text', btn: 'fic-banner-btn',
         fetchLabel: '« Récupérer en direct »', champTicker: '« Symbole évalué »' },
  lab: { ticker: 'labo-ticker', banner: 'lab-banner', text: 'lab-banner-text', btn: 'lab-banner-btn',
         fetchLabel: '« Récupérer en direct »', champTicker: '« Symbole évalué »' },
};
// ---- Onglets ----
function switchTab(name) {
  document.querySelectorAll('.tab-btn').forEach(b => {
    const active = b.dataset.tab === name;
    b.classList.toggle('is-active', active);
    b.setAttribute('aria-selected', active ? 'true' : 'false');
  });
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.toggle('is-active', p.id === 'tab-' + name));
  if (name === 'labo' && typeof laboAutoLoadOnce === 'function') laboAutoLoadOnce();
  if (name === 'fiche') {
    // Le titre de la carte Symbole utilisée en dernier (Secteurs ou
    // Screener) alimente la fiche de trade.
    // Garde ajoutée le 11/9/2026 : `lastTickerInstance` peut ne désigner
    // aucune carte Symbole (arrivée depuis le bouton « Préparer » du
    // screening, par exemple). Sans elle, l'accès plantait tout le
    // changement d'onglet.
    const inst = SELECTION_INSTANCES[lastTickerInstance];
    const selTicker = inst ? document.getElementById(inst.ticker).value : '';
    // Ne recopie que si le symbole diffère : sinon un simple retour sur l'onglet écrasait le titre préparé, et un
    // changement de symbole laissait RSI/ATR/OBV de l'ancien titre sous le nouveau (audit app-js, constat 1).
    const ficheTicker = document.getElementById('ticker');
    if (selTicker && ficheTicker.value.trim().toUpperCase() !== selTicker.toUpperCase()) {
      ficheTicker.value = selTicker;
      document.getElementById('rsi').value = '';
      document.getElementById('atr').value = '';
      document.getElementById('obv').selectedIndex = 0;
      calcFiche();
    }
  }
  if (name === 'journal') {
    loadTrades();
    loadStats();
  }
}
// ---- Réglages (overlay plein écran, même principe que essen/nemesis-retaliation) ----
function togglePersoWide() {
  const m = document.querySelector('.settings-main');
  const wide = m.classList.toggle('is-wide');
  document.getElementById('perso-expand').textContent = wide ? '⤡ Réduire' : '⤢ Agrandir';
}
function openSettings() { document.getElementById('settings-overlay').style.display = 'flex'; }
function closeSettings() { document.getElementById('settings-overlay').style.display = 'none'; }
function switchSettingsTab(name) {
  document.querySelectorAll('.settings-tab-btn').forEach((b) => {
    const active = b.dataset.stab === name;
    b.classList.toggle('is-active', active);
    b.setAttribute('aria-selected', active ? 'true' : 'false');
  });
  document.querySelectorAll('.settings-tab-panel').forEach((p) => p.classList.toggle('is-active', p.id === 'settings-tab-' + name));
}
// ---- Disclaimer réductible (27/9/2026) — ouvert par défaut à la toute
// première visite (rien en localStorage), l'état choisi ensuite (déplié ou
// replié) est mémorisé par navigateur, même patron que le thème et les
// repères d'interface (js/ui-ids.js) ----
const DISCLAIMER_STORAGE_KEY = 'castellana-disclaimer-open';
function initDisclaimerCollapse() {
  const el = document.getElementById('disclaimer-wrap');
  if (!el) return;
  try {
    const saved = localStorage.getItem(DISCLAIMER_STORAGE_KEY);
    if (saved === 'false') el.removeAttribute('open');
  } catch { /* localStorage indisponible : reste ouvert, comportement par défaut */ }
  el.addEventListener('toggle', () => {
    try { localStorage.setItem(DISCLAIMER_STORAGE_KEY, el.open ? 'true' : 'false'); } catch { /* jamais bloquant */ }
  });
}
// ---- Bascule de thème (feature 321) — logique canonique du design system,
// persistée en localStorage (clé propre à castellana) ----
function appliquerTheme(choix) {
  if (choix === 'light' || choix === 'dark') {
    document.documentElement.setAttribute('data-theme', choix);
  } else {
    document.documentElement.removeAttribute('data-theme');
    choix = 'auto';
  }
  document.querySelectorAll('#theme-switch button').forEach(b =>
    b.classList.toggle('is-active', b.dataset.themeChoice === choix));
  try { localStorage.setItem('castellana-theme', choix); } catch { /* stockage bloqué : le thème vaut pour cette visite */ }
}
// ---- Largeur de l'application (Réglages → Personnalisation) — même largeur partout ----
function setAppWidth(choix) {
  if (!['etroite', 'large', 'pleine'].includes(choix)) choix = 'large';
  if (choix === 'large') document.documentElement.removeAttribute('data-app-width');
  else document.documentElement.setAttribute('data-app-width', choix);
  document.querySelectorAll('.largeur-option').forEach((b) => {
    const actif = b.dataset.appWidthChoice === choix;
    b.classList.toggle('is-active', actif);
    b.setAttribute('aria-checked', String(actif));
  });
  try { localStorage.setItem('castellana-app-width', choix); } catch { /* navigation privée */ }
  // Les graphiques SVG se redessinent à leur nouvelle largeur.
  window.dispatchEvent(new Event('resize'));
}
// ---- Glossaire pédagogique (feature 321) — popover lisant window.GLOSSAIRE ----
function showGlossaire(key, anchor) {
  const g = window.GLOSSAIRE?.[key];
  const pop = document.getElementById('glossaire-pop');
  if (!g) { pop.style.display = 'none'; return; }
  const bandes = (g.bandes || []).map(b =>
    `<div class="gp-bande"><span class="gp-dot gp-${b.couleur}"></span><span class="gp-seuil">${b.seuil}</span><span>${b.sens}</span></div>`
  ).join('');
  pop.innerHTML = `<button class="gp-close" onclick="hideGlossaire()" aria-label="Fermer">×</button>`
    + `<h4>${g.label}</h4><div class="gp-quoi">${g.quoi}</div>`
    + `<div class="gp-pourquoi"><em>Pourquoi :</em> ${g.pourquoi}</div>${bandes}`;
  pop.style.display = 'block';
  // Positionne près de l'ancre, en restant dans la fenêtre.
  const r = anchor.getBoundingClientRect();
  const pw = Math.min(340, window.innerWidth - 24);
  let left = r.left;
  if (left + pw > window.innerWidth - 12) left = window.innerWidth - pw - 12;
  pop.style.left = Math.max(12, left) + 'px';
  pop.style.top = (r.bottom + 6) + 'px';
}
function hideGlossaire() { document.getElementById('glossaire-pop').style.display = 'none'; }
