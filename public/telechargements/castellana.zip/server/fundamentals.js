// Fondamentaux de screening (feature 322) — Float, PEG, Beta 5Y, prix,
// volume du jour, VWAP intraday. Toutes ces données viennent de Yahoo
// Finance direct (yahoo-finance2), comme indicators.js — indépendant du
// sidecar tradingview-mcp et de son scanner rate-limité (coin_analysis).
//
// Ce sont des filtres SUPPLÉMENTAIRES, pas des colonnes du score composite :
// le score reste sur les 4 colonnes du design doc (RSI/Force/Golden
// Cross/OBV, voir scoreRow() dans index.js). Ici on fournit la donnée brute
// + des drapeaux pass/fail par critère, et le frontend décide de filtrer ou
// non l'univers dessus.

import YahooFinance from 'yahoo-finance2';
import { withRetry, mapWithConcurrency } from './fetch-retry.js';
import { cached, TTL } from './cache.js';

const yahooFinance = new YahooFinance({ suppressNotices: ['yahooSurvey'] });

// VWAP intraday du jour (typical price pondéré par le volume sur les barres
// 5 min de la séance). Signal du design doc : « VWAP below price » = prix
// au-dessus du VWAP → biais acheteur. Retourne null hors séance / si Yahoo
// ne renvoie pas d'intraday (jour férié, titre peu liquide).
async function computeIntradayVWAP(symbol) {
  const now = new Date();
  const start = new Date(now.getTime() - 24 * 3600 * 1000);
  const chart = await withRetry(`VWAP intraday ${symbol}`, () =>
    yahooFinance.chart(symbol, { period1: start, period2: now, interval: '5m' }));
  const bars = chart.quotes.filter((q) => q.close != null && q.volume != null && q.high != null && q.low != null);
  if (bars.length === 0) return null;
  let pv = 0;
  let vv = 0;
  for (const b of bars) {
    const typical = (b.high + b.low + b.close) / 3;
    pv += typical * b.volume;
    vv += b.volume;
  }
  return vv > 0 ? pv / vv : null;
}

// Un titre : fondamentaux + VWAP. Deux appels Yahoo (quoteSummary + chart
// intraday) ; le VWAP est optionnel (withVwap=false pour un screening plus
// rapide). Lève si quoteSummary échoue ; le VWAP échoue en silence (null).
export async function getFundamentals(symbol, { withVwap = true } = {}) {
  // TTL court (15 min), PAS 24 h : `quoteSummary` mêlange dans un seul objet
  // des champs trimestriels (bêta, flottant, secteur, industrie) et des
  // champs intrajournaliers (prix, volume) — c'est le plus rapide des deux
  // qui doit cadencer le cache. Les séparer coûterait un appel réseau de
  // plus par titre pour un gain nul. Voir server/cache.js.
  const qs = await cached(`fundamentals:${symbol}`, TTL.FUNDAMENTALS, () =>
    withRetry(`fondamentaux ${symbol}`, () => yahooFinance.quoteSummary(symbol, {
      modules: ['price', 'summaryDetail', 'defaultKeyStatistics', 'summaryProfile'],
    })));
  const price = qs.price?.regularMarketPrice ?? null;
  let vwap = null;
  if (withVwap) {
    try {
      vwap = await computeIntradayVWAP(symbol);
    } catch {
      vwap = null;
    }
  }
  return {
    price,
    volume: qs.price?.regularMarketVolume ?? null,
    floatShares: qs.defaultKeyStatistics?.floatShares ?? null,
    pegRatio: qs.defaultKeyStatistics?.pegRatio ?? null,
    beta: qs.summaryDetail?.beta ?? null,
    // P/E ratio (trailing) et industrie (GICS sub-industry, summaryProfile) —
    // demandés par JP pour le screening. Le P/E MOYEN de l'industrie n'est
    // PAS fourni ici : voir index.js, calculé après coup sur l'ensemble du
    // batch (approximation par pairs de watchlist, pas un vrai agrégat
    // sectoriel externe).
    peRatio: qs.summaryDetail?.trailingPE ?? null,
    industry: qs.summaryProfile?.industry ?? null,
    // Secteur GICS large (Technology, Healthcare, Energy…) — distinct de
    // `industry` (plus fin, ex. "Semiconductors"). Utilisé par
    // server/sectors.js pour agréger le PEG moyen par secteur (30/8/2026).
    sector: qs.summaryProfile?.sector ?? null,
    vwap,
    // Drapeau pratique pour le frontend/scoring : prix au-dessus du VWAP.
    aboveVwap: price != null && vwap != null ? price > vwap : null,
  };
}

// Batch pour le screening — parallélisme BORNÉ depuis le 7/9/2026 (c'était
// une boucle séquentielle espacée de 300 ms par titre, même prudence héritée
// du rate-limit TradingView que dans indicators.js). Un titre en échec
// ressort avec `error` rempli et tous les champs à null, sans interrompre le
// reste.
export async function getFundamentalsBatch(tickers, { withVwap = true, concurrency = 6 } = {}) {
  return mapWithConcurrency(tickers, async (ticker) => {
    try {
      const data = await getFundamentals(ticker, { withVwap });
      return { ticker, ...data, error: null };
    } catch (err) {
      return {
        ticker,
        price: null,
        volume: null,
        floatShares: null,
        pegRatio: null,
        beta: null,
        peRatio: null,
        industry: null,
        sector: null,
        vwap: null,
        aboveVwap: null,
        error: err.message,
      };
    }
  }, { limit: concurrency });
}
