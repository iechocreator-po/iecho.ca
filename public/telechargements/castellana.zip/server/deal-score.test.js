// Tests du détecteur de « meilleurs deals » (js/options-analytics.js,
// 22/9/2026) : optDealLiquidity/optDealValuation/optDealReturnOrLeverage/
// optDealVerdict/optScoreDeal.
import test from 'node:test';
import assert from 'node:assert/strict';
import { optDealLiquidity, optDealValuation, optDealReturnOrLeverage, optDealVerdict, optScoreDeal } from './options-analytics.js';

test('liquidité : null sans ask exploitable — jamais un score sur du vide', () => {
  assert.equal(optDealLiquidity(null, null, 100, 50), null);
  assert.equal(optDealLiquidity(1, 0, 100, 50), null);
});

test('liquidité : spread serré + OI/volume élevés → score maximal', () => {
  const r = optDealLiquidity(2, 2.1, 1000, 500);
  assert.equal(r.score, 3);
  assert.ok(r.spreadPct < 10);
});

test('liquidité : bid absent (pas de marché acheteur réel) pénalise le spread', () => {
  const r = optDealLiquidity(null, 2, 1000, 500);
  assert.equal(r.spreadPct, null);
  assert.equal(r.score, 1); // -1 (spread) + 1 (OI) + 1 (volume)
});

test('liquidité : OI/volume absents sont neutres (0), pas pénalisants', () => {
  const r = optDealLiquidity(2, 2.1, null, null);
  assert.equal(r.score, 1); // seul le spread compte
});

test('valorisation : vendeur et acheteur veulent l\'inverse sur l\'edge IV', () => {
  // IV nettement plus riche que l'historique (+10 pts) : bon pour vendre, mauvais pour acheter.
  assert.equal(optDealValuation('vente', 0.35, 0.25).score, 1);
  assert.equal(optDealValuation('achat', 0.35, 0.25).score, -1);
  // IV nettement moins chère que l'historique (-10 pts) : l'inverse.
  assert.equal(optDealValuation('vente', 0.15, 0.25).score, -1);
  assert.equal(optDealValuation('achat', 0.15, 0.25).score, 1);
});

test('valorisation : null si IV ou volatilité historique manque', () => {
  assert.equal(optDealValuation('vente', null, 0.25), null);
  assert.equal(optDealValuation('vente', 0.3, null), null);
});

test('rendement (vente) : bandes du rendement annualisé calculé sur la valeur TEMPS (hors la monnaie, extrinsèque = bid)', () => {
  // Put hors la monnaie (strike 100 < prix 120) : bid = 3, entièrement extrinsèque.
  const r = optDealReturnOrLeverage('vente', { type: 'put', bid: 3, strike: 100 }, { dte: 30, price: 120 });
  assert.ok(r.metric > 25);
  assert.equal(r.score, 1);
});

test('rendement (vente) : un ITM profond n\'est PAS noté sur son bid brut — bug réel trouvé sur AMD (22/9/2026)', () => {
  // Call profondément ITM : prix 615, strike 400, bid 222 (intrinsèque ≈ 215, extrinsèque ≈ 7).
  const itm = optDealReturnOrLeverage('vente', { type: 'call', bid: 222, strike: 400 }, { dte: 30, price: 615 });
  // Sur le bid brut, le rendement dépasserait 20 000 % (faux) ; sur l'extrinsèque, il reste raisonnable.
  assert.ok(itm.metric < 200, `rendement ${itm.metric} devrait être calculé sur la valeur temps seule, pas le bid brut`);
});

test('levier (achat) : |delta|/ask, jamais calculé sans ask réel', () => {
  const r = optDealReturnOrLeverage('achat', { ask: 2, delta: -0.3 }, { dte: 30, price: 100 });
  assert.equal(r.metric, 0.15);
  assert.equal(optDealReturnOrLeverage('achat', { ask: 0, delta: -0.3 }, { dte: 30, price: 100 }), null);
  assert.equal(optDealReturnOrLeverage('achat', { ask: 2, delta: null }, { dte: 30, price: 100 }), null);
});

test('verdict : bandes du total, jamais un score opaque sans label', () => {
  assert.equal(optDealVerdict(4), 'excellent');
  assert.equal(optDealVerdict(1), 'bon');
  assert.equal(optDealVerdict(-1), 'passable');
  assert.equal(optDealVerdict(-3), 'écarter');
});

test('optScoreDeal : exclut (null) un contrat sans marché exploitable', () => {
  assert.equal(optScoreDeal('vente', { type: 'put', bid: null, ask: null, strike: 100 }, { dte: 30, price: 100, historicalVolatility: 0.3 }), null);
});

test('optScoreDeal : agrège les 3 sous-scores en un total transparent', () => {
  const r = optScoreDeal('vente', { type: 'put', bid: 2, ask: 2.1, openInterest: 600, volume: 200, iv: 0.35, strike: 100 }, { dte: 30, price: 105, historicalVolatility: 0.25 });
  assert.equal(r.total, r.liquidity.score + r.valorisation.score + r.rendement.score);
  assert.equal(r.verdict, optDealVerdict(r.total));
});
