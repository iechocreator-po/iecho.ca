import { db } from './db.js';

// Colonnes éditables du journal — schéma complet dans db.js, section 7 du
// design doc. id/date_creation sont gérés par SQLite, jamais dans le body.
// Exporté pour l'export CSV (server/index.js, GET /api/trades.csv).
export const COLUMNS = [
  'date_entree', 'date_sortie', 'compte', 'ticker', 'prix_entree', 'prix_sortie',
  'taille_position', 'stop_initial', 'vix_a_entree', 'rsi_a_entree', 'obv_a_entree',
  'correlation_flag', 'checklist_complete', 'r_realise', 'resultat',
];

const REQUIRED_ON_CREATE = ['date_entree', 'compte', 'ticker', 'prix_entree', 'taille_position', 'stop_initial'];

const COMPTES = ['RRSP', 'margin', 'corporatif'];
const OBV_VALUES = ['accumulation', 'neutre', 'distribution'];
const RESULTATS = ['gagnant', 'perdant'];

// Validation manuelle avant insert/update plutôt que de laisser remonter les
// erreurs CHECK brutes de SQLite — messages clairs pour l'appelant de l'API.
export function validateTrade(data, { partial = false } = {}) {
  const errors = [];
  if (!partial) {
    for (const field of REQUIRED_ON_CREATE) {
      if (data[field] === undefined || data[field] === null || data[field] === '') {
        errors.push(`${field} est requis`);
      }
    }
  }
  if (data.compte != null && !COMPTES.includes(data.compte)) {
    errors.push(`compte doit être l'un de : ${COMPTES.join(', ')}`);
  }
  if (data.obv_a_entree != null && !OBV_VALUES.includes(data.obv_a_entree)) {
    errors.push(`obv_a_entree doit être l'un de : ${OBV_VALUES.join(', ')}`);
  }
  if (data.resultat != null && !RESULTATS.includes(data.resultat)) {
    errors.push(`resultat doit être l'un de : ${RESULTATS.join(', ')}`);
  }
  if (data.correlation_flag !== undefined && ![0, 1].includes(Number(data.correlation_flag))) {
    errors.push('correlation_flag doit être 0 ou 1');
  }
  if (data.checklist_complete !== undefined && ![0, 1].includes(Number(data.checklist_complete))) {
    errors.push('checklist_complete doit être 0 ou 1');
  }
  return errors;
}

// Ticker normalisé en majuscules à l'écriture — cohérent avec le filtre de
// listTrades() et le reste de l'app (ex. GET /api/market-data/:ticker).
function normalize(data) {
  return data.ticker !== undefined ? { ...data, ticker: data.ticker.toUpperCase() } : data;
}

export function createTrade(rawData) {
  const data = normalize(rawData);
  const cols = COLUMNS.filter((c) => data[c] !== undefined);
  const stmt = db.prepare(`INSERT INTO trades (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`);
  const info = stmt.run(...cols.map((c) => data[c]));
  return getTrade(info.lastInsertRowid);
}

export function listTrades({ compte, ticker, open } = {}) {
  let sql = 'SELECT * FROM trades WHERE 1=1';
  const params = [];
  if (compte) { sql += ' AND compte = ?'; params.push(compte); }
  if (ticker) { sql += ' AND ticker = ?'; params.push(ticker.toUpperCase()); }
  if (open === true) sql += ' AND date_sortie IS NULL';
  if (open === false) sql += ' AND date_sortie IS NOT NULL';
  sql += ' ORDER BY date_entree DESC, id DESC';
  return db.prepare(sql).all(...params);
}

export function getTrade(id) {
  return db.prepare('SELECT * FROM trades WHERE id = ?').get(id);
}

export function updateTrade(id, rawData) {
  const data = normalize(rawData);
  const cols = COLUMNS.filter((c) => data[c] !== undefined);
  if (cols.length > 0) {
    const stmt = db.prepare(`UPDATE trades SET ${cols.map((c) => `${c} = ?`).join(', ')} WHERE id = ?`);
    stmt.run(...cols.map((c) => data[c]), id);
  }
  return getTrade(id);
}

export function deleteTrade(id) {
  return db.prepare('DELETE FROM trades WHERE id = ?').run(id).changes > 0;
}
