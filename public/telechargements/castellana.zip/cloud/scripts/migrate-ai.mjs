#!/usr/bin/env node
// Migration idempotente (10/10/2026) — analyses IA par compte : table ai_analyses.
// CREATE TABLE IF NOT EXISTS : rejouable, aucune donnée existante touchée. `schema.sql` reste la
// source de vérité pour une installation neuve.
//
// ⚠️ À lancer en --remote AVANT `wrangler deploy` (le code déployé lit cette table), puis vérifier
// avec sqlite_master — pas sur le seul message de fin.
//
// Usage :
//   node scripts/migrate-ai.mjs             (D1 local)
//   node scripts/migrate-ai.mjs --remote    (vrai D1)

import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const flag = process.argv.includes('--remote') ? '--remote' : '--local';

function run(sql) {
  const r = spawnSync('npx', ['wrangler', 'd1', 'execute', 'castellana-db', flag, '--command', sql], {
    cwd: ROOT, encoding: 'utf8', stdio: 'inherit',
  });
  if (r.status !== 0) process.exit(r.status || 1);
}

console.log(`Migration IA (${flag})…`);
run(`CREATE TABLE IF NOT EXISTS ai_analyses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  ticker TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  month TEXT NOT NULL,
  model TEXT NOT NULL,
  input_tokens INTEGER,
  output_tokens INTEGER,
  cost_usd REAL,
  result_json TEXT NOT NULL,
  sources_json TEXT NOT NULL
)`);
run('CREATE INDEX IF NOT EXISTS idx_ai_analyses_user ON ai_analyses (user_id, ticker, id)');
run("SELECT name FROM sqlite_master WHERE name IN ('ai_analyses', 'idx_ai_analyses_user')");
console.log('Terminé : vérifie que les deux noms ci-dessus sont listés.');
