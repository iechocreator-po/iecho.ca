// Routes diverses — portage Cloudflare de server/index.js.
//
// /api/health et /api/status restent par-utilisateur (comptent LES trades
// de l'utilisateur connecté) plutôt qu'un total global, cohérent avec le
// reste de l'app en mode multi-utilisateur.
//
// /api/webhook/tradingview est la SEULE route hors session — TradingView ne
// peut pas se connecter. Un secret partagé (env.WEBHOOK_SECRET) remplace la
// protection qu'offrait, côté local, le simple fait que l'app ne soit pas
// exposée sur internet.

import { checkYahooConnection } from '../lib/indicators.js';
import { createAlert, listAlerts } from '../db/alerts.js';

export function registerMiscRoutes(app) {
  app.get('/api/health', async (c) => {
    const { count } = await c.env.DB.prepare('SELECT COUNT(*) AS count FROM trades WHERE user_id = ?')
      .bind(c.get('userId')).first();
    return c.json({ status: 'ok', trades: count });
  });

  app.get('/api/status', async (c) => {
    let dbOk = true;
    let dbDetail = null;
    try {
      await c.env.DB.prepare('SELECT 1').first();
    } catch (err) {
      dbOk = false;
      dbDetail = err.message;
    }
    const homemade = await checkYahooConnection();
    return c.json({
      backend: true,
      db: dbOk,
      dbDetail,
      // Le sidecar n'existe plus en cloud — jamais montré comme "en panne",
      // toujours comme un composant qui n'a plus lieu d'être ici.
      tradingviewMcp: false,
      tradingviewMcpDisabled: true,
      tradingviewMcpDetail: null,
      homemade: homemade.ok,
      homemadeDetail: homemade.detail,
      checkedAt: new Date().toISOString(),
    });
  });

  // Journal des alertes TradingView (feature exploratoire, aucune exécution
  // déclenchée) — table GLOBALE, voir db/alerts.js.
  app.post('/api/webhook/tradingview', async (c) => {
    const secret = c.req.query('secret') ?? c.req.header('X-Webhook-Secret');
    if (!c.env.WEBHOOK_SECRET || secret !== c.env.WEBHOOK_SECRET) {
      return c.json({ error: 'secret invalide' }, 401);
    }
    const rawBody = await c.req.text();
    let ticker = null;
    let message = null;
    let payload = rawBody;
    try {
      const parsed = JSON.parse(rawBody);
      ticker = parsed.ticker ?? parsed.symbol ?? null;
      message = parsed.message ?? parsed.text ?? null;
      payload = JSON.stringify(parsed);
    } catch {
      message = rawBody;
      payload = rawBody;
    }
    const id = await createAlert(c.env.DB, ticker ? String(ticker).toUpperCase() : null, message, payload);
    return c.json({ id, ticker, message }, 201);
  });

  app.get('/api/alerts', async (c) => {
    return c.json({ alerts: await listAlerts(c.env.DB) });
  });
}
