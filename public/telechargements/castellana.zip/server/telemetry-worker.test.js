// Worker de télémétrie (audit périphérie, 22/10/2026) : le jeton d'ingestion est PUBLIC, donc ce qu'un tiers peut écrire est borné,
// et les routes de consultation / suppression exigent une authentification vérifiée à temps constant. Le Worker n'avait aucun test.
import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import worker from '../telemetry-worker/src/index.js';

function fakeDb({ recents = 0 } = {}) {
  const writes = [];
  const prepare = (sql) => {
    const mk = (args) => ({
      async first() { return /COUNT\(\*\) AS n FROM telemetry_events WHERE ip/.test(sql) ? { n: recents } : null; },
      async all() { return { results: [] }; },
      async run() { writes.push({ sql, args }); return { meta: { changes: 0 } }; },
      sql, args,
    });
    return { ...mk([]), bind: (...args) => mk(args) };
  };
  return { prepare, writes, async batch(stmts) { for (const s of stmts) writes.push({ sql: s.sql, args: s.args }); return []; } };
}
const env = (db, extra = {}) => ({ DB: db, TELEMETRY_TOKEN: 'jeton-public', DASHBOARD_USER: 'jp', DASHBOARD_PASSWORD: 'secret-long', ...extra });
const post = (path, body, headers = {}) => new Request(`https://w.example${path}`, { method: 'POST', body: typeof body === 'string' ? body : JSON.stringify(body), headers: { 'Content-Type': 'application/json', ...headers } });
const ev = (over = {}) => ({ who: 'jp', event_type: 'app_loaded', payload: {}, ...over });
const basic = (u, p) => ({ Authorization: 'Basic ' + btoa(`${u}:${p}`) });

test('ingestion : un événement valide est écrit, le jeton est obligatoire', async () => {
  const db = fakeDb();
  const sans = await worker.fetch(post('/events', ev()), env(db));
  assert.equal(sans.status, 401);
  const ok = await worker.fetch(post('/events', ev(), { 'X-Telemetry-Token': 'jeton-public' }), env(db));
  assert.equal(ok.status, 200);
  assert.ok(db.writes.some((w) => /INSERT INTO telemetry_events/.test(w.sql)));
});

test('ingestion : corps trop gros, "who" fantaisiste, "ua" démesuré et trop d\'événements par minute sont refusés', async () => {
  const h = { 'X-Telemetry-Token': 'jeton-public' };
  const gros = await worker.fetch(post('/events', { ...ev(), payload: { x: 'a'.repeat(20000) } }, h), env(fakeDb()));
  assert.equal(gros.status, 413, 'corps > 16 Ko');
  for (const who of ['x'.repeat(41), '<img src=x>', 'a"b', '']) {
    assert.equal((await worker.fetch(post('/events', ev({ who }), h), env(fakeDb()))).status, 400, `who=${JSON.stringify(who)}`);
  }
  assert.equal((await worker.fetch(post('/events', ev({ ua: 'u'.repeat(300) }), h), env(fakeDb()))).status, 400, 'ua > 256');
  assert.equal((await worker.fetch(post('/events', ev({ ua: { objet: 1 } }), h), env(fakeDb()))).status, 400, 'ua objet');
  assert.equal((await worker.fetch(post('/events', ev(), h), env(fakeDb({ recents: 300 })))).status, 429, 'débit par IP');
});

test('ingestion : une charge utile démesurée est tronquée, pas stockée', async () => {
  const db = fakeDb();
  const r = await worker.fetch(post('/events', ev({ payload: { x: 'a'.repeat(6000) } }), { 'X-Telemetry-Token': 'jeton-public' }), env(db));
  assert.equal(r.status, 200);
  const insert = db.writes.find((w) => /INSERT INTO telemetry_events/.test(w.sql));
  assert.ok(insert.args[4].length < 200, 'la charge utile stockée est un résumé, pas 6 000 caractères');
  assert.match(insert.args[4], /tronque/);
});

test('consultation et suppression : Basic Auth obligatoire (bons identifiants seulement)', async () => {
  const db = fakeDb();
  for (const [methode, chemin] of [['GET', '/summary'], ['GET', '/dashboard'], ['GET', '/events.csv']]) {
    assert.equal((await worker.fetch(new Request(`https://w.example${chemin}`, { method: methode }), env(db))).status, 401, `${chemin} sans identifiants`);
    assert.equal((await worker.fetch(new Request(`https://w.example${chemin}`, { method: methode, headers: basic('jp', 'mauvais') }), env(db))).status, 401, `${chemin} mauvais mot de passe`);
  }
  assert.equal((await worker.fetch(post('/delete', { scope: 'all' }), env(db))).status, 401);
  assert.equal((await worker.fetch(new Request('https://w.example/summary', { headers: basic('jp', 'secret-long') }), env(db))).status, 200);
  assert.equal((await worker.fetch(new Request('https://w.example/summary', { headers: basic('jp', 'secret-long') }), { DB: db })).status, 401, 'sans secrets configurés : fermé');
});

test('/delete : JSON obligatoire, origine étrangère refusée, suppression totale sans confirmation refusée', async () => {
  const db = fakeDb();
  const auth = basic('jp', 'secret-long');
  const texte = await worker.fetch(new Request('https://w.example/delete', { method: 'POST', body: '{"scope":"all","confirm":true}', headers: { ...auth, 'Content-Type': 'text/plain' } }), env(db));
  assert.equal(texte.status, 415, 'une requête simple (text/plain) venue d\'une autre page');
  const etranger = await worker.fetch(post('/delete', { scope: 'all', confirm: true }, { ...auth, Origin: 'https://evil.example' }), env(db));
  assert.equal(etranger.status, 403);
  const sansConfirm = await worker.fetch(post('/delete', { scope: 'all' }, auth), env(db));
  assert.equal(sansConfirm.status, 400, 'scope all sans confirm:true');
  const memeOrigine = await worker.fetch(post('/delete', { scope: 'ids', ids: [1] }, { ...auth, Origin: 'https://w.example' }), env(db));
  assert.notEqual(memeOrigine.status, 403, 'le tableau de bord (même origine) peut supprimer');
});

test('CSV : une cellule choisie par un tiers ne devient pas une formule', async () => {
  const db = { prepare: () => ({ bind: () => ({ all: async () => ({ results: [] }) }), all: async () => ({ results: [{ id: 1, created_at: 'x', who: '=HYPERLINK("http://evil","clic")', ip: '1.1.1.1', event_type: 'app_loaded', payload_json: '{}', user_agent: '+cmd|calc' }] }) }) };
  const r = await worker.fetch(new Request('https://w.example/events.csv', { headers: basic('jp', 'secret-long') }), env(db));
  const txt = await r.text();
  assert.ok(!/(^|,)=HYPERLINK/.test(txt) && !/(^|,)\+cmd/.test(txt), 'aucune cellule ne commence par = ou +');
  assert.match(txt, /'=HYPERLINK/);
});

test('l\'archive distribuée ne contient que des fichiers suivis par git, sans secret ni donnée', () => {
  const suivis = execFileSync('git', ['-c', 'core.quotepath=off', 'ls-files'], { cwd: new URL('..', import.meta.url), encoding: 'utf8' }).split('\n').filter(Boolean);
  const interdits = /(^|\/)\.env($|\.)|\.sqlite|\.db($|-)|\.xlsx$|\.dev\.vars|(^|\/)worktrees\/|(^|\/)node_modules\/|settings\.local|\.pem$|\.key$/;
  assert.deepEqual(suivis.filter((f) => interdits.test(f)), [], 'un secret ou une donnée suivi par git partirait dans le paquet');
});
