// Logique pure des alertes de positions (#379).
import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluatePositionObservation as ev, daysUntil, capturePercent, DTE_SEUIL_JOURS } from './position-alerts-logic.js';

const leg = { ticker: 'AMD', type: 'put', strike: 150, echeance: '2026-10-09' };

test('échéance : notifie en passant à ≤ 7 jours, pas avant, pas en continu, pas à la première observation', () => {
  assert.equal(ev('echeance', { ...leg, dte: 7 }, 'out').notify, true);
  assert.equal(ev('echeance', { ...leg, dte: 8 }, 'out').notify, false);
  assert.equal(ev('echeance', { ...leg, dte: 5 }, 'in').notify, false);   // déjà signalé
  assert.equal(ev('echeance', { ...leg, dte: 5 }, null).notify, false);   // première observation
  assert.equal(ev('echeance', { ...leg, dte: -1 }, 'out').state, 'out');  // échue : plus « proche »
  assert.equal(ev('echeance', { ...leg, dte: null }, 'out').state, null); // donnée manquante
  assert.match(ev('echeance', { ...leg, dte: 3 }, 'out').message, /3 jours/);
});

test('profit : déclenché quand la part captée atteint le seuil', () => {
  const o = { ...leg, capturePct: 55, seuilPct: 50, rachat: 0.9, primeRecue: 2 };
  assert.equal(ev('profit', o, 'out').notify, true);
  assert.equal(ev('profit', { ...o, capturePct: 40 }, 'out').notify, false);
  assert.equal(ev('profit', { ...o, capturePct: 60 }, 'in').notify, false);
  assert.equal(ev('profit', { ...o, capturePct: null }, 'out').state, null);
});

test('stop : ok → touché seulement ; cours ou stop absent = rien à mémoriser', () => {
  const o = { ticker: 'NVDA', price: 118, stop: 120 };
  assert.equal(ev('stop', o, 'ok').notify, true);
  assert.equal(ev('stop', { ...o, price: 120 }, 'ok').notify, true);      // touché pile
  assert.equal(ev('stop', { ...o, price: 125 }, 'ok').notify, false);
  assert.equal(ev('stop', o, 'hit').notify, false);                        // déjà signalé
  assert.equal(ev('stop', { ...o, price: null }, 'ok').state, null);
  assert.equal(ev('stop', { ...o, stop: 0 }, 'ok').state, null);
});

test('jours restants et part de prime captée', () => {
  assert.equal(daysUntil('2026-10-09', new Date('2026-10-02T00:00:00Z')), 7);
  assert.equal(daysUntil('2026-10-09', new Date('2026-10-02T15:00:00Z')), 7); // arrondi vers le haut
  assert.equal(daysUntil('pas-une-date'), null);
  assert.equal(capturePercent(2, 0.5), 75);
  assert.equal(capturePercent(0, 0.5), null);
  assert.equal(capturePercent(2, null), null);
  assert.equal(DTE_SEUIL_JOURS, 7);
});
