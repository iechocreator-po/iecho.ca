// Stockage de la connexion TradingView (voir schema.sql). Les jetons sont liés
// à la SESSION castellana, jamais à `users` : déconnexion ou expiration de la
// session = jetons supprimés (ON DELETE CASCADE + suppression explicite au
// logout, au cas où les clés étrangères ne s'appliqueraient pas).

export async function getClientId(db, redirectUri) {
  const r = await db.prepare('SELECT client_id FROM tv_oauth_clients WHERE redirect_uri = ?').bind(redirectUri).first();
  return r ? r.client_id : null;
}

export async function saveClientId(db, redirectUri, clientId) {
  await db.prepare(
    `INSERT INTO tv_oauth_clients (redirect_uri, client_id) VALUES (?, ?)
     ON CONFLICT(redirect_uri) DO UPDATE SET client_id = excluded.client_id`,
  ).bind(redirectUri, clientId).run();
}

// Démarre (ou redémarre) une autorisation : remplace toute connexion précédente.
export async function beginAuthorization(db, sessionToken, { clientId, redirectUri, state, verifier }) {
  await db.prepare(
    `INSERT INTO tv_oauth (session_token, client_id, redirect_uri, state, code_verifier)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(session_token) DO UPDATE SET client_id = excluded.client_id, redirect_uri = excluded.redirect_uri,
       state = excluded.state, code_verifier = excluded.code_verifier,
       access_token = NULL, refresh_token = NULL, expires_at = NULL, connected_at = NULL`,
  ).bind(sessionToken, clientId, redirectUri, state, verifier).run();
}

export async function getConnection(db, sessionToken) {
  return db.prepare(
    `SELECT client_id AS clientId, redirect_uri AS redirectUri, state, code_verifier AS verifier,
            access_token AS accessToken, refresh_token AS refreshToken, expires_at AS expiresAt, connected_at AS connectedAt
     FROM tv_oauth WHERE session_token = ?`,
  ).bind(sessionToken).first();
}

// Fin de l'autorisation : jetons enregistrés, state/PKCE effacés (usage unique).
export async function completeAuthorization(db, sessionToken, tokens) {
  await db.prepare(
    `UPDATE tv_oauth SET access_token = ?, refresh_token = ?, expires_at = ?, state = NULL, code_verifier = NULL,
       connected_at = datetime('now') WHERE session_token = ?`,
  ).bind(tokens.accessToken, tokens.refreshToken, tokens.expiresAt, sessionToken).run();
}

export async function updateTokens(db, sessionToken, tokens) {
  await db.prepare('UPDATE tv_oauth SET access_token = ?, refresh_token = COALESCE(?, refresh_token), expires_at = ? WHERE session_token = ?')
    .bind(tokens.accessToken, tokens.refreshToken, tokens.expiresAt, sessionToken).run();
}

export async function deleteConnection(db, sessionToken) {
  await db.prepare('DELETE FROM tv_oauth WHERE session_token = ?').bind(sessionToken).run();
}
