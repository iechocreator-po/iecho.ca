#!/usr/bin/env node
// Migration idempotente (19/9/2026) — paramètres des stratégies d'options.
// La base réelle est déjà déployée : `schema.sql` est la source de vérité
// pour une installation neuve, ce script amène une base EXISTANTE au même
// état. Ici, seulement une nouvelle table (CREATE TABLE IF NOT EXISTS) :
// rejouable sans erreur, aucune donnée existante touchée.
//
// ⚠️ À lancer en --remote AVANT `wrangler deploy` : le code déployé lit cette
// table, et sans elle chaque appel à /api/labo/params répond 500 (même piège
// que le magic link du 19/9/2026, où la migration distante avait été oubliée).
//
// Usage :
//   node scripts/migrate-labo-params.mjs             (D1 local)
//   node scripts/migrate-labo-params.mjs --remote    (vrai D1)

import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const flag = process.argv.includes('--remote') ? '--remote' : '--local';

function run(sql) {
  const r = spawnSync('npx', ['wrangler', 'd1', 'execute', 'castellana-db', flag, '--command', sql], {
    cwd: ROOT, encoding: 'utf8',
  });
  if (r.status !== 0) {
    console.error(r.stdout, r.stderr);
    process.exit(r.status || 1);
  }
}

console.log(`Migration strategy_params (${flag})…`);
run(`CREATE TABLE IF NOT EXISTS strategy_params (
  user_id INTEGER NOT NULL REFERENCES users(id),
  strategy_id TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'builtin',
  params_json TEXT NOT NULL,
  definition_json TEXT,
  schema_version INTEGER NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, strategy_id)
)`);
console.log('OK — table strategy_params présente.');
