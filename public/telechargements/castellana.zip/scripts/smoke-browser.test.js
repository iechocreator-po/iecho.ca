// Lancé par `npm run test:smoke` (PAS par `npm test` : il exige Chrome et prend environ 20 s).
// Deux volets : (1) les vraies pages doivent passer ; (2) l'AUTO-TEST — on injecte les deux pannes réelles de
// l'historique du produit et le test de fumée DOIT les voir. Sans (2), un test vert ne prouverait rien.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { findChrome, smokePage, PAGES } from './smoke-browser.mjs';

const REPO = fileURLToPath(new URL('..', import.meta.url));
const chromePath = findChrome();
const skip = chromePath ? false : 'Chrome introuvable (définir CHROME_PATH) : test ignoré, ce n\'est pas un succès';

for (const p of PAGES) {
  test(`fumée : ${p.label}`, { skip }, async () => {
    const r = await smokePage({ ...p, chromePath });
    assert.deepEqual(r.problems, [], r.problems.join('\n'));
    assert.ok(r.tabs.length >= 5, `trop peu d'onglets trouvés (${r.tabs.length})`);
    if (p.authenticated || p.label.startsWith('local')) {
      assert.ok(r.tabs.filter((t) => t.active).length >= 5, 'moins de 5 onglets cliqués et devenus actifs');
    }
  });
}

test('auto-test : une accolade en trop dans un script d\'onglet est détectée (cas roue-tab.js, 17/10/2026)', { skip }, async () => {
  const src = readFileSync(join(REPO, 'js', 'roue-tab.js'), 'utf8');
  const r = await smokePage({ ...PAGES[0], chromePath, overrides: { 'js/roue-tab.js': src + '\n}\n' } });
  assert.equal(r.ok, false, 'la panne injectée n\'a pas été vue');
  assert.match(r.problems.join('\n'), /SyntaxError/);
});

test('auto-test : un nom global déclaré deux fois est détecté (cas optNum, 13/10/2026)', { skip }, async () => {
  const src = readFileSync(join(REPO, 'js', 'sizing.js'), 'utf8');
  const r = await smokePage({ ...PAGES[0], chromePath, overrides: { 'js/sizing.js': src + '\nconst optNum = 1;\n' } });
  assert.equal(r.ok, false, 'la panne injectée n\'a pas été vue');
  assert.match(r.problems.join('\n'), /already been declared/);
});

test('auto-test : un script introuvable est détecté', { skip }, async () => {
  const html = readFileSync(join(REPO, 'index.html'), 'utf8').replace('<script src="js/sizing.js"></script>', '<script src="js/n-existe-pas.js"></script>');
  assert.ok(html.includes('n-existe-pas'), 'préparation de l\'auto-test : balise <script src="js/sizing.js"> introuvable dans index.html');
  const r = await smokePage({ ...PAGES[0], chromePath, overrides: { 'index.html': html } });
  assert.equal(r.ok, false);
  assert.match(r.problems.join('\n'), /HTTP 404/);
});
