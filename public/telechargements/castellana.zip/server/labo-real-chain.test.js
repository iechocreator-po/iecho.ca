// Option Lab sur la vraie chaîne (#396) — fonctions pures de js/labo-real-chain.js, évaluées comme le navigateur.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const ctx = vm.createContext({});
vm.runInContext(fs.readFileSync(new URL('../js/labo-real-chain.js', import.meta.url), 'utf8')
  + '\nthis.f = { laboQualityFlags, laboPickExpiry, laboPickContract, laboLongLeg, laboSpreadCredit, laboAtmContract, laboRealPlan };', ctx);
const f = ctx.f;

const good = { strike: 90, bid: 1.0, ask: 1.1, openInterest: 500, iv: 0.4, delta: -0.2 };

test('cote saine : aucun drapeau', () => assert.deepEqual([...f.laboQualityFlags(good)], []));

test('cote douteuse : chaque défaut est nommé (cas MTD : IV 329 %, écart énorme, OI nul)', () => {
  assert.ok(f.laboQualityFlags({ ...good, bid: 0 }).includes('pas de bid'));
  assert.ok(f.laboQualityFlags({ ...good, bid: 0.5, ask: 1 }).some((x) => x.startsWith('écart bid-ask')));
  assert.ok(f.laboQualityFlags({ ...good, openInterest: 3 }).includes('open interest faible'));
  assert.ok(f.laboQualityFlags({ ...good, iv: 3.29 }).some((x) => x.startsWith('IV aberrante')));
  assert.ok(f.laboQualityFlags({ ...good, openInterest: null }).includes('open interest faible'));
});

test('échéance : la plus proche de la cible, jamais celle du jour', () => {
  const ex = [{ date: 'a', dte: 0 }, { date: 'b', dte: 7 }, { date: 'c', dte: 30 }, { date: 'd', dte: 38 }];
  assert.equal(f.laboPickExpiry(ex, 35).date, 'd');
  assert.equal(f.laboPickExpiry(ex, 1).date, 'b');
  assert.equal(f.laboPickExpiry([], 30), null);
});

test('contrat : plage de delta en valeur absolue, retenu = premier de bonne qualité, jamais un douteux', () => {
  const list = [
    { strike: 80, bid: 0.3, ask: 0.35, openInterest: 900, iv: 0.4, delta: -0.12 },
    { strike: 85, bid: 0.9, ask: 1.0, openInterest: 900, iv: 0.4, delta: -0.2 },
    { strike: 86, bid: 0, ask: 1.2, openInterest: 900, iv: 0.4, delta: -0.22 },
    { strike: 99, bid: 4, ask: 4.2, openInterest: 900, iv: 0.4, delta: -0.6 },
  ];
  const r = f.laboPickContract(list, 0.15, 0.25);
  assert.equal(r.total, 2);
  assert.equal(r.chosen.strike, 85);
  const douteux = f.laboPickContract([list[2]], 0.15, 0.25);
  assert.equal(douteux.chosen, null);
  assert.equal(douteux.total, 1);
  assert.equal(f.laboPickContract(list, 0.7, 0.8).total, 0);
});

test('jambe de protection : put sous le strike − largeur, call au-dessus ; ask requis', () => {
  const puts = [{ strike: 80, ask: 0.2 }, { strike: 85, ask: 0.4 }, { strike: 88, ask: 0.8 }, { strike: 84, ask: 0 }];
  assert.equal(f.laboLongLeg(puts, 'put', 90, 4).strike, 85);
  const calls = [{ strike: 110, ask: 0.5 }, { strike: 114, ask: 0.3 }, { strike: 120, ask: 0.1 }];
  assert.equal(f.laboLongLeg(calls, 'call', 110, 4).strike, 114);
  assert.equal(f.laboLongLeg(puts, 'put', 90, 50), null);
});

test('crédit réel : bid vendu − ask acheté, % de la largeur, perte max', () => {
  const s = f.laboSpreadCredit({ strike: 90, bid: 1.2 }, { strike: 85, ask: 0.4 });
  assert.equal(s.width, 5);
  assert.ok(Math.abs(s.credit - 0.8) < 1e-9);
  assert.ok(Math.abs(s.creditPct - 0.16) < 1e-9);
  assert.ok(Math.abs(s.maxLoss - 4.2) < 1e-9);
});

test('contrat ATM : strike le plus proche du prix', () => {
  assert.equal(f.laboAtmContract([{ strike: 98, ask: 1 }, { strike: 101, ask: 1 }, { strike: 105, ask: 1 }], 100).strike, 101);
  assert.equal(f.laboAtmContract([], 100), null);
});

test('plan : jambes par stratégie', () => {
  const p = { putDteMin: 30, putDteMax: 45, putDeltaMin: 0.15, putDeltaMax: 0.25, callDteMin: 30, callDteMax: 45, callDeltaMin: 0.15, callDeltaMax: 0.25, leapsDteTypiqueJours: 365, leapsDeltaMin: 0.7, leapsDeltaMax: 0.85 };
  assert.equal(f.laboRealPlan('roue', p).length, 2);
  assert.equal(f.laboRealPlan('credit-spreads', p).every((l) => l.spread), true);
  assert.equal(f.laboRealPlan('pmcc', p)[0].dte, 365);
  assert.equal(f.laboRealPlan('iron-condor', p).length, 0);
});
