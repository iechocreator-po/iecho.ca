// Réglages modifiables par l'utilisateur — portage Cloudflare de
// server/preferences.js, DÉSORMAIS PAR UTILISATEUR (`user_id`) plutôt
// qu'une seule instance partagée : chaque testeur peut avoir ses propres
// périodes SMA/RSI. Mêmes règles de validation, mêmes valeurs par défaut.

export const DEFAULTS = {
  smaFast: 9,
  smaMedium: 21,
  smaSlow: 50,
  rsiPeriod: 14,
};

const MIN_PERIOD = 2;
const MAX_PERIOD = 250;

export async function getPreferences(db, userId) {
  const { results } = await db.prepare('SELECT key, value FROM preferences WHERE user_id = ?').bind(userId).all();
  const stored = Object.fromEntries(results.map((r) => [r.key, r.value]));
  const out = { ...DEFAULTS };
  for (const key of Object.keys(DEFAULTS)) {
    const n = Number.parseInt(stored[key], 10);
    if (Number.isInteger(n) && n >= MIN_PERIOD && n <= MAX_PERIOD) out[key] = n;
  }
  return out;
}

// Valide et enregistre. Retourne les préférences effectives ; lève avec un
// message lisible si une valeur est refusée.
export async function setPreferences(db, userId, patch) {
  const errors = [];
  const accepted = {};
  const labels = {
    smaFast: 'Moyenne mobile simple rapide',
    smaMedium: 'Moyenne mobile simple moyenne',
    smaSlow: 'Moyenne mobile simple lente',
    rsiPeriod: 'RSI',
  };
  for (const [key, raw] of Object.entries(patch || {})) {
    if (!(key in DEFAULTS)) continue;
    const n = Number.parseInt(raw, 10);
    if (!Number.isInteger(n) || n < MIN_PERIOD || n > MAX_PERIOD) {
      errors.push(`${labels[key]} : « ${raw} » n'est pas un entier entre ${MIN_PERIOD} et ${MAX_PERIOD}.`);
      continue;
    }
    accepted[key] = n;
  }

  const current = await getPreferences(db, userId);
  const merged = { ...current, ...accepted };
  if (!(merged.smaFast < merged.smaMedium && merged.smaMedium < merged.smaSlow)) {
    errors.push(
      `Les trois moyennes doivent aller de la plus courte à la plus longue : `
      + `rapide (${merged.smaFast}) < moyenne (${merged.smaMedium}) < lente (${merged.smaSlow}).`,
    );
  }

  if (errors.length) {
    const err = new Error(errors.join(' '));
    err.code = 'INVALID_PREFERENCES';
    throw err;
  }

  const entries = Object.entries(accepted);
  if (entries.length) {
    await db.batch(entries.map(([key, value]) =>
      db.prepare('INSERT INTO preferences (user_id, key, value) VALUES (?, ?, ?) ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value')
        .bind(userId, key, String(value))));
  }
  return getPreferences(db, userId);
}

// Réinitialise aux valeurs par défaut — SUPPRIME les lignes plutôt que d'y
// réécrire les défauts (voir server/preferences.js pour le raisonnement).
export async function resetPreferences(db, userId) {
  // Ne vide QUE les périodes : la pondération du score fondamental (`fw_*`) a son propre bouton.
  await db.prepare("DELETE FROM preferences WHERE user_id = ? AND key NOT LIKE 'fw\\_%' ESCAPE '\\'").bind(userId).run();
  return getPreferences(db, userId);
}

export function indicatorOptions(prefs) {
  return {
    periods: { fast: prefs.smaFast, medium: prefs.smaMedium, slow: prefs.smaSlow },
    rsiPeriod: prefs.rsiPeriod,
  };
}

// ---- Pondération du score fondamental (2/10/2026) — voir server/preferences.js ----
export const WEIGHT_DEFAULTS = { growth: 20, consistency: 20, conversion: 20, dilution: 20, valuation: 20, balance: 0 }; // balance (solidité du bilan, 11/10/2026) à 0 % : l'activer par défaut changerait tous les verdicts
const WEIGHT_LABELS = {
  growth: 'Croissance du FCF par action',
  consistency: 'Régularité',
  conversion: 'Conversion en cash',
  dilution: 'Dilution',
  valuation: 'Valorisation (P/S)',
  balance: 'Solidité du bilan',
};

export async function getFundamentalWeights(db, userId) {
  const { results } = await db.prepare("SELECT key, value FROM preferences WHERE user_id = ? AND key LIKE 'fw\\_%' ESCAPE '\\'").bind(userId).all();
  const stored = Object.fromEntries(results.map((r) => [r.key.slice(3), r.value]));
  const out = { ...WEIGHT_DEFAULTS };
  for (const key of Object.keys(WEIGHT_DEFAULTS)) {
    const n = Number.parseInt(stored[key], 10);
    if (Number.isInteger(n) && n >= 0 && n <= 100) out[key] = n;
  }
  return Object.values(out).reduce((a, b) => a + b, 0) === 100 ? out : { ...WEIGHT_DEFAULTS };
}

export async function setFundamentalWeights(db, userId, patch) {
  const errors = [];
  const accepted = {};
  for (const [key, raw] of Object.entries(patch || {})) {
    if (!(key in WEIGHT_DEFAULTS)) continue;
    const n = Number(raw);
    if (!Number.isInteger(n) || n < 0 || n > 100) {
      errors.push(`${WEIGHT_LABELS[key]} : « ${raw} » n'est pas un entier entre 0 et 100.`);
      continue;
    }
    accepted[key] = n;
  }
  const merged = { ...(await getFundamentalWeights(db, userId)), ...accepted };
  const total = Object.values(merged).reduce((a, b) => a + b, 0);
  if (!errors.length && total !== 100) errors.push(`La pondération doit totaliser 100 % (actuellement ${total} %).`);
  if (errors.length) {
    const err = new Error(errors.join(' '));
    err.code = 'INVALID_PREFERENCES';
    throw err;
  }
  await db.batch(Object.entries(merged).map(([k, v]) =>
    db.prepare('INSERT INTO preferences (user_id, key, value) VALUES (?, ?, ?) ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value')
      .bind(userId, 'fw_' + k, String(v))));
  return getFundamentalWeights(db, userId);
}

export async function resetFundamentalWeights(db, userId) {
  await db.prepare("DELETE FROM preferences WHERE user_id = ? AND key LIKE 'fw\\_%' ESCAPE '\\'").bind(userId).run();
  return getFundamentalWeights(db, userId);
}
