// Tests de la comparaison de versions (server/update.js). Le reste du module
// (téléchargement, extraction, bascule) touche au système de fichiers et est
// vérifié à la main sur une copie jetable — voir CLAUDE.md.

import test from 'node:test';
import assert from 'node:assert/strict';
import { isNewer } from './update.js';

test('isNewer reconnaît une version plus récente', () => {
  assert.equal(isNewer('1.0.1', '1.0.0'), true);
  assert.equal(isNewer('1.1.0', '1.0.9'), true);
  assert.equal(isNewer('2.0.0', '1.99.99'), true);
});

test('isNewer refuse une version identique ou antérieure', () => {
  assert.equal(isNewer('1.0.0', '1.0.0'), false);
  assert.equal(isNewer('1.0.0', '1.0.1'), false);
  assert.equal(isNewer('0.9.9', '1.0.0'), false);
});

test('isNewer compare numériquement, pas alphabétiquement', () => {
  // Le piège classique : "1.0.10" < "1.0.9" en comparaison de chaînes.
  assert.equal(isNewer('1.0.10', '1.0.9'), true);
  assert.equal(isNewer('1.0.9', '1.0.10'), false);
});

test('isNewer ne propose jamais de mise à jour sur une version douteuse', () => {
  // Mieux vaut ne rien proposer que de pousser un testeur vers une
  // régression sur la foi d'une chaîne mal formée.
  for (const [a, b] of [['abc', '1.0.0'], ['1.0.0', 'abc'], [null, '1.0.0'], ['1.0', '1.0.0'], ['1.0.0.1', '1.0.0'], [undefined, undefined]]) {
    assert.equal(isNewer(a, b), false, `isNewer(${a}, ${b}) doit être false`);
  }
});
