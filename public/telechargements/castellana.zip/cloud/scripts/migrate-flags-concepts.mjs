#!/usr/bin/env node
// Migration idempotente (20/9/2026) — feature flags + modifications de
// l'onglet Concepts. Deux nouvelles tables (CREATE TABLE IF NOT EXISTS) :
// rejouable sans erreur, aucune donnée existante touchée. `schema.sql` reste
// la source de vérité pour une installation neuve.
//
// ⚠️ À lancer en --remote AVANT `wrangler deploy` : le code déployé lit ces
// tables, et sans elles GET /api/flags répond 500 (même piège que le magic
// link du 19/9/2026). Vérifier ensuite que les tables existent — ne pas se
// fier au seul message de fin.
//
// Usage :
//   node scripts/migrate-flags-concepts.mjs             (D1 local)
//   node scripts/migrate-flags-concepts.mjs --remote    (vrai D1)

import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const flag = process.argv.includes('--remote') ? '--remote' : '--local';

function run(sql) {
  const r = spawnSync('npx', ['wrangler', 'd1', 'execute', 'castellana-db', flag, '--command', sql], {
    cwd: ROOT, encoding: 'utf8',
  });
  if (r.status !== 0) {
    console.error(r.stdout, r.stderr);
    process.exit(r.status || 1);
  }
}

console.log(`Migration feature_flags + concept_overrides (${flag})…`);
run(`CREATE TABLE IF NOT EXISTS feature_flags (
  key TEXT PRIMARY KEY,
  enabled INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
)`);
run(`CREATE TABLE IF NOT EXISTS concept_overrides (
  concept_id TEXT PRIMARY KEY,
  titre TEXT NOT NULL,
  corps TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
)`);
console.log('OK — commandes exécutées (à vérifier avec sqlite_master).');
