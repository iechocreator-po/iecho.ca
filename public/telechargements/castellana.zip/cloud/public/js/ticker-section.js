// js/ticker-section.js — Génère le HTML de la section "Symbole" (Force
// relative + Golden Cross, + Fondamentaux en option) pour une instance
// donnée (sec/scr) — T7 (6/9/2026, demande de JP).
//
// Contexte : la carte "Symbole" de l'onglet Secteurs a grossi (fusion avec
// Force relative/Golden Cross + ajout de 9 champs fondamentaux, 5/9/2026),
// alors que la carte homonyme de l'onglet Screener est restée plus simple
// (pas de fondamentaux, sur 3 cartes séparées) — les deux étaient jusque-là
// dupliquées à la main dans index.html, et divergeaient donc dès qu'on
// touchait l'une sans penser à l'autre. Ce fichier remplace la duplication
// par UNE fonction, appelée deux fois avec des options différentes :
//   renderTickerSectionInto('sec', { withFundamentals: true });
//   renderTickerSectionInto('scr', { withFundamentals: false });
// Les IDs générés suivent la convention déjà utilisée partout ailleurs
// dans l'app (`${instanceKey}-xxx`, voir SELECTION_INSTANCES dans
// index.html) — calcSelectionFor()/fetchLiveSelectionFor() n'ont pas
// changé, ils continuent de lire/écrire les mêmes IDs, juste injectés
// dynamiquement au lieu d'être écrits en dur dans le HTML.
//
// La section s'appelle « Symbole » dans l'interface depuis le 11/9/2026 —
// « ticker » reste le nom des identifiants, des champs d'API et des
// variables, qu'aucun renommage d'affichage ne doit toucher.
//
// 11/9/2026 (demande de JP), DEUX changements liés :
//
// 1. La bannière de verdict (force relative + Golden Cross) est désormais
//    générée ICI, en tête de la section, au lieu de flotter en haut de
//    l'onglet Secteurs au-dessus de « Performance des secteurs » — où elle
//    laissait croire qu'elle résumait les secteurs, alors qu'elle ne parle
//    que du ticker saisi juste en dessous. Elle suit donc le contenu
//    qu'elle résume, dans les trois onglets qui portent un titre.
//
// 2. Les champs n'ont PLUS de valeurs de démonstration (12 / 8 / 182 /
//    170). Ces nombres étaient indiscernables de vraies données : au
//    chargement, la bannière affichait un verdict complet (« Golden Cross
//    positif ») calculé sur des chiffres fictifs, sous un ticker bien réel.
//    Les champs partent vides, les badges affichent « non renseigné », et
//    la bannière dit qu'il n'y a rien à évaluer tant qu'on n'a pas cliqué
//    « Récupérer en direct ». Même discipline que les verdicts de la
//    checklist (7/9/2026) : jamais un chiffre crédible qui n'en est pas un.
//    Les champs restent saisissables à la main.

// 20/9/2026 — UNIFORMISATION (demande de JP, à partir d'un retour de Louis) :
// ce gabarit est désormais celui de la section « Symbole » de TOUS les
// onglets qui portent un titre — Secteurs (sec), Screener (scr), Fiche de
// trade (fic) et Labo (lab). Le Journal, qui n'est qu'un formulaire de saisie
// d'un trade, garde un simple champ (mêmes libellé et placeholder).
//
// Options :
//   tickerId      id du champ symbole si ce n'est pas `${instanceKey}-ticker`
//                 (la Fiche garde `ticker`, le Labo `labo-ticker` : des dizaines
//                 de références existantes les lisent).
//   fetchCall     code du bouton « Récupérer en direct » (défaut :
//                 fetchLiveSelectionFor). La Fiche et le Labo y ajoutent leurs
//                 propres appels (VIX/RSI/ATR… ; volatilité/SMA…).
//   onTickerInput code ajouté à la frappe dans le champ symbole (calcFiche()…).
//   withFundamentals reste `true` partout (option conservée, plus utilisée).
function tickerSectionHTML(instanceKey, { withFundamentals = true, tickerId, fetchCall, onTickerInput = '' } = {}) {
  const p = instanceKey;
  const tid = tickerId || `${p}-ticker`;
  const fetchOnclick = fetchCall || `fetchLiveSelectionFor('${p}')`;
  const fundamentalsBlock = withFundamentals ? `
    <div class="colhead" style="margin-top:0.9rem;">Fondamentaux</div>
    <div class="metric-band metric-band--rows" style="--cols:5;">
      <div><span class="mb-label" title="OBV (tendance, 10 jours)">OBV 10 j <button type="button" class="info-btn" onclick="showGlossaire('obv', this)" title="Aide">i</button></span><span class="mb-value" id="${p}-m-obv">—</span></div>
      <div><span class="mb-label" title="Volume (jour)">Volume jour</span><span class="mb-value" id="${p}-m-volume">—</span></div>
      <div><span class="mb-label" title="Volume moyen (100 derniers jours)">Vol. moy. 100 j</span><span class="mb-value" id="${p}-m-volume-avg">—</span></div>
      <div><span class="mb-label" title="Float">Float <button type="button" class="info-btn" onclick="showGlossaire('float', this)" title="Aide">i</button></span><span class="mb-value" id="${p}-m-float">—</span></div>
      <div><span class="mb-label" title="P/E (trailing)">P/E <button type="button" class="info-btn" onclick="showGlossaire('pe', this)" title="Aide">i</button></span><span class="mb-value" id="${p}-m-pe">—</span></div>
      <div><span class="mb-label" title="Moyenne des pairs de la watchlist dans la même industrie GICS fine (ex. « Aerospace &amp; Defense ») ; bascule sur le P/E du SECTEUR GICS large (l'agrégat ETF réel de la carte « Performance des secteurs ») si aucun pair de cette industrie fine n'est suivi.">P/E industrie</span><span class="mb-value" id="${p}-m-industry-pe">—</span><span class="mb-sub" id="${p}-m-industry-pe-sub"></span></div>
      <div><span class="mb-label" title="PEG">PEG <button type="button" class="info-btn" onclick="showGlossaire('peg', this)" title="Aide">i</button></span><span class="mb-value" id="${p}-m-peg">—</span></div>
      <div><span class="mb-label" title="Price-to-Sales (12 derniers mois) = capitalisation ÷ revenus. Utile pour les sociétés non rentables en forte croissance. Repère : 1 à 2 = très bien.">P/S</span><span class="mb-value" id="${p}-m-ps">—</span></div>
      <div><span class="mb-label" title="Beta (5 ans)">Bêta 5 ans <button type="button" class="info-btn" onclick="showGlossaire('beta', this)" title="Aide">i</button></span><span class="mb-value" id="${p}-m-beta">—</span></div>
      <div><span class="mb-label" title="VWAP (séance en cours)">VWAP séance <button type="button" class="info-btn" onclick="showGlossaire('vwap', this)" title="Aide">i</button></span><span class="mb-value" id="${p}-m-vwap">—</span></div>
    </div>
    <p class="metric-sub" style="text-align:left;">Volume (jour)/Volume moyen (100 j)/Float/P-E (trailing)/Industrie/PEG/Beta (5 ans)/VWAP (séance en cours) via Yahoo Finance (fundamentals.js) ; OBV via calcul maison sur 10 jours (indicators.js). P/E industrie = moyenne des pairs de la watchlist partageant la même industrie FINE, depuis le dernier screening en cache (lancer un screening dans l'onglet Screener si vide) — sans aucun pair suivi dans cette industrie, la tuile bascule sur le P/E du SECTEUR GICS large (agrégat ETF réel, carte « Performance des secteurs »), étiqueté comme tel. VWAP affiche « — » hors séance (aucune barre intraday disponible).</p>
    <div class="colhead" style="margin-top:0.9rem;">Tendance (filtre d'entrée) <button type="button" class="info-btn" onclick="showGlossaire('sma', this)" title="Aide">i</button></div>
    <div class="metric-band" style="--cols:6;">
      <div><span class="mb-label">Prix</span><span class="mb-value" id="${p}-m-prix">—</span></div>
      <div><span class="mb-label">ATR(14) <button type="button" class="info-btn" onclick="showGlossaire('atr', this)" title="Aide">i</button></span><span class="mb-value" id="${p}-m-atr">—</span></div>
      <div><span class="mb-label" id="${p}-m-smaf-lbl">SMA rapide</span><span class="mb-value" id="${p}-m-smaf">—</span></div>
      <div><span class="mb-label" id="${p}-m-smam-lbl">SMA moyenne</span><span class="mb-value" id="${p}-m-smam">—</span></div>
      <div><span class="mb-label" id="${p}-m-smal-lbl">SMA lente</span><span class="mb-value" id="${p}-m-smal">—</span></div>
      <div><span class="mb-label">Alignement</span><span class="mb-value" id="${p}-m-align">—</span></div>
    </div>
    <p class="metric-sub" style="text-align:left;" id="${p}-m-sma-rule">Prix &gt; SMA rapide &gt; SMA moyenne &gt; SMA lente (dans cet ordre) = haussier · l'ordre strictement inverse = baissier · tout le reste = neutre. Périodes réglables dans Réglages → Valeur personnalisée.</p>
  ` : '';

  return `
    <div class="section-title">Symbole</div>
    <div id="${p}-banner" class="banner unknown">
      <span id="${p}-banner-text">—</span>
      <button type="button" id="${p}-banner-btn" class="ds-btn" style="display:none;" onclick="addCurrentTickerToWatchlist('${p}')">+ Ajouter à la watchlist</button>
    </div>
    <div class="field-grid" style="margin-bottom:0.25rem;">
      <div class="field span-2"><label>Symbole évalué</label><input class="ds-input" type="text" id="${tid}" placeholder="ex. AAPL ou berkshire" style="text-transform:uppercase; " oninput="calcSelectionFor('${p}');${onTickerInput}"></div>
      <div class="field span-2"><button type="button" class="ds-btn ds-btn--shine" id="${p}-fetch-btn" onclick="searchThenFetch('${tid}', this, function(){${fetchOnclick}})">Récupérer en direct</button></div>
      ${withFundamentals ? `<div class="field span-2"><label>Industrie</label><span class="val" id="${p}-m-industry" style="max-width:100%; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">—</span></div>` : ''}
    </div>
    <p class="metric-sub" id="${p}-live-status" style="text-align:left; margin-top:4px;"></p>
    ${fundamentalsBlock}
    <div class="signal-pair" style="margin-top:0.9rem;">
      <div class="signal">
        <div class="colhead">Force relative vs SPY <button type="button" class="info-btn" onclick="showGlossaire('forceRelative', this)" title="Aide">i</button></div>
        <div class="field-grid">
          <div class="field"><label title="Performance du titre (%, jour — ou saisis une autre période à la main)">Titre (%, jour)</label><input class="ds-input" type="number" id="${p}-perfTitre" value="" placeholder="non récupéré" step="0.1" oninput="selectionManualEdit('${p}')"></div>
          <div class="field"><label title="Performance du S&amp;P 500 (SPY) sur la même période (%)">SPY (%, même période)</label><input class="ds-input" type="number" id="${p}-perfIndice" value="" placeholder="non récupéré" step="0.1" oninput="selectionManualEdit('${p}')"></div>
          <div class="field"><label>Écart</label><span class="val" id="${p}-fr-badge">—</span></div>
        </div>
        <p class="metric-sub" id="${p}-fr-note">—</p>
      </div>
      <div class="signal">
        <div class="colhead">Golden Cross (régime de fond) <button type="button" class="info-btn" onclick="showGlossaire('goldenCross', this)" title="Aide">i</button></div>
        <div class="field-grid">
          <div class="field"><label>SMA50</label><input class="ds-input" type="number" id="${p}-sma50" value="" placeholder="non récupéré" step="0.01" oninput="selectionManualEdit('${p}')"></div>
          <div class="field"><label>SMA200</label><input class="ds-input" type="number" id="${p}-sma200" value="" placeholder="non récupéré" step="0.01" oninput="selectionManualEdit('${p}')"></div>
          <div class="field"><label>Régime</label><span class="val" id="${p}-gc-badge">—</span></div>
        </div>
        <p class="metric-sub" id="${p}-gc-note">—</p>
      </div>
    </div>
  `;
}

function renderTickerSectionInto(instanceKey, options) {
  const card = document.getElementById(instanceKey + '-ticker-card');
  card.innerHTML = tickerSectionHTML(instanceKey, options);
}

// Bloc « Tendance » de la section Symbole (16/10/2026, ex-carte E7 de l'Option Lab) : prix, ATR, les
// trois SMA du filtre d'entrée (périodes des Réglages, renvoyées par /api/market-data) et l'alignement.
// `m` = réponse de /api/market-data, ou null pour tout remettre à « — ». Aucun appel de plus.
function renderTrendFor(instanceKey, m) {
  const p = instanceKey;
  const el = (id) => document.getElementById(`${p}-m-${id}`);
  if (!el('prix')) return;
  const px = (v) => (v != null && Number.isFinite(v) ? v.toFixed(2) + ' $' : '—');
  const per = m?.smaPeriods || null;
  el('prix').textContent = px(m?.price);
  el('atr').textContent = px(m?.atr);
  el('smaf-lbl').textContent = per ? `SMA ${per.fast}` : 'SMA rapide';
  el('smam-lbl').textContent = per ? `SMA ${per.medium}` : 'SMA moyenne';
  el('smal-lbl').textContent = per ? `SMA ${per.slow}` : 'SMA lente';
  el('smaf').textContent = px(m?.sma9);
  el('smam').textContent = px(m?.sma21);
  el('smal').textContent = px(m?.sma100);
  const a = m?.smaAlignment || null;
  el('align').textContent = a || '—';
  el('align').style.color = a === 'haussier' ? 'var(--green)' : a === 'baissier' ? 'var(--red)' : a ? 'var(--amber)' : '';
  el('sma-rule').textContent = per
    ? `Prix > SMA ${per.fast} > SMA ${per.medium} > SMA ${per.slow} (dans cet ordre) = haussier · l'ordre strictement inverse = baissier · tout le reste = neutre. Périodes réglables dans Réglages → Valeur personnalisée.`
    : "Prix > SMA rapide > SMA moyenne > SMA lente (dans cet ordre) = haussier · l'ordre strictement inverse = baissier · tout le reste = neutre. Périodes réglables dans Réglages → Valeur personnalisée.";
}
