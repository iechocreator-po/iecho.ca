import { createTrade, listTrades, getTrade, updateTrade, deleteTrade, validateTrade, COLUMNS as TRADE_COLUMNS } from '../db/trades.js';
import { computeStats } from '../lib/stats.js';

function csvEscape(v) {
  if (v == null) return '';
  const s = String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function registerTradesRoutes(app) {
  app.post('/api/trades', async (c) => {
    const userId = c.get('userId');
    const body = await c.req.json().catch(() => ({}));
    const errors = validateTrade(body);
    if (errors.length) return c.json({ errors }, 400);
    try {
      const trade = await createTrade(c.env.DB, userId, body);
      return c.json(trade, 201);
    } catch (err) {
      return c.json({ error: err.message }, 400);
    }
  });

  // Déclaré AVANT /api/trades/:id pour que 'trades.csv' (un chemin frère
  // de /api/trades, pas un sous-chemin) ne soit jamais confondu avec
  // /api/trades/:id — même prudence que pour /api/sectors/history.
  app.get('/api/trades.csv', async (c) => {
    const userId = c.get('userId');
    const cols = ['id', ...TRADE_COLUMNS];
    const trades = await listTrades(c.env.DB, userId);
    const lines = [cols.join(',')];
    for (const row of trades) lines.push(cols.map((col) => csvEscape(row[col])).join(','));
    return new Response(lines.join('\n'), {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="journal-castellana-${Date.now()}.csv"`,
      },
    });
  });

  app.get('/api/trades', async (c) => {
    const userId = c.get('userId');
    const compte = c.req.query('compte');
    const ticker = c.req.query('ticker');
    const rawOpen = c.req.query('open');
    const open = rawOpen === 'true' ? true : rawOpen === 'false' ? false : undefined;
    return c.json({ trades: await listTrades(c.env.DB, userId, { compte, ticker, open }) });
  });

  app.get('/api/trades/:id', async (c) => {
    const trade = await getTrade(c.env.DB, c.get('userId'), c.req.param('id'));
    if (!trade) return c.json({ error: 'trade introuvable' }, 404);
    return c.json(trade);
  });

  app.put('/api/trades/:id', async (c) => {
    const userId = c.get('userId');
    const id = c.req.param('id');
    if (!(await getTrade(c.env.DB, userId, id))) return c.json({ error: 'trade introuvable' }, 404);
    const body = await c.req.json().catch(() => ({}));
    const errors = validateTrade(body, { partial: true });
    if (errors.length) return c.json({ errors }, 400);
    try {
      return c.json(await updateTrade(c.env.DB, userId, id, body));
    } catch (err) {
      return c.json({ error: err.message }, 400);
    }
  });

  app.delete('/api/trades/:id', async (c) => {
    const userId = c.get('userId');
    if (!(await deleteTrade(c.env.DB, userId, c.req.param('id')))) {
      return c.json({ error: 'trade introuvable' }, 404);
    }
    return new Response(null, { status: 204 });
  });

  app.get('/api/stats', async (c) => {
    return c.json(await computeStats(c.env.DB, c.get('userId')));
  });
}
