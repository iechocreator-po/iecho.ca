// js/trade-rules.js — règles de validation des nombres et des dates du Journal et de la Roue (audit routes, 21/10/2026).
//
// Avant : `POST /api/trades` acceptait un prix négatif, une taille de 0, un stop « abc » ou une date quelconque (SQLite garde le texte tel
// quel dans une colonne REAL), et `primeCloture: null` passait le contrôle `>= 0` (en JavaScript null, '' et [] valent >= 0) : un rachat
// sans prime était compté à 0 $ et gonflait le profit du cycle. Le serveur local et le Worker cloud partagent maintenant CES règles.
// SOURCE UNIQUE : serveur local (server/trade-rules.js l'évalue) et Worker cloud (copie ESM générée : npm run sync:cloud).
// Ne contenir que des déclarations de premier niveau.

// Un vrai nombre fini : pas null, pas '', pas un booléen, pas un tableau.
function tradeIsNumber(v) {
  if (v === null || v === undefined || typeof v === 'boolean' || Array.isArray(v) || typeof v === 'object') return false;
  if (typeof v === 'string' && v.trim() === '') return false;
  return Number.isFinite(Number(v));
}
function tradeIsPositive(v) { return tradeIsNumber(v) && Number(v) > 0; }
function tradeIsNonNegative(v) { return tradeIsNumber(v) && Number(v) >= 0; }
// AAAA-MM-JJ, jour réel du calendrier (le 2026-02-30 est refusé).
function tradeIsIsoDate(v) {
  if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v)) return false;
  const d = new Date(v + 'T00:00:00Z');
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === v;
}

// Erreurs de nombres et de dates d'un trade d'actions. `partial` : seuls les champs présents sont contrôlés.
function tradeNumberErrors(data) {
  const errors = [];
  const present = (f) => data[f] !== undefined && data[f] !== null && data[f] !== '';
  for (const f of ['prix_entree', 'stop_initial', 'prix_sortie']) {
    if (present(f) && !tradeIsPositive(data[f])) errors.push(`${f} doit être un nombre > 0`);
  }
  if (present('taille_position') && !(tradeIsPositive(data.taille_position) && Number.isInteger(Number(data.taille_position)))) {
    errors.push('taille_position doit être un entier > 0');
  }
  if (present('r_realise') && !tradeIsNumber(data.r_realise)) errors.push('r_realise doit être un nombre');
  for (const f of ['date_entree', 'date_sortie']) {
    if (present(f) && !tradeIsIsoDate(data[f])) errors.push(`${f} doit être une date AAAA-MM-JJ`);
  }
  if (tradeIsNumber(data.prix_entree) && tradeIsNumber(data.stop_initial) && Number(data.prix_entree) === Number(data.stop_initial)) {
    errors.push('stop_initial ne peut pas égaler prix_entree (risque nul)');
  }
  return errors;
}
