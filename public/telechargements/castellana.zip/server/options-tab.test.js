// Tests des fonctions pures de js/options-common.js (export CSV, bornes de strike).
// optionDelta/optionMarketZone ont déménagé dans js/options-analytics.js
// (22/9/2026, réutilisées côté serveur pour la grille/le screener de
// primes) — leurs tests vivent désormais dans options-analytics.test.js.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const tab = readFileSync(new URL('../js/options-common.js', import.meta.url), 'utf8');
const filt = tab.slice(tab.indexOf('function optionsActiveFilterCount'), tab.length);
const { optionsToCSV, optionsStrikeBounds } = new Function(`${filt}\nreturn { optionsToCSV, optionsStrikeBounds };`)();

test('export CSV : une ligne par contrat affiché, vide (pas 0) quand absent, filtres appliqués', () => {
  const ch = {
    ticker: 'ABC', price: 100, expiry: '2026-10-16', dte: 26,
    calls: [{ strike: 100, bid: null, ask: null, last: 1.5, volume: 10, openInterest: 50, iv: 0.3, delta: 0.52, itm: false, contractSymbol: 'ABC261016C00100000' },
            { strike: 300, bid: 1, ask: 2, last: 1, volume: 1, openInterest: 1, iv: 0.9, delta: 0.01, itm: false, contractSymbol: 'X' }],
    puts: [{ strike: 95, bid: 2, ask: 2.2, last: 2.1, volume: 0, openInterest: 5, iv: 0.35, delta: -0.4, itm: false, contractSymbol: 'P,1' }],
  };
  const csv = optionsToCSV(ch, { rangePct: 20, minOI: null, minVolume: null, quotedOnly: false }).trim().split('\n');
  assert.equal(csv.length, 3); // en-tête + call 100 + put 95 (le call 300 est hors plage)
  assert.equal(csv[1], 'call,2026-10-16,26,100,,,1.5,10,50,0.3,0.52,non,ABC261016C00100000');
  assert.ok(csv[2].endsWith('"P,1"')); // virgule dans un champ → guillemets
  const quoted = optionsToCSV(ch, { rangePct: 20, minOI: null, minVolume: null, quotedOnly: true }).trim().split('\n');
  assert.equal(quoted.length, 2); // le call sans cotation est écarté
});

test('sans plage (ou sans prix exploitable), aucune borne de strike : toute la chaîne est visible', () => {
  assert.deepEqual(optionsStrikeBounds(100, null), { lo: -Infinity, hi: Infinity });
  assert.deepEqual(optionsStrikeBounds(0, 20), { lo: -Infinity, hi: Infinity });
  assert.deepEqual(optionsStrikeBounds(null, 20), { lo: -Infinity, hi: Infinity });
  const b = optionsStrikeBounds(100, 20);
  assert.ok(Math.abs(b.lo - 80) < 1e-9 && Math.abs(b.hi - 120) < 1e-9);
});

test('export CSV sans aucun filtre : tous les contrats, même hors plage', () => {
  const ch = { ticker: 'ABC', price: 100, expiry: '2026-10-16', dte: 26,
    calls: [{ strike: 300, bid: null, ask: null, last: null, volume: null, openInterest: null, iv: null, delta: null, itm: false, contractSymbol: 'X' }], puts: [] };
  assert.equal(optionsToCSV(ch, { rangePct: null, minOI: null, minVolume: null, quotedOnly: false }).trim().split('\n').length, 2);
});
