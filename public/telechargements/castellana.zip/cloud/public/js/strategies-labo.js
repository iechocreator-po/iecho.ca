// js/strategies-labo.js — Onglet Labo : catalogue des stratégies d'options
// testables + génération de la séquence pas-à-pas pour un titre.
//
// Contexte important : strategy/PoorManCoveredCall.md.rtf, malgré son nom,
// décrit en réalité deux systèmes distincts (Cash-Secured Put → Covered
// Call, puis Bull Call/Bear Put Spread pour la gestion du risque) — PAS la
// vraie Poor Man's Covered Call (LEAPS call profondément ITM + call court
// vendu contre). Décision de JP (5/9/2026, session Labo) : garder ces
// stratégies distinctes de la vraie PMCC dans le sélecteur — 'pmcc'
// implémente la vraie définition standard de la stratégie.
//
// Séparation du 7/9/2026 (demande de JP) : les deux systèmes du fichier
// source, jusque-là fusionnés dans une seule entrée 'roue-debit-spreads',
// sont désormais deux entrées séparées — 'roue' (Cash-Secured Put →
// Covered Call) et 'debit-spreads' (Bull Call / Bear Put Spread). Même
// contenu, juste réorganisé ; aucun nouveau calcul introduit (la jambe
// vendue de chaque spread réutilise la même formule Black-Scholes que la
// Covered Call/le Cash-Secured Put de La Roue, faute d'un Delta cible
// propre aux spreads dans le fichier source).
//
// AUCUNE donnée d'options réelle (chaîne, delta, prime) n'est disponible
// dans cette app — aucune source de ce type n'y est branchée.
//
// Révision du 5/9/2026 (retours de JP, 2e passe — T1/T2/T3) :
// - T1 : toute valeur DYNAMIQUE (calculée à partir du prix/de la
//   volatilité/du ticker chargé) est enveloppée dans <span class="labo-dyn">
//   pour se distinguer visuellement du texte STATIQUE (règle de la
//   stratégie, qui ne change pas d'un titre à l'autre). Voir laboDyn().
// - T2 : les zones de strike ne sont plus un multiple arbitraire de l'ATR
//   (qui n'avait aucun lien mathématique avec le Delta cible annoncé juste
//   à côté — un vrai problème de crédibilité). Elles sont maintenant
//   dérivées de Black-Scholes à partir du Delta cible réel de la
//   stratégie, du prix et de la VOLATILITÉ HISTORIQUE du titre (calculée
//   côté serveur sur son propre historique de prix). Chaque stratégie
//   expose un tableau `legs` détaillant ce calcul, rendu dans un panneau
//   "Comment ces prix sont calculés" — pour répondre concrètement à
//   "pourquoi ce prix-là ?" plutôt que de l'affirmer sans le montrer.
//   RAPPEL, à ne jamais perdre en étendant ceci : la volatilité historique
//   est un PROXY de la volatilité implicite réelle du marché (que cette
//   app n'a aucune source pour obtenir) — l'écart entre les deux peut être
//   important, en particulier autour d'événements comme les résultats
//   trimestriels. Un strike Black-Scholes reste une ESTIMATION, jamais une
//   vraie donnée d'options.
// - T3 : les 3 périodes du filtre de tendance (rapide/moyenne/lente) sont
//   désormais RÉELLEMENT configurables depuis des champs visibles en haut
//   de l'onglet Labo (index.html) — pas seulement des libellés cosmétiques
//   comme c'était le cas ailleurs dans l'app avant cette révision. Voir
//   server/indicators.js (paramètre `periods` de getHomemadeIndicators).

function laboFmtPrix(n) {
  return n == null ? '—' : new Intl.NumberFormat('fr-CA', { style: 'currency', currency: 'USD', maximumFractionDigits: 2 }).format(n);
}
function laboFmtPct(n, decimals = 1) {
  return n == null ? '—' : `${(n * 100).toFixed(decimals)} %`;
}

// T1 — enveloppe toute valeur DYNAMIQUE (dépend du ticker/des données
// chargées) pour la distinguer visuellement du texte statique de la règle.
function laboDyn(text) {
  // Échappé (audit périphérie, 22/10/2026) : le symbole saisi et le secteur venu de Yahoo ne doivent pas devenir du HTML.
  const sur = String(text ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  return `<span class="labo-dyn">${sur}</span>`;
}

// ---- Paramètres éditables (schéma : js/labo-schema.js) ----
// Trois familles de texte dans une séquence, à ne pas confondre :
//   statique  — la règle, ne change jamais ;
//   dynamique — calculée à partir du titre chargé (laboDyn, en gras/accent) ;
//   éditable  — un PARAMÈTRE de la stratégie, réglé par l'utilisateur
//               (laboParam/laboRange : un vrai champ, souligné en pointillé).
// Un paramètre modifié est marqué (point) et porte un ↺ pour revenir à sa
// valeur d'origine ; le défaut reste lisible en info-bulle.
function laboParamDef(stratId, key) {
  const def = laboResolveStrategy(stratId);
  return def ? def.params.find((p) => p.key === key) : null;
}

function laboParam(stratId, key, params, withUnit = true) {
  const def = laboParamDef(stratId, key);
  if (!def) return laboDyn(String(params[key]));
  const value = params[key];
  const modified = value !== def.default;
  const w = Math.max(3, String(value).length + 1.5);
  const unit = withUnit && def.unit ? `<span class="labo-param-unit">${def.unit}</span>` : '';
  const reset = modified
    ? `<button type="button" class="labo-param-reset" title="Remettre la valeur d'origine (${def.default}${def.unit ? ' ' + def.unit : ''})" onclick="laboResetParam('${stratId}','${key}')">↺</button>`
    : '';
  return `<span class="labo-param-wrap${modified ? ' is-modified' : ''}">`
    + `<input type="number" class="labo-param" data-strat="${stratId}" data-key="${key}" value="${value}" min="${def.min}" max="${def.max}" step="${def.step}" style="width:${w}ch" `
    + `title="${def.label} — défaut : ${def.default}${def.unit ? ' ' + def.unit : ''}" onchange="laboParamChanged(this)">`
    + `${unit}${reset}</span>`;
}

// Plage « min-max » : deux champs, l'unité affichée une seule fois à la fin.
function laboRange(stratId, keyMin, keyMax, params) {
  const def = laboParamDef(stratId, keyMax);
  const unit = def && def.unit ? `<span class="labo-param-unit">${def.unit}</span>` : '';
  return `${laboParam(stratId, keyMin, params, false)}<span class="labo-param-sep">–</span>${laboParam(stratId, keyMax, params, false)}${unit}`;
}

// Petit bouton (i) vers le popover du glossaire existant (showGlossaire,
// index.html) — mêmes clés que les indicateurs techniques, réutilisé tel
// quel pour ne pas dupliquer le mécanisme de popover.
function laboInfoBtn(key) {
  return `<button type="button" class="info-btn" onclick="showGlossaire('${key}', this)" title="Aide">i</button>`;
}

// ---- Black-Scholes minimal (delta → strike), T2 ----
// Approximation d'erf (Abramowitz & Stegun 7.1.26, précision ~1e-7) — pas
// de librairie ajoutée, cohérent avec la discipline zéro-dépendance du
// reste du portfolio pour ce genre de calcul.
function laboErf(x) {
  const sign = x < 0 ? -1 : 1;
  x = Math.abs(x);
  const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741, a4 = -1.453152027, a5 = 1.061405429, p = 0.3275911;
  const t = 1 / (1 + p * x);
  const y = 1 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);
  return sign * y;
}
function laboNormCdf(x) {
  return 0.5 * (1 + laboErf(x / Math.SQRT2));
}
// Inverse de la CDF normale — approximation rationnelle de Peter Acklam,
// précision ~1.15e-9, algorithme public bien connu (pas de librairie).
function laboNormInv(p) {
  if (p <= 0) return -Infinity;
  if (p >= 1) return Infinity;
  const a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02, 1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00];
  const b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02, 6.680131188771972e+01, -1.328068155288572e+01];
  const c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00, -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00];
  const d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00, 3.754408661907416e+00];
  const plow = 0.02425, phigh = 1 - plow;
  let q, r;
  if (p < plow) {
    q = Math.sqrt(-2 * Math.log(p));
    return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5])
      / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
  }
  if (p <= phigh) {
    q = p - 0.5;
    r = q * q;
    return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q
      / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
  }
  q = Math.sqrt(-2 * Math.log(1 - p));
  return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5])
    / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
}

// Strike dont le delta Black-Scholes ≈ `delta` cible, pour un type
// 'call'|'put' donné. d1 = Φ⁻¹(Δ) pour un Call, −Φ⁻¹(Δ) pour un Put (la
// magnitude du delta d'un Put est conventionnellement citée en positif,
// ex. "delta 0.20", même si le vrai delta d'un Put est négatif).
function laboStrikeForDelta({ S, T, r, sigma, delta, type }) {
  const d1 = type === 'call' ? laboNormInv(delta) : -laboNormInv(delta);
  const K = S * Math.exp((r + (sigma * sigma) / 2) * T - d1 * sigma * Math.sqrt(T));
  return { K, d1 };
}

// Zone [basse, haute] entre les deux bornes de Delta de la stratégie —
// calcule un strike pour chaque borne puis trie (pas d'hypothèse sur quel
// côté donne le strike le plus élevé, plus robuste). Retourne aussi le
// détail complet (`leg`) pour le panneau "Comment ces prix sont calculés".
function laboStrikeZone({ S, T, r, sigma, deltaMin, deltaMax, type, role, dteJours }) {
  if (S == null || sigma == null) {
    return { texte: '—', basse: null, haute: null, leg: { role, type, deltaMin, deltaMax, dteJours, indisponible: true } };
  }
  const atMin = laboStrikeForDelta({ S, T, r, sigma, delta: deltaMin, type });
  const atMax = laboStrikeForDelta({ S, T, r, sigma, delta: deltaMax, type });
  const basse = Math.min(atMin.K, atMax.K);
  const haute = Math.max(atMin.K, atMax.K);
  return {
    texte: `${laboFmtPrix(basse)} – ${laboFmtPrix(haute)}`,
    basse,
    haute,
    leg: { role, type, deltaMin, deltaMax, dteJours, S, T, r, sigma, atMin, atMax, indisponible: false },
  };
}

// Rendu du panneau "Comment ces prix sont calculés" (une ligne par leg) —
// <details> natif, replié par défaut, pas de JS de bascule nécessaire.
function laboRenderAnalyse(legs) {
  const rows = legs.map((leg) => {
    if (leg.indisponible) {
      return `<tr><td>${leg.role}</td><td>${leg.type === 'call' ? 'Call' : 'Put'}</td><td>${laboFmtPct(leg.deltaMin, 0)}–${laboFmtPct(leg.deltaMax, 0)}</td><td colspan="3">Charge les données en direct pour voir ce calcul.</td></tr>`;
    }
    return `<tr>
      <td>${leg.role}</td>
      <td>${leg.type === 'call' ? 'Call' : 'Put'}</td>
      <td>${laboFmtPct(leg.deltaMin, 0)} (d1=${leg.atMin.d1.toFixed(3)}) → ${laboFmtPrix(leg.atMin.K)}</td>
      <td>${laboFmtPct(leg.deltaMax, 0)} (d1=${leg.atMax.d1.toFixed(3)}) → ${laboFmtPrix(leg.atMax.K)}</td>
      <td>${leg.dteJours} j (T=${(leg.T).toFixed(3)} an)</td>
    </tr>`;
  }).join('');
  const first = legs.find((l) => !l.indisponible);
  const inputs = first
    ? `Prix (S) = ${laboFmtPrix(first.S)} · Volatilité historique annualisée (σ) = ${laboFmtPct(first.sigma)} · Taux sans risque (r) = ${laboFmtPct(first.r)}`
    : `Charge les données en direct pour voir les valeurs utilisées (prix, volatilité historique, taux sans risque).`;
  return `
    <details class="labo-analyse">
      <summary>Comment ces prix sont calculés (Black-Scholes)</summary>
      <p class="metric-sub" style="text-align:left;">${inputs}</p>
      <p class="metric-sub" style="text-align:left;">Formule : K = S × exp((r + σ²/2) × T − d1 × σ × √T), où d1 = Φ⁻¹(Delta) pour un Call acheté/vendu, ou −Φ⁻¹(Delta) pour un Put. σ est une volatilité HISTORIQUE (réalisée sur les prix passés) utilisée comme approximation de la volatilité implicite réelle du marché — que cette app n'a aucune source pour obtenir. L'écart entre les deux peut être important (ex. autour des résultats trimestriels).</p>
      <div class="screen-table-wrap">
        <table class="ds-table">
          <thead><tr><th>Jambe</th><th>Type</th><th>Borne basse du Delta</th><th>Borne haute du Delta</th><th>Échéance utilisée</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </details>
  `;
}

// Résume les SMA + le prix pour que l'alignement affiché (haussier/neutre/
// baissier) soit VÉRIFIABLE par JP plutôt qu'un mot opaque. Les périodes
// utilisées viennent de `data.smaPeriods` (réellement appliquées côté
// serveur, T3) plutôt que supposées être 9/21/100.
function laboSmaDetail(data) {
  if (!data || data.sma9 == null || data.sma21 == null || data.sma100 == null || data.price == null) {
    return "Clique « Charger les données en direct » pour voir le prix et les 3 SMA réels et vérifier toi-même l'ordre.";
  }
  const p = data.smaPeriods || { fast: 9, medium: 21, slow: 100 };
  return `Valeurs réelles — Prix ${laboDyn(laboFmtPrix(data.price))} · SMA${p.fast} ${laboDyn(laboFmtPrix(data.sma9))} · SMA${p.medium} ${laboDyn(laboFmtPrix(data.sma21))} · SMA${p.slow} ${laboDyn(laboFmtPrix(data.sma100))}. `
    + `« Haussier » exige prix > SMA${p.fast} > SMA${p.medium} > SMA${p.slow} dans cet ordre exact ; « baissier » l'ordre strictement inverse ; sinon c'est « neutre » (l'ordre n'est pas complet, même si certaines des trois valeurs sont bien rangées).`;
}

const STRATEGIES_LABO = [
  {
    id: 'roue',
    enClair: {
      quand: ["Tu aimerais de toute façon posséder cette action, mais à un meilleur prix que celui d'aujourd'hui.", "Le titre est solide (une grosse entreprise connue) et tu t'attends à ce qu'il stagne, monte doucement ou baisse un peu.", "Tu as l'argent en banque pour acheter 100 actions si jamais on te les « livre »."],
      comment: ["Imagine que tu veux acheter une console à 400 $ mais qu'elle en vaut 500 $ en ce moment. Tu dis au magasin : « Si le prix tombe à 400 $, je l'achète. En attendant, paie-moi pour avoir attendu. » Le magasin te donne une petite somme tout de suite : c'est la prime. C'est ça, vendre un Put.", "Si le prix ne tombe pas à 400 $, tu gardes la prime et tu recommences. S'il tombe, tu achètes l'action au prix que tu avais dit (moins la prime que tu as déjà reçue) : tu l'as eue à rabais.", "Une fois l'action en main, tu fais l'inverse : « Je suis prêt à la vendre à 550 $. Paie-moi pour ça. » C'est un Call. Si elle monte jusque-là, tu la vends avec profit ; sinon tu gardes la prime et tu recommences. Ça tourne en rond, comme une roue — d'où le nom.", "Le piège : si l'action s'effondre, tu l'achètes quand même au prix promis, donc tu peux perdre gros. Ne le fais que sur des titres que tu es content de posséder."],
    },
    nom: 'La Roue (Wheel Strategy)',
    statut: 'disponible',
    resume: "Vente de Cash-Secured Put pour collecter des primes, assignation éventuelle suivie de Covered Call sur les actions reçues.",
    sourceNote: "Source : strategy/PoorManCoveredCall.md.rtf — ce fichier porte ce nom mais décrit en réalité ce système (La Roue) et les Debit Spreads (voir l'entrée séparée ci-dessous), pas la vraie Poor Man's Covered Call (voir l'entrée dédiée plus bas). Séparées en deux stratégies distinctes le 7/9/2026 à la demande de JP — elles vivaient à l'origine dans une seule séquence.",
    build(ctx) {
      const { ticker, data } = ctx;
      const id = 'roue';
      const p = ctx.params || laboDefaults(id);
      const S = data?.price ?? null;
      const sigma = data?.historicalVolatility ?? null;
      const r = p.riskFreePct / 100;
      const putDte = Math.round((p.putDteMin + p.putDteMax) / 2);
      const callDte = Math.round((p.callDteMin + p.callDteMax) / 2);
      const putZone = laboStrikeZone({ S, T: putDte / 365, r, sigma, deltaMin: p.putDeltaMin, deltaMax: p.putDeltaMax, type: 'put', role: 'Put vendu (Cash-Secured Put)', dteJours: putDte });
      const callZone = laboStrikeZone({ S, T: callDte / 365, r, sigma, deltaMin: p.callDeltaMin, deltaMax: p.callDeltaMax, type: 'call', role: 'Call vendu (Covered Call)', dteJours: callDte });
      const steps = [
        {
          titre: '1. Sélection du sous-jacent (filtre fondamental)',
          points: [
            `Vérifier que ${laboDyn(ticker)} est une Blue Chip ou un ETF à forte liquidité — pas un titre spéculatif.`,
            data
              ? `Données réelles — Volume du jour : ${laboDyn(data.volume != null ? data.volume.toLocaleString('fr-CA') : '—')} · Beta 5 ans : ${laboDyn(data.beta ?? '—')} · Secteur : ${laboDyn(data.sector ?? '—')}`
              : `Clique « Charger les données en direct » pour voir le volume/beta/secteur réels de ${laboDyn(ticker)}.`,
          ],
        },
        {
          titre: '2. Phase 1 — Vendre un Put garanti par du cash (Cash-Secured Put)',
          points: [
            `Vendre (encaisser une prime pour) un Put, échéance dans ${laboRange(id, 'putDteMin', 'putDteMax', p)} (DTE = jours restants avant l'échéance), Delta cible ${laboRange(id, 'putDeltaMin', 'putDeltaMax', p)} ${laboInfoBtn('delta')} (≈${laboRange(id, 'probOtmMin', 'probOtmMax', p)} de chances d'expirer hors la monnaie, donc favorable au vendeur).`,
            `Zone de strike estimée (Black-Scholes, volatilité historique — <a href="#" onclick="return false;">détail plus bas</a>) : ${laboDyn(putZone.texte)}`,
            `Résultat A — le titre monte ou stagne : le Put expire sans valeur → profit = 100% de la prime encaissée.`,
            `Résultat B — le titre baisse sous le strike : assignation → achat obligatoire de ${laboParam(id, 'contractSize', p)} ${laboDyn(ticker)} au prix du strike (d'où « garanti par du cash » : il faut avoir ce montant disponible).`,
          ],
        },
        {
          titre: '3. Phase 2 — Vendre un Call sur les actions reçues (Covered Call)',
          points: [
            `Uniquement si assigné en phase 1 : vendre un Call sur les ${laboParam(id, 'contractSize', p)} maintenant détenues, échéance dans ${laboRange(id, 'callDteMin', 'callDteMax', p)}, Delta cible ${laboRange(id, 'callDeltaMin', 'callDeltaMax', p)} ${laboInfoBtn('delta')}.`,
            `Zone de strike estimée : ${laboDyn(callZone.texte)}`,
            `Résultat A — le titre dépasse le strike : les actions sont rachetées (« cédées ») au strike → profit sur le titre + prime encaissée.`,
            `Résultat B — le titre stagne sous le strike : rien ne se passe → répéter la vente d'un nouveau Call le cycle suivant.`,
          ],
        },
        {
          titre: '4. Règles de sortie (les deux phases)',
          points: [
            `Prise de profit : racheter l'option vendue (Buy to Close) dès ${laboRange(id, 'profitTakeMin', 'profitTakeMax', p)} du profit maximal atteint — ne pas attendre l'expiration.`,
            `Gestion défensive : rouler (Roll = racheter puis revendre à une échéance plus lointaine) si le strike est testé.`,
          ],
        },
      ];
      return { steps, legs: [putZone.leg, callZone.leg] };
    },
  },
  {
    id: 'debit-spreads',
    enClair: {
      quand: ["Tu penses que le titre va clairement monter (Bull Call) ou descendre (Bear Put) dans les prochaines semaines.", "Acheter l'option seule coûte trop cher, et tu acceptes de limiter ton gain en échange d'un coût plus bas.", "Tu veux savoir à l'avance combien tu peux perdre au maximum."],
      comment: ["Parier qu'un titre monte avec une option, c'est comme acheter un billet de loterie : ça peut rapporter gros, mais le billet est cher. Pour payer moins, tu en vends un deuxième, moins ambitieux, à quelqu'un d'autre. L'argent reçu réduit le prix de ton billet.", "Exemple : tu paries que le titre va passer de 100 $ à 110 $. Tu achètes l'option à 100 $ et tu vends celle à 110 $. Si le titre monte à 110 $ ou plus, tu gagnes le maximum ; au-delà, tu ne gagnes plus rien de plus (c'est le prix de ton rabais).", "Le meilleur côté : le pire qui puisse arriver, c'est de perdre ce que tu as payé au départ. Jamais plus. Le Bear Put, c'est la même idée à l'envers, pour une baisse."],
    },
    nom: 'Debit Spreads (Bull Call / Bear Put)',
    statut: 'disponible',
    resume: "Achat d'un Call ou Put proche du prix et vente d'une option plus loin de la monnaie dans la même direction, pour une anticipation directionnelle forte à risque limité au montant payé.",
    sourceNote: "Source : strategy/PoorManCoveredCall.md.rtf — même fichier que La Roue ci-dessus (elles y étaient décrites comme un seul système de gestion du risque). Séparées en deux stratégies distinctes le 7/9/2026 à la demande de JP.",
    build(ctx) {
      const { ticker, data } = ctx;
      const id = 'debit-spreads';
      const p = ctx.params || laboDefaults(id);
      const S = data?.price ?? null;
      const sigma = data?.historicalVolatility ?? null;
      const r = p.riskFreePct / 100;
      const putDte = Math.round((p.putDteMin + p.putDteMax) / 2);
      const callDte = Math.round((p.callDteMin + p.callDteMax) / 2);
      // Même formule que pour La Roue (jambe vendue au même Delta cible) —
      // ce fichier source ne donne pas de Delta distinct pour un spread,
      // seule la jambe achetée change (« proche du prix », non calculée
      // par Black-Scholes faute de Delta cible propre à cette jambe dans
      // la source).
      const putZone = laboStrikeZone({ S, T: putDte / 365, r, sigma, deltaMin: p.putDeltaMin, deltaMax: p.putDeltaMax, type: 'put', role: 'Put vendu (jambe courte du Bear Put Spread)', dteJours: putDte });
      const callZone = laboStrikeZone({ S, T: callDte / 365, r, sigma, deltaMin: p.callDeltaMin, deltaMax: p.callDeltaMax, type: 'call', role: 'Call vendu (jambe courte du Bull Call Spread)', dteJours: callDte });
      const steps = [
        {
          titre: '1. Sélection du sous-jacent',
          points: [
            `Vérifier que ${laboDyn(ticker)} est une Blue Chip ou un ETF à forte liquidité — pas un titre spéculatif.`,
            data
              ? `Données réelles — Volume du jour : ${laboDyn(data.volume != null ? data.volume.toLocaleString('fr-CA') : '—')} · Beta 5 ans : ${laboDyn(data.beta ?? '—')} · Secteur : ${laboDyn(data.sector ?? '—')}`
              : `Clique « Charger les données en direct » pour voir le volume/beta/secteur réels de ${laboDyn(ticker)}.`,
          ],
        },
        {
          titre: '2. Anticipation haussière forte — Bull Call Spread',
          points: [
            `Acheter un Call proche du prix actuel (${laboDyn(laboFmtPrix(S))}), vendre un Call plus haut, échéance dans ${laboRange(id, 'callDteMin', 'callDteMax', p)} (DTE), Delta cible ${laboRange(id, 'callDeltaMin', 'callDeltaMax', p)} ${laboInfoBtn('delta')}.`,
            `Zone de strike estimée pour la jambe vendue (Black-Scholes, volatilité historique — <a href="#" onclick="return false;">détail plus bas</a>) : ${laboDyn(callZone.texte)}`,
            `Gain plafonné à l'écart entre les deux strikes moins le montant payé (le « débit ») ; risque limité à ce montant payé, jamais plus.`,
          ],
        },
        {
          titre: '3. Anticipation baissière forte — Bear Put Spread',
          points: [
            `Acheter un Put proche du prix actuel (${laboDyn(laboFmtPrix(S))}), vendre un Put plus bas, échéance dans ${laboRange(id, 'putDteMin', 'putDteMax', p)}, Delta cible ${laboRange(id, 'putDeltaMin', 'putDeltaMax', p)} ${laboInfoBtn('delta')}.`,
            `Zone de strike estimée pour la jambe vendue : ${laboDyn(putZone.texte)}`,
            `Assurance baissière à coût réduit par rapport à l'achat d'un Put seul — même plafond/plancher de gain-risque qu'un Bull Call Spread, en miroir.`,
          ],
        },
        {
          titre: '4. Règles de sortie',
          points: [
            `Prise de profit : revendre le spread (ou racheter/revendre chaque jambe) dès ${laboRange(id, 'profitTakeMin', 'profitTakeMax', p)} du profit maximal atteint — ne pas attendre l'expiration.`,
            `Le risque étant déjà limité au montant payé, il n'y a pas de « gestion défensive » à proprement parler comme pour un Put/Call vendu seul — la perte maximale est connue dès l'ouverture.`,
          ],
        },
      ];
      return { steps, legs: [callZone.leg, putZone.leg] };
    },
  },
  {
    id: 'pmcc',
    enClair: {
      quand: ["Tu aimerais faire une Covered Call (vendre des Calls sur 100 actions), mais 100 actions coûtent trop cher.", "Tu es plutôt optimiste sur le titre à long terme, sans t'attendre à une explosion à court terme.", "Tu acceptes de gérer la position régulièrement, chaque mois ou presque."],
      comment: ["Au lieu d'acheter un immeuble complet (100 actions), tu achètes un très long bail dessus (le LEAPS, un Call à échéance lointaine). Ça coûte beaucoup moins cher qu'acheter l'immeuble, et ça se comporte presque pareil quand la valeur change.", "Ensuite, chaque mois, tu sous-loues l'immeuble à quelqu'un d'autre (tu vends un Call court) et tu encaisses le loyer. Si l'immeuble ne monte pas trop, tu gardes le loyer et tu recommences.", "Les risques : si le titre baisse beaucoup, ton bail perd de la valeur aussi. Et un bail qui approche de sa fin s'use de plus en plus vite : il faut le renouveler (le « rouler ») avant."],
    },
    nom: "Poor Man's Covered Call (PMCC)",
    statut: 'disponible',
    resume: "Achat d'un Call à longue échéance (LEAPS), profondément dans la monnaie, comme substitut synthétique aux 100 actions — puis vente répétée de Calls courts contre pour encaisser des primes à chaque cycle.",
    sourceNote: "Définition standard de la stratégie, indépendante du fichier strategy/PoorManCoveredCall.md.rtf (voir la note sur « La Roue & Debit Spreads » ci-dessus).",
    build(ctx) {
      const { ticker, data } = ctx;
      const id = 'pmcc';
      const p = ctx.params || laboDefaults(id);
      const r = p.riskFreePct / 100;
      const S = data?.price ?? null;
      const sigma = data?.historicalVolatility ?? null;
      const callDte = Math.round((p.callDteMin + p.callDteMax) / 2);
      const leapsZone = laboStrikeZone({ S, T: p.leapsDteTypiqueJours / 365, r, sigma, deltaMin: p.leapsDeltaMin, deltaMax: p.leapsDeltaMax, type: 'call', role: 'LEAPS Call acheté', dteJours: p.leapsDteTypiqueJours });
      const callZone = laboStrikeZone({ S, T: callDte / 365, r, sigma, deltaMin: p.callDeltaMin, deltaMax: p.callDeltaMax, type: 'call', role: 'Call court vendu', dteJours: callDte });
      const smaP = data?.smaPeriods || { fast: CFG.indicateurs.smaRapide, medium: CFG.indicateurs.smaMoyenne, slow: CFG.indicateurs.smaLente };
      const steps = [
        {
          titre: '1. Sélection du sous-jacent',
          points: [
            `Même filtre que pour une Covered Call classique : ${laboDyn(ticker)} liquide, tendance de fond haussière ou neutre — pas un titre en chute.`,
            `Alignement SMA ${smaP.fast}/${smaP.medium}/${smaP.slow} ${laboInfoBtn('sma')} : <strong>${laboDyn(data?.smaAlignment ?? '—')}</strong>. ${laboSmaDetail(data)}`,
          ],
        },
        {
          titre: `2. Acheter un Call à longue échéance (${laboInfoBtn('leaps')} LEAPS), profondément dans la monnaie`,
          points: [
            `« LEAPS » = simplement un Call dont l'échéance est longue, PAS un instrument différent — voir le bouton d'aide ci-dessus.`,
            `Échéance longue : au moins ${laboParam(id, 'leapsDteMinJours', p)} avant l'expiration (calcul ci-dessous fait pour une échéance typique de ${laboParam(id, 'leapsDteTypiqueJours', p)}, soit ${laboDyn('≈ ' + (p.leapsDteTypiqueJours / 365).toFixed(1) + ' an')}).`,
            `Delta cible ${laboInfoBtn('delta')} : ${laboRange(id, 'leapsDeltaMin', 'leapsDeltaMax', p)} — profondément dans la monnaie, pour que ce Call bouge presque comme ${laboParam(id, 'contractSize', p)} du titre.`,
            `Strike estimé (Black-Scholes, volatilité historique — détail plus bas) : ${laboDyn(leapsZone.texte)} — à valider avec la vraie chaîne d'options chez ton courtier.`,
            `Coût net généralement inférieur à l'achat de ${laboParam(id, 'contractSize', p)} ${laboDyn(ticker)}, pour une exposition directionnelle comparable.`,
          ],
        },
        {
          titre: '3. Vendre un Call à échéance courte contre ce LEAPS, cycle après cycle',
          points: [
            `Vendre un Call, échéance dans ${laboRange(id, 'callDteMin', 'callDteMax', p)} (DTE), Delta cible ${laboInfoBtn('delta')} ${laboRange(id, 'callDeltaMin', 'callDeltaMax', p)}.`,
            `Zone de strike estimée : ${laboDyn(callZone.texte)}`,
            `Résultat A — le titre reste sous le strike du Call court : il expire sans valeur → profit = prime encaissée, LEAPS conservé → vendre un nouveau Call court le cycle suivant.`,
            `Résultat B — le titre dépasse le strike du Call court : racheter (Buy to Close) avant assignation et rouler à un strike plus haut, ou laisser exercer en livrant les actions via le LEAPS.`,
          ],
        },
        {
          titre: '4. Points de vigilance propres au PMCC',
          points: [
            `Le LEAPS a un Delta ${laboInfoBtn('delta')} inférieur à 1 : il ne réplique pas exactement 100 actions — en cas de forte baisse du titre, la perte est moindre qu'avec des actions, mais elle existe.`,
            `Profit maximal plafonné à (strike du Call court − strike du LEAPS) − le coût net payé pour le LEAPS, plus les primes courtes déjà encaissées.`,
            `Rouler le LEAPS avant qu'il ne reste que ${laboParam(id, 'rouleAvantJours', p)} à l'échéance, pour éviter l'accélération de sa propre décroissance temporelle (thêta).`,
          ],
        },
      ];
      return { steps, legs: [leapsZone.leg, callZone.leg] };
    },
  },
  {
    id: 'iron-condor',
    enClair: {
      quand: ["Tu penses que le titre va rester calme, dans un couloir de prix, pendant les prochaines semaines.", "Aucune grosse nouvelle prévue (pas de résultats trimestriels avant l'échéance)."],
      comment: ["C'est deux paris en même temps : un contre une chute (Bull Put Spread, sous le prix) et un contre une hausse (Bear Call Spread, au-dessus). Tu encaisses de l'argent des deux côtés tout de suite.", "Tant que le titre reste dans le couloir entre les deux, tu gardes tout. S'il sort du couloir d'un côté, tu perds, mais ta perte est limitée, car chaque côté a sa protection. (Pas encore disponible dans le Labo.)"],
    },
    nom: 'Iron Condor',
    statut: 'a-venir',
    resume: "Vente simultanée d'un Bull Put Spread et d'un Bear Call Spread sur un titre jugé stable — encaisse une prime nette si le titre reste dans un canal de prix.",
  },
  {
    id: 'credit-spreads',
    enClair: {
      quand: [
        "Tu penses que le titre ne va PAS descendre sous un certain prix (Bull Put) ou ne va PAS monter au-dessus d'un certain prix (Bear Call). Il n'a pas besoin de bouger beaucoup : il doit juste éviter d'aller dans le mauvais sens.",
        "Tu veux encaisser de l'argent tout de suite et connaître ta perte maximale dès le départ.",
        "Tu n'as pas assez d'argent pour garantir un Put complet (Cash-Secured Put), ou tu ne veux pas posséder les actions."],
      comment: [
        "Imagine que tu vends une assurance : quelqu'un te paie pour que tu le protèges si le titre tombe sous 90 $. Tu encaisses l'argent tout de suite. Le risque : si le titre s'effondre, c'est toi qui paies, et ça peut être énorme.",
        "Pour t'éviter ça, tu achètes toi-même une petite assurance moins chère, à 85 $. C'est comme un assureur qui se réassure. Maintenant, le pire qui puisse arriver, c'est l'écart entre 90 $ et 85 $ (moins l'argent déjà encaissé). C'est ça, un Credit Spread.",
        "Si le titre reste au-dessus de 90 $, tu gardes tout l'argent encaissé : c'est ton gain maximal. Plus l'écart entre les deux prix est large, plus tu encaisses, mais plus ta perte possible est grande.",
        "Bull Put = tu gagnes si ça monte ou stagne. Bear Call = tu gagnes si ça descend ou stagne."],
    },
    nom: 'Credit Spreads (Bull Put / Bear Call)',
    statut: 'disponible',
    resume: "Vente d'un spread crédit directionnel à risque défini, sans détenir le sous-jacent : on encaisse un crédit tout de suite, et la perte maximale est connue dès l'ouverture.",
    sourceNote: "Définition standard de la stratégie, indépendante du fichier strategy/PoorManCoveredCall.md.rtf. Aucune prime réelle n'est connue ici : le crédit minimal est une règle à vérifier dans la vraie chaîne.",
    build(ctx) {
      const { ticker, data } = ctx;
      const id = 'credit-spreads';
      const p = ctx.params || laboDefaults(id);
      const S = data?.price ?? null;
      const sigma = data?.historicalVolatility ?? null;
      const r = p.riskFreePct / 100;
      const putDte = Math.round((p.putDteMin + p.putDteMax) / 2);
      const callDte = Math.round((p.callDteMin + p.callDteMax) / 2);
      const putZone = laboStrikeZone({ S, T: putDte / 365, r, sigma, deltaMin: p.putDeltaMin, deltaMax: p.putDeltaMax, type: 'put', role: 'Put vendu (jambe courte du Bull Put Spread)', dteJours: putDte });
      const callZone = laboStrikeZone({ S, T: callDte / 365, r, sigma, deltaMin: p.callDeltaMin, deltaMax: p.callDeltaMax, type: 'call', role: 'Call vendu (jambe courte du Bear Call Spread)', dteJours: callDte });
      const W = S != null ? S * p.spreadWidthPct / 100 : null;
      const creditMin = W != null ? W * p.creditMinPct / 100 : null;
      const longPut = putZone.basse != null && W != null ? `${laboFmtPrix(putZone.basse - W)} – ${laboFmtPrix(putZone.haute - W)}` : '—';
      const longCall = callZone.basse != null && W != null ? `${laboFmtPrix(callZone.basse + W)} – ${laboFmtPrix(callZone.haute + W)}` : '—';
      const steps = [
        {
          titre: '1. Sélection du sous-jacent',
          points: [
            `Vérifier que ${laboDyn(ticker)} est liquide (options très échangées, écart bid-ask serré) — un spread se ferme à deux jambes, un mauvais écart double le coût.`,
            data
              ? `Données réelles — Volume du jour : ${laboDyn(data.volume != null ? data.volume.toLocaleString('fr-CA') : '—')} · Beta 5 ans : ${laboDyn(data.beta ?? '—')} · Secteur : ${laboDyn(data.sector ?? '—')}`
              : `Clique « Charger les données en direct » pour voir le volume/beta/secteur réels de ${laboDyn(ticker)}.`,
            data && data.daysToEarnings != null
              ? `Résultats trimestriels dans ${laboDyn(data.daysToEarnings + ' j')} — éviter une échéance qui tombe après cette date (le titre peut sauter au-delà du strike).`
              : `Vérifier la date des prochains résultats : éviter une échéance qui tombe après.`,
          ],
        },
        {
          titre: '2. Anticipation haussière ou neutre — Bull Put Spread',
          points: [
            `Vendre un Put proche de la zone suivante et acheter un Put plus bas, échéance dans ${laboRange(id, 'putDteMin', 'putDteMax', p)} (DTE), Delta cible de la jambe vendue ${laboRange(id, 'putDeltaMin', 'putDeltaMax', p)} ${laboInfoBtn('delta')}.`,
            `Zone de strike estimée pour la jambe vendue (Black-Scholes, volatilité historique — détail plus bas) : ${laboDyn(putZone.texte)}`,
            `Jambe achetée (protection) : une largeur de ${laboParam(id, 'spreadWidthPct', p)} du prix${W != null ? ` (≈ ${laboDyn(laboFmtPrix(W))})` : ''} plus bas, soit un strike autour de ${laboDyn(longPut)}.`,
            `Tu gagnes si le titre reste au-dessus du strike vendu à l'échéance.`,
          ],
        },
        {
          titre: '3. Anticipation baissière ou neutre — Bear Call Spread',
          points: [
            `Vendre un Call et acheter un Call plus haut, échéance dans ${laboRange(id, 'callDteMin', 'callDteMax', p)}, Delta cible de la jambe vendue ${laboRange(id, 'callDeltaMin', 'callDeltaMax', p)} ${laboInfoBtn('delta')}.`,
            `Zone de strike estimée pour la jambe vendue : ${laboDyn(callZone.texte)}`,
            `Jambe achetée (protection) : même largeur de ${laboDyn(W != null ? laboFmtPrix(W) : '—')} plus haut, soit un strike autour de ${laboDyn(longCall)}.`,
            `Tu gagnes si le titre reste sous le strike vendu à l'échéance.`,
          ],
        },
        {
          titre: '4. Valider le crédit avant d\'entrer',
          points: [
            `Crédit net exigé : au moins ${laboParam(id, 'creditMinPct', p)} de la largeur${creditMin != null ? ` (≈ ${laboDyn(laboFmtPrix(creditMin))} par action, soit ${laboDyn(laboFmtPrix(creditMin * 100))} par contrat de 100)` : ''}. En dessous, le risque n'est pas payé.`,
            `Gain maximal = le crédit encaissé. Perte maximale = largeur − crédit${creditMin != null ? ` (≈ ${laboDyn(laboFmtPrix(W - creditMin))} par action si le crédit est au minimum)` : ''}. Elle est connue dès l'ouverture.`,
            `Le crédit réel dépend de la vraie chaîne d'options chez ton courtier — cet outil ne connaît aucune prime.`,
          ],
        },
        {
          titre: '5. Règles de sortie',
          points: [
            `Prise de profit : racheter le spread dès ${laboRange(id, 'profitTakeMin', 'profitTakeMax', p)} du crédit encaissé — ne pas attendre l'expiration pour les derniers sous.`,
            `Stop : racheter le spread si la perte atteint ${laboParam(id, 'stopLossMult', p)} le crédit encaissé, plutôt que d'attendre la perte maximale.`,
            `Si le strike vendu est touché avant l'échéance, soit fermer, soit rouler à une échéance plus lointaine pour un nouveau crédit — jamais rouler à perte sans réévaluer.`,
          ],
        },
      ];
      return { steps, legs: [putZone.leg, callZone.leg] };
    },
  },
];
