// Etat partagé entre fichiers du navigateur (audit app-js, 21/10/2026, constats 1 à 5). Ces défauts ne se voient ni par la
// syntaxe ni par une API vide : il faut enchaîner des gestes (Préparer, changer d'onglet, enregistrer) dans une vraie page.
import test from 'node:test';
import assert from 'node:assert/strict';
import { findChrome, withPage, PAGES } from './smoke-browser.mjs';

const chromePath = findChrome();
const skip = chromePath ? false : 'Chrome introuvable (définir CHROME_PATH) : test ignoré, ce n\'est pas un succès';

test('Fiche : « Préparer » garde son titre au retour sur l\'onglet, et un autre titre efface RSI/ATR/OBV de l\'ancien', { skip }, async () => {
  const r = await withPage({ root: PAGES[0].root, authenticated: false, chromePath }, async ({ ev, errors }) => {
    const out = await ev(`(() => {
      const val = (id) => document.getElementById(id).value;
      // Secteurs a évalué AAPL; le Screener prépare NVDA.
      document.getElementById('sec-ticker').value = 'AAPL'; calcSelectionFor('sec');
      lastScreeningRows = [{ ticker: 'NVDA', price: 100, atr: 3, rsi: 55, obvTrend: 'neutre' }];
      prepareTradeFrom('NVDA');
      switchTab('journal'); switchTab('fiche');
      const garde = { ticker: val('ticker'), rsi: val('rsi'), atr: val('atr') };
      // Autre cas : la Fiche porte NVDA, mais une carte Symbole désigne maintenant AMD.
      document.getElementById('sec-ticker').value = 'AMD'; calcSelectionFor('sec');
      switchTab('journal'); switchTab('fiche');
      const change = { ticker: val('ticker'), rsi: val('rsi'), atr: val('atr') };
      // Même symbole des deux côtés : revenir sur l'onglet ne doit rien effacer de ce que la Fiche porte.
      document.getElementById('ticker').value = 'AMD'; document.getElementById('rsi').value = '60';
      switchTab('journal'); switchTab('fiche');
      const meme = { ticker: val('ticker'), rsi: val('rsi') };
      return { garde, change, meme };
    })()`);
    return { ...out, errors: [...errors] };
  });
  assert.deepEqual(r.garde, { ticker: 'NVDA', rsi: '55.0', atr: '3.00' }, 'le titre préparé ne doit pas être remplacé');
  assert.deepEqual(r.change, { ticker: 'AMD', rsi: '', atr: '' }, 'un autre titre ne doit pas hériter de RSI/ATR de NVDA');
  assert.deepEqual(r.meme, { ticker: 'AMD', rsi: '60' }, 'le même symbole ne doit pas effacer RSI/ATR/OBV');
  assert.deepEqual(r.errors, []);
});

test('rafraîchir la watchlist ne change pas la dernière carte Symbole utilisée', { skip }, async () => {
  const apiStub = (method, path) => (path === '/api/watchlist' ? { body: { watchlist: [{ ticker: 'AMD' }] } } : undefined);
  const r = await withPage({ root: PAGES[0].root, authenticated: false, apiStub, chromePath }, async ({ ev }) => ev(`(async () => {
    lastTickerInstance = 'sec';
    await loadWatchlist();
    const apres = lastTickerInstance;
    calcSelectionFor('scr');
    return { apres, actif: lastTickerInstance };
  })()`));
  assert.equal(r.apres, 'sec', 'la watchlist ne doit pas rediriger la Fiche vers un autre titre');
  assert.equal(r.actif, 'scr', 'un geste sur la carte, lui, la désigne bien');
});

test('journal : le contexte préparé est joint une fois, et jamais en édition', { skip }, async () => {
  const apiStub = (method, path) => (path === '/api/trades' && method === 'POST' ? { body: { id: 7 } } : path.startsWith('/api/trades/') && method === 'PUT' ? { body: { id: 3 } } : undefined);
  const r = await withPage({ root: PAGES[0].root, authenticated: false, apiStub, chromePath }, async ({ ev, sleep }) => {
    await ev(`(() => {
      window.__corps = []; const f = window.fetch;
      window.fetch = (u, o) => { if (o && o.body && String(u).startsWith('/api/trades')) window.__corps.push(JSON.parse(o.body)); return f(u, o); };
      const set = (id, v) => { document.getElementById('j-' + id).value = v; };
      const remplir = () => { set('date_entree', '2026-10-01'); set('ticker', 'AMD'); set('prix_entree', '100'); set('taille_position', '10'); set('stop_initial', '95'); };
      window.__remplir = remplir;
      contexteScreeningPrepare = { ticker: 'AMD', setup_score: 3, contexte_score: 2, alignement_a_entree: true, signal_age_a_entree: 4 };
      remplir(); saveTrade();
    })(); 0`);
    await sleep(600);
    await ev(`(() => {
      // Deuxième trade AMD, saisi à la main : plus de contexte.
      window.__remplir(); saveTrade();
    })(); 0`);
    await sleep(600);
    await ev(`(() => {
      contexteScreeningPrepare = { ticker: 'AMD', setup_score: 9, contexte_score: 9, alignement_a_entree: true, signal_age_a_entree: 1 };
      window.__remplir(); editingTradeId = 3; saveTrade();
    })(); 0`);
    await sleep(600);
    return ev('window.__corps');
  });
  assert.equal(r.length, 3, 'trois enregistrements envoyés');
  assert.equal(r[0].setup_score, 3, 'le premier trade reçoit le contexte préparé');
  assert.equal(r[1].setup_score, undefined, 'le trade saisi à la main ne reçoit plus un vieux contexte');
  assert.equal(r[2].setup_score, undefined, 'une modification ne remplace pas les scores d\'entrée');
});

test('Labo : la séquence n\'utilise pas les données d\'un autre symbole', { skip }, async () => {
  const r = await withPage({ root: PAGES[0].root, authenticated: false, chromePath }, async ({ ev }) => ev(`(() => {
    const texte = () => document.getElementById('labo-sequence') ? document.getElementById('labo-sequence').textContent : null;
    const champ = document.getElementById('labo-ticker');
    const donneesAMD = { ticker: 'AMD', price: 12345.67, historicalVolatility: 0.9, beta: 2.2, sector: 'SecteurAMD' };
    champ.value = 'NVDA';
    laboTickerData = null; renderLaboSequence(); const sans = texte();
    laboTickerData = donneesAMD; renderLaboSequence(); const avecAutre = texte();
    champ.value = 'AMD'; renderLaboSequence(); const avecMeme = texte();
    return { sans, avecAutre, avecMeme, existe: sans !== null };
  })()`));
  assert.equal(r.existe, true, 'la séquence du Labo est rendue (élément #labo-sequence)');
  assert.equal(r.avecAutre, r.sans, 'NVDA avec les données d\'AMD doit se rendre comme NVDA sans données');
  assert.notEqual(r.avecMeme, r.avecAutre, 'avec les bonnes données (AMD), la séquence change bien');
});

test('cloud : une session perdue ramène à la connexion, et rien ne tourne avant la connexion', { skip }, async () => {
  const apiStub = (method, path) => (path === '/api/zz' ? { status: 401, body: { error: 'Non authentifié' } } : undefined);
  const connecte = await withPage({ root: PAGES[1].root, authenticated: true, apiStub, chromePath }, async ({ ev, sleep }) => {
    const demarree = await ev('appDemarree');
    await ev(`fetchJSON('/api/zz').catch(() => 0); 0`);
    await sleep(3500); // rechargement puis démarrage
    return { demarree, recharge: await ev(`performance.getEntriesByType('navigation')[0].type`), drapeau: await ev(`!!sessionStorage.getItem('castellana-session-perdue')`) };
  });
  assert.equal(connecte.demarree, true);
  assert.equal(connecte.recharge, 'reload', 'un 401 hors /api/auth/ recharge la page');
  assert.equal(connecte.drapeau, true);
  const ecran = await withPage({ root: PAGES[2].root, authenticated: false, chromePath }, async ({ ev }) => ev('appDemarree'));
  assert.equal(ecran, false, 'sur l\'écran de connexion, l\'application n\'est pas démarrée : les minuteries restent muettes');
});

test('Screener : sans VIX, RSI ou OBV la taille est « N/D » (rien d\'inventé), puis elle apparaît quand le VIX arrive', { skip }, async () => {
  const r = await withPage({ root: PAGES[0].root, authenticated: false, chromePath }, async ({ ev }) => ev(`(() => {
    const ligne = { ticker: 'ZZZ', price: 100, atr: 2, rsi: 55, obvTrend: 'neutre' };
    currentVix = null;
    const sansVix = sizingForCandidate(ligne);
    currentVix = 15;
    const avecVix = sizingForCandidate(ligne);
    const sansRsi = sizingForCandidate({ ...ligne, rsi: null });
    const sansObv = sizingForCandidate({ ...ligne, obvTrend: null });
    currentVix = null;
    const html = screeningRowHTML(ligne, { onclick: 'selectScreeningRow', pairsLabel: 'x' });
    return { sansVix, avecVix: !!avecVix && avecVix.shares > 0, sansRsi, sansObv, nd: (html.match(/>N\\/D</g) || []).length };
  })()`));
  assert.equal(r.sansVix, null, 'sans VIX : pas de taille (avant : VIX de 17 inventé)');
  assert.equal(r.avecVix, true, 'avec les trois données : une taille est calculée');
  assert.equal(r.sansRsi, null);
  assert.equal(r.sansObv, null);
  assert.equal(r.nd, 2, 'les deux cellules (stop et taille) affichent N/D');
});

test('Journal : un prix de sortie saisi avec une virgule est lu en entier', { skip }, async () => {
  const apiStub = (method, path) => (path === '/api/trades/9' && method === 'GET' ? { body: { id: 9, ticker: 'AMD', prix_entree: 10, stop_initial: 9 } } : path === '/api/trades/9' && method === 'PUT' ? { body: { id: 9 } } : undefined);
  const r = await withPage({ root: PAGES[0].root, authenticated: false, apiStub, chromePath }, async ({ ev, sleep }) => {
    await ev(`(() => {
      window.__corps = []; const f = window.fetch;
      window.fetch = (u, o) => { if (o && o.method === 'PUT') window.__corps.push(JSON.parse(o.body)); return f(u, o); };
      window.prompt = () => '12,5'; closeTrade(9);
    })(); 0`);
    await sleep(700);
    return ev('window.__corps');
  });
  assert.equal(r.length, 1);
  assert.equal(r[0].prix_sortie, 12.5, '« 12,5 » vaut 12,5 (avant : 12)');
  assert.equal(r[0].resultat, 'gagnant');
});

test('graphiques : les séries sont alignées par DATE, pas par indice', { skip }, async () => {
  const r = await withPage({ root: PAGES[0].root, authenticated: false, chromePath }, async ({ ev }) => ev(`(() => {
    const pt = (date, pct) => ({ date, pct });
    // A suit le calendrier complet; B manque le 2026-10-02 (jour férié) et ne commence que le 2026-10-02 ... B est donc plus courte.
    const A = { key: 'A', points: [pt('2026-10-01', 0), pt('2026-10-02', 1), pt('2026-10-05', 2), pt('2026-10-06', 3)] };
    const B = { key: 'B', points: [pt('2026-10-02', 0), pt('2026-10-06', 5)] };
    const { axis, aligned } = alignSeriesByDate([A, B]);
    const b = aligned[1];
    return { axis, posB: b.points.map((p) => p.i), idx0: b.byIdx[0] || null, idx2: b.byIdx[2] && b.byIdx[2].pct, idx3: b.byIdx[3] && b.byIdx[3].pct };
  })()`));
  assert.deepEqual(r.axis, ['2026-10-01', '2026-10-02', '2026-10-05', '2026-10-06']);
  assert.deepEqual(r.posB, [1, 3], 'B est placée à ses vraies dates (avant : aux positions 0 et 1)');
  assert.equal(r.idx0, null, 'rien avant son premier point');
  assert.equal(r.idx2, 0, 'le 5 octobre, B garde sa dernière valeur connue');
  assert.equal(r.idx3, 5);
});

test('un stockage local bloqué ne fige pas le démarrage', { skip }, async () => {
  const r = await withPage({ root: PAGES[0].root, authenticated: false, chromePath, overrides: {
    'index.html': (await import('node:fs')).readFileSync(new URL('../index.html', import.meta.url), 'utf8')
      .replace('<head>', '<head><script>Object.defineProperty(window, \'localStorage\', { get() { throw new DOMException(\'bloqué\', \'SecurityError\'); } });</script>'),
  } }, async ({ ev, errors }) => ({ demarree: await ev('appDemarree'), errors: [...errors] }));
  assert.equal(r.demarree, true, 'l\'application démarre malgré un localStorage qui lève une exception');
  assert.deepEqual(r.errors, []);
});

test('graphiques : une série qui commence plus tard est dessinée à ses vraies dates', { skip }, async () => {
  const x0 = await withPage({ root: PAGES[0].root, authenticated: false, chromePath }, async ({ ev }) => ev(`(() => {
    const h = (date, close) => ({ date, close });
    const A = { key: 'A', label: 'A', color: '#f00', lineStyle: 'solid', history: [h('2026-10-01', 100), h('2026-10-02', 101), h('2026-10-05', 102), h('2026-10-06', 103)] };
    const B = { key: 'B', label: 'B', color: '#00f', lineStyle: 'solid', history: [h('2026-10-02', 50), h('2026-10-06', 55)] };
    renderPerfChart({ svgId: 'sector-chart', legendId: 'sector-legend', tooltipId: 'sector-chart-tooltip', series: [A, B], periodDays: 3650, hiddenSet: new Set(), onToggleName: 'toggleSectorSeries' });
    const chemins = [...document.querySelectorAll('#sector-chart path.sector-chart-line')].map((p) => p.getAttribute('d'));
    return +chemins[1].match(/^M ([0-9.]+)/)[1];
  })()`));
  // axe de 4 dates, largeur utile 662 depuis x = 40 : B démarre à la 2e date, soit 40 + 662 / 3
  assert.ok(Math.abs(x0 - (40 + 662 / 3)) < 1, `B doit démarrer à sa vraie date (x = ${x0}, attendu ≈ 260.7)`);
});

// Audit onglets locaux (21/10/2026)
test('analyste IA : une réponse arrivée après un changement de symbole n\'écrase pas la carte du nouveau titre', { skip }, async () => {
  const analyse = (ticker) => ({ ticker, createdAt: '2026-10-21T10:00:00Z', model: 'm', costUsd: 0.01, fromCache: false,
    analysis: { resume: `RESUME-${ticker}`, actualites: [], resultats: 'x', risques: [], contradictions_signal: [], critique_plan: [], non_disponible: [] } });
  const apiStub = (method, path) => {
    if (method === 'POST' && path === '/api/ai/analyse/AMD') return { body: analyse('AMD') };
    if (method === 'GET' && path === '/api/ai/analyse/NVDA') return { body: { analysis: null } };
    return undefined;
  };
  const r = await withPage({ root: PAGES[0].root, authenticated: false, apiStub, chromePath }, async ({ ev, sleep, errors }) => {
    const out = await ev(`(async () => {
      document.getElementById('ticker').value = 'AMD';
      const p = aiAnalyse(false);
      document.getElementById('ticker').value = 'NVDA';   // le symbole change pendant l'attente
      await p;
      const apresChangement = document.getElementById('ai-result').innerHTML;
      document.getElementById('ticker').value = 'AMD';
      await aiAnalyse(false);
      const memeSymbole = document.getElementById('ai-result').innerHTML;
      return { apresChangement, memeSymbole };
    })()`);
    return { ...out, errors: [...errors] };
  });
  assert.ok(!/RESUME-AMD/.test(r.apresChangement), 'la carte de NVDA ne montre pas l\'analyse d\'AMD');
  assert.match(r.memeSymbole, /RESUME-AMD/, 'avec le même symbole, l\'analyse s\'affiche');
  assert.match(r.memeSymbole, /<strong>AMD<\/strong>/, 'le symbole est écrit dans la carte');
  assert.deepEqual(r.errors, []);
});

test('Radar : le nombre d\'erreurs d\'un scan est lu dans erreurs_json', { skip }, async () => {
  const r = await withPage({ root: PAGES[0].root, authenticated: false, chromePath }, async ({ ev }) => ev(`({
    aucune: radarErrorCount({ erreurs_json: '[]' }), deux: radarErrorCount({ erreurs_json: '[{"ticker":"A"},{"ticker":"B"}]' }),
    illisible: radarErrorCount({ erreurs_json: 'pas du json' }), absent: radarErrorCount({}),
  })`));
  assert.deepEqual(r, { aucune: 0, deux: 2, illisible: 0, absent: 0 });
});

test('Réglages : le contrôle des alertes de positions se charge, se coupe et s\'enregistre', { skip }, async () => {
  const apiStub = (method, path) => (path === '/api/app-settings' && method === 'GET'
    ? { body: { sweepAuto: false, publishCloud: false, alertEmails: [], emailsFromEnv: false, emailAvailable: false, resendKeySource: null, profitTakeMin: 60, publish: {},
        positionAlerts: { enabled: true, kinds: { echeance: true, profit: false, stop: true }, email: false } } } : undefined);
  const r = await withPage({ root: PAGES[0].root, authenticated: false, apiStub, chromePath }, async ({ ev, sleep, errors }) => {
    await ev('loadAppSettings(); 0');
    await sleep(500);
    const charge = await ev(`({ enabled: document.getElementById('app-posalerts-enabled').checked, profit: document.getElementById('app-posalerts-profit').checked,
      email: document.getElementById('app-posalerts-email').checked, seuil: document.getElementById('app-posalerts-seuil').textContent,
      detailActif: !document.getElementById('app-posalerts-profit').disabled })`);
    await ev(`(() => { const c = document.getElementById('app-posalerts-enabled'); c.checked = false; c.dispatchEvent(new Event('change')); })(); 0`);
    const coupe = await ev(`({ detailDesactive: document.getElementById('app-posalerts-stop').disabled, envoi: collectPosAlerts() })`);
    return { charge, coupe, errors: [...errors] };
  });
  assert.deepEqual(r.charge, { enabled: true, profit: false, email: false, seuil: '60', detailActif: true }, 'les réglages enregistrés sont affichés, avec le seuil de la Roue');
  assert.equal(r.coupe.detailDesactive, true, 'décocher le principal grise le détail');
  assert.deepEqual(r.coupe.envoi, { enabled: false, kinds: { echeance: true, profit: false, stop: true }, email: false }, 'ce qui part au serveur');
  assert.deepEqual(r.errors, []);
});

// Audit périphérie (22/10/2026)
test('télémétrie : aucun montant du testeur (capital, risque) n\'est suivi, en local comme en cloud', { skip }, async () => {
  for (const page of [PAGES[0], PAGES[1]]) {
    const ids = await withPage({ root: page.root, authenticated: page.authenticated, chromePath }, async ({ ev }) => ev(`TRACKED_PARAMS.map((p) => p.id)`));
    assert.ok(ids.length > 3, 'les autres paramètres restent suivis');
    assert.ok(!ids.includes('capital') && !ids.includes('riskpct'), `${page.label} : capital et risque ne doivent pas partir au Worker`);
  }
});

test('Concepts : l\'assainisseur retire balises et gestionnaires, même sous un lien sans href', { skip }, async () => {
  const r = await withPage({ root: PAGES[0].root, authenticated: false, chromePath }, async ({ ev }) => ev(`(() => {
    const sortie = (h) => conceptSanitizeHtml(h);
    return {
      lienSansHref: sortie('<a><img src=x onerror=alert(1)></a>'),
      lienJavascript: sortie('<a href="javascript:1"><span onclick="x()">t</span></a>'),
      script: sortie('<p>ok</p><script>alert(1)</script>'),
      normal: sortie('<p>Un <strong>mot</strong> et <a href="https://example.com/x">un lien</a></p>'),
    };
  })()`));
  assert.ok(!/onerror|<img/i.test(r.lienSansHref), `sous un lien sans href : ${r.lienSansHref}`);
  assert.ok(!/onclick|javascript:/i.test(r.lienJavascript), `sous un lien javascript: : ${r.lienJavascript}`);
  assert.ok(!/<script|alert/i.test(r.script), `balise script : ${r.script}`);
  assert.match(r.normal, /<strong>mot<\/strong>/);
  assert.match(r.normal, /href="https:\/\/example\.com\/x"/, 'un lien http(s) légitime est conservé');
});

test('Labo : le symbole saisi ne devient pas du HTML dans la séquence', { skip }, async () => {
  const r = await withPage({ root: PAGES[0].root, authenticated: false, chromePath }, async ({ ev }) => ev(`laboDyn('<img src=x onerror=alert(1)>')`));
  assert.ok(!/<img/.test(r), r);
  assert.match(r, /&lt;img/);
});
