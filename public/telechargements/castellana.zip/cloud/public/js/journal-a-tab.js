// js/journal-a-tab.js — onglet « Journal A » (22/9/2026, feature flag
// journal_a_tab, défaut OFF) : suivi de la vente de primes —
//   #8  screener de primes (watchlist / MAG7 / liste perso — jamais
//       « élargi »),
//   #9  IV du contrat retenu vs volatilité HISTORIQUE du titre (pas un
//       vrai « IV rank », Yahoo n'expose pas l'IV passée),
//   #4  calculateur « vendre un put » (ou call), avec enregistrement,
//   #5  cycles de la Roue (jambes liées) + effet de bord Journal actions
//       à l'assignation (voir server/option-trades.js pour le détail),
//   #7  alertes de roulement sur les positions ouvertes.
//
// Réutilise js/options-analytics.js (optAnnualizedYield, optCapitalRequired)
// et la fonction d'échappement optEsc() déjà globale (js/options-common.js).
// Même règle d'honnêteté que partout ailleurs : « — » si non calculable,
// jamais 0 ni un chiffre inventé.

let janlScreenerRows = [];
let janlScreenerMeta = null;
// Côté du screener (4/10/2026) : puts (vente de put, la Roue) ou calls (calls couverts) —
// même mécanisme d'onglets que la chaîne d'options. Chaque côté garde son dernier résultat.
let janlSide = 'put';
const janlSideData = { put: null, call: null };
let janlCustomLists = [];

function janlContractSize() {
  const p = typeof laboEffectiveParams === 'function' ? laboEffectiveParams('roue', (typeof laboParamOverrides !== 'undefined' ? laboParamOverrides.roue : {})) : null;
  return p ? p.contractSize : 100;
}

function janlFmtPct(v, d = 1) { return v == null ? '—' : v.toFixed(d) + ' %'; }
function janlFmtMoney(v) { return v == null ? '—' : v.toLocaleString('fr-CA', { maximumFractionDigits: 0 }) + ' $'; }

// ---- Rendu de la page ----

function janlShellHTML() {
  return `
    <div class="ds-card">
      <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:1rem;">
        <div class="section-title" style="margin-bottom:0;">Screener de primes <span class="ds-text-hint" style="font-weight:400;">(#8)</span></div>
        <button type="button" class="ds-btn ds-btn--pulse expand-btn" onclick="openTableOverlay('janl-screener-content','janl-screener-anchor','Screener de primes')" title="Agrandir le tableau en plein écran">⤢ Agrandir</button>
      </div>
      <p class="metric-sub" style="text-align:left;">Pour chaque titre de l'univers choisi, le meilleur put (onglet Puts) ou call couvert (onglet Calls) selon le mode de choix, sur une échéance dans la fenêtre DTE. Jamais 219 chaînes d'options à la volée : l'univers élargi (local seulement) relit le dernier scan hebdo du Radar, avec les échéances de 5 à 10 jours.</p>
      <div class="field-grid">
        <div class="field span-2"><label for="janl-universe">Univers</label><select id="janl-universe" class="ds-select"><option value="watchlist">Ma watchlist</option><option value="mag7">MAG7</option></select></div>
        <div class="field span-2" title="Éloigné : pour chaque titre, le put le plus loin du prix dont le bid respecte encore la règle de prime (moins de risque d'assignation). Rendement : le put au meilleur rendement annualisé dans la plage de delta (favorise les strikes proches du prix)."><label for="janl-pick-mode">Choix du put</label><select id="janl-pick-mode" class="ds-select"><option value="limite" selected>Le plus éloigné qui respecte la règle</option><option value="rendement">Meilleur rendement annualisé</option></select></div>
        <div class="field"><label for="janl-delta-min">Delta min <span id="janl-delta-min-note" class="ds-text-hint"></span></label><input type="number" id="janl-delta-min" class="ds-input" min="0.01" max="0.99" step="0.01" value="0.15"></div>
        <div class="field"><label for="janl-delta-max" title="En mode « éloigné », plafond de risque : on ne retient jamais un put au delta plus élevé.">Delta max</label><input type="number" id="janl-delta-max" class="ds-input" min="0.01" max="0.99" step="0.01" value="0.25"></div>
        <div class="field"><label for="janl-dte-min">DTE min</label><input type="number" id="janl-dte-min" class="ds-input" min="1" step="1" value="5"></div>
        <div class="field"><label for="janl-dte-max">DTE max</label><input type="number" id="janl-dte-max" class="ds-input" min="1" step="1" value="10"></div>
        <div class="field" title="Prime minimale exigée sur le bid, en % du strike — partagée avec la chaîne de l'onglet Options"><label for="janl-rule-pct">Règle de prime — %</label><input type="number" id="janl-rule-pct" class="ds-input" min="0.1" max="10" step="0.1" value="0.5"></div>
        <div class="field" title="Le % est exigé par tranche de ce nombre de jours, proportionnellement à l'échéance"><label for="janl-rule-days">…par tranche (jours)</label><input type="number" id="janl-rule-days" class="ds-input" min="1" max="60" step="1" value="5"></div>
        <div class="field span-2"><label for="janl-rule-hide" style="width:auto;"><input type="checkbox" id="janl-rule-hide"> Masquer ce qui ne respecte pas la règle</label></div>
      </div>
      <div class="row">
        <button type="button" class="ds-btn ds-btn--primary" id="janl-screener-run">Lancer le screener</button>
      </div>
      <div id="janl-screener-anchor"></div>
      <div id="janl-screener-content">
        <div class="univers-switch" id="janl-side" role="group" aria-label="Côté du screener" style="margin-bottom:var(--ds-space-3);">
          <button type="button" class="ds-btn" data-side="call">Calls</button>
          <button type="button" class="ds-btn is-active" data-side="put">Puts</button>
        </div>
        <p class="hint" id="janl-screener-status"></p>
        <div id="janl-screener-host"><p class="ds-text-muted">Lance le screener pour voir les résultats.</p></div>
      </div>
    </div>

    <div class="ds-card">
      <div class="section-title">Calculateur « Vendre une option » <span class="ds-text-hint" style="font-weight:400;">(#4)</span></div>
      <p class="ds-text-hint roue-etat" style="text-align:left; color:var(--accent);">Améliorée : la commission est enregistrée avec la position, qui apparaît dans l'onglet Roue (journal des positions, H5).</p>
      <p class="metric-sub" style="text-align:left;">Saisis les termes d'un put (ou call) vendu — ou clique une ligne du screener ci-dessus. « Enregistrer » crée la position dans le Journal (onglet Cycles ci-dessous).</p>
      <div class="field-grid">
        <div class="field"><label>Symbole</label><input type="text" id="janl-calc-ticker" class="ds-input" placeholder="ex. AAPL" style="text-transform:uppercase;"></div>
        <div class="field"><label>Type</label><select id="janl-calc-type" class="ds-select"><option value="put">Put vendu</option><option value="call">Call vendu</option></select></div>
        <div class="field"><label>Compte</label><select id="janl-calc-compte" class="ds-select"><option value="margin">margin (non-enreg.)</option><option value="RRSP">RRSP (REER)</option><option value="corporatif">corporatif</option></select></div>
        <div class="field"><label>Contrats</label><input type="number" id="janl-calc-contrats" class="ds-input" min="1" step="1" value="1"></div>
        <div class="field"><label>Strike</label><input type="number" id="janl-calc-strike" class="ds-input" step="0.01" min="0"></div>
        <div class="field"><label title="Prime reçue (par action)">Prime reçue</label><input type="number" id="janl-calc-prime" class="ds-input" step="0.01" min="0"></div>
        <div class="field"><label>Échéance</label><input type="date" id="janl-calc-echeance" class="ds-input"></div>
        <div class="field"><label>Date d'ouverture</label><input type="date" id="janl-calc-date-ouverture" class="ds-input"></div>
        <div class="field"><label title="Commission du courtier à l'ouverture, en $ (facultatif)">Commission ($)</label><input type="number" id="janl-calc-commission" class="ds-input" step="0.01" min="0"></div>
        <div class="field span-2"><label for="janl-calc-cycle">Cycle</label><select id="janl-calc-cycle" class="ds-select"><option value="">— position autonome, pas de cycle —</option><option value="__new__">+ Nouveau cycle</option></select></div>
        <div class="field span-2 field-actions"><button type="button" class="ds-btn" id="janl-calc-compute">Calculer</button><button type="button" class="ds-btn ds-btn--primary" id="janl-calc-save">Enregistrer</button></div>
      </div>
      <span class="hint" id="janl-calc-status"></span>
      <div class="metric-band" style="--cols:3; margin-top:0.5rem;">
        <div><span class="mb-label">Capital requis</span><span class="mb-value" id="janl-calc-capital">—</span></div>
        <div><span class="mb-label">Rendement annualisé</span><span class="mb-value" id="janl-calc-yield">—</span></div>
        <div><span class="mb-label">Seuil de rentabilité (breakeven)</span><span class="mb-value" id="janl-calc-breakeven">—</span></div>
      </div>
    </div>

    <div class="ds-card">
      <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:0.5rem;">
        <div class="section-title" style="margin-bottom:0;">Alertes de roulement <span class="ds-text-hint" style="font-weight:400;">(#7)</span></div>
        <button type="button" class="ds-btn" id="janl-alerts-refresh">Actualiser</button>
      </div>
      <p class="metric-sub" style="text-align:left;">Positions ouvertes qui méritent un coup d'œil aujourd'hui — échéance proche, seuil de prise de profit atteint, ou position qu'on ne peut plus évaluer.</p>
      <div id="janl-alerts-host"><p class="ds-text-muted">Chargement…</p></div>
    </div>

    <!-- Alertes de positions poussées (#379) — LOCAL seulement : la carte se masque si la route n'existe pas (cloud). -->
    <div class="ds-card" id="janl-pa-card" style="display:none;">
      <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:0.5rem;">
        <div class="section-title" style="margin-bottom:0;">Alertes de positions <span class="ds-text-hint" style="font-weight:400;">(#379)</span> <span class="ds-text-muted" id="janl-pa-unread"></span></div>
        <span><button type="button" class="ds-btn" id="janl-pa-run">Évaluer maintenant</button> <button type="button" class="ds-btn ds-btn--sm" id="janl-pa-read">Tout marquer comme lu</button></span>
      </div>
      <p class="metric-sub" style="text-align:left;">Surveille en arrière-plan les positions ouvertes et te prévient <strong>au changement de situation</strong> : jambe d'option à ≤ 7 jours de l'échéance, seuil de prise de profit atteint, stop d'une action touché. La première observation d'une position n'alerte pas.</p>
      <p class="metric-sub" id="janl-pa-msg" style="text-align:left;"></p>
      <p class="metric-sub" id="janl-pa-info" style="text-align:left;"></p>
      <div id="janl-pa-events"></div>
    </div>

    <div class="ds-card">
      <div class="section-title">Cycles & positions ouvertes <span class="ds-text-hint" style="font-weight:400;">(#5)</span></div>
      <p class="ds-text-hint roue-etat" style="text-align:left; color:var(--amber);">Visée pour suppression : remplacée par l'onglet Roue, journal des positions (H5, avec commissions et roulement lié) et positions de la Roue (H6). Décision à prendre : feature bilbao #439.</p>
      <p class="metric-sub" style="text-align:left;">Un cycle regroupe les jambes d'une Roue sur un titre (put vendu → assigné → call couvert → assigné...). Marquer un put « assigné » crée automatiquement une ligne dans le Journal actions ; marquer un call vendu du même cycle « assigné » la clôture automatiquement.</p>
      <div id="janl-cycles-host"><p class="ds-text-muted">Chargement…</p></div>
    </div>
  `;
}

async function renderJournalATab() {
  const host = document.getElementById('janl-content');
  host.innerHTML = janlShellHTML();
  if (typeof uiIdsNumber === 'function') uiIdsNumber(); // cartes injectées après initUiIds()
  document.getElementById('janl-calc-date-ouverture').value = new Date().toISOString().slice(0, 10);
  await janlLoadCustomLists();
  // Univers élargi : LOCAL seulement (relit le dernier scan hebdo du Radar). En cloud
  // window.CASTELLANA_USERNAME est défini et l'option n'est pas proposée.
  if (typeof window.CASTELLANA_USERNAME === 'undefined') {
    const opt = document.createElement('option');
    opt.value = 'elargi';
    opt.textContent = 'Univers élargi (scan hebdo du Radar)';
    document.getElementById('janl-universe').appendChild(opt);
  }
  // S&P 500 (7/10/2026) : LOCAL seulement — le balayage de ~500 chaînes d'options ne peut pas
  // tourner sur Cloudflare. Toujours listé, mais NON sélectionnable (grisé) hors local.
  {
    const local = typeof window.CASTELLANA_USERNAME === 'undefined';
    const opt = document.createElement('option');
    opt.value = 'sp500';
    opt.textContent = local ? 'S&P 500 (scan hebdo local)' : 'S&P 500 (local seulement)';
    opt.disabled = !local;
    document.getElementById('janl-universe').appendChild(opt);
  }
  document.getElementById('janl-screener-run').addEventListener('click', janlRunScreener);
  document.getElementById('janl-side').addEventListener('click', (e) => {
    const b = e.target.closest('button[data-side]');
    if (!b || b.dataset.side === janlSide) return;
    janlSide = b.dataset.side;
    const d = janlSideData[janlSide];
    if (d) { janlScreenerRows = d.rows; janlScreenerMeta = d.meta; janlRenderScreener(); return; }
    // Pas encore de résultat pour ce côté : on le calcule tout de suite si l'autre côté l'a déjà été.
    janlScreenerRows = []; janlScreenerMeta = null;
    document.querySelectorAll('#janl-side button').forEach((x) => x.classList.toggle('is-active', x.dataset.side === janlSide));
    document.getElementById('janl-screener-host').innerHTML = '<p class="ds-text-muted">Chargement…</p>';
    if (janlSideData.put || janlSideData.call) janlRunScreener();
    else { document.getElementById('janl-screener-host').innerHTML = '<p class="ds-text-muted">Lance le screener pour voir les résultats.</p>'; document.getElementById('janl-screener-status').textContent = ''; }
  });
  const syncPickMode = () => {
    const lim = document.getElementById('janl-pick-mode').value === 'limite';
    document.getElementById('janl-delta-min').disabled = lim;
    document.getElementById('janl-delta-min-note').textContent = lim ? '(ignoré)' : '';
  };
  document.getElementById('janl-pick-mode').addEventListener('change', syncPickMode);
  syncPickMode();
  optaLoadRule(); // reprend la règle mémorisée (partagée avec la chaîne)
  ['janl-rule-pct', 'janl-rule-days', 'janl-rule-hide'].forEach((id) =>
    document.getElementById(id).addEventListener('input', () => { optaSyncRuleInputs('janl'); }));
  document.getElementById('janl-calc-compute').addEventListener('click', janlComputeCalculator);
  document.getElementById('janl-calc-save').addEventListener('click', janlSaveToJournal);
  document.getElementById('janl-calc-ticker').addEventListener('change', janlRefreshCycleOptions);
  document.getElementById('janl-alerts-refresh').addEventListener('click', janlLoadAlerts);
  document.getElementById('janl-pa-run').addEventListener('click', janlRunPositionAlerts);
  document.getElementById('janl-pa-read').addEventListener('click', async () => { await fetchJSON('/api/position-alerts/read', { method: 'POST' }); janlLoadPositionAlerts(); });
  janlLoadPositionAlerts();
  janlLoadAlerts();
  janlLoadCycles();
}

// ---- Screener (#8/#9) ----

async function janlLoadCustomLists() {
  try {
    const { lists } = await fetchJSON('/api/lists');
    janlCustomLists = lists || [];
    const sel = document.getElementById('janl-universe');
    for (const l of janlCustomLists) {
      const opt = document.createElement('option');
      opt.value = `list:${l.id}`;
      opt.textContent = l.nom;
      sel.appendChild(opt);
    }
  } catch { /* pas de listes personnalisées disponibles — sans conséquence */ }
}

// Règle de prime minimale (0,5 % / 5 j par défaut) : mêmes valeurs que la chaîne
// de l'onglet Options (clé localStorage partagée, champs synchronisés par
// optaSyncRuleInputs). Le put du screener est hors la monnaie par construction
// (delta 0,15-0,25) : on compare le bid, sans retrancher d'intrinsèque.
function janlRule() {
  const num = (id, def) => { const v = parseFloat(document.getElementById(id).value); return v > 0 ? v : def; };
  return { pct: num('janl-rule-pct', OPTA_RULE_DEFAULT.pct), days: num('janl-rule-days', OPTA_RULE_DEFAULT.days), hide: document.getElementById('janl-rule-hide').checked };
}

function janlRenderScreener() {
  const status = document.getElementById('janl-screener-status');
  const host = document.getElementById('janl-screener-host');
  if (!janlScreenerMeta) return;
  const rule = janlRule();
  const verdicts = janlScreenerRows.map((r) => optPremiumRule(janlSide, r.price ?? null, r.strike, r.premium, r.dte, rule.pct, rule.days));
  const nOk = verdicts.filter((v) => v && v.ok).length;
  const shown = janlScreenerRows.map((r, i) => i).filter((i) => !rule.hide || (verdicts[i] && verdicts[i].ok));
  const stale = janlScreenerMeta.mode === 'limite' && (rule.pct !== janlScreenerMeta.ruleAtRun.pct || rule.days !== janlScreenerMeta.ruleAtRun.days);
  document.querySelectorAll('#janl-side button').forEach((b) => { b.classList.toggle('is-active', b.dataset.side === janlSide); const d = janlSideData[b.dataset.side]; b.textContent = `${b.dataset.side === 'put' ? 'Puts' : 'Calls'}${d ? ` (${d.rows.length})` : ''}`; });
  const noLimit = janlScreenerMeta.mode === 'limite' ? verdicts.filter((v) => v && !v.ok).length : 0;
  const sc = janlScreenerMeta.scan;
  const scanTxt = sc ? ` · scan hebdo du ${new Date(sc.startedAt.replace(' ', 'T') + 'Z').toLocaleString('fr-CA')}${sc.sansHebdo ? ` (${sc.sansHebdo} titres sans hebdo ignorés)` : ''}${sc.sansPrix ? ` — ${sc.sansPrix} contrats ignorés faute du prix du titre (scan ancien : relance un scan hebdo)` : ''} — prix de la prime figés à ce moment, relance le scan pour rafraîchir` : '';
  status.textContent = `${janlScreenerRows.length} résultat(s) sur ${janlScreenerMeta.total} titre(s) — ${janlScreenerMeta.skipped} ignoré(s) · ${nOk} respectent la règle ${rule.pct} % / ${rule.days} j${rule.hide ? ` (${shown.length} affiché(s))` : ''}${scanTxt}.${janlScreenerMeta.mode === 'limite' ? ` Mode « éloigné » : strike limite de la règle, trié par marge en σ${noLimit ? ` — ${noLimit} titre(s) n'atteignent pas la règle sous le delta max : affichés en grisé avec leur prime réelle (le ${janlSide === 'put' ? 'put' : 'call'} au plus gros delta permis)` : ''}.` : ''}${stale ? ' ⚠ Règle modifiée depuis le calcul : relance le screener pour recalculer le strike limite.' : ''}`;
  const sty = tsGet('g2');
  host.innerHTML = shown.length
    ? `${tsLegend('g2', sty)}<div style="overflow-x:auto"><table class="ds-table opt-table tsx tsx${sty}">
        <thead><tr><th>Symbole</th><th>Échéance${optInfoBtn('optExpiry')}</th><th class="is-num">DTE${optInfoBtn('optDte')}</th><th class="is-num">Strike${optInfoBtn('optStrike')}</th><th class="is-num" title="Distance du strike au prix, en % du prix">Dist. <button type="button" class="info-btn" onclick="showGlossaire('marge', this)" title="Aide">i</button></th><th class="is-num" title="Distance en écarts-types du mouvement attendu (IV × √DTE) — comparable d'un titre à l'autre">Marge σ${optInfoBtn('marge')}</th><th title="Position du strike par rapport à la plage de l'expected move (IV à la monnaie × √DTE × multiple de σ, réglable dans l'onglet Options). « hors EM » = strike au-delà de la plage, ce qu'on cherche à vendre ; « dans EM » = à l'intérieur, à éviter. — = IV à la monnaie indisponible (scan du Radar sans cette donnée).">Vs EM</th><th class="is-num" title="Delta estimé (≈ probabilité d'assignation)">Δ${optInfoBtn('delta')}</th><th class="is-num">Prime (bid)${optInfoBtn('optBid')}</th><th class="is-num" title="Prime (bid) ÷ strike, avec entre parenthèses le seuil de la règle pour cette échéance. Ex. « 0,45 % / 0,50 % » : on est à 90 % du but.">Prime / strike (seuil)${optInfoBtn('optPremPct')}</th><th class="is-num" title="prime ÷ seuil de la règle (≥ 1× = respectée)">Règle${optInfoBtn('optRuleRatio')}</th><th class="is-num">Rend. ann.${optInfoBtn('optYield')}</th><th class="is-num">IV <button type="button" class="info-btn" onclick="showGlossaire('iv', this)" title="Aide">i</button></th><th class="is-num">Vol. hist. <button type="button" class="info-btn" onclick="showGlossaire('volHist', this)" title="Aide">i</button></th><th class="is-num" title="Jours avant la prochaine publication de résultats trimestriels. ⚠ = les résultats tombent AVANT l'échéance du contrat : le titre peut gapper contre toi pendant la vie de la position.">Résultats (j)${optInfoBtn('optEarnings')}</th></tr></thead>
        <tbody>${shown.map((i) => { const r = janlScreenerRows[i]; const v = verdicts[i]; const ok = !!(v && v.ok);
          const warn = r.daysToEarnings != null && r.daysToEarnings <= r.dte;
          const tip = v ? ` title="seuil ${v.required.toFixed(2)} $ (${v.requiredPct.toFixed(2)} % du strike à ${r.dte} j) — ${v.ok ? 'respectée' : 'non respectée'}"` : '';
          const rowCls = sty === '4' ? (warn ? 'warn' : ok ? 'ok' : 'under') : sty === '2' ? 'otm' : (v && !v.ok ? 'janl-under-rule' : '');
          const pctTxt = r.premium > 0 && r.strike > 0 ? (r.premium / r.strike * 100).toFixed(2).replace('.', ',') + ' %' : '—';
          const good = ok && (sty === '2' || sty === '5') ? ' good' : '';
          const premPctCell = sty === '1' ? `<td class="is-num prem"${tip}>${tsGauge(v ? v.ratio : null, pctTxt)}${v ? ` <span class="ds-text-hint">/ ${v.requiredPct.toFixed(2).replace('.', ',')} %</span>` : ''}</td>`
            : sty === '3' ? `<td class="is-num"${tip}><span class="ts-dot${ok ? ' ok' : ''}"></span>${pctTxt}${v ? ` <span class="ds-text-hint">/ ${v.requiredPct.toFixed(2).replace('.', ',')} %</span>` : ''}</td>`
            : `<td class="is-num${good}"${tip}>${pctTxt}${sty === '2' && ok ? ' ✓' : ''}${v ? ` <span class="ds-text-hint">/ ${v.requiredPct.toFixed(2).replace('.', ',')} %</span>` : ''}</td>`;
          const yTxt = `${r.annualizedYield.toFixed(1)} %`;
          const yCell = sty === '3' ? `<td class="is-num heat" style="${tsHeat(r.annualizedYield / 60)}">${yTxt}</td>` : `<td class="is-num${good}">${yTxt}</td>`;
          const sigTxt = r.sigmaMargin == null ? '—' : r.sigmaMargin.toFixed(1).replace('.', ',') + 'σ';
          const sigCell = sty === '5' ? `<td class="is-num">${sigTxt} ${tsSigmaSvg(r.strike, r.price, r.iv, r.dte, ok)}</td>` : sty === '3' ? `<td class="is-num heat" style="${tsHeat(r.sigmaMargin == null ? null : Math.max(0, r.sigmaMargin) / 2)}">${sigTxt}</td>` : `<td class="is-num">${sigTxt}</td>`;
          const emMove = typeof optExpectedMove === 'function' && typeof optaEmMult === 'function' ? optExpectedMove(r.price, r.atmIv, r.dte, optaEmMult()) : null;
          const emCell = (typeof optaEmBadge === 'function' ? optaEmBadge(janlSide, r.strike, emMove).trim() : '') || '—';
          const tag = sty === '4' && warn ? `<span class="ts-tag ts-tag-w">résultats ${r.daysToEarnings} j</span>` : '';
          const earnStyle = warn && sty !== '4' ? ' style="color:var(--amber);font-weight:600;" title="résultats avant l\'échéance"' : '';
          return `<tr class="janl-screener-row ${rowCls}" onclick="janlUseScreenerRow(${i})" title="${v && !v.ok ? 'Sous la règle — clique pour remplir le calculateur' : 'Clique pour remplir le calculateur'}">
          <td><b>${optEsc(r.ticker)}</b>${tag}</td><td>${optEsc(r.expiry)}</td><td class="is-num">${r.dte}</td><td class="is-num"><strong>${optNum(r.strike)}</strong></td>
          <td class="is-num">${r.distancePct == null ? '—' : r.distancePct.toFixed(1).replace('.', ',') + ' %'}</td>${sigCell}<td>${emCell}</td><td class="is-num">${r.delta == null ? '—' : Math.abs(r.delta).toFixed(2)}</td>
          <td class="is-num">${optNum(r.premium)}</td>
          ${premPctCell}
          <td class="is-num${good}"${tip}>${v ? v.ratio.toFixed(2) + '×' : '—'}</td>
          ${yCell}<td class="is-num">${r.iv == null ? '—' : (r.iv * 100).toFixed(0) + ' %'}</td><td class="is-num">${r.historicalVolatility == null ? '—' : (r.historicalVolatility * 100).toFixed(0) + ' %'}</td>
          <td class="is-num"${earnStyle}>${r.daysToEarnings == null ? '—' : (warn ? '⚠ ' : '') + r.daysToEarnings}</td>
        </tr>`; }).join('')}</tbody>
      </table></div>`
    : `<p class="ds-text-muted">${janlScreenerRows.length ? 'Aucun résultat ne respecte la règle de prime — décoche « Masquer » ou assouplis le % / les jours.' : 'Aucun résultat dans cette plage de delta/DTE.'}</p>`;
}

async function janlRunScreener() {
  const side = janlSide; // l'utilisateur peut changer d'onglet pendant l'attente
  const status = document.getElementById('janl-screener-status');
  const host = document.getElementById('janl-screener-host');
  const universe = document.getElementById('janl-universe').value;
  const qs = new URLSearchParams({
    universe,
    deltaMin: document.getElementById('janl-delta-min').value || 0.15,
    deltaMax: document.getElementById('janl-delta-max').value || 0.25,
    dteMin: document.getElementById('janl-dte-min').value || 5,
    dteMax: document.getElementById('janl-dte-max').value || 10,
    mode: document.getElementById('janl-pick-mode').value,
    rulePct: janlRule().pct,
    ruleDays: janlRule().days,
    type: janlSide,
  });
  status.textContent = (universe === 'elargi' || universe === 'sp500') ? 'Lecture du dernier scan hebdo du Radar…' : 'Screening en cours (peut prendre plusieurs secondes)…';
  host.innerHTML = '';
  try {
    const data = await fetchJSON(`/api/options/premium-screener?${qs}`);
    const meta = { total: data.total, skipped: data.skipped.length, skippedList: data.skipped, scan: data.scan || null, mode: data.mode || 'rendement', ruleAtRun: { pct: janlRule().pct, days: janlRule().days } };
    janlSideData[side] = { rows: data.rows, meta };
    if (janlSide === side) { janlScreenerRows = data.rows; janlScreenerMeta = meta; }
    janlRenderScreener();
  } catch (err) {
    if ((universe === 'elargi' || universe === 'sp500') && /Aucun scan hebdo/.test(err.message)) {
      status.textContent = '';
      const quoi = universe === 'sp500' ? 'les 503 titres du S&P 500' : 'les 219 titres de l\'univers élargi';
      const duree = universe === 'sp500' ? 'quelques minutes' : 'environ une minute';
      host.innerHTML = `<p class="ds-text-muted">Aucun scan hebdo du Radar pour l'instant. Le scan balaie ${quoi} (échéances de 5 à 10 jours) en ${duree} ; les titres sans options hebdomadaires sont mémorisés et ignorés aux scans suivants.</p>
        <button type="button" class="ds-btn ds-btn--primary" onclick="janlStartWeeklyScan()">Lancer le scan hebdo maintenant</button>`;
      return;
    }
    status.textContent = 'Échec : ' + err.message;
  }
}

// Lance un scan hebdo du Radar depuis G2 puis relance le screener quand il est terminé.
async function janlStartWeeklyScan() {
  const status = document.getElementById('janl-screener-status');
  const host = document.getElementById('janl-screener-host');
  try {
    const { scanId } = await fetchJSON('/api/deal-scanner/start', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ fenetre: 'hebdo', univers: document.getElementById('janl-universe').value === 'sp500' ? 'sp500' : 'elargi' }) });
    host.innerHTML = '';
    const poll = async () => {
      const scan = await fetchJSON(`/api/deal-scanner/status?scanId=${scanId}`);
      if (scan.statut === 'en_cours') {
        status.textContent = `Scan hebdo en cours : ${scan.tickers_scannes} / ${scan.total_tickers} titres…`;
        setTimeout(() => poll().catch((e) => { status.textContent = 'Suivi interrompu : ' + e.message; }), 1500);
      } else {
        janlRunScreener();
      }
    };
    await poll();
  } catch (err) {
    status.textContent = 'Échec du scan : ' + err.message + (/déjà en cours/.test(err.message) ? ' — réessaie dans un instant.' : '');
  }
}

function janlUseScreenerRow(i) {
  const r = janlScreenerRows[i];
  if (!r) return;
  document.getElementById('janl-calc-ticker').value = r.ticker;
  document.getElementById('janl-calc-type').value = janlSide;
  document.getElementById('janl-calc-strike').value = r.strike;
  document.getElementById('janl-calc-prime').value = r.premium;
  document.getElementById('janl-calc-echeance').value = r.expiry;
  janlComputeCalculator();
  janlRefreshCycleOptions();
  document.getElementById('janl-calc-ticker').scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// ---- Calculateur (#4) ----

function janlComputeCalculator() {
  const strike = parseFloat(document.getElementById('janl-calc-strike').value);
  const prime = parseFloat(document.getElementById('janl-calc-prime').value);
  const echeance = document.getElementById('janl-calc-echeance').value;
  const contrats = parseInt(document.getElementById('janl-calc-contrats').value, 10) || 1;
  const type = document.getElementById('janl-calc-type').value;
  const dte = echeance ? Math.max(1, Math.ceil((new Date(`${echeance}T00:00:00Z`).getTime() - Date.now()) / 86400000)) : null;

  const capital = optCapitalRequired(strike, janlContractSize(), contrats);
  const yieldPct = optAnnualizedYield(prime, strike, dte);
  const breakeven = Number.isFinite(strike) && Number.isFinite(prime) ? (type === 'put' ? strike - prime : strike + prime) : null;

  document.getElementById('janl-calc-capital').textContent = janlFmtMoney(capital);
  document.getElementById('janl-calc-yield').textContent = janlFmtPct(yieldPct);
  document.getElementById('janl-calc-breakeven').textContent = breakeven == null ? '—' : optNum(breakeven);
}

async function janlRefreshCycleOptions() {
  const ticker = document.getElementById('janl-calc-ticker').value.trim().toUpperCase();
  const sel = document.getElementById('janl-calc-cycle');
  sel.innerHTML = '<option value="">— position autonome, pas de cycle —</option><option value="__new__">+ Nouveau cycle</option>';
  if (!ticker) return;
  try {
    const { cycles } = await fetchJSON('/api/option-cycles');
    for (const c of cycles.filter((c) => c.ticker === ticker && c.statut === 'actif')) {
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = `Cycle #${c.id} — ${c.legs.length} jambe(s), ${janlFmtMoney(c.primeTotale)} encaissés`;
      sel.appendChild(opt);
    }
  } catch { /* liste de cycles indisponible — le champ reste utilisable en mode autonome */ }
}

async function janlSaveToJournal() {
  const status = document.getElementById('janl-calc-status');
  const ticker = document.getElementById('janl-calc-ticker').value.trim().toUpperCase();
  const type = document.getElementById('janl-calc-type').value;
  const compte = document.getElementById('janl-calc-compte').value;
  const contrats = parseInt(document.getElementById('janl-calc-contrats').value, 10) || 1;
  const strike = parseFloat(document.getElementById('janl-calc-strike').value);
  const prime_recue = parseFloat(document.getElementById('janl-calc-prime').value);
  const echeance = document.getElementById('janl-calc-echeance').value;
  const date_ouverture = document.getElementById('janl-calc-date-ouverture').value;
  const commissionRaw = document.getElementById('janl-calc-commission').value;
  const commission_ouverture = commissionRaw === '' ? null : parseFloat(commissionRaw); // vide = non renseignée, jamais 0
  let cycleSel = document.getElementById('janl-calc-cycle').value;

  if (!ticker || !echeance || !date_ouverture || !Number.isFinite(strike) || !Number.isFinite(prime_recue)) {
    status.textContent = 'Symbole, strike, prime, échéance et date d\'ouverture sont requis.';
    return;
  }
  status.textContent = 'Enregistrement…';
  try {
    let cycleId = null;
    if (cycleSel === '__new__') {
      const cycle = await fetchJSON('/api/option-cycles', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ticker, compte, notes: '' }) });
      cycleId = cycle.id;
    } else if (cycleSel) {
      cycleId = Number(cycleSel);
    }
    await fetchJSON('/api/option-trades', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cycle_id: cycleId, type, ticker, compte, strike, echeance, contrats, prime_recue, date_ouverture, commission_ouverture }),
    });
    status.textContent = '✓ Position enregistrée.';
    janlLoadCycles();
    janlLoadAlerts();
    if (typeof roueRefresh === 'function' && document.getElementById('roue-legs-host')) roueRefresh();
  } catch (err) {
    status.textContent = 'Échec : ' + err.message;
  }
}

// ---- Alertes (#7) ----

async function janlLoadAlerts() {
  const host = document.getElementById('janl-alerts-host');
  try {
    const { alerts } = await fetchJSON('/api/option-trades/alerts');
    host.innerHTML = alerts.length
      ? `<ul style="margin:0; padding-left:1.2rem;">${alerts.map((a) => `<li style="margin-bottom:0.4rem;"><strong>${optEsc(a.ticker)}</strong> ${optEsc(a.type)} ${optNum(a.strike)} (${optEsc(a.echeance)}) — ${optEsc(a.raison)}</li>`).join('')}</ul>`
      : '<p class="ds-text-muted">Aucune alerte pour le moment — soit aucune position ouverte, soit rien ne dépasse les seuils.</p>';
  } catch (err) {
    host.innerHTML = `<p class="ds-text-muted">Échec du chargement des alertes : ${optEsc(err.message)}</p>`;
  }
}

// ---- Alertes de positions poussées (#379) — local seulement ----

async function janlLoadPositionAlerts() {
  const card = document.getElementById('janl-pa-card');
  try {
    const d = await fetchJSON('/api/position-alerts/events');
    card.style.display = '';
    const unread = d.events.filter((e) => !e.readAt).length;
    document.getElementById('janl-pa-unread').textContent = unread ? `${unread} non lue(s)` : '';
    document.getElementById('janl-pa-info').textContent = (d.autoRunMinutes > 0
      ? `Évaluation automatique toutes les ${d.autoRunMinutes} min, jours ouvrables 9 h–17 h (New York), tant que castellana tourne sur ton Mac. `
      : 'Évaluation automatique désactivée (settings.json → listAlerts.autoRunMinutes). ')
      + (d.emailConfigured ? 'Courriel activé.' : 'Aucun courriel : ajoute ALERT_EMAIL et RESEND_API_KEY dans le fichier .env pour en recevoir.');
    document.getElementById('janl-pa-events').innerHTML = d.events.length
      ? `<ul style="margin:0; padding-left:1.2rem; line-height:1.6;">${d.events.slice(0, 30).map((e) => `<li${e.readAt ? ' style="opacity:.6"' : ''}><span class="ds-text-muted">${optEsc(e.createdAt)}</span> — ${optEsc(e.message)}</li>`).join('')}</ul>`
      : '<p class="ds-text-muted">Aucune alerte de position pour l\'instant.</p>';
  } catch { card.style.display = 'none'; }
}

async function janlRunPositionAlerts() {
  const btn = document.getElementById('janl-pa-run');
  const msg = document.getElementById('janl-pa-msg');
  btn.disabled = true; msg.textContent = 'Évaluation en cours…';
  try {
    const s = await fetchJSON('/api/position-alerts/run', { method: 'POST' });
    const bits = [`${s.legs} jambe(s) d'option et ${s.stocks} action(s) évaluées`, `${s.newAlerts} nouvelle(s) alerte(s)`];
    if (s.email.sent) bits.push('courriel envoyé');
    if (s.email.skipped) bits.push(`courriel non envoyé : ${s.email.skipped}`);
    if (s.errors.length) bits.push(`erreurs : ${s.errors.join(' ; ')}`);
    msg.textContent = bits.join(' · ');
    msg.style.color = s.errors.length ? 'var(--red)' : 'var(--text-2)';
    janlLoadPositionAlerts();
  } catch (err) { msg.textContent = err.message; msg.style.color = 'var(--red)'; }
  btn.disabled = false;
}

// ---- Cycles & positions ouvertes (#5) ----

function janlLegRowHTML(leg) {
  const capital = optCapitalRequired(leg.strike, janlContractSize(), leg.contrats);
  const primeTotale = leg.prime_recue * leg.contrats * janlContractSize();
  return `<tr>
    <td>${optEsc(leg.type)}</td><td class="is-num">${optNum(leg.strike)}</td><td>${optEsc(leg.echeance)}</td>
    <td class="is-num">${optNum(leg.prime_recue)}</td><td class="is-num">${janlFmtMoney(primeTotale)}</td>
    <td>${optEsc(leg.statut)}</td>
    <td>${leg.statut === 'ouvert' ? `<button type="button" class="ds-btn" onclick="janlCloseLeg(${leg.id})">Clôturer</button>` : (leg.date_cloture || '—')}</td>
  </tr>`;
}

async function janlLoadCycles() {
  const host = document.getElementById('janl-cycles-host');
  try {
    const { cycles } = await fetchJSON('/api/option-cycles');
    host.innerHTML = cycles.length
      ? cycles.map((c) => `
        <details class="ds-card" style="margin-bottom:0.75rem;" open>
          <summary><strong>${optEsc(c.ticker)}</strong> — cycle #${c.id} (${optEsc(c.statut)}) — ${c.legs.length} jambe(s) — ${janlFmtMoney(c.primeTotale)} de primes encaissées</summary>
          <div style="overflow-x:auto; margin-top:0.5rem;">
            <table class="ds-table"><thead><tr><th>Type</th><th class="is-num">Strike</th><th>Échéance</th><th class="is-num">Prime/action</th><th class="is-num">Prime totale</th><th>Statut</th><th></th></tr></thead>
            <tbody>${c.legs.map(janlLegRowHTML).join('')}</tbody></table>
          </div>
          <button type="button" class="ds-btn" style="margin-top:0.5rem;" onclick="janlPrefillNewLeg(${c.id}, '${optEsc(c.ticker)}', '${optEsc(c.compte)}')">+ Nouveau maillon (ex. call couvert après assignation)</button>
        </details>`).join('')
      : '<p class="ds-text-muted">Aucun cycle pour l\'instant — enregistre une position ci-dessus (avec « Nouveau cycle ») pour en créer un.</p>';
  } catch (err) {
    host.innerHTML = `<p class="ds-text-muted">Échec du chargement des cycles : ${optEsc(err.message)}</p>`;
  }
}

function janlPrefillNewLeg(cycleId, ticker, compte) {
  document.getElementById('janl-calc-ticker').value = ticker;
  document.getElementById('janl-calc-compte').value = compte;
  document.getElementById('janl-calc-type').value = 'call';
  janlRefreshCycleOptions().then(() => {
    const sel = document.getElementById('janl-calc-cycle');
    if ([...sel.options].some((o) => o.value === String(cycleId))) sel.value = String(cycleId);
  });
  document.querySelector('.ds-card:has(#janl-calc-ticker)')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// Clôture d'une jambe — statut, date, prime de rachat (sauf expiration),
// et pour l'assignation d'un put, le stop initial (jamais inventé, voir
// server/option-trades.js). Même patron d'interaction que closeTrade()
// (index.html) : prompt() natif, pas de dialogue custom.
async function janlCloseLeg(id) {
  const statut = prompt('Statut de clôture — expire / assigne / roule / rachete :', 'expire');
  if (!statut || !['expire', 'assigne', 'roule', 'rachete'].includes(statut)) return;
  const dateCloture = new Date().toISOString().slice(0, 10);
  let primeCloture = 0;
  if (statut !== 'expire') {
    const raw = prompt('Prime de rachat (par action) :');
    primeCloture = parseFloat(raw);
    if (!Number.isFinite(primeCloture) || primeCloture < 0) { alert('Prime de rachat invalide.'); return; }
  }
  const body = { statut, dateCloture, primeCloture };
  if (statut === 'assigne') {
    const ot = await fetchJSON(`/api/option-trades/${id}`);
    if (ot.type === 'put') {
      const raw = prompt('Stop initial de la position résultant de l\'assignation (obligatoire, jamais déduit automatiquement) :');
      const stopInitial = parseFloat(raw);
      if (!(stopInitial > 0)) { alert('Un stop initial positif est requis pour créer cette position dans le Journal actions.'); return; }
      body.stopInitial = stopInitial;
    }
  }
  try {
    const result = await fetchJSON(`/api/option-trades/${id}/close`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    let msg = 'Position clôturée.';
    if (result.effect.type === 'trade_cree') msg += ` Position créée dans le Journal actions (trade #${result.effect.tradeId}).`;
    if (result.effect.type === 'trade_ferme') msg += ` Position liée fermée dans le Journal actions (trade #${result.effect.tradeId}, ${result.effect.resultat}).`;
    if (result.effect.type === 'aucune_position_liee') msg += ' Aucune position liée trouvée dans le Journal actions pour ce cycle — rien de fermé automatiquement.';
    alert(msg);
    janlLoadCycles();
    janlLoadAlerts();
  } catch (err) {
    alert('Échec : ' + err.message);
  }
}

// ---- Labo #6 — revenu de primes RÉALISÉ (22/9/2026) ----
//
// Agrège les jambes CLOSES (expire/assigne/roule/rachete — la prime reste
// acquise dans tous les cas) par mois/titre/compte. Rendement annualisé
// « réalisé » = celui verrouillé À LA VENTE (prime/strike sur le DTE
// d'ouverture), pas raccourci par une clôture anticipée — c'est la
// performance de la décision de vendre, pas de la durée réellement tenue.
//
// Volontairement AUCUNE comparaison à un « rendement visé » : le Labo n'a
// pas de paramètre de rendement cible explicite, et ce projet a pour règle
// constante de ne jamais fabriquer un chiffre qui n'a pas de source réelle.
function janlDteAtOpen(leg) {
  const ms = new Date(`${leg.echeance}T00:00:00Z`).getTime() - new Date(`${leg.date_ouverture}T00:00:00Z`).getTime();
  return Math.max(1, Math.round(ms / 86400000));
}

function janlGroupSummary(legs, keyFn) {
  const byKey = new Map();
  for (const leg of legs) {
    const key = keyFn(leg);
    if (!byKey.has(key)) byKey.set(key, { key, count: 0, primeTotale: 0, yields: [] });
    const g = byKey.get(key);
    g.count++;
    g.primeTotale += leg.prime_recue * leg.contrats * janlContractSize();
    const y = optAnnualizedYield(leg.prime_recue, leg.strike, janlDteAtOpen(leg));
    if (y != null) g.yields.push(y);
  }
  return [...byKey.values()].map((g) => ({
    ...g, rendementMoyen: g.yields.length ? g.yields.reduce((a, b) => a + b, 0) / g.yields.length : null,
  })).sort((a, b) => (a.key < b.key ? -1 : 1));
}

function janlSummaryTableHTML(title, rows) {
  return `<div class="section-title" style="font-size:0.9rem; margin-top:0.75rem;">${optEsc(title)}</div>
    <table class="ds-table"><thead><tr><th></th><th class="is-num">Positions</th><th class="is-num">Prime encaissée</th><th class="is-num">Rendement annualisé moyen (à la vente)</th></tr></thead>
    <tbody>${rows.map((r) => `<tr><td>${optEsc(r.key)}</td><td class="is-num">${r.count}</td><td class="is-num">${janlFmtMoney(r.primeTotale)}</td><td class="is-num">${janlFmtPct(r.rendementMoyen)}</td></tr>`).join('')}</tbody></table>`;
}

async function renderLaboRevenuPrimes() {
  const card = document.getElementById('labo-revenu-primes-card');
  if (!card) return;
  // Ligne d'état (#437) : visible seulement si l'onglet Roue est actif (html.roue-on).
  const etat = '<p class="ds-text-hint roue-etat" style="text-align:left; color:var(--amber);">Visée pour suppression : ces chiffres sont repris, nets de frais, par le tableau de bord annuel de l\'onglet Roue (H3). Décision à prendre : feature bilbao #441.</p>';
  card.innerHTML = '<div class="section-title">Revenu de primes réalisé</div>' + etat + '<p class="ds-text-muted">Chargement…</p>';
  try {
    const { trades: legs } = await fetchJSON('/api/option-trades?statut=expire,assigne,roule,rachete');
    if (!legs.length) {
      card.innerHTML = '<div class="section-title">Revenu de primes réalisé</div>' + etat + '<p class="ds-text-muted">Aucune position clôturée pour l\'instant — clôture une jambe dans l\'onglet Screener Prime pour l\'alimenter.</p>';
      return;
    }
    const primeTotale = legs.reduce((s, l) => s + l.prime_recue * l.contrats * janlContractSize(), 0);
    const yields = legs.map((l) => optAnnualizedYield(l.prime_recue, l.strike, janlDteAtOpen(l))).filter((y) => y != null);
    const rendementMoyen = yields.length ? yields.reduce((a, b) => a + b, 0) / yields.length : null;
    const byMonth = janlGroupSummary(legs, (l) => l.date_ouverture.slice(0, 7));
    const byTicker = janlGroupSummary(legs, (l) => l.ticker);
    const byCompte = janlGroupSummary(legs, (l) => l.compte);
    card.innerHTML = `
      <div class="section-title">Revenu de primes réalisé</div>
      ${etat}
      <p class="metric-sub" style="text-align:left;">${legs.length} position(s) clôturée(s) — ${janlFmtMoney(primeTotale)} de primes encaissées au total, ${janlFmtPct(rendementMoyen)} de rendement annualisé moyen (verrouillé à la vente, pas raccourci par une clôture anticipée).</p>
      ${janlSummaryTableHTML('Par mois d\'ouverture', byMonth)}
      ${janlSummaryTableHTML('Par symbole', byTicker)}
      ${janlSummaryTableHTML('Par compte', byCompte)}
    `;
  } catch (err) {
    card.innerHTML = `<div class="section-title">Revenu de primes réalisé</div><p class="ds-text-muted">Échec du chargement : ${optEsc(err.message)}</p>`;
  }
}

// ---- Feature flag journal_a_tab (défaut OFF) — révèle l'onglet ET la
// carte Labo #6 (revenu de primes réalisé), qui dépend du même schéma. Même
// patron que initConceptsTab()/initOptaVisibility().
async function initJournalAVisibility() {
  const btn = document.getElementById('tab-btn-journal-a');
  const laboCard = document.getElementById('labo-revenu-primes-card');
  try {
    const { flags } = await fetchJSON('/api/flags');
    if (flags && flags.journal_a_tab === true) {
      if (btn) btn.style.display = '';
      renderJournalATab();
      if (laboCard) { laboCard.style.display = ''; renderLaboRevenuPrimes(); }
    }
  } catch { /* onglet et carte restent cachés */ }
}
