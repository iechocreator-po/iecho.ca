// js/fcf-card.js — Carte « Fondamentaux » de la Fiche de trade (26/9/2026,
// lot 1, feature flag fundamentals_card, défaut OFF) : EPS, FCF, FCF par
// action, et l'indice « le FCF est-il bon dans le temps ? ».
//
// Affichée sous la section « Symbole » de la Fiche (#fic-fcf-card) et, depuis
// le 26/9/2026 (demande de JP), des onglets Secteurs (#sec-fcf-card) et
// Screener (#scr-fcf-card) et Labo (#lab-fcf-card) : même rendu, identifiant de carte en paramètre.
//
// Local ET cloud (26/9/2026) : copie identique dans cloud/public/js/ (test de
// parité) ; la route cloud est GET /api/fcf/:ticker (cloud/src/lib/fcf-quality.js).
// Tout ce qui est affiché vient de GET /api/fcf/:ticker (server/fcf-quality.js),
// y compris les seuils — aucun chiffre de règle n'est dupliqué ici.

let fcfCardEnabled = false;
// Instances de la section « Symbole » qui affichent la carte (la Fiche, `fic`,
// la charge par son propre chemin : fetchLiveFiche()).
const FCF_INSTANCES = ['sec', 'scr', 'lab'];

async function initFcfCardVisibility() {
  try {
    const { flags } = await fetchJSON('/api/flags');
    fcfCardEnabled = !!(flags && flags.fundamentals_card === true);
  } catch { /* carte reste cachée */ }
}

function fcfEsc(v) {
  return String(v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// 1 234 567 890 → « 1,23 G$ » ; jamais de float brut à l'écran.
function fcfMoney(v) {
  if (v == null) return 'N/D';
  const a = Math.abs(v);
  const [d, u] = a >= 1e9 ? [1e9, ' G$'] : a >= 1e6 ? [1e6, ' M$'] : [1, ' $'];
  return (v < 0 ? '−' : '') + (a / d).toFixed(2).replace('.', ',') + u;
}
const fcfPS = (v) => (v == null ? 'N/D' : (v < 0 ? '−' : '') + Math.abs(v).toFixed(2).replace('.', ',') + ' $');
const fcfPct = (v) => (v == null ? 'N/D' : (v < 0 ? '−' : '') + Math.abs(v * 100).toFixed(1).replace('.', ',') + ' %');

const FCF_VERDICT = {
  solide: { label: 'Solide', cls: 'ds-badge--success' },
  mitige: { label: 'Mitigé', cls: 'ds-badge--warning' },
  fragile: { label: 'Fragile', cls: 'ds-badge--danger' },
};

// ---- Pondération du score fondamental (2/10/2026) --------------------------
// Le score est une moyenne PONDÉRÉE de 5 critères évalués de 0 à 100 % : les 4 mesures de la
// qualité du FCF (calculées côté serveur, en points sur 25) et la valorisation (P/S, évaluée ici
// car le prix change pendant la journée alors que le FCF est mis en cache 24 h). Les poids sont les
// réglages de l'utilisateur (Réglages → Valeur personnalisée, 100 % au total).
let fcfWeights = { growth: 20, consistency: 20, conversion: 20, dilution: 20, valuation: 20, balance: 0 };
const fcfLastRender = {}; // cardId → arguments du dernier rendu, pour re-rendre quand les poids changent

function setFcfWeights(w) {
  fcfWeights = { ...fcfWeights, ...w };
  for (const [id, a] of Object.entries(fcfLastRender)) {
    const card = document.getElementById(id);
    if (card && card.style.display !== 'none') renderFcfCard(a.d, id, a.price, a.md);
  }
}

// Part des points (0–1) selon le P/S, d'après le barème de config.js ; null si le P/S n'est pas exploitable.
function fcfPsFraction(ps, bareme) {
  if (!(ps > 0)) return null;
  for (const b of bareme) {
    if (b.lt != null ? ps < b.lt : b.lte != null ? ps <= b.lte : true) return b.frac;
  }
  return 0;
}

// Part des points (0–1) selon trésorerie ÷ dette (barème `cashBareme` de config.js). Dette nulle = 1 ;
// trésorerie ou dette inconnue (Yahoo ne la donne pas) = null, donc critère exclu — jamais un zéro inventé.
function fcfCashFraction(balance, bareme) {
  if (!balance || !bareme) return null;
  const { cash, debt } = balance;
  if (cash == null || debt == null || cash < 0 || debt < 0) return null;
  if (debt === 0) return 1;
  const ratio = cash / debt;
  for (const b of bareme) {
    if (b.gte == null || ratio >= b.gte) return b.frac;
  }
  return 0;
}

// Pur (testé) : retourne les lignes du tableau et le score pondéré. Un critère sans donnée (N/D) ou à
// poids 0 est EXCLU et les autres sont ramenés à 100 % — jamais compté comme un zéro.
function fcfWeightedScore(quality, ps, weights, bareme, verdicts, balance, cashBareme) {
  const sub = quality.sub;
  const frac = (s) => (s && s.score != null ? s.score / quality.max : null);
  const fr = {
    growth: frac(sub.growth), consistency: frac(sub.consistency), conversion: frac(sub.conversion), dilution: frac(sub.dilution),
    valuation: fcfPsFraction(ps, bareme),
    balance: fcfCashFraction(balance, cashBareme),
  };
  let totalW = 0, acc = 0, partial = false;
  for (const k of Object.keys(fr)) {
    const w = weights[k] || 0;
    if (w <= 0) continue;
    if (fr[k] == null) { partial = true; continue; }
    totalW += w; acc += w * fr[k];
  }
  const score = totalW > 0 ? Math.round((acc / totalW) * 100) : null;
  const verdict = score == null ? null : score >= verdicts.solide ? 'solide' : score >= verdicts.mitige ? 'mitige' : 'fragile';
  return { fractions: fr, score, verdict, partial, totalWeight: totalW };
}

// Couleur (vert / jaune / rouge) d'UNE tuile (2/10/2026) — repères de CFG.fondamentaux.bandes, les mêmes
// que ceux affichés dans les popovers (i). Retourne null quand le chiffre ne peut pas être situé (pas de
// comparaison possible) : une tuile sans couleur vaut « non évalué », jamais « neutre » déguisé.
function fcfTileBands(d, price, b) {
  const num = (v) => v != null && Number.isFinite(v);
  const out = { eps: null, fcf: null, fcfPerShare: null, yield: null, cash: null };
  const last = d.years && d.years.length ? d.years[d.years.length - 1] : null;
  const eps = d.ttm.eps;
  if (num(eps)) {
    if (eps <= 0) out.eps = 'rouge';
    else if (last && num(last.eps)) out.eps = last.eps <= 0 || eps >= last.eps ? 'vert' : 'amber';
  }
  const fcf = d.ttm.fcf;
  if (num(fcf)) {
    if (fcf < 0) out.fcf = 'rouge';
    else if (d.ttm.revenue > 0) out.fcf = (fcf / d.ttm.revenue) * 100 >= b.fcfMargeVert ? 'vert' : 'amber';
  }
  const fps = d.ttm.fcfPerShare;
  if (num(fps)) {
    if (fps <= 0) out.fcfPerShare = 'rouge';
    else if (last && num(last.fcfPerShare)) {
      if (last.fcfPerShare <= 0) out.fcfPerShare = 'vert';
      else {
        const g = (fps / last.fcfPerShare - 1) * 100;
        out.fcfPerShare = g >= b.fcfParActionHausseVert ? 'vert' : g < b.fcfParActionBaisseRouge ? 'rouge' : 'amber';
      }
    }
  }
  if (num(fps) && price > 0) {
    const y = (fps / price) * 100;
    out.yield = y >= b.rendementVert ? 'vert' : y < b.rendementRouge ? 'rouge' : 'amber';
  }
  const bal = d.balance;
  if (bal && num(bal.cash) && num(bal.debt) && b.tresorerieVert != null) {
    if (bal.debt === 0) out.cash = 'vert';
    else {
      const r = bal.cash / bal.debt;
      out.cash = r >= b.tresorerieVert ? 'vert' : r < b.tresorerieRouge ? 'rouge' : 'amber';
    }
  }
  return out;
}
const fcfBandColor = (band) => ({ vert: 'var(--green)', amber: 'var(--amber)', rouge: 'var(--red)' }[band] || '');
const fcfValStyle = (band) => (band ? ` style="color:${fcfBandColor(band)}"` : '');

function fcfSubRow(label, frac, weight, valueText, help, note) {
  const excluded = weight <= 0;
  const pts = excluded ? '—' : frac == null ? 'N/D' : `${(frac * weight).toFixed(1).replace('.', ',')} / ${weight}`;
  const noteHtml = note ? ` <span class="metric-sub">(${fcfEsc(note)})</span>` : '';
  const dim = excluded ? ' style="opacity:.55;"' : '';
  return `<tr${dim}><td>${label}<div class="metric-sub" style="text-align:left;">${help}${excluded ? ' — exclu du score (poids 0 %)' : ''}</div></td>
    <td>${valueText}${noteHtml}</td><td style="text-align:right;">${weight} %</td><td style="text-align:right;">${pts}</td></tr>`;
}

// Une ligne de contexte sous une tuile (2/10/2026) — jamais un chiffre sans sa référence.
const fcfCtx = (txt) => (txt ? `<span class="metric-sub" style="text-align:left;">${fcfEsc(txt)}</span>` : '');
const fcfSigned = (r) => (r > 0 ? '+' : r < 0 ? '−' : '') + Math.abs(r * 100).toFixed(0) + ' %';
// Variation du chiffre des 12 mois contre le dernier exercice complet. Exercice à valeur
// négative ou nulle : pas de pourcentage (il ne voudrait rien dire), juste la valeur.
function fcfVsLastYear(ttmValue, d, field, fmt) {
  const y = d.years && d.years.length ? d.years[d.years.length - 1] : null;
  if (ttmValue == null || !y || y[field] == null) return '';
  if (y[field] <= 0) return `exercice ${y.fiscalYear} : ${fmt(y[field])}`;
  return `${fcfSigned(ttmValue / y[field] - 1)} vs exercice ${y.fiscalYear} (${fmt(y[field])})`;
}
function fcfRiskFreePct() {
  try {
    const p = laboEffectiveParams('roue', (typeof laboParamOverrides !== 'undefined' ? laboParamOverrides.roue : {}));
    if (p && Number.isFinite(p.riskFreePct)) return p.riskFreePct;
  } catch { /* repli ci-dessous */ }
  return 4;
}

function renderFcfCard(d, cardId = 'fic-fcf-card', price = null, md = null) {
  const card = document.getElementById(cardId);
  if (!card) return;
  fcfLastRender[cardId] = { d, price, md };
  card.style.display = '';
  const head = `<div class="section-title">Fondamentaux — ${fcfEsc(d.symbol)}</div>`;
  // Rendement du FCF (12 mois) = FCF par action ÷ prix courant (28/9/2026,
  // demande de JP) — 4e tuile, les 3 existantes rétrécissent avec elle
  // (grid-3 → grid-4) plutôt que de s'ajouter en surplus. `price` vient du
  // marché courant, jamais du même appel que le FCF (cache 24h, voir
  // getFcfQuality() côté serveur) — sinon un prix figé pendant 24h fausserait
  // le rendement sans que rien ne le signale.
  const fcfYield = (d.ttm.fcfPerShare != null && price > 0) ? d.ttm.fcfPerShare / price : null;
  const tb = fcfTileBands(d, price, CFG.fondamentaux.bandes);
  const rf = fcfRiskFreePct();
  const epsCtx = fcfVsLastYear(d.ttm.eps, d, 'eps', fcfPS);
  const fcfMargin = (d.ttm.fcf != null && d.ttm.revenue > 0) ? d.ttm.fcf / d.ttm.revenue : null;
  const fcfCtxTxt = fcfMargin == null ? '' : `marge de FCF : ${fcfPct(fcfMargin)} des revenus`;
  const fcfPsCtx = fcfVsLastYear(d.ttm.fcfPerShare, d, 'fcfPerShare', fcfPS);
  const yieldCtx = fcfYield == null ? '' : `${fcfYield * 100 >= rf ? 'au-dessus' : 'sous'} le taux sans risque (${rf.toFixed(1).replace('.', ',')} %)`;
  const bal = d.balance;
  const cashCtx = !bal || bal.cash == null ? '' : bal.debt == null ? 'dette : N/D'
    : bal.debt === 0 ? 'aucune dette'
    : `dette ${fcfMoney(bal.debt)} · ${bal.cash >= bal.debt ? 'trésorerie nette +' + fcfMoney(bal.cash - bal.debt) : 'dette nette ' + fcfMoney(bal.debt - bal.cash)}`;
  const ttm = `<div class="grid-6">
      <div class="ds-metric" style="display:flex;flex-direction:column;"><span class="ds-metric__label">EPS (12 derniers mois)<button type="button" class="info-btn" onclick="showGlossaire('fcfEps', this)" title="Aide">i</button></span><span class="ds-metric__value"${fcfValStyle(tb.eps)}>${fcfPS(d.ttm.eps)}</span>${fcfCtx(epsCtx)}</div>
      <div class="ds-metric" style="display:flex;flex-direction:column;"><span class="ds-metric__label">FCF (12 derniers mois)<button type="button" class="info-btn" onclick="showGlossaire('fcfTotal', this)" title="Aide">i</button></span><span class="ds-metric__value"${fcfValStyle(tb.fcf)}>${fcfMoney(d.ttm.fcf)}</span>${fcfCtx(fcfCtxTxt)}</div>
      <div class="ds-metric" style="display:flex;flex-direction:column;"><span class="ds-metric__label">FCF par action (12 mois)<button type="button" class="info-btn" onclick="showGlossaire('fcfPerShare', this)" title="Aide">i</button></span><span class="ds-metric__value"${fcfValStyle(tb.fcfPerShare)}>${fcfPS(d.ttm.fcfPerShare)}</span>${fcfCtx(fcfPsCtx)}</div>
      <div class="ds-metric" style="display:flex;flex-direction:column;"><span class="ds-metric__label" title="FCF par action (12 mois) ÷ prix courant de l'action.">Rendement du FCF (12 mois)<button type="button" class="info-btn" onclick="showGlossaire('fcfYield', this)" title="Aide">i</button></span><span class="ds-metric__value"${fcfValStyle(tb.yield)}>${fcfYield == null ? 'N/D' : fcfPct(fcfYield)}</span>${fcfCtx(yieldCtx)}</div>
      <div class="ds-metric" style="display:flex;flex-direction:column;"><span class="ds-metric__label" title="Price-to-Sales (12 mois) = capitalisation ÷ revenus. Repère : 1 à 2 = très bien.">P/S (12 mois)<button type="button" class="info-btn" onclick="showGlossaire('priceToSales', this)" title="Aide">i</button></span><span class="ds-metric__value"${md?.priceToSales != null && psInGoodBand(md.priceToSales) ? ' style="color:var(--green)"' : ''}>${md?.priceToSales != null ? md.priceToSales.toFixed(2).replace('.', ',') : 'N/D'}</span><span class="metric-sub" style="text-align:left;">${md?.priceToSales != null ? fcfEsc(psSectorText(md)) : ''}</span></div>
      <div class="ds-metric" style="display:flex;flex-direction:column;"><span class="ds-metric__label" title="Trésorerie et placements à court terme (dernier trimestre publié), comparés à la dette totale.">Trésorerie (cash)<button type="button" class="info-btn" onclick="showGlossaire('cashEquivalents', this)" title="Aide">i</button></span><span class="ds-metric__value"${fcfValStyle(tb.cash)}>${fcfMoney(d.balance?.cash ?? null)}</span>${fcfCtx(cashCtx)}</div>
    </div>`;
  if (!d.applicable || !d.quality) {
    card.innerHTML = `${head}${ttm}<p class="metric-sub" style="text-align:left;"><strong>Score fondamental : N/D</strong> — ${fcfEsc(d.reason)}</p>`;
    return;
  }
  const q = d.quality;
  const w = fcfWeights;
  const ps = md?.priceToSales ?? null;
  const bareme = CFG.fondamentaux.psBareme;
  const res = fcfWeightedScore(q, ps, w, bareme, d.thresholds.verdicts, d.balance, CFG.fondamentaux.cashBareme);
  const v = res.verdict ? FCF_VERDICT[res.verdict] : null;
  const s = q.sub;
  const psBand = ps == null ? '—' : psInGoodBand(ps) ? 'très bien (1 à 2)' : ps < CFG.fondamentaux.psBon.min ? 'sous 1' : ps <= 5 ? 'entre 2 et 5' : ps <= 10 ? 'entre 5 et 10' : 'au-dessus de 10';
  const rows = [
    fcfSubRow('Croissance du FCF par action', res.fractions.growth, w.growth, s.growth.value == null ? '—' : fcfPct(s.growth.value) + ' / an', 'Compare la 1re et la dernière année, par action (pas le FCF brut).', s.growth.note),
    fcfSubRow('Régularité', res.fractions.consistency, w.consistency, `${s.consistency.positiveYears} années positives sur ${s.consistency.years}`, 'Le FCF est-il positif chaque année ?', s.consistency.note),
    fcfSubRow('Conversion en cash', res.fractions.conversion, w.conversion, s.conversion.value == null ? '—' : s.conversion.value.toFixed(2).replace('.', ',') + '×', 'FCF ÷ résultat net (médiane) : les profits sont-ils de l\'argent réel ?', s.conversion.note),
    fcfSubRow('Dilution', res.fractions.dilution, w.dilution, fcfPct(s.dilution.value) + ' / an', 'Évolution du nombre d\'actions : négatif = rachats.', s.dilution.note),
    fcfSubRow('Valorisation (P/S)', res.fractions.valuation, w.valuation, ps == null ? 'N/D' : `P/S ${ps.toFixed(2).replace('.', ',')} — ${psBand}`, 'Capitalisation ÷ revenus : 1 à 2 = très bien (barème dans config.js).', ''),
    fcfSubRow('Solidité du bilan', res.fractions.balance, w.balance, !bal || bal.cash == null ? 'N/D' : bal.debt == null ? `trésorerie ${fcfMoney(bal.cash)} — dette N/D` : bal.debt === 0 ? `trésorerie ${fcfMoney(bal.cash)} — aucune dette` : `trésorerie ÷ dette = ${(bal.cash / bal.debt).toFixed(2).replace('.', ',')}`, 'Trésorerie face à la dette totale : 1 ou plus = trésorerie nette positive (barème dans config.js).', ''),
  ].join('');
  const maxFcfPS = Math.max(...d.years.map((y) => Math.abs(y.fcfPerShare)));
  const years = d.years.map((y) => {
    const w = Math.round((Math.abs(y.fcfPerShare) / maxFcfPS) * 100);
    const color = y.fcfPerShare < 0 ? 'var(--red)' : 'var(--green)';
    return `<tr><td>${fcfEsc(y.fiscalYear)}</td><td>${fcfMoney(y.fcf)}</td>
      <td><div style="display:flex;align-items:center;gap:8px;"><div style="height:8px;width:${w}px;max-width:100px;background:${color};border-radius:2px;"></div>${fcfPS(y.fcfPerShare)}</div></td>
      <td>${fcfPS(y.eps)}</td><td>${y.conversion == null ? 'N/D' : y.conversion.toFixed(2).replace('.', ',') + '×'}</td></tr>`;
  }).join('');
  card.innerHTML = `${head}${ttm}
    <p style="margin:12px 0 4px;"><strong>Score fondamental :</strong>
      ${v ? `<span class="ds-badge ${v.cls}">${v.label}</span> ${res.score} / 100` : 'N/D (tous les poids exclus)'} <span class="metric-sub">— qualité du FCF sur ${q.years} exercices, valorisation (P/S) et solidité du bilan (0 % par défaut), pondération réglable dans Réglages → Valeur personnalisée${res.partial ? ' · critère sans donnée exclu, poids restants ramenés à 100 %' : ''}</span></p>
    <table class="ds-table"><thead><tr><th>Critère</th><th>Mesure</th><th style="text-align:right;">Poids</th><th style="text-align:right;">Points</th></tr></thead><tbody>${rows}</tbody></table>
    <table class="ds-table" style="margin-top:10px;"><thead><tr><th>Exercice</th><th>FCF</th><th>FCF / action</th><th>EPS dilué</th><th>FCF ÷ résultat net</th></tr></thead><tbody>${years}</tbody></table>
    <p class="metric-sub" style="text-align:left;">Les 12 derniers mois et l'historique annuel sont deux sources distinctes de Yahoo Finance : ils peuvent différer beaucoup (un gros trimestre récent, un exercice décalé). Seul l'historique annuel alimente les quatre critères de qualité du FCF. Description d'un flux passé, pas une recommandation. Verdict : Solide ≥ ${d.thresholds.verdicts.solide}, Mitigé ≥ ${d.thresholds.verdicts.mitige}. Un gros investissement volontaire (capex de croissance) peut faire baisser le FCF sans que l'entreprise soit fragile.</p>`;
}

// Appelée par fetchLiveSelectionFor()/fetchLiveFiche(). N'affiche rien (et ne
// fait aucun appel réseau) tant que le flag n'est pas ON. `marketDataPromise`
// est le /api/market-data déjà lancé par l'appelant pour la section
// « Symbole » — réutilisé pour le prix courant (rendement du FCF, 28/9/2026)
// sans appel réseau supplémentaire ; absent, le rendement affiche « N/D ».
// Renvoie une note de statut, ou null.
async function loadFcfCard(ticker, cardId = 'fic-fcf-card', marketDataPromise) {
  const card = document.getElementById(cardId);
  if (!fcfCardEnabled || !card) return null;
  card.style.display = '';
  card.innerHTML = '<div class="section-title">Fondamentaux</div><p class="metric-sub">Chargement…</p>';
  try {
    const [fcfRes, marketRes] = await Promise.allSettled([
      fetchJSON(`/api/fcf/${encodeURIComponent(ticker)}`),
      marketDataPromise || Promise.resolve(null),
    ]);
    if (fcfRes.status !== 'fulfilled') throw fcfRes.reason;
    const price = marketRes.status === 'fulfilled' ? (marketRes.value?.price ?? null) : null;
    renderFcfCard(fcfRes.value, cardId, price, marketRes.status === 'fulfilled' ? marketRes.value : null);
    return null;
  } catch (err) {
    card.innerHTML = `<div class="section-title">Fondamentaux</div><p class="metric-sub" style="text-align:left;">Indisponible : ${fcfEsc(err.message)}</p>`;
    return 'fondamentaux (FCF) indisponibles';
  }
}

// Cache la carte quand le symbole change : ses chiffres seraient ceux d'un
// AUTRE titre (même garde-fou que invalidateSelectionData()).
function hideFcfCard(cardId) {
  const card = document.getElementById(cardId);
  if (card) { card.style.display = 'none'; card.innerHTML = ''; }
}
