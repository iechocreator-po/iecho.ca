# castellana — Assistant de swing trading

Outil personnel d'aide à la décision pour le swing trading sur actions
(tech/IA principalement). Ce n'est **ni un robot de trading, ni un
générateur de conseils financiers** : il n'envoie jamais d'ordre et ne
recommande rien à un tiers. C'est un assistant de screening, de calcul de
taille de position, et de journal de trades — pour une seule personne
(usage local, pas de compte, pas d'authentification).

> Nom de code interne : **castellana**. Le dossier s'appelle
> `trading-assistant` par convention (voir `CLAUDE.md` si tu cherches le
> contexte complet du projet — c'est le journal de bord détaillé, pas
> nécessaire pour faire tourner l'app).

## Ce que fait l'app

Trois écrans, dans un seul parcours :

1. **Écran de sélection** — un tableau de 20 titres passés au crible (RSI,
   force relative vs S&P 500, Golden Cross, OBV, P/E, industrie…), plus la
   performance du jour de chaque secteur du marché (graphique + tableau).
   Sert à décider quels titres suivre activement.
2. **Fiche de trade** — une fois un titre choisi, calcule automatiquement la
   taille de position, le stop (basé sur l'ATR), la charge de risque du
   portefeuille, et les cibles de sortie (multiples de R et extensions
   Fibonacci).
3. **Journal & stats** — enregistre chaque trade pris (compte, prix, stop,
   indicateurs au moment de l'entrée) et calcule après coup si tel ou tel
   indicateur a réellement aidé.

Toutes les données de marché (cours, indicateurs techniques, secteurs) sont
allées chercher **en direct**, gratuitement, via Yahoo Finance et un petit
serveur tiers spécialisé (voir architecture ci-dessous) — aucune clé API à
configurer.

## Architecture — un seul programme

> **Simplifié le 7/9/2026.** C'étaient auparavant *deux* serveurs séparés
> (Node + un sidecar Python), et c'était la source de confusion la plus
> fréquente à l'installation. Le sidecar est devenu optionnel et désactivé
> par défaut : tout ce qu'il fournissait — VIX, RSI(14), SMA 50/200, Golden
> Cross, cotations — est désormais calculé par le backend à partir de
> l'historique Yahoo Finance qu'il télécharge de toute façon, et vérifié
> identique à la décimale sur toute la watchlist.

```mermaid
flowchart LR
    subgraph Navigateur
        UI["Dashboard\n(index.html — HTML/CSS/JS, aucun build)"]
    end
    subgraph "Machine locale"
        BACK["Backend Express\n(Node.js — server/index.js)\nhttp://127.0.0.1:4700"]
        DB[("SQLite\ndata/castellana.sqlite\ndonnées + cache\ncréée automatiquement")]
        SIDE["Sidecar Python\n(tradingview-mcp)\nDÉSACTIVÉ par défaut"]
    end
    YAHOO[("Yahoo Finance\n(gratuit, pas de clé)")]

    UI <--> BACK
    BACK <--> DB
    BACK --> YAHOO
    BACK -. "optionnel,\npour comparer" .-> SIDE
```

| Pièce | Techno | Rôle | Obligatoire ? |
|---|---|---|---|
| **Dashboard** | `index.html` — HTML/CSS/JS pur, aucune étape de build | L'interface dans le navigateur | Oui — servi par le backend |
| **Backend** | Node.js + Express + SQLite (`server/`) | Sert le dashboard, calcule **tous** les indicateurs depuis Yahoo Finance, gère le journal de trades et le cache | **Oui — et c'est le seul** |
| **Sidecar MCP** | Python (`tradingview-mcp-server`) | Rien d'indispensable. Reste installable pour comparer les valeurs calculées avec celles de TradingView | **Non** — désactivé par défaut, ~170 Mo, second processus à maintenir |
| **Launcher** | Node.js (`launcher/`, port 4750) | Surveille castellana et le relance automatiquement s'il tombe | Non, mais recommandé pour un usage prolongé |

**Aucun compte n'est nécessaire** — ni TradingView, ni Yahoo, ni clé API, ni
`.env` à remplir. Tout tourne en local sur `127.0.0.1`, jamais exposé sur
Internet.

## Installer et lancer le projet

👉 **Voir [`SETUP.md`](SETUP.md)** pour les instructions pas-à-pas, Windows et
macOS.

Le plus court : décompresser `castellana.zip`, puis double-cliquer
`demarrer.command` (macOS, **clic droit → Ouvrir** la première fois) ou
`demarrer.bat` (Windows). Le script installe ce qui manque et ouvre le
navigateur.

Pour qui a déjà tout installé :

```bash
npm run doctor   # vérifie Node, dépendances, base, port, Yahoo — et dit quoi faire
npm start        # l'adresse s'affiche (repli automatique si 4700 est pris)
```

> Projet déjà cloné auparavant ? Fais `git pull` avant de relancer — une
> erreur inattendue vient presque toujours d'une copie locale pas à jour
> plutôt que d'un vrai problème d'installation.

Le témoin de statut dans l'en-tête indique en direct ce qui tourne. Un point
**gris** sur « tradingview-mcp » signifie *désactivé* (normal), pas en panne ;
seul un point **rouge** signale un vrai problème, avec sa cause en clair.

L'app signale aussi, par un bandeau, quand une version plus récente est
publiée — et sait s'installer elle-même en un clic sans toucher au journal
de trades.

## Stack technique

- **Frontend** : HTML/CSS/JS vanilla, zéro framework, zéro étape de build.
- **Backend** : Node.js (≥ 20) + Express + `better-sqlite3` (seul module
  natif — voir `SETUP.md` si son installation échoue sur Windows).
- **Données de marché** : `yahoo-finance2` (npm, direct) — source unique par
  défaut. `tradingview-mcp` (sidecar Python tiers) reste branchable mais
  n'est plus utilisé.
- **Robustesse** : réessai + temporisation sur chaque appel externe
  (`server/fetch-retry.js`), cache persistant en SQLite
  (`server/cache.js`).
- **Design** : copie vendorée du design system du portfolio
  (`design-system/`), pas de dépendance externe.

## Portée et limites (à lire avant de contribuer)

- Usage **local et personnel** — pas pensé pour être déployé sur le web, pas
  d'authentification.
- **N'envoie jamais d'ordre** à un courtier — c'est un outil d'aide à la
  décision et de journalisation, pas d'exécution automatique.
- Les données de screening dépendent d'API publiques non officielles
  (Yahoo Finance, scanner TradingView) — un rate-limit occasionnel sur le
  scanner TradingView est normal et documenté (voir `CLAUDE.md`).
- `CLAUDE.md` à la racine est le journal de bord détaillé du projet
  (décisions, historique, limites connues) — utile pour comprendre
  *pourquoi* certains choix ont été faits, pas nécessaire pour l'utiliser.
