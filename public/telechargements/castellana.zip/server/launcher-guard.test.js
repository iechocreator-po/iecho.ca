// Garde du lanceur (audit périphérie, 22/10/2026) : une page web quelconque ne doit pas pouvoir relancer l'app ou couper sa surveillance.
import test from 'node:test';
import assert from 'node:assert/strict';
import { verifierRequete } from '../launcher/guard.js';

const req = (method, headers) => ({ method, headers: { host: '127.0.0.1:4750', ...headers } });
const json = { 'content-type': 'application/json' };

test('lanceur : la page du lanceur lui-même et les outils locaux passent', () => {
  assert.equal(verifierRequete(req('GET', {})), null);
  assert.equal(verifierRequete(req('POST', { ...json, origin: 'http://127.0.0.1:4750' })), null, 'la page du lanceur');
  assert.equal(verifierRequete(req('POST', { ...json, origin: 'http://localhost:4750' })), null);
  assert.equal(verifierRequete(req('POST', json)), null, 'curl, sans Origin');
  assert.equal(verifierRequete(req('GET', { host: '[::1]:4750', 'sec-fetch-site': 'same-origin' })), null);
});

test('lanceur : un autre site, un autre hôte, ou un POST qui n\'est pas du JSON sont refusés', () => {
  assert.equal(verifierRequete(req('POST', { ...json, origin: 'https://evil.example' })).status, 403, 'autre origine');
  assert.equal(verifierRequete(req('POST', { ...json, origin: 'null' })).status, 403, 'origine opaque');
  assert.equal(verifierRequete(req('GET', { 'sec-fetch-site': 'cross-site' })).status, 403, 'lecture d\'une autre page');
  assert.equal(verifierRequete(req('GET', { host: 'evil.example' })).status, 403, 'DNS rebinding');
  assert.equal(verifierRequete(req('POST', { 'content-type': 'text/plain' })).status, 415, 'POST « simple » no-cors');
  assert.equal(verifierRequete(req('POST', {})).status, 415, 'sans Content-Type');
  assert.equal(verifierRequete({ method: 'GET', headers: {} }).status, 403, 'sans Host');
});
