// Tests de js/sizing.js — le calcul qui décide combien d'argent est engagé.
//
// Il n'avait AUCUN test jusqu'au 11/9/2026, parce qu'il était enfermé au
// milieu des écritures DOM de `calcFiche()`. C'est la raison principale de
// l'avoir extrait : pas la réutilisation, la vérifiabilité.
//
// Les valeurs attendues sont calculées à la main dans chaque test, avec une
// configuration EXPLICITE plutôt que celle de config.js — un test qui lit la
// même config que le code ne vérifie pas la formule, il la recopie.

import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

// `computeSizing` lit `CFG` comme global (c'est un script de navigateur,
// chargé après config.js). On lui en fournit un, aux valeurs connues.
globalThis.CFG = {
  sizing: {
    discounts: { correlation: 0.5, vixNervosite: 0.75, vixPanique: 0.5, rsiSurachat: 0.75, obvDistribution: 0.75 },
    chargePortefeuille: { avertissement: 4, alerte: 6 },
  },
  bandes: {
    vix: { normalBas: 15, normalHaut: 20, nervositeHaut: 30 },
    rsi: { surventeHaut: 30, entreeBas: 40, entreeHaut: 70 },
  },
};
// js/sizing.js est un script de NAVIGATEUR classique (chargé par un <script>
// dans index.html), pas un module ESM — il ne peut donc pas porter
// `export`, qui serait une erreur de syntaxe dans ce contexte. On l'évalue
// ici comme le navigateur le ferait.
//
// Piège rencontré en écrivant ce test : `createRequire(...)` semblait plus
// direct, mais le paquet est en `"type": "module"`, donc Node charge le
// fichier comme ESM, où `module` n'existe pas — la garde
// `typeof module !== 'undefined'` du bas du fichier ne s'exécutait jamais et
// l'import ressortait vide, sans erreur.
const source = readFileSync(new URL('../js/sizing.js', import.meta.url), 'utf8');
const { computeSizing, sizingCapNote } = new Function(`${source}; return { computeSizing, sizingCapNote };`)();

const base = { capital: 50000, riskPct: 1, heatExist: 0, entry: 100, atr: 5, atrMult: 2,
               correlated: false, vix: 17, rsi: 55, obv: 'accumulation' };

test('cas de base : stop, taille et charge se dérivent à la main', () => {
  const r = computeSizing(base);
  assert.equal(r.stopDist, 10, 'ATR 5 × multiplicateur 2');
  assert.equal(r.stopPrice, 90, 'entrée 100 − 10');
  assert.equal(r.riskAmount, 500, '1 % de 50 000 $');
  assert.equal(r.shares, 50, '500 $ de risque ÷ 10 $ de distance');
  assert.equal(r.thisTradeHeat, 1);
  assert.deepEqual(r.reasons, []);
});

test('les discounts sont MULTIPLICATIFS, pas additifs', () => {
  // C'est la propriété qui compte : deux conditions défavorables réduisent
  // davantage que la somme de leurs effets pris séparément.
  const correle = computeSizing({ ...base, correlated: true });          // ×0,5
  const vixHaut = computeSizing({ ...base, vix: 25 });                    // ×0,75
  const lesDeux = computeSizing({ ...base, correlated: true, vix: 25 });  // ×0,375
  assert.equal(correle.riskAmount, 250);
  assert.equal(vixHaut.riskAmount, 375);
  assert.equal(lesDeux.riskAmount, 187.5);
  assert.equal(lesDeux.riskAmount, 500 * 0.5 * 0.75, 'produit des deux facteurs, pas leur somme');
  // Additifs, on aurait retiré 250 + 125 = 375 (reste 125). Multiplicatifs,
  // il reste 187,50 — davantage. Les deux modèles ne coïncident jamais.
  assert.notEqual(lesDeux.riskAmount, 500 - 250 - 125);
});

test('le VIX en panique remplace le discount de nervosité, il ne s’y ajoute pas', () => {
  // Les deux branches sont exclusives (if/else) : un VIX à 35 ne doit pas
  // subir 0,75 × 0,5.
  const panique = computeSizing({ ...base, vix: 35 });
  assert.equal(panique.riskAmount, 250, '500 × 0,5 seulement');
});

test('la taille est arrondie vers le BAS', () => {
  // Arrondir au supérieur ferait dépasser le risque voulu — sur un outil de
  // sizing, c'est le sens de l'arrondi qui compte, pas sa précision.
  const r = computeSizing({ ...base, atr: 3, atrMult: 1 }); // 500 / 3 = 166,67
  assert.equal(r.shares, 166);
});

test('une distance de stop nulle ne produit pas d’Infinity', () => {
  const r = computeSizing({ ...base, atr: 0 });
  assert.equal(r.shares, 0, 'zéro action, pas une division par zéro');
  assert.ok(Number.isFinite(r.totalHeat));
});

test('la charge existante s’ajoute à celle du trade', () => {
  const r = computeSizing({ ...base, heatExist: 4.5 });
  assert.equal(r.totalHeat, 5.5);
  assert.equal(r.depasseAvertissement, true, 'au-delà de 4 %');
  assert.equal(r.depasseAlerte, false, 'mais sous 6 %');
});

test('le seuil d’alerte est ce qui grise un candidat dans le screening', () => {
  const r = computeSizing({ ...base, heatExist: 5.5 });
  assert.equal(r.totalHeat, 6.5);
  assert.equal(r.depasseAlerte, true);
});

test('les raisons de réduction sont nommées, pas seulement appliquées', () => {
  // Une taille réduite sans explication est indistinguable d'un bug.
  const r = computeSizing({ ...base, correlated: true, vix: 35, rsi: 80, obv: 'distribution' });
  assert.deepEqual(r.reasons, ['corrélation', 'VIX', 'surachat', 'divergence OBV']);
});

test('un RSI sain et un OBV en accumulation ne réduisent rien', () => {
  const r = computeSizing({ ...base, rsi: 45, obv: 'accumulation' });
  assert.equal(r.riskAmount, 500);
  assert.deepEqual(r.reasons, []);
});

// ---- Plafond de capital (audit formules, 20/10/2026, constat 1) --------------------------------------------------
// Avant : shares = floor(risque ÷ distance du stop), sans aucune borne par le capital. Un titre calme (ATR petit devant
// le prix) donnait une position supérieure au compte — 133 % du capital à 0,5 % d'ATR — sans la moindre alerte.

const calme = { capital: 100000, riskPct: 1, heatExist: 0, entry: 40, atr: 0.22, atrMult: 1.5, correlated: false, vix: 17, rsi: 55, obv: 'accumulation' };

test('titre très calme : la taille est plafonnée au capital au lieu de le dépasser', () => {
  const r = computeSizing(calme);
  assert.equal(r.stopDist, 0.33 * 1, 'ATR 0,22 × 1,5');
  assert.equal(r.sharesParRisque, 3030, 'le risque seul donnerait 3 030 actions = 121 200 $ (121 % du capital)');
  assert.equal(r.shares, 2500, '100 000 $ ÷ 40 $ = 2 500 actions au plus');
  assert.equal(r.plafonneParCapital, true);
  assert.equal(r.valeurPosition, 100000);
  assert.equal(r.pctCapital, 100);
  assert.ok(r.reasons.includes('capital'));
});

test('plafonnée, la position risque MOINS que le budget : le risque et la charge sont ceux de la position réelle', () => {
  const r = computeSizing(calme);
  assert.equal(r.riskAmount, 1000, 'le budget de risque ne change pas : 1 % de 100 000 $');
  assert.ok(Math.abs(r.riskEngage - 2500 * 0.33) < 1e-9, '2 500 actions × 0,33 $ = 825 $ engagés si le stop est touché');
  assert.ok(Math.abs(r.thisTradeHeat - 0.825) < 1e-9, 'la charge suit le risque réel (0,825 %), pas le budget');
});

test('cas ordinaire : aucun plafond, comportement inchangé', () => {
  const r = computeSizing(base);
  assert.equal(r.plafonneParCapital, false);
  assert.equal(r.shares, r.sharesParRisque);
  assert.equal(r.riskEngage, r.riskAmount);
  assert.equal(r.valeurPosition, 5000);
  assert.equal(r.pctCapital, 10);
  assert.ok(!r.reasons.includes('capital'));
});

test('pile à la limite : pas de plafond quand le risque donne exactement le maximum permis', () => {
  // capital 10 000, entrée 100 -> au plus 100 actions ; risque 1 % = 100 $, stop 1 $ -> 100 actions.
  const r = computeSizing({ ...base, capital: 10000, entry: 100, atr: 1, atrMult: 1 });
  assert.equal(r.sharesParRisque, 100);
  assert.equal(r.shares, 100);
  assert.equal(r.plafonneParCapital, false);
});

test('le plafond est réglable (CFG.sizing.positionMaxPct)', () => {
  CFG.sizing.positionMaxPct = 25;
  try {
    const r = computeSizing(calme);
    assert.equal(r.shares, 625, '25 % de 100 000 $ = 25 000 $ ÷ 40 $');
    assert.equal(r.plafonneParCapital, true);
    assert.equal(r.valeurPosition, 25000);
    assert.equal(r.positionMaxPct, 25);
  } finally { delete CFG.sizing.positionMaxPct; }
});

test('sans prix d\'entrée, pas de plafond (la valeur ne se calcule pas) et rien d\'inventé', () => {
  const r = computeSizing({ ...calme, entry: NaN });
  assert.equal(r.plafonneParCapital, false);
  assert.equal(r.valeurPosition, null);
  assert.equal(r.pctCapital, null);
});

test('stop nul ou capital nul : zéro action, jamais NaN ni infini', () => {
  assert.equal(computeSizing({ ...base, atr: 0 }).shares, 0);
  assert.equal(computeSizing({ ...base, capital: 0 }).shares, 0);
});

test('PROPRIÉTÉ : sur 5 000 cas tirés au hasard, la valeur de la position ne dépasse jamais le capital permis', () => {
  let s = 123456789; // générateur déterministe : le test se rejoue à l'identique
  const rnd = () => { s = (s * 1664525 + 1013904223) % 4294967296; return s / 4294967296; };
  let plafonnes = 0;
  for (let i = 0; i < 5000; i++) {
    const entry = 2 + rnd() * 998;
    const input = { capital: 5000 + rnd() * 995000, riskPct: 0.25 + rnd() * 2.75, heatExist: rnd() * 5, entry,
      atr: entry * (0.001 + rnd() * 0.06), atrMult: 1 + rnd() * 2, correlated: rnd() < 0.3, vix: 10 + rnd() * 30, rsi: 20 + rnd() * 70,
      obv: ['accumulation', 'neutre', 'distribution'][Math.floor(rnd() * 3)] };
    const r = computeSizing(input);
    assert.ok(r.shares >= 0 && Number.isInteger(r.shares), `actions entières et positives (cas ${i})`);
    assert.ok(r.valeurPosition <= input.capital + 1e-6, `la position (${r.valeurPosition}) dépasse le capital (${input.capital}) au cas ${i}`);
    assert.ok(r.shares <= r.sharesParRisque, 'le plafond ne fait que réduire');
    assert.ok(r.riskEngage <= r.riskAmount + 1e-9, 'le risque réel ne dépasse jamais le budget');
    if (r.plafonneParCapital) plafonnes++;
  }
  assert.ok(plafonnes > 100 && plafonnes < 4900, `le tirage doit exercer les deux branches (plafonné ${plafonnes} fois sur 5 000)`);
});

test('sizingCapNote : null si pas plafonné, sinon une phrase avec les vrais chiffres', () => {
  assert.equal(sizingCapNote(computeSizing(base)), null);
  assert.equal(sizingCapNote(null), null);
  const note = sizingCapNote(computeSizing(calme));
  assert.match(note, /3030 actions/);
  assert.match(note, /2500 actions/);
  assert.match(note, /100 % du capital/);
});
