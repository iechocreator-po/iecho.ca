// Photographie les NOMS GLOBAUX des pages et leur contenu (source de chaque fonction, valeur des variables) APRÈS démarrage,
// pour prouver qu'un déplacement de code entre fichiers (découpage des index.html, phase 2) ne change rien de ce que la page
// expose : même ensemble de noms, même source de fonction, mêmes valeurs d'état.
//
// Usage : node scripts/snapshot-globals.mjs <sortie.json>
//         node scripts/snapshot-globals.mjs --compare <a.json> <b.json>
//
// Les noms viennent des déclarations en tête de ligne (`function x`, `const|let|var x`) de TOUS les scripts de la page,
// en ligne ou chargés (même convention que server/browser-globals.test.js). Chaque nom est lu par un eval indirect, donc
// les const/let (non visibles sur `window`) sont inclus. Mêmes limites que snapshot-styles : API bouchonnée, états sans données.
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { findChrome, launchChrome, startServer, PAGES } from './smoke-browser.mjs';

// Valeurs qui dépendent du moment ou des erreurs réseau bouchonnées, pas du code : ignorées à la comparaison.
const VOLATILE = new Set(['seenErrors']);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const DECL = /^(?:async\s+)?(?:function\*?\s+([A-Za-z_$][\w$]*)|(?:const|let|var)\s+([A-Za-z_$][\w$]*))/gm;

function namesOf(root) {
  const html = readFileSync(join(root, 'index.html'), 'utf8');
  const names = new Set();
  const scan = (code) => { for (const m of code.matchAll(DECL)) names.add(m[1] || m[2]); };
  for (const m of html.matchAll(/<script>([\s\S]*?)<\/script>/g)) scan(m[1]);
  for (const [, src] of html.matchAll(/<script src="([^"]+\.js)"/g)) {
    if (/^https?:/.test(src)) continue;
    const f = join(root, src);
    if (existsSync(f)) scan(readFileSync(f, 'utf8'));
  }
  return [...names].sort();
}

const PROBE = (names) => `(() => {
  const h = (s) => { let x = 5381; for (let i = 0; i < s.length; i++) x = ((x << 5) + x + s.charCodeAt(i)) | 0; return (x >>> 0).toString(36); };
  const rep = (k, v) => (v instanceof Set ? { __set: [...v] } : v instanceof Map ? { __map: [...v] } : typeof v === 'function' ? 'fn:' + h(String(v)) : v);
  const out = {};
  for (const n of ${JSON.stringify(names)}) {
    try {
      const t = (0, eval)('typeof ' + n);
      if (t === 'undefined') { out[n] = 'undefined'; continue; }
      const v = (0, eval)(n);
      out[n] = t === 'function' ? 'function:' + h(String(v)) : t + ':' + h(JSON.stringify(v, rep) ?? 'undefined');
    } catch (e) { out[n] = 'erreur:' + String(e.message).slice(0, 60); }
  }
  return out;
})()`;

async function snapshot({ root, label, authenticated, chromePath }) {
  const names = namesOf(root);
  const { server, origin } = await startServer(root, { authenticated });
  const chrome = await launchChrome(chromePath);
  try {
    const { targetId } = await chrome.send('Target.createTarget', { url: 'about:blank' });
    const { sessionId } = await chrome.send('Target.attachToTarget', { targetId, flatten: true });
    const send = (m, p) => chrome.send(m, p, sessionId);
    let loaded; const loadedP = new Promise((ok) => { loaded = ok; });
    chrome.on((m) => { if (m.sessionId === sessionId && m.method === 'Page.loadEventFired') loaded(); });
    for (const d of ['Runtime', 'Page']) await send(`${d}.enable`);
    await send('Page.navigate', { url: `${origin}/` });
    await Promise.race([loadedP, sleep(20000)]);
    await sleep(3000);
    const r = await send('Runtime.evaluate', { expression: PROBE(names), returnByValue: true });
    if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
    return { names: names.length, values: r.result.value };
  } finally { await chrome.close(); server.close(); }
}

if (process.argv[2] === '--compare') {
  const a = JSON.parse(readFileSync(process.argv[3], 'utf8')); const b = JSON.parse(readFileSync(process.argv[4], 'utf8'));
  let diffs = 0; let compared = 0;
  for (const page of Object.keys(a)) {
    const A = a[page].values; const B = (b[page] || {}).values || {};
    for (const n of new Set([...Object.keys(A), ...Object.keys(B)])) {
      if (VOLATILE.has(n)) continue;
      compared++;
      if (A[n] !== B[n]) { diffs++; if (diffs <= 25) console.log(`DIFFÉRENT : ${page} / ${n} : ${A[n]} -> ${B[n]}`); }
    }
  }
  console.log(`${compared} noms comparés, ${diffs} différence(s).`);
  process.exit(diffs ? 1 : 0);
} else if (process.argv[2]) {
  const chromePath = findChrome();
  if (!chromePath) { console.error('Aucun Chrome trouvé (CHROME_PATH).'); process.exit(2); }
  const all = {};
  for (const p of PAGES) {
    all[p.label] = await snapshot({ ...p, chromePath });
    const v = Object.values(all[p.label].values);
    console.log(`${p.label} : ${all[p.label].names} noms (${v.filter((x) => x.startsWith('function')).length} fonctions, ${v.filter((x) => x === 'undefined').length} non définis, ${v.filter((x) => x.startsWith('erreur')).length} en erreur)`);
  }
  writeFileSync(process.argv[2], JSON.stringify(all, null, 0));
  console.log('Écrit :', process.argv[2]);
} else { console.error('Usage : node scripts/snapshot-globals.mjs <sortie.json> | --compare <a.json> <b.json>'); process.exit(2); }
