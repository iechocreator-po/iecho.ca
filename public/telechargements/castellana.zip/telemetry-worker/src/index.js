// castellana-telemetry — collecteur de télémétrie (6/9/2026)
//
// Contexte : castellana tourne en local chez chaque testeur (aucun serveur
// partagé, décision JP), donc ce petit Worker est le SEUL point de collecte
// centralisé. Le navigateur de chaque testeur poste directement ici
// (js/telemetry.js de castellana) — server/index.js n'est pas impliqué.
//
// Worker natif, zéro framework (Hono, itty-router, etc.) — 3 routes, pas
// besoin d'un routeur pour ça, cohérent avec la discipline zéro-dépendance
// du reste du portfolio pour ce type d'outil (voir launcher/server.js).
//
// Sécurité — À NE PAS SURESTIMER : `TELEMETRY_TOKEN` (wrangler.jsonc `vars`,
// doit rester identique à CFG.telemetry.sharedToken dans config.js côté
// castellana) n'est PAS une vraie authentification. C'est un filtre
// anti-bruit pour qu'un bot qui découvrirait cette URL publique (par
// définition, tout Worker Cloudflare est joignable depuis Internet) ne
// pollue pas la base avec des faux événements. Le jeton est visible dans le
// code source du navigateur de castellana — quiconque a accès à castellana
// peut le lire. Si un vrai contrôle d'accès devient nécessaire un jour,
// voir T3 (login) dans CLAUDE.md — ce Worker n'en fait pas partie pour
// l'instant.

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*', // chaque testeur a une origine locale différente (127.0.0.1:4700 chez l'un, localhost:4700 chez l'autre) — le filtrage se fait par jeton, pas par origine
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, X-Telemetry-Token',
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...CORS_HEADERS },
  });
}

function checkToken(request, env, url) {
  const header = request.headers.get('X-Telemetry-Token');
  const queryToken = url.searchParams.get('token');
  const provided = header || queryToken;
  return Boolean(env.TELEMETRY_TOKEN) && provided === env.TELEMETRY_TOKEN;
}

const KNOWN_EVENT_TYPES = new Set(['app_loaded', 'ticker_selected', 'param_changed']);

function validateEvent(ev) {
  if (!ev || typeof ev !== 'object') return 'événement absent ou invalide';
  if (typeof ev.who !== 'string' || !ev.who) return 'champ "who" manquant';
  if (typeof ev.event_type !== 'string' || !KNOWN_EVENT_TYPES.has(ev.event_type)) {
    return `event_type inconnu : ${JSON.stringify(ev.event_type)}`;
  }
  return null;
}

async function handleEvents(request, env, ip) {
  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: 'JSON invalide' }, 400);
  }
  const events = Array.isArray(body?.events) ? body.events : [body];
  if (events.length === 0) return json({ error: 'aucun événement' }, 400);
  if (events.length > 50) return json({ error: 'trop d\'événements dans un seul envoi (max 50)' }, 400);

  const now = new Date().toISOString();
  const stmt = env.DB.prepare(
    'INSERT INTO telemetry_events (created_at, who, ip, event_type, payload_json, user_agent) VALUES (?, ?, ?, ?, ?, ?)'
  );
  const batch = [];
  for (const ev of events) {
    const err = validateEvent(ev);
    if (err) return json({ error: err }, 400);
    batch.push(stmt.bind(now, ev.who, ip, ev.event_type, JSON.stringify(ev.payload ?? {}), ev.ua ?? null));
  }
  await env.DB.batch(batch);
  return json({ ok: true, inserted: batch.length });
}

function csvEscape(v) {
  if (v == null) return '';
  const s = String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

async function handleCsv(env) {
  const { results } = await env.DB
    .prepare('SELECT id, created_at, who, ip, event_type, payload_json, user_agent FROM telemetry_events ORDER BY id DESC LIMIT 5000')
    .all();
  const cols = ['id', 'created_at', 'who', 'ip', 'event_type', 'payload_json', 'user_agent'];
  const lines = [cols.join(',')];
  for (const row of results) lines.push(cols.map((c) => csvEscape(row[c])).join(','));
  return new Response(lines.join('\n'), {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="castellana-telemetry-${Date.now()}.csv"`,
      ...CORS_HEADERS,
    },
  });
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

async function handleDashboard(env) {
  const { results } = await env.DB
    .prepare('SELECT id, created_at, who, ip, event_type, payload_json FROM telemetry_events ORDER BY id DESC LIMIT 200')
    .all();
  const rows = results
    .map(
      (r) => `<tr><td>${r.id}</td><td>${escapeHtml(r.created_at)}</td><td>${escapeHtml(r.who)}</td><td>${escapeHtml(r.ip ?? '')}</td><td>${escapeHtml(r.event_type)}</td><td><code>${escapeHtml(r.payload_json)}</code></td></tr>`
    )
    .join('\n');
  const html = `<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><title>castellana — télémétrie</title>
<style>
  body { font-family: system-ui, sans-serif; margin: 2rem; background: #0f1115; color: #e6e6e6; }
  table { border-collapse: collapse; width: 100%; font-size: 13px; }
  th, td { border: 1px solid #333; padding: 4px 8px; text-align: left; vertical-align: top; }
  th { background: #1a1d24; position: sticky; top: 0; }
  code { font-size: 11px; color: #9fd3ff; }
  h1 { font-size: 16px; }
</style></head>
<body>
  <h1>castellana — 200 derniers événements de télémétrie</h1>
  <p>Export complet : <code>/events.csv?token=...</code></p>
  <table>
    <thead><tr><th>id</th><th>quand (serveur)</th><th>qui</th><th>ip</th><th>type</th><th>détail</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>
</body></html>`;
  return new Response(html, { headers: { 'Content-Type': 'text/html; charset=utf-8', ...CORS_HEADERS } });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: CORS_HEADERS });
    }

    if (request.method === 'POST' && url.pathname === '/events') {
      if (!checkToken(request, env, url)) return json({ error: 'jeton invalide ou absent' }, 401);
      const ip = request.headers.get('cf-connecting-ip') || 'inconnue';
      return handleEvents(request, env, ip);
    }

    if (request.method === 'GET' && url.pathname === '/events.csv') {
      if (!checkToken(request, env, url)) return json({ error: 'jeton invalide ou absent' }, 401);
      return handleCsv(env);
    }

    if (request.method === 'GET' && url.pathname === '/dashboard') {
      if (!checkToken(request, env, url)) return json({ error: 'jeton invalide ou absent (ajouter ?token=...)' }, 401);
      return handleDashboard(env);
    }

    return json({ error: 'not found' }, 404);
  },
};
