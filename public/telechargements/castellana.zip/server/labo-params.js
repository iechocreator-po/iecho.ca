// Paramètres des stratégies d'options (onglet Labo), éditables par l'utilisateur.
//
// Même patron que server/preferences.js : stockage EN BASE (survit aux mises
// à jour de l'app, qui ne touchent jamais à `data/`), reset = suppression des
// lignes plutôt que réécriture des défauts.
//
// Seules les SURCHARGES sont stockées (clé → valeur), jamais les valeurs
// effectives : un changement futur d'un défaut profite à qui n'a rien touché.
// Les défauts et les règles de validation vivent dans js/labo-schema.js,
// évalué ici comme le fait server/sizing.test.js — le navigateur, ce serveur
// et le Worker cloud partagent ainsi UNE définition.
//
// `kind` et `definition_json` sont RÉSERVÉS aux futures stratégies
// personnalisées : rien ne les écrit aujourd'hui, mais la table n'aura pas à
// être migrée le jour où l'utilisateur pourra créer les siennes.

import { readFileSync } from 'node:fs';
import { db } from './db.js';

const source = readFileSync(new URL('../js/labo-schema.js', import.meta.url), 'utf8');
export const schema = new Function(
  `${source}; return { LABO_SCHEMA, laboResolveStrategy, laboDefaults, laboEffectiveParams, laboMergeOverrides };`,
)();

db.exec(`
  CREATE TABLE IF NOT EXISTS strategy_params (
    strategy_id TEXT PRIMARY KEY,
    kind TEXT NOT NULL DEFAULT 'builtin',
    params_json TEXT NOT NULL,
    definition_json TEXT,
    schema_version INTEGER NOT NULL,
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

function fail(errors) {
  const err = new Error(errors.join(' '));
  err.code = 'INVALID_LABO_PARAMS';
  err.errors = errors;
  return err;
}

function readRow(id) {
  const row = db.prepare('SELECT params_json FROM strategy_params WHERE strategy_id = ?').get(id);
  if (!row) return {};
  try { return JSON.parse(row.params_json) || {}; } catch { return {}; }
}

// { roue: { putDteMin: 20 }, … } — uniquement les stratégies qui ont au moins
// une surcharge. Les clés qui ne sont plus dans le schéma sont écartées
// plutôt que renvoyées : une valeur orpheline ne doit pas réapparaître.
export function getAllOverrides() {
  const out = {};
  const rows = db.prepare('SELECT strategy_id, params_json, updated_at FROM strategy_params').all();
  for (const row of rows) {
    if (!schema.laboResolveStrategy(row.strategy_id)) continue;
    let parsed = {};
    try { parsed = JSON.parse(row.params_json) || {}; } catch { continue; }
    const known = schema.laboDefaults(row.strategy_id);
    const clean = {};
    for (const [k, v] of Object.entries(parsed)) if (k in known) clean[k] = v;
    if (Object.keys(clean).length) out[row.strategy_id] = clean;
  }
  return out;
}

export function setStrategyParams(id, values) {
  const { errors, overrides } = schema.laboMergeOverrides(id, readRow(id), values);
  if (errors.length) throw fail(errors);
  if (Object.keys(overrides).length === 0) {
    db.prepare('DELETE FROM strategy_params WHERE strategy_id = ?').run(id);
  } else {
    db.prepare(`
      INSERT INTO strategy_params (strategy_id, params_json, schema_version, updated_at)
      VALUES (?, ?, ?, datetime('now'))
      ON CONFLICT(strategy_id) DO UPDATE SET
        params_json = excluded.params_json,
        schema_version = excluded.schema_version,
        updated_at = excluded.updated_at
    `).run(id, JSON.stringify(overrides), schema.LABO_SCHEMA.version);
  }
  return getAllOverrides();
}

export function resetStrategyParams(id) {
  if (!schema.laboResolveStrategy(id)) throw fail([`Stratégie inconnue ou sans paramètres : ${id}`]);
  db.prepare('DELETE FROM strategy_params WHERE strategy_id = ?').run(id);
  return getAllOverrides();
}

export function resetAllStrategyParams() {
  db.prepare('DELETE FROM strategy_params').run();
  return {};
}

// Valeurs effectives (défauts ⊕ surcharges) d'une stratégie — réutilisé côté
// serveur par la grille de rendement annualisé et le screener de primes
// (22/9/2026, Options A/Journal A) pour le taux sans risque et la taille de
// contrat, sans dupliquer la lecture de strategy_params.
export function getEffectiveParams(id) {
  return schema.laboEffectiveParams(id, readRow(id));
}
