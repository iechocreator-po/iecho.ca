// Orchestration du screening (11/9/2026) — sortie de server/index.js, qui
// dépassait 750 lignes, et étendue à un second univers.
//
// LE PROBLÈME RÉSOLU : le screening ne regardait que la watchlist de JP, soit
// 22 titres. Mesuré le 11/9/2026 : **2 en setup d'entrée ce jour-là**. Un
// outil qui ne balaie que ce que son utilisateur suit déjà ne peut pas, par
// construction, lui faire découvrir une position — il classe, il ne génère
// pas.
//
// Or 210 titres curés dormaient déjà dans le code : `SECTOR_TOP_CANDIDATES`
// (server/sectors.js), vérifiés un par un contre la classification réelle de
// Yahoo le 2/9/2026, et qui ne servaient qu'à afficher « top du secteur ».
// Passés dans la même logique : 19 en setup, 9 signaux frais, dont 8 hors
// watchlist — et répartis sur 7 secteurs, là où la watchlist tech/IA produit
// structurellement des candidats corrélés entre eux.
//
// DEUX TEMPS, ET C'EST UNE MESURE QUI LE DICTE : les fondamentaux coûtent un
// `quoteSummary` par titre, soit ~16 s pour 210 à froid, contre ~4 s pour les
// historiques seuls. On filtre donc AVANT d'enrichir — les fondamentaux ne
// partent que sur les titres retenus (~19), jamais sur les 210.

import { getWatchlist } from './watchlist.js';
import { getListById } from './lists.js';
import { SECTOR_TOP_CANDIDATES, SECTOR_DEFS } from './sectors.js';
import { getRelativeStrength, BENCHMARK_SYMBOL } from './quotes.js';
import { getHomemadeIndicatorsBatch, fetchDailyHistory } from './indicators.js';
import { mapWithConcurrency } from './fetch-retry.js';
import { getFundamentalsBatch } from './fundamentals.js';
import { scoreRow, SIGNAL_AGE } from './scoring.js';
import { getPreferences, indicatorOptions } from './preferences.js';
import { readFileSync } from 'node:fs';

// S&P 500 (7/10/2026) — liste figée (data : Wikipedia, 7/10/2026), pour le
// balayage local (server/sweep.js). À rafraîchir à la main quand l'indice change.
export const SP500 = JSON.parse(readFileSync(new URL('./sp500.json', import.meta.url), 'utf8'));
export const SP500_TICKERS = SP500.tickers.map((t) => t.ticker);

export const UNIVERS = ['watchlist', 'elargi', 'mag7', 'sp500'];

// Listes personnalisées (12/9/2026) : univers DYNAMIQUE `list:<id>`, en plus
// des trois univers fixes ci-dessus — UNIVERS.includes(...) seul ne peut pas
// les valider (id imprévisible). Toute route qui accepte un `universe` de
// requête doit utiliser cette fonction, pas UNIVERS.includes() directement.
export function isValidUniverse(universe) {
  return UNIVERS.includes(universe) || /^list:\d+$/.test(String(universe));
}

// MAG7 (12/9/2026, T5 — demande de JP) : liste fixe, pas encore une vraie
// gestion de plusieurs listes personnalisées (feature future, voir
// CLAUDE.md). GOOGL plutôt que GOOG — même entreprise (Alphabet), classe
// d'action différente — choisi arbitrairement, les deux cotent quasi
// identiquement.
export const MAG7_TICKERS = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'NVDA', 'META', 'TSLA'];

// Clé de cache par univers. `screening:last` reste la clé de la watchlist —
// inchangée à dessein : l'export CSV et le calcul du « P/E industrie » d'un
// ticker hors watchlist s'appuient dessus, et un renommage les aurait fait
// repartir de zéro sans raison.
export const SCREENING_KEY = 'screening:last';
// Performance en % des titres retenus, pour le graphique de l'onglet Screener
// (21/9/2026) — réutilise l'IDÉE du graphique de l'onglet Secteurs (ligne de
// performance cumulée, légende cliquable), appliquée aux tickers du dernier
// screening plutôt qu'aux 11 secteurs.
//
// `fetchDailyHistory()` est DÉJÀ appelée par `getHomemadeIndicatorsBatch()`
// pendant le screening lui-même (même clé de cache `history:TICKER:420`,
// même TTL) — cette fonction ne fait donc, dans le cas courant, RELIRE le
// cache que le screening venait de remplir : pas d'appel Yahoo supplémentaire
// pour la majorité des titres affichés.

const TICKER_PARAM_RE = /^[A-Z0-9.^-]{1,10}$/;

// Pure — testable sans réseau : valide/dédoublonne/plafonne la liste de
// tickers reçue en query string. Séparée de la route pour ne pas laisser ce
// morceau de validation (le seul non tributaire du réseau) sans aucun test,
// comme documenté ailleurs dans ce fichier pour scoring/sizing.
export function parseTickersParam(raw, { max = 40 } = {}) {
  const list = String(raw ?? '')
    .split(',')
    .map((s) => s.trim().toUpperCase())
    .filter(Boolean);
  const unique = [...new Set(list)];
  if (unique.length === 0) {
    throw Object.assign(new Error('paramètre "tickers" requis (liste séparée par des virgules)'), { status: 400 });
  }
  if (unique.length > max) {
    throw Object.assign(new Error(`${max} titres maximum par appel (reçu ${unique.length})`), { status: 400 });
  }
  const invalid = unique.find((t) => !TICKER_PARAM_RE.test(t));
  if (invalid) {
    throw Object.assign(new Error(`symbole invalide : "${invalid}"`), { status: 400 });
  }
  return unique;
}

export async function getScreeningPerformance(tickers) {
  return mapWithConcurrency(tickers, async (ticker) => {
    try {
      const bars = await fetchDailyHistory(ticker);
      const history = bars
        .filter((b) => b.close != null && b.date)
        .map((b) => ({ date: b.date.toISOString().slice(0, 10), close: b.close }));
      return { ticker, history, error: null };
    } catch (err) {
      return { ticker, history: [], error: err.message };
    }
  }, { limit: 6 });
}

export function screeningCacheKey(universe) {
  if (universe === 'elargi') return `${SCREENING_KEY}:elargi`;
  if (universe === 'mag7') return `${SCREENING_KEY}:mag7`;
  if (universe === 'sp500') return `${SCREENING_KEY}:sp500`;
  if (String(universe).startsWith('list:')) return `${SCREENING_KEY}:${universe}`;
  return SCREENING_KEY;
}

// Seuils des filtres supplémentaires (feature 322) — dupliqués de config.js
// (CFG.screening) faute de format de module commun entre le frontend
// classique et ce backend ESM. Reporter à la main tout changement.
export const SCREEN_FILTERS = {
  prixMin: 5,
  prixMax: 1000,
  floatMinM: 10,
  floatMaxM: 20,
  volumeMin: 1_000_000,
  pegMax: 1,
  betaMin: 1,
  earningsMinJours: 7,
  calculerVwap: true,
};

// Drapeaux pass/fail par critère, pour une ligne enrichie de fondamentaux.
// `null` = donnée absente : ni pass ni fail. Les deux axes de score
// n'utilisent PAS ces drapeaux — ils servent au filtrage optionnel de
// l'univers côté frontend.
export function fundamentalFlags(row) {
  const floatM = row.floatShares != null ? row.floatShares / 1_000_000 : null;
  return {
    passPrix: row.price != null ? (row.price >= SCREEN_FILTERS.prixMin && row.price <= SCREEN_FILTERS.prixMax) : null,
    passFloat: floatM != null ? (floatM >= SCREEN_FILTERS.floatMinM && floatM <= SCREEN_FILTERS.floatMaxM) : null,
    passVolume: row.volume != null ? row.volume >= SCREEN_FILTERS.volumeMin : null,
    passPeg: row.pegRatio != null ? row.pegRatio <= SCREEN_FILTERS.pegMax : null,
    passBeta: row.beta != null ? row.beta > SCREEN_FILTERS.betaMin : null,
    passVwap: row.aboveVwap, // déjà un booléen/null (prix > VWAP)
    // `null` (date inconnue, FNB…) plutôt que `false` : « on ne sait pas »
    // n'est pas « c'est risqué ».
    passEarnings: row.daysToEarnings != null ? row.daysToEarnings >= SCREEN_FILTERS.earningsMinJours : null,
  };
}

// Index ticker → NOM du secteur, construit une fois. Sert à afficher le
// secteur d'un candidat : sans lui, impossible de voir d'un coup d'œil que
// les cinq premiers résultats sont cinq titres du même secteur — le risque
// que l'univers élargi est justement censé réduire.
//
// On stocke le libellé lisible (« Finance ») et non la clé de l'ETF
// (« XLF ») : le tableau est lu par un humain, pas par un script.
const SECTEUR_DE = (() => {
  const libelle = new Map(SECTOR_DEFS.map((d) => [d.key, d.label]));
  const m = new Map();
  for (const [cle, tickers] of Object.entries(SECTOR_TOP_CANDIDATES)) {
    for (const t of tickers) if (!m.has(t)) m.set(t, libelle.get(cle) ?? cle);
  }
  for (const t of SP500.tickers) if (!m.has(t.ticker)) m.set(t.ticker, t.sector); // secteur GICS (anglais) pour le reste du S&P 500
  return m;
})();

// Exporté (22/9/2026) pour le screener de primes (Journal A, #8) — qui
// réutilise la même résolution watchlist/mag7/liste perso, mais REFUSE
// volontairement 'elargi' (voir isPremiumUniverse dans premium-screener.js) :
// 219 titres × un appel de chaîne d'options chacun reproduirait le bug de
// sous-requêtes Cloudflare déjà heurté le 12/9/2026 sur ce même univers.
export function universeTickers(universe) {
  if (universe === 'elargi') {
    // Les titres suivis EN PLUS des candidats sectoriels : JP doit retrouver
    // ses propres titres dans l'univers élargi, pas devoir basculer pour
    // les voir.
    const suivis = getWatchlist().map((w) => w.ticker);
    return [...new Set([...Object.values(SECTOR_TOP_CANDIDATES).flat(), ...suivis])];
  }
  if (universe === 'mag7') return MAG7_TICKERS;
  if (universe === 'sp500') return SP500_TICKERS;
  if (universe.startsWith('list:')) {
    const list = getListById(Number(universe.slice('list:'.length)));
    return list ? list.tickers.map((t) => t.ticker) : [];
  }
  return getWatchlist().map((w) => w.ticker);
}

// Un titre mérite-t-il qu'on dépense un appel de fondamentaux pour lui ?
//
// Uniquement pertinent pour l'univers élargi : sur la watchlist, JP veut
// voir SES titres qu'ils soient en setup ou non, et 22 appels ne coûtent
// rien. Sur 210, garder tout reviendrait à afficher 190 lignes de bruit et à
// payer 16 s pour les enrichir.
function meriteEnrichissement(hm) {
  return hm && !hm.error && hm.smaAlignment === 'haussier';
}

/**
 * Coeur du screening, sur une liste de titres explicite.
 *
 * Extrait de buildScreening() le 11/9/2026, quand la carte « Titres les plus
 * performants du secteur » a dû porter LES MÊMES COLONNES que le tableau de
 * screening (demande de JP). Deux choix possibles : recopier la vingtaine de
 * champs dans sectors.js, ou faire passer les candidats du secteur par ce
 * pipeline. Recopier aurait créé une TROISIÈME duplication documentée dans ce
 * projet (après SCORE_BANDS et SCREEN_FILTERS) — et la plus coûteuse, puisque
 * les deux tableaux sont censés être identiques et se liraient côte à côte.
 *
 * @param {string[]} tickers
 * @param {{ filtrerAvantEnrichissement?: boolean }} options
 *   filtrerAvantEnrichissement : n'enrichir de fondamentaux que les titres en
 *   setup haussier. Vrai seulement pour l'univers élargi (210 titres) — sur
 *   une vingtaine, l'économie est nulle et on veut toutes les lignes.
 */
// Médiane — plus robuste que la moyenne pour un P/S, où un seul titre à 70×
// (PLTR) tirerait la moyenne d'un secteur entier vers le haut.
function median(values) {
  const v = values.filter((x) => x != null && Number.isFinite(x)).sort((a, b) => a - b);
  if (!v.length) return null;
  const mid = Math.floor(v.length / 2);
  return v.length % 2 ? v[mid] : (v[mid - 1] + v[mid]) / 2;
}

// P/S « du secteur » — approximation par pairs, comme le P/E industrie : médiane
// du P/S des titres DE CE SCREENING partageant le même secteur Yahoo (pour la
// carte « Titres les plus performants du secteur », ce sont les titres suivis
// du secteur cliqué). Sous 3 pairs la comparaison ne veut rien dire → null.
const PS_MIN_PEERS = 3;
function sectorPsStats(fundamentalRows) {
  const bySector = new Map();
  for (const f of fundamentalRows) {
    if (!f.sector || f.priceToSales == null) continue;
    if (!bySector.has(f.sector)) bySector.set(f.sector, []);
    bySector.get(f.sector).push(f.priceToSales);
  }
  return new Map([...bySector.entries()].map(([sector, values]) => [
    sector,
    { medianPS: values.length >= PS_MIN_PEERS ? median(values) : null, peerCount: values.length },
  ]));
}

async function screenTickers(tickers, { filtrerAvantEnrichissement = false } = {}) {
  // --- Temps 1 : ce qui est bon marché ---------------------------------
  // Force relative (UNE requête groupée pour tout l'univers + SPY) et
  // indicateurs maison (un historique par titre, parallélisme borné).
  const [rsResult, homemadeResult] = await Promise.allSettled([
    getRelativeStrength(tickers),
    getHomemadeIndicatorsBatch(tickers, indicatorOptions()),
  ]);

  if (rsResult.status === 'rejected' && homemadeResult.status === 'rejected') {
    const err = new Error('Aucune source de données joignable');
    err.passErrors = {
      forceRelative: rsResult.reason?.message ?? null,
      indicateurs: homemadeResult.reason?.message ?? null,
      fondamentaux: null,
    };
    throw err;
  }

  const rsRows = rsResult.status === 'fulfilled' ? rsResult.value.rows : new Map();
  const benchmarkChange = rsResult.status === 'fulfilled' ? rsResult.value.benchmarkChange : null;
  const homemadeRows = homemadeResult.status === 'fulfilled' ? homemadeResult.value : [];
  const homemadeByTicker = new Map(homemadeRows.map((h) => [h.ticker, h]));

  // --- Filtrage avant enrichissement -----------------------------------
  const retenus = filtrerAvantEnrichissement
    ? tickers.filter((t) => meriteEnrichissement(homemadeByTicker.get(t)))
    : tickers;

  // --- Temps 2 : les fondamentaux, seulement sur les retenus -----------
  const fundamentalResult = retenus.length
    ? await Promise.allSettled([getFundamentalsBatch(retenus, { withVwap: SCREEN_FILTERS.calculerVwap })]).then((r) => r[0])
    : { status: 'fulfilled', value: [] };

  const passErrors = {
    forceRelative: rsResult.status === 'rejected' ? rsResult.reason.message : null,
    indicateurs: homemadeResult.status === 'rejected' ? homemadeResult.reason.message : null,
    fondamentaux: fundamentalResult.status === 'rejected' ? fundamentalResult.reason.message : null,
  };
  const fundamentalRows = fundamentalResult.status === 'fulfilled' ? fundamentalResult.value : [];
  const fundamentalByTicker = new Map(fundamentalRows.map((f) => [f.ticker, f]));

  // P/E moyen « par famille d'industrie » — PAS un vrai agrégat sectoriel
  // externe (aucune source gratuite fiable identifiée), mais la moyenne des
  // P/E des titres DE CE SCREENING partageant la même industrie.
  // Approximation assumée : une industrie peut n'avoir qu'un ou deux pairs,
  // d'où `industryPeerCount`, exposé pour que le frontend puisse le signaler
  // plutôt que de laisser croire à un benchmark de marché.
  const sectorPs = sectorPsStats(fundamentalRows);
  const peByIndustry = new Map();
  for (const f of fundamentalRows) {
    if (!f.industry || f.peRatio == null) continue;
    if (!peByIndustry.has(f.industry)) peByIndustry.set(f.industry, []);
    peByIndustry.get(f.industry).push(f.peRatio);
  }
  const industryStats = new Map(
    [...peByIndustry.entries()].map(([industry, values]) => [
      industry,
      { avgPE: values.reduce((a, b) => a + b, 0) / values.length, peerCount: values.length },
    ]),
  );

  const suivis = new Set(getWatchlist().map((w) => w.ticker));
  const scored = retenus
    .map((ticker) => {
      const hm = homemadeByTicker.get(ticker);
      const rs = rsRows.get(ticker);
      const fund = fundamentalByTicker.get(ticker) ?? {};
      const industryStat = fund.industry ? industryStats.get(fund.industry) : null;
      const merged = {
        ticker,
        // Repli sur le secteur Yahoo pour les titres de la watchlist absents
        // des listes sectorielles (SMCI, par exemple) — la donnée est déjà
        // dans les fondamentaux, autant s'en servir plutôt qu'afficher « — ».
        secteur: SECTEUR_DE.get(ticker) ?? fund.sector ?? null,
        suivi: suivis.has(ticker),
        rsi: hm?.rsi ?? null,
        goldenCross: hm?.goldenCross ?? null,
        smaAlignment: hm?.smaAlignment ?? null,
        alignmentAge: hm?.alignmentAge ?? null,
        smaPeriods: hm?.smaPeriods ?? null,
        changePercent: rs?.changePercent ?? null,
        forceRelative: rs?.forceRelative ?? null,
        error: hm?.error ?? null,
        obvTrend: hm?.obvTrend ?? null,
        obvError: hm?.error ?? null,
        atr: hm?.atr ?? null,
        price: fund.price ?? rs?.price ?? hm?.price ?? null,
        volume: fund.volume ?? null,
        marketCap: fund.marketCap ?? null,
        floatShares: fund.floatShares ?? null,
        pegRatio: fund.pegRatio ?? null,
        beta: fund.beta ?? null,
        peRatio: fund.peRatio ?? null,
        industry: fund.industry ?? null,
        sector: fund.sector ?? null,
        priceToSales: fund.priceToSales ?? null,
        sectorPS: fund.sector ? (sectorPs.get(fund.sector)?.medianPS ?? null) : null,
        sectorPSPeerCount: fund.sector ? (sectorPs.get(fund.sector)?.peerCount ?? null) : null,
        industryPE: industryStat?.avgPE ?? null,
        industryPeerCount: industryStat?.peerCount ?? null,
        vwap: fund.vwap ?? null,
        aboveVwap: fund.aboveVwap ?? null,
        daysToEarnings: fund.daysToEarnings ?? null,
      };
      return { ...merged, ...scoreRow(merged), flags: fundamentalFlags(merged) };
    })
    // Tri par SETUP d'abord (est-ce que ça se déclenche maintenant ?), puis
    // par CONTEXTE à setup égal. Trier sur la somme ferait remonter un bon
    // titre sans setup au-dessus d'un signal qui vient de se déclencher —
    // exactement ce que la séparation en deux axes vise à éviter.
    .sort((a, b) => (b.setupScore ?? -99) - (a.setupScore ?? -99)
                 || (b.contexteScore ?? -99) - (a.contexteScore ?? -99));

  return {
    rows: scored,
    passErrors,
    benchmarkChange,
    // De quoi lire honnêtement le résultat : combien de titres ont été
    // balayés, combien ont survécu au filtre. Sans ça, « 9 candidats »
    // ne dit pas s'ils sortent de 22 titres ou de 210.
    universeSize: tickers.length,
    retainedSize: retenus.length,
  };
}

/**
 * Construit le résultat complet d'un screening.
 * @param {'watchlist'|'elargi'|'mag7'} universe
 */
export async function buildScreening(universe = 'watchlist') {
  const tickers = universeTickers(universe);
  const out = await screenTickers(tickers, { filtrerAvantEnrichissement: universe === 'elargi' || universe === 'sp500' });
  return {
    generatedAt: new Date().toISOString(),
    universe,
    universeSize: out.universeSize,
    retainedSize: out.retainedSize,
    preferences: getPreferences(),
    signalAge: SIGNAL_AGE,
    passErrors: out.passErrors,
    benchmark: BENCHMARK_SYMBOL,
    benchmarkChange: out.benchmarkChange,
    rows: out.rows,
  };
}

/**
 * « Titres les plus performants du secteur », avec les MÊMES colonnes que le
 * tableau de screening (11/9/2026, demande de JP) — même pipeline, donc les
 * deux tableaux ne peuvent pas diverger.
 *
 * Deux différences assumées avec buildScreening(), et une seule raison pour
 * les deux : cette carte répond à « qu'est-ce qui bouge dans ce secteur ? »,
 * pas à « qu'est-ce qui se déclenche ? ».
 *   1. Aucun filtre avant enrichissement : on montre TOUS les titres suivis
 *      du secteur, en setup ou non.
 *   2. Tri par variation du jour décroissante, pas par Setup/Contexte — le
 *      nom de la carte est « les plus performants », et un tri par setup en
 *      ferait un second screener sans le dire.
 *
 * `mode` reprend le comportement d'avant : 'raw' ne filtre rien, 'filtered'
 * exclut les titres sous les seuils de capitalisation/volume — et, par
 * prudence, tout titre dont l'un ou l'autre n'a pas pu être confirmé (jamais
 * inclus « au bénéfice du doute »).
 */
// Colonnes complètes pour une liste de symboles fournie par le navigateur (ex. les « prêt » du balayage S&P 500 → A4).
export async function buildTickersScreening(tickers) {
  const out = await screenTickers(tickers, { filtrerAvantEnrichissement: false });
  return { rows: out.rows, passErrors: out.passErrors, benchmarkChange: out.benchmarkChange, generatedAt: new Date().toISOString() };
}

export async function buildSectorScreening(sectorKey, { mode = 'raw', filters } = {}) {
  const candidates = SECTOR_TOP_CANDIDATES[sectorKey];
  if (!candidates) {
    const err = new Error(`Secteur inconnu ou sans liste de titres : ${sectorKey}`);
    err.code = 'UNKNOWN_SECTOR';
    throw err;
  }
  const out = await screenTickers(candidates, { filtrerAvantEnrichissement: false });
  const retenues = mode === 'filtered'
    ? out.rows.filter((r) => r.marketCap != null && r.marketCap >= filters.marketCapMin
                          && r.volume != null && r.volume >= filters.volumeMin)
    : out.rows;
  const triees = retenues
    .slice()
    .sort((a, b) => (b.changePercent ?? -Infinity) - (a.changePercent ?? -Infinity));
  return {
    rows: triees.slice(0, 30),
    totalCandidates: candidates.length,
    failedCount: out.rows.filter((r) => r.error).length,
    preferences: getPreferences(),
    signalAge: SIGNAL_AGE,
    passErrors: out.passErrors,
    benchmark: BENCHMARK_SYMBOL,
    benchmarkChange: out.benchmarkChange,
  };
}
