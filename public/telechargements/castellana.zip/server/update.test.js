// Tests de la comparaison de versions (server/update.js). Le reste du module
// (téléchargement, extraction, bascule) touche au système de fichiers et est
// vérifié à la main sur une copie jetable — voir CLAUDE.md.

import test from 'node:test';
import assert from 'node:assert/strict';
import { isNewer, urlSure, empreinteValide, sha256Hex, verifierEmpreinte, applyUpdate } from './update.js';

test('isNewer reconnaît une version plus récente', () => {
  assert.equal(isNewer('1.0.1', '1.0.0'), true);
  assert.equal(isNewer('1.1.0', '1.0.9'), true);
  assert.equal(isNewer('2.0.0', '1.99.99'), true);
});

test('isNewer refuse une version identique ou antérieure', () => {
  assert.equal(isNewer('1.0.0', '1.0.0'), false);
  assert.equal(isNewer('1.0.0', '1.0.1'), false);
  assert.equal(isNewer('0.9.9', '1.0.0'), false);
});

test('isNewer compare numériquement, pas alphabétiquement', () => {
  // Le piège classique : "1.0.10" < "1.0.9" en comparaison de chaînes.
  assert.equal(isNewer('1.0.10', '1.0.9'), true);
  assert.equal(isNewer('1.0.9', '1.0.10'), false);
});

test('isNewer ne propose jamais de mise à jour sur une version douteuse', () => {
  // Mieux vaut ne rien proposer que de pousser un testeur vers une
  // régression sur la foi d'une chaîne mal formée.
  for (const [a, b] of [['abc', '1.0.0'], ['1.0.0', 'abc'], [null, '1.0.0'], ['1.0', '1.0.0'], ['1.0.0.1', '1.0.0'], [undefined, undefined]]) {
    assert.equal(isNewer(a, b), false, `isNewer(${a}, ${b}) doit être false`);
  }
});

// Audit routes (21/10/2026, constat 1) : ce que la mise à jour télécharge est exécuté — https et empreinte sont obligatoires.
test('urlSure : https seulement (http permis vers la machine locale pour les essais)', () => {
  assert.equal(urlSure('https://iecho.ca/telechargements/castellana.zip'), true);
  assert.equal(urlSure('http://evil.example/x.zip'), false);
  assert.equal(urlSure('http://127.0.0.1:9/x.zip'), true);
  assert.equal(urlSure('ftp://iecho.ca/x.zip'), false);
  assert.equal(urlSure('pas une url'), false);
  assert.equal(urlSure(null), false);
});

test('empreinteValide : 64 caractères hexadécimaux, rien d\'autre', () => {
  assert.equal(empreinteValide('a'.repeat(64)), true);
  assert.equal(empreinteValide('A'.repeat(64)), true);
  assert.equal(empreinteValide('a'.repeat(63)), false);
  assert.equal(empreinteValide('g'.repeat(64)), false);
  assert.equal(empreinteValide(null), false);
  assert.equal(empreinteValide(undefined), false);
});

test('verifierEmpreinte : accepte la bonne, refuse une autre archive et l\'absence d\'empreinte', () => {
  const archive = Buffer.from('contenu de l\'archive');
  assert.doesNotThrow(() => verifierEmpreinte(archive, sha256Hex(archive)));
  assert.doesNotThrow(() => verifierEmpreinte(archive, sha256Hex(archive).toUpperCase()));
  assert.throws(() => verifierEmpreinte(Buffer.from('archive piégée'), sha256Hex(archive)), /différente/);
  assert.throws(() => verifierEmpreinte(archive, null), /sha256/);
  assert.throws(() => verifierEmpreinte(archive, 'abc'), /sha256/);
});

test('applyUpdate refuse avant tout téléchargement : URL non https ou empreinte absente', async () => {
  await assert.rejects(() => applyUpdate('http://evil.example/x.zip', 'a'.repeat(64)), /https/);
  await assert.rejects(() => applyUpdate('https://iecho.ca/x.zip', null), /sha256/);
  await assert.rejects(() => applyUpdate('https://iecho.ca/x.zip', 'zz'), /sha256/);
});
