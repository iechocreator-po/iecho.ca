// Comptes utilisateurs — pas d'auto-inscription. Historiquement créés à la
// main par scripts/create-user.mjs (exécuté par JP) ; depuis le 19/9/2026,
// createUser/updateUser/setDisabled/resetPassword sont aussi appelées par
// la console CRUD de bilbao via src/routes/admin.js (voir CLAUDE.md,
// section « Console bilbao — comptes castellana »). Le script reste un
// filet de secours local, les deux chemins passent par les mêmes
// fonctions ci-dessous — pas de logique dupliquée.

import { seedWatchlistFor } from './watchlist.js';
import { revokeAllSessions } from './sessions.js';
import { invalidateMagicLinksForUser } from './magic-links.js';

export async function findUserByUsername(db, username) {
  return db.prepare('SELECT * FROM users WHERE username = ?').bind(username.toLowerCase()).first();
}

// Utilisée par la demande de magic link — comparaison insensible à la
// casse comme le username, un email n'est unique que par construction
// applicative (pas de contrainte UNIQUE en base, un admin pourrait laisser
// deux comptes sans email ou, par erreur, le même email deux fois ; on
// prend alors le premier trouvé plutôt que d'échouer).
export async function findUserByEmail(db, email) {
  return db.prepare('SELECT * FROM users WHERE email = ? COLLATE NOCASE').bind(email).first();
}

export async function findUserById(db, id) {
  return db.prepare('SELECT * FROM users WHERE id = ?').bind(id).first();
}

// Jamais password_hash/password_salt — cette liste alimente la console
// d'administration de bilbao, qui ne doit jamais voir ces champs.
//
// last_login (19/9/2026) — dernière connexion réussie, mot de passe OU
// magic link confondus : les deux créent une ligne dans `sessions` au
// moment de la connexion (`createSession()`, `auth.js`), donc le plus
// récent `created_at` de cette table pour un utilisateur EST sa dernière
// connexion. Pas une colonne dédiée sur `users` — dérivée de données déjà
// là, aucune migration nécessaire. `null` si le compte ne s'est jamais
// connecté (aucune ligne de session), jamais confondu avec « il y a
// longtemps ».
//
// 18/10/2026 : cette dérivée se trompait sur deux points — une session dure
// 30 jours (un compte resté connecté ne « se connecte » plus jamais) et une
// déconnexion efface la ligne. last_login_at et last_seen_at vivent donc
// maintenant sur users (scripts/migrate-user-activity.mjs) ; `last_login`
// reste renvoyé pour un bilbao qui ne connaît pas encore les nouveaux champs,
// et la requête retombe sur l'ancienne forme tant que la migration n'a pas tourné.
export async function listUsers(db) {
  const derived = '(SELECT MAX(s.created_at) FROM sessions s WHERE s.user_id = u.id)';
  try {
    const { results } = await db
      .prepare(
        `SELECT u.id, u.username, u.email, u.disabled, u.created_at,
          COALESCE(u.last_login_at, ${derived}) AS last_login,
          COALESCE(u.last_login_at, ${derived}) AS last_login_at,
          u.last_seen_at
         FROM users u ORDER BY u.username`,
      )
      .all();
    return results;
  } catch (err) {
    if (!/no such column/i.test(String(err?.message))) throw err;
    const { results } = await db
      .prepare(`SELECT u.id, u.username, u.email, u.disabled, u.created_at, ${derived} AS last_login FROM users u ORDER BY u.username`)
      .all();
    return results;
  }
}

// Crée le compte ET sème sa watchlist par défaut (SEED_WATCHLIST) — la
// watchlist locale était semée une seule fois, globalement ; ici chaque
// nouveau compte reçoit sa propre copie de départ.
export async function createUser(db, username, passwordHash, passwordSalt, email = null) {
  const result = await db.prepare(
    'INSERT INTO users (username, password_hash, password_salt, email) VALUES (?, ?, ?, ?)',
  ).bind(username.toLowerCase(), passwordHash, passwordSalt, email || null).run();
  const userId = result.meta.last_row_id;
  await seedWatchlistFor(db, userId);
  return findUserById(db, userId);
}

// Édition partielle (username et/ou email) — undefined signifie « ne pas
// toucher à ce champ », null/'' signifie « effacer l'email ». Le
// username, lui, ne peut pas être vidé (contrainte NOT NULL).
export async function updateUser(db, id, { username, email } = {}) {
  if (username !== undefined) {
    await db.prepare('UPDATE users SET username = ? WHERE id = ?').bind(username.toLowerCase(), id).run();
  }
  if (email !== undefined) {
    await db.prepare('UPDATE users SET email = ? WHERE id = ?').bind(email || null, id).run();
  }
  return findUserById(db, id);
}

// Un compte désactivé ne peut plus se connecter (mot de passe NI magic
// link, voir routes/auth.js) mais garde toutes ses données — voir
// CLAUDE.md, « suppression = désactivation, pas un DELETE dur » : les
// trades/watchlist/preferences référencent users(id) sans ON DELETE
// CASCADE, une vraie suppression casserait ou perdrait un journal de
// trades réel.
export async function setDisabled(db, id, disabled) {
  await db.prepare('UPDATE users SET disabled = ? WHERE id = ?').bind(disabled ? 1 : 0, id).run();
  return findUserById(db, id);
}

export async function resetPassword(db, id, passwordHash, passwordSalt) {
  await db.prepare('UPDATE users SET password_hash = ?, password_salt = ? WHERE id = ?')
    .bind(passwordHash, passwordSalt, id).run();
}

// Désactivation par l'administrateur : le compte ne peut plus se connecter ET perd tout accès tout de suite — sessions déjà
// ouvertes fermées (jetons TradingView compris) et liens de connexion encore valides invalidés. Avant (audit cloud-comptes,
// 20/10/2026), seule la NOUVELLE connexion était refusée : une session ouverte survivait jusqu'à 30 jours.
// Renvoie { user, sessionsClosed }, ou null si le compte n'existe pas.
export async function disableUserAndRevoke(db, id) {
  const user = await setDisabled(db, id, true);
  if (!user) return null;
  const sessionsClosed = await revokeAllSessions(db, id);
  await invalidateMagicLinksForUser(db, id);
  return { user, sessionsClosed };
}

// Réinitialisation du mot de passe par l'administrateur : sert aussi à reprendre la main sur un compte compromis, donc les
// sessions déjà ouvertes et les liens de connexion encore valides tombent avec l'ancien mot de passe.
export async function resetPasswordAndRevoke(db, id, passwordHash, passwordSalt) {
  await resetPassword(db, id, passwordHash, passwordSalt);
  const sessionsClosed = await revokeAllSessions(db, id);
  await invalidateMagicLinksForUser(db, id);
  return sessionsClosed;
}
