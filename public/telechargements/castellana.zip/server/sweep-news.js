// Nouveautés d'un balayage S&P 500 par rapport au précédent (#395, 8/10/2026).
// Fonctions PURES : la persistance et l'envoi vivent dans sweep.js.
//
// « Candidat » = titre dont le verdict est « prêt » (le setup se déclenche maintenant).
// Nouveauté = candidat aujourd'hui qui ne l'était pas au balayage précédent ; sortie =
// l'inverse. Sans balayage précédent, il n'y a PAS de nouveautés à annoncer (on ne
// présente jamais tous les candidats comme « nouveaux » : ce serait faux).

export function readyTickers(rows) {
  return (rows || []).filter((r) => r.verdict === 'prêt').map((r) => r.ticker);
}

export function diffSweep(previousReady, rows) {
  const now = readyTickers(rows);
  if (!previousReady) return { baseline: true, nouveautes: [], sorties: [], ready: now };
  const before = new Set(previousReady);
  const nowSet = new Set(now);
  return {
    baseline: false,
    nouveautes: now.filter((t) => !before.has(t)),
    sorties: previousReady.filter((t) => !nowSet.has(t)),
    ready: now,
  };
}

const fmt = (r) => `${r.ticker}${r.sector ? ` (${r.sector})` : ''} — Setup ${r.setupScore ?? '?'}, Contexte ${r.contexteScore ?? '?'}${r.price != null ? `, ${Number(r.price).toFixed(2)} $` : ''}`;

export function buildSweepDigest(diff, rows, { source, day, universeSize, retainedSize } = {}) {
  const byTicker = new Map((rows || []).map((r) => [r.ticker, r]));
  const lines = [`castellana — balayage S&P 500 du ${day || ''}`.trim(), `Source : ${source || '?'} · ${retainedSize ?? '?'} retenu(s) sur ${universeSize ?? '?'}`, ''];
  if (diff.baseline) {
    lines.push(`Premier balayage enregistré : ${diff.ready.length} candidat(s) « prêt ». Les nouveautés seront comparées à celui-ci dès demain.`);
  } else {
    lines.push(`■ Nouveaux candidats depuis le dernier balayage (${diff.nouveautes.length})`);
    for (const t of diff.nouveautes) lines.push(`  • ${byTicker.has(t) ? fmt(byTicker.get(t)) : t}`);
    if (!diff.nouveautes.length) lines.push('  (aucun)');
    lines.push('', `■ Sortis de la liste « prêt » (${diff.sorties.length})`);
    lines.push(diff.sorties.length ? `  ${diff.sorties.join(', ')}` : '  (aucun)');
  }
  lines.push('', 'Données différées. Outil d\'aide à la décision, pas un conseil en investissement.');
  const subject = diff.baseline ? 'castellana : premier balayage S&P 500' : `castellana : S&P 500 — ${diff.nouveautes.length} nouveau(x) candidat(s)`;
  return { subject, text: lines.join('\n') };
}
