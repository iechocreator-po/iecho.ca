// Glossaire des indicateurs (feature 321) — objet JS statique, aucun appel
// modèle à la volée (décision documentée dans CLAUDE.md, 22/7/2026). Texte
// pré-rédigé par indicateur, calqué sur les bandes de la section 4.4 du
// design doc. Une seule fonction de rendu (index.html) lit ce glossaire pour
// les popovers d'aide. Aucune clé API, aucun credential.
//
// Format par entrée : { label, quoi, pourquoi, bandes:[{couleur,seuil,sens}] }
// couleur ∈ vert|amber|rouge — pour colorer la pastille dans le popover.
// Seuils des tuiles « Fondamentaux » : lus dans config.js (chargé avant ce fichier) pour que le popover
// et la couleur de la tuile ne puissent pas diverger ; repli sur les mêmes valeurs si config.js manque.
const _FB = (typeof CFG !== 'undefined' && CFG.fondamentaux && CFG.fondamentaux.bandes) || {
  fcfMargeVert: 10, fcfParActionHausseVert: 5, fcfParActionBaisseRouge: -5, rendementVert: 5, rendementRouge: 2, tresorerieVert: 1, tresorerieRouge: 0.25,
};

const GLOSSAIRE = {
  vix: {
    label: 'VIX — indice de volatilité',
    quoi: "Mesure la volatilité implicite attendue sur le S&P 500 à 30 jours. Souvent appelé « indice de la peur ».",
    pourquoi: "Donne le climat de marché global. En swing trading, un VIX élevé multiplie les faux signaux et élargit les mouvements — il module la taille de position et la largeur des stops.",
    bandes: [
      { couleur: 'amber', seuil: '< 15', sens: "Complaisance — marché calme, primes basses, risque de retournement soudain." },
      { couleur: 'vert', seuil: '15–20', sens: "Normal — climat neutre, taille de base appropriée." },
      { couleur: 'amber', seuil: '20–30', sens: "Nervosité — élargir les stops (ATR plus large) ou réduire la taille." },
      { couleur: 'rouge', seuil: '> 30', sens: "Panique — faux signaux fréquents, réduire de moitié ou attendre." },
    ],
  },
  rsi: {
    label: 'RSI(14) — force relative interne',
    quoi: "Oscillateur de momentum (0–100) mesurant la vitesse et l'ampleur des variations de prix récentes.",
    pourquoi: "Seul indicateur de momentum retenu (pas de MACD ni Stochastic RSI — redondance écartée avec JP). Repère le surachat/survente et la zone d'entrée saine.",
    bandes: [
      { couleur: 'amber', seuil: '< 30', sens: "Survente — rebond possible mais couteau qui tombe, pas un signal d'achat isolé." },
      { couleur: 'vert', seuil: '40–70', sens: "Zone d'entrée saine — momentum haussier sans excès." },
      { couleur: 'rouge', seuil: '> 70', sens: "Surachat — risque de correction, discount de sizing appliqué." },
    ],
  },
  obv: {
    label: 'OBV — On-Balance Volume',
    quoi: "Volume cumulatif : +volume les jours de hausse, −volume les jours de baisse. Vrai cumul (calcul maison), pas l'heuristique clôture/ouverture de tradingview-mcp.",
    pourquoi: "Confirme (ou non) le mouvement de prix par le volume. Une hausse de prix sans hausse d'OBV (divergence) trahit un mouvement peu soutenu.",
    bandes: [
      { couleur: 'vert', seuil: 'Accumulation', sens: "Le prix monte ET l'OBV monte — mouvement soutenu par le volume." },
      { couleur: 'amber', seuil: 'Neutre', sens: "Pas de signal clair : volume sans tendance nette, ou prix en baisse (l'OBV sert ici à juger une hausse, pas une baisse)." },
      { couleur: 'rouge', seuil: 'Distribution', sens: "Le prix monte mais l'OBV baisse — le volume ne suit pas, méfiance." },
    ],
  },
  forceRelative: {
    label: 'Force relative vs indice',
    quoi: "Écart de performance du titre par rapport à son indice de référence (SPY) sur la période.",
    pourquoi: "Un titre qui surperforme son indice attire la demande et tend à mener — le leadership relatif est un filtre de sélection clé.",
    bandes: [
      { couleur: 'vert', seuil: '> +5 pts', sens: "Forte — surperformance nette, potentiel de leadership." },
      { couleur: 'amber', seuil: '−5 à +5 pts', sens: "Neutre — suit le marché sans se démarquer." },
      { couleur: 'rouge', seuil: '< −5 pts', sens: "Faible — sous-performance, risque de continuité." },
    ],
  },
  goldenCross: {
    label: 'Golden Cross (SMA50 / SMA200)',
    quoi: "Croisement de la moyenne mobile simple 50 jours au-dessus de la 200 jours.",
    pourquoi: "Signal de tendance de fond haussière de long terme — sert de toile de fond au filtre de tendance court terme (les trois SMA configurées dans Réglages → Valeur personnalisée).",
    bandes: [
      { couleur: 'vert', seuil: 'Confirmé (> +1 %)', sens: "SMA50 nettement au-dessus de la SMA200 — tendance de fond haussière établie." },
      { couleur: 'amber', seuil: 'Naissant', sens: "Croisement récent/proche — à confirmer avec du volume." },
      { couleur: 'rouge', seuil: 'Absent', sens: "SMA50 sous la SMA200 — tendance de fond baissière ou neutre." },
    ],
  },
  sma: {
    label: 'Filtre de tendance — trois SMA (rapide / moyenne / lente)',
    quoi: "Trois moyennes mobiles SIMPLES (SMA, fenêtre glissante — pas lissées/RMA). Signal au premier alignement haussier (prix > rapide > moyenne > lente), sortie sous la moyenne intermédiaire. Les trois périodes sont modifiables dans Réglages → Valeur personnalisée, et pilotent réellement le calcul.",
    pourquoi: "Cœur du filtre de tendance validé avec JP (ne pas remplacer par EMA 50/100/200). Définit le sens autorisé des trades.",
    bandes: [
      { couleur: 'vert', seuil: 'Haussier', sens: "Prix > SMA rapide > moyenne > lente (9 / 21 / 50 par défaut, réglables) — alignement haussier complet." },
      { couleur: 'amber', seuil: 'Neutre', sens: "Alignement incomplet — pas de signal de tendance franc." },
      { couleur: 'rouge', seuil: 'Baissier', sens: "Prix < SMA rapide < moyenne < lente — tendance baissière." },
    ],
  },
  atr: {
    label: 'ATR(14) — Average True Range',
    quoi: "Amplitude moyenne des mouvements quotidiens (vrai range lissé Wilder). Exprimé en dollars.",
    pourquoi: "Base du placement du stop (distance = ATR × multiplicateur) et donc du sizing. Un ATR large impose un stop plus large et une position plus petite à risque constant.",
    bandes: [],
  },
  vwap: {
    label: 'VWAP — Volume Weighted Average Price',
    quoi: "Prix moyen pondéré par le volume, calculé sur les barres de 5 minutes des 24 dernières heures (jusqu'à une séance et demie le matin, la veille en pré-ouverture).",
    pourquoi: "Référence des intervenants institutionnels. Un prix au-dessus du VWAP indique un biais acheteur intraday ; en dessous, un biais vendeur.",
    bandes: [
      { couleur: 'vert', seuil: 'Prix > VWAP', sens: "Biais acheteur intraday — le prix se tient au-dessus de la référence institutionnelle." },
      { couleur: 'rouge', seuil: 'Prix < VWAP', sens: "Biais vendeur intraday — sous la référence, prudence sur une entrée longue." },
    ],
  },
  pe: {
    label: 'P/E — ratio cours/bénéfice',
    quoi: "Prix de l'action ÷ bénéfice par action des 12 derniers mois (trailing). Combien d'années de bénéfices actuels le marché paie.",
    pourquoi: "Repère de valorisation, à lire en comparaison : avec le P/E de l'industrie à côté, ou avec les pairs du même secteur. Un P/E élevé n'est pas mauvais en soi (forte croissance attendue), un P/E bas n'est pas une aubaine en soi. Absent si la société n'est pas rentable.",
    bandes: [],
  },
  peg: {
    label: 'PEG ratio',
    quoi: "Ratio cours/bénéfice rapporté à la croissance des bénéfices (PE ÷ croissance).",
    pourquoi: "Filtre de valorisation : un PEG ≤ 1 suggère une valorisation raisonnable au regard de la croissance. Critère de screening supplémentaire (feature 322).",
    bandes: [
      { couleur: 'vert', seuil: '≤ 1', sens: "Valorisation raisonnable au regard de la croissance." },
      { couleur: 'amber', seuil: '> 1', sens: "Valorisation tendue — la croissance ne justifie pas entièrement le prix." },
    ],
  },
  beta: {
    label: 'Beta 5Y',
    quoi: "Sensibilité du titre aux mouvements du marché sur 5 ans (1 = suit l'indice, > 1 = amplifie).",
    pourquoi: "Filtre de screening (feature 322) : un beta > 1 privilégie les titres qui amplifient les mouvements — cohérent avec une stratégie swing offensive.",
    bandes: [
      { couleur: 'vert', seuil: '> 1', sens: "Amplifie les mouvements du marché — plus de potentiel (et de risque)." },
      { couleur: 'amber', seuil: '≤ 1', sens: "Suit ou amortit le marché — mouvements plus modérés." },
    ],
  },
  float: {
    label: 'Float — actions en circulation',
    quoi: "Nombre d'actions réellement disponibles à l'échange (hors blocs détenus par les initiés).",
    pourquoi: "Filtre de screening (feature 322) : un float plus faible amplifie les mouvements (moins d'offre). Borné par config pour cibler un profil de liquidité donné.",
    bandes: [],
  },
  rMultiples: {
    label: 'Multiples de R (basé sur l\'ATR)',
    quoi: "Cibles de sortie exprimées en multiples du risque initial R (R = distance du stop = ATR × multiplicateur). 1R, 2R, 3R sont les prix à atteindre pour gagner respectivement 1, 2 ou 3 fois le montant risqué sur ce trade.",
    pourquoi: "Ancre les objectifs sur le risque réellement pris sur CE trade, pas sur un pourcentage fixe — un stop plus large (titre volatil) donne mécaniquement des cibles plus éloignées, cohérent avec un ratio risque/récompense constant.",
    bandes: [],
  },
  fibonacci: {
    label: 'Extension Fibonacci',
    quoi: "Niveaux de prix projetés au-delà du haut du swing, à partir de l'amplitude du dernier mouvement (bas → haut) multipliée par des ratios Fibonacci (127.2 %, 161.8 %, 261.8 %).",
    pourquoi: "Cibles basées sur la structure du marché plutôt que sur le risque pris — utile à croiser avec les multiples de R pour repérer des zones de prix où d'autres intervenants pourraient aussi prendre profit.",
    bandes: [],
  },

  // Deux entrées ajoutées pour l'onglet Labo (5/9/2026, suite aux questions
  // de JP T0/T1/T3) — concepts d'options, pas des indicateurs de prix, mais
  // rendues avec le même popover (showGlossaire) pour rester cohérent avec
  // le reste de l'app plutôt que d'inventer un second mécanisme.
  leaps: {
    label: 'LEAPS — option à longue échéance',
    quoi: "LEAPS = Long-term Equity AnticiPation Securities. Ce n'est PAS un type de contrat différent d'un Call ou d'un Put ordinaire — c'est simplement une option (Call ou Put) dont l'échéance est longue (généralement 9 mois à 2-3 ans), par opposition à une option « classique » dont l'échéance va de quelques semaines à quelques mois. « LEAPS Call » se lit donc « Call (option d'achat) à longue échéance ».",
    pourquoi: "Dans le PMCC, on ACHÈTE un LEAPS Call profondément dans la monnaie pour qu'il serve de substitut aux 100 actions : sa longue échéance lui laisse le temps de se comporter presque comme l'action elle-même, sans en payer le plein prix.",
    bandes: [],
  },
  // Trois entrées sur la volatilité implicite (4/10/2026, demande de JP).
  optStrike: {
    label: "Strike — prix d'exercice",
    quoi: "Le prix auquel l'option peut être exercée. Pour un put vendu : si le titre termine sous le strike à l'échéance, tu es assigné et tu achètes les actions à ce prix. Pour un call vendu : s'il termine au-dessus, tes actions sont vendues à ce prix.",
    pourquoi: "Plus le strike d'un put vendu est bas (loin sous le prix), moins tu risques d'être assigné — mais moins la prime est généreuse. C'est le compromis central de la Roue.",
    bandes: [],
  },
  optBid: {
    label: 'Bid — ce que tu encaisses',
    quoi: "Le prix le plus élevé que les acheteurs offrent pour l'option. En VENDANT, c'est ce que tu reçois (par action : × 100 pour un contrat).",
    pourquoi: "Toutes les primes de castellana sont calculées sur le bid, jamais sur l'ask ni sur le dernier prix : c'est ce que le marché te paie réellement. Un bid vide ou nul affiche « — », jamais 0.",
    bandes: [],
  },
  optAsk: {
    label: 'Ask — ce que paient les acheteurs',
    quoi: "Le prix le plus bas que les vendeurs demandent. En ACHETANT (ou en rachetant pour fermer une position), c'est ce que tu paies.",
    pourquoi: "L'écart bid–ask est un coût caché : un grand écart (visible en survolant l'ask) signale un contrat peu liquide où sortir coûtera cher. Le bouton « Racheter » du roulement utilise l'ask.",
    bandes: [],
  },
  optLast: {
    label: 'Dernier — dernier prix échangé',
    quoi: 'Le prix de la dernière transaction. Il peut dater de plusieurs heures, voire de la veille, surtout sur un strike peu actif.',
    pourquoi: "Pour estimer la prime qu'on encaisserait maintenant, le bid est plus fiable : le dernier prix sert surtout de repère.",
    bandes: [],
  },
  optVol: {
    label: 'Vol. — volume du jour',
    quoi: "Nombre de contrats échangés aujourd'hui sur ce strike.",
    pourquoi: "Un volume élevé indique un marché actif aujourd'hui. Un volume nul ne veut pas dire que le strike est illiquide : regarde aussi l'open interest.",
    bandes: [],
  },
  optOI: {
    label: 'OI — open interest',
    quoi: 'Nombre de contrats actuellement ouverts (non fermés) sur ce strike.',
    pourquoi: "Mesure de liquidité durable : un OI élevé signifie que beaucoup de gens ont une position, donc qu'il sera plus facile d'entrer et de sortir. Un filtre d'OI minimum se règle dans « Filtres sur les données ».",
    bandes: [],
  },
  optPremPct: {
    label: 'Prime / strike — où on en est avec la règle',
    quoi: "Le bid divisé par le strike, en %. C'est le rendement de la période pour ce contrat (ex. 0,45 % : on encaisse 0,45 $ pour 100 $ de strike). À côté ou dans l'en-tête : le seuil de la règle pour cette échéance (par défaut 0,5 % par 5 jours, proportionnel au nombre de jours).",
    pourquoi: 'Compare directement ta prime au but : 0,45 % / 0,50 % = 90 % du chemin. Vert = la règle est respectée. Pour un contrat dans la monnaie, seule la valeur temps (bid moins la valeur intrinsèque) compte.',
    bandes: [],
  },
  optYield: {
    label: 'Rend. ann. — rendement annualisé',
    quoi: "Prime ÷ strike × 365 ÷ jours à l'échéance, en %. Calculé sur 1 contrat, sur le bid (valeur temps seulement si le contrat est dans la monnaie).",
    pourquoi: "Permet de comparer des échéances différentes. C'est une hypothèse optimiste : elle suppose que tu puisses refaire la même vente à chaque période, sans assignation ni baisse de la volatilité.",
    bandes: [],
  },
  optCapital: {
    label: 'Capital requis',
    quoi: "Strike × nombre d'actions par contrat (100 par défaut, réglable dans le Labo). Pour un put vendu, c'est le cash à garder en réserve ; pour un call couvert, la valeur des actions détenues.",
    pourquoi: "Sert à juger l'effort de capital derrière la prime : une grosse prime sur un très gros capital n'est pas forcément plus intéressante en rendement.",
    bandes: [],
  },
  optRoll: {
    label: 'Roul. — roulement',
    quoi: "Deux boutons qui envoient ce contrat au calculateur de roulement : « Racheter » (prix = ask) pour fermer l'ancienne position, « Vendre » (prix = bid) pour ouvrir la nouvelle.",
    pourquoi: 'Rouler = racheter la jambe actuelle et en vendre une plus loin dans le temps. Le calculateur affiche le crédit net : il doit rester positif pour que le roulement vaille la peine.',
    bandes: [],
  },
  optDte: {
    label: "DTE — jours avant l'échéance",
    quoi: "Nombre de jours calendaires restants avant l'échéance du contrat.",
    pourquoi: 'Plus le DTE est court, plus la prime se dégrade vite en ta faveur (theta), mais plus le risque de gap se concentre. Le seuil de la règle de prime est proportionnel au DTE.',
    bandes: [],
  },
  optExpiry: {
    label: 'Échéance',
    quoi: 'Date à laquelle le contrat expire.',
    pourquoi: "Les échéances hebdomadaires (vendredis) sont privilégiées pour la Roue à courte durée ; tous les titres n'en ont pas.",
    bandes: [],
  },
  optRuleRatio: {
    label: 'Règle — ratio prime ÷ seuil',
    quoi: 'La prime (valeur temps du bid) divisée par la prime minimale exigée par ta règle pour ce strike et cette échéance. 1,00× = pile au seuil ; 1,29× = 29 % au-dessus ; 0,90× = il manque 10 %.',
    pourquoi: 'Un ratio ≥ 1× signifie que la règle est respectée. Les lignes sous 1× sont affichées en grisé dans le Screener Prime pour que tu voies à quel point elles en sont proches.',
    bandes: [],
  },
  optEarnings: {
    label: 'Résultats (j)',
    quoi: "Jours avant la prochaine publication de résultats trimestriels du titre. Un ⚠ signale que les résultats tombent AVANT l'échéance du contrat.",
    pourquoi: "Les résultats provoquent des gaps : un put vendu qui traverse l'annonce peut être assigné bien sous ton strike. Le Radar exclut ces cas ; ici c'est un avertissement.",
    bandes: [],
  },
  marge: {
    label: 'Marge — distance du strike au prix',
    quoi: "Deux mesures de la distance entre le strike et le prix du titre. 1) En % du prix (ex. 7 % = le titre doit baisser de 7 % pour toucher le strike d'un put). 2) En écarts-types (σ) du mouvement attendu d'ici l'échéance, calculé avec l'IV du contrat : distance ÷ (IV × √(jours/365)). 1,0σ ≈ le mouvement que le marché juge « normal » sur cette durée.",
    pourquoi: "Le but de la Roue : rester le plus loin possible du prix (moins de risque d'être assigné) tout en encaissant assez de prime (règle des 0,5 %). Le ★ marque le STRIKE LIMITE : le plus éloigné dont le bid respecte encore la règle. Les σ permettent de comparer des titres de volatilité différente ; le delta, lui, mesure la probabilité d'assignation. Une grande marge due à une IV énorme n'est pas forcément plus sûre — regarde les deux.",
    bandes: [],
  },
  iv: {
    label: 'IV — volatilité implicite',
    quoi: "L'amplitude de mouvement annuelle que le MARCHÉ anticipe pour le titre, déduite du prix de l'option elle-même (en %). Une IV de 50 % signifie que le marché s'attend à un écart-type d'environ 50 % sur un an, soit environ 3 % par jour de bourse. Plus l'IV est haute, plus les options sont chères.",
    pourquoi: "C'est ce qui rend une prime « riche » ou « bon marché ». Le vendeur de put veut une IV élevée (prime généreuse), l'acheteur une IV basse. Une IV très haute n'est pas un cadeau : elle signale souvent un événement à venir (résultats) ou un titre risqué. Ici l'IV vient de Yahoo (différée ~15 min) ; une valeur de bruit sous 1 % est ignorée.",
    bandes: [],
  },
  ivEcart: {
    label: 'Écart IV — IV moins volatilité historique',
    quoi: "Différence, en points de %, entre l'IV du contrat et la volatilité HISTORIQUE du titre (celle réellement observée sur ses derniers cours). +10 pts = le marché anticipe 10 points de plus de mouvement que ce que le titre a récemment fait.",
    pourquoi: "Repère de cherté relative. Pour un VENDEUR, un écart positif (> +5 pts) est favorable : on encaisse plus que le risque passé ne le justifie. Pour un ACHETEUR, c'est l'inverse. Approximation : la volatilité historique regarde en arrière, l'IV intègre l'avenir (résultats, actualités). Remplacé par l'IV Rank réel dès que l'historique du Radar est suffisant (≥ 20 jours, local seulement).",
    bandes: [],
  },
  ivRank: {
    label: 'IV Rank — l\'IV actuelle dans son historique',
    quoi: "Position de l'IV à la monnaie du titre entre son plus bas (0) et son plus haut (100) observés dans l'historique accumulé par le Radar. IV Rank 80 = l'IV est proche des plus hauts connus de CE titre. Le percentile indique la part des jours où l'IV a été plus basse.",
    pourquoi: "Une IV de 40 % est élevée pour un titre calme et banale pour un titre nerveux : le rang compare le titre à lui-même. Le vendeur de prime cherche un rang élevé. Non affiché tant qu'il y a moins de 20 jours d'historique (le Radar en ajoute un par jour de scan) — jamais un chiffre sur trop peu de données.",
    bandes: [],
  },
  volHist: {
    label: 'Vol. hist. — volatilité historique',
    quoi: "Volatilité réellement observée du titre : écart-type des rendements quotidiens sur 60 séances, annualisé. C'est le passé, pas une prévision.",
    pourquoi: "Sert de point de comparaison à l'IV (voir « Écart IV ») et de proxy dans les calculs Black-Scholes du Labo. Ne voit pas les événements futurs comme les résultats.",
    bandes: [],
  },
  delta: {
    label: 'Delta — sensibilité au prix et probabilité approximative',
    quoi: "Pour une option, le delta mesure de combien son prix bouge pour chaque 1$ de mouvement du titre sous-jacent (ex. delta 0.20 ≈ +0.20$ sur l'option si le titre monte de 1$). C'est aussi, par approximation courante (pas une garantie mathématique), la probabilité que l'option termine dans la monnaie à l'échéance — delta 0.20 ≈ environ 20 % de chances.",
    pourquoi: "Sert de raccourci pour choisir un strike sans calculer soi-même les probabilités. Un Put VENDU à delta 0.15-0.25 a ≈75-85 % de chances d'expirer sans valeur (favorable au vendeur de prime). Un LEAPS Call ACHETÉ à delta 0.70-0.85 bouge presque comme l'action elle-même (mouvement de prix très corrélé) — c'est ce qui lui permet de la remplacer dans le PMCC.",
    bandes: [],
  },

  // Trois pastilles du header ajoutées le 28/9/2026 aux côtés du VIX.
  // Bandes de couleur ajoutées le même jour (demande de JP, « propose-moi un
  // texte simple et un code de couleur ») — seuils PROPOSÉS par Claude à
  // partir de l'historique documenté publiquement (pas un standard Cboe
  // officiel fixé en dur), sources dans CLAUDE.md et dans config.js.
  cor1m: {
    label: 'COR1M — Corrélation implicite (1 mois)',
    quoi: "Mesure à quel point les titres du S&P 500 bougent ENSEMBLE plutôt que chacun de son côté, sur le mois à venir — dérivée des prix d'options, comme le VIX.",
    pourquoi: "Complète le VIX : une hausse de la volatilité peut venir d'un vrai stress de marché (tout baisse ensemble, corrélation haute) ou rester propre à quelques titres (stock-picking, corrélation basse). Utile pour juger si un mouvement de marché est large ou isolé.",
    bandes: [
      { couleur: 'vert', seuil: '< 15', sens: "Faible — chaque titre bouge pour ses propres raisons (résultats, nouvelles), pas pour des raisons de marché." },
      { couleur: 'amber', seuil: '15–30', sens: "Modérée — mélange de mouvements propres au titre et de mouvements de marché." },
      { couleur: 'rouge', seuil: '> 30', sens: "Élevée — le marché bouge en bloc (macro, risk-off) : la diversification protège moins." },
    ],
  },
  vixeq: {
    label: 'VIXEQ — Volatilité implicite des titres (1 mois)',
    quoi: "Comme le VIX, mais mesuré sur chaque titre du S&P 500 pris individuellement plutôt que sur l'indice dans son ensemble. VIXEQ dépasse presque TOUJOURS le VIX : un titre seul bouge naturellement plus que l'indice, qui lisse les mouvements de 500 titres entre eux.",
    pourquoi: "Ce n'est donc pas son niveau seul qui compte, mais son ÉCART avec le VIX. Un grand écart veut dire que le marché s'attend à ce que les titres bougent beaucoup chacun de leur côté, sans que l'indice bouge autant — souvent un signe de résultats/nouvelles à venir plutôt que de stress général. La pastille affiche cet écart et se colore sur lui, pas sur le niveau brut de VIXEQ.",
    bandes: [
      { couleur: 'vert', seuil: 'Écart < 16 pts', sens: "Proche de la moyenne historique (≈13 pts) — rien d'inhabituel." },
      { couleur: 'amber', seuil: 'Écart 16–25 pts', sens: "Nettement au-dessus de la moyenne." },
      { couleur: 'rouge', seuil: 'Écart > 25 pts', sens: "Proche des niveaux historiques les plus élevés observés (record : 34 pts, juillet 2026)." },
    ],
  },
  dspx: {
    label: 'DSPX — Dispersion entre les titres (1 mois)',
    quoi: "Mesure à quel point les titres du S&P 500 vont bouger DIFFÉREMMENT les uns des autres sur le mois à venir — l'inverse, en un sens, de COR1M : plus les titres se ressemblent (corrélation haute), moins ils se dispersent.",
    pourquoi: "Une dispersion élevée dit que chaque titre devrait suivre sa propre histoire (bon terrain pour repérer des titres individuels) ; une dispersion faible dit que tout bouge ensemble, comme un COR1M élevé.",
    bandes: [
      { couleur: 'rouge', seuil: '< 15', sens: "Faible — les titres bougent ensemble, cohérent avec une corrélation élevée." },
      { couleur: 'amber', seuil: '15–30', sens: "Modérée." },
      { couleur: 'vert', seuil: '> 30', sens: "Élevée — chaque titre suit sa propre histoire, cohérent avec une corrélation faible." },
    ],
  },
  // Tuiles de la carte « Fondamentaux » (2/10/2026) — mêmes popovers que les indicateurs.
  fcfEps: {
    label: 'EPS — bénéfice par action (12 derniers mois)',
    quoi: "Le bénéfice net de l'entreprise divisé par son nombre d'actions, sur les 12 derniers mois (trailing). C'est la part de profit « attribuée » à chaque action.",
    pourquoi: "Base du P/E (prix ÷ EPS). Un EPS qui monte d'année en année est le signe d'une entreprise qui gagne réellement de l'argent. C'est un chiffre comptable : il peut être gonflé ou réduit par des éléments non récurrents, d'où l'intérêt de le comparer au FCF, plus proche du cash réel.",
    bandes: [
      { couleur: 'vert', seuil: 'Positif et ≥ dernier exercice', sens: "L'entreprise gagne de l'argent et son bénéfice par action progresse." },
      { couleur: 'amber', seuil: 'Positif mais en baisse', sens: "Rentable, mais le bénéfice par action recule par rapport au dernier exercice complet." },
      { couleur: 'rouge', seuil: '≤ 0', sens: "Perte : pas de bénéfice — le P/E n'existe pas, regarder le P/S et le FCF." },
    ],
  },
  fcfTotal: {
    label: 'FCF — flux de trésorerie disponible (12 derniers mois)',
    quoi: "L'argent réellement dégagé par l'activité après les investissements nécessaires (flux d'exploitation moins dépenses d'investissement), sur les 12 derniers mois.",
    pourquoi: "C'est le cash que l'entreprise peut utiliser pour rembourser sa dette, racheter des actions ou verser des dividendes. Plus difficile à « maquiller » que le bénéfice comptable. Un FCF négatif n'est pas toujours mauvais (croissance financée par investissement), mais il faut alors regarder la régularité dans la grille ci-dessous.",
    bandes: [
      { couleur: 'vert', seuil: `≥ ${_FB.fcfMargeVert} % des revenus`, sens: "Marge de FCF confortable : l'activité transforme bien ses ventes en cash." },
      { couleur: 'amber', seuil: `0 à ${_FB.fcfMargeVert} %`, sens: "FCF positif mais mince — peu de marge d'erreur." },
      { couleur: 'rouge', seuil: '< 0', sens: "L'activité consomme plus de cash qu'elle n'en dégage (parfois voulu : croissance financée par l'investissement)." },
    ],
  },
  fcfPerShare: {
    label: 'FCF par action (12 mois)',
    quoi: "Le FCF divisé par le nombre d'actions diluées.",
    pourquoi: "Ramène le cash généré à ce que représente UNE action : il baisse si l'entreprise émet de nouvelles actions (dilution) même quand le FCF total monte. C'est la base du rendement du FCF et du critère « croissance du FCF par action » du pointage.",
    bandes: [
      { couleur: 'vert', seuil: `hausse ≥ ${_FB.fcfParActionHausseVert} % vs dernier exercice`, sens: "Le cash par action progresse nettement (ou redevient positif)." },
      { couleur: 'amber', seuil: `${_FB.fcfParActionBaisseRouge} % à +${_FB.fcfParActionHausseVert} %`, sens: "Stable : ni progression ni recul marqué." },
      { couleur: 'rouge', seuil: `baisse > ${Math.abs(_FB.fcfParActionBaisseRouge)} % ou ≤ 0`, sens: "Le cash par action recule ou est négatif — dilution ou baisse du FCF." },
    ],
  },
  fcfYield: {
    label: 'Rendement du FCF (12 mois)',
    quoi: "FCF par action ÷ prix courant de l'action : le cash généré chaque année, en % de ce que coûte l'action aujourd'hui.",
    pourquoi: "L'inverse « cash » du P/E. Plus il est élevé, plus l'action est « bon marché » par rapport au cash qu'elle produit. À comparer au taux sans risque (≈ 4 %) : un rendement très inférieur signifie qu'on paie cher la croissance future. Les seuils ci-dessous sont des repères usuels (réglables dans config.js), pas des règles de marché.",
    bandes: [
      { couleur: 'vert', seuil: `≥ ${_FB.rendementVert} %`, sens: "Cash généré élevé par rapport au prix — valorisation plutôt attrayante." },
      { couleur: 'amber', seuil: `${_FB.rendementRouge}–${_FB.rendementVert} %`, sens: "Zone intermédiaire — comparable au taux sans risque, la croissance doit justifier le prix." },
      { couleur: 'rouge', seuil: `< ${_FB.rendementRouge} %`, sens: "Peu de cash par dollar investi — le prix repose surtout sur la croissance attendue." },
    ],
  },
  cashEquivalents: {
    label: 'Trésorerie (cash & equivalents)',
    quoi: "L'argent disponible ou presque : encaisse et placements à court terme du dernier bilan trimestriel publié (total cash chez Yahoo Finance), comparé à la dette totale.",
    pourquoi: "Dit si l'entreprise peut absorber un mauvais trimestre ou rembourser ses dettes sans émettre d'actions ni emprunter. Le rapport trésorerie ÷ dette est le repère : au-dessus de 1, la trésorerie nette est positive. La dette de Yahoo inclut les contrats de location, ce qui pénalise certains détaillants. Ne s'applique pas aux banques. Critère « Solidité du bilan » du score : 0 % par défaut, réglable dans Réglages → Valeur personnalisée.",
    bandes: [
      { couleur: 'vert', seuil: `trésorerie ÷ dette ≥ ${_FB.tresorerieVert} (ou aucune dette)`, sens: "Trésorerie nette positive : le bilan se tient seul." },
      { couleur: 'amber', seuil: `${_FB.tresorerieRouge}–${_FB.tresorerieVert}`, sens: "Dette supérieure à la trésorerie mais couverte en partie — à lire avec le FCF." },
      { couleur: 'rouge', seuil: `< ${_FB.tresorerieRouge}`, sens: "Peu de liquidités face à la dette — dépend du refinancement ou du FCF." },
    ],
  },
  priceToSales: {
    label: 'P/S — Price-to-Sales (12 mois)',
    quoi: "Capitalisation boursière ÷ revenus des 12 derniers mois : ce que le marché paie pour chaque dollar de ventes.",
    pourquoi: "Indispensable pour les entreprises non rentables en forte croissance, où le P/E n'existe pas (bénéfice nul ou négatif). Il ne dit rien des marges : un P/S bas peut cacher une entreprise peu rentable, un P/S haut est normal pour une société en forte croissance. À lire contre la médiane de son secteur.",
    bandes: [
      { couleur: 'vert', seuil: '1–2', sens: "Repère « très bien » retenu dans castellana." },
      { couleur: 'amber', seuil: '< 1', sens: "Peu cher, mais à vérifier : marges faibles ou activité en difficulté ?" },
      { couleur: 'amber', seuil: '> 2', sens: "Plus cher — acceptable seulement avec une forte croissance des revenus. Comparer au secteur." },
    ],
  },
  // --- En-têtes des tableaux A2, A3, B4 et de l'onglet Roue (H2, H5) — 16/10/2026 ---
  peSecteur: {
    label: 'P/E moyen du secteur',
    quoi: "Ratio cours/bénéfice (12 derniers mois) de l'ETF sectoriel lui-même, calculé par son émetteur sur tous ses titres.",
    pourquoi: "Un vrai agrégat de marché, pas une moyenne de quelques pairs : il situe la cherté d'un secteur entier. À comparer d'un secteur à l'autre et au S&P 500 (dernière ligne), en gardant en tête qu'un secteur en forte croissance a naturellement un P/E plus élevé.",
    bandes: [],
  },
  pegSecteur: {
    label: 'PEG moyen du secteur',
    quoi: "Moyenne des PEG (P/E ÷ croissance des bénéfices) des titres de TA watchlist qui appartiennent à ce secteur.",
    pourquoi: "Yahoo ne donne aucun PEG au niveau d'un ETF : c'est une approximation par tes pairs suivis, pas un agrégat de marché. « — » = aucun titre suivi dans ce secteur ; le nombre de pairs est dans l'infobulle de la cellule.",
    bandes: [
      { couleur: 'vert', seuil: '≤ 1', sens: "Croissance qui justifie le prix, en moyenne sur tes titres du secteur." },
      { couleur: 'amber', seuil: '> 1', sens: "Valorisation tendue au regard de la croissance." },
    ],
  },
  variation: {
    label: 'Variation du jour',
    quoi: "Variation du prix depuis la clôture de la veille, en %.",
    pourquoi: "C'est elle qui classe ce tableau par défaut : il répond à « qu'est-ce qui bouge dans ce secteur aujourd'hui ? », pas à « qu'est-ce qui se déclenche ? » (voir Setup).",
    bandes: [],
  },
  contexte: {
    label: 'Contexte (−3 à +3)',
    quoi: "Le titre vaut-il la peine d'être suivi ? Somme de trois signaux : Golden Cross, force relative contre le S&P 500, tendance de l'OBV (+1 favorable, −1 défavorable, 0 neutre).",
    pourquoi: "Sert à CHOISIR le titre, jamais à valider une entrée : un excellent contexte sans setup veut dire « à surveiller », pas « à acheter ».",
    bandes: [
      { couleur: 'vert', seuil: '≥ 1', sens: "Titre qui vaut la peine : au moins un signal favorable net (tendance de fond, surperformance, volume qui confirme). Avec un Setup ≥ 2, c'est « prêt »." },
      { couleur: 'amber', seuil: '0', sens: "Contexte mitigé." },
      { couleur: 'rouge', seuil: '< 0', sens: "Contexte défavorable." },
    ],
  },
  setup: {
    label: 'Setup (−2 à +5)',
    quoi: "Est-ce que ça se déclenche maintenant ? L'alignement des moyennes (prix > SMA rapide > moyenne > lente) est une PORTE (±2) ; s'ajoutent la fraîcheur du signal, le RSI en zone et le prix au-dessus du VWAP.",
    pourquoi: "C'est le filtre d'entrée de la stratégie. Sans alignement, il n'y a pas de setup, quels que soient le RSI ou le VWAP.",
    bandes: [
      { couleur: 'vert', seuil: '≥ 2', sens: "Prêt si le Contexte est aussi ≥ 1 : alignement haussier en place, signal récent." },
      { couleur: 'amber', seuil: '1', sens: "À surveiller : alignement haussier, mais le reste (fraîcheur, RSI, VWAP) ne suit pas encore, ou signal ancien (« trop tard »)." },
      { couleur: 'rouge', seuil: '≤ 0', sens: "Pas de setup : moyennes non alignées (0) ou alignement baissier (−2)." },
    ],
  },
  signal: {
    label: 'Signal — âge de l\'alignement',
    quoi: "Nombre de séances depuis le début de l'alignement haussier des moyennes, sans interruption. 1 j = le signal vient de se déclencher.",
    pourquoi: "La stratégie entre au PREMIER alignement : un signal vieux de plusieurs semaines veut dire que le mouvement est en partie fait (« trop tard »).",
    bandes: [],
  },
  secteur: {
    label: 'Secteur',
    quoi: "Secteur du titre selon Yahoo Finance (classification proche du GICS).",
    pourquoi: "Un proxy de corrélation : cinq candidats du même secteur sont cinq paris corrélés, pas cinq paris indépendants.",
    bandes: [],
  },
  prix: {
    label: 'Prix',
    quoi: "Dernier cours connu (Yahoo, différé d'environ 15 minutes pendant la séance).",
    pourquoi: "Sert au stop, à la taille de position et au filtre de prix du Screener.",
    bandes: [],
  },
  volume: {
    label: 'Volume',
    quoi: "Nombre d'actions échangées dans la séance (partiel pendant la séance).",
    pourquoi: "Mesure de liquidité : sous 1 million d'actions par jour, l'écart entre l'offre et la demande coûte plus cher et l'ordre au marché devient risqué.",
    bandes: [],
  },
  stop: {
    label: 'Stop',
    quoi: "Distance du stop = ATR(14) × le multiplicateur de la Fiche de trade, et prix du stop = prix − cette distance.",
    pourquoi: "Un stop calé sur la volatilité du titre : assez large pour ne pas sauter sur du bruit, assez serré pour limiter la perte à 1 R.",
    bandes: [],
  },
  tailleCharge: {
    label: 'Taille / charge',
    quoi: "Nombre d'actions pour risquer le % de capital choisi dans la Fiche de trade, et ce que ce trade ajouterait à la charge de portefeuille (somme des risques ouverts).",
    pourquoi: "Une ligne grisée dépasserait le seuil d'alerte de charge (6 % par défaut). C'est un plafond : la taille ne peut que baisser si le titre est corrélé à une position ouverte.",
    bandes: [],
  },
  resultats: {
    label: 'Résultats (jours)',
    quoi: "Jours avant la prochaine publication des résultats trimestriels.",
    pourquoi: "Entrer juste avant des résultats est un pari d'une autre nature : le titre peut ouvrir très loin du stop, qui ne protège plus.",
    bandes: [
      { couleur: 'rouge', seuil: '≤ 5 j', sens: "Résultats imminents." },
      { couleur: 'amber', seuil: '≤ 10 j', sens: "Résultats proches. Dans le tableau du Screener, le seuil est de 7 jours : plus près, la ligne est grisée." },
      { couleur: 'vert', seuil: '> 10 j', sens: "Pas de résultats à court terme." },
    ],
  },
  industrie: {
    label: 'Industrie',
    quoi: "Sous-industrie du titre selon Yahoo (ex. « Semiconductors », « Software - Infrastructure »).",
    pourquoi: "Plus fine que le secteur : c'est elle qui sert à comparer le P/E du titre à celui de ses pairs (colonne P/E industrie).",
    bandes: [],
  },
  peIndustrie: {
    label: 'P/E industrie',
    quoi: "Moyenne des P/E des titres de ce tableau qui partagent la même industrie (le nombre de pairs est dans l'infobulle de la cellule).",
    pourquoi: "Une approximation par pairs, pas un agrégat de marché : avec un seul pair, c'est le P/E du titre lui-même. Sert à dire si le titre est cher par rapport à ses semblables.",
    bandes: [],
  },
  psSecteur: {
    label: 'P/S du secteur',
    quoi: "Médiane du P/S des titres de ce tableau appartenant au même secteur, s'il y en a au moins 3.",
    pourquoi: "La médiane plutôt que la moyenne : un titre à 70× les ventes tirerait tout le secteur. « — » sous 3 pairs.",
    bandes: [],
  },
  roueType: {
    label: 'Type',
    quoi: "PUT vendu (on s'engage à acheter 100 actions par contrat au strike) ou CALL vendu (on s'engage à vendre les actions détenues au strike).",
    pourquoi: "La Roue alterne : puts vendus tant qu'on n'a pas les actions, calls couverts une fois assigné.",
    bandes: [],
  },
  roueDates: {
    label: 'Vendu → échéance',
    quoi: "Date de vente de l'option, puis date d'échéance (jour-mois).",
    pourquoi: "La durée entre les deux sert à la règle de prime : plus l'échéance est loin, plus la prime exigée est grande.",
    bandes: [],
  },
  rouePrime: {
    label: 'Prime',
    quoi: "Prime encaissée par action à la vente (× 100 par contrat).",
    pourquoi: "C'est le revenu de la Roue. Elle est acquise à la vente ; seul un rachat en retire une partie.",
    bandes: [],
  },
  rouePrimeStrike: {
    label: 'Prime / strike',
    quoi: "Prime encaissée ÷ strike, en %. ⚠ si elle est sous la règle des Options : 0,5 % du strike par tranche de 5 jours de durée.",
    pourquoi: "Le rendement brut de la position sur le capital engagé. Sous la règle, la prime ne paie pas assez le risque d'être assigné.",
    bandes: [
      { couleur: 'vert', seuil: 'règle respectée', sens: "Prime suffisante pour la durée." },
      { couleur: 'amber', seuil: '⚠ sous la règle', sens: "Prime trop faible pour la durée du contrat." },
    ],
  },
  roueQte: {
    label: 'Quantité / contrats',
    quoi: "Nombre de contrats ; un contrat porte sur 100 actions.",
    pourquoi: "Capital engagé d'un put = strike × 100 × contrats.",
    bandes: [],
  },
  roueCours: {
    label: 'Cours',
    quoi: "Dernier cours connu du titre (Yahoo, différé).",
    pourquoi: "Sert à la distance au strike et au latent des actions détenues. « — » si le cours n'a pas pu être lu.",
    bandes: [],
  },
  roueDistance: {
    label: 'Distance au strike',
    quoi: "Écart entre le strike et le cours, en % du cours. OTM = hors la monnaie (marge avant d'être touché) ; ITM = dans la monnaie.",
    pourquoi: "Un put ITM ou un call ITM à l'échéance sera probablement assigné : c'est le moment de décider (laisser assigner, rouler ou racheter).",
    bandes: [
      { couleur: 'vert', seuil: '≥ 2 % OTM', sens: "Marge confortable." },
      { couleur: 'amber', seuil: '< 2 % OTM', sens: "Le cours s'approche du strike." },
      { couleur: 'rouge', seuil: 'ITM', sens: "Dans la monnaie : assignation probable." },
    ],
  },
  roueEarning: {
    label: 'Earning — résultats',
    quoi: "Jours avant la prochaine publication des résultats du titre (positions ouvertes seulement).",
    pourquoi: "Des résultats avant l'échéance peuvent faire sauter le cours bien au-delà du strike : un put vendu peut être assigné très bas.",
    bandes: [
      { couleur: 'rouge', seuil: '≤ 5 j', sens: "Résultats imminents." },
      { couleur: 'amber', seuil: '≤ 10 j', sens: "Résultats proches." },
      { couleur: 'vert', seuil: '> 10 j', sens: "Pas de résultats à court terme." },
    ],
  },
  rouePl: {
    label: 'P/L net',
    quoi: "(Prime − rachat) × actions − commissions. Pour une position ouverte : la prime déjà encaissée moins la commission d'ouverture.",
    pourquoi: "Une position ouverte n'entre dans aucun profit réalisé : ce chiffre est ce qui restera si elle expire sans valeur.",
    bandes: [],
  },
  roueStatut: {
    label: 'Statut',
    quoi: "ouvert · expiré (sans valeur, prime gardée) · assigné (actions achetées ou vendues au strike) · racheté · roulé (racheté et remplacé par une nouvelle position du même cycle).",
    pourquoi: "Une assignation n'est pas un échec dans la Roue : elle fait passer du put au call couvert.",
    bandes: [],
  },
  roueOuverture: {
    label: 'Ouverture',
    quoi: "Date de vente de l'option.",
    pourquoi: "Début de la durée qui sert au rendement annualisé.",
    bandes: [],
  },
  roueEcheance: {
    label: 'Échéance',
    quoi: "Date d'expiration du contrat.",
    pourquoi: "Fin prévue de la position ; une clôture plus tôt (rachat, roulement) la remplace pour le calcul des jours.",
    bandes: [],
  },
  roueCommissions: {
    label: 'Commissions',
    quoi: "Commission d'ouverture + commission de clôture (rachat), en $.",
    pourquoi: "Déduites du P/L net. Le Sheets du club oubliait la commission de rachat ; castellana la compte.",
    bandes: [],
  },
  roueRachat: {
    label: 'Rachat',
    quoi: "Prime payée par action pour racheter (ou rouler) la position.",
    pourquoi: "Seul un rachat ou un roulement coûte une prime ; une expiration ou une assignation ne coûte rien de plus.",
    bandes: [],
  },
  roueJours: {
    label: 'Jours',
    quoi: "Jours entre l'ouverture et la clôture (ou l'échéance si la position est ouverte).",
    pourquoi: "« — » si les dates sont incohérentes (clôture avant l'ouverture) : la ligne est signalée ⚠ plutôt que de produire un rendement absurde.",
    bandes: [],
  },
  roueAnnualise: {
    label: 'Rendement annualisé',
    quoi: "P/L net ÷ capital (strike × 100 × contrats) × 365 ÷ jours.",
    pourquoi: "Permet de comparer des positions de durées différentes. Sur quelques jours, il grossit vite : à lire avec le P/L en dollars.",
    bandes: [],
  },
  roueCapital: {
    label: 'Capital',
    quoi: "Strike × 100 × contrats : l'argent garanti par un put vendu (vue cash-secured).",
    pourquoi: "Base du rendement. Sur un compte sur marge, le capital réellement bloqué est plus faible (feature #442).",
    bandes: [],
  },
  roueCycle: {
    label: 'Cycle',
    quoi: "Numéro du cycle de la Roue : toutes les positions d'un même titre, du premier put vendu jusqu'à la vente des actions.",
    pourquoi: "Le bilan par cycle (H7) additionne primes, commissions, dividendes et gain ou perte sur les actions.",
    bandes: [],
  },
  roueCompte: {
    label: 'Compte',
    quoi: "Compte où la position est logée : margin, RRSP ou corporatif.",
    pourquoi: "Le REER ne permet aucune déduction de perte en capital : savoir où vit chaque position compte pour la fiscalité.",
    bandes: [],
  },
};

// Exposé en global pour le <script> classique de index.html (pas de module).
window.GLOSSAIRE = GLOSSAIRE;

// Bouton (i) d'un en-tête de tableau : ouvre le glossaire sans déclencher le tri de la colonne.
function glossInfoBtn(key) {
  return `<button type="button" class="info-btn" onclick="event.stopPropagation(); showGlossaire('${key}', this)" title="Aide">i</button>`;
}
// Ajoute le (i) à chaque <th data-gloss="clé"> du document (tableaux écrits dans index.html),
// juste avant la flèche de tri s'il y en a une. Idempotent.
function initGlossHeaders(root = document) {
  root.querySelectorAll('th[data-gloss]').forEach((th) => {
    if (th.querySelector(':scope > .info-btn')) return;
    const tpl = document.createElement('template');
    tpl.innerHTML = glossInfoBtn(th.dataset.gloss);
    const arrow = th.querySelector(':scope > .sort-arrow');
    th.insertBefore(tpl.content.firstChild, arrow);
  });
}
