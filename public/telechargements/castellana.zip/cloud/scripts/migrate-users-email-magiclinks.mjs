#!/usr/bin/env node
// Migration idempotente (19/9/2026) — console CRUD bilbao + magic link.
// La base réelle est déjà déployée : `schema.sql` (CREATE TABLE IF NOT
// EXISTS) ne touche jamais aux colonnes d'une table existante, donc
// "email"/"disabled" doivent être ajoutées via ALTER TABLE, qui n'est PAS
// rejouable sans erreur ("duplicate column") — même discipline que
// server/db.js (migration locale des trades, PRAGMA table_info avant
// chaque ALTER, voir CLAUDE.md).
//
// Usage :
//   node scripts/migrate-users-email-magiclinks.mjs             (D1 local)
//   node scripts/migrate-users-email-magiclinks.mjs --remote    (vrai D1)

import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const remote = process.argv.includes('--remote');
const flag = remote ? '--remote' : '--local';

function run(sql, { json = false } = {}) {
  const args = ['wrangler', 'd1', 'execute', 'castellana-db', flag, '--command', sql];
  if (json) args.push('--json');
  const result = spawnSync('npx', args, { cwd: ROOT, stdio: json ? ['ignore', 'pipe', 'pipe'] : 'inherit' });
  if (result.status !== 0) {
    console.error(json ? result.stderr?.toString() : '');
    throw new Error(`Échec de la commande wrangler (SQL: ${sql})`);
  }
  if (!json) return null;
  return JSON.parse(result.stdout.toString());
}

function existingColumns(table) {
  const out = run(`PRAGMA table_info(${table})`, { json: true });
  return new Set(out[0].results.map((c) => c.name));
}

console.log(`\nMigration users.email / users.disabled / magic_links (${remote ? 'D1 distant' : 'D1 local'})...`);

const cols = existingColumns('users');
if (!cols.has('email')) {
  console.log('- ajout de la colonne users.email');
  run('ALTER TABLE users ADD COLUMN email TEXT');
} else {
  console.log('- users.email déjà présente, ignorée');
}
if (!cols.has('disabled')) {
  console.log("- ajout de la colonne users.disabled");
  run("ALTER TABLE users ADD COLUMN disabled INTEGER NOT NULL DEFAULT 0 CHECK (disabled IN (0,1))");
} else {
  console.log('- users.disabled déjà présente, ignorée');
}

console.log('- création de magic_links (si absente)');
run(`CREATE TABLE IF NOT EXISTS magic_links (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at INTEGER NOT NULL,
  used_at TEXT
)`);
run('CREATE INDEX IF NOT EXISTS idx_magic_links_user ON magic_links(user_id)');

console.log(`\nMigration terminée (${flag}). Rejouable sans erreur.`);
