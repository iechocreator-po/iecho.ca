// config.js — réglages castellana, éditable sans toucher au code applicatif.
// Chargé avant le script de l'app (voir index.html). Toute valeur ici a une
// contrepartie par défaut dans applyConfig() (index.html) si ce fichier est
// absent ou incomplet.
const CFG = {
  // Périodes des indicateurs suivis. Ne pas remplacer sma par ema sans en
  // discuter : filtre de tendance validé avec JP (voir
  // design_assistant_swing_trading.md section 4.1). SMA = Simple Moving
  // Average, fenêtre glissante (révisé 29/8/2026 — c'était une SMMA/RMA
  // lissée jusque-là, standardisé sur SMA pour éliminer une confusion de
  // terminologie SMMA/MM dans les capsules d'aide).
  //
  // ⚠️ CES VALEURS NE SONT PLUS LA SOURCE DE VÉRITÉ (feature 351, 7/9/2026).
  // Les périodes des moyennes mobiles et du RSI sont désormais éditables
  // depuis l'app (Réglages → Valeur personnalisée), stockées en base
  // (server/preferences.js) et appliquées RÉELLEMENT au calcul sur tous les
  // écrans — screening, fiche de trade et Labo.
  //
  // Ce qui restait ici n'était de toute façon qu'un décor sur la plupart des
  // écrans : les libellés suivaient `config.js` pendant que le calcul serveur
  // restait figé à 9/21/100. C'est cet écart que la feature 351 supprime.
  //
  // Les valeurs ci-dessous ne servent plus qu'à l'affichage AVANT le premier
  // chargement des préférences, et sont aussitôt remplacées. Les vrais
  // défauts vivent dans `DEFAULTS` de server/preferences.js.
  //
  // `smaLente` passe de 100 à 50 : demande explicite de JP (feature 351,
  // points 4a et 4b). ÉCART ASSUMÉ avec design_assistant_swing_trading.md,
  // qui fixe le filtre de tendance à 9/21/100 — à reporter dans ce document
  // et dans l'alerte Pine Script configurée sur TradingView.
  indicateurs: {
    smaRapide: 9,
    smaMoyenne: 21,
    smaLente: 50,
    atrPeriode: 14,
    rsiPeriode: 14,
  },

  // Bandes de couleur (vert/amber/rouge) — voir design_assistant_swing_trading.md
  // section 4.4 pour la logique complète associée à chaque seuil.
  bandes: {
    vix: { normalBas: 15, normalHaut: 20, nervositeHaut: 30 },
    rsi: { surventeHaut: 30, entreeBas: 40, entreeHaut: 70 },
    forceRelative: { seuilPts: 5 },
    goldenCross: { seuilPct: 1 },
  },

  // Filtres de l'écran de screening (feature 322). Ce sont des critères
  // SUPPLÉMENTAIRES aux 4 colonnes du score (RSI/Force/Golden Cross/OBV) —
  // affichés en colonnes, activables comme filtres. `actif: false` = le
  // critère s'affiche mais ne filtre pas l'univers tant que JP ne coche pas
  // la case correspondante dans l'UI. Bornes Prix/Float resserrées le
  // 6/9/2026 (demande de JP) — ajuster ici si l'univers suivi change de
  // profil. Doublé côté backend (SCREEN_FILTERS dans server/index.js) —
  // reporter à la main tout changement de seuil.
  screening: {
    prix: { min: 5, max: 1000 },        // Price : between x$ et y$
    floatMin: 10,                        // Float (actions en circulation), en millions
    floatMax: 20,                        // en millions
    volumeMin: 1_000_000,                // Afficher/valoriser si volume > 1M
    pegMax: 1,                           // PEG ratio : 1 and below
    betaMin: 1,                          // Beta 5Y : plus grand que 1
    calculerVwap: true,                  // VWAP intraday (below price) — désactivable si trop lent
  },

  // Sizing — fiche de trade (design_assistant_swing_trading.md section 4.5).
  sizing: {
    atrMultiplicateur: { min: 1, max: 3, step: 0.25, defaut: 1.5 },
    risquePctBase: { min: 0.25, max: 3, step: 0.25, defaut: 1 },
    discounts: {
      correlation: 0.7,
      vixPanique: 0.5,
      vixNervosite: 0.75,
      rsiSurachat: 0.8,
      obvDistribution: 0.7,
    },
    chargePortefeuille: { avertissement: 4, alerte: 6 },
  },

  // Valeurs par défaut affichées à l'ouverture (démo / première utilisation).
  defauts: {
    ticker: 'AMD',
    capital: 50000,
  },

  // Seuils du mode "filtré" du tableau "Titres les plus performants du
  // secteur" (2/9/2026) — exclut les micro-caps peu liquides de la liste
  // curatée par secteur (server/sectors.js, SECTOR_TOP_CANDIDATES). Doublé
  // côté backend (SECTOR_TOP_FILTERS dans server/sectors.js) — reporter à la
  // main tout changement de seuil.
  sectorTop: {
    marketCapMinM: 2000, // Cap. boursière > 2 G$
    volumeMin: 1_000_000,
  },

  // Onglet Labo (5/9/2026) — paramètres des séquences de stratégies
  // d'options (js/strategies-labo.js). Aucune donnée d'options réelle
  // (chaîne, delta, prime) n'est branchée dans cette app.
  //
  // Depuis la révision du 5/9/2026 (demande de JP T2 : "pourquoi choisir ce
  // prix ?"), les zones de strike ne sont plus un multiple arbitraire de
  // l'ATR (qui n'avait aucun lien mathématique avec le Delta cible annoncé
  // à côté) — elles sont dérivées de Black-Scholes à partir du Delta cible
  // réel, du prix, et de la volatilité HISTORIQUE du titre (calculée
  // serveur, server/indicators.js). Volatilité historique = PROXY de la
  // volatilité implicite réelle du marché (que cette app n'a aucune source
  // pour obtenir) — l'écart entre les deux peut être important autour
  // d'événements comme les résultats trimestriels. Toujours une estimation,
  // jamais une vraie donnée d'options — à valider chez un courtier.
  labo: {
    // Ticker par défaut de l'onglet Labo — distinct de CFG.defauts.ticker
    // (AMD, utilisé par Secteurs/Screener/Fiche de trade) à la demande de
    // JP (5/9/2026).
    defaultTicker: 'TQQQ',
    put: { dteMin: 30, dteMax: 45, deltaMin: 0.15, deltaMax: 0.25 },
    call: { dteMin: 30, dteMax: 45, deltaMin: 0.15, deltaMax: 0.25 },
    profitTake: { min: 50, max: 80 }, // % du profit max, prise de profit anticipée
    // Taux sans risque utilisé par Black-Scholes — constante approximative
    // (proxy du rendement des bons du Trésor américain à court terme),
    // AUCUNE source de taux en direct n'est branchée dans cette app.
    riskFreeRate: 0.04,
    // Poor Man's Covered Call — LEAPS call profondément ITM en remplacement
    // des 100 actions.
    pmcc: {
      leapsDteMinJours: 180,        // minimum annoncé à l'utilisateur (6 mois)
      leapsDteTypiqueJours: 365,    // échéance utilisée pour le calcul Black-Scholes (1 an, point de départ courant)
      leapsDeltaMin: 0.70,
      leapsDeltaMax: 0.85,
      rouleAvantJours: 90,          // rouler le LEAPS avant qu'il ne reste que ce nombre de jours
    },
  },

  // Télémétrie testeurs (6/9/2026) — castellana tourne en local chez chaque
  // testeur (pas d'hébergement partagé, décision JP), donc aucune vue
  // d'ensemble n'est possible sans un point de collecte externe. Événements
  // envoyés directement du navigateur vers un petit Cloudflare Worker
  // (telemetry-worker/) — server/index.js n'est PAS impliqué. Voir
  // CLAUDE.md section "Télémétrie testeurs" pour le détail complet.
  //
  // `sharedToken` n'est PAS un mécanisme de sécurité réelle — c'est un
  // filtre anti-bruit pour éviter qu'un bot qui découvrirait l'URL du
  // Worker ne pollue la base de données. Il est visible dans le code source
  // du navigateur par construction (comme tout secret purement côté
  // client) ; le repo est privé, mais ne pas le traiter comme un vrai
  // credential.
  //
  // `endpoint` reste vide tant que JP n'a pas déployé le Worker
  // (telemetry-worker/README.md) — la télémétrie s'auto-désactive
  // silencieusement (aucune erreur visible) tant que ce champ est vide.
  telemetry: {
    enabled: true,
    endpoint: 'https://castellana-telemetry.iechocreator.workers.dev', // déployé le 6/9/2026
    sharedToken: 'ca614bd00a6e166c352bdc4964c857b7',
    // Qui peut se sélectionner dans le menu d'identité (pas un vrai login —
    // voir CLAUDE.md, T3 reporté). Renommer librement selon les vrais
    // testeurs.
    testeurs: ['JP', 'Louis', 'Guillaume'],
  },
};
