@echo off
REM demarrer.bat — lanceur self-install castellana (Windows)
REM
REM Revise le 7/9/2026 apres l'audit, en miroir de demarrer.command :
REM   1. PYTHON N'EST PLUS INSTALLE. Tous les indicateurs (RSI, SMA, Golden
REM      Cross, ATR, OBV, VIX) sont calcules depuis Yahoo Finance par l'app
REM      elle-meme. Installation ~223 Mo -> ~53 Mo, deux prerequis -> un seul.
REM      Qui veut quand meme le sidecar lance installer-sidecar.bat.
REM   2. La VERSION de Node est verifiee, pas seulement sa presence.
REM   3. Le navigateur s'ouvre sur le PORT REELLEMENT UTILISE (lu dans
REM      data\runtime.json) : le serveur se replie tout seul si 4700 est pris.
REM   4. La fenetre ne se referme plus en silence sur une erreur — chaque
REM      sortie passe par `pause`, sinon le testeur ne voit jamais le message.
REM
REM NON TESTE sur une vraie machine Windows — verifie par lecture de code et
REM coherence avec demarrer.command / scripts\run-sidecar.mjs uniquement.

setlocal enabledelayedexpansion
cd /d "%~dp0"

echo === castellana - installation et demarrage ===
echo.

REM --- 1. Node.js (version comprise) --------------------------------------
where node >nul 2>nul
if %errorlevel% neq 0 (
  echo [X] Node.js est requis mais introuvable sur cette machine.
  echo     Ouverture de la page de telechargement officielle...
  start https://nodejs.org/
  echo.
  echo Installe Node.js ^(version LTS^) puis relance ce fichier.
  pause
  exit /b 1
)
for /f "delims=" %%v in ('node -p "process.versions.node"') do set NODE_VERSION=%%v
for /f "delims=" %%v in ('node -p "process.versions.node.split^('.'^)[0]"') do set NODE_MAJOR=%%v
if !NODE_MAJOR! LSS 20 (
  echo [X] Node.js !NODE_VERSION! est trop ancien ^(castellana requiert la version 20 ou plus^).
  echo     Ouverture de la page de telechargement officielle...
  start https://nodejs.org/
  echo.
  echo Installe la version LTS puis relance ce fichier.
  pause
  exit /b 1
)
echo [OK] Node.js detecte ^(!NODE_VERSION!^).

REM --- 2. Dependances Node -------------------------------------------------
if exist "node_modules" (
  echo [OK] Dependances deja installees.
) else (
  echo Installation des dependances ^(premiere fois, peut prendre une minute^)...
  call npm install
  if !errorlevel! neq 0 (
    echo.
    echo [X] npm install a echoue.
    echo     Lance "npm run doctor" dans ce dossier pour savoir exactement
    echo     ce qui manque, ou consulte SETUP.md ^(section Depannage^).
    pause
    exit /b 1
  )
)
echo.

REM --- 3. Preflight ---------------------------------------------------------
REM Bloque AVANT de demarrer si quelque chose d'essentiel manque, plutot que
REM de laisser le testeur devant une page qui ne charge pas.
call npm run --silent doctor
if !errorlevel! neq 0 (
  echo Corrige les points ci-dessus, puis relance ce fichier.
  pause
  exit /b 1
)

REM --- 4. Demarrage ---------------------------------------------------------
echo Demarrage de castellana...
if exist "data\runtime.json" del "data\runtime.json"
start "castellana - serveur" cmd /k "npm start"

REM Le serveur ecrit data\runtime.json une fois qu'il ecoute reellement, avec
REM le port retenu. On attend ce fichier plutot que de dormir un temps fixe :
REM sur une machine lente, l'ancien `timeout 2` ouvrait le navigateur avant
REM que le serveur soit pret, et le testeur voyait une page d'erreur.
set APP_URL=
for /l %%i in (1,1,30) do (
  if not defined APP_URL (
    if exist "data\runtime.json" (
      for /f "delims=" %%u in ('node -p "require('./data/runtime.json').url" 2^>nul') do set APP_URL=%%u
    )
    if not defined APP_URL timeout /t 1 /nobreak >nul
  )
)

if defined APP_URL (
  start "" !APP_URL!
  echo.
  echo === castellana tourne - !APP_URL! ===
) else (
  echo.
  echo [!] Le serveur n'a pas confirme son demarrage dans les 30 secondes.
  echo     Regarde la fenetre "castellana - serveur", ou lance "npm run doctor".
)
echo Ferme la fenetre "castellana - serveur" pour tout arreter.
echo.
pause
endlocal
