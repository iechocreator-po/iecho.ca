// js/concepts-content.js — onglet "Concepts" du panneau Réglages (6/9/2026).
//
// Contenu transcrit depuis un guide fourni par JP :
// investment-dashboard/indicateur/GUIDE_15_CONCEPTS_TRADING.md (autre
// produit du portfolio) — pas de fichier partagé entre les deux repos,
// donc copié ici en dur (texte + 15 images, voir img/concepts/). Si le
// guide source change, il faut reporter les changements ici à la main.
//
// Chaque concept a une structure un peu différente dans le guide source
// (certains ont un "conseil du pro", d'autres un "piège à éviter", "Golden
// Cross" a les deux en listes ✅/❌, "Gaps" n'a pas de liste "à retenir"
// mais "les 4 types") — plutôt que de forcer un schéma rigide qui aurait
// perdu ces nuances, chaque concept porte directement son "corps" en HTML
// pré-écrit (`corps`), fidèle au texte source.

const CONCEPTS_TRADING = [
  {
    id: 'ema',
    titre: '1. EMA 50/100/200 — Suivre la tendance comme un pro',
    image: 'img/concepts/ema.jpg',
    corps: `
      <p><strong>C'est quoi ?</strong> Une EMA, c'est la moyenne du prix d'une action sur une période donnée (50 jours, 100 jours ou 200 jours), mais qui donne plus d'importance aux jours récents. Sur le graphique, ça donne une ligne bien lisse qui suit le prix de loin, sans les petits zigzags.</p>
      <p><strong>L'analogie</strong> : imagine ta moyenne de notes à l'école. Si tu regardes ta moyenne des 50 derniers devoirs, des 100 derniers, ou des 200 derniers, tu obtiens trois lignes différentes qui te disent si tu progresses (tendance haussière) ou si tu descends (tendance baissière). L'EMA 50, c'est ta tendance récente ; l'EMA 200, c'est ta tendance de fond, sur longtemps.</p>
      <p><strong>Ce qu'il faut retenir :</strong></p>
      <ul>
        <li>Prix <strong>au-dessus</strong> des 3 lignes → le marché monte (tendance haussière).</li>
        <li>Prix <strong>en-dessous</strong> des 3 lignes → le marché descend (tendance baissière).</li>
        <li>Prix <strong>coincé entre</strong> les lignes → le marché hésite (ça bouge sans vraie direction).</li>
      </ul>
      <p class="concept-note">💡 <strong>Le conseil du pro</strong> : avant de chercher le moment parfait pour acheter, demande-toi toujours : est-ce que je suis dans le sens de la tendance, ou est-ce que je vais à contre-courant ?</p>
    `,
  },
  {
    id: 'rsi',
    titre: '2. RSI — Détecter le surachat et la survente',
    image: 'img/concepts/rsi.jpg',
    corps: `
      <p><strong>C'est quoi ?</strong> Un chiffre entre 0 et 100 qui mesure si un titre a été acheté ou vendu « trop vite » récemment.</p>
      <p><strong>L'analogie</strong> : pense à un élastique. Si tu l'étires trop fort et trop vite dans un sens, il a tendance à revenir un peu en arrière. Le RSI, c'est la jauge qui te dit à quel point l'élastique est étiré.</p>
      <p><strong>Ce qu'il faut retenir :</strong></p>
      <ul>
        <li>RSI <strong>au-dessus de 70</strong> → zone de « surachat » (l'élastique est très étiré vers le haut, tout le monde achète, ça peut redescendre un peu).</li>
        <li>RSI <strong>sous 30</strong> → zone de « survente » (l'élastique est très étiré vers le bas, tout le monde vend, ça peut remonter un peu).</li>
      </ul>
      <p class="concept-note concept-note--piege">⚠️ <strong>Le piège à éviter</strong> : ce n'est PAS parce que le RSI est sous 30 qu'il faut acheter tout de suite, ni parce qu'il est au-dessus de 70 qu'il faut vendre. Le RSI mesure juste la vitesse du mouvement, il ne prédit pas un retournement. Il faut toujours le combiner avec la tendance générale.</p>
    `,
  },
  {
    id: 'macd',
    titre: '3. MACD — Le momentum en un coup d’œil',
    image: 'img/concepts/macd.jpg',
    corps: `
      <p><strong>C'est quoi ?</strong> Un outil qui compare deux moyennes de prix (une rapide et une lente) pour voir si l'élan (le « momentum ») d'un titre s'accélère ou ralentit.</p>
      <p><strong>L'analogie</strong> : c'est comme comparer ta vitesse de course sur les 100 derniers mètres avec ta vitesse sur les 300 derniers mètres. Si tu accélères par rapport à ta moyenne habituelle, ça se voit tout de suite.</p>
      <p><strong>Ce qu'il faut retenir :</strong></p>
      <ul>
        <li>Quand la ligne rapide (bleue) <strong>croise au-dessus</strong> de la ligne lente (orange) → <strong>croisement haussier</strong>, le momentum devient positif.</li>
        <li>Quand la ligne rapide <strong>croise en-dessous</strong> → <strong>croisement baissier</strong>, le momentum devient négatif.</li>
        <li>Les barres (l'histogramme) montrent à quel point ce momentum est fort ou faible.</li>
      </ul>
      <p class="concept-note">💡 <strong>Le conseil du pro</strong> : utilise le MACD pour <strong>confirmer</strong> une tendance déjà en place, pas pour deviner à l'avance ce qui va se passer.</p>
    `,
  },
  {
    id: 'stochastic-rsi',
    titre: '4. Stochastic RSI — Un indicateur rapide et sensible',
    image: 'img/concepts/stochastic-rsi.jpg',
    corps: `
      <p><strong>C'est quoi ?</strong> Une version « boostée » et plus nerveuse du RSI. Il mesure le momentum... du RSI lui-même. Un indicateur au carré, en quelque sorte.</p>
      <p><strong>L'analogie</strong> : si le RSI est comme regarder la vitesse d'une voiture, le Stochastic RSI c'est comme regarder l'accélération de cette vitesse — il réagit plus vite, mais il est aussi plus nerveux et peut donner de fausses alertes.</p>
      <p><strong>Ce qu'il faut retenir :</strong></p>
      <ul>
        <li>Très <strong>rapide</strong> : il réagit avant le RSI classique.</li>
        <li>Utile pour repérer des reprises en cours de route (« swing »).</li>
        <li><strong>Très sensible</strong> aux faux signaux quand le marché ne fait rien de spécial (marché « latéral »).</li>
      </ul>
      <p class="concept-note">💡 <strong>Le conseil du pro</strong> : ne l'utilise jamais tout seul — toujours en complément d'autres outils comme la tendance ou les niveaux de support/résistance.</p>
    `,
  },
  {
    id: 'volume',
    titre: '5. Volume — La conviction derrière le prix',
    image: 'img/concepts/volume.jpg',
    corps: `
      <p><strong>C'est quoi ?</strong> Le nombre d'actions échangées à un moment donné. Ça montre si beaucoup de monde participe au mouvement, ou si c'est juste quelques personnes.</p>
      <p><strong>L'analogie</strong> : imagine une pétition. Si 10 000 personnes la signent, c'est un vrai mouvement de fond. Si seulement 5 personnes la signent, ça ne veut pas dire grand-chose, même si le message est le même. Le volume, c'est le nombre de signatures derrière le mouvement du prix.</p>
      <p><strong>Ce qu'il faut retenir :</strong></p>
      <ul>
        <li><strong>Cassure avec volume élevé</strong> → signal fort, le mouvement est soutenu par beaucoup de monde.</li>
        <li><strong>Cassure avec volume faible</strong> → signal faible, peu de conviction, risque de fausse alerte.</li>
        <li><strong>Tendance avec volume qui grimpe</strong> → tendance saine, de plus en plus de gens y participent.</li>
      </ul>
      <p class="concept-note">💡 <strong>Le conseil du pro</strong> : un prix qui bouge sans volume, c'est comme une voiture sans essence — ça ne va pas loin.</p>
    `,
  },
  {
    id: 'obv',
    titre: '6. OBV (On Balance Volume) — Suivre le volume derrière le prix',
    image: 'img/concepts/obv.jpg',
    corps: `
      <p><strong>C'est quoi ?</strong> Une ligne qui additionne le volume des jours de hausse et soustrait le volume des jours de baisse. Ça permet de voir si les gens « accumulent » (achètent en cachette) ou « distribuent » (vendent en cachette) un titre.</p>
      <p><strong>L'analogie</strong> : c'est comme suivre les allées et venues dans un magasin sans regarder les prix affichés. Si beaucoup de gens entrent avec des paniers pleins (accumulation), quelque chose se prépare, même si le prix n'a pas encore bougé.</p>
      <p><strong>Ce qu'il faut retenir :</strong></p>
      <ul>
        <li>OBV qui <strong>monte</strong> → accumulation (les gens achètent avec conviction).</li>
        <li>OBV qui <strong>descend</strong> → distribution (les gens vendent avec conviction).</li>
        <li><strong>Divergence</strong> : si le prix baisse mais que l'OBV monte (ou l'inverse), c'est un signal d'alerte — quelque chose ne colle pas entre le prix et le volume, et un changement de direction pourrait arriver.</li>
      </ul>
      <p class="concept-note">💡 <strong>Le conseil du pro</strong> : l'OBV ne prédit pas le prix, il révèle la force cachée derrière le mouvement.</p>
    `,
  },
  {
    id: 'vwap',
    titre: '7. VWAP — Le prix moyen pondéré par le volume',
    image: 'img/concepts/vwap.jpg',
    corps: `
      <p><strong>C'est quoi ?</strong> Le prix « moyen réel » d'un titre pendant la journée, en tenant compte du nombre d'actions échangées à chaque prix (pas juste une moyenne simple).</p>
      <p><strong>L'analogie</strong> : si tu achètes 3 sacs de bonbons à 1$, 2$ et 10$, la moyenne simple est de 4,33$. Mais si tu as acheté 100 sacs à 1$ et un seul à 10$, le vrai prix moyen que tu as payé est beaucoup plus proche de 1$. Le VWAP fait ce calcul plus juste, en pondérant par les quantités.</p>
      <p><strong>Ce qu'il faut retenir :</strong></p>
      <ul>
        <li>Prix <strong>au-dessus</strong> du VWAP → les acheteurs contrôlent la journée.</li>
        <li>Prix <strong>en-dessous</strong> du VWAP → les vendeurs contrôlent la journée.</li>
        <li>Le VWAP sert souvent de <strong>niveau de support ou de résistance</strong> pendant la journée — le prix vient souvent le retester.</li>
      </ul>
      <p class="concept-note">💡 <strong>Le conseil du pro</strong> : les grandes institutions (banques, fonds) utilisent le VWAP pour savoir si elles ont acheté « au bon prix » par rapport au reste du marché ce jour-là.</p>
    `,
  },
  {
    id: 'bollinger',
    titre: '8. Bandes de Bollinger — Mesurer la volatilité du marché',
    image: 'img/concepts/bollinger.jpg',
    corps: `
      <p><strong>C'est quoi ?</strong> Trois lignes autour du prix : une moyenne au milieu, et deux bandes (au-dessus et en-dessous) qui s'écartent ou se resserrent selon que le marché bouge beaucoup ou peu.</p>
      <p><strong>L'analogie</strong> : pense à un élastique qui entoure le prix. Quand le marché est calme, l'élastique est serré. Quand le marché s'agite, l'élastique s'étire. Un élastique très serré depuis longtemps annonce souvent un mouvement brusque à venir (le « squeeze »), comme un ressort qu'on comprime avant qu'il ne se détende d'un coup.</p>
      <p><strong>Ce qu'il faut retenir :</strong></p>
      <ul>
        <li>Bandes <strong>serrées</strong> → faible volatilité (marché calme).</li>
        <li>Bandes <strong>écartées</strong> → forte volatilité (marché agité).</li>
        <li>Ce n'est <strong>pas</strong> un signal d'achat ou de vente en soi — juste une mesure de à quel point le marché bouge.</li>
      </ul>
      <p class="concept-note">💡 <strong>Le conseil du pro</strong> : les Bandes de Bollinger ne prédisent pas la direction du mouvement, seulement son amplitude probable.</p>
    `,
  },
  {
    id: 'atr',
    titre: '9. ATR (Average True Range) — Mesurer la volatilité, pas la direction',
    image: 'img/concepts/atr.jpg',
    corps: `
      <p><strong>C'est quoi ?</strong> Un chiffre qui indique de combien un titre bouge en moyenne chaque jour, en dollars (ou en points).</p>
      <p><strong>L'analogie</strong> : c'est comme savoir qu'un ami marche en moyenne 5 km par jour, sans savoir dans quelle direction il va. Ça ne te dit pas où il se dirige, juste à quel point il est actif.</p>
      <p><strong>Ce qu'il faut retenir :</strong></p>
      <ul>
        <li>ATR <strong>bas</strong> → marché calme, les mouvements sont petits.</li>
        <li>ATR <strong>élevé</strong> → marché agité, les mouvements sont grands.</li>
        <li>Sert surtout à décider <strong>où placer son stop</strong> (le seuil de sortie de secours) : plus l'ATR est élevé, plus il faut laisser de la marge pour ne pas se faire sortir par un mouvement normal.</li>
      </ul>
      <p class="concept-note">💡 <strong>Le conseil du pro</strong> : l'ATR n'indique jamais si le prix va monter ou descendre — seulement à quel point il pourrait bouger.</p>
    `,
  },
  {
    id: 'fibonacci',
    titre: '10. Fibonacci — Des niveaux clés pour anticiper les zones de réaction',
    image: 'img/concepts/fibonacci.jpg',
    corps: `
      <p><strong>C'est quoi ?</strong> Une série de niveaux (23,6 % / 38,2 % / 50 % / 61,8 % / 78,6 %) tracés entre un sommet et un creux, où le prix a statistiquement tendance à faire une pause ou à rebondir.</p>
      <p><strong>L'analogie</strong> : imagine que tu montes un escalier en courant (le prix qui grimpe), puis tu redescends un peu pour reprendre ton souffle avant de continuer à monter. Les niveaux de Fibonacci sont les marches où les gens ont tendance à « reprendre leur souffle » avant de repartir dans le même sens.</p>
      <p><strong>Ce qu'il faut retenir :</strong></p>
      <ul>
        <li><strong>23,6 %</strong> → petit retracement (léger).</li>
        <li><strong>38,2 %</strong> → zone de rebond fréquente.</li>
        <li><strong>50 %</strong> → niveau psychologique (la moitié du chemin).</li>
        <li><strong>61,8 %</strong> → zone de rebond majeure.</li>
        <li><strong>78,6 %</strong> → retracement profond (le mouvement de fond est presque entièrement remis en question).</li>
      </ul>
      <p class="concept-note">💡 <strong>Le conseil du pro</strong> : Fibonacci ne prédit rien à coup sûr — il aide juste à repérer des zones où le prix <em>pourrait</em> réagir.</p>
    `,
  },
  {
    id: 'force-relative',
    titre: '11. Force relative — Comparer pour mieux investir',
    image: 'img/concepts/force-relative.jpg',
    corps: `
      <p><strong>C'est quoi ?</strong> Comparer la performance d'une action à celle d'un indice général (comme le S&P 500) pour voir si elle fait mieux ou moins bien que « la moyenne du marché ».</p>
      <p><strong>L'analogie</strong> : c'est comme comparer ta note à un examen avec la moyenne de la classe. Avoir 15/20 c'est bien, mais si la moyenne de la classe est de 18/20, tu es en fait en dessous des autres. À l'inverse, avoir 12/20 quand la moyenne est de 8/20, c'est en fait une très bonne performance relative.</p>
      <p><strong>Ce qu'il faut retenir :</strong></p>
      <ul>
        <li><strong>Forte force relative</strong> → l'action fait mieux que le marché (elle « surperforme »).</li>
        <li><strong>Force relative neutre</strong> → l'action suit le marché, ni plus ni moins.</li>
        <li><strong>Faible force relative</strong> → l'action fait moins bien que le marché (« sous-performe »), signe possible de faiblesse.</li>
      </ul>
      <p class="concept-note">💡 <strong>Le conseil du pro</strong> : les marchés récompensent souvent les leaders — mieux vaut investir dans la force que dans la faiblesse.</p>
    `,
  },
  {
    id: 'breakout',
    titre: '12. Breakout — La cassure qui démarre un mouvement',
    image: 'img/concepts/breakout.jpg',
    corps: `
      <p><strong>C'est quoi ?</strong> Le moment où le prix casse enfin un plafond (une résistance) qu'il n'arrivait pas à dépasser depuis un moment, et qui peut lancer un nouveau mouvement.</p>
      <p><strong>L'analogie</strong> : imagine que tu sautes en hauteur et que tu bloques plusieurs fois d'affilée à la même barre. Le jour où tu la passes enfin, avec de l'élan, ça montre que tu as vraiment progressé — pas juste eu de la chance. Le breakout, c'est ce fameux saut réussi.</p>
      <p><strong>Ce qu'il faut retenir — un vrai breakout a :</strong></p>
      <ul>
        <li>Une cassure <strong>franche</strong> au-dessus de la résistance (pas juste un centimètre).</li>
        <li>Un <strong>volume supérieur</strong> à la moyenne (beaucoup de monde y participe).</li>
        <li>Une <strong>poursuite</strong> du mouvement après la cassure.</li>
        <li>L'ancienne résistance qui <strong>devient un support</strong> (le plafond devient le plancher).</li>
      </ul>
      <p class="concept-note concept-note--piege">⚠️ <strong>Le piège à éviter — le faux breakout</strong> : le prix dépasse légèrement la résistance, avec un faible volume, puis retombe rapidement en dessous. Il faut donc toujours vérifier le volume avant de croire à une vraie cassure.</p>
    `,
  },
  {
    id: 'gaps',
    titre: '13. Les Gaps — Les écarts qui envoient un message',
    image: 'img/concepts/gaps.jpg',
    corps: `
      <p><strong>C'est quoi ?</strong> Un « trou » sur le graphique, quand le prix ouvre le lendemain beaucoup plus haut ou plus bas que la veille, sans rien entre les deux — souvent à cause d'une nouvelle importante annoncée pendant que le marché était fermé.</p>
      <p><strong>L'analogie</strong> : c'est comme si tu allais te coucher en sachant que ton équipe de sport favorite est à égalité, et qu'au réveil tu apprends qu'elle a gagné le championnat pendant la nuit — il n'y a pas eu de match « intermédiaire » que tu as vu, juste un saut direct à la nouvelle réalité.</p>
      <p><strong>Les 4 types de gaps :</strong></p>
      <ul>
        <li><strong>Gap de continuation</strong> : apparaît en pleine tendance et confirme qu'elle continue.</li>
        <li><strong>Gap d'évasion</strong> : marque la sortie d'une période calme et le début d'un nouveau mouvement.</li>
        <li><strong>Gap d'épuisement</strong> : peut signaler que la tendance touche à sa fin.</li>
        <li><strong>Gap commun</strong> : le prix revient souvent combler cet écart dans les jours suivants.</li>
      </ul>
      <p class="concept-note">💡 <strong>Le conseil du pro</strong> : un gap est un message du marché — il faut chercher à comprendre <em>pourquoi</em> il existe avant d'agir.</p>
    `,
  },
  {
    id: 'golden-cross',
    titre: '14. Golden Cross — Un signal haussier important',
    image: 'img/concepts/golden-cross.jpg',
    corps: `
      <p><strong>C'est quoi ?</strong> Le moment où la moyenne à court terme (MM 50) croise <strong>au-dessus</strong> de la moyenne à long terme (MM 200) — un signal classique de début de tendance haussière.</p>
      <p><strong>L'analogie</strong> : imagine que ta moyenne de notes du dernier mois dépasse enfin ta moyenne de l'année entière. Ça veut dire que tu es en train de vraiment progresser, pas juste d'avoir eu un bon jour.</p>
      <p><strong>Ce qu'il faut retenir — à surveiller pour un vrai signal :</strong></p>
      <ul>
        <li>Croisement MM 50 au-dessus de MM 200 ✅</li>
        <li>Tendance haussière déjà confirmée ✅</li>
        <li>Volume en augmentation ✅</li>
        <li>Cassure d'une résistance récente ✅</li>
      </ul>
      <p><strong>Ce qu'il faut retenir — à éviter :</strong></p>
      <ul>
        <li>Marché encore en tendance baissière ❌</li>
        <li>Volume faible ou en baisse ❌</li>
        <li>Marché qui ne fait que zigzaguer ❌</li>
      </ul>
      <p class="concept-note">💡 <strong>Le conseil du pro</strong> : le Golden Cross est un signal puissant, mais il doit toujours être confirmé par le contexte général du marché.</p>
    `,
  },
  {
    id: 'support-resistance',
    titre: '15. Support & Résistance — Les niveaux que le marché n’oublie pas',
    image: 'img/concepts/support-resistance.jpg',
    corps: `
      <p><strong>C'est quoi ?</strong> Des zones de prix où le marché a tendance à réagir de façon répétée : un <strong>support</strong> est un plancher où les acheteurs reprennent le contrôle, une <strong>résistance</strong> est un plafond où les vendeurs reprennent le contrôle.</p>
      <p><strong>L'analogie</strong> : c'est comme un ballon qu'on lance dans une pièce entre le sol et le plafond. Le sol (support), c'est là où le ballon rebondit vers le haut. Le plafond (résistance), c'est là où il rebondit vers le bas. Mais si quelqu'un pousse assez fort pour casser le plafond, le ballon peut continuer à monter bien plus haut qu'avant.</p>
      <p><strong>Ce qu'il faut retenir :</strong></p>
      <ul>
        <li>Le prix touche le <strong>support</strong> → il a tendance à <strong>rebondir vers le haut</strong>.</li>
        <li>Le prix touche la <strong>résistance</strong> → il a tendance à <strong>repartir vers le bas</strong>.</li>
        <li>Une <strong>cassure</strong> de la résistance ou du support peut lancer un mouvement important dans cette direction.</li>
      </ul>
      <p class="concept-note">💡 <strong>Le conseil du pro</strong> : les supports et résistances sont des <strong>zones</strong>, pas des lignes exactes au centime près. Le marché réagit à l'histoire des prix passés... et cette histoire a tendance à se répéter.</p>
    `,
  },
];

// Table récapitulative de fin de guide ("comment ces 15 outils travaillent
// ensemble") — transcrite telle quelle.
const CONCEPTS_RESUME_TABLE = [
  ['Dans quel sens va le marché ?', 'EMA, Golden Cross'],
  ['Le prix est-il « trop étiré » ?', 'RSI, Stochastic RSI'],
  ['L’élan est-il en train de changer ?', 'MACD'],
  ['Y a-t-il assez de monde derrière le mouvement ?', 'Volume, OBV'],
  ['Où le prix pourrait-il réagir ?', 'Support/Résistance, Fibonacci, VWAP'],
  ['À quel point le marché bouge-t-il ?', 'Bandes de Bollinger, ATR'],
  ['Ce titre est-il un leader ou un retardataire ?', 'Force relative'],
  ['Un nouveau mouvement démarre-t-il ?', 'Breakout, Gaps'],
];

// Rend le contenu complet de l'onglet Concepts dans le conteneur donné.
// Appelé une seule fois (le contenu est statique) — voir initConceptsTab()
// dans index.html.
function renderConceptsTab(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const cards = CONCEPTS_TRADING.map((c) => `
    <details class="ds-card concept-card">
      <summary>${c.titre}</summary>
      <div class="concept-body">
        <img src="${c.image}" alt="${c.titre}" loading="lazy">
        ${c.corps}
      </div>
    </details>
  `).join('');

  const resumeRows = CONCEPTS_RESUME_TABLE
    .map(([question, outils]) => `<tr><td>${question}</td><td>${outils}</td></tr>`)
    .join('');

  container.innerHTML = `
    <p class="concept-note concept-note--piege">⚠️ <strong>Origine des images</strong> : les images de ce guide proviennent de la page Facebook de <a href="https://dtrading.net/" target="_blank" rel="noopener">dtrading.net</a> (https://dtrading.net/) — crédit à leur auteur, reprises ici à titre éducatif uniquement.</p>
    <p class="metric-sub" style="text-align:left;">Ce guide reprend 15 concepts de trading expliqués simplement — sans jargon, avec des exemples de la vraie vie. Clique un titre pour déplier.</p>
    <p class="concept-intro-note">💡 <strong>Rappel important</strong> : aucun de ces outils ne prédit l'avenir avec certitude. Ce sont des indices, un peu comme les traces de pas d'un animal dans la neige — ça te dit ce qui vient de se passer, pas ce qui va forcément arriver.</p>
    ${cards}
    <div class="ds-card">
      <div class="section-title">En résumé : comment ces 15 outils travaillent ensemble</div>
      <p class="metric-sub" style="text-align:left;">Aucun de ces indicateurs ne doit être utilisé seul — c'est comme les ingrédients d'une recette : un seul ne fait pas le plat, mais ensemble ils racontent une histoire cohérente.</p>
      <table class="ds-table">
        <thead><tr><th>Ce que tu veux savoir</th><th>Les outils à regarder</th></tr></thead>
        <tbody>${resumeRows}</tbody>
      </table>
      <p class="concept-note concept-note--piege" style="margin-top:12px;">⚠️ <strong>Le plus important à retenir</strong> : ces outils décrivent ce qui vient de se passer et donnent des indices sur ce qui pourrait arriver — ils ne garantissent jamais rien. Personne, même avec 30 ans d'expérience, ne prédit le marché à coup sûr. Le trading, ce n'est pas de la magie, c'est de la probabilité et de la gestion du risque.</p>
    </div>
  `;
}
