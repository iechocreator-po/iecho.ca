import express from 'express';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { db } from './db.js';
import { getMarketSnapshot, getTechnicalAnalysis, getPrice, screenWatchlist, checkSidecarConnection } from './tradingview.js';
import { getHomemadeIndicators, getHomemadeIndicatorsBatch, checkYahooConnection } from './indicators.js';
import { seedWatchlistIfEmpty, getWatchlist, addToWatchlist, removeFromWatchlist } from './watchlist.js';
import { createTrade, listTrades, getTrade, updateTrade, deleteTrade, validateTrade, COLUMNS as TRADE_COLUMNS } from './trades.js';
import { getFundamentals, getFundamentalsBatch } from './fundamentals.js';
import { getSectorPerformance, getSectorHistory, getTopMoversForSector, SECTOR_ETF_TO_YAHOO_SECTOR, SECTOR_MODES, SECTOR_DEFS } from './sectors.js';
import { computeStats } from './stats.js';

// Sème la watchlist en base au premier démarrage (idempotent, no-op ensuite).
seedWatchlistIfEmpty();

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const settings = JSON.parse(readFileSync(new URL('../settings.json', import.meta.url)));

const app = express();
app.use(express.json());
app.use(express.static(ROOT));

app.get('/api/health', (req, res) => {
  const { count } = db.prepare('SELECT COUNT(*) AS count FROM trades').get();
  res.json({ status: 'ok', trades: count });
});

// Statut agrégé pour le témoin visuel du frontend (header de index.html).
// `tradingviewMcp` utilise checkSidecarConnection() (listTools(), pas
// d'appel outil) — ne consomme jamais le quota du scanner rate-limité.
// `homemade` teste juste la joignabilité de Yahoo Finance (cotation SPY,
// légère) — les calculs maison (ATR/volume/OBV/SMA) en dépendent tous.
// Chaque check remonte un `*Detail` explicite (30/8/2026, demande de JP) —
// jamais juste un booléen qui masque la vraie cause (sidecar non démarré,
// rate-limit, DB verrouillée…).
app.get('/api/status', async (req, res) => {
  let dbOk = true;
  let dbDetail = null;
  try {
    db.prepare('SELECT 1').get();
  } catch (err) {
    dbOk = false;
    dbDetail = err.message;
  }
  const [tradingviewMcp, homemade] = await Promise.all([
    checkSidecarConnection(),
    checkYahooConnection(),
  ]);
  res.json({
    backend: true,
    db: dbOk,
    dbDetail,
    tradingviewMcp: tradingviewMcp.ok,
    tradingviewMcpDetail: tradingviewMcp.detail,
    homemade: homemade.ok,
    homemadeDetail: homemade.detail,
    checkedAt: new Date().toISOString(),
  });
});

// Pont vers le sidecar tradingview-mcp — VIX + RSI/ATR/Volume/Golden Cross
// pour un titre. Le sidecar (npm run sidecar) n'est pas géré par ce
// serveur : s'il n'est pas démarré, on répond 503 proprement plutôt que de
// planter (même patron que le GITHUB_TOKEN absent chez bilbao).
// Promise.allSettled (pas Promise.all) : VIX (market_snapshot, Yahoo),
// RSI/Golden Cross (coin_analysis, scanner TradingView) et OBV réel/SMA
// 9-21-100 (calcul maison, historique Yahoo direct — indicators.js) sont
// trois sources indépendantes — l'échec de l'une (rate-limit du scanner,
// observé en test réel) ne doit pas faire perdre les autres.
// P/E moyen "par famille d'industrie" pour UN ticker arbitraire (pas
// forcément dans la watchlist) — réutilise le dernier résultat de
// screening EN CACHE (screeningCache, déclaré plus bas) plutôt que de
// refaire un batch de 20 appels Yahoo à chaque clic sur "Récupérer en
// direct". Si aucun screening n'a encore été lancé, retourne
// explicitement `null`/0 pairs plutôt que de forcer un fetch coûteux et
// invisible pour l'utilisateur.
function industryPeerStatsFromScreeningCache(industry) {
  if (!industry || !screeningCache) return { avgPE: null, peerCount: 0 };
  const rows = screeningCache.payload.rows.filter((r) => r.industry === industry && r.peRatio != null);
  if (!rows.length) return { avgPE: null, peerCount: 0 };
  const avg = rows.reduce((sum, r) => sum + r.peRatio, 0) / rows.length;
  return { avgPE: avg, peerCount: rows.length };
}

// Fondamentaux (P/E, industrie, PEG, beta, float, VWAP) + OBV/volume pour la
// carte "Ticker" fusionnée de l'onglet Secteurs (5/9/2026, demande de JP
// T5) — 4ᵉ branche Promise.allSettled, indépendante des trois autres (VIX/
// RSI/Golden Cross et calculs maison), Yahoo Finance direct comme
// fundamentals.js.
app.get('/api/market-data/:ticker', async (req, res) => {
  const [snapshotResult, taResult, homemadeResult, fundResult] = await Promise.allSettled([
    getMarketSnapshot(),
    getTechnicalAnalysis(req.params.ticker, { exchange: req.query.exchange || 'NASDAQ' }),
    getHomemadeIndicators(req.params.ticker),
    getFundamentals(req.params.ticker, { withVwap: true }),
  ]);
  if (snapshotResult.status === 'rejected' && taResult.status === 'rejected' && homemadeResult.status === 'rejected' && fundResult.status === 'rejected') {
    res.status(503).json({ error: 'tradingview-mcp et Yahoo Finance injoignables', detail: taResult.reason.message });
    return;
  }
  const snapshot = snapshotResult.status === 'fulfilled' ? snapshotResult.value : null;
  const ta = taResult.status === 'fulfilled' ? taResult.value : null;
  const hm = homemadeResult.status === 'fulfilled' ? homemadeResult.value : null;
  const fund = fundResult.status === 'fulfilled' ? fundResult.value : null;
  const industryStat = fund?.industry ? industryPeerStatsFromScreeningCache(fund.industry) : { avgPE: null, peerCount: 0 };
  res.json({
    ticker: req.params.ticker.toUpperCase(),
    vix: snapshot?.vix ?? null,
    rsi: ta?.rsi?.value ?? null,
    // ATR/volume : calcul maison en priorité (indicators.js) — celui de
    // tradingview-mcp est structurellement absent en pratique (voir
    // CLAUDE.md), gardé en repli au cas où l'outil tiers l'exposerait un
    // jour pour ce titre/timeframe.
    atr: hm?.atr ?? ta?.atr?.value ?? null,
    volumeRatio: hm?.volumeRatio ?? ta?.volume_analysis?.ratio ?? null,
    volumeSMA20: hm?.volumeSMA20 ?? null,
    changePercent: ta?.price_data?.change_percent ?? null,
    goldenCross: ta?.sma?.signals?.some((s) => s.startsWith('Golden Cross')) ?? null,
    sma50: ta?.sma?.sma50 ?? null,
    sma200: ta?.sma?.sma200 ?? null,
    technicalError: taResult.status === 'rejected' ? taResult.reason.message : null,
    // sma9/21/100 : SMA maison (Simple Moving Average, fenêtre glissante —
    // voir indicators.js), à ne pas confondre avec sma50/sma200 juste
    // au-dessus qui viennent de tradingview-mcp (Golden Cross).
    sma9: hm?.sma9 ?? null,
    sma21: hm?.sma21 ?? null,
    sma100: hm?.sma100 ?? null,
    smaAlignment: hm?.smaAlignment ?? null,
    obv: hm?.obv ?? null,
    obvTrend: hm?.obvTrend ?? null,
    homemadeError: homemadeResult.status === 'rejected' ? homemadeResult.reason.message : null,
    // Fondamentaux (5/9/2026, T5) — volume, float, P/E, industrie, PEG,
    // beta, VWAP, via fundamentals.js (Yahoo direct). P/E industrie =
    // moyenne des pairs de LA WATCHLIST partageant la même industrie,
    // depuis le dernier screening en cache (pas de nouveau batch coûteux à
    // chaque clic) — `null`/0 pairs si aucun screening n'a encore tourné.
    volume: fund?.volume ?? null,
    floatShares: fund?.floatShares ?? null,
    peRatio: fund?.peRatio ?? null,
    industry: fund?.industry ?? null,
    industryPE: industryStat.avgPE,
    industryPeerCount: industryStat.peerCount,
    pegRatio: fund?.pegRatio ?? null,
    beta: fund?.beta ?? null,
    vwap: fund?.vwap ?? null,
    aboveVwap: fund?.aboveVwap ?? null,
    fundamentalsError: fundResult.status === 'rejected' ? fundResult.reason.message : null,
  });
});

// Cotation simple (Yahoo Finance via yahoo_price) — utilisée pour la force
// relative (titre + indice de référence). Séparée de /api/market-data pour
// rester utilisable même quand coin_analysis est rate-limité.
app.get('/api/quote/:symbol', async (req, res) => {
  try {
    const quote = await getPrice(req.params.symbol);
    res.json({
      symbol: req.params.symbol.toUpperCase(),
      price: quote.price ?? null,
      changePercent: quote.change_pct ?? null,
    });
  } catch (err) {
    res.status(503).json({ error: 'tradingview-mcp injoignable', detail: err.message });
  }
});

// Onglet Labo (5/9/2026) — données réelles d'un titre pour démontrer la
// séquence d'une stratégie d'options (server/../js/strategies-labo.js).
// Uniquement des sources Yahoo Finance directes (fundamentals.js +
// indicators.js) — volontairement PAS tradingview-mcp/coin_analysis, pour
// ne jamais dépendre du rate-limit déjà documenté sur ce chemin. Aucune
// donnée d'options (chaîne, delta, prime) n'existe dans cette app : ce
// endpoint fournit le prix + la volatilité historique réels, à partir
// desquels le frontend ESTIME un strike par Black-Scholes (jamais une
// vraie donnée d'options — voir CLAUDE.md).
//
// `smaFast`/`smaMedium`/`smaSlow` (5/9/2026, demande de JP T3) — périodes du
// filtre de tendance, réellement PASSÉES à getHomemadeIndicators() (pas
// seulement des libellés) : 9/21/100 par défaut, surchageables depuis les
// champs visibles en haut de l'onglet Labo. `smaPeriods` dans la réponse
// confirme les valeurs effectivement utilisées.
app.get('/api/labo/:ticker', async (req, res) => {
  const ticker = req.params.ticker.toUpperCase();
  const parsePeriod = (raw, fallback) => {
    const n = parseInt(raw, 10);
    return Number.isInteger(n) && n > 0 ? n : fallback;
  };
  const periods = {
    fast: parsePeriod(req.query.smaFast, 9),
    medium: parsePeriod(req.query.smaMedium, 21),
    slow: parsePeriod(req.query.smaSlow, 100),
  };
  const [fundResult, indicResult] = await Promise.allSettled([
    getFundamentals(ticker, { withVwap: false }),
    getHomemadeIndicators(ticker, { periods }),
  ]);
  if (fundResult.status === 'rejected' && indicResult.status === 'rejected') {
    res.status(503).json({ error: 'Yahoo Finance injoignable pour ce titre', detail: fundResult.reason.message });
    return;
  }
  const fund = fundResult.status === 'fulfilled' ? fundResult.value : null;
  const indic = indicResult.status === 'fulfilled' ? indicResult.value : null;
  res.json({
    ticker,
    price: fund?.price ?? null,
    volume: fund?.volume ?? null,
    beta: fund?.beta ?? null,
    peRatio: fund?.peRatio ?? null,
    industry: fund?.industry ?? null,
    sector: fund?.sector ?? null,
    atr: indic?.atr ?? null,
    sma9: indic?.sma9 ?? null,
    sma21: indic?.sma21 ?? null,
    sma100: indic?.sma100 ?? null,
    smaPeriods: indic?.smaPeriods ?? periods,
    smaAlignment: indic?.smaAlignment ?? null,
    obvTrend: indic?.obvTrend ?? null,
    volumeRatio: indic?.volumeRatio ?? null,
    historicalVolatility: indic?.historicalVolatility ?? null,
    fundamentalsError: fundResult.status === 'rejected' ? fundResult.reason.message : null,
    indicatorsError: indicResult.status === 'rejected' ? indicResult.reason.message : null,
  });
});

// Performance + P/E des 11 secteurs SPDR + benchmark S&P 500 (carte
// "Performance des secteurs" de l'écran de sélection, server/sectors.js).
// Rapide (~2s, quote() simple) et pas affecté par le rate-limit de
// coin_analysis — pas de cache nécessaire ici, contrairement à
// /api/screening.
// PEG moyen par secteur (30/8/2026, demande de JP) — AUCUNE source Yahoo ne
// fournit de PEG au niveau ETF/secteur (vérifié : quote()/quoteSummary
// renvoient `undefined` pour XLK/XLF/SPY, contrairement au P/E qui, lui,
// existe réellement au niveau de l'ETF). Calculé à la place comme la
// moyenne des PEG des titres de LA WATCHLIST partageant le même secteur
// GICS large (`summaryProfile.sector`, fundamentals.js + mapping
// SECTOR_ETF_TO_YAHOO_SECTOR de sectors.js) — même principe d'approximation
// assumée que le "P/E industrie" du screening, PAS un agrégat de marché.
// Couverture nécessairement partielle : la watchlist (20 titres tech/IA)
// ne compte aucun titre dans plusieurs secteurs (Énergie, Immobilier,
// Matériaux…) — ces lignes ressortent en `null`/"—", jamais un chiffre
// inventé. `pegPeerCount` expose le nombre de titres utilisés, affiché en
// tooltip pour ne jamais laisser croire à un échantillon plus large.
// `mode` (usd|cad, 2/9/2026) sélectionne quels tickers interroger — voir
// server/sectors.js, SECTOR_DEFS. Invalide par défaut sur 'usd' plutôt que
// de planter si le paramètre est absent ou mal formé.
function parseSectorMode(req, res) {
  const mode = req.query.mode || 'usd';
  if (!SECTOR_MODES.includes(mode)) {
    res.status(400).json({ error: `mode invalide : ${mode} (attendu : ${SECTOR_MODES.join('|')})` });
    return null;
  }
  return mode;
}

app.get('/api/sectors', async (req, res) => {
  const mode = parseSectorMode(req, res);
  if (mode === null) return;
  try {
    const watchlist = getWatchlist();
    const [perf, fundamentalRows] = await Promise.all([
      getSectorPerformance({ mode }),
      getFundamentalsBatch(watchlist.map((w) => w.ticker), { withVwap: false, delayMs: 150 }),
    ]);
    const pegBySector = new Map();
    for (const f of fundamentalRows) {
      if (!f.sector || f.pegRatio == null) continue;
      if (!pegBySector.has(f.sector)) pegBySector.set(f.sector, []);
      pegBySector.get(f.sector).push(f.pegRatio);
    }
    // Jointure par `s.key` (toujours le ticker USD, stable) et non
    // `s.ticker` (qui peut être un ticker .TO en mode CAD) — sinon la
    // moyenne PEG par secteur casserait dès qu'on bascule hors USD.
    const sectorsWithPeg = perf.sectors.map((s) => {
      const values = pegBySector.get(SECTOR_ETF_TO_YAHOO_SECTOR[s.key]);
      return {
        ...s,
        pegAvg: values?.length ? values.reduce((a, b) => a + b, 0) / values.length : null,
        pegPeerCount: values?.length ?? 0,
      };
    });
    res.json({ generatedAt: new Date().toISOString(), mode, sectors: sectorsWithPeg, benchmark: perf.benchmark });
  } catch (err) {
    res.status(503).json({ error: 'Yahoo Finance injoignable', detail: err.message });
  }
});

// Historique quotidien (~13 mois) pour le line graph de performance
// sectorielle — un seul fetch, le frontend découpe par période (1S à 12M)
// et normalise en % côté client, sans refetch à chaque changement de période.
app.get('/api/sectors/history', async (req, res) => {
  const mode = parseSectorMode(req, res);
  if (mode === null) return;
  try {
    const data = await getSectorHistory({ mode });
    res.json({ generatedAt: new Date().toISOString(), mode, ...data });
  } catch (err) {
    res.status(503).json({ error: 'Yahoo Finance injoignable', detail: err.message });
  }
});

// "Titres les plus performants du secteur" (onglet Secteurs, 2/9/2026) —
// classe une liste CURATÉE par secteur (server/sectors.js,
// SECTOR_TOP_CANDIDATES) par variation du jour. PAS une requête de marché
// large — voir le commentaire détaillé dans sectors.js sur l'échec du
// screener personnalisé Yahoo (429 systématique sur un endpoint
// probablement réservé aux comptes connectés). Cache en mémoire par
// (sectorKey, mode-filtre), même patron que screeningCache plus bas,
// ?force=true bypasse. Jamais un 200 avec rows:[] qui laisserait croire à
// "aucun titre" — un échec Yahoo devient un 503 explicite.
const sectorTopCache = new Map(); // `${sectorKey}:${filterMode}` -> { payload, timestamp }

app.get('/api/sectors/:sectorKey/top', async (req, res) => {
  const sectorKey = req.params.sectorKey.toUpperCase();
  const filterMode = req.query.mode === 'filtered' ? 'filtered' : req.query.mode === 'raw' ? 'raw' : null;
  if (!filterMode) {
    res.status(400).json({ error: `mode invalide : ${req.query.mode} (attendu : raw|filtered)` });
    return;
  }
  if (!SECTOR_ETF_TO_YAHOO_SECTOR[sectorKey]) {
    res.status(400).json({ error: `secteur inconnu : ${sectorKey}` });
    return;
  }
  const cacheKey = `${sectorKey}:${filterMode}`;
  const ttlMs = (settings.sectorTopCacheMinutes ?? 20) * 60 * 1000;
  const cached = sectorTopCache.get(cacheKey);
  if (req.query.force !== 'true' && cached && (Date.now() - cached.timestamp) < ttlMs) {
    res.json({ ...cached.payload, cached: true });
    return;
  }
  try {
    const { rows, totalCandidates, failedCount } = await getTopMoversForSector(sectorKey, { mode: filterMode });
    const payload = {
      sectorKey,
      sectorLabel: SECTOR_DEFS.find((d) => d.key === sectorKey)?.label ?? sectorKey,
      mode: filterMode,
      generatedAt: new Date().toISOString(),
      rows,
      totalCandidates,
      failedCount,
    };
    sectorTopCache.set(cacheKey, { payload, timestamp: Date.now() });
    res.json({ ...payload, cached: false });
  } catch (err) {
    res.status(503).json({ error: 'Yahoo Finance injoignable pour ce secteur', detail: err.message, sectorKey, mode: filterMode });
  }
});

// Bandes de score — dupliquées de config.js (CFG.bandes) faute de format de
// module commun entre le frontend classique <script> et ce backend ESM.
// Si les bandes de config.js changent, reporter le changement ici aussi.
const SCORE_BANDS = {
  rsiEntreeBas: 40,
  rsiEntreeHaut: 70,
  forceRelativeSeuil: 5,
};

// Seuils des filtres de screening (feature 322) — dupliqués de config.js
// (CFG.screening), même limitation de module que SCORE_BANDS. Reporter à la
// main tout changement. floatMax en millions d'actions comme config.js.
const SCREEN_FILTERS = {
  prixMin: 5,
  prixMax: 1000,
  floatMinM: 10,
  floatMaxM: 20,
  volumeMin: 1_000_000,
  pegMax: 1,
  betaMin: 1,
  calculerVwap: true,
};

// Drapeaux pass/fail par critère 322 pour une ligne enrichie de fondamentaux.
// null = donnée absente (ni pass ni fail). Le score composite N'utilise PAS
// ces drapeaux (il reste sur les 4 colonnes du design doc) — ils servent au
// filtrage optionnel de l'univers côté frontend.
function fundamentalFlags(row) {
  const floatM = row.floatShares != null ? row.floatShares / 1_000_000 : null;
  return {
    passPrix: row.price != null ? (row.price >= SCREEN_FILTERS.prixMin && row.price <= SCREEN_FILTERS.prixMax) : null,
    passFloat: floatM != null ? (floatM >= SCREEN_FILTERS.floatMinM && floatM <= SCREEN_FILTERS.floatMaxM) : null,
    passVolume: row.volume != null ? row.volume >= SCREEN_FILTERS.volumeMin : null,
    passPeg: row.pegRatio != null ? row.pegRatio <= SCREEN_FILTERS.pegMax : null,
    passBeta: row.beta != null ? row.beta > SCREEN_FILTERS.betaMin : null,
    passVwap: row.aboveVwap, // déjà un booléen/null (prix > VWAP)
  };
}

// Score calculé sur les champs disponibles, même partiellement — un titre
// dont seule la force relative a pu être récupérée (RSI/Golden Cross en
// panne côté coin_analysis, voir tradingview.js) reste noté plutôt que
// rejeté en bloc. Verdict "erreur" seulement si AUCUNE donnée n'a pu être
// récupérée du tout. 4 colonnes (RSI, Force relative, Golden Cross, OBV) —
// conforme à la section 5 du design doc depuis l'ajout des calculs maison
// (22/7/2026, OBV réel via server/indicators.js).
function scoreRow(row) {
  let score = 0;
  let hasData = false;
  if (row.rsi != null) {
    hasData = true;
    if (row.rsi > SCORE_BANDS.rsiEntreeHaut) score -= 1;
    else if (row.rsi >= SCORE_BANDS.rsiEntreeBas) score += 1;
    // entre 30 et rsiEntreeBas, et sous 30 : zone amber, 0 point (ni + ni -)
  }
  if (row.forceRelative != null) {
    hasData = true;
    if (row.forceRelative > SCORE_BANDS.forceRelativeSeuil) score += 1;
    else if (row.forceRelative < -SCORE_BANDS.forceRelativeSeuil) score -= 1;
  }
  if (row.goldenCross === true) {
    hasData = true;
    score += 1;
  } else if (row.goldenCross === false) {
    hasData = true;
    score -= 1;
  }
  if (row.obvTrend === 'accumulation') {
    hasData = true;
    score += 1;
  } else if (row.obvTrend === 'distribution') {
    hasData = true;
    score -= 1;
  }
  if (!hasData) return { score: null, verdict: 'erreur' };

  let verdict = 'ne pas ajouter';
  if (score >= 2) verdict = 'ajouter';
  else if (score >= 0) verdict = 'surveiller';
  return { score, verdict };
}

// Screening de l'univers de titres (server/watchlist.js, 20 titres) — deux
// passes séquentielles indépendantes : tradingview.js (RSI/Force
// relative/Golden Cross, rate-limit non documenté observé en test réel) et
// indicators.js (OBV réel, calcul maison sur historique Yahoo direct, pas
// affecté par ce rate-limit). Peut prendre ~45-60s pour 20 titres au total.
// Un titre en échec individuel (sur l'une ou l'autre passe) ne fait pas
// échouer toute la requête — verdict "erreur" pour ce titre seulement si
// vraiment aucune des deux sources n'a rien donné.
//
// Cache en mémoire (TTL settings.screeningCacheMinutes, défaut 20 — plage
// 15-30 min suggérée dans CLAUDE.md) : un screening relancé dans la fenêtre
// TTL renvoie le résultat précédent sans re-solliciter coin_analysis, pour
// amortir son rate-limit non documenté en cas de clics rapprochés.
// ?force=true bypasse le cache. Perdu au redémarrage du process — pas de
// persistance voulue, c'est un tampon anti-rate-limit, pas un journal.
let screeningCache = null; // { payload, timestamp }

app.get('/api/screening', async (req, res) => {
  const ttlMs = (settings.screeningCacheMinutes ?? 20) * 60 * 1000;
  if (req.query.force !== 'true' && screeningCache && (Date.now() - screeningCache.timestamp) < ttlMs) {
    res.json({ ...screeningCache.payload, cached: true });
    return;
  }
  try {
    const watchlist = getWatchlist();
    const tickers = watchlist.map((w) => w.ticker);
    // Trois passes indépendantes : tradingview-mcp (RSI/Force/Golden Cross,
    // rate-limitable), calculs maison OBV (Yahoo daily), fondamentaux 322
    // (Yahoo quoteSummary + VWAP intraday). Les deux passes Yahoo ne sont
    // pas affectées par le rate-limit du scanner TradingView.
    const [mcpRows, homemadeRows, fundamentalRows] = await Promise.all([
      screenWatchlist(watchlist),
      getHomemadeIndicatorsBatch(tickers),
      getFundamentalsBatch(tickers, { withVwap: SCREEN_FILTERS.calculerVwap }),
    ]);
    const homemadeByTicker = new Map(homemadeRows.map((h) => [h.ticker, h]));
    const fundamentalByTicker = new Map(fundamentalRows.map((f) => [f.ticker, f]));
    // P/E moyen "par famille d'industrie" — PAS un vrai agrégat sectoriel
    // externe (aucune source gratuite fiable identifiée), mais la moyenne
    // des P/E des titres de LA WATCHLIST partageant la même industrie
    // (summaryProfile.industry, Yahoo Finance). Approximation assumée : sur
    // 20 titres, une industrie peut n'avoir qu'1-2 pairs — `industryPeerCount`
    // est exposé pour que le frontend puisse le signaler plutôt que de
    // laisser croire à un vrai benchmark de marché.
    const peByIndustry = new Map();
    for (const f of fundamentalRows) {
      if (!f.industry || f.peRatio == null) continue;
      if (!peByIndustry.has(f.industry)) peByIndustry.set(f.industry, []);
      peByIndustry.get(f.industry).push(f.peRatio);
    }
    const industryStats = new Map(
      [...peByIndustry.entries()].map(([industry, values]) => [
        industry,
        { avgPE: values.reduce((a, b) => a + b, 0) / values.length, peerCount: values.length },
      ]),
    );
    const scored = mcpRows
      .map((row) => {
        const hm = homemadeByTicker.get(row.ticker);
        const fund = fundamentalByTicker.get(row.ticker) ?? {};
        const industryStat = fund.industry ? industryStats.get(fund.industry) : null;
        const merged = {
          ...row,
          obvTrend: hm?.obvTrend ?? null,
          obvError: hm?.error ?? null,
          price: fund.price ?? null,
          volume: fund.volume ?? null,
          floatShares: fund.floatShares ?? null,
          pegRatio: fund.pegRatio ?? null,
          beta: fund.beta ?? null,
          peRatio: fund.peRatio ?? null,
          industry: fund.industry ?? null,
          industryPE: industryStat?.avgPE ?? null,
          industryPeerCount: industryStat?.peerCount ?? null,
          vwap: fund.vwap ?? null,
          aboveVwap: fund.aboveVwap ?? null,
        };
        return { ...merged, ...scoreRow(merged), flags: fundamentalFlags(merged) };
      })
      .sort((a, b) => (b.score ?? -99) - (a.score ?? -99));
    const payload = { generatedAt: new Date().toISOString(), rows: scored };
    screeningCache = { payload, timestamp: Date.now() };
    res.json({ ...payload, cached: false });
  } catch (err) {
    res.status(503).json({ error: 'tradingview-mcp injoignable', detail: err.message });
  }
});

// Export CSV du screening (bonus) — sert le dernier résultat en cache pour
// ne pas relancer 60s d'appels ; si le cache est vide, invite à lancer un
// screening d'abord (pas de fetch implicite ici).
app.get('/api/screening.csv', (req, res) => {
  if (!screeningCache) {
    res.status(409).json({ error: 'Aucun screening en cache — lancer /api/screening d\'abord.' });
    return;
  }
  const cols = ['ticker', 'rsi', 'forceRelative', 'goldenCross', 'obvTrend', 'score', 'verdict', 'price', 'volume', 'floatShares', 'peRatio', 'industry', 'industryPE', 'pegRatio', 'beta', 'vwap'];
  const escape = (v) => {
    if (v == null) return '';
    const s = String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [cols.join(',')];
  for (const row of screeningCache.payload.rows) {
    lines.push(cols.map((c) => escape(row[c])).join(','));
  }
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="screening-castellana-${Date.now()}.csv"`);
  res.send(lines.join('\n'));
});

// Routes CRUD du journal de trades (table `trades`, schéma section 7 du
// design doc — voir db.js). Validation manuelle en amont (trades.js) plutôt
// que de laisser remonter les erreurs CHECK brutes de SQLite.
app.post('/api/trades', (req, res) => {
  const errors = validateTrade(req.body);
  if (errors.length) { res.status(400).json({ errors }); return; }
  try {
    res.status(201).json(createTrade(req.body));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/trades', (req, res) => {
  const { compte, ticker } = req.query;
  const open = req.query.open === 'true' ? true : req.query.open === 'false' ? false : undefined;
  res.json({ trades: listTrades({ compte, ticker, open }) });
});

app.get('/api/trades/:id', (req, res) => {
  const trade = getTrade(req.params.id);
  if (!trade) { res.status(404).json({ error: 'trade introuvable' }); return; }
  res.json(trade);
});

// PUT partiel — sert aussi bien à corriger une saisie qu'à clôturer un trade
// (date_sortie/prix_sortie/r_realise/resultat envoyés seuls).
app.put('/api/trades/:id', (req, res) => {
  if (!getTrade(req.params.id)) { res.status(404).json({ error: 'trade introuvable' }); return; }
  const errors = validateTrade(req.body, { partial: true });
  if (errors.length) { res.status(400).json({ errors }); return; }
  try {
    res.json(updateTrade(req.params.id, req.body));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/trades/:id', (req, res) => {
  if (!deleteTrade(req.params.id)) { res.status(404).json({ error: 'trade introuvable' }); return; }
  res.status(204).end();
});

// Export CSV du journal (amélioration 31/8/2026) — même patron que
// GET /api/screening.csv ci-dessus, mais pas de cache : lit la base
// directement, toujours à jour.
app.get('/api/trades.csv', (req, res) => {
  const cols = ['id', ...TRADE_COLUMNS];
  const escape = (v) => {
    if (v == null) return '';
    const s = String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [cols.join(',')];
  for (const row of listTrades()) {
    lines.push(cols.map((c) => escape(row[c])).join(','));
  }
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="journal-castellana-${Date.now()}.csv"`);
  res.send(lines.join('\n'));
});

// Statistiques post-trade (feature 323) — taux de réussite par bande
// d'indicateur (VIX/RSI/OBV/checklist/corrélation/compte) sur les trades
// clôturés. Voir server/stats.js.
app.get('/api/stats', (req, res) => {
  res.json(computeStats());
});

// Webhook TradingView (feature 323, exploratoire) — reçoit l'alerte du Pine
// Script v5 (design doc) et la journalise dans la table `alerts`. AUCUNE
// exécution : c'est un journal pour rapprocher a posteriori le signal du
// trade réel. Accepte du JSON {ticker, message} ou du texte brut.
app.post('/api/webhook/tradingview', express.text({ type: '*/*' }), (req, res) => {
  let ticker = null;
  let message = null;
  let payload = req.body;
  try {
    const parsed = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    ticker = parsed.ticker ?? parsed.symbol ?? null;
    message = parsed.message ?? parsed.text ?? null;
    payload = JSON.stringify(parsed);
  } catch {
    // Pas du JSON — on garde le texte brut comme message.
    message = typeof req.body === 'string' ? req.body : null;
    payload = typeof req.body === 'string' ? req.body : JSON.stringify(req.body);
  }
  const info = db.prepare('INSERT INTO alerts (ticker, message, payload) VALUES (?, ?, ?)').run(
    ticker ? String(ticker).toUpperCase() : null,
    message,
    payload,
  );
  res.status(201).json({ id: info.lastInsertRowid, ticker, message });
});

app.get('/api/alerts', (req, res) => {
  const alerts = db.prepare('SELECT * FROM alerts ORDER BY recu_le DESC, id DESC LIMIT 200').all();
  res.json({ alerts });
});

// Watchlist éditable (bonus) — CRUD sur l'univers de screening persisté en
// base (server/watchlist.js). Modifier la watchlist invalide le cache de
// screening (sinon on servirait un résultat sur l'ancien univers).
app.get('/api/watchlist', (req, res) => {
  res.json({ watchlist: getWatchlist() });
});

app.post('/api/watchlist', (req, res) => {
  const { ticker, exchange } = req.body;
  if (!ticker || !/^[A-Za-z.\-]{1,10}$/.test(ticker)) {
    res.status(400).json({ error: 'ticker invalide' });
    return;
  }
  const watchlist = addToWatchlist(ticker, exchange || 'NASDAQ');
  screeningCache = null;
  res.status(201).json({ watchlist });
});

app.delete('/api/watchlist/:ticker', (req, res) => {
  if (!removeFromWatchlist(req.params.ticker)) {
    res.status(404).json({ error: 'ticker absent de la watchlist' });
    return;
  }
  screeningCache = null;
  res.json({ watchlist: getWatchlist() });
});

app.listen(settings.port, settings.host, () => {
  console.log(`castellana — http://${settings.host}:${settings.port}`);
});
