// Fondamentaux de qualité (26/9/2026, lot 1) — EPS, free cash flow, FCF par
// action, et un indice « le FCF est-il bon dans le temps ? ».
//
// Source : Yahoo Finance direct, comme fundamentals.js. L'HISTORIQUE vient de
// `fundamentalsTimeSeries` (annuel) — les sous-modules d'états financiers de
// `quoteSummary` ne rendent presque plus rien depuis nov. 2024 (Yahoo le dit
// lui-même dans un avertissement). Spike du 26/9/2026 sur AAPL, NVDA et
// SHOP.TO : 4 exercices exploitables par titre ; la 1re ligne renvoyée est
// SYSTÉMATIQUEMENT vide et doit être écartée.
//
// ⚠️ Le `freeCashflow` de `quoteSummary.financialData` est un TTM, pas un
// exercice : sur NVDA il valait 41,8 G$ contre 96,7 G$ pour l'exercice clos
// en janvier 2026. Les deux ne se mélangent JAMAIS dans le score — le score
// ne lit que l'historique annuel, le TTM est affiché à part et étiqueté.
//
// Les seuils vivent ICI et sont renvoyés dans la réponse (`thresholds`),
// plutôt que dupliqués dans config.js : même choix que `signalAge` pour le
// screener, pour ne pas créer une quatrième source de vérité à resynchroniser.
//
// L'indice est DESCRIPTIF, pas un conseil : il résume la régularité et la
// qualité d'un flux de trésorerie passé.

import YahooFinance from 'yahoo-finance2';
import { withRetry } from './fetch-retry.js';
import { cached, TTL } from './cache.js';

const yahooFinance = new YahooFinance({ suppressNotices: ['yahooSurvey'] });

export const FCF_THRESHOLDS = {
  minYears: 3,                 // en dessous : « non disponible », jamais un score
  // Chaque sous-score vaut au plus 25 points ; total sur 100.
  growth: [                    // CAGR du FCF PAR ACTION (pas du FCF brut : un FCF
    { min: 0.10, points: 25 }, // brut monte aussi quand on émet des actions)
    { min: 0.05, points: 18 },
    { min: 0,    points: 10 },
    { min: -0.03, points: 5 },
  ],
  growthFromNegativePoints: 15, // point de départ ≤ 0 : CAGR indéfini, redressement
  consistency: [               // part des exercices à FCF positif
    { min: 1,    points: 25 },
    { min: 0.75, points: 12 },
  ],
  conversion: [                // médiane de FCF ÷ résultat net (années à résultat > 0)
    { min: 0.9, points: 25 },
    { min: 0.7, points: 18 },
    { min: 0.5, points: 10 },
  ],
  dilution: [                  // variation annualisée du nombre d'actions diluées
    { max: -0.01, points: 25 },// rachats nets
    { max: 0.01,  points: 18 },// stable
    { max: 0.03,  points: 8 },
  ],
  verdicts: { solide: 75, mitige: 50 },
  // Le FCF n'a pas de sens comparable pour une banque ou un assureur.
  nonApplicableSectors: ['Financial Services'],
};

const PER_METRIC_MAX = 25;

function pick(bands, value, key) {
  for (const b of bands) {
    if (key === 'min' ? value >= b.min : value <= b.max) return b.points;
  }
  return 0;
}

function median(xs) {
  const s = [...xs].sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}

const isNum = (v) => typeof v === 'number' && Number.isFinite(v);

// Lignes brutes de fundamentalsTimeSeries → exercices exploitables, du plus
// ancien au plus récent. Un exercice sans FCF ni actions diluées est écarté
// (c'est le cas de la 1re ligne, toujours vide).
export function normalizeYears(rows) {
  return (rows || [])
    .filter((r) => isNum(r.freeCashFlow) && isNum(r.dilutedAverageShares) && r.dilutedAverageShares > 0)
    .map((r) => {
      const date = r.date instanceof Date ? r.date : new Date(r.date);
      return {
        fiscalYear: date.toISOString().slice(0, 4),
        date: date.toISOString().slice(0, 10),
        fcf: r.freeCashFlow,
        netIncome: isNum(r.netIncome) ? r.netIncome : null,
        revenue: isNum(r.totalRevenue) ? r.totalRevenue : null,
        dilutedShares: r.dilutedAverageShares,
        eps: isNum(r.dilutedEPS) ? r.dilutedEPS : null,
        fcfPerShare: r.freeCashFlow / r.dilutedAverageShares,
        conversion: isNum(r.netIncome) && r.netIncome > 0 ? r.freeCashFlow / r.netIncome : null,
        fcfMargin: isNum(r.totalRevenue) && r.totalRevenue > 0 ? r.freeCashFlow / r.totalRevenue : null,
      };
    })
    .sort((a, b) => a.date.localeCompare(b.date));
}

// Cœur pur, testé avec des cas construits à la main. Renvoie null si
// l'historique est trop court : l'appelant affiche « N/D », pas un score.
export function scoreFcfQuality(years, t = FCF_THRESHOLDS) {
  if (!years || years.length < t.minYears) return null;
  const n = years.length;
  const first = years[0];
  const last = years[n - 1];
  const span = n - 1;
  const sub = {};

  // 1. Croissance du FCF par action
  if (first.fcfPerShare > 0 && last.fcfPerShare > 0) {
    const cagr = (last.fcfPerShare / first.fcfPerShare) ** (1 / span) - 1;
    sub.growth = { score: pick(t.growth, cagr, 'min'), value: cagr, note: null };
  } else if (first.fcfPerShare <= 0 && last.fcfPerShare > 0) {
    sub.growth = { score: t.growthFromNegativePoints, value: null, note: 'point de départ négatif : croissance non chiffrable' };
  } else {
    sub.growth = { score: 0, value: null, note: 'FCF par action négatif ou nul sur la période récente' };
  }

  // 2. Régularité : part des exercices à FCF positif. Pas de volatilité :
  // sur 3 à 4 points, un écart-type ne dirait rien de fiable.
  const positive = years.filter((y) => y.fcf > 0).length;
  sub.consistency = { score: pick(t.consistency, positive / n, 'min'), value: positive / n, positiveYears: positive, years: n, note: null };

  // 3. Conversion (médiane : un exercice à résultat net minuscule donne un
  // ratio aberrant — SHOP 2023 : 6,9×)
  const conv = years.map((y) => y.conversion).filter(isNum);
  sub.conversion = conv.length
    ? { score: pick(t.conversion, median(conv), 'min'), value: median(conv), note: null }
    : { score: null, value: null, note: 'aucun exercice à résultat net positif' };

  // 4. Dilution : variation annualisée du nombre d'actions diluées
  const dil = (last.dilutedShares / first.dilutedShares) ** (1 / span) - 1;
  sub.dilution = { score: pick(t.dilution, dil, 'max'), value: dil, note: null };

  const available = Object.values(sub).filter((s) => s.score != null);
  const raw = available.reduce((acc, s) => acc + s.score, 0);
  const score = Math.round((raw / (available.length * PER_METRIC_MAX)) * 100);
  const verdict = score >= t.verdicts.solide ? 'solide' : score >= t.verdicts.mitige ? 'mitige' : 'fragile';
  return { score, verdict, partial: available.length < 4, max: PER_METRIC_MAX, sub, years: n };
}

// Un titre → tout ce que la Fiche de trade affiche. Mis en cache 24 h : rien
// d'intrajournalier n'est conservé (on ne garde de `financialData` que le FCF
// TTM, jamais son prix courant).
export async function getFcfQuality(symbol) {
  return cached(`fcf-quality:v3:${symbol}`, TTL.SLOW, async () => {
    const period1 = new Date(Date.now() - 6 * 365 * 24 * 3600 * 1000);
    const [qs, ts] = await Promise.all([
      withRetry(`FCF quoteSummary ${symbol}`, () => yahooFinance.quoteSummary(symbol, {
        modules: ['financialData', 'defaultKeyStatistics', 'summaryProfile'],
      })),
      withRetry(`FCF historique ${symbol}`, () => yahooFinance.fundamentalsTimeSeries(symbol, {
        period1, type: 'annual', module: 'all',
      })),
    ]);
    const sector = qs.summaryProfile?.sector ?? null;
    const shares = qs.defaultKeyStatistics?.sharesOutstanding ?? null;
    const ttmFcf = qs.financialData?.freeCashflow ?? null;
    const base = {
      symbol,
      sector,
      thresholds: FCF_THRESHOLDS,
      ttm: {
        eps: qs.defaultKeyStatistics?.trailingEps ?? null,
        fcf: ttmFcf,
        // Revenus 12 mois (financialData, module déjà demandé) — sert à la marge de FCF.
        revenue: qs.financialData?.totalRevenue ?? null,
        fcfPerShare: isNum(ttmFcf) && isNum(shares) && shares > 0 ? ttmFcf / shares : null,
      },
      // Bilan (11/10/2026) : trésorerie et placements à court terme, dette totale (incluant les
      // contrats de location selon Yahoo), du dernier trimestre publié. Même module financialData,
      // aucun appel de plus. `null` = Yahoo ne le donne pas : jamais 0 (une dette absente n'est pas
      // une dette nulle). Descriptif ; sert à la tuile « Trésorerie » et au critère « Solidité du bilan ».
      balance: {
        cash: isNum(qs.financialData?.totalCash) ? qs.financialData.totalCash : null,
        debt: isNum(qs.financialData?.totalDebt) ? qs.financialData.totalDebt : null,
      },
    };
    if (FCF_THRESHOLDS.nonApplicableSectors.includes(sector)) {
      return { ...base, applicable: false, reason: `Le FCF n'est pas comparable pour le secteur « ${sector} ».`, years: [], quality: null };
    }
    const years = normalizeYears(ts);
    const quality = scoreFcfQuality(years);
    return {
      ...base,
      applicable: true,
      reason: quality ? null : `Historique insuffisant : ${years.length} exercice(s) exploitable(s), ${FCF_THRESHOLDS.minYears} requis.`,
      years,
      quality,
    };
  });
}
