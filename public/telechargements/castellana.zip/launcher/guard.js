// launcher/guard.js — garde des requêtes du lanceur (audit périphérie, 22/10/2026). Fonction pure, sans dépendance : testée dans
// server/launcher-guard.test.js. Le lanceur écoute déjà sur 127.0.0.1 seulement; il manquait le contrôle de ce qui y arrive :
//   - l'en-tête Host doit être la machine elle-même (anti « DNS rebinding », même règle que server/http-guard.js);
//   - une requête marquée `Sec-Fetch-Site: cross-site` est refusée (un <img> ou un fetch d'une autre page);
//   - une écriture (POST) dont l'Origin n'est pas locale est refusée, et doit être du JSON (un POST « simple » d'une autre page ne l'est pas).
const LOOPBACK = new Set(['127.0.0.1', 'localhost', '::1']);

function hostnameOf(value) {
  if (typeof value !== 'string' || !value) return null;
  const h = value.trim().toLowerCase();
  if (h.startsWith('[')) { const end = h.indexOf(']'); return end > 0 ? h.slice(1, end) : null; }
  return h.split(':')[0] || null;
}

/** Retourne null si la requête est acceptée, sinon { status, error }. */
export function verifierRequete({ method, headers }) {
  const host = hostnameOf(headers.host);
  if (!host || !LOOPBACK.has(host)) return { status: 403, error: 'Hôte non autorisé.' };
  if (headers['sec-fetch-site'] === 'cross-site') return { status: 403, error: 'Requête d\'un autre site refusée.' };
  if (method === 'POST') {
    const origin = headers.origin;
    if (origin !== undefined) {
      let name = null;
      try { name = hostnameOf(new URL(origin).host); } catch { /* origine illisible : refusée */ }
      if (!name || !LOOPBACK.has(name)) return { status: 403, error: 'Origine non autorisée.' };
    }
    if (!String(headers['content-type'] || '').toLowerCase().includes('application/json')) {
      return { status: 415, error: 'Content-Type application/json requis.' };
    }
  }
  return null;
}

export const MAX_BODY_BYTES = 4096;
