import test from 'node:test';
import assert from 'node:assert/strict';
import { diffSweep, readyTickers, buildSweepDigest } from './sweep-news.js';

const rows = [
  { ticker: 'AAA', verdict: 'prêt', setupScore: 4, contexteScore: 2, price: 10 },
  { ticker: 'BBB', verdict: 'à surveiller' },
  { ticker: 'CCC', verdict: 'prêt', sector: 'Tech' },
];

test('readyTickers ne garde que les « prêt »', () => assert.deepEqual(readyTickers(rows), ['AAA', 'CCC']));
test('sans balayage précédent : baseline, aucune nouveauté inventée', () => {
  const d = diffSweep(null, rows);
  assert.equal(d.baseline, true); assert.deepEqual(d.nouveautes, []); assert.deepEqual(d.ready, ['AAA', 'CCC']);
});
test('nouveautés et sorties par rapport au précédent', () => {
  const d = diffSweep(['AAA', 'ZZZ'], rows);
  assert.deepEqual(d.nouveautes, ['CCC']); assert.deepEqual(d.sorties, ['ZZZ']); assert.equal(d.baseline, false);
});
test('liste précédente vide (≠ null) : tout est nouveau', () => {
  assert.deepEqual(diffSweep([], rows).nouveautes, ['AAA', 'CCC']);
});
test('courriel : sujet et contenu', () => {
  const m = buildSweepDigest(diffSweep(['ZZZ'], rows), rows, { source: 'yahoo', day: '2026-10-08', universeSize: 503, retainedSize: 40 });
  assert.match(m.subject, /2 nouveau/); assert.match(m.text, /AAA/); assert.match(m.text, /ZZZ/);
  assert.match(buildSweepDigest(diffSweep(null, rows), rows, {}).subject, /premier balayage/);
});
