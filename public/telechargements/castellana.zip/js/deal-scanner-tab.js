// js/deal-scanner-tab.js — onglet « Radar » (22/9/2026), LOCAL UNIQUEMENT.
// Screener multi-titres de meilleurs deals d'options sur les titres déjà
// curés (SECTOR_TOP_CANDIDATES) — pas d'équivalent cloud, jamais chargé par
// cloud/public/index.html. Caché derrière le flag `radar_tab` (défaut OFF,
// `settings.json` → `featureFlags.radarTab`), même patron que Options A/
// Journal A — demandé explicitement par JP pour la cohérence avec les
// autres onglets avancés, même si ce screener n'a qu'un seul utilisateur
// possible (JP, en local).
//
// Le scan tourne en tâche de fond côté serveur (server/deal-scanner.js) ;
// cette page ne fait qu'afficher la progression (poll) et les résultats
// déjà calculés — aucun calcul de score ici, tout vient du serveur.

let radarPollTimer = null;
let radarCurrentScanId = null;

function radarFmtDate(iso) {
  if (!iso) return '—';
  return new Date(iso.replace(' ', 'T') + 'Z').toLocaleString('fr-CA');
}

async function radarStartScan() {
  const status = document.getElementById('radar-status');
  const btn = document.getElementById('radar-start');
  try {
    const { scanId } = await fetchJSON('/api/deal-scanner/start', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ fenetre: document.getElementById('radar-window')?.value || 'standard' }) });
    radarCurrentScanId = scanId;
    btn.disabled = true;
    status.textContent = 'Scan démarré…';
    radarPollProgress();
  } catch (err) {
    status.textContent = 'Échec : ' + err.message;
  }
}

// Nombre de titres en erreur d'un scan (erreurs_json) : un scan « terminé » peut avoir perdu une partie de l'univers.
function radarErrorCount(scan) {
  try { const e = JSON.parse(scan.erreurs_json || '[]'); return Array.isArray(e) ? e.length : 0; } catch { return 0; }
}
function radarProgressBarHTML(scan) {
  const pct = scan.total_tickers > 0 ? Math.round((scan.tickers_scannes / scan.total_tickers) * 100) : 0;
  return `<div style="background:var(--surface-2); border-radius:6px; overflow:hidden; height:10px; margin:6px 0;">
    <div style="background:var(--accent); height:100%; width:${pct}%; transition:width 0.3s;"></div>
  </div>
  <p class="metric-sub" style="text-align:left;">${scan.tickers_scannes} / ${scan.total_tickers} titres scannés (${pct} %) — statut : ${optEsc(scan.statut)}${radarErrorCount(scan) ? ` (${radarErrorCount(scan)} erreur(s))` : ''}${scan.sans_hebdo ? ` — ${scan.sans_hebdo} sans échéances hebdo (ignorés)` : ''}</p>`;
}

async function radarPollProgress() {
  const host = document.getElementById('radar-progress-host');
  const btn = document.getElementById('radar-start');
  if (!radarCurrentScanId) return;
  try {
    const scan = await fetchJSON(`/api/deal-scanner/status?scanId=${radarCurrentScanId}`);
    host.innerHTML = radarProgressBarHTML(scan);
    if (scan.statut === 'en_cours') {
      radarPollTimer = setTimeout(radarPollProgress, 1500);
    } else {
      btn.disabled = false;
      const nbErr = radarErrorCount(scan);
      document.getElementById('radar-status').textContent = scan.statut === 'termine'
        ? (nbErr ? `✓ Scan terminé, mais ${nbErr} erreur(s) : des titres ou des fondamentaux n'ont pas pu être lus (Yahoo limite peut-être les requêtes). Relance plus tard pour compléter.` : '✓ Scan terminé.')
        : 'Le scan a échoué : aucun titre n\'a pu être lu (Yahoo injoignable ou limite de requêtes). Rien n\'a été enregistré. Réessaie plus tard.';
      radarLoadResults();
      radarLoadHistory();
    }
  } catch (err) {
    host.innerHTML = `<p class="ds-text-muted">Échec du suivi de progression : ${optEsc(err.message)}</p>`;
    btn.disabled = false;
  }
}

function radarResultRowHTML(r) {
  const verdictClass = r.verdict === 'excellent' || r.verdict === 'bon' ? 'ds-badge--success' : r.verdict === 'passable' ? 'ds-badge--warning' : 'ds-badge--danger';
  const metricLabel = r.mode === 'vente' ? (r.metric == null ? '—' : r.metric.toFixed(1) + ' %') : (r.metric == null ? '—' : r.metric.toFixed(3));
  return `<tr>
    <td><strong>${optEsc(r.ticker)}</strong></td>
    <td class="ds-text-hint">${optEsc(r.secteur || '—')}</td>
    <td>${optEsc(r.type)}</td>
    <td class="is-num">${optNum(r.strike)}</td>
    <td>${optEsc(r.echeance)} <span class="ds-text-hint">(${r.dte} j)</span></td>
    <td class="is-num">${optNum(r.bid)}</td>
    <td class="is-num">${optNum(r.ask)}</td>
    <td class="is-num">${r.iv == null ? '—' : (r.iv * 100).toFixed(0) + ' %'}</td>
    <td class="is-num">${r.iv_rank == null ? '—' : r.iv_rank.toFixed(0)}</td>
    <td class="is-num">${metricLabel}</td>
    <td class="is-num">${r.days_to_earnings == null ? '—' : r.days_to_earnings}</td>
    <td><span class="ds-badge ${verdictClass}">${optEsc(r.verdict)}</span></td>
  </tr>`;
}

async function radarLoadResults() {
  const host = document.getElementById('radar-results-host');
  const scanId = radarCurrentScanId || document.getElementById('radar-scan-select')?.value;
  if (!scanId) { host.innerHTML = '<p class="ds-text-muted">Lance un scan pour voir les résultats.</p>'; return; }
  const mode = document.getElementById('radar-mode').value;
  const type = document.getElementById('radar-type').value;
  const diversifie = document.getElementById('radar-diversifie').checked;
  const qs = new URLSearchParams({ scanId, mode, diversifie: String(diversifie), limit: '20' });
  if (type !== 'both') qs.set('type', type);
  try {
    const { results } = await fetchJSON(`/api/deal-scanner/results?${qs}`);
    const metricLabel = mode === 'vente' ? 'Rend. ann.' : 'Levier (Δ/prime)';
    host.innerHTML = results.length
      ? `<div style="overflow-x:auto"><table class="ds-table">
          <thead><tr><th>Symbole</th><th>Secteur</th><th>Type</th><th class="is-num">Strike</th><th>Échéance</th><th class="is-num">Bid</th><th class="is-num">Ask</th><th class="is-num">IV <button type="button" class="info-btn" onclick="showGlossaire('iv', this)" title="Aide">i</button></th><th class="is-num" title="Position de l'IV à la monnaie dans son historique du Radar (—  tant que moins de 20 jours)">IV Rank <button type="button" class="info-btn" onclick="showGlossaire('ivRank', this)" title="Aide">i</button></th><th class="is-num">${metricLabel}</th><th class="is-num">Résultats (j)</th><th>Verdict</th></tr></thead>
          <tbody>${results.map(radarResultRowHTML).join('')}</tbody>
        </table></div>`
      : '<p class="ds-text-muted">Aucun résultat pour ce mode/type — élargis les filtres ou consulte le classement brut.</p>';
  } catch (err) {
    host.innerHTML = `<p class="ds-text-muted">Échec du chargement : ${optEsc(err.message)}</p>`;
  }
}

async function radarLoadHistory() {
  const sel = document.getElementById('radar-scan-select');
  try {
    const { scans } = await fetchJSON('/api/deal-scanner/history?limit=20');
    sel.innerHTML = scans.map((s) => `<option value="${s.id}"${s.id === radarCurrentScanId ? ' selected' : ''}>${radarFmtDate(s.started_at)} — ${s.fenetre === 'hebdo' ? 'hebdo 5-10 j' : 'standard 25-45 j'} — ${optEsc(s.statut)} (${s.tickers_scannes}/${s.total_tickers}${s.sans_hebdo ? `, ${s.sans_hebdo} sans hebdo` : ''})</option>`).join('')
      || '<option value="">Aucun scan pour l\'instant</option>';
    if (!radarCurrentScanId && scans.length) { radarCurrentScanId = scans[0].id; radarLoadResults(); }
  } catch { /* historique indisponible — sans conséquence sur le reste de la page */ }
}

function initRadarTab() {
  const btn = document.getElementById('radar-start');
  if (!btn) return;
  btn.addEventListener('click', radarStartScan);
  document.getElementById('radar-mode').addEventListener('change', radarLoadResults);
  document.getElementById('radar-type').addEventListener('change', radarLoadResults);
  document.getElementById('radar-diversifie').addEventListener('change', radarLoadResults);
  document.getElementById('radar-scan-select').addEventListener('change', (e) => { if (document.getElementById('radar-start').disabled) { e.target.value = String(radarCurrentScanId); return; } radarCurrentScanId = Number(e.target.value); radarLoadResults(); });
  radarLoadHistory();
}

// Feature flag radar_tab (défaut OFF) — même patron que
// initOptaVisibility()/initJournalAVisibility() : bouton caché tant que le
// flag n'est pas confirmé ON, toute erreur laisse l'onglet caché.
async function initRadarVisibility() {
  const btn = document.getElementById('tab-btn-radar');
  try {
    const { flags } = await fetchJSON('/api/flags');
    if (flags && flags.radar_tab === true) {
      if (btn) btn.style.display = '';
      initRadarTab();
    }
  } catch { /* onglet reste caché */ }
}
