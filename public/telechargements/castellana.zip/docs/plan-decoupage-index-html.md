# Plan : découper les deux `index.html` de castellana (feature bilbao #447)

Rédigé le 20/10/2026. **Plan seulement, rien n'est modifié.** Les chiffres viennent d'une mesure faite ce jour-là.

## 1. Ce qui est mesuré

| | `index.html` (local) | `cloud/public/index.html` |
|---|---|---|
| Lignes | 5 543 | 5 449 |
| Bloc `<style>` | 1 395 lignes | 1 533 lignes |
| Script en ligne (le gros) | 3 387 lignes, 170 fonctions | 3 375 lignes, 162 fonctions |
| `onclick=` en ligne | 90 | 84 |
| `style="…"` en ligne | 251 | 239 |

Entre les deux pages :
- **142 fonctions sur 170 sont identiques** (≈ 2 670 lignes recopiées), 10 existent dans les deux mais diffèrent, 18 sont propres au local, 10 propres au cloud.
- **606 lignes de CSS sur 666 sont identiques.**
- Les différences réelles sont donc petites et prévisibles : connexion/mot de passe/lien magique (cloud), TradingView local, courriel, mise à jour, publication du balayage (local).
- Les 10 fonctions « différentes » sont à examiner une par une, ce sont elles qui portent la vraie différence local/cloud : `calcFiche`, `checkStatus`, `fetchJSON`, `flagCell`, `initLaboQuickTicker`, `loadSectorSetups`, `resetWeights`, `runScreening`, `screeningExplainError`, `vixInterp`.

Autour de ces deux fichiers, 25 fichiers `js/` existent déjà (de 63 à 1 309 lignes), chargés comme **scripts classiques**
(portée globale partagée). C'est le patron de découpage déjà en place : on l'étend plutôt que d'en inventer un autre.

## 2. Pourquoi c'est un problème (concrètement, ici)

- **Une correction se fait deux fois, ou une fois et on oublie l'autre.** C'est le piège n°1 de la revue de code.
- **Les pannes sont silencieuses.** Une accolade en trop (17/10) ou un nom global dupliqué (13/10) ont fait disparaître un onglet alors que les 330 tests passaient. Un script de 3 400 lignes en ligne est exactement le terrain où cela arrive.
- **Impossible à tester par morceaux.** Les tests évaluent les fichiers `js/` un à un ; le script en ligne n'est testé qu'en compilation.
- **Relecture coûteuse** (humaine ou par un modèle) : 5 500 lignes à lire pour juger un changement de 20 lignes.

## 3. Bonnes pratiques retenues

1. **Mettre un filet avant de toucher quoi que ce soit.** On refactore ce qui est testé. Ici, ce qui manque, c'est un test du **navigateur** (la page se charge, chaque onglet existe, aucune erreur console), parce que les pannes passées étaient invisibles aux tests unitaires.
2. **Découper par petits pas, pas en une réécriture (« strangler »).** Une famille de fonctions à la fois, déplacée telle quelle dans un fichier `js/`, tests verts à chaque pas, un commit par pas.
3. **Une seule source pour tout ce qui est commun**, et des fichiers de **variante** minces pour ce qui diffère. Les deux pages deviennent des coquilles qui ne diffèrent que par leurs cartes propres : c'est exactement le but écrit dans la feature #447.
4. **Retirer les gestionnaires en ligne** (`onclick=`) au profit de `addEventListener` ou d'une délégation par `data-action`. C'est le prérequis pour passer un jour aux modules ES (ils n'exposent pas de globales).
5. **Remplacer les `style="…"` répétés par des classes**, et sortir le CSS dans des fichiers `css/`, communs à l'identique.
6. **Garder le principe « zéro build »** du produit. Pas de bundler (Vite, webpack) : il changerait la façon de lancer, d'installer et de déployer, pour un gain que le découpage seul apporte déjà. On réévaluera si l'on veut un jour les modules ES.

## 4. Plan par phases

Chaque phase est livrable seule, laisse l'app fonctionnelle, et a un critère de fin vérifiable.

### Phase 0 : filet de sécurité (avant tout découpage) : FAITE le 20/10/2026
- `scripts/smoke-browser.mjs` + `scripts/smoke-browser.test.js`, lancés par `npm run test:smoke`. Vrai Chrome headless piloté par le
  protocole DevTools, **sans dépendance npm** (choix modifié en cours de route : Puppeteer en `devDependencies` aurait été installé par
  le `npm install` des testeurs ; le WebSocket natif de Node >= 22 suffit). Chaque page est servie en statique avec un bouchon d'API.
- Vérifie : aucune exception ni erreur de syntaxe, aucun script/CSS introuvable, chaque onglet visible cliquable et son panneau actif,
  écran de connexion présent côté cloud sans session.
- **Auto-test** : le test injecte trois vraies pannes (accolade en trop dans `roue-tab.js`, `optNum` déclaré deux fois, script
  introuvable) et exige que le test de fumée les voie. 6 tests sur 6, environ 45 s. Ils ne sont pas dans `npm test` (Chrome requis).
- Limite : les onglets masqués par un feature flag ne sont pas cliqués (ils sont comptés, pas testés) ; le cloud est testé sans API
  réelle, donc ce qui dépend des données n'est pas vu.

### Phase 1 : sortir le CSS : FAITE le 20/10/2026 (sauf les `style="…"` en ligne, voir « reste »)
- Le seul bloc `<style>` de chaque page est devenu des fichiers : `css/app.css` (commun, 665 lignes + 3 de commentaire), `css/mode-cloud.css`
  (cloud seulement : l'onglet Anticipation, 16 lignes) et `css/mode-local.css` (local seulement : la règle `.sub-title`).
  `cloud/public/css/app.css` est la **copie octet pour octet** de `css/app.css`, tenue par `npm run sync:cloud` (le script gère désormais
  des copies simples, `PLAIN_COPIES`) et gardée par `server/css-parity.test.js` (copie identique, bons fichiers chargés, plus aucun
  bloc `<style>` dans les pages). Pages : `index.html` 5 543 -> 4 878 lignes, `cloud/public/index.html` 5 449 -> 4 770.
- **Preuve que le rendu n'a pas bougé** : `scripts/snapshot-styles.mjs` photographie les styles calculés de chaque élément dans 29 états
  (chaque onglet visible, Réglages et chacun de ses onglets, écran de connexion). Avant et après : **54 712 élément-états comparés,
  0 différence**. Le même outil détecte un changement de 0,1 rem sur le remplissage de la page (1 974 différences) : le « 0 » n'est donc
  pas un faux négatif. Deux prises de vue identiques de l'état de départ donnent aussi 0 (il a fallu trier les propriétés, leur ordre
  d'énumération varie).
- **Ce que la photographie a trouvé** : mon premier découpage mettait `.sub-title` dans le fichier commun, en supposant que le cloud
  n'utilisait pas cette classe. Faux : la carte « Compte » du cloud contient un `div.sub-title` (« Changer mon mot de passe ») qui,
  **depuis l'origine, n'a jamais reçu ce style** dans la version cloud. Appliquer la règle partout aurait changé le cloud (couleur
  et hauteur du libellé). La règle est donc restée **propre au local** (`css/mode-local.css`) pour que ce refactor ne change rien.
  **À décider par JP** : la déplacer dans `css/app.css` pour que le cloud l'applique aussi (probablement l'intention d'origine).
- Reste (phase 1b) : 251 `style="…"` en ligne côté local et 239 côté cloud, à remplacer par des classes en commençant par les motifs
  qui reviennent le plus. Plus risqué que le déplacement du bloc (un style en ligne l'emporte sur une classe) : à faire avec le même
  outil de photographie.
- Limite : les états qui exigent des données réelles (cartes remplies, onglets masqués par un feature flag, Anticipation côté cloud)
  ne sont pas photographiés. Les règles `.antic-*` ont été déplacées en fin de cascade ; elles ne portent que des classes uniques à
  cet onglet, donc le risque est faible, mais **non vérifié visuellement**.

### Phase 2 : sortir le script en ligne : FAITE le 20/10/2026
- Le script en ligne (3 384 lignes local, 3 372 cloud ; 275 et 227 unités de premier niveau) est découpé **par un analyseur de syntaxe**
  (acorn, utilisé une seule fois, hors du dépôt), pas à la main, en alignant les deux pages unité par unité : **206 unités sont
  identiques**, le reste est propre à un mode. Résultat :
  - 11 fichiers COMMUNS `js/app-*.js` (base, listes, journal, selection, fiche, labo, screening, secteurs, graphiques, reglages,
    init), 2 677 lignes, copiés octet pour octet sous `cloud/public/js/` (`PLAIN_COPIES` de `npm run sync:cloud`) ;
  - `js/mode-local.js` (568 lignes) et `cloud/public/js/mode-cloud.js` (546 lignes) : le code propre à un mode, **dont les 10 fonctions qui
    diffèrent** et la connexion/compte du cloud. Une partie de la phase 3 est donc déjà faite ;
  - il reste en ligne **le démarrage seulement** : environ 60 lignes (local) et 45 (cloud, la fonction `boot`).
- Pages : `index.html` 4 878 -> 1 551 lignes, `cloud/public/index.html` 4 770 -> 1 461. Le code est déplacé **tel quel**, sans réécriture.
- **Un piège d'ordre trouvé par le test de fumée, corrigé** : dans un script unique, une déclaration de fonction est « hissée » et
  utilisable par un énoncé placé plus haut ; entre scripts séparés, non. Premier essai : `ReferenceError: renderSectorTopRows is not
  defined` (un `initSortableHeaders(...)` du Screener nomme une fonction des secteurs, déclarée plus loin). Deux règles en découlent :
  les **énoncés exécutés au chargement** (écouteurs, thème, minuteries) sont regroupés dans `js/app-init.js`, chargé après toutes
  les déclarations ; et le **fichier de mode charge en premier** (un énoncé commun nomme `checkStatus`, propre au mode).
  Le test `server/shared-files-parity.test.js` garde cet ordre.
- **Preuves** (mêmes outils qu'en phase 1, plus un nouveau) : `scripts/snapshot-globals.mjs` photographie, après démarrage, les
  **1 899 noms globaux** des trois pages (source de chaque fonction, valeur de chaque variable d'état) : avant/après, **0 différence**
  (il voit un changement d'une valeur d'état) ; `snapshot-styles` : 54 712 élément-états, 0 différence ; `npm test` 349/349 ; test de
  fumée 6/6. Une valeur dépendant du moment (`seenErrors`) est ignorée à la comparaison.
- Limites : ce qui exige des données réelles ou un clic hors des onglets/Réglages n'est pas exercé ; l'équivalence est celle du
  **chargement et de la forme des globales**, pas de chaque parcours utilisateur. Non essayé dans un navigateur avec un vrai compte.
- Reste de la phase 3 : le démarrage en ligne (local : séquence d'appels ; cloud : `boot()`), à sortir dans les fichiers de mode.

### Phase 3 : isoler la différence local/cloud : 3a FAITE le 20/10/2026, 3b non faite
- **3a (fait)** : la séquence de démarrage, qui existait en double (script en ligne de `index.html` et `bootApp()` du cloud), vit une
  fois dans `js/app-demarrage.js` (`demarrerApp(etapes)`, copie cloud par `sync:cloud`). Ce qui est propre à un mode s'y accroche par
  des étapes nommées d'après l'étape commune qu'elles suivent (`apresLoadWeights`, `apresInitLaboStrategies`, etc.) : `MODE_LOCAL` dans
  `js/mode-local.js` (checkVersion, TradingView local, nouvelles du balayage, Radar, alertes, backtest) ; `bootApp()` du cloud (masque la
  connexion, nom du compte, Anticipation, connexion TradingView, mode démo). Le script en ligne local tient en une ligne
  (`demarrerApp(MODE_LOCAL);`). **34 appels étaient communs** aux deux séquences.
- **Seul changement de comportement, décidé avec JP** : `loadSectorSetups()` était appelée plus tôt en cloud qu'en local ; elle est
  maintenant appelée au même endroit (celui du cloud). Elle est indépendante des autres (corps différent selon le mode, n'écrit que dans
  sa carte). Effet : en local, sa requête part avant celles de `labo/params`, `tradingview/status` et `sweep/news`.
- **Preuves** : nouvel outil `scripts/snapshot-boot.mjs` (ordre d'ÉMISSION des appels d'API au démarrage, lu côté navigateur, stable sur
  3 exécutions) : cloud **identique**, local **mêmes 23 appels**, seul `sweep/sectors` change de place, comme décidé. Noms globaux :
  seules différences = `demarrerApp`, `MODE_LOCAL` (nouveaux) et le texte de `bootApp` (cloud) ; styles : 0 différence sur 54 712 ;
  350 tests, 6 de fumée, `wrangler deploy --dry-run` ok.
- **3b (à part, non fait)** : la fonction `boot()` du cloud (45 lignes, décide : lien magique, session, ou écran de connexion) reste en
  ligne, **intacte**. La déplacer touche à l'authentification : à ne faire qu'avec un essai de JP sur une version de test (connexion,
  lien magique, mot de passe oublié) avant promotion.
- Reste hors phase 3 : environ 520 lignes de structure HTML qui diffèrent encore entre les deux pages (fenêtre de connexion, onglet
  Anticipation, cartes propres à un mode).

### Phase 4 : retirer les gestionnaires en ligne
- `onclick=` (90 + 84) vers une délégation d'événements par `data-action`, fichier par fichier.
- **Fin** : plus aucun `onclick=` dans les pages. Cette phase ouvre la porte aux modules ES, sans l'imposer.

### Phase 5 (optionnelle) : modules ES
- À envisager seulement si les collisions de noms globaux restent un problème après les phases 1 à 4. Elle impose de revoir le chargement des tests et les copies cloud ; ne pas la lancer sans en avoir un besoin démontré.

## 5. Risques et parades

| Risque | Parade |
|---|---|
| Une fonction déplacée perd l'accès à une variable globale qui était dans le script en ligne | Inventaire des variables de niveau supérieur (à compter : un premier repérage en voit une cinquantaine) avant la phase 2 ; les déplacer en premier dans un fichier `js/etat.js` chargé le premier |
| Ordre de chargement des scripts | Un test qui échoue si un fichier est appelé avant sa définition (via le test de fumée navigateur) |
| Ajouter un fichier à une seule des deux pages | Test de parité des listes `<script src>` hors fichiers déclarés propres à un mode |
| Le cloud casse alors que le local marche | Chaque phase se termine par `wrangler deploy --dry-run` et un essai en `wrangler dev` local ; le déploiement reste un geste séparé |
| Régression de rendu invisible | Captures avant/après, comparées à l'œil sur les onglets touchés |
| Le chantier s'étire et laisse le code à moitié découpé | Chaque phase laisse l'app fonctionnelle ; on peut s'arrêter après n'importe laquelle |

## 6. Décisions qui reviennent à JP

1. ~~Outil du test de fumée navigateur~~ : tranché, Chrome piloté sans dépendance (voir phase 0).
2. **Périmètre de la phase 3** : accepter que le cloud et le local aient chacun un petit fichier de mode, ou viser une seule page avec détection d'environnement à l'exécution (plus simple à maintenir, mais un seul fichier sert aux deux et un `if` mal placé touche les deux).
3. **Cadence** : une phase par session, avec revue (`/revue-code`) avant chaque push.
4. **Suivi dans bilbao** : découper la feature #447 en une feature par phase.

## 7. Où la revue de code s'insère

- Avant la phase 0 : `/revue-code audit parite-routes` et `/revue-code audit onglets`, pour savoir ce qu'on touche.
- À la fin de chaque phase : `/revue-code` (avant push) sur le diff de la phase.
- Après la phase 3 : la zone `pages` du fichier de pièges devient auditable (elle est volontairement repoussée à après le découpage).
