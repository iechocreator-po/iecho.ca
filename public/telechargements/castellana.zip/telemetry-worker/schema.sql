-- castellana-telemetry — schéma D1 (6/9/2026)
-- Une seule table, volontairement plate : chaque ligne est un événement
-- brut envoyé par une instance locale de castellana (voir js/telemetry.js).
-- `payload_json` porte le détail spécifique à l'event_type (ticker+tab pour
-- ticker_selected, param+oldValue+newValue pour param_changed, etc.) plutôt
-- que des colonnes séparées par type — évite une migration de schéma à
-- chaque nouveau type d'événement.

CREATE TABLE IF NOT EXISTS telemetry_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT NOT NULL,      -- horodatage serveur (ISO 8601, Worker) — jamais celui du client, pour rester fiable même si l'horloge locale d'un testeur dérive
  who TEXT NOT NULL,             -- valeur du sélecteur d'identité (js/telemetry.js) — "inconnu" si jamais choisi
  ip TEXT,                       -- cf-connecting-ip, capturé côté Worker — complément du champ who, jamais le seul identifiant (voir CLAUDE.md)
  event_type TEXT NOT NULL,      -- 'app_loaded' | 'ticker_selected' | 'param_changed'
  payload_json TEXT NOT NULL,    -- détail spécifique à event_type, JSON brut
  user_agent TEXT
);

CREATE INDEX IF NOT EXISTS idx_telemetry_created_at ON telemetry_events (created_at);
CREATE INDEX IF NOT EXISTS idx_telemetry_who ON telemetry_events (who);
