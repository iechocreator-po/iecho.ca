// Cotations Yahoo Finance directes (yahoo-finance2) — remplace, depuis le
// 7/9/2026, l'outil `yahoo_price` du sidecar tradingview-mcp comme source
// par défaut des prix et de la force relative.
//
// Pourquoi ce module existe (constat F6 de l'audit du 7/9/2026) : le
// screening tirait ses cotations de `yahoo_price` *à travers le sidecar
// Python*, alors qu'indicators.js/fundamentals.js/sectors.js interrogeaient
// déjà Yahoo en direct. La « résilience par source » documentée tenait
// contre le rate-limit de `coin_analysis`, mais PAS contre une panne du
// sidecar : les deux transitaient par le même processus Python et tombaient
// ensemble. La force relative, censée survivre à une panne du scanner
// TradingView, disparaissait donc en même temps que le RSI.
//
// Gain mesuré au passage : `quote()` accepte un TABLEAU de symboles et les
// renvoie en une seule requête HTTP — 20 titres en ~81 ms, contre 20
// requêtes espacées de 1,5 s auparavant (l'espacement avait été calibré
// pour le rate-limit TradingView, puis appliqué à Yahoo qui n'en a pas).

import YahooFinance from 'yahoo-finance2';
import { withRetry } from './fetch-retry.js';
import { readCache, writeCache, TTL } from './cache.js';

const yahooFinance = new YahooFinance({ suppressNotices: ['yahooSurvey'] });

// Indice de référence pour la force relative — S&P 500 via SPY, comme
// partout ailleurs dans l'app (js/ticker-section.js l'affiche en clair).
export const BENCHMARK_SYMBOL = 'SPY';

// Cotations groupées : UNE requête pour N symboles. Retourne une Map
// ticker → { price, changePercent, volume, currency }, en n'incluant que
// les symboles réellement résolus par Yahoo — un ticker inconnu est
// simplement absent de la Map, jamais présent avec des zéros trompeurs.
export async function getQuotes(symbols, { force = false } = {}) {
  if (!symbols || symbols.length === 0) return new Map();
  const unique = [...new Set(symbols)];
  const out = new Map();

  // Cache PAR SYMBOLE plutôt que par requête : consulter AMD puis
  // « AMD + ^VIX » réutilise l'entrée d'AMD au lieu de tout refetcher, et
  // une seule requête groupée couvre ensuite les symboles manquants.
  const missing = [];
  for (const symbol of unique) {
    if (force) { missing.push(symbol); continue; }
    const { hit, value } = readCache(`quote:${symbol}`);
    if (hit) out.set(symbol, value);
    else missing.push(symbol);
  }
  if (missing.length === 0) return out;

  const raw = await withRetry(
    `cotations Yahoo (${missing.slice(0, 3).join(', ')}${missing.length > 3 ? `, +${missing.length - 3}` : ''})`,
    () => yahooFinance.quote(missing),
  );
  const rows = Array.isArray(raw) ? raw : [raw];
  for (const q of rows) {
    if (!q?.symbol) continue;
    const value = {
      price: q.regularMarketPrice ?? null,
      changePercent: q.regularMarketChangePercent ?? null,
      volume: q.regularMarketVolume ?? null,
      currency: q.currency ?? null,
    };
    out.set(q.symbol, value);
    writeCache(`quote:${q.symbol}`, value, TTL.QUOTE);
  }
  return out;
}

// VIX — remplace `market_snapshot` du sidecar (qui cherchait '^VIX' dans un
// tableau d'indices). Même symbole, même valeur, une requête directe.
export async function getVix() {
  const quotes = await getQuotes(['^VIX']);
  return quotes.get('^VIX')?.price ?? null;
}

// Force relative de chaque titre vs l'indice de référence, en UNE requête
// groupée pour tout l'univers + le benchmark.
//
// Définition inchangée depuis l'origine (server/tradingview.js) :
// forceRelative = variation du jour du titre − variation du jour de SPY.
// Si SPY est injoignable, `forceRelative` vaut null pour tout le monde —
// jamais 0, qui se lirait comme « performance identique à l'indice ».
export async function getRelativeStrength(tickers, benchmark = BENCHMARK_SYMBOL) {
  const quotes = await getQuotes([...tickers, benchmark]);
  const benchmarkChange = quotes.get(benchmark)?.changePercent ?? null;
  const out = new Map();
  for (const ticker of tickers) {
    const q = quotes.get(ticker);
    const changePercent = q?.changePercent ?? null;
    out.set(ticker, {
      price: q?.price ?? null,
      changePercent,
      forceRelative:
        changePercent != null && benchmarkChange != null
          ? changePercent - benchmarkChange
          : null,
    });
  }
  return { rows: out, benchmarkChange };
}

// Vérif de connectivité pour le témoin de statut du frontend — cotation
// minimale, pas d'historique. Retourne le détail de l'erreur (convention
// établie le 30/8/2026 : jamais un booléen nu qui masque la cause).
export async function checkQuotesConnection() {
  try {
    const quotes = await getQuotes([BENCHMARK_SYMBOL]);
    if (!quotes.has(BENCHMARK_SYMBOL)) {
      return { ok: false, detail: `Yahoo Finance a répondu sans cotation pour ${BENCHMARK_SYMBOL}` };
    }
    return { ok: true, detail: null };
  } catch (err) {
    return { ok: false, detail: err.message };
  }
}
