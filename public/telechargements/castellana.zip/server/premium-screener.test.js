// Test de isPremiumUniverse — la garde qui exclut volontairement l'univers
// élargi du screener de primes (décision de JP, 22/9/2026 : 219 titres × un
// appel de chaîne d'options chacun reproduirait le bug de sous-requêtes
// Cloudflare déjà heurté le 12/9/2026 sur ce même univers). screenPremiums()
// lui-même fait des appels réseau réels — vérifié en direct, pas ici.
import test from 'node:test';
import assert from 'node:assert/strict';
import { isPremiumUniverse } from './premium-screener.js';

test('watchlist, MAG7 et une liste personnalisée sont acceptés', () => {
  assert.equal(isPremiumUniverse('watchlist'), true);
  assert.equal(isPremiumUniverse('mag7'), true);
  assert.equal(isPremiumUniverse('list:12'), true);
});

test('« élargi » est explicitement refusé, contrairement au screener actions', () => {
  assert.equal(isPremiumUniverse('elargi'), false);
});

test('un univers inconnu est refusé', () => {
  assert.equal(isPremiumUniverse('n-importe-quoi'), false);
});
