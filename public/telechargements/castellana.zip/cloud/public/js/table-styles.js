// Styles d'affichage des chaînes d'options (F3) et du screener de primes (G2) — 8/10/2026.
// Cinq styles au choix dans Réglages → Personnalisation ; choix PAR NAVIGATEUR (localStorage),
// défaut : 5 pour F3, 4 pour G2. Ce fichier ne contient que des fonctions d'affichage
// (aucune donnée de marché) ; les tableaux réels les appellent, et l'aperçu des réglages
// les rappelle sur des données fictives, pour que l'aperçu = le rendu réel.
const TS_STYLES = [
  { id: '1', name: 'Thermomètre de la règle', pitch: 'La prime devient une jauge : le trait vertical est le seuil de la règle, la barre se remplit jusqu\'au % atteint et passe au vert quand elle le dépasse.' },
  { id: '2', name: 'La ligne du prix', pitch: 'Une ligne bleue marque le cours ; fond bleu côté assignation, dégradé vert côté sécurité, strike limite encadré avec une pastille.' },
  { id: '3', name: 'Carte thermique sobre', pitch: 'Tout reste neutre sauf le rendement et la marge, colorés en intensité ; la règle devient un voyant vert.' },
  { id: '4', name: 'Rails d\'état', pitch: 'Chaque ligne est une petite carte avec un rail à gauche : vert = règle respectée, ambre = résultats avant l\'échéance, gris = sous la règle.' },
  { id: '5', name: 'Échelle de σ', pitch: 'Un mini-graphique par ligne montre le cours, le mouvement attendu ±1σ/±2σ et la position du strike : la marge de sécurité se voit.' },
];
const TS_DEFAULTS = { f3: '5', g2: '4' };
const TS_KEYS = { f3: 'castellana-style-f3', g2: 'castellana-style-g2' };

function tsGet(which) {
  try { const v = localStorage.getItem(TS_KEYS[which]); if (TS_STYLES.some((s) => s.id === v)) return v; } catch (e) { /* stockage indisponible : défaut */ }
  return TS_DEFAULTS[which];
}
function tsSet(which, id) {
  try { localStorage.setItem(TS_KEYS[which], id); } catch (e) { /* sans effet */ }
}
const tsF2 = (n, d = 2) => Number(n).toFixed(d).replace('.', ',');

// Jauge de la règle : ratio = prime ÷ seuil (1 = seuil atteint, trait au milieu).
function tsGauge(ratio, text) {
  const ok = ratio != null && ratio >= 1;
  const w = ratio == null ? 0 : Math.min(100, ratio * 50);
  return `<div class="ts-gauge${ok ? ' ok' : ''}"><b style="width:${w}%"></b><u></u><span>${text}</span></div>`;
}
// Intensité continue d'une teinte verte (0..1).
function tsHeat(v) {
  if (v == null || !(v > 0)) return '';
  return `background:rgba(46,160,67,${(0.08 + Math.min(1, v) * 0.5).toFixed(2)})`;
}
// Mini-graphique : trait = cours, bande = ±1σ, bande large = ±2σ, point = strike.
function tsSigmaSvg(strike, price, iv, dte, ok) {
  if (!(price > 0) || !(iv > 0) || !(dte > 0) || strike == null) return '';
  const W = 150, mid = W / 2, px = (z) => mid + z * 22;
  const z = (strike - price) / (price * iv * Math.sqrt(dte / 365));
  const x = Math.max(4, Math.min(W - 4, px(z)));
  return `<svg class="ts-sig" viewBox="0 0 ${W} 20" aria-hidden="true"><rect x="${px(-2)}" y="6" width="${px(2) - px(-2)}" height="8" rx="4" fill="var(--surface-2)"/><rect x="${px(-1)}" y="4" width="${px(1) - px(-1)}" height="12" rx="6" fill="rgba(60,110,255,.22)"/><line x1="${mid}" x2="${mid}" y1="2" y2="18" stroke="var(--accent)" stroke-width="2"/><circle cx="${x}" cy="10" r="5" fill="${ok ? 'var(--green)' : 'var(--text-2)'}" stroke="var(--surface)" stroke-width="2"/></svg>`;
}
function tsLegend(which, id) {
  const sw = (bg, t, extra = '') => `<span class="opt-legend-item"><i class="opt-legend-sw" style="background:${bg};${extra}"></i>${t}</span>`;
  const items = {
    '1': [sw('linear-gradient(90deg,rgba(46,160,67,.35),rgba(46,160,67,.8))', 'Jauge verte : la règle est respectée'), sw('rgba(150,150,150,.5)', 'Gris : part du seuil atteinte (le trait = 100 %)'), sw('var(--accent)', 'Filet bleu : dans la monnaie')],
    '2': [sw('rgba(60,110,255,.3)', 'Fond bleu : zone d\'assignation'), sw('rgba(46,160,67,.3)', 'Dégradé vert : hors de la monnaie'), sw('var(--accent)', 'Ligne bleue : cours du sous-jacent'), sw('var(--green)', 'Pastille / pointillé : strike limite')],
    '3': [sw('rgba(46,160,67,.55)', 'Plus foncé = meilleur (rendement, marge)'), sw('var(--green)', 'Voyant vert : règle respectée'), sw('transparent', 'Souligné pointillé bleu : dans la monnaie', 'border-bottom:2px dotted var(--accent);border-radius:0')],
    '4': [sw('var(--green)', 'Rail vert : règle respectée'), sw('var(--amber)', 'Rail ambre : résultats avant l\'échéance'), sw('var(--border)', 'Rail gris, ligne estompée : sous la règle'), sw('var(--accent-bg)', 'Fond bleu : dans la monnaie')],
    '5': [sw('var(--accent)', 'Trait : cours actuel'), sw('rgba(60,110,255,.35)', 'Bande : mouvement attendu ±1σ'), sw('var(--green)', 'Point vert : strike dont la règle est respectée'), sw('var(--green-bg, rgba(46,160,67,.18))', 'Ligne verte : strike limite')],
  }[id];
  const extra = which === 'g2' ? sw('var(--amber)', 'Ambre ⚠ : résultats avant l\'échéance') : '';
  return `<div class="opt-legend">${items.join('')}${id === '4' || which !== 'g2' ? '' : extra}</div>`;
}

// ---- Aperçu (Réglages → Personnalisation) sur des données fictives ----
const TS_PREVIEW = { price: 182.4, iv: 0.55, dte: 14, need: 1.4 };
function tsPreviewF3(id) {
  const P = TS_PREVIEW;
  const data = [[190, 11.68], [182.5, 7.43], [180, 6.25], [175, 4.26], [170, 2.74], [165, 1.66], [160, 0.93], [155, 0.48]];
  let spot = false;
  const rows = [...data].reverse().map(([k, bid]) => {
    const pct = bid / k * 100, ratio = pct / P.need, ok = ratio >= 1, itm = k > P.price, lim = k === 170;
    const yld = bid / k * (365 / P.dte) * 100;
    let out = '';
    if (id === '2' && !spot && k >= P.price) { spot = true; out += `<tr class="spot"><td colspan="5"><div class="ts-spot">Prix ${tsF2(P.price)} $</div></td></tr>`; }
    const z = (P.price - k) / (P.price * P.iv * Math.sqrt(P.dte / 365));
    const prem = id === '1' ? tsGauge(ratio, tsF2(pct) + ' %') : id === '3' ? `<span class="ts-dot${ok ? ' ok' : ''}"></span>${tsF2(pct)} %` : `${tsF2(pct)} %${id === '2' && ok ? ' ✓' : ''}`;
    const good = (id === '2' || id === '5') && ok ? ' class="good"' : '';
    const yCell = id === '3' ? `<td class="heat" style="${tsHeat(yld / 60)}">${tsF2(yld, 1)} %</td>` : `<td${good}>${tsF2(yld, 1)} %</td>`;
    const mCell = id === '5' ? `<td>${tsSigmaSvg(k, P.price, P.iv, P.dte, ok)}</td>` : id === '3' ? `<td class="heat" style="${tsHeat(Math.max(0, z) / 2)}">${tsF2(z, 1)}σ</td>` : `<td>${tsF2(z, 1)}σ</td>`;
    const tag = id === '4' ? (lim ? '<span class="ts-tag">limite</span>' : '') + (itm ? '<span class="ts-tag ts-tag-g">ITM</span>' : '') : id === '2' && lim ? '<span class="ts-pill">LIMITE</span>' : lim && id !== '3' ? ' ★' : '';
    out += `<tr class="${itm ? 'itm' : 'otm'} ${ok ? 'ok' : 'under'} ${lim ? 'lim' : ''}"><td class="opt-strike"><b>${tsF2(k)}</b>${tag}</td><td>${tsF2(bid)}</td><td${id === '1' ? ' class="prem"' : good}>${prem}</td>${yCell}${mCell}</tr>`;
    return out;
  });
  return `<table class="ds-table opt-table tsx tsx${id}"><thead><tr><th>Strike</th><th>Bid</th><th>Prime / strike</th><th>Rend. ann.</th><th>${id === '5' ? 'Position' : 'Marge'}</th></tr></thead><tbody>${rows.join('')}</tbody></table>`;
}
function tsPreviewG2(id) {
  const data = [
    { t: 'NVDA', k: 168, dist: 7.8, pct: 0.51, ratio: 1.06, y: 23.4, price: 182.4, iv: .48, dte: 8, earn: null },
    { t: 'AMD', k: 155, dist: 15.0, pct: 0.66, ratio: 0.44, y: 16.0, price: 182.4, iv: .55, dte: 15, earn: 12 },
    { t: 'MSFT', k: 462, dist: 4.1, pct: 0.81, ratio: 1.01, y: 37.1, price: 482, iv: .24, dte: 8, earn: null },
  ];
  const rows = data.map((r) => {
    const ok = r.ratio >= 1, warn = r.earn != null && r.earn <= r.dte;
    const cls = id === '4' ? (warn ? 'warn' : ok ? 'ok' : 'under') : id === '2' ? 'otm' : '';
    const tag = id === '4' && warn ? `<span class="ts-tag ts-tag-w">résultats ${r.earn} j</span>` : '';
    const prem = id === '1' ? `<td class="prem">${tsGauge(r.ratio, tsF2(r.pct) + ' %')}</td>` : id === '3' ? `<td><span class="ts-dot${ok ? ' ok' : ''}"></span>${tsF2(r.pct)} %</td>` : `<td${(id === '2' || id === '5') && ok ? ' class="good"' : ''}>${tsF2(r.pct)} %${id === '2' && ok ? ' ✓' : ''}</td>`;
    const dist = id === '5' ? `<td>${tsF2(r.dist, 1)} % ${tsSigmaSvg(r.k, r.price, r.iv, r.dte, ok)}</td>` : id === '3' ? `<td class="heat" style="${tsHeat(r.dist / 16)}">${tsF2(r.dist, 1)} %</td>` : `<td>${tsF2(r.dist, 1)} %</td>`;
    const yc = id === '3' ? `<td class="heat" style="${tsHeat(r.y / 60)}">${tsF2(r.y, 1)} %</td>` : `<td${(id === '2' || id === '5') && ok ? ' class="good"' : ''}>${tsF2(r.y, 1)} %</td>`;
    const earn = `<td${warn && id !== '4' ? ' style="color:var(--amber);font-weight:700"' : ''}>${warn ? '⚠ ' : ''}${r.earn ?? '—'}</td>`;
    return `<tr class="${cls}"><td><b>${r.t}</b>${tag}</td><td>${tsF2(r.k, 0)}</td>${dist}${prem}${yc}${earn}</tr>`;
  });
  return `<table class="ds-table opt-table tsx tsx${id}"><thead><tr><th>Symbole</th><th>Strike</th><th>Dist.</th><th>Prime / strike</th><th>Rend. ann.</th><th>Résultats (j)</th></tr></thead><tbody>${rows.join('')}</tbody></table>`;
}

function renderPersonnalisation() {
  const host = document.getElementById('perso-host');
  if (!host) return;
  const section = (which, title, preview) => {
    const cur = tsGet(which);
    return `<div class="ds-card"><div class="section-title">${title}</div>
      <p class="metric-sub" style="text-align:left;">Clique un style : il s'applique tout de suite (si le tableau est chargé, il se redessine). Chaque aperçu est dessiné avec les mêmes fonctions que le vrai tableau, sur des données fictives (AMD, 182,40 $, échéance 14 j, règle 0,5 % / 5 j). Par défaut : style ${TS_DEFAULTS[which]}.</p>
      <div class="perso-grid">${TS_STYLES.map((s) => `<label class="perso-card${s.id === cur ? ' is-selected' : ''}"><div class="perso-head"><input type="radio" name="perso-${which}" value="${s.id}"${s.id === cur ? ' checked' : ''} onchange="persoChoose('${which}','${s.id}')"><b>${s.id} · ${s.name}</b>${s.id === TS_DEFAULTS[which] ? '<span class="ds-badge">défaut</span>' : ''}</div><div class="perso-pitch">${s.pitch}</div><div class="perso-prev">${preview(s.id)}</div>${tsLegend(which, s.id)}</label>`).join('')}</div></div>`;
  };
  host.innerHTML = section('f3', 'F3 — Chaîne d\'options', tsPreviewF3) + section('g2', 'G2 — Screener de primes', tsPreviewG2) +
    '<div style="margin-top:8px;"><button type="button" class="ds-btn" onclick="persoReset()">Revenir aux styles par défaut</button> <span class="metric-sub">Le choix est mémorisé dans ce navigateur.</span></div>';
}
function persoChoose(which, id) {
  tsSet(which, id);
  renderPersonnalisation();
  if (which === 'f3' && typeof optaChain !== 'undefined' && optaChain && typeof renderOptaChain === 'function') renderOptaChain();
  if (which === 'g2' && typeof janlScreenerMeta !== 'undefined' && janlScreenerMeta && typeof janlRenderScreener === 'function') janlRenderScreener();
}
function persoReset() { persoChoose('f3', TS_DEFAULTS.f3); persoChoose('g2', TS_DEFAULTS.g2); }
