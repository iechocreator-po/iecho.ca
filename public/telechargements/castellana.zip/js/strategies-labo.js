// js/strategies-labo.js — Onglet Labo : catalogue des stratégies d'options
// testables + génération de la séquence pas-à-pas pour un titre.
//
// Contexte important : strategy/PoorManCoveredCall.md.rtf, malgré son nom,
// décrit en réalité deux systèmes distincts (Cash-Secured Put → Covered
// Call, puis Bull Call/Bear Put Spread pour la gestion du risque) — PAS la
// vraie Poor Man's Covered Call (LEAPS call profondément ITM + call court
// vendu contre). Décision de JP (5/9/2026, session Labo) : garder ces
// stratégies distinctes de la vraie PMCC dans le sélecteur — 'pmcc'
// implémente la vraie définition standard de la stratégie.
//
// Séparation du 7/9/2026 (demande de JP) : les deux systèmes du fichier
// source, jusque-là fusionnés dans une seule entrée 'roue-debit-spreads',
// sont désormais deux entrées séparées — 'roue' (Cash-Secured Put →
// Covered Call) et 'debit-spreads' (Bull Call / Bear Put Spread). Même
// contenu, juste réorganisé ; aucun nouveau calcul introduit (la jambe
// vendue de chaque spread réutilise la même formule Black-Scholes que la
// Covered Call/le Cash-Secured Put de La Roue, faute d'un Delta cible
// propre aux spreads dans le fichier source).
//
// AUCUNE donnée d'options réelle (chaîne, delta, prime) n'est disponible
// dans cette app — aucune source de ce type n'y est branchée.
//
// Révision du 5/9/2026 (retours de JP, 2e passe — T1/T2/T3) :
// - T1 : toute valeur DYNAMIQUE (calculée à partir du prix/de la
//   volatilité/du ticker chargé) est enveloppée dans <span class="labo-dyn">
//   pour se distinguer visuellement du texte STATIQUE (règle de la
//   stratégie, qui ne change pas d'un titre à l'autre). Voir laboDyn().
// - T2 : les zones de strike ne sont plus un multiple arbitraire de l'ATR
//   (qui n'avait aucun lien mathématique avec le Delta cible annoncé juste
//   à côté — un vrai problème de crédibilité). Elles sont maintenant
//   dérivées de Black-Scholes à partir du Delta cible réel de la
//   stratégie, du prix et de la VOLATILITÉ HISTORIQUE du titre (calculée
//   côté serveur sur son propre historique de prix). Chaque stratégie
//   expose un tableau `legs` détaillant ce calcul, rendu dans un panneau
//   "Comment ces prix sont calculés" — pour répondre concrètement à
//   "pourquoi ce prix-là ?" plutôt que de l'affirmer sans le montrer.
//   RAPPEL, à ne jamais perdre en étendant ceci : la volatilité historique
//   est un PROXY de la volatilité implicite réelle du marché (que cette
//   app n'a aucune source pour obtenir) — l'écart entre les deux peut être
//   important, en particulier autour d'événements comme les résultats
//   trimestriels. Un strike Black-Scholes reste une ESTIMATION, jamais une
//   vraie donnée d'options.
// - T3 : les 3 périodes du filtre de tendance (rapide/moyenne/lente) sont
//   désormais RÉELLEMENT configurables depuis des champs visibles en haut
//   de l'onglet Labo (index.html) — pas seulement des libellés cosmétiques
//   comme c'était le cas ailleurs dans l'app avant cette révision. Voir
//   server/indicators.js (paramètre `periods` de getHomemadeIndicators).

function laboFmtPrix(n) {
  return n == null ? '—' : new Intl.NumberFormat('fr-CA', { style: 'currency', currency: 'USD', maximumFractionDigits: 2 }).format(n);
}
function laboFmtPct(n, decimals = 1) {
  return n == null ? '—' : `${(n * 100).toFixed(decimals)} %`;
}

// T1 — enveloppe toute valeur DYNAMIQUE (dépend du ticker/des données
// chargées) pour la distinguer visuellement du texte statique de la règle.
function laboDyn(text) {
  return `<span class="labo-dyn">${text}</span>`;
}

// Petit bouton (i) vers le popover du glossaire existant (showGlossaire,
// index.html) — mêmes clés que les indicateurs techniques, réutilisé tel
// quel pour ne pas dupliquer le mécanisme de popover.
function laboInfoBtn(key) {
  return `<button type="button" class="info-btn" onclick="showGlossaire('${key}', this)" title="Aide">i</button>`;
}

// ---- Black-Scholes minimal (delta → strike), T2 ----
// Approximation d'erf (Abramowitz & Stegun 7.1.26, précision ~1e-7) — pas
// de librairie ajoutée, cohérent avec la discipline zéro-dépendance du
// reste du portfolio pour ce genre de calcul.
function laboErf(x) {
  const sign = x < 0 ? -1 : 1;
  x = Math.abs(x);
  const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741, a4 = -1.453152027, a5 = 1.061405429, p = 0.3275911;
  const t = 1 / (1 + p * x);
  const y = 1 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);
  return sign * y;
}
function laboNormCdf(x) {
  return 0.5 * (1 + laboErf(x / Math.SQRT2));
}
// Inverse de la CDF normale — approximation rationnelle de Peter Acklam,
// précision ~1.15e-9, algorithme public bien connu (pas de librairie).
function laboNormInv(p) {
  if (p <= 0) return -Infinity;
  if (p >= 1) return Infinity;
  const a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02, 1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00];
  const b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02, 6.680131188771972e+01, -1.328068155288572e+01];
  const c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00, -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00];
  const d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00, 3.754408661907416e+00];
  const plow = 0.02425, phigh = 1 - plow;
  let q, r;
  if (p < plow) {
    q = Math.sqrt(-2 * Math.log(p));
    return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5])
      / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
  }
  if (p <= phigh) {
    q = p - 0.5;
    r = q * q;
    return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q
      / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
  }
  q = Math.sqrt(-2 * Math.log(1 - p));
  return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5])
    / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1);
}

// Strike dont le delta Black-Scholes ≈ `delta` cible, pour un type
// 'call'|'put' donné. d1 = Φ⁻¹(Δ) pour un Call, −Φ⁻¹(Δ) pour un Put (la
// magnitude du delta d'un Put est conventionnellement citée en positif,
// ex. "delta 0.20", même si le vrai delta d'un Put est négatif).
function laboStrikeForDelta({ S, T, r, sigma, delta, type }) {
  const d1 = type === 'call' ? laboNormInv(delta) : -laboNormInv(delta);
  const K = S * Math.exp((r + (sigma * sigma) / 2) * T - d1 * sigma * Math.sqrt(T));
  return { K, d1 };
}

// Zone [basse, haute] entre les deux bornes de Delta de la stratégie —
// calcule un strike pour chaque borne puis trie (pas d'hypothèse sur quel
// côté donne le strike le plus élevé, plus robuste). Retourne aussi le
// détail complet (`leg`) pour le panneau "Comment ces prix sont calculés".
function laboStrikeZone({ S, T, r, sigma, deltaMin, deltaMax, type, role, dteJours }) {
  if (S == null || sigma == null) {
    return { texte: '—', basse: null, haute: null, leg: { role, type, deltaMin, deltaMax, dteJours, indisponible: true } };
  }
  const atMin = laboStrikeForDelta({ S, T, r, sigma, delta: deltaMin, type });
  const atMax = laboStrikeForDelta({ S, T, r, sigma, delta: deltaMax, type });
  const basse = Math.min(atMin.K, atMax.K);
  const haute = Math.max(atMin.K, atMax.K);
  return {
    texte: `${laboFmtPrix(basse)} – ${laboFmtPrix(haute)}`,
    basse,
    haute,
    leg: { role, type, deltaMin, deltaMax, dteJours, S, T, r, sigma, atMin, atMax, indisponible: false },
  };
}

// Rendu du panneau "Comment ces prix sont calculés" (une ligne par leg) —
// <details> natif, replié par défaut, pas de JS de bascule nécessaire.
function laboRenderAnalyse(legs) {
  const rows = legs.map((leg) => {
    if (leg.indisponible) {
      return `<tr><td>${leg.role}</td><td>${leg.type === 'call' ? 'Call' : 'Put'}</td><td>${laboFmtPct(leg.deltaMin, 0)}–${laboFmtPct(leg.deltaMax, 0)}</td><td colspan="3">Charge les données en direct pour voir ce calcul.</td></tr>`;
    }
    return `<tr>
      <td>${leg.role}</td>
      <td>${leg.type === 'call' ? 'Call' : 'Put'}</td>
      <td>${laboFmtPct(leg.deltaMin, 0)} (d1=${leg.atMin.d1.toFixed(3)}) → ${laboFmtPrix(leg.atMin.K)}</td>
      <td>${laboFmtPct(leg.deltaMax, 0)} (d1=${leg.atMax.d1.toFixed(3)}) → ${laboFmtPrix(leg.atMax.K)}</td>
      <td>${leg.dteJours} j (T=${(leg.T).toFixed(3)} an)</td>
    </tr>`;
  }).join('');
  const first = legs.find((l) => !l.indisponible);
  const inputs = first
    ? `Prix (S) = ${laboFmtPrix(first.S)} · Volatilité historique annualisée (σ) = ${laboFmtPct(first.sigma)} · Taux sans risque (r) = ${laboFmtPct(first.r)}`
    : `Charge les données en direct pour voir les valeurs utilisées (prix, volatilité historique, taux sans risque).`;
  return `
    <details class="labo-analyse">
      <summary>Comment ces prix sont calculés (Black-Scholes)</summary>
      <p class="metric-sub" style="text-align:left;">${inputs}</p>
      <p class="metric-sub" style="text-align:left;">Formule : K = S × exp((r + σ²/2) × T − d1 × σ × √T), où d1 = Φ⁻¹(Delta) pour un Call acheté/vendu, ou −Φ⁻¹(Delta) pour un Put. σ est une volatilité HISTORIQUE (réalisée sur les prix passés) utilisée comme approximation de la volatilité implicite réelle du marché — que cette app n'a aucune source pour obtenir. L'écart entre les deux peut être important (ex. autour des résultats trimestriels).</p>
      <div class="screen-table-wrap">
        <table class="ds-table">
          <thead><tr><th>Jambe</th><th>Type</th><th>Borne basse du Delta</th><th>Borne haute du Delta</th><th>Échéance utilisée</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </details>
  `;
}

// Résume les SMA + le prix pour que l'alignement affiché (haussier/neutre/
// baissier) soit VÉRIFIABLE par JP plutôt qu'un mot opaque. Les périodes
// utilisées viennent de `data.smaPeriods` (réellement appliquées côté
// serveur, T3) plutôt que supposées être 9/21/100.
function laboSmaDetail(data) {
  if (!data || data.sma9 == null || data.sma21 == null || data.sma100 == null || data.price == null) {
    return "Clique « Charger les données en direct » pour voir le prix et les 3 SMA réels et vérifier toi-même l'ordre.";
  }
  const p = data.smaPeriods || { fast: 9, medium: 21, slow: 100 };
  return `Valeurs réelles — Prix ${laboDyn(laboFmtPrix(data.price))} · SMA${p.fast} ${laboDyn(laboFmtPrix(data.sma9))} · SMA${p.medium} ${laboDyn(laboFmtPrix(data.sma21))} · SMA${p.slow} ${laboDyn(laboFmtPrix(data.sma100))}. `
    + `« Haussier » exige prix > SMA${p.fast} > SMA${p.medium} > SMA${p.slow} dans cet ordre exact ; « baissier » l'ordre strictement inverse ; sinon c'est « neutre » (l'ordre n'est pas complet, même si certaines des trois valeurs sont bien rangées).`;
}

const STRATEGIES_LABO = [
  {
    id: 'roue',
    nom: 'La Roue (Wheel Strategy)',
    statut: 'disponible',
    resume: "Vente de Cash-Secured Put pour collecter des primes, assignation éventuelle suivie de Covered Call sur les actions reçues.",
    sourceNote: "Source : strategy/PoorManCoveredCall.md.rtf — ce fichier porte ce nom mais décrit en réalité ce système (La Roue) et les Debit Spreads (voir l'entrée séparée ci-dessous), pas la vraie Poor Man's Covered Call (voir l'entrée dédiée plus bas). Séparées en deux stratégies distinctes le 7/9/2026 à la demande de JP — elles vivaient à l'origine dans une seule séquence.",
    build(ctx) {
      const { ticker, data } = ctx;
      const cfg = CFG.labo;
      const S = data?.price ?? null;
      const sigma = data?.historicalVolatility ?? null;
      const r = cfg.riskFreeRate;
      const putDte = Math.round((cfg.put.dteMin + cfg.put.dteMax) / 2);
      const callDte = Math.round((cfg.call.dteMin + cfg.call.dteMax) / 2);
      const putZone = laboStrikeZone({ S, T: putDte / 365, r, sigma, deltaMin: cfg.put.deltaMin, deltaMax: cfg.put.deltaMax, type: 'put', role: 'Put vendu (Cash-Secured Put)', dteJours: putDte });
      const callZone = laboStrikeZone({ S, T: callDte / 365, r, sigma, deltaMin: cfg.call.deltaMin, deltaMax: cfg.call.deltaMax, type: 'call', role: 'Call vendu (Covered Call)', dteJours: callDte });
      const steps = [
        {
          titre: '1. Sélection du sous-jacent (filtre fondamental)',
          points: [
            `Vérifier que ${laboDyn(ticker)} est une Blue Chip ou un ETF à forte liquidité — pas un titre spéculatif.`,
            data
              ? `Données réelles — Volume du jour : ${laboDyn(data.volume != null ? data.volume.toLocaleString('fr-CA') : '—')} · Beta 5 ans : ${laboDyn(data.beta ?? '—')} · Secteur : ${laboDyn(data.sector ?? '—')}`
              : `Clique « Charger les données en direct » pour voir le volume/beta/secteur réels de ${laboDyn(ticker)}.`,
          ],
        },
        {
          titre: '2. Phase 1 — Vendre un Put garanti par du cash (Cash-Secured Put)',
          points: [
            `Vendre (encaisser une prime pour) un Put, échéance dans ${laboDyn(cfg.put.dteMin + '-' + cfg.put.dteMax + ' jours')} (DTE = jours restants avant l'échéance), Delta cible ${laboDyn(cfg.put.deltaMin + '-' + cfg.put.deltaMax)} ${laboInfoBtn('delta')} (≈75-85% de chances d'expirer hors la monnaie, donc favorable au vendeur).`,
            `Zone de strike estimée (Black-Scholes, volatilité historique — <a href="#" onclick="return false;">détail plus bas</a>) : ${laboDyn(putZone.texte)}`,
            `Résultat A — le titre monte ou stagne : le Put expire sans valeur → profit = 100% de la prime encaissée.`,
            `Résultat B — le titre baisse sous le strike : assignation → achat obligatoire de 100 actions ${laboDyn(ticker)} au prix du strike (d'où « garanti par du cash » : il faut avoir ce montant disponible).`,
          ],
        },
        {
          titre: '3. Phase 2 — Vendre un Call sur les actions reçues (Covered Call)',
          points: [
            `Uniquement si assigné en phase 1 : vendre un Call sur les 100 actions maintenant détenues, mêmes échéance/Delta cible que le Put ci-dessus.`,
            `Zone de strike estimée : ${laboDyn(callZone.texte)}`,
            `Résultat A — le titre dépasse le strike : les actions sont rachetées (« cédées ») au strike → profit sur le titre + prime encaissée.`,
            `Résultat B — le titre stagne sous le strike : rien ne se passe → répéter la vente d'un nouveau Call le cycle suivant.`,
          ],
        },
        {
          titre: '4. Règles de sortie (les deux phases)',
          points: [
            `Prise de profit : racheter l'option vendue (Buy to Close) dès ${laboDyn(cfg.profitTake.min + '%')} à ${laboDyn(cfg.profitTake.max + '%')} du profit maximal atteint — ne pas attendre l'expiration.`,
            `Gestion défensive : rouler (Roll = racheter puis revendre à une échéance plus lointaine) si le strike est testé.`,
          ],
        },
      ];
      return { steps, legs: [putZone.leg, callZone.leg] };
    },
  },
  {
    id: 'debit-spreads',
    nom: 'Debit Spreads (Bull Call / Bear Put)',
    statut: 'disponible',
    resume: "Achat d'un Call ou Put proche du prix et vente d'une option plus loin de la monnaie dans la même direction, pour une anticipation directionnelle forte à risque limité au montant payé.",
    sourceNote: "Source : strategy/PoorManCoveredCall.md.rtf — même fichier que La Roue ci-dessus (elles y étaient décrites comme un seul système de gestion du risque). Séparées en deux stratégies distinctes le 7/9/2026 à la demande de JP.",
    build(ctx) {
      const { ticker, data } = ctx;
      const cfg = CFG.labo;
      const S = data?.price ?? null;
      const sigma = data?.historicalVolatility ?? null;
      const r = cfg.riskFreeRate;
      const putDte = Math.round((cfg.put.dteMin + cfg.put.dteMax) / 2);
      const callDte = Math.round((cfg.call.dteMin + cfg.call.dteMax) / 2);
      // Même formule que pour La Roue (jambe vendue au même Delta cible) —
      // ce fichier source ne donne pas de Delta distinct pour un spread,
      // seule la jambe achetée change (« proche du prix », non calculée
      // par Black-Scholes faute de Delta cible propre à cette jambe dans
      // la source).
      const putZone = laboStrikeZone({ S, T: putDte / 365, r, sigma, deltaMin: cfg.put.deltaMin, deltaMax: cfg.put.deltaMax, type: 'put', role: 'Put vendu (jambe courte du Bear Put Spread)', dteJours: putDte });
      const callZone = laboStrikeZone({ S, T: callDte / 365, r, sigma, deltaMin: cfg.call.deltaMin, deltaMax: cfg.call.deltaMax, type: 'call', role: 'Call vendu (jambe courte du Bull Call Spread)', dteJours: callDte });
      const steps = [
        {
          titre: '1. Sélection du sous-jacent',
          points: [
            `Vérifier que ${laboDyn(ticker)} est une Blue Chip ou un ETF à forte liquidité — pas un titre spéculatif.`,
            data
              ? `Données réelles — Volume du jour : ${laboDyn(data.volume != null ? data.volume.toLocaleString('fr-CA') : '—')} · Beta 5 ans : ${laboDyn(data.beta ?? '—')} · Secteur : ${laboDyn(data.sector ?? '—')}`
              : `Clique « Charger les données en direct » pour voir le volume/beta/secteur réels de ${laboDyn(ticker)}.`,
          ],
        },
        {
          titre: '2. Anticipation haussière forte — Bull Call Spread',
          points: [
            `Acheter un Call proche du prix actuel (${laboDyn(laboFmtPrix(S))}), vendre un Call plus haut, échéance dans ${laboDyn(cfg.call.dteMin + '-' + cfg.call.dteMax + ' jours')} (DTE).`,
            `Zone de strike estimée pour la jambe vendue (Black-Scholes, volatilité historique — <a href="#" onclick="return false;">détail plus bas</a>) : ${laboDyn(callZone.texte)}`,
            `Gain plafonné à l'écart entre les deux strikes moins le montant payé (le « débit ») ; risque limité à ce montant payé, jamais plus.`,
          ],
        },
        {
          titre: '3. Anticipation baissière forte — Bear Put Spread',
          points: [
            `Acheter un Put proche du prix actuel (${laboDyn(laboFmtPrix(S))}), vendre un Put plus bas, mêmes échéance/Delta cible que ci-dessus.`,
            `Zone de strike estimée pour la jambe vendue : ${laboDyn(putZone.texte)}`,
            `Assurance baissière à coût réduit par rapport à l'achat d'un Put seul — même plafond/plancher de gain-risque qu'un Bull Call Spread, en miroir.`,
          ],
        },
        {
          titre: '4. Règles de sortie',
          points: [
            `Prise de profit : revendre le spread (ou racheter/revendre chaque jambe) dès ${laboDyn(cfg.profitTake.min + '%')} à ${laboDyn(cfg.profitTake.max + '%')} du profit maximal atteint — ne pas attendre l'expiration.`,
            `Le risque étant déjà limité au montant payé, il n'y a pas de « gestion défensive » à proprement parler comme pour un Put/Call vendu seul — la perte maximale est connue dès l'ouverture.`,
          ],
        },
      ];
      return { steps, legs: [callZone.leg, putZone.leg] };
    },
  },
  {
    id: 'pmcc',
    nom: "Poor Man's Covered Call (PMCC)",
    statut: 'disponible',
    resume: "Achat d'un Call à longue échéance (LEAPS), profondément dans la monnaie, comme substitut synthétique aux 100 actions — puis vente répétée de Calls courts contre pour encaisser des primes à chaque cycle.",
    sourceNote: "Définition standard de la stratégie, indépendante du fichier strategy/PoorManCoveredCall.md.rtf (voir la note sur « La Roue & Debit Spreads » ci-dessus).",
    build(ctx) {
      const { ticker, data } = ctx;
      const cfg = CFG.labo.pmcc;
      const r = CFG.labo.riskFreeRate;
      const S = data?.price ?? null;
      const sigma = data?.historicalVolatility ?? null;
      const callDte = Math.round((CFG.labo.call.dteMin + CFG.labo.call.dteMax) / 2);
      const leapsZone = laboStrikeZone({ S, T: cfg.leapsDteTypiqueJours / 365, r, sigma, deltaMin: cfg.leapsDeltaMin, deltaMax: cfg.leapsDeltaMax, type: 'call', role: 'LEAPS Call acheté', dteJours: cfg.leapsDteTypiqueJours });
      const callZone = laboStrikeZone({ S, T: callDte / 365, r, sigma, deltaMin: CFG.labo.call.deltaMin, deltaMax: CFG.labo.call.deltaMax, type: 'call', role: 'Call court vendu', dteJours: callDte });
      const smaP = data?.smaPeriods || { fast: CFG.indicateurs.smaRapide, medium: CFG.indicateurs.smaMoyenne, slow: CFG.indicateurs.smaLente };
      const steps = [
        {
          titre: '1. Sélection du sous-jacent',
          points: [
            `Même filtre que pour une Covered Call classique : ${laboDyn(ticker)} liquide, tendance de fond haussière ou neutre — pas un titre en chute.`,
            `Alignement SMA ${smaP.fast}/${smaP.medium}/${smaP.slow} ${laboInfoBtn('sma')} : ${laboDyn(`<strong>${data?.smaAlignment ?? '—'}</strong>`)}. ${laboSmaDetail(data)}`,
          ],
        },
        {
          titre: `2. Acheter un Call à longue échéance (${laboInfoBtn('leaps')} LEAPS), profondément dans la monnaie`,
          points: [
            `« LEAPS » = simplement un Call dont l'échéance est longue, PAS un instrument différent — voir le bouton d'aide ci-dessus.`,
            `Échéance longue : au moins ${laboDyn(cfg.leapsDteMinJours + ' jours')} avant l'expiration (calcul ci-dessous fait pour une échéance typique de ${laboDyn(cfg.leapsDteTypiqueJours + ' jours')}, environ 1 an).`,
            `Delta cible ${laboInfoBtn('delta')} : ${laboDyn(cfg.leapsDeltaMin + '-' + cfg.leapsDeltaMax)} — profondément dans la monnaie, pour que ce Call bouge presque comme 100 actions du titre.`,
            `Strike estimé (Black-Scholes, volatilité historique — détail plus bas) : ${laboDyn(leapsZone.texte)} — à valider avec la vraie chaîne d'options chez ton courtier.`,
            `Coût net généralement inférieur à l'achat de 100 actions ${laboDyn(ticker)}, pour une exposition directionnelle comparable.`,
          ],
        },
        {
          titre: '3. Vendre un Call à échéance courte contre ce LEAPS, cycle après cycle',
          points: [
            `Vendre un Call, échéance dans ${laboDyn(CFG.labo.call.dteMin + '-' + CFG.labo.call.dteMax + ' jours')} (DTE), Delta cible ${laboInfoBtn('delta')} ${laboDyn(CFG.labo.call.deltaMin + '-' + CFG.labo.call.deltaMax)}.`,
            `Zone de strike estimée : ${laboDyn(callZone.texte)}`,
            `Résultat A — le titre reste sous le strike du Call court : il expire sans valeur → profit = prime encaissée, LEAPS conservé → vendre un nouveau Call court le cycle suivant.`,
            `Résultat B — le titre dépasse le strike du Call court : racheter (Buy to Close) avant assignation et rouler à un strike plus haut, ou laisser exercer en livrant les actions via le LEAPS.`,
          ],
        },
        {
          titre: '4. Points de vigilance propres au PMCC',
          points: [
            `Le LEAPS a un Delta ${laboInfoBtn('delta')} inférieur à 1 : il ne réplique pas exactement 100 actions — en cas de forte baisse du titre, la perte est moindre qu'avec des actions, mais elle existe.`,
            `Profit maximal du côté court plafonné au strike du Call court moins le coût net payé pour le LEAPS.`,
            `Rouler le LEAPS avant qu'il ne reste que ${laboDyn(cfg.rouleAvantJours + ' jours')} à l'échéance, pour éviter l'accélération de sa propre décroissance temporelle (thêta).`,
          ],
        },
      ];
      return { steps, legs: [leapsZone.leg, callZone.leg] };
    },
  },
  {
    id: 'iron-condor',
    nom: 'Iron Condor',
    statut: 'a-venir',
    resume: "Vente simultanée d'un Bull Put Spread et d'un Bear Call Spread sur un titre jugé stable — encaisse une prime nette si le titre reste dans un canal de prix.",
  },
  {
    id: 'credit-spreads',
    nom: 'Credit Spreads (Bull Put / Bear Call)',
    statut: 'a-venir',
    resume: "Vente d'un spread crédit directionnel à risque défini, sans détenir le sous-jacent.",
  },
];
