// js/symbol-search.js — Recherche de symbole par nom, à la TradingView
// (3/10/2026). Fenêtre modale : champ de recherche, filtres (Tous / Actions /
// Fonds / Indices), liste symbole · nom · type · bourse. Un clic (ou Entrée)
// remplit le champ « Symbole évalué » qui l'a ouverte et lance la récupération. Backend : GET /api/search/symbols (Yahoo, voir server/symbol-search.js).
//
// Conversion de notation : taper « BRK.B » (TradingView) dans un champ
// symbole le transforme en « BRK-B » (Yahoo) à la sortie du champ.
// Les suffixes de bourse (.TO, .V…) ne sont pas touchés.

(function () {
  const FILTERS = [['all', 'Tous'], ['stocks', 'Actions'], ['funds', 'Fonds'], ['indices', 'Indices']];
  let dlg = null, state = { targetId: null, onPick: null, filter: 'all', results: [], active: 0, timer: null, seq: 0 };

  const css = `
    #symbol-search-dlg { border: 1px solid var(--border); border-radius: 12px; background: var(--surface); color: var(--text); padding: 0; width: min(640px, 94vw); margin: 8vh auto 0; box-shadow: 0 12px 40px rgba(0,0,0,.4); }
    #symbol-search-dlg::backdrop { background: rgba(0,0,0,.55); }
    .ss-head { display: flex; justify-content: space-between; align-items: center; padding: 14px 18px 4px; font-weight: 700; font-size: 16px; }
    .ss-close { background: none; border: none; color: var(--text-2); font-size: 22px; cursor: pointer; line-height: 1; }
    .ss-body { padding: 8px 18px 6px; }
    .ss-chips { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 10px; }
    .ss-chip { border: 1px solid var(--border); background: var(--surface-2); color: var(--text); border-radius: 999px; padding: 4px 12px; font-size: 12px; cursor: pointer; }
    .ss-chip.is-active { background: var(--accent); border-color: var(--accent); color: var(--surface); font-weight: 600; }
    .ss-list { max-height: 52vh; overflow-y: auto; margin-top: 8px; border-top: 1px solid var(--border); }
    .ss-row { display: grid; grid-template-columns: 110px 1fr auto; gap: 10px; align-items: center; padding: 9px 18px; cursor: pointer; border-bottom: 1px solid var(--border); font-size: 13px; }
    .ss-row.is-active, .ss-row:hover { background: var(--surface-2); outline: 1px solid var(--accent); outline-offset: -1px; }
    .ss-sym { color: var(--accent); font-weight: 700; }
    .ss-name { color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .ss-meta { color: var(--text-2); font-size: 11px; white-space: nowrap; }
    .ss-empty { padding: 18px; color: var(--text-2); font-size: 13px; }
  `;

  function esc(t) { return String(t ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

  function build() {
    const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
    dlg = document.createElement('dialog');
    dlg.id = 'symbol-search-dlg';
    dlg.innerHTML = `
      <div class="ss-head"><span>Recherche de symbole</span><button type="button" class="ss-close" aria-label="Fermer">&times;</button></div>
      <div class="ss-body">
        <input class="ds-input" id="ss-input" type="text" placeholder="Nom ou symbole (ex. berkshire, BRK.B, apple)" autocomplete="off" style="width:100%;">
        <div class="ss-chips">${FILTERS.map(([k, l]) => `<button type="button" class="ss-chip${k === 'all' ? ' is-active' : ''}" data-f="${k}">${l}</button>`).join('')}</div>
      </div>
      <div class="ss-list" id="ss-list"><div class="ss-empty">Tape un nom d'entreprise ou un symbole.</div></div>`;
    document.body.appendChild(dlg);
    dlg.querySelector('.ss-close').addEventListener('click', () => dlg.close());
    dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close(); });
    dlg.querySelectorAll('.ss-chip').forEach((b) => b.addEventListener('click', () => {
      state.filter = b.dataset.f;
      dlg.querySelectorAll('.ss-chip').forEach((x) => x.classList.toggle('is-active', x === b));
      run();
    }));
    const input = dlg.querySelector('#ss-input');
    input.addEventListener('input', () => { clearTimeout(state.timer); state.timer = setTimeout(run, 250); });
    input.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') { e.preventDefault(); move(1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); move(-1); }
      else if (e.key === 'Enter') { e.preventDefault(); if (state.results[state.active]) pick(state.results[state.active].symbol); }
    });
    dlg.querySelector('#ss-list').addEventListener('click', (e) => {
      const row = e.target.closest('.ss-row'); if (row) pick(row.dataset.sym);
    });
  }

  function move(d) {
    if (!state.results.length) return;
    state.active = (state.active + d + state.results.length) % state.results.length;
    renderList();
    const el = dlg.querySelector('.ss-row.is-active'); if (el) el.scrollIntoView({ block: 'nearest' });
  }

  function renderList(msg) {
    const list = dlg.querySelector('#ss-list');
    if (msg) { list.innerHTML = `<div class="ss-empty">${esc(msg)}</div>`; return; }
    list.innerHTML = state.results.map((r, i) => `
      <div class="ss-row${i === state.active ? ' is-active' : ''}" data-sym="${esc(r.symbol)}">
        <span class="ss-sym">${esc(r.symbol)}</span>
        <span class="ss-name">${esc(r.name)}</span>
        <span class="ss-meta">${esc(r.typeLabel)} · ${esc(r.exchange)}</span>
      </div>`).join('');
  }

  async function run() {
    const q = dlg.querySelector('#ss-input').value.trim();
    if (!q) { state.results = []; renderList("Tape un nom d'entreprise ou un symbole."); return; }
    const seq = ++state.seq;
    renderList('Recherche…');
    try {
      const data = await fetchJSON(`/api/search/symbols?q=${encodeURIComponent(q)}&filter=${state.filter}`);
      if (seq !== state.seq) return; // une recherche plus récente a pris le relais
      state.results = data.results || []; state.active = 0;
      if (!state.results.length) renderList(`Aucun résultat pour « ${q} ».`); else renderList();
    } catch (err) {
      if (seq !== state.seq) return;
      state.results = []; renderList('Recherche indisponible : ' + err.message);
    }
  }

  function pick(symbol) {
    const input = document.getElementById(state.targetId);
    dlg.close();
    if (!input) return;
    input.value = symbol;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    if (state.onPick) state.onPick();
  }

  function openDialog(targetId, onPick) {
    if (!dlg) build();
    state.targetId = targetId; state.onPick = onPick; state.results = []; state.active = 0;
    const input = dlg.querySelector('#ss-input');
    input.value = (document.getElementById(targetId)?.value || '').trim();
    dlg.showModal();
    input.focus(); input.select();
    if (input.value) run(); else renderList("Tape un nom d'entreprise ou un symbole.");
  }

  // Bouton unique « Récupérer en direct » : champ vide → ouvre la recherche ;
  // texte tapé → on le cherche d'abord. Si c'est exactement un symbole connu
  // (AAPL, BRK.B, XEQT.TO…) on récupère tout de suite, sans fenêtre ; sinon
  // la fenêtre s'ouvre avec les choix. Si la recherche elle-même échoue ou ne
  // trouve rien, on récupère quand même (le message d'erreur habituel dira
  // « inconnu ») plutôt que de bloquer l'utilisateur.
  window.searchThenFetch = async function (targetId, btn, doFetch) {
    const input = document.getElementById(targetId);
    const typed = (input?.value || '').trim();
    if (!typed) { openDialog(targetId, doFetch); return; }
    if (btn) btn.disabled = true;
    try {
      const data = await fetchJSON(`/api/search/symbols?q=${encodeURIComponent(typed)}&filter=all`);
      const results = data.results || [];
      const exact = results.find((r) => r.symbol.toUpperCase() === (data.query || typed).toUpperCase());
      if (exact || results.length === 0) { if (exact && input.value !== exact.symbol) { input.value = exact.symbol; input.dispatchEvent(new Event('input', { bubbles: true })); } doFetch(); return; }
      openDialog(targetId, doFetch);
    } catch (e) {
      doFetch();
    } finally {
      if (btn) btn.disabled = false;
    }
  };

  // « BRK.B » → « BRK-B » à la sortie d'un champ symbole.
  document.addEventListener('change', (e) => {
    const t = e.target;
    if (!t || t.tagName !== 'INPUT' || !/ticker$/.test(t.id || '')) return;
    const m = String(t.value).trim().match(/^([A-Za-z]{1,5})[./]([A-Za-z])$/);
    if (m && !/^(TO|V|L|NE|CN)$/i.test(m[2])) {
      t.value = `${m[1].toUpperCase()}-${m[2].toUpperCase()}`;
      t.dispatchEvent(new Event('input', { bubbles: true }));
    }
  });
})();
