# Document de design — Assistant de swing trading (screening, sizing, exécution)

## 1. Contexte

JP est un investisseur autodirigé basé au Québec, gérant un portefeuille multi-comptes (REER, non-enregistré/margin, corporatif) et pratiquant le swing trading à haute fréquence (250-570 transactions/mois observées) principalement sur des titres tech/IA (MSFT, META, GOOG, AMZN, AMD, ADBE, PYPL, RDDT, JD, SMCI, ASML, CRWV). Stratégie de tendance existante : alignement SMA 9/21/100 comme filtre d'entrée, sortie sur clôture sous SMA21. *(Révisé le 29/8/2026 — était SMMA/RMA lissée jusque-là ; JP a demandé de standardiser sur la moyenne mobile SIMPLE après avoir relevé une incohérence de terminologie SMMA/MM dans les capsules d'aide de l'app.)*

**Problème observé** : difficulté de timing au screening ("trop tôt ou en retard"), pas de mécanisme systématique de sizing/stop-loss, pas de suivi de la valeur ajoutée réelle des indicateurs utilisés, saisie manuelle de données de marché.

**Contrainte importante à respecter dans toute logique de compte** : le swing trading actif doit être traité différemment selon le compte — le REER ne permet aucune déduction de perte en capital (contrairement au non-enregistré), donc l'outil doit toujours savoir dans quel compte un trade est logé.

## 2. Objectif du projet

Construire un système d'aide à la décision pour le swing trading, en trois briques :
1. **Écran de sélection de titres** — décide quels titres suivre activement
2. **Fiche de trade** — calcule sizing, stop, cible à chaque entrée
3. **Automatisation & suivi** — branche les données de marché en direct et mesure après coup si chaque indicateur a réellement aidé

Ce projet est distinct du projet séparé "La Roue" (simulateur Wheel options) — garder les deux contextes séparés.

## 3. Prototypes existants (point de départ pour Claude Code)

Deux fichiers HTML autonomes ont déjà été construits et validés fonctionnellement — Claude Code devrait les utiliser comme référence de logique métier plutôt que de repartir de zéro :

- `fiche_trade_sizing_stop.html` — calculateur de sizing/stop par trade
- `ecran_selection_titres.html` — écran de sélection de titres (version single-ticker, à faire évoluer en tableau multi-titres, voir section 5)

## 4. Logique métier à préserver (déjà validée avec JP)

### 4.1 Filtre de tendance
- SMA (Simple Moving Average, fenêtre glissante — **pas** une SMMA/RMA lissée, voir note du 29/8/2026 ci-dessus) sur 3 périodes, **paramétrables** (défaut : 9/21/**50** — ne pas remplacer par EMA 50/100/200)

> **Révisé le 7/9/2026 (feature 351).** La moyenne lente passe de **100 à 50**,
> à la demande explicite de JP. Les trois périodes et celle du RSI sont
> désormais **réellement modifiables dans l'app** (Réglages → Valeur
> personnalisée) et pilotent le calcul serveur sur tous les écrans — la
> source de vérité est `server/preferences.js` (`DEFAULTS`), plus ce
> document ni `config.js`.
>
> ⚠️ **Le Pine Script ci-dessous n'a PAS été modifié** : il calcule toujours
> `sma100`. C'est délibéré — l'alerte réellement configurée sur TradingView
> ne peut être changée que par JP, à la main, et réécrire le script ici sans
> qu'il le reporte créerait un écart silencieux entre l'app et l'alerte.
> À aligner sur 50 (ou à laisser à 100 en connaissance de cause).
- Signal haussier : close > SMA9 > SMA21 > SMA100, déclenché une seule fois au premier alignement (pas à chaque barre où l'état est vrai)
- Sortie : clôture sous SMA21

### 4.2 Alerte TradingView (Pine Script v5 déjà fourni à JP)
```pinescript
//@version=5
indicator("Alerte SMA 9/21/100 + Volume", overlay=true)
sma9   = ta.sma(close, 9)
sma21  = ta.sma(close, 21)
sma100 = ta.sma(close, 100)
volMA20   = ta.sma(volume, 20)
volFiltre = volume > volMA20
alignementHaussier   = close > sma9 and sma9 > sma21 and sma21 > sma100
premierAlignement    = alignementHaussier and not alignementHaussier[1]
signalEntree          = premierAlignement and volFiltre
signalSortie           = ta.crossunder(close, sma21)
alertcondition(signalEntree, title="Entrée - Alignement confirmé", message="{{ticker}} : alignement SMA9/21/100 confirmé avec volume, clôture {{close}}")
alertcondition(signalSortie, title="Sortie - Sous SMA21", message="{{ticker}} : clôture sous SMA21, réviser la position")
```
Réglage critique côté TradingView : déclencheur = "Une fois par clôture de bougie" (élimine le bruit intrabar). *(Pine Script mis à jour le 29/8/2026 — `ta.rma()` → `ta.sma()` ; JP doit reproduire ce changement dans l'alerte réellement configurée sur TradingView, cet outil ne la modifie pas à distance.)*

### 4.3 Checklist pré-trade (gate obligatoire, 6 items)
1. Setup confirmé (SMA aligné)
2. Bougie de confirmation clôturée
3. Volume au-dessus de la moyenne 20 jours
4. Climat de marché (VIX) vérifié
5. RSI en zone d'entrée + OBV sans divergence baissière
6. Engagement à placer le stop immédiatement à l'entrée

### 4.4 Indicateurs retenus et bandes de couleur (décidées avec JP, ne pas réinventer)

| Indicateur | Vert | Amber | Rouge |
|---|---|---|---|
| VIX | 15-20 (normal) | <15 (complaisance) ou 20-30 (nervosité) | ≥30 (panique) |
| RSI(14) | 40-70 (zone d'entrée) | 30-40 (pullback profond) ou <30 (survente) | >70 (surachat) |
| OBV | Accumulation | Neutre | Distribution (divergence) |
| Force relative vs indice | écart >+5 pts | écart entre -5 et +5 | écart <-5 pts |
| Golden Cross (écart SMA50 vs SMA200) | >+1% (confirmé) | 0 à +1% (naissant) | ≤0% (absent) |

**Redondance à éviter** : ne pas ajouter MACD ni Stochastic RSI — décision déjà prise avec JP (RSI seul retenu comme momentum, pour éviter la duplication avec le système de croisement SMA déjà en place).

### 4.5 Sizing (le cœur de la fiche de trade)
- Distance du stop = ATR(14) × multiplicateur (1.0–3.0x, défaut 1.5x, ajustable par titre selon liquidité)
- Prix du stop = Prix d'entrée − distance du stop
- Risque de base = % du capital alloué au trading (défaut 1%, slider 0.25–3%)
- **Discounts multiplicatifs appliqués au risque de base** (cumulatifs) :
  - × 0.7 si la position est corrélée aux positions déjà ouvertes (même thème dominant, ex. tech/IA)
  - × 0.5 si VIX ≥ 30, × 0.75 si VIX ≥ 20
  - × 0.8 si RSI > 70
  - × 0.7 si OBV = distribution
- Taille de position (actions) = (capital × risque effectif%) ÷ distance du stop
- **Charge de portefeuille agrégée** : risque déjà engagé (autres positions ouvertes, saisi manuellement pour l'instant) + risque de ce trade → alerte si total > 6%

### 4.6 Type d'ordre recommandé selon liquidité
| Liquidité | Entrée | Sortie |
|---|---|---|
| Liquide (MSFT, GOOG, AMZN) | Stop d'achat au-dessus de la bougie de confirmation | Stop-market au prix du stop |
| Mi-liquide (AMD, RDDT, JD) | Stop d'achat | Stop-limit, marge de 15% de la distance du stop |
| Mince/volatil (SMCI, CRWV, ASML) | Ordre limite au retest — jamais de stop d'achat au marché | Stop-limit obligatoire, marge de 30% |

### 4.7 Objectifs — comparaison R vs Fibonacci
- R-multiples : 1R/2R/3R = Prix d'entrée + (distance du stop × multiple)
- Extension Fibonacci (depuis bas/haut du dernier swing) : 127.2%, 161.8%, 261.8% au-delà du haut du swing
- Afficher les deux côte à côte avec le R-équivalent de chaque niveau Fibonacci, pour que l'utilisateur voie si sa cible R est trop conservatrice ou trop ambitieuse par rapport à la structure du marché

## 5. Évolution demandée : tableau de sélection multi-titres

Remplacer/étendre l'écran de sélection single-ticker par :
- Import en bloc (coller une liste CSV : ticker, prix, RSI, écart force relative, écart golden cross, état OBV)
- Tableau trié par score composite décroissant (score = somme des indicateurs verts/ambres/rouges sur 4 colonnes : RSI, Force relative, Golden Cross, OBV)
- Affichage plafonné aux 20 meilleurs titres
- Cellules colorées selon les bandes de la section 4.4
- Verdict par ligne : ajouter à la liste active / à surveiller / ne pas ajouter

## 6. Intégration Alpha Vantage MCP — état actuel des tests

- Connecteur installé et connecté côté JP
- **GLOBAL_QUOTE : fonctionne**, confirmé avec un appel réel sur AMD (retour correct : prix, volume, variation)
- **RSI : a échoué** avec l'erreur `No approval received.` — cause non confirmée, à investiguer côté Claude Code (possible flux d'approbation manquant pour les outils d'indicateurs calculés vs les cotations brutes)
- **Contrainte de palier gratuit à respecter dans l'architecture** : 25 requêtes/jour, 5/minute, données décalées de 15 minutes. Un rafraîchissement complet du tableau de 20 titres (RSI + Force relative + Golden Cross + OBV, chacun potentiellement plusieurs appels) dépasse largement ce quota en une seule passe.
- **Recommandation d'architecture** : soit limiter le rafraîchissement automatique à un sous-ensemble prioritaire de titres par jour (rotation), soit budgéter le palier payant (49,99 $/mois, 75 requêtes/minute, sans plafond quotidien) si l'usage réel le justifie.
- Prévoir une couche de cache/persistance (éviter de re-interroger l'API pour une donnée déjà récupérée dans la même journée)

## 7. Suivi post-trade automatisé (à construire)

**Schéma de données minimal pour le journal de trades** :
```
trade_id, date_entree, date_sortie, compte (RRSP/margin/corporatif), ticker,
prix_entree, prix_sortie, taille_position, stop_initial,
vix_a_entree, rsi_a_entree, obv_a_entree, correlation_flag,
checklist_complete (bool), R_realise, resultat (gagnant/perdant)
```

**Objectif analytique** : déterminer, après coup, si chaque indicateur (VIX, RSI, OBV, corrélation) a une vraie valeur prédictive dans les trades de JP — ex. requête type "quel est le taux de réussite des trades pris avec VIX > 20 vs VIX < 20 ?"

**Source de données** : peut se brancher sur l'export d'activités déjà utilisé dans les analyses de portefeuille (format connu : transaction_date, account_type, symbol, activity_sub_type, quantity, net_cash_amount, etc.) plutôt que de redemander à JP de ressaisir ses trades.

## 8. Hors scope pour cette phase

- Exécution automatique de trades (pas d'ordres envoyés automatiquement au courtier)
- Intégration avec la stratégie "La Roue" (projet séparé)
- Rebalancement du portefeuille long terme (couvert par les outils d'analyse de portefeuille existants, hors de ce projet)

## 9. Feuille de route suggérée

1. **Phase 1** — Consolider les deux prototypes HTML existants en une seule application (React/PWA cohérente avec le reste du travail de JP), résoudre le blocage RSI sur Alpha Vantage
2. **Phase 2** — Automatiser le remplissage du tableau de sélection (avec gestion du quota API), ajouter le cache/persistance
3. **Phase 3** — Construire le journal de trades automatisé et les requêtes analytiques post-trade; explorer le webhook TradingView pour rapprocher l'alerte du signal réel
