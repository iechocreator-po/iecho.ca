// js/options-common.js — helpers partagés des onglets Options, Screener Prime
// (journal-a-tab.js) et Radar (deal-scanner-tab.js).
// Extraits de l'ancien js/options-tab.js (onglet « Options » de base, supprimé le
// 29/9/2026 : redondant avec Options A). Règle d'honnêteté : une valeur absente
// s'affiche « — », jamais 0. OPT_MIN_IV/optionDelta/optionMarketZone vivent dans
// js/options-analytics.js, chargé avant ce fichier.

function optionsRiskFree() {
  const p = typeof laboEffectiveParams === 'function' ? laboEffectiveParams('roue', (typeof laboParamOverrides !== 'undefined' ? laboParamOverrides.roue : {})) : null;
  return (p ? p.riskFreePct : 4) / 100;
}

// Ajoute `delta` à chaque contrat de la chaîne (une seule fois, au chargement).
function optionsAttachDeltas(ch) {
  const r = optionsRiskFree();
  ch.calls.forEach((c) => { c.delta = optionDelta('call', ch.price, c.strike, ch.dte, r, c.iv); });
  ch.puts.forEach((c) => { c.delta = optionDelta('put', ch.price, c.strike, ch.dte, r, c.iv); });
}

// Bouton (i) d'aide d'un en-tête de colonne — ouvre l'entrée du glossaire (js/glossaire-indicateurs.js).
const optInfoBtn = (key) => ` <button type="button" class="info-btn" onclick="showGlossaire('${key}', this)" title="Aide">i</button>`;

const optEsc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const optNum = (v, d = 2) => (v == null ? '—' : Number(v).toFixed(d));
const optInt = (v) => (v == null ? '—' : Number(v).toLocaleString('fr-CA'));
const optDelta = (v) => (v == null ? '—' : (v >= 0 ? '+' : '') + v.toFixed(2));
const optPct = (v) => (v == null ? '—' : (v * 100).toFixed(0) + ' %');

function optionsActiveFilterCount(f) {
  return [f.rangePct, f.minOI, f.minVolume].filter((v) => v != null).length + (f.quotedOnly ? 1 : 0);
}

// Pure : bornes de strike de la plage ±%. Sans plage (ou sans prix exploitable) : aucune borne.
function optionsStrikeBounds(price, rangePct) {
  if (rangePct == null || !(price > 0)) return { lo: -Infinity, hi: Infinity };
  return { lo: price * (1 - rangePct / 100), hi: price * (1 + rangePct / 100) };
}

// Pure (testable) : un contrat passe-t-il les filtres de liquidité ?
function optionPassesFilters(c, f) {
  if (!c) return false;
  if (f.quotedOnly && (c.bid == null || c.ask == null)) return false;
  if (f.minOI != null && !(c.openInterest >= f.minOI)) return false;
  if (f.minVolume != null && !(c.volume >= f.minVolume)) return false;
  return true;
}

// Pure : chaîne + filtres → une ligne par contrat AFFICHÉ (mêmes filtres que le tableau),
// puis CSV (virgule, point décimal — comme les autres exports de castellana).
// Une valeur absente reste VIDE dans le CSV : jamais 0.
const OPT_CSV_COLS = ['type', 'echeance', 'dte', 'strike', 'bid', 'ask', 'dernier', 'volume', 'open_interest', 'iv', 'delta_estime', 'dans_la_monnaie', 'symbole_contrat'];

// Arrondi à 4 décimales pour l'export (l'IV et le delta sortent de calculs flottants).
const optRound = (v) => (v == null ? null : Math.round(v * 10000) / 10000);

function optionsCsvRows(ch, f) {
  const { lo, hi } = optionsStrikeBounds(ch.price, f.rangePct);
  const out = [];
  for (const [type, list] of [['call', ch.calls], ['put', ch.puts]]) {
    for (const c of list) {
      if (c.strike < lo || c.strike > hi || !optionPassesFilters(c, f)) continue;
      out.push([type, ch.expiry, ch.dte, c.strike, c.bid, c.ask, c.last, c.volume, c.openInterest, optRound(c.iv), optRound(c.delta), c.itm ? 'oui' : 'non', c.contractSymbol]);
    }
  }
  return out;
}

function optionsToCSV(ch, f) {
  const cell = (v) => {
    if (v == null) return '';
    const t = String(v);
    return /[",\n]/.test(t) ? `"${t.replace(/"/g, '""')}"` : t;
  };
  const lines = [OPT_CSV_COLS, ...optionsCsvRows(ch, f)].map((r) => r.map(cell).join(','));
  return lines.join('\n') + '\n';
}
