// Étiquette de la tendance de l'OBV (audit donnees-marche, 20/10/2026, constat 1) : la direction du PRIX compte.
// Avant, « même signe = accumulation » : un prix qui baisse avec un OBV qui baisse sortait « accumulation » (+1 au score de
// contexte), et un prix qui baisse avec un OBV qui monte sortait « distribution » (-1 et taille réduite).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { obvTrendFrom } from './obv-trend.js';
import { classifyOBV, computeOBV } from './indicators.js';
import { classifyOBV as classifyOBVCloud } from '../cloud/src/lib/indicators.js';
import { featuresAt } from './dataset.js';
import { scoreRow } from './scoring.js';

test('obvTrendFrom : les quatre quadrants prix x OBV', () => {
  assert.equal(obvTrendFrom(+5, +100), 'accumulation', 'le prix monte, l\'OBV monte : le volume soutient la hausse');
  assert.equal(obvTrendFrom(+5, -100), 'distribution', 'le prix monte, l\'OBV baisse : divergence baissière');
  assert.equal(obvTrendFrom(-5, -100), 'neutre', 'le prix baisse, l\'OBV baisse : avant, « accumulation » à tort');
  assert.equal(obvTrendFrom(-5, +100), 'neutre', 'le prix baisse, l\'OBV monte : avant, « distribution » à tort');
});

test('obvTrendFrom : variation nulle, absente ou illisible -> neutre, jamais une étiquette inventée', () => {
  assert.equal(obvTrendFrom(0, 100), 'neutre');
  assert.equal(obvTrendFrom(5, 0), 'neutre');
  assert.equal(obvTrendFrom(1e-12, 100), 'neutre');
  assert.equal(obvTrendFrom(NaN, 100), 'neutre');
  assert.equal(obvTrendFrom(5, undefined), 'neutre');
  assert.equal(obvTrendFrom(null, null), 'neutre');
});

// 20 séances de mise en place, puis 10 séances où le prix et les volumes sont choisis pour fixer le signe de chaque variation.
function barres(prixMonte, obvMonte) {
  const bars = [];
  let c = 100;
  for (let i = 0; i < 30; i++) {
    if (i < 20) { c += i % 2 ? -0.5 : 0.5; bars.push({ close: c, volume: 1_000_000 }); continue; }
    const jourHausse = (i - 20) % 2 === 0;
    c += jourHausse ? (prixMonte ? 2 : 0.5) : (prixMonte ? -0.5 : -2);
    bars.push({ close: c, volume: (jourHausse ? obvMonte : !obvMonte) ? 3_000_000 : 1_000_000 });
  }
  return bars;
}
const etiquette = (fn, bars) => fn(computeOBV(bars), bars.map((b) => b.close));

test('classifyOBV sur de vraies barres : serveur ET cloud donnent les mêmes étiquettes', () => {
  const cas = [[true, true, 'accumulation'], [true, false, 'distribution'], [false, false, 'neutre'], [false, true, 'neutre']];
  for (const [prixMonte, obvMonte, attendu] of cas) {
    const bars = barres(prixMonte, obvMonte);
    const obv = computeOBV(bars); const n = bars.length;
    assert.equal(obv[n - 1] - obv[n - 11] > 0, obvMonte, 'préparation : le signe de l\'OBV est bien celui voulu');
    assert.equal(bars[n - 1].close - bars[n - 11].close > 0, prixMonte, 'préparation : le signe du prix est bien celui voulu');
    assert.equal(etiquette(classifyOBV, bars), attendu, `prix ${prixMonte ? 'monte' : 'baisse'} / OBV ${obvMonte ? 'monte' : 'baisse'}`);
    assert.equal(etiquette(classifyOBVCloud, bars), attendu, 'version cloud');
  }
});

test('classifyOBV : historique trop court -> neutre', () => {
  const bars = barres(true, true).slice(0, 8);
  assert.equal(etiquette(classifyOBV, bars), 'neutre');
});

test('le jeu de données du backtest (dataset.js) utilise la même définition', () => {
  for (const [prixMonte, obvMonte, attendu] of [[true, true, 'accumulation'], [true, false, 'distribution'], [false, false, 'neutre'], [false, true, 'neutre']]) {
    const bars = barres(prixMonte, obvMonte).map((b, i) => ({ ...b, date: new Date(Date.UTC(2026, 0, 1 + i)), open: b.close, high: b.close + 1, low: b.close - 1 }));
    assert.equal(featuresAt(bars, bars.length - 1).obv_trend, attendu, `dataset : prix ${prixMonte ? 'monte' : 'baisse'} / OBV ${obvMonte ? 'monte' : 'baisse'}`);
  }
});

test('effet sur le verdict : un repli accompagné d\'un OBV qui baisse ne rapporte plus de point de contexte', () => {
  const ligne = (obvTrend) => ({ smaAlignment: 'haussier', alignmentAge: 3, rsi: 55, aboveVwap: true, goldenCross: false, forceRelative: 6, obvTrend });
  // Avant le correctif, prix et OBV qui baissent donnaient « accumulation » : contexte 1, verdict « prêt ».
  const apres = scoreRow(ligne(etiquette(classifyOBV, barres(false, false))));
  assert.equal(apres.contexteScore, 0);
  assert.equal(apres.verdict, 'à surveiller');
  const vraie = scoreRow(ligne(etiquette(classifyOBV, barres(true, true))));
  assert.equal(vraie.contexteScore, 1, 'une vraie accumulation compte toujours +1');
  assert.equal(vraie.verdict, 'prêt');
});

test('la source de l\'étiquette est unique : ni indicators.js (serveur ou cloud) ni dataset.js ne la recopient', () => {
  for (const f of ['./indicators.js', '../cloud/src/lib/indicators.js', './dataset.js']) {
    const src = readFileSync(new URL(f, import.meta.url), 'utf8');
    assert.match(src, /from '\.\/obv-trend\.js'/, `${f} doit importer obv-trend.js`);
    assert.doesNotMatch(src, /\(priceChange > 0\) === \(obvChange > 0\)|Math\.sign\(dObv\) === Math\.sign\(dPx\)/, `${f} recopie l'ancienne comparaison de signes`);
  }
});
