// Isolation entre comptes et écritures atomiques de la couche D1 (audit routes, 21/10/2026).
// Aucun test ne vérifiait qu'un compte ne peut pas lire, modifier ou supprimer les lignes d'un autre : un oubli de `AND user_id = ?`
// dans une future requête n'aurait été attrapé par rien. On fait tourner les VRAIES fonctions contre le VRAI schéma SQL dans une
// base SQLite en mémoire habillée en D1 (voir le commentaire de server/account-revocation.test.js).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import Database from 'better-sqlite3';
import { createTrade, getTrade, updateTrade, deleteTrade, listTrades } from '../cloud/src/db/trades.js';
import { createCycle, getCycle, updateCycle, createOptionTrade, getOptionTrade, listOptionTrades, closeOptionTrade, deleteOptionTrade, deleteRoueEntries } from '../cloud/src/db/option-trades.js';
import { createCashFlow, listCashFlows, deleteCashFlow } from '../cloud/src/db/cash-flows.js';
import { createList, getListById, renameList, deleteList, addTickerToList, getLists } from '../cloud/src/db/lists.js';
import { getWatchlist, removeFromWatchlist, addToWatchlist, seedWatchlistFor } from '../cloud/src/db/watchlist.js';
import { getPreferences, setPreferences } from '../cloud/src/db/preferences.js';
import { createMagicLink, consumeMagicLink } from '../cloud/src/db/magic-links.js';

function d1(raw, { echouerSur = null } = {}) {
  return {
    prepare(sql) {
      if (echouerSur && echouerSur.test(sql)) throw new Error('panne simulée');
      const make = (args) => ({
        async first() { return raw.prepare(sql).get(...args) ?? null; },
        async all() { return { results: raw.prepare(sql).all(...args) }; },
        async run() { const r = raw.prepare(sql).run(...args); return { meta: { changes: r.changes, last_row_id: Number(r.lastInsertRowid) } }; },
      });
      return { ...make([]), bind: (...args) => make(args) };
    },
    async batch(stmts) { return Promise.all(stmts.map((s) => s.run())); },
  };
}
function fresh() {
  const raw = new Database(':memory:');
  raw.pragma('foreign_keys = ON');
  raw.exec(readFileSync(new URL('../cloud/schema.sql', import.meta.url), 'utf8'));
  const add = (name) => Number(raw.prepare("INSERT INTO users (username, password_hash, password_salt, email) VALUES (?, 'h', 's', ?)").run(name, `${name}@example.test`).lastInsertRowid);
  return { raw, db: d1(raw), add, A: add('alice'), B: add('bob') };
}
const trade = { date_entree: '2026-10-01', compte: 'margin', ticker: 'AMD', prix_entree: 100, taille_position: 10, stop_initial: 95 };
const jambe = (over = {}) => ({ type: 'put', ticker: 'AMD', compte: 'margin', strike: 50, echeance: '2026-11-20', prime_recue: 1, date_ouverture: '2026-10-01', ...over });

test('trades : un compte ne voit, ne modifie et ne supprime pas le trade d\'un autre', async () => {
  const { db, A, B } = fresh();
  const t = await createTrade(db, A, trade);
  assert.equal(await getTrade(db, B, t.id), null, 'lecture par id');
  assert.deepEqual(await listTrades(db, B), [], 'liste');
  await updateTrade(db, B, t.id, { stop_initial: 1 }).catch(() => {});
  assert.equal((await getTrade(db, A, t.id)).stop_initial, 95, 'modification refusée');
  await deleteTrade(db, B, t.id).catch(() => {});
  assert.ok(await getTrade(db, A, t.id), 'suppression refusée');
});

test('options et cycles : isolation, et un cycle d\'un autre compte n\'est pas un lien valide', async () => {
  const { db, A, B } = fresh();
  const cycle = await createCycle(db, A, { ticker: 'AMD', compte: 'margin' });
  const leg = await createOptionTrade(db, A, jambe({ cycle_id: cycle.id }));
  assert.equal(await getCycle(db, B, cycle.id), null);
  assert.equal(await getOptionTrade(db, B, leg.id), undefined ?? null);
  assert.deepEqual(await listOptionTrades(db, B), []);
  await updateCycle(db, B, cycle.id, { statut: 'ferme' }).catch(() => {});
  assert.notEqual((await getCycle(db, A, cycle.id)).statut, 'ferme', 'modification du cycle refusée');
  await assert.rejects(() => closeOptionTrade(db, B, leg.id, { statut: 'expire', dateCloture: '2026-11-20' }), /introuvable/i);
  await deleteOptionTrade(db, B, leg.id).catch(() => {});
  await deleteRoueEntries(db, B, { legIds: [leg.id] }).catch(() => {});
  assert.equal((await getOptionTrade(db, A, leg.id)).statut, 'ouvert', 'la jambe d\'Alice est intacte');
  await assert.rejects(() => createOptionTrade(db, B, jambe({ cycle_id: cycle.id })), /Cycle introuvable/, 'Bob ne rattache pas une jambe au cycle d\'Alice');
});

test('flux de trésorerie, listes, watchlist, préférences : isolation entre comptes', async () => {
  const { db, A, B } = fresh();
  const cf = await createCashFlow(db, A, { compte: 'margin', date: '2026-10-01', type: 'depot', montant: 100 });
  assert.deepEqual(await listCashFlows(db, B), []);
  assert.equal(await deleteCashFlow(db, B, cf.id), false);
  assert.equal((await listCashFlows(db, A)).length, 1);

  const liste = await createList(db, A, 'Ma liste');
  assert.equal(await getListById(db, B, liste.id), null);
  assert.equal(await renameList(db, B, liste.id, 'Pirate').catch(() => null), null);
  await addTickerToList(db, B, liste.id, 'AMD').catch(() => {});
  await deleteList(db, B, liste.id).catch(() => {});
  assert.equal((await getListById(db, A, liste.id)).nom, 'Ma liste');
  assert.equal((await getLists(db, B)).filter((l) => l.id === liste.id).length, 0);

  await addToWatchlist(db, A, 'ZZZZ');
  assert.ok(!(await getWatchlist(db, B)).some((w) => w.ticker === 'ZZZZ'), 'la watchlist de Bob ne contient pas le titre d\'Alice');
  assert.equal(await removeFromWatchlist(db, B, 'ZZZZ'), false);
  assert.ok((await getWatchlist(db, A)).some((w) => w.ticker === 'ZZZZ'));

  await setPreferences(db, A, { smaFast: 12 });
  assert.notEqual((await getPreferences(db, B)).smaFast, 12, 'les préférences d\'Alice ne passent pas chez Bob');
});

test('clôture d\'une jambe : une seule fois, même si deux requêtes arrivent ensemble', async () => {
  const { raw, db, A } = fresh();
  const leg = await createOptionTrade(db, A, jambe());
  const corps = { statut: 'assigne', dateCloture: '2026-11-20', primeCloture: 0, stopInitial: 45 };
  const res = await Promise.allSettled([closeOptionTrade(db, A, leg.id, corps), closeOptionTrade(db, A, leg.id, corps)]);
  assert.equal(res.filter((r) => r.status === 'fulfilled').length, 1, 'une seule clôture réussit');
  assert.equal(raw.prepare('SELECT COUNT(*) n FROM trades WHERE user_id = ?').get(A).n, 1, 'UNE seule action créée (avant : deux)');
});

test('clôture d\'une jambe : si la position liée échoue, la jambe redevient ouverte', async () => {
  const { raw, add, A } = fresh();
  const db = d1(raw, { echouerSur: /INSERT INTO trades/ });
  const leg = await createOptionTrade(db, A, jambe());
  await assert.rejects(() => closeOptionTrade(db, A, leg.id, { statut: 'assigne', dateCloture: '2026-11-20', primeCloture: 0, stopInitial: 45 }), /panne simulée/);
  const apres = raw.prepare('SELECT statut, date_cloture, prime_cloture FROM option_trades WHERE id = ?').get(leg.id);
  assert.deepEqual({ ...apres }, { statut: 'ouvert', date_cloture: null, prime_cloture: null }, 'pas de jambe « assignée » sans position');
});

test('clôture : un rachat sans prime est refusé (null valait 0 $)', async () => {
  const { db, A } = fresh();
  const leg = await createOptionTrade(db, A, jambe());
  await assert.rejects(() => closeOptionTrade(db, A, leg.id, { statut: 'rachete', dateCloture: '2026-10-15', primeCloture: null }), /primeCloture/);
  await assert.rejects(() => closeOptionTrade(db, A, leg.id, { statut: 'rachete', dateCloture: '2026-10-15', primeCloture: '' }), /primeCloture/);
  const ok = await closeOptionTrade(db, A, leg.id, { statut: 'rachete', dateCloture: '2026-10-15', primeCloture: 0 });
  assert.equal(ok.optionTrade.statut, 'rachete', '0 reste une prime réelle');
});

test('lien de connexion par courriel : consommable une seule fois', async () => {
  const { db, A } = fresh();
  await createMagicLink(db, A, 'jeton-1');
  const [x, y] = await Promise.all([consumeMagicLink(db, 'jeton-1'), consumeMagicLink(db, 'jeton-1')]);
  assert.deepEqual([x, y].sort(), [false, true], 'un seul des deux appels obtient le lien');
  assert.equal(await consumeMagicLink(db, 'jeton-1'), false);
  assert.equal(await consumeMagicLink(db, 'inconnu'), false);
});

test('watchlist : semée une fois, jamais re-semée après suppression, deux premiers chargements sans erreur', async () => {
  const { db, A, add } = fresh();
  const neuf = add('carol');
  const [l1, l2] = await Promise.all([getWatchlist(db, neuf), getWatchlist(db, neuf)]);
  assert.ok(l1.length > 15 && l2.length > 15, 'semée');
  for (const w of await getWatchlist(db, neuf)) await removeFromWatchlist(db, neuf, w.ticker);
  assert.deepEqual(await getWatchlist(db, neuf), [], 'vidée par l\'utilisateur : elle le reste (avant : les 21 revenaient)');
  await seedWatchlistFor(db, A);
  await seedWatchlistFor(db, A); // idempotent
});

// Audit routes locales (21/10/2026)
test('cycle : modifier un cycle inexistant (ou d\'un autre compte) est un 404, et statut null est refusé', async () => {
  const { db, A, B } = fresh();
  const cycle = await createCycle(db, A, { ticker: 'AMD', compte: 'margin' });
  await assert.rejects(() => updateCycle(db, A, 9999, { notes: 'x' }), (e) => e.status === 404);
  await assert.rejects(() => updateCycle(db, B, cycle.id, { notes: 'x' }), (e) => e.status === 404, 'le cycle d\'Alice n\'est pas à Bob');
  await assert.rejects(() => updateCycle(db, A, cycle.id, { statut: null }), /statut de cycle invalide/);
  assert.equal((await updateCycle(db, A, cycle.id, { statut: 'clos' })).statut, 'clos');
});

test('supprimer une jambe détache celles qui roulaient vers elle (pas de lien pendant)', async () => {
  const { raw, db, A } = fresh();
  const vieille = await createOptionTrade(db, A, jambe());
  const nouvelle = await createOptionTrade(db, A, jambe({ echeance: '2026-12-18' }));
  await closeOptionTrade(db, A, vieille.id, { statut: 'roule', dateCloture: '2026-10-15', primeCloture: 0.5, rouleVersId: nouvelle.id });
  assert.equal(raw.prepare('SELECT roule_vers_id r FROM option_trades WHERE id = ?').get(vieille.id).r, nouvelle.id);
  assert.equal(await deleteOptionTrade(db, A, nouvelle.id), true);
  assert.equal(raw.prepare('SELECT roule_vers_id r FROM option_trades WHERE id = ?').get(vieille.id).r, null, 'le lien vers la jambe supprimée est retiré');
});
