// Lance le sidecar Python tradingview-mcp — remplace l'ancien script npm
// `./.venv-mcp/bin/tradingview-mcp ...` qui codait en dur un chemin
// Unix/macOS (venv/bin/) et échouait silencieusement sur Windows (venv
// Scripts\ + .exe). Zéro dépendance ajoutée : node:child_process natif.
import { spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { join } from 'node:path';

const isWindows = process.platform === 'win32';
const venvDir = '.venv-mcp';
const binDir = isWindows ? 'Scripts' : 'bin';
const exeName = isWindows ? 'tradingview-mcp.exe' : 'tradingview-mcp';
const exePath = join(venvDir, binDir, exeName);

if (!existsSync(exePath)) {
  console.error(`\nSidecar introuvable : ${exePath}\n`);
  console.error("L'environnement virtuel Python n'existe pas encore (ou a été supprimé). Pour le créer :\n");
  if (isWindows) {
    console.error('    python -m venv .venv-mcp');
    console.error('    .venv-mcp\\Scripts\\activate');
    console.error('    pip install tradingview-mcp-server');
  } else {
    console.error('    python3 -m venv .venv-mcp');
    console.error('    source .venv-mcp/bin/activate');
    console.error('    pip install tradingview-mcp-server');
  }
  console.error('\nPuis relance : npm run sidecar\n');
  process.exit(1);
}

const result = spawnSync(exePath, ['streamable-http', '--host', '127.0.0.1', '--port', '4701'], {
  stdio: 'inherit',
});
process.exit(result.status ?? 1);
