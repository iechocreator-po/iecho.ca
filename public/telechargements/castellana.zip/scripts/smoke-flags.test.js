// Onglets DERRIÈRE UN DRAPEAU, avec des données — dont des données PIÉGÉES (audit onglets, 20/10/2026, constat 1).
// Le test de fumée habituel ne voit que les onglets visibles avec une API vide : la Roue, Journal A, le Radar et
// Anticipation y restent cachés, et la faille de l'onglet Roue (un symbole importé s'exécutait comme du code) y était invisible.
// Ici tous les drapeaux sont vrais, l'API renvoie des données d'exemple dont le symbole, le secteur, les notes et le titre d'une
// carte sont des charges d'injection. Le test exige : aucune exception, aucun code exécuté, aucun élément créé par une donnée,
// et les textes piégés affichés tels quels (échappés).
import test from 'node:test';
import assert from 'node:assert/strict';
import { findChrome, withPage, PAGES } from './smoke-browser.mjs';

const chromePath = findChrome();
const skip = chromePath ? false : 'Chrome introuvable (définir CHROME_PATH) : test ignoré, ce n\'est pas un succès';

// Charge en MAJUSCULES et en entités numériques (ce que l'application stockait après .toUpperCase()) : elle exécute window.__xss = 1.
const entites = (s) => [...s].map((c) => `&#${c.charCodeAt(0)};`).join('');
const PIEGE = `<IMG SRC=X ONERROR=${entites('window.__xss=1')}>`;
const PIEGE_TITRE = `<img src=x onerror="window.__xss=1">Titre`;

const iso = (ms) => new Date(ms).toISOString().slice(0, 10);
const jour = 86400000;
function semaine() { // dimanche de la semaine courante (UTC), comme roueWeekOf()
  const now = Date.now();
  const dimanche = now - new Date(now).getUTCDay() * jour;
  return { dimanche, echeanceSuivante: iso(dimanche + 12 * jour), ouverture: iso(dimanche - 2 * jour), aujourdhui: iso(now) };
}

const DRAPEAUX = ['journal_a_tab', 'roue_tab', 'radar_tab', 'fundamentals_card', 'ai_analyst', 'concepts_tab', 'options_a_tab', 'anticipation_tab', 'tradingview_connect', 'sp500_sweep'];

function stubDonnees(appels) {
  const w = semaine();
  return (method, path, q) => {
    appels.push(`${method} ${path}`);
    if (path === '/api/flags') return { body: { flags: Object.fromEntries(DRAPEAUX.map((k) => [k, true])) } };
    if (path === '/api/option-cycles') return { body: { cycles: [{ id: 1, ticker: PIEGE, compte: 'margin', statut: 'ouvert' }] } };
    if (path === '/api/option-cycles/bilans') return { body: { bilans: [] } };
    if (path === '/api/option-trades') {
      return { body: { trades: [{ id: 1, cycle_id: 1, type: 'put', ticker: PIEGE, compte: 'margin', strike: 50, contrats: 1, prime_recue: 1, statut: 'ouvert',
        echeance: w.echeanceSuivante, date_ouverture: w.ouverture, commission_ouverture: 0 }] } };
    }
    if (path === '/api/trades') {
      return { body: { trades: [{ id: 1, option_cycle_id: 1, ticker: PIEGE, compte: 'margin', date_entree: w.ouverture, prix_entree: 50, taille_position: 100, stop_initial: 45 }] } };
    }
    if (path === '/api/cash-flows') {
      return { body: { cashFlows: [{ id: 1, compte: 'margin', date: w.aujourdhui, type: 'dividende', montant: 5, ticker: PIEGE, cycle_id: 1, notes: PIEGE }] } };
    }
    if (path.startsWith('/api/quote/')) return { body: { price: 42, changePercent: 1 } };
    if (path === '/api/ticker-sectors') return { body: { sectors: { [PIEGE]: PIEGE }, earnings: { [PIEGE]: 3 } } };
    if (path === '/api/anticipation') {
      return { body: { remaining: 5, maxVotes: 5, cards: [{ id: 'carte-1', titre: PIEGE_TITRE, description: PIEGE_TITRE, statut: 'maquette', onglet: PIEGE_TITRE, date: '2026-10-01', votes: 1, voted: false }] } };
    }
    if (path === '/api/anticipation/proposals') return { body: { proposals: [{ titre: PIEGE_TITRE, statut: PIEGE_TITRE }] } };
    if (path === '/api/anticipation/carte-1/vote' && method === 'PUT') return { body: { remaining: 4, maxVotes: 5, cards: [{ id: 'carte-1', titre: 'ok', description: 'ok', statut: 'maquette', onglet: 'Roue', date: '2026-10-01', votes: 2, voted: true }] } };
    return undefined; // le reste : bouchon 503 habituel
  };
}

const scenarioOnglets = (cloud) => async ({ ev, errors, sleep }) => {
  await ev('window.__xss = 0; 0');
  const onglets = await ev(`[...document.querySelectorAll('.tab-btn')].filter(b => b.offsetParent !== null).map(b => b.dataset.tab)`);
  const actifs = [];
  for (const t of onglets) {
    await ev(`document.querySelector('.tab-btn[data-tab="${t}"]').click(); 0`);
    await sleep(500);
    actifs.push(t);
  }
  await sleep(800);
  const etat = await ev(`(() => ({
    xss: window.__xss === 1,
    imgDonnees: document.querySelectorAll('img[src="x"], img[src="X"]').length,
    roueHote: ((document.getElementById('roue-wk-next-host') || {}).textContent || ''),
    roueDividendes: ((document.getElementById('roue-content') || {}).textContent || '').includes('<IMG SRC=X'),
    anticTitre: ((document.getElementById('antic-content') || {}).textContent || ''),
  }))()`);
  return { onglets: actifs, etat, errors: [...errors] };
};

test('local, tous les drapeaux : la Roue et les onglets cachés se rendent sans erreur et sans exécuter une donnée piégée', { skip }, async () => {
  const appels = [];
  const r = await withPage({ root: PAGES[0].root, authenticated: false, apiStub: stubDonnees(appels), chromePath }, scenarioOnglets(false));
  assert.ok(r.onglets.includes('roue'), `l'onglet Roue doit être révélé par son drapeau (onglets visibles : ${r.onglets.join(', ')})`);
  assert.ok(r.onglets.length >= 8, `davantage d'onglets visibles avec les drapeaux (${r.onglets.length})`);
  assert.deepEqual(r.errors, [], 'aucune exception non attrapée');
  assert.equal(r.etat.xss, false, 'AUCUN code venu d\'une donnée ne doit s\'exécuter');
  assert.equal(r.etat.imgDonnees, 0, 'aucun élément ne doit être créé à partir d\'une donnée');
  assert.match(r.etat.roueHote, /<IMG SRC=X/, 'la carte « Semaine suivante » doit afficher le texte piégé tel quel, échappé');
  assert.ok(appels.some((a) => a === 'GET /api/option-trades'), 'l\'onglet Roue a bien chargé ses données');
});

test('cloud, tous les drapeaux : Roue et Anticipation, données piégées, et le vote passe par l\'écouteur délégué', { skip }, async () => {
  const appels = [];
  const r = await withPage({ root: PAGES[1].root, authenticated: true, apiStub: stubDonnees(appels), chromePath }, async (ctx) => {
    const base = await scenarioOnglets(true)(ctx);
    // Vote : cliquer le bouton doit envoyer PUT /api/anticipation/carte-1/vote (sans gestionnaire en ligne)
    await ctx.ev(`document.querySelector('.tab-btn[data-tab="anticipation"]').click(); 0`);
    await ctx.sleep(400);
    const bouton = await ctx.ev(`!!document.querySelector('[data-antic="vote"][data-id="carte-1"]')`);
    await ctx.ev(`(() => { const b = document.querySelector('[data-antic="vote"][data-id="carte-1"]'); if (b) b.click(); })(); 0`);
    await ctx.sleep(700);
    const apres = await ctx.ev(`(document.getElementById('antic-content') || {}).textContent || ''`);
    return { ...base, bouton, apres };
  });
  assert.ok(r.onglets.includes('roue') && r.onglets.includes('anticipation'), `Roue et Anticipation visibles (${r.onglets.join(', ')})`);
  assert.deepEqual(r.errors, [], 'aucune exception non attrapée');
  assert.equal(r.etat.xss, false, 'AUCUN code venu d\'une donnée ne doit s\'exécuter');
  assert.equal(r.etat.imgDonnees, 0);
  assert.match(r.etat.anticTitre, /<img src=x onerror=/, 'le titre piégé d\'une carte s\'affiche tel quel');
  assert.equal(r.bouton, true, 'le bouton de vote porte data-antic="vote" (plus de onclick en ligne)');
  assert.ok(appels.includes('PUT /api/anticipation/carte-1/vote'), 'le clic sur le vote a bien envoyé la requête');
  assert.match(r.apres, /ok/, 'l\'écran se met à jour avec la réponse du serveur');
});

test('import de la Roue : une clé de cycle piégée ne s\'exécute plus et le stop saisi est bien enregistré', { skip }, async () => {
  const cle = "x'];window.__x2=1;//";
  const r = await withPage({ root: PAGES[0].root, authenticated: false, apiStub: stubDonnees([]), chromePath }, async ({ ev, sleep, errors }) => {
    await ev('renderRoueTab(); 0');
    await sleep(1500);
    const out = await ev(`(() => {
      const plan = { resume: { lignes: 1, aImporter: 1, doublons: 0, incoherentes: 0, aVerifier: 0 },
        cycles: [{ key: ${JSON.stringify(cle)}, ticker: 'AAA', debut: '2026-01-01', dejaCycleId: null, besoinStop: true,
          ops: [{ kind: 'achat', ligne: 2, ticker: 'AAA', date: '2026-01-02', prix: 10, actions: 100, commission: 0, issues: [], doublon: false, include: true }] }] };
      roueImpState = { plan, flows: [], fichier: 'club.xlsx', stops: Object.create(null), compte: 'margin' };
      roueImpRender();
      window.__x2 = 0;
      const champ = document.querySelector('#roue-imp-host input[data-stop-key]');
      if (!champ) return { champ: false };
      champ.value = '9.5';
      champ.dispatchEvent(new Event('input', { bubbles: true }));
      return { champ: true, gestionnaireEnLigne: champ.hasAttribute('oninput'), execute: window.__x2 === 1, enregistre: roueImpState.stops[${JSON.stringify(cle)}] };
    })()`);
    return { ...out, errors: [...errors] };
  });
  assert.equal(r.champ, true, 'le champ « Stop de l\'action » est affiché');
  assert.equal(r.gestionnaireEnLigne, false, 'plus de oninput en ligne');
  assert.equal(r.execute, false, 'la clé piégée ne doit rien exécuter');
  assert.equal(r.enregistre, '9.5', 'le stop saisi est bien rangé sous la clé du cycle');
  assert.deepEqual(r.errors, []);
});
