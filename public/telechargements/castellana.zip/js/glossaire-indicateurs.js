// Glossaire des indicateurs (feature 321) — objet JS statique, aucun appel
// modèle à la volée (décision documentée dans CLAUDE.md, 22/7/2026). Texte
// pré-rédigé par indicateur, calqué sur les bandes de la section 4.4 du
// design doc. Une seule fonction de rendu (index.html) lit ce glossaire pour
// les popovers d'aide. Aucune clé API, aucun credential.
//
// Format par entrée : { label, quoi, pourquoi, bandes:[{couleur,seuil,sens}] }
// couleur ∈ vert|amber|rouge — pour colorer la pastille dans le popover.
const GLOSSAIRE = {
  vix: {
    label: 'VIX — indice de volatilité',
    quoi: "Mesure la volatilité implicite attendue sur le S&P 500 à 30 jours. Souvent appelé « indice de la peur ».",
    pourquoi: "Donne le climat de marché global. En swing trading, un VIX élevé multiplie les faux signaux et élargit les mouvements — il module la taille de position et la largeur des stops.",
    bandes: [
      { couleur: 'amber', seuil: '< 15', sens: "Complaisance — marché calme, primes basses, risque de retournement soudain." },
      { couleur: 'vert', seuil: '15–20', sens: "Normal — climat neutre, taille de base appropriée." },
      { couleur: 'amber', seuil: '20–30', sens: "Nervosité — élargir les stops (ATR plus large) ou réduire la taille." },
      { couleur: 'rouge', seuil: '> 30', sens: "Panique — faux signaux fréquents, réduire de moitié ou attendre." },
    ],
  },
  rsi: {
    label: 'RSI(14) — force relative interne',
    quoi: "Oscillateur de momentum (0–100) mesurant la vitesse et l'ampleur des variations de prix récentes.",
    pourquoi: "Seul indicateur de momentum retenu (pas de MACD ni Stochastic RSI — redondance écartée avec JP). Repère le surachat/survente et la zone d'entrée saine.",
    bandes: [
      { couleur: 'amber', seuil: '< 30', sens: "Survente — rebond possible mais couteau qui tombe, pas un signal d'achat isolé." },
      { couleur: 'vert', seuil: '40–70', sens: "Zone d'entrée saine — momentum haussier sans excès." },
      { couleur: 'rouge', seuil: '> 70', sens: "Surachat — risque de correction, discount de sizing appliqué." },
    ],
  },
  obv: {
    label: 'OBV — On-Balance Volume',
    quoi: "Volume cumulatif : +volume les jours de hausse, −volume les jours de baisse. Vrai cumul (calcul maison), pas l'heuristique clôture/ouverture de tradingview-mcp.",
    pourquoi: "Confirme (ou non) le mouvement de prix par le volume. Une hausse de prix sans hausse d'OBV (divergence) trahit un mouvement peu soutenu.",
    bandes: [
      { couleur: 'vert', seuil: 'Accumulation', sens: "OBV monte avec le prix — mouvement soutenu par le volume." },
      { couleur: 'amber', seuil: 'Neutre', sens: "Pas de tendance nette du volume sur la fenêtre récente." },
      { couleur: 'rouge', seuil: 'Distribution', sens: "OBV diverge du prix — le volume ne suit pas, méfiance." },
    ],
  },
  forceRelative: {
    label: 'Force relative vs indice',
    quoi: "Écart de performance du titre par rapport à son indice de référence (SPY) sur la période.",
    pourquoi: "Un titre qui surperforme son indice attire la demande et tend à mener — le leadership relatif est un filtre de sélection clé.",
    bandes: [
      { couleur: 'vert', seuil: '> +5 pts', sens: "Forte — surperformance nette, potentiel de leadership." },
      { couleur: 'amber', seuil: '−5 à +5 pts', sens: "Neutre — suit le marché sans se démarquer." },
      { couleur: 'rouge', seuil: '< −5 pts', sens: "Faible — sous-performance, risque de continuité." },
    ],
  },
  goldenCross: {
    label: 'Golden Cross (SMA50 / SMA200)',
    quoi: "Croisement de la moyenne mobile simple 50 jours au-dessus de la 200 jours.",
    pourquoi: "Signal de tendance de fond haussière de long terme — sert de toile de fond au filtre de tendance court terme (SMA 9/21/100).",
    bandes: [
      { couleur: 'vert', seuil: 'Confirmé (> +1 %)', sens: "SMA50 nettement au-dessus de la SMA200 — tendance de fond haussière établie." },
      { couleur: 'amber', seuil: 'Naissant', sens: "Croisement récent/proche — à confirmer avec du volume." },
      { couleur: 'rouge', seuil: 'Absent', sens: "SMA50 sous la SMA200 — tendance de fond baissière ou neutre." },
    ],
  },
  sma: {
    label: 'SMA 9/21/100 — filtre de tendance',
    quoi: "Trois moyennes mobiles SIMPLES (SMA, fenêtre glissante — pas lissées/RMA). Signal au premier alignement haussier (prix > 9 > 21 > 100), sortie sous la SMA21.",
    pourquoi: "Cœur du filtre de tendance validé avec JP (ne pas remplacer par EMA 50/100/200). Définit le sens autorisé des trades.",
    bandes: [
      { couleur: 'vert', seuil: 'Haussier', sens: "Prix > SMA9 > SMA21 > SMA100 — alignement haussier complet." },
      { couleur: 'amber', seuil: 'Neutre', sens: "Alignement incomplet — pas de signal de tendance franc." },
      { couleur: 'rouge', seuil: 'Baissier', sens: "Prix < SMA9 < SMA21 < SMA100 — tendance baissière." },
    ],
  },
  atr: {
    label: 'ATR(14) — Average True Range',
    quoi: "Amplitude moyenne des mouvements quotidiens (vrai range lissé Wilder). Exprimé en dollars.",
    pourquoi: "Base du placement du stop (distance = ATR × multiplicateur) et donc du sizing. Un ATR large impose un stop plus large et une position plus petite à risque constant.",
    bandes: [],
  },
  vwap: {
    label: 'VWAP — Volume Weighted Average Price',
    quoi: "Prix moyen de la séance pondéré par le volume (calculé sur les barres 5 min du jour).",
    pourquoi: "Référence des intervenants institutionnels. Un prix au-dessus du VWAP indique un biais acheteur intraday ; en dessous, un biais vendeur.",
    bandes: [
      { couleur: 'vert', seuil: 'Prix > VWAP', sens: "Biais acheteur intraday — le prix se tient au-dessus de la référence institutionnelle." },
      { couleur: 'rouge', seuil: 'Prix < VWAP', sens: "Biais vendeur intraday — sous la référence, prudence sur une entrée longue." },
    ],
  },
  peg: {
    label: 'PEG ratio',
    quoi: "Ratio cours/bénéfice rapporté à la croissance des bénéfices (PE ÷ croissance).",
    pourquoi: "Filtre de valorisation : un PEG ≤ 1 suggère une valorisation raisonnable au regard de la croissance. Critère de screening supplémentaire (feature 322).",
    bandes: [
      { couleur: 'vert', seuil: '≤ 1', sens: "Valorisation raisonnable au regard de la croissance." },
      { couleur: 'amber', seuil: '> 1', sens: "Valorisation tendue — la croissance ne justifie pas entièrement le prix." },
    ],
  },
  beta: {
    label: 'Beta 5Y',
    quoi: "Sensibilité du titre aux mouvements du marché sur 5 ans (1 = suit l'indice, > 1 = amplifie).",
    pourquoi: "Filtre de screening (feature 322) : un beta > 1 privilégie les titres qui amplifient les mouvements — cohérent avec une stratégie swing offensive.",
    bandes: [
      { couleur: 'vert', seuil: '> 1', sens: "Amplifie les mouvements du marché — plus de potentiel (et de risque)." },
      { couleur: 'amber', seuil: '≤ 1', sens: "Suit ou amortit le marché — mouvements plus modérés." },
    ],
  },
  float: {
    label: 'Float — actions en circulation',
    quoi: "Nombre d'actions réellement disponibles à l'échange (hors blocs détenus par les initiés).",
    pourquoi: "Filtre de screening (feature 322) : un float plus faible amplifie les mouvements (moins d'offre). Borné par config pour cibler un profil de liquidité donné.",
    bandes: [],
  },
  rMultiples: {
    label: 'Multiples de R (basé sur l\'ATR)',
    quoi: "Cibles de sortie exprimées en multiples du risque initial R (R = distance du stop = ATR × multiplicateur). 1R, 2R, 3R sont les prix à atteindre pour gagner respectivement 1, 2 ou 3 fois le montant risqué sur ce trade.",
    pourquoi: "Ancre les objectifs sur le risque réellement pris sur CE trade, pas sur un pourcentage fixe — un stop plus large (titre volatil) donne mécaniquement des cibles plus éloignées, cohérent avec un ratio risque/récompense constant.",
    bandes: [],
  },
  fibonacci: {
    label: 'Extension Fibonacci',
    quoi: "Niveaux de prix projetés au-delà du haut du swing, à partir de l'amplitude du dernier mouvement (bas → haut) multipliée par des ratios Fibonacci (127.2 %, 161.8 %, 261.8 %).",
    pourquoi: "Cibles basées sur la structure du marché plutôt que sur le risque pris — utile à croiser avec les multiples de R pour repérer des zones de prix où d'autres intervenants pourraient aussi prendre profit.",
    bandes: [],
  },

  // Deux entrées ajoutées pour l'onglet Labo (5/9/2026, suite aux questions
  // de JP T0/T1/T3) — concepts d'options, pas des indicateurs de prix, mais
  // rendues avec le même popover (showGlossaire) pour rester cohérent avec
  // le reste de l'app plutôt que d'inventer un second mécanisme.
  leaps: {
    label: 'LEAPS — option à longue échéance',
    quoi: "LEAPS = Long-term Equity AnticiPation Securities. Ce n'est PAS un type de contrat différent d'un Call ou d'un Put ordinaire — c'est simplement une option (Call ou Put) dont l'échéance est longue (généralement 9 mois à 2-3 ans), par opposition à une option « classique » dont l'échéance va de quelques semaines à quelques mois. « LEAPS Call » se lit donc « Call (option d'achat) à longue échéance ».",
    pourquoi: "Dans le PMCC, on ACHÈTE un LEAPS Call profondément dans la monnaie pour qu'il serve de substitut aux 100 actions : sa longue échéance lui laisse le temps de se comporter presque comme l'action elle-même, sans en payer le plein prix.",
    bandes: [],
  },
  delta: {
    label: 'Delta — sensibilité au prix et probabilité approximative',
    quoi: "Pour une option, le delta mesure de combien son prix bouge pour chaque 1$ de mouvement du titre sous-jacent (ex. delta 0.20 ≈ +0.20$ sur l'option si le titre monte de 1$). C'est aussi, par approximation courante (pas une garantie mathématique), la probabilité que l'option termine dans la monnaie à l'échéance — delta 0.20 ≈ environ 20 % de chances.",
    pourquoi: "Sert de raccourci pour choisir un strike sans calculer soi-même les probabilités. Un Put VENDU à delta 0.15-0.25 a ≈75-85 % de chances d'expirer sans valeur (favorable au vendeur de prime). Un LEAPS Call ACHETÉ à delta 0.70-0.85 bouge presque comme l'action elle-même (mouvement de prix très corrélé) — c'est ce qui lui permet de la remplacer dans le PMCC.",
    bandes: [],
  },
};

// Exposé en global pour le <script> classique de index.html (pas de module).
window.GLOSSAIRE = GLOSSAIRE;
