// Performance et P/E moyen par secteur — carte "Performance des secteurs" de
// l'écran de sélection (29/8/2026, demande de JP, inspirée d'un tableau de
// performance sectorielle vu ailleurs). Univers : les 11 ETF SPDR Select
// Sector (State Street) — même famille que SPY, déjà utilisé partout
// ailleurs dans ce projet comme indice de référence (server/tradingview.js).
//
// Une seule requête Yahoo Finance légère par ETF (`yahooFinance.quote()`,
// pas `quoteSummary`) donne à la fois la performance du jour
// (`regularMarketChangePercent`) et le P/E trailing de l'ETF
// (`trailingPE`) — contrairement aux titres individuels (fundamentals.js),
// pas besoin d'un second appel pour le VWAP ici. Le "P/E moyen" du secteur
// est donc le P/E réel de l'ETF sectoriel lui-même (déjà une moyenne
// pondérée de marché sur ses constituants, calculée par le fournisseur de
// l'ETF) — PAS une approximation par pairs comme le "P/E industrie" du
// screening (voir server/index.js, section dédiée du CLAUDE.md) : ce champ-ci
// est un vrai agrégat de marché, pas construit maison.
//
// Sélecteur USD/CAD (2/9/2026, demande de JP) — voir SECTOR_DEFS ci-dessous.
// Une version "CAD couverte contre le risque de change" a été envisagée
// mais abandonnée : vérifié en direct que les 11 ETF sectoriels BMO n'ont
// PAS de version couverte listée sur Yahoo (les 11 tickers `.F.TO` testés
// échouent tous), contrairement au S&P 500 qui, lui, a une vraie version
// couverte (ZUE.TO) — mais un secteur seul sur onze n'aurait pas justifié
// un 3e mode. Le dropdown reste donc à 2 choix : USD / CAD (non couvert).

import YahooFinance from 'yahoo-finance2';

const yahooFinance = new YahooFinance({ suppressNotices: ['yahooSurvey'] });

// `key` reste toujours le ticker USD, stable quel que soit le mode devise
// affiché — c'est lui qui indexe SECTOR_ETF_TO_YAHOO_SECTOR et
// SECTOR_TOP_CANDIDATES plus bas, pour n'avoir qu'une seule table de
// correspondance peu importe la devise choisie à l'écran.
//
// Tickers CAD (BMO) vérifiés en direct sur Yahoo Finance le 2/9/2026
// (yahooFinance.quote()) — tous résolvent sauf le cas Immobilier noté
// ci-dessous. Fournis par JP à partir de la famille BMO "ZXLx" (même
// famille de nommage que XEQT.TO déjà dans la watchlist).
export const SECTOR_DEFS = [
  { key: 'XLK', label: 'Technologie', usd: 'XLK', cad: 'ZXLK.TO' },
  { key: 'XLY', label: 'Conso. discr.', usd: 'XLY', cad: 'ZXLY.TO' },
  { key: 'XLI', label: 'Industriel', usd: 'XLI', cad: 'ZXLI.TO' },
  { key: 'XLF', label: 'Finance', usd: 'XLF', cad: 'ZXLF.TO' },
  { key: 'XLU', label: 'Services publics', usd: 'XLU', cad: 'ZXLU.TO' },
  { key: 'XLV', label: 'Santé', usd: 'XLV', cad: 'ZXLV.TO' },
  // ZXRE.TO (nommage "ZXLx" attendu) ne résout PAS sur Yahoo — l'alternative
  // que JP avait mentionnée, ZRE.TO (BMO Equal Weight REITs Index ETF,
  // famille de nommage différente), résout bien et est utilisée à la place.
  { key: 'XLRE', label: 'Immobilier', usd: 'XLRE', cad: 'ZRE.TO' },
  { key: 'XLP', label: 'Conso. de base', usd: 'XLP', cad: 'ZXLP.TO' },
  { key: 'XLE', label: 'Énergie', usd: 'XLE', cad: 'ZXLE.TO' },
  { key: 'XLC', label: 'Services de comm.', usd: 'XLC', cad: 'ZXLC.TO' },
  { key: 'XLB', label: 'Matériaux', usd: 'XLB', cad: 'ZXLB.TO' },
];

export const BENCHMARK_DEFS = { key: 'SPY', label: 'S&P 500', usd: 'SPY', cad: 'ZSP.TO' };

export const SECTOR_MODES = ['usd', 'cad'];

// Mapping ETF secteur → nom de secteur GICS large tel que renvoyé par Yahoo
// Finance (`summaryProfile.sector`, fundamentals.js) — sert à agréger le PEG
// moyen des titres de la watchlist par secteur (feature "PEG moyen",
// 30/8/2026) et, depuis le 2/9/2026, à construire les listes "titres du
// secteur" (SECTOR_TOP_CANDIDATES ci-dessous). Indexé par `key` (toujours le
// ticker USD), pas par le ticker réellement affiché — reste correct peu
// importe le mode devise choisi. Vérifié en direct sur des titres connus de
// chaque secteur (ex. XOM→"Energy", NEE→"Utilities", PLD→"Real Estate",
// LIN→"Basic Materials", UNH→"Healthcare", HON→"Industrials",
// PG→"Consumer Defensive") — les noms Yahoo diffèrent parfois du nom de
// l'ETF SPDR (ex. "Consumer Cyclical" chez Yahoo = "Consumer Discretionary"
// côté SPDR/XLY), c'est la même catégorie sous deux conventions de nommage
// différentes.
export const SECTOR_ETF_TO_YAHOO_SECTOR = {
  XLK: 'Technology',
  XLY: 'Consumer Cyclical',
  XLI: 'Industrials',
  XLF: 'Financial Services',
  XLU: 'Utilities',
  XLV: 'Healthcare',
  XLRE: 'Real Estate',
  XLP: 'Consumer Defensive',
  XLE: 'Energy',
  XLC: 'Communication Services',
  XLB: 'Basic Materials',
};

// Titres "les plus performants du secteur" (feature top 30 par secteur,
// 2/9/2026) — liste CURATÉE par secteur, pas une requête de marché en
// direct. Décision prise avec JP après l'échec d'un spike sur l'endpoint
// screener personnalisé de Yahoo Finance (`v1/finance/screener` hors
// `/predefined/saved`) : 429 systématique même avec le crumb/cookie déjà
// valide, alors que le screener PRÉDÉFINI (day_gainers, etc., déjà exposé
// par yahoo-finance2) répond normalement avec les mêmes identifiants — tout
// indique un endpoint réservé aux utilisateurs connectés de Yahoo Finance,
// pas un simple rate-limit. Comme documenté dans le CLAUDE.md racine
// (leçon valencia/idealista), on ne force pas ce genre de barrière.
//
// À la place : même principe que la watchlist principale
// (server/watchlist.js) — une liste à la main de titres liquides et
// connus par secteur, classés par performance du jour au moment de la
// requête (getTopMoversForSector ci-dessous), pas figée dans le temps.
// Chaque ticker de cette liste a été VÉRIFIÉ EN DIRECT le 2/9/2026 contre
// la vraie classification `summaryProfile.sector` de Yahoo Finance (pas
// seulement une hypothèse) — plusieurs candidats initiaux ont été écartés
// à cette étape : ADP et PARA sont classés "Technology" chez Yahoo (pas
// dans leur secteur "attendu") ; AVY/PKG/IP/BALL (emballage) sont classés
// "Consumer Cyclical" plutôt que "Basic Materials" ; HES/CTRA/IPG ne
// résolvent plus du tout (probablement des fusions/acquisitions récentes).
// Ces titres ont été retirés plutôt que gardés avec une classification
// fausse. Les comptes par secteur varient donc naturellement (16 à 20) —
// Matériaux et Énergie/Comm. ont des univers plus restreints, ce qui est
// une réalité de la taille de ces secteurs, pas un bug : le nombre réel de
// candidats est toujours exposé (`totalCandidates`), jamais masqué derrière
// un "top 30" qui laisserait croire à un univers plus large qu'il ne l'est.
export const SECTOR_TOP_CANDIDATES = {
  XLK: ['AAPL', 'MSFT', 'NVDA', 'AVGO', 'ORCL', 'CRM', 'ADBE', 'AMD', 'CSCO', 'ACN', 'IBM', 'TXN', 'QCOM', 'INTC', 'NOW', 'PANW', 'MU', 'LRCX', 'KLAC', 'AMAT'],
  XLY: ['AMZN', 'TSLA', 'HD', 'MCD', 'NKE', 'LOW', 'SBUX', 'BKNG', 'TJX', 'CMG', 'MAR', 'ORLY', 'YUM', 'ROST', 'GM', 'F', 'RCL', 'HLT', 'EBAY', 'ABNB'],
  XLI: ['CAT', 'HON', 'UNP', 'RTX', 'BA', 'DE', 'LMT', 'GE', 'UPS', 'NOC', 'ETN', 'ITW', 'EMR', 'CSX', 'WM', 'GD', 'FDX', 'PH', 'NSC'],
  XLF: ['JPM', 'V', 'MA', 'BAC', 'WFC', 'GS', 'MS', 'SPGI', 'AXP', 'C', 'BLK', 'SCHW', 'PGR', 'CB', 'ICE', 'CME', 'USB', 'PNC', 'TFC'],
  XLU: ['NEE', 'DUK', 'SO', 'D', 'AEP', 'EXC', 'SRE', 'XEL', 'PEG', 'ED', 'WEC', 'ES', 'EIX', 'PPL', 'AEE', 'FE', 'DTE', 'CMS', 'ATO', 'CNP'],
  XLV: ['UNH', 'JNJ', 'LLY', 'ABBV', 'MRK', 'PFE', 'TMO', 'ABT', 'DHR', 'BMY', 'AMGN', 'MDT', 'ISRG', 'GILD', 'CVS', 'ELV', 'VRTX', 'CI', 'ZTS', 'SYK'],
  XLRE: ['PLD', 'AMT', 'EQIX', 'PSA', 'O', 'WELL', 'SPG', 'DLR', 'CCI', 'VICI', 'AVB', 'EQR', 'IRM', 'CBRE', 'SBAC', 'EXR', 'VTR', 'MAA', 'ESS', 'ARE'],
  XLP: ['PG', 'KO', 'PEP', 'WMT', 'COST', 'PM', 'MO', 'MDLZ', 'CL', 'TGT', 'KMB', 'GIS', 'STZ', 'SYY', 'KDP', 'KHC', 'HSY', 'MKC', 'CHD', 'CLX'],
  XLE: ['XOM', 'CVX', 'COP', 'EOG', 'SLB', 'MPC', 'PSX', 'WMB', 'OXY', 'VLO', 'KMI', 'OKE', 'BKR', 'HAL', 'DVN', 'FANG', 'TRGP', 'EQT'],
  XLC: ['META', 'GOOGL', 'GOOG', 'NFLX', 'DIS', 'CMCSA', 'T', 'VZ', 'TMUS', 'CHTR', 'EA', 'TTWO', 'WBD', 'OMC', 'LYV', 'MTCH', 'FOXA', 'NWSA'],
  XLB: ['LIN', 'SHW', 'ECL', 'APD', 'FCX', 'NEM', 'NUE', 'DOW', 'DD', 'PPG', 'VMC', 'MLM', 'ALB', 'CTVA', 'IFF', 'CE'],
};

// Seuils du mode "filtré" (exclut les micro-caps peu liquides) — dupliqués
// de config.js (CFG.sectorTop), même limitation de module que SCORE_BANDS/
// SCREEN_FILTERS dans server/index.js. Cohérent avec le rejet déjà
// documenté d'un scan générique "top gainers" ramenant des micro-caps
// spéculatives (voir CLAUDE.md racine).
export const SECTOR_TOP_FILTERS = {
  marketCapMin: 2_000_000_000,
  volumeMin: 1_000_000,
};

async function quoteChangeAndPE(ticker) {
  const q = await yahooFinance.quote(ticker);
  return {
    changePercent: q.regularMarketChangePercent ?? null,
    peRatio: q.trailingPE ?? null,
  };
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Séquentiel, délai léger par politesse — même discipline que
// getFundamentalsBatch/getHomemadeIndicatorsBatch, même si `quote()` ne
// s'est pas montré rate-limité en test réel (12 appels en ~2.5s, aucun
// rapport avec `coin_analysis`/tradingview-mcp). Un secteur en échec
// ressort avec `error` rempli, sans interrompre le reste.
export async function getSectorPerformance({ mode = 'usd', delayMs = 150 } = {}) {
  const sectors = [];
  for (const def of SECTOR_DEFS) {
    const ticker = def[mode] ?? def.usd;
    try {
      sectors.push({ key: def.key, ticker, label: def.label, ...(await quoteChangeAndPE(ticker)), error: null });
    } catch (err) {
      sectors.push({ key: def.key, ticker, label: def.label, changePercent: null, peRatio: null, error: err.message });
    }
    await sleep(delayMs);
  }
  const benchmarkTicker = BENCHMARK_DEFS[mode] ?? BENCHMARK_DEFS.usd;
  let benchmark;
  try {
    benchmark = { key: BENCHMARK_DEFS.key, ticker: benchmarkTicker, label: BENCHMARK_DEFS.label, ...(await quoteChangeAndPE(benchmarkTicker)), error: null };
  } catch (err) {
    benchmark = { key: BENCHMARK_DEFS.key, ticker: benchmarkTicker, label: BENCHMARK_DEFS.label, changePercent: null, peRatio: null, error: err.message };
  }
  return { sectors, benchmark };
}

// Historique quotidien pour le line graph de performance sectorielle
// (29/8/2026, demande de JP — période sélectionnable 1 semaine à 12 mois,
// défaut 12 mois). Un seul appel `yahooFinance.chart()` par ETF récupère
// ~13 mois de barres quotidiennes (marge au-delà de 12 mois pour couvrir le
// calendrier boursier) ; la normalisation en % depuis le début de la période
// choisie et le découpage par période se font côté frontend (sliceAndNormalize
// dans index.html) — pas de refetch à chaque changement de période.
const HISTORY_LOOKBACK_DAYS = 385;

async function fetchDailyCloses(ticker) {
  const now = new Date();
  const start = new Date(now.getTime() - HISTORY_LOOKBACK_DAYS * 24 * 3600 * 1000);
  const chart = await yahooFinance.chart(ticker, { period1: start, period2: now, interval: '1d' });
  return chart.quotes
    .filter((q) => q.close != null)
    .map((q) => ({ date: q.date.toISOString().slice(0, 10), close: q.close }));
}

export async function getSectorHistory({ mode = 'usd', delayMs = 150 } = {}) {
  const sectors = [];
  for (const def of SECTOR_DEFS) {
    const ticker = def[mode] ?? def.usd;
    try {
      sectors.push({ key: def.key, ticker, label: def.label, history: await fetchDailyCloses(ticker), error: null });
    } catch (err) {
      sectors.push({ key: def.key, ticker, label: def.label, history: [], error: err.message });
    }
    await sleep(delayMs);
  }
  const benchmarkTicker = BENCHMARK_DEFS[mode] ?? BENCHMARK_DEFS.usd;
  let benchmark;
  try {
    benchmark = { key: BENCHMARK_DEFS.key, ticker: benchmarkTicker, label: BENCHMARK_DEFS.label, history: await fetchDailyCloses(benchmarkTicker), error: null };
  } catch (err) {
    benchmark = { key: BENCHMARK_DEFS.key, ticker: benchmarkTicker, label: BENCHMARK_DEFS.label, history: [], error: err.message };
  }
  return { sectors, benchmark };
}

// "Titres les plus performants du secteur" — classe la liste curatée
// (SECTOR_TOP_CANDIDATES) du secteur cliqué par variation du jour
// descendante. mode='raw' : aucun filtre. mode='filtered' : exclut les
// titres dont la cap. boursière ou le volume sont sous SECTOR_TOP_FILTERS
// (et, par prudence, tout titre dont on n'a pas pu confirmer l'un ou
// l'autre — jamais inclus "au bénéfice du doute"). Un seul appel
// quoteSummary par titre (price+summaryProfile+summaryDetail) — pas
// d'appel supplémentaire vers coin_analysis/indicateurs maison pour ne
// jamais re-déclencher le rate-limit déjà documenté sur ce scanner.
export async function getTopMoversForSector(sectorKey, { mode = 'raw', delayMs = 120 } = {}) {
  const candidates = SECTOR_TOP_CANDIDATES[sectorKey];
  if (!candidates) {
    const err = new Error(`Secteur inconnu ou sans liste de titres : ${sectorKey}`);
    err.code = 'UNKNOWN_SECTOR';
    throw err;
  }
  const rows = [];
  for (const ticker of candidates) {
    try {
      const qs = await yahooFinance.quoteSummary(ticker, { modules: ['price', 'summaryDetail'] });
      rows.push({
        ticker,
        name: qs.price?.shortName ?? null,
        price: qs.price?.regularMarketPrice ?? null,
        changePercent: qs.price?.regularMarketChangePercent ?? null,
        marketCap: qs.price?.marketCap ?? null,
        volume: qs.price?.regularMarketVolume ?? null,
        peRatio: qs.summaryDetail?.trailingPE ?? null,
        exchange: qs.price?.exchangeName ?? null,
        error: null,
      });
    } catch (err) {
      rows.push({ ticker, name: null, price: null, changePercent: null, marketCap: null, volume: null, peRatio: null, exchange: null, error: err.message });
    }
    await sleep(delayMs);
  }
  const filtered = mode === 'filtered'
    ? rows.filter((r) => r.marketCap != null && r.marketCap >= SECTOR_TOP_FILTERS.marketCapMin && r.volume != null && r.volume >= SECTOR_TOP_FILTERS.volumeMin)
    : rows;
  const sorted = filtered
    .slice()
    .sort((a, b) => (b.changePercent ?? -Infinity) - (a.changePercent ?? -Infinity));
  return {
    rows: sorted.slice(0, 30),
    totalCandidates: candidates.length,
    failedCount: rows.filter((r) => r.error).length,
  };
}
