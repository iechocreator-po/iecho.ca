// castellana-telemetry — collecteur de télémétrie (6/9/2026)
//
// Contexte : castellana tourne en local chez chaque testeur (aucun serveur
// partagé, décision JP), donc ce petit Worker est le SEUL point de collecte
// centralisé. Le navigateur de chaque testeur poste directement ici
// (js/telemetry.js de castellana) — server/index.js n'est pas impliqué.
//
// Worker natif, zéro framework (Hono, itty-router, etc.) — pas besoin d'un
// routeur pour ce nombre de routes, cohérent avec la discipline
// zéro-dépendance du reste du portfolio pour ce type d'outil (voir
// launcher/server.js).
//
// Sécurité — DEUX mécanismes distincts, pas interchangeables.
//
// POST /events (ingestion) reste protégé par `TELEMETRY_TOKEN` seul
// (wrangler.jsonc `vars`, doit rester identique à CFG.telemetry.sharedToken
// dans config.js côté castellana) — PAS une vraie authentification, un
// filtre anti-bruit : le jeton est visible dans le code source du
// navigateur de castellana (quiconque a accès à l'app peut le lire), et
// c'est castellana lui-même qui poste ici, donc aucun vrai login n'est
// possible à ce point d'entrée.
//
// GET /dashboard, GET /events.csv, GET /summary et POST /delete
// (CONSULTATION ET ADMINISTRATION) sont protégés par une vraie
// authentification HTTP Basic (`DASHBOARD_USER`/`DASHBOARD_PASSWORD`, en
// SECRETS Wrangler — jamais dans ce dépôt).
//
// GET /summary et POST /delete (13/9/2026, feature bilbao #356) existent
// pour que **bilbao** (feature-factory), et non plus seulement le navigateur
// de JP, puisse consulter et administrer ces données EN ARRIÈRE-PLAN (fetch
// serveur→serveur, jamais depuis le navigateur d'un visiteur de bilbao) —
// bilbao détient les mêmes identifiants côté serveur (voir
// feature-factory/server/telemetry.js), jamais exposés à son propre
// navigateur. `POST /delete` est DESTRUCTEUR sur de vraies données de
// production : protégé par le même Basic Auth que /dashboard, jamais
// dégradé à un simple jeton même appelé depuis un outil de confiance comme
// bilbao (voir le raisonnement complet dans ../CLAUDE.md, 13/9/2026).

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*', // chaque testeur a une origine locale différente (127.0.0.1:4700 chez l'un, localhost:4700 chez l'autre) — le filtrage se fait par jeton, pas par origine
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, X-Telemetry-Token',
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...CORS_HEADERS },
  });
}

function checkToken(request, env, url) {
  const header = request.headers.get('X-Telemetry-Token');
  const queryToken = url.searchParams.get('token');
  const provided = header || queryToken;
  return Boolean(env.TELEMETRY_TOKEN) && provided === env.TELEMETRY_TOKEN;
}

// Authentification RÉELLE pour /dashboard et /events.csv (12/9/2026, demande
// de JP). `TELEMETRY_TOKEN` ci-dessus reste inchangé pour POST /events — il
// DOIT rester un simple filtre anti-bruit, puisque c'est castellana
// lui-même (code JS public, visible de quiconque ouvre l'app) qui l'envoie ;
// aucune vraie authentification n'est possible côté ingestion. Les deux
// routes de CONSULTATION, elles, ne sont ouvertes que par JP dans son
// navigateur — Basic Auth HTTP suffit (le navigateur affiche sa propre boîte
// de dialogue native, aucune page de login à construire) et les identifiants
// vivent en secrets Wrangler (`wrangler secret put`), jamais dans ce dépôt.
// Comparaison à temps constant (audit périphérie, 22/10/2026) : on compare des condensats SHA-256, de même longueur, octet par octet
// sans sortie anticipée. `===` révélait, par le temps de réponse, la longueur du préfixe correct.
async function sameSecret(a, b) {
  const enc = new TextEncoder();
  const [ha, hb] = await Promise.all([crypto.subtle.digest('SHA-256', enc.encode(String(a))), crypto.subtle.digest('SHA-256', enc.encode(String(b)))]);
  const x = new Uint8Array(ha), y = new Uint8Array(hb);
  let diff = 0;
  for (let i = 0; i < x.length; i++) diff |= x[i] ^ y[i];
  return diff === 0;
}

async function checkBasicAuth(request, env) {
  const header = request.headers.get('Authorization');
  if (!header || !header.startsWith('Basic ')) return false;
  let decoded;
  try {
    decoded = atob(header.slice(6));
  } catch {
    return false;
  }
  const sep = decoded.indexOf(':');
  if (sep === -1) return false;
  const user = decoded.slice(0, sep);
  const pass = decoded.slice(sep + 1);
  if (!env.DASHBOARD_USER || !env.DASHBOARD_PASSWORD) return false;
  const [okUser, okPass] = await Promise.all([sameSecret(user, env.DASHBOARD_USER), sameSecret(pass, env.DASHBOARD_PASSWORD)]);
  return okUser && okPass;
}

function unauthorized() {
  return new Response('Authentification requise.', {
    status: 401,
    headers: { 'WWW-Authenticate': 'Basic realm="castellana telemetry"', ...CORS_HEADERS },
  });
}

// Bug trouvé en testant list_saved (12/9/2026, pas en relisant le code) :
// cette liste n'avait jamais été mise à jour depuis sa création le
// 6/9/2026 — 'error' (ajouté le 7/9/2026, voir js/telemetry.js
// trackError()) en était absent, donc CHAQUE événement d'erreur envoyé par
// un testeur depuis cette date a été rejeté en silence (400, jamais vu par
// personne — le fire-and-forget de sendTelemetryEvent avale l'échec en
// console.warn). Corrigé en même temps que l'ajout de list_saved.
const KNOWN_EVENT_TYPES = new Set(['app_loaded', 'ticker_selected', 'param_changed', 'error', 'list_saved']);

const MAX_BODY_BYTES = 16 * 1024;
const MAX_WHO = 40;
const MAX_UA = 256;
const MAX_PAYLOAD_JSON = 4 * 1024;
const MAX_EVENTS_PER_MINUTE_PER_IP = 300;
const RETENTION_DAYS = 365;

function validateEvent(ev) {
  if (!ev || typeof ev !== 'object') return 'événement absent ou invalide';
  if (typeof ev.who !== 'string' || !ev.who) return 'champ "who" manquant';
  // Le jeton d'ingestion est public : on borne ce qu'un tiers peut écrire (audit périphérie, 22/10/2026).
  if (ev.who.length > MAX_WHO || /[\u0000-\u001f<>"'&]/.test(ev.who)) return 'champ "who" invalide';
  if (ev.ua != null && (typeof ev.ua !== 'string' || ev.ua.length > MAX_UA)) return 'champ "ua" invalide';
  if (typeof ev.event_type !== 'string' || !KNOWN_EVENT_TYPES.has(ev.event_type)) {
    return `event_type inconnu : ${JSON.stringify(ev.event_type)}`;
  }
  return null;
}

async function handleEvents(request, env, ip) {
  if (Number(request.headers.get('content-length')) > MAX_BODY_BYTES) return json({ error: 'corps trop volumineux' }, 413);
  let body;
  try {
    const text = await request.text();
    if (text.length > MAX_BODY_BYTES) return json({ error: 'corps trop volumineux' }, 413);
    body = JSON.parse(text);
  } catch {
    return json({ error: 'JSON invalide' }, 400);
  }
  const events = Array.isArray(body?.events) ? body.events : [body];
  if (events.length === 0) return json({ error: 'aucun événement' }, 400);
  if (events.length > 50) return json({ error: 'trop d\'événements dans un seul envoi (max 50)' }, 400);

  const now = new Date().toISOString();
  // Débit par adresse IP : un tiers qui connaît le jeton public ne peut pas remplir la base (et épuiser les limites D1) en boucle.
  const depuis = new Date(Date.now() - 60_000).toISOString();
  const recents = await env.DB.prepare('SELECT COUNT(*) AS n FROM telemetry_events WHERE ip = ? AND created_at >= ?').bind(ip, depuis).first();
  if ((recents?.n ?? 0) + events.length > MAX_EVENTS_PER_MINUTE_PER_IP) return json({ error: 'trop d\'événements, réessaie plus tard' }, 429);
  const stmt = env.DB.prepare(
    'INSERT INTO telemetry_events (created_at, who, ip, event_type, payload_json, user_agent) VALUES (?, ?, ?, ?, ?, ?)'
  );
  const batch = [];
  for (const ev of events) {
    const err = validateEvent(ev);
    if (err) return json({ error: err }, 400);
    let payload = JSON.stringify(ev.payload ?? {});
    if (payload.length > MAX_PAYLOAD_JSON) payload = JSON.stringify({ tronque: true, taille: payload.length });
    batch.push(stmt.bind(now, ev.who, ip, ev.event_type, payload, ev.ua ?? null));
  }
  await env.DB.batch(batch);
  // Rétention : une fois sur cinquante environ, on purge ce qui dépasse RETENTION_DAYS (la table ne grossit pas sans fin).
  if (Math.random() < 0.02) {
    const limite = new Date(Date.now() - RETENTION_DAYS * 86_400_000).toISOString();
    await env.DB.prepare('DELETE FROM telemetry_events WHERE created_at < ?').bind(limite).run().catch(() => {});
  }
  return json({ ok: true, inserted: batch.length });
}

function csvEscape(v) {
  if (v == null) return '';
  let s = String(v);
  // Un champ choisi par un tiers (who, user_agent) ne doit pas devenir une formule dans Excel (audit périphérie, 22/10/2026).
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

async function handleCsv(env) {
  const { results } = await env.DB
    .prepare('SELECT id, created_at, who, ip, event_type, payload_json, user_agent FROM telemetry_events ORDER BY id DESC LIMIT 5000')
    .all();
  const cols = ['id', 'created_at', 'who', 'ip', 'event_type', 'payload_json', 'user_agent'];
  const lines = [cols.join(',')];
  for (const row of results) lines.push(cols.map((c) => csvEscape(row[c])).join(','));
  return new Response(lines.join('\n'), {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="castellana-telemetry-${Date.now()}.csv"`,
      ...CORS_HEADERS,
    },
  });
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// ---- Dashboard (6/9/2026, enrichi) — activité par jour, tickers populaires,
// filtre par testeur. Palette et specs de marque repris du skill dataviz du
// portfolio (bleu catégoriel slot 1, mode sombre — voir palette.md) : une
// seule teinte par graphique (une seule série à la fois, pas de comparaison
// catégorielle), gridlines hairline récessives, barres <=24px avec coin
// arrondi 4px côté données, écart de 2px entre barres adjacentes,
// info-bulle au survol plutôt qu'une valeur sur chaque barre.
const DASH_COLORS = {
  surface: '#1a1a19',
  page: '#0d0d0d',
  ink: '#ffffff',
  ink2: '#c3c2b7',
  muted: '#898781',
  grid: '#2c2c2a',
  baseline: '#383835',
  series: '#3987e5',
};

// Graphique en barres verticales — activité par jour (une série, magnitude
// dans le temps). Pas de valeur sur chaque barre (jusqu'à 90 barres selon le
// filtre de période) — l'info-bulle au survol porte le détail, les
// graduations Y portent l'ordre de grandeur.
function dailyActivitySVG(rows) {
  const width = 720;
  const height = 220;
  const padL = 36;
  const padB = 28;
  const padT = 12;
  const padR = 12;
  const plotW = width - padL - padR;
  const plotH = height - padT - padB;
  const maxN = Math.max(1, ...rows.map((r) => r.n));
  const yMax = Math.ceil(maxN / 5) * 5 || 1;
  const n = rows.length || 1;
  const bandW = plotW / n;
  const barW = Math.max(2, Math.min(24, bandW - 2));

  const yTicks = [0, yMax / 2, yMax].map((v) => Math.round(v));
  const gridLines = yTicks
    .map((t) => {
      const y = padT + plotH - (t / yMax) * plotH;
      return `<line x1="${padL}" y1="${y.toFixed(1)}" x2="${width - padR}" y2="${y.toFixed(1)}" stroke="${DASH_COLORS.grid}" stroke-width="1"/>
        <text x="${padL - 6}" y="${(y + 3).toFixed(1)}" font-size="10" fill="${DASH_COLORS.muted}" text-anchor="end">${t}</text>`;
    })
    .join('');

  // Étiquettes X : espacées pour ne jamais se chevaucher (max ~8 visibles).
  const labelEvery = Math.max(1, Math.ceil(n / 8));
  const bars = rows
    .map((r, i) => {
      const x = padL + i * bandW + (bandW - barW) / 2;
      const h = (r.n / yMax) * plotH;
      const y = padT + plotH - h;
      const label = i % labelEvery === 0 ? `<text x="${(x + barW / 2).toFixed(1)}" y="${height - 8}" font-size="9" fill="${DASH_COLORS.muted}" text-anchor="middle">${escapeHtml(r.jour.slice(5))}</text>` : '';
      return `<rect class="dash-bar" data-jour="${escapeHtml(r.jour)}" data-n="${r.n}" x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${barW.toFixed(1)}" height="${Math.max(0, h).toFixed(1)}" rx="4" fill="${DASH_COLORS.series}"/>${label}`;
    })
    .join('');

  return `<svg viewBox="0 0 ${width} ${height}" width="100%" style="max-width:${width}px" role="img" aria-label="Activité par jour">
    ${gridLines}
    <line x1="${padL}" y1="${padT + plotH}" x2="${width - padR}" y2="${padT + plotH}" stroke="${DASH_COLORS.baseline}" stroke-width="1"/>
    ${bars}
  </svg>`;
}

// Graphique en barres horizontales — tickers les plus sélectionnés (classement,
// jusqu'à 15). Valeur au bout de chaque barre : liste courte, contrairement au
// graphique quotidien, donc labeller chaque ligne reste lisible et utile ici.
function topTickersSVG(rows) {
  if (rows.length === 0) return '<p class="dash-empty">Aucun ticker sélectionné sur cette période.</p>';
  const width = 360;
  const rowH = 24;
  const gap = 6;
  const height = rows.length * (rowH + gap) - gap + 8;
  const labelW = 64;
  const valueW = 34;
  const barMaxW = width - labelW - valueW - 8;
  const maxN = Math.max(1, ...rows.map((r) => r.n));

  const bars = rows
    .map((r, i) => {
      const y = i * (rowH + gap);
      const w = Math.max(2, (r.n / maxN) * barMaxW);
      return `
        <text x="${labelW - 8}" y="${(y + rowH / 2 + 4).toFixed(1)}" font-size="12" fill="${DASH_COLORS.ink2}" text-anchor="end" font-family="ui-monospace, monospace">${escapeHtml(r.ticker ?? '—')}</text>
        <rect class="dash-bar" data-ticker="${escapeHtml(r.ticker ?? '—')}" data-n="${r.n}" x="${labelW}" y="${y.toFixed(1)}" width="${w.toFixed(1)}" height="${rowH - 4}" rx="4" fill="${DASH_COLORS.series}"/>
        <text x="${(labelW + w + 6).toFixed(1)}" y="${(y + rowH / 2 + 4).toFixed(1)}" font-size="11" fill="${DASH_COLORS.ink}" font-variant-numeric="tabular-nums">${r.n}</text>
      `;
    })
    .join('');

  return `<svg viewBox="0 0 ${width} ${height}" width="100%" style="max-width:${width}px" role="img" aria-label="Tickers les plus sélectionnés">${bars}</svg>`;
}

// Requête partagée entre le dashboard HTML (JP, navigateur) et /summary
// (JSON, bilbao) — une seule implémentation des 4 requêtes plutôt que
// dupliquée entre les deux consommateurs (voir CLAUDE.md, discipline anti-
// duplication déjà appliquée ailleurs dans ce portfolio).
async function queryTelemetry(env, { days, who }) {
  const whoClause = who !== 'all' ? 'AND who = ?' : '';
  const whoBind = who !== 'all' ? [who] : [];
  // Seuil en ISO (comme created_at) : `datetime('now', ?)` donnait « AAAA-MM-JJ HH:MM:SS », qui s'ordonne mal contre « AAAA-MM-JJTHH:MM:SS ».
  const periodeArg = new Date(Date.now() - days * 86_400_000).toISOString();

  const [testeursRes, dailyRes, tickersRes, recentRes, typesRes, ipsRes, lastRes] = await Promise.all([
    env.DB.prepare('SELECT DISTINCT who FROM telemetry_events ORDER BY who LIMIT 200').all(),
    env.DB
      .prepare(
        `SELECT substr(created_at,1,10) AS jour, COUNT(*) AS n FROM telemetry_events
         WHERE created_at >= ? ${whoClause}
         GROUP BY jour ORDER BY jour`
      )
      .bind(periodeArg, ...whoBind)
      .all(),
    env.DB
      .prepare(
        `SELECT json_extract(payload_json,'$.ticker') AS ticker, COUNT(*) AS n FROM telemetry_events
         WHERE event_type = 'ticker_selected' AND created_at >= ? ${whoClause}
         GROUP BY ticker ORDER BY n DESC LIMIT 15`
      )
      .bind(periodeArg, ...whoBind)
      .all(),
    env.DB
      .prepare(
        `SELECT id, created_at, who, ip, event_type, payload_json FROM telemetry_events
         WHERE created_at >= ? ${whoClause}
         ORDER BY id DESC LIMIT 200`
      )
      .bind(periodeArg, ...whoBind)
      .all(),
    env.DB
      .prepare(
        `SELECT substr(created_at,1,10) AS jour, event_type, COUNT(*) AS n FROM telemetry_events
         WHERE created_at >= ? ${whoClause}
         GROUP BY jour, event_type ORDER BY jour`
      )
      .bind(periodeArg, ...whoBind)
      .all(),
    // Adresses IP (toute la base, pas seulement la période) : sert au menu de
    // suppression par IP de bilbao — une IP à supprimer peut dater d'avant la période.
    env.DB
      .prepare(
        `SELECT ip, COUNT(*) AS n, group_concat(DISTINCT who) AS who FROM telemetry_events
         GROUP BY ip ORDER BY n DESC LIMIT 200`
      )
      .all(),
    // Dernier événement par testeur (toute la base, 18/10/2026) : colonne
    // « dernière activité » des comptes castellana dans bilbao (carte G3).
    env.DB
      .prepare('SELECT who, MAX(created_at) AS last, COUNT(*) AS n FROM telemetry_events GROUP BY who LIMIT 200')
      .all(),
  ]);

  return {
    testeurs: testeursRes.results.map((r) => r.who),
    daily: dailyRes.results, // [{jour, n}]
    ips: ipsRes.results, // [{ip, n, who}] — toutes périodes (menu de suppression par IP)
    dailyByType: typesRes.results, // [{jour, event_type, n}] — graphique par type (bilbao)
    tickers: tickersRes.results, // [{ticker, n}]
    lastByWho: lastRes.results, // [{who, last, n}] — toutes périodes
    recent: recentRes.results, // [{id, created_at, who, ip, event_type, payload_json}]
    total: dailyRes.results.reduce((sum, r) => sum + r.n, 0),
  };
}

async function handleDashboard(env, url) {
  const days = Math.min(Math.max(parseInt(url.searchParams.get('days') || '30', 10) || 30, 1), 365);
  const who = url.searchParams.get('who') || 'all';
  const token = url.searchParams.get('token');

  const data = await queryTelemetry(env, { days, who });

  const testeurOptions = data.testeurs
    .map((w) => `<option value="${escapeHtml(w)}"${w === who ? ' selected' : ''}>${escapeHtml(w)}</option>`)
    .join('');

  const dayPresets = [7, 30, 90]
    .map((d) => `<option value="${d}"${d === days ? ' selected' : ''}>${d} derniers jours</option>`)
    .join('');

  const totalPeriode = data.total;

  // Une checkbox par ligne (suppression sélective, 18/9/2026, T1) — value =
  // id réel de la ligne, jamais un index de position (une ligne masquée par
  // un filtre ne doit jamais changer ce qui serait supprimé).
  const rows = data.recent
    .map(
      (r) => `<tr><td><input type="checkbox" class="dash-row-check" value="${r.id}"></td><td>${r.id}</td><td>${escapeHtml(r.created_at)}</td><td>${escapeHtml(r.who)}</td><td>${escapeHtml(r.ip ?? '')}</td><td>${escapeHtml(r.event_type)}</td><td><code>${escapeHtml(r.payload_json)}</code></td></tr>`
    )
    .join('\n');

  const html = `<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><title>castellana — télémétrie</title>
<style>
  :root { color-scheme: dark; }
  body { font-family: system-ui, -apple-system, "Segoe UI", sans-serif; margin: 0; padding: 2rem; background: ${DASH_COLORS.page}; color: ${DASH_COLORS.ink}; }
  h1 { font-size: 18px; margin: 0 0 4px; }
  .sub { color: ${DASH_COLORS.ink2}; font-size: 13px; margin: 0 0 1.2rem; }
  .filtres { display: flex; align-items: center; gap: 10px; margin-bottom: 1.4rem; flex-wrap: wrap; }
  .filtres select, .filtres button { font: inherit; font-size: 13px; background: ${DASH_COLORS.surface}; color: ${DASH_COLORS.ink}; border: 1px solid ${DASH_COLORS.baseline}; border-radius: 8px; padding: 6px 10px; }
  .filtres button { cursor: pointer; }
  .filtres button:hover { border-color: ${DASH_COLORS.series}; }
  .grille { display: grid; grid-template-columns: 1fr 1fr; gap: 1.2rem; margin-bottom: 1.4rem; }
  @media (max-width: 800px) { .grille { grid-template-columns: 1fr; } }
  .carte { background: ${DASH_COLORS.surface}; border: 1px solid ${DASH_COLORS.baseline}; border-radius: 12px; padding: 1rem 1.1rem; }
  .carte h2 { font-size: 13px; font-weight: 600; color: ${DASH_COLORS.ink2}; text-transform: uppercase; letter-spacing: 0.04em; margin: 0 0 10px; }
  .carte .stat { font-size: 22px; font-weight: 700; margin: 0 0 2px; }
  .dash-empty { color: ${DASH_COLORS.muted}; font-size: 13px; }
  .dash-bar { transition: filter 0.1s; cursor: default; }
  .dash-bar:hover { filter: brightness(1.3); }
  #dash-tooltip { position: fixed; pointer-events: none; background: ${DASH_COLORS.surface}; border: 1px solid ${DASH_COLORS.baseline}; border-radius: 6px; padding: 4px 8px; font-size: 12px; color: ${DASH_COLORS.ink}; display: none; z-index: 10; white-space: nowrap; }
  #dash-tooltip strong { font-variant-numeric: tabular-nums; }
  table { border-collapse: collapse; width: 100%; font-size: 13px; }
  th, td { border: 1px solid ${DASH_COLORS.baseline}; padding: 4px 8px; text-align: left; vertical-align: top; }
  th { background: ${DASH_COLORS.surface}; position: sticky; top: 0; }
  code { font-size: 11px; color: #9fd3ff; }
  a { color: ${DASH_COLORS.series}; }
  th.dash-sortable { cursor: pointer; user-select: none; }
  th.dash-sortable:hover { color: ${DASH_COLORS.series}; }
  th.dash-sort-asc::after { content: ' \\25B2'; font-size: 10px; }
  th.dash-sort-desc::after { content: ' \\25BC'; font-size: 10px; }
  tr.dash-filter-row th { background: ${DASH_COLORS.page}; padding: 3px 6px; }
  .dash-filter { width: 100%; box-sizing: border-box; font: inherit; font-size: 11px; padding: 3px 5px; background: ${DASH_COLORS.surface}; color: ${DASH_COLORS.ink}; border: 1px solid ${DASH_COLORS.baseline}; border-radius: 5px; }
  .table-actions { display: flex; justify-content: flex-end; margin-bottom: 8px; }
  #dash-delete-btn { font: inherit; font-size: 12px; background: #3a1414; color: #ffb4b4; border: 1px solid #5c2323; border-radius: 8px; padding: 5px 10px; cursor: pointer; }
  #dash-delete-btn:hover:not(:disabled) { border-color: #ffb4b4; }
  #dash-delete-btn:disabled { opacity: 0.45; cursor: default; }
</style></head>
<body>
  <h1>castellana — télémétrie</h1>
  <p class="sub"><strong>${totalPeriode}</strong> événement(s) sur la période — export complet : <code>/events.csv?token=...</code></p>

  <form class="filtres" method="get">
    <input type="hidden" name="token" value="${escapeHtml(token ?? '')}">
    <select name="days">${dayPresets}</select>
    <select name="who">
      <option value="all"${who === 'all' ? ' selected' : ''}>Tous les testeurs</option>
      ${testeurOptions}
    </select>
    <button type="submit">Filtrer</button>
  </form>

  <div class="grille">
    <div class="carte">
      <h2>Activité par jour</h2>
      ${dailyActivitySVG(data.daily)}
    </div>
    <div class="carte">
      <h2>Tickers les plus sélectionnés</h2>
      ${topTickersSVG(data.tickers)}
    </div>
  </div>

  <div class="carte" style="margin-bottom:1.4rem;">
    <h2>Derniers événements (200 max, période filtrée)</h2>
    <div class="table-actions">
      <button type="button" id="dash-delete-btn" disabled>Supprimer la sélection (0)</button>
    </div>
    <table id="dash-events-table">
      <thead>
        <tr>
          <th><input type="checkbox" id="dash-select-all" title="Tout sélectionner (lignes visibles)"></th>
          <th class="dash-sortable" data-col="1" data-type="num">id</th>
          <th class="dash-sortable" data-col="2" data-type="str">quand (serveur)</th>
          <th class="dash-sortable" data-col="3" data-type="str">qui</th>
          <th class="dash-sortable" data-col="4" data-type="str">ip</th>
          <th class="dash-sortable" data-col="5" data-type="str">type</th>
          <th class="dash-sortable" data-col="6" data-type="str">détail</th>
        </tr>
        <tr class="dash-filter-row">
          <th></th>
          <th><input type="text" class="dash-filter" data-col="1" placeholder="filtrer…"></th>
          <th><input type="text" class="dash-filter" data-col="2" placeholder="filtrer…"></th>
          <th><input type="text" class="dash-filter" data-col="3" placeholder="filtrer…"></th>
          <th><input type="text" class="dash-filter" data-col="4" placeholder="filtrer…"></th>
          <th><input type="text" class="dash-filter" data-col="5" placeholder="filtrer…"></th>
          <th><input type="text" class="dash-filter" data-col="6" placeholder="filtrer…"></th>
        </tr>
      </thead>
      <tbody id="dash-events-tbody">${rows}</tbody>
    </table>
  </div>

  <div id="dash-tooltip"></div>
  <script>
    const tooltip = document.getElementById('dash-tooltip');
    document.querySelectorAll('.dash-bar').forEach((bar) => {
      bar.addEventListener('pointermove', (e) => {
        const jour = bar.dataset.jour;
        const ticker = bar.dataset.ticker;
        const n = bar.dataset.n;
        tooltip.textContent = '';
        const strong = document.createElement('strong');
        strong.textContent = n;
        tooltip.appendChild(strong);
        tooltip.appendChild(document.createTextNode(' — ' + (jour || ticker)));
        tooltip.style.display = 'block';
        tooltip.style.left = (e.clientX + 12) + 'px';
        tooltip.style.top = (e.clientY + 12) + 'px';
      });
      bar.addEventListener('pointerleave', () => { tooltip.style.display = 'none'; });
    });

    // Tri, filtre et suppression du tableau "Derniers événements" (18/9/2026,
    // T1) — tout est client-side sur les lignes déjà chargées (≤200, aucun
    // aller-retour serveur pour trier/filtrer). Seule la suppression appelle
    // le serveur (POST /delete, scope "ids").
    (function () {
      const table = document.getElementById('dash-events-table');
      const tbody = document.getElementById('dash-events-tbody');
      const selectAll = document.getElementById('dash-select-all');
      const deleteBtn = document.getElementById('dash-delete-btn');
      if (!table || !tbody || !selectAll || !deleteBtn) return;

      function rowChecks() {
        return Array.from(tbody.querySelectorAll('.dash-row-check'));
      }

      function updateDeleteButton() {
        const n = rowChecks().filter((c) => c.checked).length;
        deleteBtn.textContent = 'Supprimer la sélection (' + n + ')';
        deleteBtn.disabled = n === 0;
      }

      tbody.addEventListener('change', (e) => {
        if (e.target.classList.contains('dash-row-check')) updateDeleteButton();
      });

      selectAll.addEventListener('change', () => {
        rowChecks().forEach((c) => {
          if (c.closest('tr').style.display !== 'none') c.checked = selectAll.checked;
        });
        updateDeleteButton();
      });

      // Tri — une seule colonne active à la fois, bascule asc/desc au reclic.
      const sortState = { col: null, dir: 1 };
      table.querySelectorAll('th.dash-sortable').forEach((th) => {
        th.addEventListener('click', () => {
          const col = parseInt(th.dataset.col, 10);
          const type = th.dataset.type;
          sortState.dir = sortState.col === col ? -sortState.dir : 1;
          sortState.col = col;
          table.querySelectorAll('th.dash-sortable').forEach((h) => h.classList.remove('dash-sort-asc', 'dash-sort-desc'));
          th.classList.add(sortState.dir === 1 ? 'dash-sort-asc' : 'dash-sort-desc');

          const rows = Array.from(tbody.querySelectorAll('tr'));
          rows.sort((a, b) => {
            const av = a.children[col].textContent.trim();
            const bv = b.children[col].textContent.trim();
            if (type === 'num') return (parseFloat(av) - parseFloat(bv)) * sortState.dir;
            return av.localeCompare(bv) * sortState.dir;
          });
          rows.forEach((r) => tbody.appendChild(r));
        });
      });

      // Filtre — un champ par colonne, sous-chaîne insensible à la casse,
      // toutes les colonnes renseignées doivent matcher (ET logique).
      const filterInputs = Array.from(table.querySelectorAll('.dash-filter'));
      function applyFilters() {
        const active = filterInputs
          .map((inp) => ({ col: parseInt(inp.dataset.col, 10), value: inp.value.trim().toLowerCase() }))
          .filter((f) => f.value);
        tbody.querySelectorAll('tr').forEach((row) => {
          const match = active.every((f) => row.children[f.col].textContent.toLowerCase().includes(f.value));
          row.style.display = match ? '' : 'none';
        });
        updateDeleteButton();
      }
      filterInputs.forEach((inp) => inp.addEventListener('input', applyFilters));

      // Suppression — réutilise le Basic Auth déjà entré par le navigateur
      // pour /dashboard (même origine/royaume, renvoyé automatiquement).
      deleteBtn.addEventListener('click', async () => {
        const ids = rowChecks().filter((c) => c.checked).map((c) => parseInt(c.value, 10));
        if (ids.length === 0) return;
        if (!confirm('Supprimer définitivement ' + ids.length + ' événement(s) ? Cette action est irréversible.')) return;
        deleteBtn.disabled = true;
        deleteBtn.textContent = 'Suppression…';
        try {
          const res = await fetch('/delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ scope: 'ids', ids }),
          });
          const data = await res.json();
          if (!res.ok) throw new Error(data.error || 'échec inconnu');
          location.reload();
        } catch (err) {
          alert('Échec de la suppression : ' + err.message);
          updateDeleteButton();
        }
      });
    })();
  </script>
</body></html>`;
  return new Response(html, { headers: { 'Content-Type': 'text/html; charset=utf-8', ...CORS_HEADERS } });
}

// GET /summary (13/9/2026, feature bilbao #356) — mêmes 4 requêtes que le
// dashboard HTML, en JSON : bilbao construit son propre rendu (ses propres
// jetons de design, sa propre carte) plutôt que d'embarquer du HTML/SVG
// pensé pour être ouvert directement dans un navigateur.
async function handleSummary(env, url) {
  const days = Math.min(Math.max(parseInt(url.searchParams.get('days') || '30', 10) || 30, 1), 365);
  const who = url.searchParams.get('who') || 'all';
  const data = await queryTelemetry(env, { days, who });
  return json({ days, who, ...data });
}

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

// POST /delete (13/9/2026, feature bilbao #356 ; scope "ids" ajouté le
// 18/9/2026, T1 — suppression d'événements précis depuis le tableau du
// dashboard) — DESTRUCTEUR sur de vraies données de production. Portées
// explicites, aucun défaut implicite : 'all' exige `confirm: true` dans le
// corps (dernier garde-fou contre un bug d'appel côté bilbao qui omettrait
// le scope réel) ; 'who'/'range'/'ip'/'ids' exigent leurs paramètres, jamais une
// suppression plus large par accident faute d'un champ manquant. Compte les
// lignes AVANT de les supprimer pour pouvoir rapporter un nombre exact —
// jamais un succès muet sans dire combien.
async function handleDelete(request, env, url) {
  // Destructeur : JSON obligatoire (une page tierce ne peut pas l'envoyer en « requête simple ») et origine inconnue refusée. bilbao appelle de
  // serveur à serveur (aucun Origin); le tableau de bord appelle depuis sa propre origine (audit périphérie, 22/10/2026).
  const origin = request.headers.get('Origin');
  if (origin && origin !== url.origin) return json({ error: 'origine non autorisée' }, 403);
  if (!(request.headers.get('Content-Type') || '').toLowerCase().includes('application/json')) return json({ error: 'Content-Type application/json requis' }, 415);
  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: 'JSON invalide' }, 400);
  }
  const { scope, who, from, to, confirm, ids, ip } = body || {};

  let where;
  let binds = [];
  if (scope === 'all') {
    if (confirm !== true) {
      return json({ error: 'suppression totale refusée sans confirmation explicite (confirm: true)' }, 400);
    }
    where = '1=1';
  } else if (scope === 'who') {
    if (typeof who !== 'string' || !who) {
      return json({ error: 'champ "who" requis pour scope=who' }, 400);
    }
    where = 'who = ?';
    binds = [who];
  } else if (scope === 'range') {
    if (!DATE_RE.test(from) || !DATE_RE.test(to)) {
      return json({ error: 'champs "from"/"to" requis pour scope=range, au format YYYY-MM-DD' }, 400);
    }
    where = 'created_at >= ? AND created_at <= ?';
    binds = [`${from}T00:00:00.000Z`, `${to}T23:59:59.999Z`];
  } else if (scope === 'ip') {
    if (typeof ip !== 'string' || !ip || ip.length > 64) {
      return json({ error: 'champ "ip" requis pour scope=ip' }, 400);
    }
    where = 'ip = ?';
    binds = [ip];
  } else if (scope === 'ids') {
    // Tableau du dashboard limité à 200 lignes (queryTelemetry) — le plafond
    // ci-dessous n'est donc jamais atteignable depuis l'UI, seulement une
    // garde contre un appel direct malformé.
    const valid = Array.isArray(ids) && ids.length > 0 && ids.length <= 200
      && ids.every((id) => Number.isInteger(id) && id > 0);
    if (!valid) {
      return json({ error: 'champ "ids" requis pour scope=ids — tableau de 1 à 200 entiers positifs' }, 400);
    }
    // json_each plutôt que "IN (?,?,...)" — un `IN` à 200 paramètres liés
    // reste sous la limite D1 observée (~270, voir cloud/src/db/cache.js),
    // mais json_each est le patron déjà établi dans ce portfolio pour ce cas
    // et évite de s'en approcher si le plafond de 200 changeait un jour.
    where = 'id IN (SELECT value FROM json_each(?))';
    binds = [JSON.stringify(ids)];
  } else {
    return json({ error: 'scope invalide — attendu "all", "who", "range", "ip" ou "ids"' }, 400);
  }

  const countRow = await env.DB.prepare(`SELECT COUNT(*) AS n FROM telemetry_events WHERE ${where}`).bind(...binds).first();
  await env.DB.prepare(`DELETE FROM telemetry_events WHERE ${where}`).bind(...binds).run();
  return json({ ok: true, scope, deleted: countRow?.n ?? 0 });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: CORS_HEADERS });
    }

    if (request.method === 'POST' && url.pathname === '/events') {
      if (!checkToken(request, env, url)) return json({ error: 'jeton invalide ou absent' }, 401);
      const ip = request.headers.get('cf-connecting-ip') || 'inconnue';
      return handleEvents(request, env, ip);
    }

    if (request.method === 'GET' && url.pathname === '/events.csv') {
      if (!(await checkBasicAuth(request, env))) return unauthorized();
      return handleCsv(env);
    }

    // Manifeste de version (7/9/2026) — publique et SANS jeton, à dessein :
    // c'est l'app installée chez un testeur qui l'interroge au démarrage
    // pour savoir si sa copie est à jour, et elle ne révèle rien de plus
    // que ce qui est déjà téléchargeable depuis iecho.ca.
    //
    // ⚠️ À BUMPER À LA MAIN à chaque publication d'un nouveau zip, en même
    // temps que "version" dans ../package.json — rien ne synchronise les
    // deux (même limite que TELEMETRY_TOKEN / CFG.telemetry.sharedToken).
    // Publier un zip sans toucher à PUBLISHED_VERSION laisse simplement les
    // testeurs sur leur version : c'est silencieux, pas cassé.
    if (request.method === 'GET' && url.pathname === '/version') {
      return json({
        version: env.PUBLISHED_VERSION ?? null,
        url: env.PUBLISHED_URL ?? null,
        notes: env.PUBLISHED_NOTES ?? null,
        // Empreinte sha256 de l'archive (audit routes, 21/10/2026) : l'app refuse d'installer une archive sans elle ou qui ne correspond pas.
        // À mettre à jour avec PUBLISHED_VERSION à chaque publication (npm run package l'affiche).
        sha256: env.PUBLISHED_SHA256 ?? null,
      });
    }

    if (request.method === 'GET' && url.pathname === '/dashboard') {
      if (!(await checkBasicAuth(request, env))) return unauthorized();
      return handleDashboard(env, url);
    }

    // Consultation ET administration depuis bilbao (13/9/2026, #356) — voir
    // le commentaire d'en-tête. Basic Auth uniquement (`Authorization`,
    // jamais `?token=` — bilbao l'envoie en en-tête, appel serveur→serveur).
    if (request.method === 'GET' && url.pathname === '/summary') {
      if (!(await checkBasicAuth(request, env))) return unauthorized();
      return handleSummary(env, url);
    }

    if (request.method === 'POST' && url.pathname === '/delete') {
      if (!(await checkBasicAuth(request, env))) return unauthorized();
      return handleDelete(request, env, url);
    }

    return json({ error: 'not found' }, 404);
  },
};
