// Fichiers communs aux deux versions (local et cloud) : une SOURCE dans le dépôt (css/, js/), une COPIE octet pour octet sous
// cloud/public/ (npm run sync:cloud). La liste vit dans scripts/sync-cloud-copies.mjs (PLAIN_COPIES). Garde aussi la forme
// des pages après le découpage des index.html (phase 2) : le script en ligne ne doit plus contenir que le démarrage.
import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { PLAIN_COPIES } from '../scripts/sync-cloud-copies.mjs';

const ROOT = new URL('..', import.meta.url);
const read = (p) => readFileSync(new URL(p, ROOT), 'utf8');

for (const { source, target } of PLAIN_COPIES) {
  test(`copie cloud identique : ${source} -> ${target}`, () => {
    assert.ok(existsSync(new URL(source, ROOT)), `${source} (source) introuvable`);
    assert.equal(read(target), read(source), `${target} a dérivé de ${source} : lance \`npm run sync:cloud\` (depuis trading-assistant/)`);
  });
}

const PAGES = [
  { page: 'index.html', base: '', mode: 'js/mode-local.js', autre: 'js/mode-cloud.js' },
  { page: 'cloud/public/index.html', base: 'cloud/public/', mode: 'js/mode-cloud.js', autre: 'js/mode-local.js' },
];
const COMMUNS = PLAIN_COPIES.map((c) => c.source).filter((s) => s.startsWith('js/app-'));

for (const { page, base, mode, autre } of PAGES) {
  test(`${page} : fichier de mode d'abord, puis les fichiers communs dans l'ordre, init puis démarrage à la fin`, () => {
    const html = read(page);
    const srcs = [...html.matchAll(/<script src="(js\/[^"]+\.js)"/g)].map((m) => m[1]);
    assert.ok(srcs.includes(mode), `${page} ne charge pas ${mode}`);
    assert.ok(!srcs.includes(autre), `${page} ne doit pas charger ${autre} (propre à l'autre mode)`);
    for (const f of COMMUNS) assert.ok(srcs.includes(f), `${page} ne charge pas ${f}`);
    for (const f of [mode, ...COMMUNS]) assert.ok(existsSync(new URL(base + f, ROOT)), `${base + f} référencé mais introuvable`);
    const attendu = [mode, ...COMMUNS].filter((f) => srcs.includes(f));
    assert.deepEqual(srcs.filter((s) => attendu.includes(s)), attendu,
      `ordre de chargement : ${mode} doit précéder les fichiers communs (ils nomment au chargement des fonctions du mode), js/app-init.js puis js/app-demarrage.js à la fin`);
  });

  test(`${page} : le script en ligne ne contient plus que le démarrage`, () => {
    const html = read(page);
    const inlines = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1]);
    const gros = inlines.reduce((a, b) => (b.split('\n').length > a.split('\n').length ? b : a), '');
    const n = gros.split('\n').length;
    assert.ok(n <= 120, `le script en ligne de ${page} fait ${n} lignes (max 120) : le code va dans js/ (communs : js/app-*.js, propre à un mode : js/mode-*.js)`);
    assert.ok(!/^function\s+\w+/m.test(gros.replace(/^\s*\(async function boot\(\)[\s\S]*$/m, '')), `${page} : déclaration de fonction dans le script en ligne : à déplacer dans js/`);
  });
}
