// js/sizing.js — calcul de taille de position, stop et charge de
// portefeuille. Extrait de `calcFiche()` le 11/9/2026.
//
// POURQUOI L'EXTRAIRE : ces formules étaient enfermées au milieu des
// écritures DOM de `calcFiche()`, donc utilisables par un seul écran. Le
// screening doit maintenant afficher, pour CHAQUE candidat, ce que le trade
// coûterait en charge de portefeuille — sans quoi passer de 2 à ~19
// candidats par jour reviendrait à présenter un menu sans prix.
//
// ⚠️ CE FICHIER EST LA SEULE MAISON DE CES FORMULES. Ne jamais les
// redupliquer côté serveur pour « faire le calcul dans /api/screening » :
// ce projet porte déjà DEUX duplications à resynchroniser à la main
// (`SCORE_BANDS` et `SCREEN_FILTERS`, entre config.js et server/), chacune
// documentée comme un piège. Une troisième, sur le calcul qui décide
// combien d'argent est engagé, serait la pire des trois. Le screening passe
// donc par cette fonction côté client, avec le capital et la charge saisis
// dans la Fiche de trade.
//
// Fonction PURE : aucune lecture du DOM, aucune écriture. C'est ce qui la
// rend testable — elle ne l'était pas jusqu'ici, alors que c'est le calcul
// le plus lourd de conséquences de l'application.

/**
 * @param {object} p
 * @param {number} p.capital     capital total du compte
 * @param {number} p.riskPct     risque de base en % du capital
 * @param {number} p.heatExist   charge de portefeuille déjà engagée, en %
 * @param {number} p.entry       prix d'entrée envisagé
 * @param {number} p.atr         ATR(14) du titre
 * @param {number} p.atrMult     multiplicateur d'ATR pour la distance du stop
 * @param {boolean} p.correlated position corrélée à une autre déjà ouverte
 * @param {number} p.vix         VIX au moment de l'entrée
 * @param {number} p.rsi         RSI au moment de l'entrée
 * @param {string} p.obv         'accumulation' | 'neutre' | 'distribution'
 */
function computeSizing({ capital, riskPct, heatExist, entry, atr, atrMult, correlated, vix, rsi, obv }) {
  const d = CFG.sizing.discounts;
  const bVix = CFG.bandes.vix;
  const bRsi = CFG.bandes.rsi;

  const stopDist = atr * atrMult;
  const stopPrice = entry - stopDist;

  // Discounts MULTIPLICATIFS et cumulatifs (design doc section 6) — deux
  // conditions défavorables réduisent donc la taille davantage qu'une seule.
  let effectiveRiskPct = riskPct;
  const reasons = [];
  if (correlated) { effectiveRiskPct *= d.correlation; reasons.push('corrélation'); }
  if (vix >= bVix.nervositeHaut) effectiveRiskPct *= d.vixPanique;
  else if (vix >= bVix.normalHaut) effectiveRiskPct *= d.vixNervosite;
  if (vix >= bVix.normalHaut) reasons.push('VIX');
  if (rsi > bRsi.entreeHaut) { effectiveRiskPct *= d.rsiSurachat; reasons.push('surachat'); }
  if (obv === 'distribution') { effectiveRiskPct *= d.obvDistribution; reasons.push('divergence OBV'); }

  const riskAmount = capital * (effectiveRiskPct / 100);
  // `Math.floor` : on n'achète jamais une fraction d'action, et arrondir au
  // supérieur ferait dépasser le risque voulu.
  const sharesParRisque = stopDist > 0 ? Math.floor(riskAmount / stopDist) : 0;

  // Plafond de CAPITAL (audit formules, 20/10/2026). Le risque seul ne borne pas la position : plus l'ATR est petit
  // devant le prix, plus il faut d'actions pour « utiliser » le risque permis. À 0,5 % d'ATR, risque 1 %, stop à 1,5 ATR,
  // la formule donnait 133 % du capital — sans aucune alerte. Sans prix d'entrée, la valeur ne se calcule pas : pas de plafond.
  const positionMaxPct = CFG.sizing.positionMaxPct ?? 100;
  const maxShares = capital > 0 && entry > 0 ? Math.floor((capital * (positionMaxPct / 100)) / entry) : null;
  const plafonneParCapital = maxShares != null && sharesParRisque > maxShares;
  const shares = plafonneParCapital ? maxShares : sharesParRisque;
  if (plafonneParCapital) reasons.push('capital');

  // Risque réellement engagé si le stop est touché : plafonnée, la position risque moins que le budget de risque.
  const riskEngage = plafonneParCapital ? shares * stopDist : riskAmount;
  const valeurPosition = entry > 0 ? shares * entry : null;
  const pctCapital = valeurPosition != null && capital > 0 ? (valeurPosition / capital) * 100 : null;
  const thisTradeHeat = capital > 0 ? (riskEngage / capital) * 100 : 0;
  const totalHeat = heatExist + thisTradeHeat;

  return {
    stopDist,
    stopPrice,
    effectiveRiskPct,
    riskAmount,
    shares,
    sharesParRisque,
    plafonneParCapital,
    riskEngage,
    valeurPosition,
    pctCapital,
    positionMaxPct,
    thisTradeHeat,
    totalHeat,
    reasons,
    // Dépasse-t-on le seuil d'alerte de charge agrégée ? C'est le garde-fou
    // du screening : un candidat qui ferait franchir ce seuil est grisé
    // plutôt que présenté comme une opportunité ordinaire.
    depasseAlerte: totalHeat > CFG.sizing.chargePortefeuille.alerte,
    depasseAvertissement: totalHeat > CFG.sizing.chargePortefeuille.avertissement,
  };
}

// Phrase d'avertissement quand la taille a été plafonnée par le capital (null sinon) — partagée par la Fiche de trade
// (les deux versions) pour qu'elle dise la même chose partout.
function sizingCapNote(sz) {
  if (!sz || !sz.plafonneParCapital) return null;
  const f = (n) => Math.round(n).toLocaleString('fr-CA');
  return 'Taille plafonnée au capital : avec ce stop, le risque seul donnerait ' + sz.sharesParRisque + ' actions, soit plus que la limite de '
    + sz.positionMaxPct + ' % du capital. Retenu : ' + sz.shares + ' actions (' + f(sz.valeurPosition) + ' $), risque réel ' + f(sz.riskEngage) + ' $ si le stop est touché.';
}

// Exporté pour les tests Node (`node --test`), inerte dans le navigateur.
if (typeof module !== 'undefined' && module.exports) module.exports = { computeSizing, sizingCapNote };
