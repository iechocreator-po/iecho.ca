// Statistiques post-trade (feature 323) — répond à l'objectif analytique de
// la section 7 du design doc : « chaque indicateur (VIX, RSI, OBV,
// corrélation) a-t-il une vraie valeur prédictive dans les trades de JP ? »
// Ex. taux de réussite des trades pris avec VIX>20 vs VIX<20.
//
// Ne considère que les trades CLÔTURÉS (resultat renseigné) — un trade
// encore ouvert n'a pas de verdict gagnant/perdant. Bandes VIX/RSI alignées
// sur config.js (dupliquées, même limitation que SCORE_BANDS).

import { db } from './db.js';

// Agrège un ensemble de trades clôturés en {n, gagnants, tauxReussite, rMoyen}.
function summarize(trades) {
  const n = trades.length;
  if (n === 0) return { n: 0, gagnants: 0, tauxReussite: null, rMoyen: null };
  const gagnants = trades.filter((t) => t.resultat === 'gagnant').length;
  const rValues = trades.filter((t) => t.r_realise != null).map((t) => t.r_realise);
  const rMoyen = rValues.length ? rValues.reduce((a, b) => a + b, 0) / rValues.length : null;
  return {
    n,
    gagnants,
    tauxReussite: gagnants / n,
    rMoyen,
  };
}

// Découpe les trades en groupes selon `keyFn`, et résume chaque groupe.
// Les trades dont la clé est null (indicateur non renseigné à l'entrée)
// vont dans un groupe "inconnu" à part.
function bucketize(trades, buckets) {
  const out = {};
  for (const { label, test } of buckets) {
    out[label] = summarize(trades.filter(test));
  }
  return out;
}

export function computeStats() {
  const closed = db.prepare("SELECT * FROM trades WHERE resultat IS NOT NULL").all();

  const vixSeuil = 20; // config.js CFG.bandes.vix.normalHaut
  const rsiHaut = 70; // config.js CFG.bandes.rsi.entreeHaut

  return {
    global: {
      total: db.prepare('SELECT COUNT(*) AS c FROM trades').get().c,
      clotures: closed.length,
      ouverts: db.prepare('SELECT COUNT(*) AS c FROM trades WHERE date_sortie IS NULL').get().c,
      ...summarize(closed),
    },
    parVix: bucketize(closed, [
      { label: `VIX < ${vixSeuil}`, test: (t) => t.vix_a_entree != null && t.vix_a_entree < vixSeuil },
      { label: `VIX ≥ ${vixSeuil}`, test: (t) => t.vix_a_entree != null && t.vix_a_entree >= vixSeuil },
    ]),
    parRsi: bucketize(closed, [
      { label: `RSI ≤ ${rsiHaut}`, test: (t) => t.rsi_a_entree != null && t.rsi_a_entree <= rsiHaut },
      { label: `RSI > ${rsiHaut} (surachat)`, test: (t) => t.rsi_a_entree != null && t.rsi_a_entree > rsiHaut },
    ]),
    parObv: bucketize(closed, [
      { label: 'Accumulation', test: (t) => t.obv_a_entree === 'accumulation' },
      { label: 'Neutre', test: (t) => t.obv_a_entree === 'neutre' },
      { label: 'Distribution', test: (t) => t.obv_a_entree === 'distribution' },
    ]),
    parChecklist: bucketize(closed, [
      { label: 'Checklist complétée', test: (t) => t.checklist_complete === 1 },
      { label: 'Checklist incomplète', test: (t) => t.checklist_complete === 0 },
    ]),
    parCorrelation: bucketize(closed, [
      { label: 'Corrélation signalée', test: (t) => t.correlation_flag === 1 },
      { label: 'Pas de corrélation', test: (t) => t.correlation_flag === 0 },
    ]),
    // « Le score prédit-il le R ? » (feature #376, 30/9/2026) — seuls les trades
    // PRÉPARÉS depuis le screening portent un score (setup_score & co.) ; les
    // autres tombent hors de tous ces groupes, jamais dans un groupe « 0 ».
    // Seuils = ceux de scoring.js (SIGNAL_AGE : frais ≤ 5, ancien > 20 séances).
    parSetup: bucketize(closed, [
      { label: 'Setup ≥ 4', test: (t) => t.setup_score != null && t.setup_score >= 4 },
      { label: 'Setup 2–3', test: (t) => t.setup_score != null && t.setup_score >= 2 && t.setup_score < 4 },
      { label: 'Setup ≤ 1', test: (t) => t.setup_score != null && t.setup_score < 2 },
    ]),
    parContexte: bucketize(closed, [
      { label: 'Contexte ≥ 2', test: (t) => t.contexte_score != null && t.contexte_score >= 2 },
      { label: 'Contexte 0–1', test: (t) => t.contexte_score != null && t.contexte_score >= 0 && t.contexte_score < 2 },
      { label: 'Contexte < 0', test: (t) => t.contexte_score != null && t.contexte_score < 0 },
    ]),
    parAlignement: bucketize(closed, [
      { label: 'Aligné à l\'entrée', test: (t) => t.alignement_a_entree === 'haussier' },
      { label: 'Non aligné à l\'entrée', test: (t) => t.alignement_a_entree != null && t.alignement_a_entree !== 'haussier' },
    ]),
    parAgeSignal: bucketize(closed, [
      { label: 'Signal frais (≤ 5 séances)', test: (t) => t.signal_age_a_entree != null && t.signal_age_a_entree <= 5 },
      { label: 'Signal moyen (6–20)', test: (t) => t.signal_age_a_entree != null && t.signal_age_a_entree > 5 && t.signal_age_a_entree <= 20 },
      { label: 'Signal ancien (> 20)', test: (t) => t.signal_age_a_entree != null && t.signal_age_a_entree > 20 },
    ]),
    avecScore: closed.filter((t) => t.setup_score != null || t.contexte_score != null).length,
    echantillonMin: 30,
    parCompte: bucketize(closed, [
      { label: 'RRSP', test: (t) => t.compte === 'RRSP' },
      { label: 'margin', test: (t) => t.compte === 'margin' },
      { label: 'corporatif', test: (t) => t.compte === 'corporatif' },
    ]),
  };
}
