// Instantanés du balayage S&P 500 poussés vers la version en ligne (17/10/2026).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildSweepSnapshot, validateSnapshot, snapshotStale, nyDate, screeningFromSnapshot, ROW_FIELDS } from '../cloud/src/lib/snapshots.js';
import { parsePublishConfig } from './snapshot-publish.js';

const NOW = new Date('2026-10-16T22:30:00Z'); // vendredi 18 h 30 à New York
const row = (t, extra = {}) => ({ ticker: t, verdict: 'prêt', setupScore: 3, contexteScore: 2, rsi: 58.123456, smaAlignment: 'haussier', alignmentAge: 2, price: 101.5, forceRelative: 4.2, goldenCross: true, obvTrend: 'accumulation', atr: 2.3, daysToEarnings: 12, peRatio: 30, industry: 'Software', setupParts: [1, 2], secret: 'x', ...extra });
const sample = () => buildSweepSnapshot({
  payload: { rows: [row('AAPL'), row('BRK-B', { verdict: 'à surveiller', rsi: null })], universeSize: 503, retainedSize: 2 },
  news: { baseline: false, nouveautes: ['AAPL'], sorties: ['MSFT'], ready: ['AAPL'], day: 'x' },
  sectors: [{ sector: 'Information Technology', label: 'Technologie', total: 70, pret: ['AAPL'], surveiller: [], autres: 0, pretCount: 1 }],
  sectorOf: new Map([['AAPL', 'Information Technology'], ['BRK-B', 'Financials']]),
  computedAt: NOW, source: 'yahoo',
});
const bytes = (o) => Buffer.byteLength(JSON.stringify(o));

test('buildSweepSnapshot : garde seulement les champs prévus, arrondis, secteur du référentiel', () => {
  const s = sample();
  assert.equal(s.date, '2026-10-16');
  assert.deepEqual(Object.keys(s.rows[0]).sort(), Object.keys(ROW_FIELDS).sort());
  assert.equal(s.rows[0].rsi, 58.1235);
  assert.equal(s.rows[1].sector, 'Financials');
  assert.equal(s.rows[1].rsi, null);
  assert.equal('peRatio' in s.rows[0], false);
  assert.deepEqual(s.news, { baseline: false, nouveautes: ['AAPL'], sorties: ['MSFT'] });
  assert.deepEqual(Object.keys(s.sectors[0]).sort(), ['autres', 'label', 'pret', 'sector', 'surveiller', 'total']);
});

test('validateSnapshot accepte l\'instantané construit', () => {
  const s = sample();
  assert.doesNotThrow(() => validateSnapshot('sp500_sweep', s, bytes(s), NOW));
  // Aller-retour JSON : c'est ce que reçoit le Worker
  const back = JSON.parse(JSON.stringify(s));
  assert.doesNotThrow(() => validateSnapshot('sp500_sweep', back, bytes(back), NOW));
});

test('validateSnapshot refuse forme, taille, type et dates incohérents', () => {
  const bad = (mut, kind = 'sp500_sweep', size) => { const s = sample(); mut(s); return () => validateSnapshot(kind, s, size ?? bytes(s), NOW); };
  assert.throws(bad(() => {}, 'autre'), /inconnu/);
  assert.throws(bad(() => {}, 'sp500_sweep', 300_001), /trop gros/);
  assert.throws(bad(() => {}, 'sp500_sweep', 0), /vide/);
  assert.throws(bad((s) => { s.extra = 1; }), /champ inconnu/);
  assert.throws(bad((s) => { s.rows[0].peRatio = 3; }), /champ inconnu/);
  assert.throws(bad((s) => { delete s.rows[0].rsi; }), /manquant/);
  assert.throws(bad((s) => { s.rows[0].ticker = '<script>'; }), /invalide/);
  assert.throws(bad((s) => { s.rows[0].verdict = 'acheter'; }), /invalide/);
  assert.throws(bad((s) => { s.rows[0].rsi = 'NaN'; }), /invalide/);
  assert.throws(bad((s) => { s.v = 2; }), /Version/);
  assert.throws(bad((s) => { s.kind = 'x'; }), /type du corps/);
  assert.throws(bad((s) => { s.date = '2026-10-15'; }), /date/);
  assert.throws(bad((s) => { s.computedAt = '2026-10-18T00:00:00Z'; s.date = '2026-10-17'; }), /futur/);
  assert.throws(bad((s) => { s.retainedSize = 600; }), /retainedSize/);
  assert.throws(bad((s) => { s.sectors[0].pret = ['a b']; }), /symbole/);
  assert.throws(bad((s) => { s.news.baseline = 'non'; }), /booléen/);
  assert.throws(() => validateSnapshot('sp500_sweep', [], 10, NOW), /objet/);
});

test('snapshotStale : plus d\'un jour ouvrable', () => {
  assert.equal(snapshotStale('2026-10-16', new Date('2026-10-17T15:00:00Z')), false); // samedi
  assert.equal(snapshotStale('2026-10-16', new Date('2026-10-19T15:00:00Z')), false); // lundi
  assert.equal(snapshotStale('2026-10-16', new Date('2026-10-20T15:00:00Z')), true);  // mardi
  assert.equal(snapshotStale('2026-10-14', new Date('2026-10-15T20:00:00Z')), false);
  assert.equal(snapshotStale('2026-10-14', new Date('2026-10-16T20:00:00Z')), true);
  assert.equal(nyDate(new Date('2026-10-17T02:00:00Z')), '2026-10-16'); // 22 h à New York
});

test('screeningFromSnapshot : forme attendue par le Screener, avec sa date', () => {
  const r = screeningFromSnapshot(sample(), new Date('2026-10-20T15:00:00Z'));
  assert.equal(r.universe, 'sp500');
  assert.equal(r.rows.length, 2);
  assert.equal(r.snapshot.stale, true);
  assert.equal(r.snapshot.date, '2026-10-16');
  assert.ok(r.cacheAgeSeconds > 3 * 86400);
});

test('parsePublishConfig : https seulement, http vers localhost, jamais le mot de passe en clair', () => {
  assert.equal(parsePublishConfig({ url: '', user: 'a', password: 'b' }).ok, false);
  assert.equal(parsePublishConfig({ url: 'http://exemple.com', user: 'a', password: 'b' }).ok, false);
  const local = parsePublishConfig({ url: 'http://127.0.0.1:8787/', user: 'a', password: 'b' });
  assert.equal(local.ok, true);
  assert.equal(local.base, 'http://127.0.0.1:8787');
  const prod = parsePublishConfig({ url: 'https://castellana.iechocreator.workers.dev', user: 'jp', password: 's3cret' });
  assert.equal(prod.host, 'castellana.iechocreator.workers.dev');
  assert.equal(prod.auth, 'Basic ' + Buffer.from('jp:s3cret').toString('base64'));
});
