@echo off
REM installer-sidecar.bat — installation OPTIONNELLE du sidecar Python
REM (Windows, 7/9/2026). Miroir de installer-sidecar.command.
REM
REM castellana n'a PAS besoin de ce composant : depuis le 7/9/2026, RSI,
REM SMA 50/200, Golden Cross, VIX et cotations sont calcules par l'app
REM elle-meme depuis Yahoo Finance. Ce script n'existe que pour comparer
REM les deux sources. Pour revenir en arriere : remettre "enabled": false
REM dans settings.json et supprimer le dossier .venv-mcp.
REM
REM NON TESTE sur une vraie machine Windows.

setlocal enabledelayedexpansion
cd /d "%~dp0"

echo === castellana - sidecar tradingview-mcp ^(OPTIONNEL^) ===
echo.
echo [!] Ce composant n'est pas necessaire au fonctionnement de castellana.
echo     Il ajoute ~170 Mo et un second processus a maintenir en vie.
echo.
set /p REPONSE="Installer quand meme ? [o/N] "
if /i not "!REPONSE!"=="o" (
  echo Annule - rien n'a ete modifie.
  pause
  exit /b 0
)
echo.

set PYTHON_CMD=
where python >nul 2>nul && set PYTHON_CMD=python
if not defined PYTHON_CMD (
  where python3 >nul 2>nul && set PYTHON_CMD=python3
)
if not defined PYTHON_CMD (
  echo [X] Python introuvable. Ouverture de la page de telechargement...
  start https://www.python.org/downloads/windows/
  pause
  exit /b 1
)
echo [OK] Python detecte.

if not exist ".venv-mcp\Scripts\tradingview-mcp.exe" (
  echo Installation du sidecar ^(~170 Mo^)...
  !PYTHON_CMD! -m venv .venv-mcp
  call .venv-mcp\Scripts\pip install --quiet tradingview-mcp-server
)
if not exist ".venv-mcp\Scripts\tradingview-mcp.exe" (
  echo [X] L'installation a echoue. castellana continue de fonctionner sans.
  pause
  exit /b 1
)
echo [OK] Sidecar installe.

node -e "const fs=require('fs');const s=JSON.parse(fs.readFileSync('settings.json','utf8'));s.tradingviewMcp.enabled=true;fs.writeFileSync('settings.json',JSON.stringify(s,null,2)+'\n');console.log('[OK] settings.json : sidecar active.');"
echo.
echo Il faut maintenant DEUX processus :
echo   1. npm start        ^(castellana^)
echo   2. npm run sidecar  ^(ce sidecar, dans une seconde fenetre^)
echo.
pause
endlocal
