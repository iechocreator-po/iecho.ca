// API d'administration des comptes (19/9/2026) — consommée par la console
// CRUD de bilbao (feature-factory/server/castellana-users.js), jamais par
// le navigateur d'un testeur castellana. Protégée par HTTP Basic Auth avec
// un secret DISTINCT de celui de telemetry-worker (ADMIN_USER/
// ADMIN_PASSWORD, `wrangler secret put`) — bilbao n'est pas un testeur
// connecté, une session castellana n'a aucun sens ici.
//
// Montée sur /api/admin/* AVANT le middleware de session général
// (index.js) — /api/admin/ est dans PUBLIC_PREFIXES pour que ce dernier ne
// l'intercepte pas une seconde fois, cette route a sa PROPRE vérification.

import { hashPassword } from '../auth.js';
import { LABO_SCHEMA, listAllUsersOverrides } from '../db/labo-params.js';
import { yahooFinance } from '../lib/yahoo.js';
import { readCache } from '../db/cache.js';
import { listAllUsersLists } from '../db/lists.js';
import { listFlagsAdmin, setFlag, listAllUsersFlagOverrides, setUserFlag, KNOWN_USER_FLAGS } from '../db/flags.js';
import { listConceptsAdmin, saveConcept, resetConcept } from '../db/concepts.js';
import { listAnticipationAdmin } from '../db/anticipation.js';
import { listUsers, createUser, updateUser, setDisabled, disableUserAndRevoke, resetPasswordAndRevoke, findUserByUsername } from '../db/users.js';

// Comparaison à temps constant, même principe que verifyPassword côté
// auth.js — évite qu'une différence de timing sur la comparaison ne fuite
// d'information, même pour un secret à usage interne uniquement.
function timingSafeEqual(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function checkAdminAuth(request, env) {
  const header = request.headers.get('Authorization');
  if (!header || !header.startsWith('Basic ')) return false;
  let decoded;
  try {
    decoded = atob(header.slice(6));
  } catch {
    return false;
  }
  const sep = decoded.indexOf(':');
  if (sep === -1) return false;
  const user = decoded.slice(0, sep);
  const pass = decoded.slice(sep + 1);
  return Boolean(env.ADMIN_USER) && Boolean(env.ADMIN_PASSWORD)
    && timingSafeEqual(user, env.ADMIN_USER) && timingSafeEqual(pass, env.ADMIN_PASSWORD);
}

export function registerAdminAuthMiddleware(app) {
  app.use('/api/admin/*', async (c, next) => {
    if (!checkAdminAuth(c.req.raw, c.env)) {
      return c.text('Authentification requise.', 401, { 'WWW-Authenticate': 'Basic realm="castellana admin"' });
    }
    await next();
  });
}

// Génère un mot de passe temporaire — n'est JAMAIS stocké en clair (haché
// immédiatement via hashPassword, même PBKDF2 que le reste de l'app) ni
// loggé ; il n'existe que dans la réponse HTTP à bilbao, qui l'affiche une
// fois à JP puis ne le garde pas.
function generateTempPassword() {
  const bytes = crypto.getRandomValues(new Uint8Array(9));
  return btoa(String.fromCharCode(...bytes)).replace(/[+/=]/g, '').slice(0, 12);
}

export function registerAdminRoutes(app) {
  // Diagnostic Yahoo Finance DEPUIS le Worker (20/9/2026) — lecture seule, admin.
  // Répond à « le problème vient-il de l'app, de Cloudflare ou de Yahoo ? » avec des
  // mesures prises sur le vrai réseau de production, étape par étape : appel brut
  // (réseau + Yahoo), puis la bibliothèque (historique sans jeton, cotation avec jeton),
  // plus l'état du jeton partagé en cache. Aucune donnée personnelle.
  app.get('/api/admin/yahoo', async (c) => {
    const step = async (fn) => {
      const start = Date.now();
      try { const v = await Promise.race([fn(), new Promise((_, r) => setTimeout(() => r(new Error('délai 8000 ms')), 8000))]); return { ok: true, ms: Date.now() - start, ...(v || {}) }; }
      catch (e) { return { ok: false, ms: Date.now() - start, erreur: String(e?.message).slice(0, 220) }; }
    };
    const UA = { 'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/124 Safari/537.36' };
    const jar = await readCache(c.env.DB, 'yahoo:cookiejar:v1').catch(() => null);
    const period1 = new Date(Date.now() - 5 * 24 * 3600 * 1000);
    return c.json({
      colo: c.req.raw.cf?.colo ?? null,
      jarPartage: jar?.hit ? { present: true, ageSecondes: Math.round(jar.ageSeconds), crumb: !!jar.value?.cookies?.some((k) => k.key === 'crumb') } : { present: false },
      appelBrutChart: await step(async () => { const r = await fetch('https://query1.finance.yahoo.com/v8/finance/chart/SPY?range=5d&interval=1d', { headers: UA }); return { http: r.status }; }),
      appelBrutCookie: await step(async () => { const r = await fetch('https://fc.yahoo.com', { headers: UA, redirect: 'manual' }); return { http: r.status }; }),
      bibliothequeChart: await step(async () => { await yahooFinance.chart('SPY', { period1, interval: '1d' }); }),
      bibliothequeQuote: await step(async () => { await yahooFinance.quote('SPY'); }),
    });
  });

  // Watchlists et listes personnalisées du Screener de tous les comptes
  // (20/9/2026) — lecture seule, consommée par l'onglet « Watchlists » de bilbao.
  app.get('/api/admin/watchlists', async (c) => c.json({ users: await listAllUsersLists(c.env.DB) }));

  // Feature flags et onglet Concepts (20/9/2026) — pilotés depuis bilbao.
  // Les flags sont GLOBAUX ; les textes modifiés aussi (ce que voient tous les
  // testeurs). Les testeurs, eux, ne font que LIRE (routes/flags.js).
  const statusOf = (err) => (['UNKNOWN_FLAG', 'UNKNOWN_CONCEPT'].includes(err.code) ? 404
    : ['INVALID_FLAG', 'INVALID_CONCEPT'].includes(err.code) ? 400 : 500);

  app.get('/api/admin/flags', async (c) => c.json({ flags: await listFlagsAdmin(c.env.DB) }));

  app.put('/api/admin/flags/:key', async (c) => {
    const body = await c.req.json().catch(() => ({}));
    try {
      return c.json({ flags: await setFlag(c.env.DB, c.req.param('key'), body.enabled) });
    } catch (err) {
      return c.json({ error: err.message }, statusOf(err));
    }
  });

  // Surcharges par compte (22/9/2026) — Comptes castellana (bilbao) peut
  // forcer options_a_tab/journal_a_tab ON/OFF pour un testeur précis, sans
  // toucher au réglage global. `overrides` : { userId: { key: bool } }.
  app.get('/api/admin/user-flags', async (c) => c.json({
    keys: Object.fromEntries(Object.entries(KNOWN_USER_FLAGS).map(([k, v]) => [k, v.label])),
    overrides: await listAllUsersFlagOverrides(c.env.DB),
  }));

  // body.enabled : true|false pour forcer, null (ou absent) pour réinitialiser.
  app.put('/api/admin/users/:id/flags/:key', async (c) => {
    const body = await c.req.json().catch(() => ({}));
    const enabled = body.enabled === undefined ? null : body.enabled;
    try {
      return c.json({ overrides: await setUserFlag(c.env.DB, Number(c.req.param('id')), c.req.param('key'), enabled) });
    } catch (err) {
      return c.json({ error: err.message }, statusOf(err));
    }
  });

  // Anticipation (12/10/2026) — lecture seule pour bilbao : propositions et votes par carte.
  app.get('/api/admin/anticipation', async (c) => c.json(await listAnticipationAdmin(c.env.DB)));

  app.get('/api/admin/concepts', async (c) => c.json({ concepts: await listConceptsAdmin(c.env.DB) }));

  app.put('/api/admin/concepts/:id', async (c) => {
    const body = await c.req.json().catch(() => ({}));
    try {
      return c.json({ concepts: await saveConcept(c.env.DB, c.req.param('id'), body) });
    } catch (err) {
      return c.json({ error: err.message }, statusOf(err));
    }
  });

  app.post('/api/admin/concepts/:id/reset', async (c) => {
    try {
      return c.json({ concepts: await resetConcept(c.env.DB, c.req.param('id')) });
    } catch (err) {
      return c.json({ error: err.message }, statusOf(err));
    }
  });

  // Stratégies d'options paramétrées par les testeurs (19/9/2026) — lecture
  // seule, consommée par l'onglet « Stratégies options » de bilbao. Ne
  // renvoie que les SURCHARGES (jamais rien de sensible : ni mot de passe, ni
  // e-mail) ; le schéma sert à afficher le défaut à côté de chaque valeur.
  app.get('/api/admin/strategies', async (c) => {
    return c.json({ strategies: await listAllUsersOverrides(c.env.DB), schemaVersion: LABO_SCHEMA.version });
  });

  app.get('/api/admin/strategies/schema', (c) => {
    return c.json({ schema: LABO_SCHEMA });
  });

  app.get('/api/admin/users', async (c) => {
    return c.json({ users: await listUsers(c.env.DB) });
  });

  app.post('/api/admin/users', async (c) => {
    const body = await c.req.json().catch(() => ({}));
    const username = typeof body.username === 'string' ? body.username.trim().toLowerCase() : '';
    const email = typeof body.email === 'string' ? body.email.trim() : '';
    if (!/^[a-z0-9._-]{2,30}$/.test(username)) {
      return c.json({ error: 'Nom d\'utilisateur invalide : 2 à 30 caractères parmi lettres, chiffres, point, tiret, tiret bas (les majuscules sont converties en minuscules).' }, 400);
    }
    if (await findUserByUsername(c.env.DB, username)) {
      return c.json({ error: `Le nom "${username}" est déjà pris` }, 409);
    }
    const tempPassword = generateTempPassword();
    const { hash, salt } = await hashPassword(tempPassword);
    const user = await createUser(c.env.DB, username, hash, salt, email || null);
    return c.json({ user: { id: user.id, username: user.username, email: user.email }, tempPassword }, 201);
  });

  app.patch('/api/admin/users/:id', async (c) => {
    const id = Number(c.req.param('id'));
    const body = await c.req.json().catch(() => ({}));
    const patch = {};
    if (typeof body.username === 'string') {
      if (!/^[a-z0-9._-]{2,30}$/.test(body.username.trim().toLowerCase())) {
        return c.json({ error: 'Nom d\'utilisateur invalide : 2 à 30 caractères parmi lettres, chiffres, point, tiret, tiret bas (les majuscules sont converties en minuscules).' }, 400);
      }
      patch.username = body.username.trim().toLowerCase();
    }
    if (typeof body.email === 'string') patch.email = body.email.trim();
    const user = await updateUser(c.env.DB, id, patch);
    if (!user) return c.json({ error: 'Compte introuvable' }, 404);
    return c.json({ user: { id: user.id, username: user.username, email: user.email, disabled: user.disabled } });
  });

  app.post('/api/admin/users/:id/disable', async (c) => {
    // Désactiver = plus d'accès du tout : sessions déjà ouvertes fermées, liens de connexion invalidés (db/users.js).
    const result = await disableUserAndRevoke(c.env.DB, Number(c.req.param('id')));
    if (!result) return c.json({ error: 'Compte introuvable' }, 404);
    return c.json({ ok: true, disabled: true, sessionsClosed: result.sessionsClosed });
  });

  app.post('/api/admin/users/:id/enable', async (c) => {
    const user = await setDisabled(c.env.DB, Number(c.req.param('id')), false);
    if (!user) return c.json({ error: 'Compte introuvable' }, 404);
    return c.json({ ok: true, disabled: false });
  });

  app.post('/api/admin/users/:id/reset-password', async (c) => {
    const id = Number(c.req.param('id'));
    const user = await c.env.DB.prepare('SELECT id FROM users WHERE id = ?').bind(id).first();
    if (!user) return c.json({ error: 'Compte introuvable' }, 404);
    const tempPassword = generateTempPassword();
    const { hash, salt } = await hashPassword(tempPassword);
    const sessionsClosed = await resetPasswordAndRevoke(c.env.DB, id, hash, salt); // ferme aussi les sessions et liens ouverts (db/users.js)
    return c.json({ ok: true, tempPassword, sessionsClosed });
  });
}
