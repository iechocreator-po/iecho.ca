// js/backtest-tab.js — carte « Backtest du signal d'alignement » de l'onglet
// Screener (feature #375, 30/9/2026). LOCAL UNIQUEMENT. Voir server/backtest.js
// pour les règles exactes de la simulation et ses limites.

const btEsc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const btR = (v) => (v == null ? '—' : (v >= 0 ? '+' : '') + v.toFixed(2) + ' R');
const btPct = (v) => (v == null ? '—' : (v * 100).toFixed(0) + ' %');
const btN = (v, d = 1) => (v == null ? '—' : Number(v).toFixed(d));

function btListOptions() {
  const lists = (typeof customLists !== 'undefined' ? customLists : []).map((l) => `<option value="list:${l.id}">${btEsc(l.nom)}</option>`).join('');
  return `<option value="watchlist">Ma watchlist</option><option value="mag7">MAG7</option><option value="elargi">Univers élargi (long)</option>${lists}`;
}

function btMsg(text, kind) {
  const el = document.getElementById('bt-msg');
  el.textContent = text || '';
  el.style.color = kind === 'err' ? 'var(--red)' : 'var(--text-2)';
}

function btRow(label, s) {
  return `<tr><td>${btEsc(label)}</td><td>${s.n}</td><td>${btPct(s.winRate)}</td><td>${btR(s.avgR)}</td><td>${btR(s.totalR)}</td><td>${btN(s.profitFactor, 2)}</td><td>${btN(s.maxDrawdownR)}</td></tr>`;
}

function btCmpRow(label, s, hint) {
  return s ? `<tr><td title="${btEsc(hint)}">${btEsc(label)}</td><td>${s.n}</td><td>${btPct(s.winRate)}</td><td>${btR(s.avgR)}</td><td>${btR(s.totalR)}</td><td>${btN(s.profitFactor, 2)}</td><td>${btN(s.maxDrawdownR)}</td></tr>` : '';
}
// Le même signal lu trois fois : brut, avec frais et glissement, puis avec le filtre de régime.
function btComparison(d) {
  const c = d.comparison, r = d.realism;
  if (!c) return '';
  const regimeTxt = r.regime ? `SPY > SMA ${r.regimeSma}${r.vixMax ? ` et VIX ≤ ${r.vixMax}` : ''}` : null;
  return `<div class="section-title" style="margin-top:8px;">Même signal, trois lectures</div>
    <div style="overflow-x:auto"><table class="ds-table"><thead><tr><th>Lecture</th><th>Trades</th><th>Réussite</th><th>R moyen</th><th>R total</th><th>Fact. profit</th><th>Creux (R)</th></tr></thead><tbody>
      ${btCmpRow('1 · Brut (ni frais ni filtre)', c.gross, 'Simulation idéale du design doc')}
      ${btCmpRow(`2 · Avec frais et glissement (${btN(r.costPct, 2)} % / côté)`, c.costed, 'Chaque entrée est payée plus cher, chaque sortie encaissée moins cher')}
      ${regimeTxt ? btCmpRow(`3 · Avec frais + filtre de régime (${regimeTxt})`, c.filtered, 'Les signaux hors régime sont ignorés') : '<tr><td colspan="7" class="ds-text-muted">Filtre de régime désactivé : coche-le pour comparer.</td></tr>'}
    </tbody></table></div>
    <p class="metric-sub" style="text-align:left;">Les mesures ci-dessous (secteurs, détail par titre) suivent la lecture ${regimeTxt ? '3' : '2'}. Le biais du survivant reste : ces listes sont celles d'aujourd'hui.</p>`;
}

function btRender(d) {
  const o = d.overall;
  const warn = o.n === 0
    ? 'Aucun trade simulé sur cette période et cette liste.'
    : (o.enough ? '' : `⚠️ Seulement ${o.n} trade(s) : sous le seuil de ${d.minTrades}, ce n'est pas assez pour conclure quoi que ce soit.`);
  document.getElementById('bt-result').innerHTML = `
    <div class="metric-band" style="--cols:6;">
      <div class="ds-metric"><div class="ds-metric__label">Trades</div><div class="ds-metric__value">${o.n}</div></div>
      <div class="ds-metric"><div class="ds-metric__label">Réussite</div><div class="ds-metric__value">${btPct(o.winRate)}</div></div>
      <div class="ds-metric"><div class="ds-metric__label">R moyen</div><div class="ds-metric__value">${btR(o.avgR)}</div></div>
      <div class="ds-metric"><div class="ds-metric__label">R total</div><div class="ds-metric__value">${btR(o.totalR)}</div></div>
      <div class="ds-metric"><div class="ds-metric__label">Facteur de profit</div><div class="ds-metric__value">${btN(o.profitFactor, 2)}</div></div>
      <div class="ds-metric"><div class="ds-metric__label">Pire creux</div><div class="ds-metric__value">${btN(o.maxDrawdownR)} R</div></div>
    </div>
    ${btComparison(d)}
    ${warn ? `<p class="metric-sub" style="text-align:left;color:var(--amber);">${warn}</p>` : ''}
    <p class="metric-sub" style="text-align:left;">${d.tickersTested} titre(s) testé(s) sur ${d.years} an(s) · SMA ${d.periods.fast}/${d.periods.medium}/${d.periods.slow} · stop ${d.atrMult} × ATR · durée moyenne ${btN(o.avgBars, 0)} séances · ${o.stops} sortie(s) au stop${d.errors.length ? ` · ${d.errors.length} titre(s) sans historique (${d.errors.slice(0, 3).map((e) => btEsc(e.ticker)).join(', ')}${d.errors.length > 3 ? '…' : ''})` : ''}${d.openPositions.length ? ` · ${d.openPositions.length} position(s) encore ouverte(s), non comptées` : ''}.</p>
    <div style="overflow-x:auto"><table class="ds-table"><thead><tr><th>Secteur</th><th>Trades</th><th>Réussite</th><th>R moyen</th><th>R total</th><th>Fact. profit</th><th>Creux (R)</th></tr></thead>
      <tbody>${d.bySector.map((s) => btRow(s.sector, s)).join('') || '<tr><td colspan="7">—</td></tr>'}</tbody></table></div>
    <details style="margin-top:8px;"><summary class="metric-sub" style="cursor:pointer;">Détail par titre (${d.perTicker.length})</summary>
      <div style="overflow-x:auto"><table class="ds-table"><thead><tr><th>Symbole</th><th>Trades</th><th>Réussite</th><th>R moyen</th><th>R total</th><th>Fact. profit</th><th>Creux (R)</th></tr></thead>
      <tbody>${d.perTicker.map((s) => btRow(s.ticker, s)).join('')}</tbody></table></div></details>`;
}

async function btRun(btn) {
  const universe = document.getElementById('bt-universe').value;
  const atrMult = Number(document.getElementById('bt-atr').value);
  const years = Number(document.getElementById('bt-years').value);
  btn.disabled = true;
  btMsg(universe === 'elargi' ? 'Simulation en cours (univers élargi : compte quelques dizaines de secondes)…' : 'Simulation en cours…');
  document.getElementById('bt-result').innerHTML = '';
  try {
    const q = new URLSearchParams({ universe, atrMult, years,
      fees: document.getElementById('bt-fees').value || 0, slippage: document.getElementById('bt-slip').value || 0,
      regime: document.getElementById('bt-regime').checked ? '1' : '0', regimeSma: document.getElementById('bt-regime-sma').value || 200, vixMax: document.getElementById('bt-vix').value || 0 });
    const d = await fetchJSON(`/api/backtest?${q}`);
    btMsg('');
    btRender(d);
  } catch (err) { btMsg(err.message, 'err'); }
  btn.disabled = false;
}

function initBacktestTab() {
  if (!document.getElementById('bt-card')) return;
  document.getElementById('bt-universe').innerHTML = btListOptions();
  document.getElementById('bt-run').addEventListener('click', (e) => btRun(e.target));
}
