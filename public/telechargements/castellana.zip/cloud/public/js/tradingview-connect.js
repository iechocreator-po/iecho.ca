// js/tradingview-connect.js — Réglages → TradingView, « Option 3 » (feature
// #367, 30/9/2026). VERSION CLOUD SEULEMENT (les sessions et les jetons
// n'existent pas en local). Derrière le flag tradingview_connect : sans lui,
// la carte garde son texte « pas encore disponible ».
//
// Étape 1 : connexion OAuth, import des watchlists dans les listes du Screener,
// choix de la source de données (Yahoo par défaut). TradingView n'est utilisé
// que pour les watchlists — les cotations et indicateurs restent Yahoo, et
// l'interface le dit.

const tvEsc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let tvState = { connected: false, dataSource: 'yahoo' };

// Indicateur de source (étape 2) : l'en-tête X-Data-Source de chaque réponse dit d'où sont
// venues les données. Absent = rien à signaler (source Yahoo). Appelé par fetchJSON.
const TV_BADGES = {
  tradingview: ['Données : TradingView', 'ds-badge--success'],
  mixed: ['Données : TradingView + Yahoo (repli partiel)', 'ds-badge--warning'],
  'yahoo-fallback': ['Données : Yahoo (TradingView indisponible)', 'ds-badge--warning'],
};
function tvNoteSource(value) {
  let el = document.getElementById('tv-source-badge');
  const def = TV_BADGES[value];
  if (!def) { if (value === 'yahoo' && el) el.remove(); return; }
  if (!el) {
    const bar = document.querySelector('.status-bar') || document.querySelector('header');
    if (!bar) return;
    el = document.createElement('span');
    el.id = 'tv-source-badge';
    bar.appendChild(el);
  }
  el.className = `ds-badge ${def[1]}`;
  el.textContent = def[0];
  el.title = 'Source des cotations et de l\'historique de la dernière requête. Choix dans Réglages → TradingView.';
}

function tvSetMsg(text, kind) {
  const el = document.getElementById('tv-msg');
  if (!el) return;
  el.textContent = text || '';
  el.style.color = kind === 'err' ? 'var(--red)' : kind === 'ok' ? 'var(--green)' : 'var(--text-2)';
}

function renderTvCard() {
  const body = document.getElementById('tv-connect-body');
  if (!body) return;
  const c = tvState.connected;
  body.innerHTML = `
    <p class="metric-sub" style="text-align:left;">Connecte ton compte TradingView pour importer tes <strong>watchlists</strong> comme listes du Screener. Lecture seule : castellana ne modifie rien chez TradingView, et ton jeton est attaché à ta session (effacé à la déconnexion).</p>
    <p class="metric-sub" style="text-align:left;"><strong>État :</strong> ${c ? '<span class="ds-badge ds-badge--success">connecté</span>' : '<span class="ds-badge">non connecté</span>'}
      <button type="button" class="ds-btn ds-btn--sm" id="tv-toggle" style="margin-left:8px;">${c ? 'Déconnecter' : 'Connecter TradingView'}</button></p>
    <div class="section-title" style="margin-top:12px;">Source des données</div>
    <div class="row" style="gap:16px; flex-wrap:wrap;">
      <label style="width:auto;"><input type="radio" name="tv-source" value="yahoo" ${tvState.dataSource === 'yahoo' ? 'checked' : ''}> Yahoo Finance <span class="ds-text-muted">(défaut)</span></label>
      <label style="width:auto;"><input type="radio" name="tv-source" value="tradingview" ${tvState.dataSource === 'tradingview' ? 'checked' : ''} ${c ? '' : 'disabled'}> TradingView</label>
    </div>
    <p class="metric-sub" style="text-align:left;">Avec <strong>TradingView</strong>, les <strong>cotations</strong> et l'<strong>historique quotidien</strong> (donc les indicateurs calculés dessus) viennent de TradingView. Les fondamentaux, les chaînes d'options et les secteurs restent sur Yahoo. Si TradingView échoue ou limite les requêtes (429), castellana bascule seul sur Yahoo et l'indique dans l'en-tête. Données différées d'environ 15 minutes, comme Yahoo.</p>
    ${c ? `<div class="section-title" style="margin-top:12px;">Mes watchlists TradingView</div>
      <button type="button" class="ds-btn ds-btn--sm" id="tv-load">Charger mes watchlists</button>
      <div id="tv-lists" style="margin-top:8px;"></div>` : ''}
    <p class="metric-sub" id="tv-msg" style="text-align:left;"></p>`;

  document.getElementById('tv-toggle').addEventListener('click', c ? tvDisconnect : tvConnect);
  body.querySelectorAll('input[name="tv-source"]').forEach((r) => r.addEventListener('change', () => tvSetSource(r.value)));
  if (c) document.getElementById('tv-load').addEventListener('click', tvLoadWatchlists);
}

async function tvRefresh() {
  const st = await fetchJSON('/api/tradingview/status');
  tvState = { connected: st.connected, dataSource: st.dataSource };
  return st;
}

async function tvConnect() {
  tvSetMsg('Redirection vers TradingView…');
  try {
    const { url } = await fetchJSON('/api/tradingview/connect', { method: 'POST' });
    window.location.href = url; // le retour se fait sur /?tv=ok|refuse|erreur
  } catch (err) { tvSetMsg(err.message, 'err'); }
}

async function tvDisconnect() {
  try {
    await fetchJSON('/api/tradingview/disconnect', { method: 'POST' });
    await tvRefresh(); renderTvCard(); tvSetMsg('Déconnecté. Ton jeton a été effacé.', 'ok');
  } catch (err) { tvSetMsg(err.message, 'err'); }
}

async function tvSetSource(source) {
  try {
    await fetchJSON('/api/data-source', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ source }) });
    tvState.dataSource = source;
    if (source === 'yahoo') tvNoteSource('yahoo');
    tvSetMsg(source === 'tradingview' ? 'Source : TradingView pour les cotations et l\'historique (repli automatique sur Yahoo en cas d\'échec). Recharge les données pour l\'appliquer.' : 'Source : Yahoo Finance.', 'ok');
  } catch (err) { tvSetMsg(err.message, 'err'); await tvRefresh(); renderTvCard(); }
}

async function tvLoadWatchlists() {
  const host = document.getElementById('tv-lists');
  host.textContent = 'Chargement…';
  try {
    const { watchlists } = await fetchJSON('/api/tradingview/watchlists');
    if (!watchlists.length) { host.textContent = 'Aucune watchlist trouvée.'; return; }
    host.innerHTML = `<table class="ds-table"><thead><tr><th>Nom</th><th>Importables</th><th>Ignorés</th><th></th></tr></thead><tbody>${
      watchlists.map((w) => `<tr>
        <td>${tvEsc(w.name)}${w.active ? ' <span class="ds-badge">active</span>' : ''}</td>
        <td>${w.importable}${w.truncated ? ` <span class="ds-text-muted" title="Plafond de 50 titres par liste">(+${w.truncated} au-delà du plafond)</span>` : ''}</td>
        <td title="Crypto, forex, futures, indices et bourses non prises en charge">${w.skipped}</td>
        <td><button type="button" class="ds-btn ds-btn--sm" data-tv-import="${tvEsc(w.id)}" ${w.importable ? '' : 'disabled'}>Importer</button></td></tr>`).join('')
    }</tbody></table>`;
    host.querySelectorAll('[data-tv-import]').forEach((b) => b.addEventListener('click', () => tvImport(b.dataset.tvImport, b)));
  } catch (err) {
    host.textContent = '';
    if (err.message.includes('pas connecté')) { await tvRefresh(); renderTvCard(); }
    tvSetMsg(err.message, 'err');
  }
}

async function tvImport(id, btn) {
  btn.disabled = true;
  try {
    const r = await fetchJSON('/api/tradingview/import', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ watchlistId: id }) });
    tvSetMsg(`« ${r.name} » ${r.updated ? 'mise à jour' : 'créée'} : ${r.imported} titre(s) importé(s)${r.skipped.length ? `, ${r.skipped.length} ignoré(s) (${r.skipped.slice(0, 4).map((s) => s.symbol).join(', ')}${r.skipped.length > 4 ? '…' : ''})` : ''}${r.truncated ? `, ${r.truncated} au-delà du plafond` : ''}. Elle est disponible dans le Screener.`, 'ok');
    if (typeof loadCustomLists === 'function') loadCustomLists();
  } catch (err) { tvSetMsg(err.message, 'err'); }
  btn.disabled = false;
}

// Appelé une fois au démarrage (bootApp). Toute erreur laisse la carte telle
// quelle (« pas encore disponible ») — jamais un bouton cassé.
async function initTradingviewConnect() {
  try {
    const st = await tvRefresh();
    if (!st.enabled) return;
    const legacy = document.getElementById('tv-connect-legacy');
    if (legacy) legacy.style.display = 'none';
    document.getElementById('tv-connect-live').style.display = '';
    const note = document.getElementById('tv-intro-note'); if (note) note.textContent = '';
    const i3 = document.getElementById('tv-intro-3'); if (i3) i3.innerHTML = '<strong>Connexion à ton compte TradingView</strong> — importe tes watchlists (lecture seule).';
    renderTvCard();

    const params = new URLSearchParams(location.search);
    const r = params.get('tv');
    if (r) {
      history.replaceState(null, '', location.pathname); // le paramètre ne doit pas rester dans l'URL
      openSettings(); switchSettingsTab('tradingview');
      if (r === 'ok') { await tvRefresh(); renderTvCard(); tvSetMsg('TradingView est connecté.', 'ok'); }
      else if (r === 'refuse') tvSetMsg('Connexion annulée : tu as refusé l\'accès chez TradingView.', 'err');
      else tvSetMsg('La connexion a échoué. Réessaie ; si ça persiste, déconnecte puis reconnecte.', 'err');
    }
  } catch { /* carte inchangée */ }
}
