#!/usr/bin/env node
// Migration idempotente (17/10/2026) — table daily_snapshots (instantanés poussés par l'app
// locale : balayage du S&P 500). CREATE TABLE IF NOT EXISTS, rejouable ; aucune donnée touchée.
//
// ⚠️ À lancer en --remote AVANT `wrangler deploy`, puis vérifier la sortie sqlite_master
// affichée à la fin — pas sur le seul message « Terminé ».
//
// Usage :
//   node scripts/migrate-snapshots.mjs             (D1 local)
//   node scripts/migrate-snapshots.mjs --remote    (vrai D1)

import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const remote = process.argv.includes('--remote');
const flag = remote ? '--remote' : '--local';

function run(sql) {
  const r = spawnSync('npx', ['wrangler', 'd1', 'execute', 'castellana-db', flag, '--command', sql], { cwd: ROOT, stdio: 'inherit' });
  if (r.status !== 0) throw new Error(`Échec de la commande wrangler (SQL: ${sql})`);
}

console.log(`\nMigration daily_snapshots (${remote ? 'D1 distant' : 'D1 local'})...`);
run(`CREATE TABLE IF NOT EXISTS daily_snapshots (
  kind TEXT NOT NULL,
  date TEXT NOT NULL,
  json TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (kind, date)
)`);
console.log('\nVérification :');
run("SELECT name, sql FROM sqlite_master WHERE name = 'daily_snapshots'");
console.log('\nTerminé.');
