// IA étape 2 (#399), phase 1 : régression logistique en JS pur (zéro dépendance) + protocole de
// validation en progression dans le temps. Fonctions PURES, testées sur des données synthétiques.
//
// Pourquoi une régression logistique : elle est interprétable (un coefficient par variable, dans
// l'unité de l'écart-type), elle ne surapprend pas facilement ~7 500 lignes, et elle fixe la barre :
// si elle ne bat pas la ligne de base, des arbres boostés ne feront que mieux mémoriser le bruit.

export const NUMERIC_FEATURES = [
  'rsi', 'atr_pct', 'gap_slow_pct', 'spread_fast_slow_pct', 'ret20_pct', 'rel_strength_60_pct',
  'vol_ratio_20', 'hv60_pct', 'golden_cross', 'spy_above_sma200', 'vix',
];

const num = (v) => (v === '' || v == null ? null : Number.isFinite(+v) ? +v : null);

function quantile(sorted, q) {
  if (!sorted.length) return null;
  const pos = (sorted.length - 1) * q, lo = Math.floor(pos), hi = Math.ceil(pos);
  return sorted[lo] + (sorted[hi] - sorted[lo]) * (pos - lo);
}

/** Matrice brute d'une ligne : numériques + obv_trend==accumulation / ==distribution (neutre = référence). */
export function rawVector(row) {
  return [
    ...NUMERIC_FEATURES.map((f) => num(row[f])),
    row.obv_trend === 'accumulation' ? 1 : row.obv_trend === 'distribution' ? 0 : null,
  ];
}
export const FEATURE_NAMES = [...NUMERIC_FEATURES, 'obv_accumulation'];

/**
 * Prétraitement APPRIS SUR L'ENTRAÎNEMENT SEULEMENT (médiane d'imputation, bornes 1-99 %, moyenne,
 * écart-type) puis appliqué tel quel au test : recalculer ces statistiques sur le test serait une fuite.
 */
export function fitPreprocessor(rows) {
  const vecs = rows.map(rawVector);
  const d = FEATURE_NAMES.length;
  const stats = [];
  for (let j = 0; j < d; j++) {
    const col = vecs.map((v) => v[j]).filter((x) => x != null).sort((a, b) => a - b);
    const median = quantile(col, 0.5) ?? 0;
    const lo = quantile(col, 0.01) ?? 0, hi = quantile(col, 0.99) ?? 0;
    const clipped = col.map((x) => Math.min(hi, Math.max(lo, x)));
    const mean = clipped.reduce((a, b) => a + b, 0) / (clipped.length || 1);
    const sd = Math.sqrt(clipped.reduce((a, b) => a + (b - mean) ** 2, 0) / (clipped.length || 1)) || 1;
    stats.push({ median, lo, hi, mean, sd });
  }
  return { stats, transform: (row) => transformRow(row, stats) };
}
function transformRow(row, stats) {
  const v = rawVector(row);
  return v.map((x, j) => {
    const s = stats[j];
    const val = x == null ? s.median : Math.min(s.hi, Math.max(s.lo, x));
    return (val - s.mean) / s.sd;
  });
}

const sigmoid = (z) => 1 / (1 + Math.exp(-Math.max(-35, Math.min(35, z))));

function solve(A, b) { // élimination de Gauss avec pivot partiel
  const n = b.length;
  const M = A.map((r, i) => [...r, b[i]]);
  for (let c = 0; c < n; c++) {
    let p = c;
    for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
    [M[c], M[p]] = [M[p], M[c]];
    const piv = M[c][c];
    if (Math.abs(piv) < 1e-12) throw new Error('Matrice singulière');
    for (let r = c + 1; r < n; r++) {
      const f = M[r][c] / piv;
      for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k];
    }
  }
  const x = new Array(n).fill(0);
  for (let i = n - 1; i >= 0; i--) {
    let s = M[i][n];
    for (let k = i + 1; k < n; k++) s -= M[i][k] * x[k];
    x[i] = s / M[i][i];
  }
  return x;
}

/**
 * Régression logistique régularisée (ridge `lambda`, intercept non pénalisé), Newton-Raphson.
 * @param X  tableau de vecteurs standardisés   @param y  0/1
 */
export function fitLogistic(X, y, { lambda = 1, iterations = 50, tol = 1e-8 } = {}) {
  const n = X.length, d = X[0].length + 1;
  let w = new Array(d).fill(0);
  const base = y.reduce((a, b) => a + b, 0) / n;
  w[0] = Math.log(Math.max(1e-6, base) / Math.max(1e-6, 1 - base));
  for (let it = 0; it < iterations; it++) {
    const g = new Array(d).fill(0);
    const H = Array.from({ length: d }, () => new Array(d).fill(0));
    for (let i = 0; i < n; i++) {
      const xi = [1, ...X[i]];
      let z = 0;
      for (let j = 0; j < d; j++) z += w[j] * xi[j];
      const p = sigmoid(z), r = p - y[i], s = p * (1 - p);
      for (let j = 0; j < d; j++) {
        g[j] += r * xi[j];
        for (let k = 0; k <= j; k++) H[j][k] += s * xi[j] * xi[k];
      }
    }
    for (let j = 1; j < d; j++) { g[j] += lambda * w[j]; H[j][j] += lambda; }
    for (let j = 0; j < d; j++) for (let k = j + 1; k < d; k++) H[j][k] = H[k][j];
    const step = solve(H, g);
    let maxStep = 0;
    for (let j = 0; j < d; j++) { w[j] -= step[j]; maxStep = Math.max(maxStep, Math.abs(step[j])); }
    if (maxStep < tol) break;
  }
  return { intercept: w[0], coefs: w.slice(1) };
}

export function predictProba(model, x) {
  let z = model.intercept;
  for (let j = 0; j < x.length; j++) z += model.coefs[j] * x[j];
  return sigmoid(z);
}

/** AUC par les rangs (Mann-Whitney), égalités au rang moyen. null si une seule classe. */
export function auc(scores, labels) {
  const idx = scores.map((s, i) => i).sort((a, b) => scores[a] - scores[b]);
  const ranks = new Array(scores.length);
  for (let i = 0; i < idx.length;) {
    let j = i;
    while (j + 1 < idx.length && scores[idx[j + 1]] === scores[idx[i]]) j++;
    const r = (i + j) / 2 + 1;
    for (let k = i; k <= j; k++) ranks[idx[k]] = r;
    i = j + 1;
  }
  const pos = labels.reduce((a, b) => a + b, 0), neg = labels.length - pos;
  if (!pos || !neg) return null;
  let sumPos = 0;
  labels.forEach((l, i) => { if (l === 1) sumPos += ranks[i]; });
  return (sumPos - pos * (pos + 1) / 2) / (pos * neg);
}

export const brier = (p, y) => p.reduce((a, pi, i) => a + (pi - y[i]) ** 2, 0) / p.length;

/** Courbe de calibration : `bins` tranches de probabilité prédite (quantiles), fréquence observée. */
export function calibration(p, y, bins = 5) {
  const idx = p.map((_, i) => i).sort((a, b) => p[a] - p[b]);
  const out = [];
  for (let b = 0; b < bins; b++) {
    const slice = idx.slice(Math.floor(b * idx.length / bins), Math.floor((b + 1) * idx.length / bins));
    if (!slice.length) continue;
    out.push({
      n: slice.length,
      predicted: slice.reduce((a, i) => a + p[i], 0) / slice.length,
      observed: slice.reduce((a, i) => a + y[i], 0) / slice.length,
    });
  }
  return out;
}

/**
 * Protocole en progression : pour chaque année de test, entraînement sur les signaux dont le
 * résultat était CONNU avant le début de l'année (exit_date < début), test sur l'année. Aucune
 * ligne ne sert à la fois à l'entraînement et au test, et aucun résultat futur n'est utilisé.
 */
export function walkForward(rows, { testYears, lambda = 1, minTrain = 500 } = {}) {
  const folds = [];
  for (const year of testYears) {
    const start = `${year}-01-01`, end = `${year + 1}-01-01`;
    const train = rows.filter((r) => r.exit_date < start);
    const test = rows.filter((r) => r.signal_date >= start && r.signal_date < end);
    if (train.length < minTrain || !test.length) continue;
    const prep = fitPreprocessor(train);
    const model = fitLogistic(train.map(prep.transform), train.map((r) => +r.win_1r), { lambda });
    const p = test.map((r) => predictProba(model, prep.transform(r)));
    folds.push({ year, trainN: train.length, testN: test.length, model, prep, test, p, baseRate: train.reduce((a, r) => a + +r.win_1r, 0) / train.length });
  }
  return folds;
}

/** Moyenne de r_net des trades dont la probabilité est dans le quantile supérieur `top` (0,2 = meilleur quintile), par fold puis agrégée. */
export function topQuantileRows(folds, top = 0.2) {
  const picked = [];
  for (const f of folds) {
    const order = f.p.map((_, i) => i).sort((a, b) => f.p[b] - f.p[a]);
    const k = Math.max(1, Math.round(order.length * top));
    for (const i of order.slice(0, k)) picked.push(f.test[i]);
  }
  return picked;
}

/** Bootstrap simple (par trade) de la moyenne d'une différence : borne basse/haute à 95 %. Optimiste: les trades d'une même période sont corrélés. */
export function bootstrapMeanDiff(a, b, { n = 2000, seed = 7 } = {}) {
  let s = seed;
  const rnd = () => { s = (s * 1664525 + 1013904223) % 4294967296; return s / 4294967296; };
  const mean = (arr) => arr.reduce((x, y) => x + y, 0) / arr.length;
  const diffs = [];
  for (let k = 0; k < n; k++) {
    const sa = Array.from({ length: a.length }, () => a[Math.floor(rnd() * a.length)]);
    const sb = Array.from({ length: b.length }, () => b[Math.floor(rnd() * b.length)]);
    diffs.push(mean(sa) - mean(sb));
  }
  diffs.sort((x, y) => x - y);
  return { mean: mean(a) - mean(b), lo: diffs[Math.floor(n * 0.025)], hi: diffs[Math.floor(n * 0.975)] };
}
