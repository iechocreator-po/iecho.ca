#!/bin/bash
# scripts/package-zip.sh — construit castellana.zip pour distribution
# (téléchargement gated depuis iecho.ca, 6/9/2026).
#
# Zéro dépendance npm ajoutée : utilise `zip`, déjà présent sur macOS.
# Ne contient que les fichiers suivis par git (jamais .env, data/, bases,
# node_modules/, .venv-mcp/) — l'archive est le code source, demarrer.command/demarrer.bat font
# l'installation réelle (npm install, venv Python) au premier lancement
# chez le testeur.
#
# Usage : npm run package  (depuis la racine de trading-assistant/)
# Résultat : castellana.zip à la racine du repo, JAMAIS committé
# (voir .gitignore) — à copier manuellement vers
# iecho.ca/public/telechargements/castellana.zip puis committer/pousser
# iecho.ca pour redéployer. Voir CLAUDE.md, section "Paquet téléchargeable".

set -e
cd "$(dirname "$0")/.."

rm -f castellana.zip

# version.json — estampille le paquet (7/9/2026). Sans lui, un testeur n'a
# aucun moyen de savoir que sa copie a trois semaines de retard : le zip
# devenait périmé en silence. L'app lit ce fichier et le compare à la version
# publiée (voir /api/version et le bandeau de mise à jour).
VERSION="$(node -p "require('./package.json').version")"
cat > version.json <<JSON
{
  "version": "$VERSION",
  "buildDate": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
}
JSON
echo "version.json : $VERSION"

# L'archive contient UNIQUEMENT les fichiers suivis par git (audit périphérie, 22/10/2026). Avant, `zip -r .` avec une liste d'exclusions
# écrite à la main embarquait `.env` (clé Resend, mot de passe admin), des copies de la base du journal, les données du club (.xlsx) et
# des centaines de Mo de node_modules/worktrees : les motifs `node_modules/*` et `data/*` ne couvrent que la racine, car `zip -x` ancre le chemin.
# Une liste d'INCLUSION ne peut pas oublier d'exclure un nouveau secret.
git -c core.quotepath=off ls-files | zip -q castellana.zip -@
zip -q castellana.zip version.json   # généré ci-dessus, non suivi par git

# Garde-fou : l'archive ne doit contenir aucun secret ni aucune donnée personnelle. Sinon on la supprime et on s'arrête.
INTERDITS='(^|/)\.env($|\.)|\.sqlite|\.db($|-)|\.xlsx$|\.dev\.vars|(^|/)worktrees/|(^|/)node_modules/|settings\.local|\.pem$|\.key$'
if unzip -Z1 castellana.zip | grep -E "$INTERDITS"; then
  rm -f castellana.zip
  echo "ERREUR : l'archive contenait les fichiers ci-dessus (secrets ou données). Archive supprimée." >&2
  exit 1
fi
if [ -n "$(git status --porcelain --untracked-files=no)" ]; then
  echo "AVERTISSEMENT : des fichiers suivis ont des modifications non commitées; l'archive contient leur version du disque." >&2
fi

echo "castellana.zip créé ($(du -h castellana.zip | cut -f1)) — version $VERSION."
echo "Prochaine étape : copier ce fichier vers iecho.ca/public/telechargements/castellana.zip"
echo "Empreinte sha256 (à publier avec PUBLISHED_VERSION dans telemetry-worker/wrangler.jsonc : PUBLISHED_SHA256) :"
shasum -a 256 castellana.zip | cut -d' ' -f1
