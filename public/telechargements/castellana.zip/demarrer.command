#!/bin/bash
# demarrer.command — lanceur self-install castellana (macOS, 6/9/2026)
#
# Pensé pour un testeur qui télécharge un zip depuis iecho.ca et double-clique
# ce fichier : vérifie/installe ce qui manque (npm install, venv Python +
# sidecar), démarre les deux serveurs, ouvre le navigateur. Reprend les mêmes
# conventions que scripts/run-sidecar.mjs (nom du dossier .venv-mcp, chemin
# de l'exécutable) — ne pas les faire diverger si l'un des deux change.
#
# ⚠️ Limite connue (Gatekeeper macOS) : un script .command téléchargé depuis
# un navigateur porte l'attribut com.apple.quarantine — macOS peut refuser de
# l'exécuter au double-clic ou afficher "développeur non identifié". Pas de
# signature Apple Developer ici (hors scope). Si le double-clic ne fonctionne
# pas : clic droit → Ouvrir (une seule fois), ou en Terminal :
#   xattr -d com.apple.quarantine demarrer.command
#
# Le sidecar Python (VIX/RSI/Golden Cross) est OPTIONNEL — s'il ne peut pas
# être installé (Python absent), castellana démarre quand même en mode
# dégradé (comportement déjà géré nativement par l'app, voir CLAUDE.md).

set -u
cd "$(dirname "$0")"

echo "=== castellana — installation et démarrage ==="
echo

# --- 1. Node.js ---------------------------------------------------------
if ! command -v node >/dev/null 2>&1; then
  echo "❌ Node.js est requis mais introuvable sur cette machine."
  echo "   Ouverture de la page de téléchargement officielle..."
  open "https://nodejs.org/"
  echo
  echo "Installe Node.js puis relance ce fichier. Appuie sur Entrée pour fermer."
  read -r _
  exit 1
fi
echo "✅ Node.js détecté ($(node --version))."

# --- 2. Python 3 (optionnel — pour le sidecar tradingview-mcp) ----------
PYTHON_OK=0
if command -v python3 >/dev/null 2>&1; then
  PYTHON_OK=1
  echo "✅ Python 3 détecté ($(python3 --version 2>&1))."
else
  echo "⚠️  Python 3 introuvable — le sidecar (VIX/RSI/Golden Cross en direct)"
  echo "   ne sera pas installé. castellana fonctionnera quand même, en mode"
  echo "   dégradé pour ces indicateurs (les calculs maison Yahoo Finance"
  echo "   restent disponibles)."
  echo "   Ouverture de la page de téléchargement officielle (optionnel)..."
  open "https://www.python.org/downloads/"
fi
echo

# --- 3. Dépendances Node -------------------------------------------------
if [ ! -d "node_modules" ]; then
  echo "📦 Installation des dépendances Node (première fois, peut prendre une minute)..."
  npm install
  if [ $? -ne 0 ]; then
    echo
    echo "❌ npm install a échoué. Voir SETUP.md (section Dépannage) —"
    echo "   causes fréquentes : cache npm (EACCES), better-sqlite3 nécessite"
    echo "   des outils de compilation sur certaines machines."
    read -r _
    exit 1
  fi
else
  echo "✅ Dépendances Node déjà installées."
fi
echo

# --- 4. Sidecar Python (si Python disponible et pas déjà installé) ------
SIDECAR_EXE=".venv-mcp/bin/tradingview-mcp"
SIDECAR_READY=0
if [ "$PYTHON_OK" = "1" ]; then
  if [ -f "$SIDECAR_EXE" ]; then
    echo "✅ Sidecar Python déjà installé."
    SIDECAR_READY=1
  else
    echo "📦 Installation du sidecar Python (tradingview-mcp)..."
    python3 -m venv .venv-mcp && \
      .venv-mcp/bin/pip install --quiet tradingview-mcp-server
    if [ -f "$SIDECAR_EXE" ]; then
      echo "✅ Sidecar Python installé."
      SIDECAR_READY=1
    else
      echo "⚠️  L'installation du sidecar a échoué — castellana démarrera quand"
      echo "   même, sans VIX/RSI/Golden Cross en direct."
    fi
  fi
fi
echo

# --- 5. Démarrage ---------------------------------------------------------
echo "🚀 Démarrage du serveur castellana..."
npm start &
SERVER_PID=$!

if [ "$SIDECAR_READY" = "1" ]; then
  echo "🚀 Démarrage du sidecar tradingview-mcp..."
  npm run sidecar &
  SIDECAR_PID=$!
fi

sleep 2
open "http://127.0.0.1:4700"

echo
echo "=== castellana tourne — http://127.0.0.1:4700 ==="
echo "Ferme cette fenêtre (ou appuie sur Ctrl+C) pour tout arrêter."
echo

wait
