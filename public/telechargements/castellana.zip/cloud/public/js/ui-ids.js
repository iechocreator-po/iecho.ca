// js/ui-ids.js — Repères d'interface (27/9/2026) : une lettre par onglet, une
// lettre+numéro par carte (ex. "F3"), pour qu'un testeur puisse pointer
// précisément un endroit de l'app dans un retour sans devoir décrire
// l'onglet et la section. Copié tel quel côté cloud (cloud/public/js/
// ui-ids.js, byte pour byte) — voir le test de parité dans
// server/labo-params.test.js.
//
// Les identifiants sont DÉRIVÉS de l'ordre réel du DOM à chaque chargement
// (lettres = ordre des .tab-btn dans la barre d'onglets, numéros = ordre des
// .ds-card DANS chaque .tab-panel), jamais d'une table écrite à la main —
// même piège déjà documenté ailleurs dans ce projet (SCORE_BANDS,
// SCREEN_FILTERS, fcf-quality.js) : une table dupliquée dérive en silence
// dès qu'on ajoute un onglet/une carte sans penser à la mettre à jour ici.
//
// Un onglet ou une carte caché(e) par un feature flag (Options A, Screener
// Prime, Radar, Concepts…) compte quand même dans la numérotation — sa
// place dans le DOM ne change pas selon l'état du flag. Conséquence
// recherchée : "F3" désigne la toujours la même carte, que le testeur ait
// ce flag activé ou non.
//
// Rendu en CSS pur, via des attributs (`data-ui-tab`, `data-ui-card`) lus
// par un ::before — jamais un noeud enfant injecté dans la carte : plusieurs
// cartes (js/fcf-card.js, js/ticker-section.js, le tableau de screening…)
// réécrivent leur innerHTML au complet à chaque rafraîchissement, ce qui
// effacerait un badge inséré comme enfant.

const UI_IDS_STORAGE_KEY = 'castellana-ui-ids';

// A, B, C … Z, puis AA, AB… — 9 onglets aujourd'hui, ne plante pas si ça
// dépasse 26 un jour.
function uiIdLetter(index) {
  let n = index;
  let out = '';
  do {
    out = String.fromCharCode(65 + (n % 26)) + out;
    n = Math.floor(n / 26) - 1;
  } while (n >= 0);
  return out;
}

// Numérote onglets et cartes d'après le DOM actuel — idempotent. Rappelée par
// les onglets dont les cartes sont injectées après le chargement (Screener Prime).
function uiIdsNumber() {
  const tabs = Array.from(document.querySelectorAll('.tabs[role="tablist"] > .tab-btn'));
  tabs.forEach((btn, i) => {
    const letter = uiIdLetter(i);
    btn.setAttribute('data-ui-tab', letter);
    const panel = document.getElementById('tab-' + btn.dataset.tab);
    if (!panel) return;
    // Cartes de premier niveau seulement (jamais une .ds-card imbriquée
    // dans une autre — ça n'arrive pas aujourd'hui, mais ne pas la
    // recompter si ça arrivait).
    const cards = Array.from(panel.querySelectorAll('.ds-card')).filter(
      (c) => !c.parentElement.closest('.ds-card')
    );
    cards.forEach((card, j) => card.setAttribute('data-ui-card', letter + (j + 1)));
  });

  // Réglages (overlay) : mêmes règles, préfixe « R- » pour ne jamais confondre « R-D2 » (Réglages)
  // avec une carte d'un onglet principal. L'onglet Concepts, caché par un flag, compte quand même.
  const stabs = Array.from(document.querySelectorAll('#settings-overlay .settings-tab-btn'));
  stabs.forEach((btn, i) => {
    const id = 'R-' + uiIdLetter(i);
    btn.setAttribute('data-ui-tab', id);
    const panel = document.getElementById('settings-tab-' + btn.dataset.stab);
    if (!panel) return;
    Array.from(panel.querySelectorAll('.ds-card'))
      .filter((c) => !c.parentElement.closest('.ds-card'))
      .forEach((card, j) => card.setAttribute('data-ui-card', id + (j + 1)));
  });
}

// Apparence des repères sur les cartes (4 choix, repris de toledo) : a = étiquette discrète en
// coin bas, b = pastille au-dessus du titre (défaut), c = marge extérieure, d = languette sur le
// coin du cadre. Pur CSS, via <html data-ui-ids-style>.
const UI_IDS_STYLE_KEY = 'castellana-ui-ids-style';
const UI_IDS_STYLES = ['a', 'b', 'c', 'd'];

function setUiIdsStyle(choix) {
  if (!UI_IDS_STYLES.includes(choix)) choix = 'b';
  document.documentElement.setAttribute('data-ui-ids-style', choix);
  document.querySelectorAll('.reperes-option').forEach((b) => {
    const actif = b.dataset.reperesStyle === choix;
    b.setAttribute('aria-checked', String(actif));
    b.classList.toggle('is-active', actif);
  });
  try { localStorage.setItem(UI_IDS_STYLE_KEY, choix); } catch { /* tant pis */ }
}

function initUiIds() {
  let style = null;
  try { style = localStorage.getItem(UI_IDS_STYLE_KEY); } catch { /* navigation privée, tant pis */ }
  setUiIdsStyle(style);
  uiIdsNumber();

  let saved = null;
  try { saved = localStorage.getItem(UI_IDS_STORAGE_KEY); } catch { /* navigation privée, tant pis */ }
  setUiIdsVisible(saved === 'on'); // OFF par défaut, comme les autres feature flags du produit
}

function setUiIdsVisible(visible) {
  document.documentElement.setAttribute('data-ui-ids', visible ? 'on' : 'off');
  const toggle = document.getElementById('ui-ids-toggle');
  if (toggle) toggle.checked = visible;
  const wrap = document.getElementById('ui-ids-switch');
  if (wrap) wrap.classList.toggle('is-on', visible);
  const state = document.getElementById('ui-ids-state');
  if (state) state.textContent = visible ? 'ON' : 'OFF';
  try { localStorage.setItem(UI_IDS_STORAGE_KEY, visible ? 'on' : 'off'); } catch { /* tant pis */ }
}
