// Tests des réglages utilisateur (feature 351). Utilise la vraie base, avec
// remise à l'état initial après coup pour ne pas laisser les préférences de
// JP modifiées par une exécution de tests.

import test from 'node:test';
import assert from 'node:assert/strict';
import { getPreferences, setPreferences, resetPreferences, indicatorOptions, DEFAULTS } from './preferences.js';

const initial = getPreferences();
test.after(() => { resetPreferences(); setPreferences(initial); });

test('sans réglage enregistré, on obtient les valeurs par défaut', () => {
  resetPreferences();
  assert.deepEqual(getPreferences(), DEFAULTS);
});

test('les valeurs par défaut sont celles demandées dans la feature 351', () => {
  // 9 / 21 / 50 et RSI 14 — la lente à 50 est un écart assumé avec le
  // document de design (qui dit 100), demandé explicitement par JP.
  assert.deepEqual(DEFAULTS, { smaFast: 9, smaMedium: 21, smaSlow: 50, rsiPeriod: 14 });
});

test('un réglage valide est enregistré et relu', () => {
  resetPreferences();
  const out = setPreferences({ smaFast: 5, smaMedium: 20, smaSlow: 60, rsiPeriod: 21 });
  assert.deepEqual(out, { smaFast: 5, smaMedium: 20, smaSlow: 60, rsiPeriod: 21 });
  assert.deepEqual(getPreferences(), out);
});

test('un ordre incohérent est refusé avec un message explicite', () => {
  // Sans ce contrôle, rapide > moyenne rendrait l'alignement haussier
  // silencieusement inatteignable — un réglage accepté qui casse un signal.
  resetPreferences();
  assert.throws(() => setPreferences({ smaFast: 50, smaMedium: 21, smaSlow: 9 }), /plus courte à la plus longue/);
  assert.deepEqual(getPreferences(), DEFAULTS, 'rien ne doit avoir été écrit');
});

test('une valeur non entière ou hors bornes est refusée', () => {
  resetPreferences();
  for (const patch of [{ rsiPeriod: 'abc' }, { rsiPeriod: 0 }, { rsiPeriod: 1 }, { smaFast: 9999 }, { smaFast: -3 }]) {
    assert.throws(() => setPreferences(patch), /n'est pas un entier/);
  }
  assert.deepEqual(getPreferences(), DEFAULTS);
});

test('une clé inconnue est ignorée sans faire échouer le reste', () => {
  resetPreferences();
  const out = setPreferences({ rsiPeriod: 20, couleurPreferee: 'bleu' });
  assert.equal(out.rsiPeriod, 20);
  assert.ok(!('couleurPreferee' in out));
});

test('réinitialiser efface les réglages plutôt que d’y réécrire les défauts', () => {
  // Nuance qui compte : si les défauts changent un jour, un utilisateur qui
  // a « réinitialisé » doit suivre le NOUVEAU défaut, pas rester figé.
  setPreferences({ smaFast: 3, smaMedium: 8, smaSlow: 30 });
  assert.deepEqual(resetPreferences(), DEFAULTS);
});

test('indicatorOptions produit la forme attendue par getHomemadeIndicators', () => {
  resetPreferences();
  assert.deepEqual(indicatorOptions(), {
    periods: { fast: 9, medium: 21, slow: 50 },
    rsiPeriod: 14,
  });
});

// ---- Pondération du score fondamental (2/10/2026) ----
import { getFundamentalWeights, setFundamentalWeights, resetFundamentalWeights, WEIGHT_DEFAULTS } from './preferences.js';
const initialWeights = getFundamentalWeights();
test.after(() => { resetFundamentalWeights(); setFundamentalWeights(initialWeights); });

test('pondération : 20 % chacun par défaut, total 100', () => {
  resetFundamentalWeights();
  assert.deepEqual(getFundamentalWeights(), WEIGHT_DEFAULTS);
  assert.equal(Object.values(WEIGHT_DEFAULTS).reduce((a, b) => a + b, 0), 100);
});

test('pondération : un total de 100 est enregistré, relu, et 0 % retire un critère', () => {
  const w = { growth: 30, consistency: 20, conversion: 20, dilution: 30, valuation: 0, balance: 0 };
  assert.deepEqual(setFundamentalWeights(w), w);
  assert.deepEqual(getFundamentalWeights(), w);
});

test('pondération : un total différent de 100 est refusé, rien n\'est écrit', () => {
  resetFundamentalWeights();
  assert.throws(() => setFundamentalWeights({ growth: 50 }), /totaliser 100 % \(actuellement 130 %\)/);
  assert.deepEqual(getFundamentalWeights(), WEIGHT_DEFAULTS);
});

test('pondération : valeur non entière ou hors 0–100 refusée', () => {
  resetFundamentalWeights();
  for (const bad of [-5, 101, 12.5, 'abc']) assert.throws(() => setFundamentalWeights({ growth: bad }), /entier entre 0 et 100/);
});

test('réinitialiser les périodes ne touche pas la pondération, et inversement', () => {
  resetPreferences(); resetFundamentalWeights();
  setFundamentalWeights({ growth: 40, consistency: 15, conversion: 15, dilution: 15, valuation: 15 });
  setPreferences({ rsiPeriod: 21 });
  resetPreferences();
  assert.equal(getFundamentalWeights().growth, 40, 'la pondération survit à la réinitialisation des périodes');
  setPreferences({ rsiPeriod: 21 });
  resetFundamentalWeights();
  assert.equal(getPreferences().rsiPeriod, 21, 'les périodes survivent à la réinitialisation de la pondération');
});
