// Photographie les STYLES CALCULÉS de chaque élément des pages, dans plusieurs états (chaque onglet visible, la fenêtre
// Réglages et chacun de ses onglets), pour PROUVER qu'un refactor du CSS ou du HTML ne change pas le rendu.
//
// Usage : node scripts/snapshot-styles.mjs <sortie.json>            (avant le changement)
//         node scripts/snapshot-styles.mjs <autre.json>             (après)
//         node scripts/snapshot-styles.mjs --compare <a.json> <b.json>
//
// Même Chrome headless sans dépendance que le test de fumée. Vue fixe 1280 x 900, transitions et animations coupées.
// Limites : ne voit que les états atteignables sans données réelles (API bouchonnée) ; les onglets masqués par un
// feature flag et les cartes qui n'apparaissent qu'avec des données ne sont pas photographiés.
import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { findChrome, launchChrome, startServer, PAGES } from './smoke-browser.mjs';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Évalué DANS la page : une ligne par élément du <body> (hors script/style/link), clé = position + balise + id/classes.
const DUMP = `(() => {
  const out = {};
  const els = [document.body, ...document.body.querySelectorAll('*')].filter(e => !['SCRIPT','STYLE','LINK','META'].includes(e.tagName));
  els.forEach((el, i) => {
    const key = i + ' ' + el.tagName.toLowerCase() + (el.id ? '#' + el.id : '') + (el.className && typeof el.className === 'string' ? '.' + el.className.trim().split(/\\s+/).join('.') : '');
    const cs = getComputedStyle(el);
    // Noms triés : l'ordre d'énumération des propriétés (notamment les variables --*) n'est pas garanti stable.
    const names = (c) => { const r = []; for (let k = 0; k < c.length; k++) r.push(c[k]); return r.sort(); };
    let s = '';
    for (const n of names(cs)) s += n + ':' + cs.getPropertyValue(n) + ';';
    for (const pseudo of ['::before', '::after']) {
      const p = getComputedStyle(el, pseudo);
      if (p.content && p.content !== 'none' && p.content !== 'normal') {
        let ps = '';
        for (const n of names(p)) ps += n + ':' + p.getPropertyValue(n) + ';';
        s += '|' + pseudo + '{' + ps + '}';
      }
    }
    out[key] = s;
  });
  return out;
})()`;

async function snapshotPage({ root, label, authenticated, chromePath }) {
  const { server, origin } = await startServer(root, { authenticated });
  const chrome = await launchChrome(chromePath);
  const states = {};
  try {
    const { targetId } = await chrome.send('Target.createTarget', { url: 'about:blank' });
    const { sessionId } = await chrome.send('Target.attachToTarget', { targetId, flatten: true });
    const send = (m, p) => chrome.send(m, p, sessionId);
    let loaded; const loadedP = new Promise((ok) => { loaded = ok; });
    chrome.on((m) => { if (m.sessionId === sessionId && m.method === 'Page.loadEventFired') loaded(); });
    for (const d of ['Runtime', 'Page']) await send(`${d}.enable`);
    await send('Emulation.setDeviceMetricsOverride', { width: 1280, height: 900, deviceScaleFactor: 1, mobile: false });
    await send('Page.navigate', { url: `${origin}/` });
    await Promise.race([loadedP, sleep(20000)]);
    await sleep(2500);
    const ev = async (expression) => {
      const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
      if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
      return r.result.value;
    };
    await ev(`(() => { const s = document.createElement('style'); s.id = '__snap'; s.textContent = '*,*::before,*::after{transition:none!important;animation:none!important;caret-color:transparent!important}'; document.head.appendChild(s); })()`);
    states['initial'] = await ev(DUMP);
    const tabs = await ev(`[...document.querySelectorAll('.tab-btn')].filter(b => b.offsetParent !== null).map(b => b.dataset.tab)`);
    if (authenticated || label.startsWith('local')) {
      for (const t of tabs) {
        await ev(`document.querySelector('.tab-btn[data-tab="${t}"]').click()`);
        await sleep(400);
        states['onglet:' + t] = await ev(DUMP);
      }
      if (await ev(`typeof openSettings === 'function'`)) {
        await ev('openSettings()'); await sleep(300);
        states['réglages'] = await ev(DUMP);
        const stabs = await ev(`[...document.querySelectorAll('.settings-tab-btn')].map(b => b.dataset.stab)`);
        for (const s of stabs) {
          await ev(`switchSettingsTab(${JSON.stringify(s)})`); await sleep(300);
          states['réglages:' + s] = await ev(DUMP);
        }
      }
    }
    return states;
  } finally { await chrome.close(); server.close(); }
}

function compare(aFile, bFile) {
  const a = JSON.parse(readFileSync(aFile, 'utf8')); const b = JSON.parse(readFileSync(bFile, 'utf8'));
  let diffs = 0; let compared = 0;
  for (const page of Object.keys(a)) {
    if (!b[page]) { console.log(`MANQUANT dans ${bFile} : ${page}`); diffs++; continue; }
    for (const st of Object.keys(a[page])) {
      if (!b[page][st]) { console.log(`ÉTAT MANQUANT : ${page} / ${st}`); diffs++; continue; }
      const A = JSON.parse(gunzipSync(Buffer.from(a[page][st], 'base64'))); const B = JSON.parse(gunzipSync(Buffer.from(b[page][st], 'base64')));
      const ka = Object.keys(A); const kb = Object.keys(B);
      if (ka.length !== kb.length) { console.log(`NOMBRE D'ÉLÉMENTS DIFFÉRENT : ${page} / ${st} : ${ka.length} contre ${kb.length}`); diffs++; }
      for (const k of ka) {
        compared++;
        if (A[k] !== B[k]) {
          diffs++;
          if (diffs <= 15) {
            const pa = A[k].split(';'); const pb = (B[k] || '').split(';');
            const delta = pa.filter((x) => !pb.includes(x)).slice(0, 4).concat(['→'], pb.filter((x) => !pa.includes(x)).slice(0, 4));
            console.log(`DIFFÉRENT : ${page} / ${st} / ${k}\n    ${delta.join('  ')}`);
          }
        }
      }
    }
  }
  console.log(`${compared} élément-états comparés, ${diffs} différence(s).`);
  process.exit(diffs ? 1 : 0);
}

const args = process.argv.slice(2);
if (args[0] === '--compare') compare(args[1], args[2]);
else if (args[0]) {
  const chromePath = findChrome();
  if (!chromePath) { console.error('Aucun Chrome trouvé (CHROME_PATH).'); process.exit(2); }
  const all = {};
  for (const p of PAGES) {
    const states = await snapshotPage({ ...p, chromePath });
    const n = Object.values(states).reduce((s, st) => s + Object.keys(st).length, 0);
    console.log(`${p.label} : ${Object.keys(states).length} états, ${n} élément-états`);
    // Un état fait plusieurs Mo de texte : compressé, sinon le fichier dépasse la taille maximale d'une chaîne JS.
    all[p.label] = Object.fromEntries(Object.entries(states).map(([k, v]) => [k, gzipSync(JSON.stringify(v)).toString('base64')]));
  }
  writeFileSync(args[0], JSON.stringify(all));
  console.log('Écrit :', args[0]);
} else { console.error('Usage : node scripts/snapshot-styles.mjs <sortie.json> | --compare <a.json> <b.json>'); process.exit(2); }
