// Listes personnalisées de l'onglet Screener (12/9/2026, demande de JP) —
// en plus de « Ma watchlist »/« Univers élargi »/« MAG7 », l'utilisateur
// peut créer, renommer, supprimer des listes nommées et y ajouter/retirer
// des titres. Même patron CRUD que watchlist.js, mais répétable N fois.
//
// Plafond de 50 titres par liste (MAX_TICKERS_PER_LIST) : après le bug de
// l'univers élargi (219 titres → plafond de sous-requêtes Cloudflare, voir
// CLAUDE.md section T6), une liste custom sans limite recréerait le même
// risque sur la version cloud. Appliqué ici pour que le comportement soit
// identique entre local et cloud — pas seulement côté cloud où ça casserait.

import { db } from './db.js';

export const MAX_TICKERS_PER_LIST = 50;

export function getLists() {
  const lists = db.prepare('SELECT id, nom, date_creation FROM custom_lists ORDER BY nom').all();
  const tickersStmt = db.prepare('SELECT ticker, exchange FROM custom_list_tickers WHERE list_id = ? ORDER BY ticker');
  return lists.map((l) => ({ ...l, tickers: tickersStmt.all(l.id) }));
}

export function getListById(id) {
  const list = db.prepare('SELECT id, nom, date_creation FROM custom_lists WHERE id = ?').get(id);
  if (!list) return null;
  const tickers = db.prepare('SELECT ticker, exchange FROM custom_list_tickers WHERE list_id = ? ORDER BY ticker').all(id);
  return { ...list, tickers };
}

export function createList(nom) {
  const trimmed = nom.trim();
  if (!trimmed) throw new Error('Nom de liste requis.');
  const info = db.prepare('INSERT INTO custom_lists (nom) VALUES (?)').run(trimmed);
  return getListById(info.lastInsertRowid);
}

export function renameList(id, nom) {
  const trimmed = nom.trim();
  if (!trimmed) throw new Error('Nom de liste requis.');
  const result = db.prepare('UPDATE custom_lists SET nom = ? WHERE id = ?').run(trimmed, id);
  if (result.changes === 0) return null;
  return getListById(id);
}

// Cascade gérée à la main (pas de foreign_keys = ON sur cette base — voir
// db.js) : supprimer les titres AVANT la liste, dans une transaction pour
// qu'un échec ne laisse jamais des titres orphelins.
export function deleteList(id) {
  const tx = db.transaction((listId) => {
    db.prepare('DELETE FROM custom_list_tickers WHERE list_id = ?').run(listId);
    return db.prepare('DELETE FROM custom_lists WHERE id = ?').run(listId).changes > 0;
  });
  return tx(id);
}

export function addTickerToList(listId, ticker, exchange = 'NASDAQ') {
  const list = getListById(listId);
  if (!list) throw new Error('Liste introuvable.');
  if (list.tickers.length >= MAX_TICKERS_PER_LIST && !list.tickers.some((t) => t.ticker === ticker.toUpperCase())) {
    throw new Error(`Cette liste a déjà ${MAX_TICKERS_PER_LIST} titres (maximum).`);
  }
  db.prepare(
    'INSERT INTO custom_list_tickers (list_id, ticker, exchange) VALUES (?, ?, ?) ON CONFLICT(list_id, ticker) DO UPDATE SET exchange = excluded.exchange',
  ).run(listId, ticker.toUpperCase(), exchange);
  return getListById(listId);
}

export function removeTickerFromList(listId, ticker) {
  db.prepare('DELETE FROM custom_list_tickers WHERE list_id = ? AND ticker = ?').run(listId, ticker.toUpperCase());
  return getListById(listId);
}
