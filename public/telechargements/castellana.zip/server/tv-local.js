// Option 2 — TradingView en appels LOCAUX, sans Cloudflare (7/10/2026).
//
// L'app locale (127.0.0.1) fait elle-même la connexion OAuth 2.1 (PKCE) au
// serveur MCP officiel de TradingView et appelle ses outils directement : aucune
// limite de sous-requêtes du plan Cloudflare, donc de quoi balayer tout le
// S&P 500 (server/sweep.js). Le client OAuth et le protocole sont ceux du Worker :
// on réutilise TELS QUELS cloud/src/lib/tv-mcp.js et tv-symbols.js (ESM pur,
// `fetch` + Web Crypto, aussi disponibles dans Node ≥ 20) — une seule
// implémentation, pas une copie qui dériverait.
//
// Sécurité :
//  - lecture seule : seuls des outils de données et de watchlists sont appelés ;
//  - les jetons vivent dans la base SQLite LOCALE (data/, gitignorée, jamais
//    envoyée nulle part) et ne sont jamais renvoyés par l'API ni journalisés ;
//  - la source « TradingView » exige une connexion valide, sinon retour à Yahoo ;
//  - Yahoo reste TOUJOURS le repli, titre par titre.
//
// Contrairement au Worker (jeton par SESSION), l'app locale est mono-utilisateur :
// la connexion survit au redémarrage, jusqu'à la déconnexion ou un refus de
// rafraîchissement.

import { db } from './db.js';
import { readCache, writeCache } from './cache.js';
import {
  randomToken, challengeFor, registerClient, buildAuthUrl, exchangeCode,
  refreshAccessToken, openMcpSession,
} from '../cloud/src/lib/tv-mcp.js';
import { yahooTickerToTvCandidates, tvBarsToDailyBars } from '../cloud/src/lib/tv-symbols.js';

db.exec('CREATE TABLE IF NOT EXISTS tv_local (key TEXT PRIMARY KEY, value TEXT NOT NULL)');
const getStmt = db.prepare('SELECT value FROM tv_local WHERE key = ?');
const setStmt = db.prepare('INSERT INTO tv_local (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
const delStmt = db.prepare('DELETE FROM tv_local WHERE key = ?');
const readKey = (k) => { const r = getStmt.get(k); if (!r) return null; try { return JSON.parse(r.value); } catch { return null; } };
const writeKey = (k, v) => setStmt.run(k, JSON.stringify(v));

export const DATA_SOURCES = ['yahoo', 'tradingview'];
const COOLDOWN_MS = 60_000;
const MIN_GAP_MS = 200;        // politesse entre deux appels d'outils
const BATCH_MAX = 50;
const SYMBOL_TTL = 30 * 24 * 3600;
const NONE_TTL = 24 * 3600;

const state = {
  session: null, sessionToken: null,
  cooldownUntil: 0, lastCallAt: 0, chain: Promise.resolve(),
  stats: { tv: 0, yahoo: 0, rateLimits: 0, lastError: null },
};

// --- État persistant ---------------------------------------------------------

export function getDataSource() {
  const s = readKey('dataSource');
  return DATA_SOURCES.includes(s) ? s : 'yahoo';
}
export function setDataSource(source) {
  if (!DATA_SOURCES.includes(source)) throw new Error('Source inconnue.');
  writeKey('dataSource', source);
}

function getConnection() {
  const c = readKey('conn');
  return c && c.accessToken ? c : null;
}

export function getStatus() {
  const conn = getConnection();
  return {
    connected: !!conn,
    connectedAt: conn?.connectedAt || null,
    dataSource: getDataSource(),
    active: tvLocalActive() !== null,
    coolingUntil: state.cooldownUntil > Date.now() ? state.cooldownUntil : null,
    stats: { ...state.stats },
  };
}

// Contexte actif (source TradingView ET connexion valide) ou null.
export function tvLocalActive() {
  if (getDataSource() !== 'tradingview') return null;
  return getConnection() ? state : null;
}
export function tvLocalNoteFallback(count = 1) { state.stats.yahoo += count; }

// --- Connexion OAuth ---------------------------------------------------------

export async function beginConnect(origin) {
  const redirectUri = `${origin}/api/tradingview/callback`;
  const reg = readKey('client');
  let clientId = reg && reg.redirectUri === redirectUri ? reg.clientId : null;
  if (!clientId) { clientId = await registerClient(redirectUri); writeKey('client', { clientId, redirectUri }); }
  const verifier = randomToken(48);
  const stateTok = randomToken(24);
  writeKey('pending', { clientId, redirectUri, state: stateTok, verifier, at: Date.now() });
  return buildAuthUrl({ clientId, redirectUri, challenge: await challengeFor(verifier), state: stateTok });
}

// Retourne 'ok' | 'refuse' | 'erreur'. Le `state` est à usage unique.
export async function completeConnect(query) {
  const pending = readKey('pending');
  delStmt.run('pending');
  if (query.error) return 'refuse';
  if (!pending || !query.state || query.state !== pending.state || !query.code) return 'erreur';
  if (Date.now() - pending.at > 15 * 60_000) return 'erreur';
  try {
    const t = await exchangeCode({ clientId: pending.clientId, redirectUri: pending.redirectUri, code: query.code, verifier: pending.verifier });
    writeKey('conn', { clientId: pending.clientId, ...t, connectedAt: new Date().toISOString() });
    return 'ok';
  } catch (err) {
    state.stats.lastError = err.message;
    return 'erreur';
  }
}

export function disconnect() {
  delStmt.run('conn');
  delStmt.run('pending');
  state.session = null; state.sessionToken = null;
  if (getDataSource() === 'tradingview') setDataSource('yahoo'); // sans connexion : retour à Yahoo
}

const notConnected = () => Object.assign(new Error('TradingView n\'est pas connecté.'), { code: 'TV_NOT_CONNECTED' });

// Jeton valide, rafraîchi au besoin ; un refus de rafraîchissement DÉCONNECTE.
async function withToken(fn) {
  let conn = getConnection();
  if (!conn) throw notConnected();
  const refresh = async () => {
    if (!conn.refreshToken) { disconnect(); throw notConnected(); }
    try {
      const t = await refreshAccessToken({ clientId: conn.clientId, refreshToken: conn.refreshToken });
      conn = { ...conn, ...t, refreshToken: t.refreshToken || conn.refreshToken };
      writeKey('conn', conn);
    } catch (err) {
      if (err.code === 'TV_TOKEN') { disconnect(); throw notConnected(); }
      throw err;
    }
  };
  if (conn.expiresAt && conn.expiresAt < Date.now() + 60_000) await refresh();
  try {
    return await fn(conn.accessToken);
  } catch (err) {
    if (err.code !== 'TV_UNAUTHORIZED') throw err;
    state.session = null;
    await refresh();
    return fn(conn.accessToken);
  }
}

// --- Appels d'outils : un à la fois, avec pause après un 429 ------------------

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// `patient` (balayage) : attend la fin de la pause puis réessaie ; sinon (requête
// d'écran) échoue aussitôt pour que Yahoo prenne le relais sans faire attendre.
function runTool(name, args, { patient = false } = {}) {
  const run = async () => {
    for (let attempt = 0; attempt < 6; attempt += 1) {
      const wait = state.cooldownUntil - Date.now();
      if (wait > 0) {
        if (!patient) throw Object.assign(new Error('TradingView en pause après une limite (429).'), { code: 'TV_COOLDOWN' });
        await sleep(wait);
      }
      const gap = MIN_GAP_MS - (Date.now() - state.lastCallAt);
      if (gap > 0) await sleep(gap);
      try {
        const out = await withToken((token) => {
          if (!state.session || state.sessionToken !== token) { state.session = openMcpSession(token); state.sessionToken = token; }
          return state.session.call(name, args);
        });
        state.lastCallAt = Date.now();
        return out;
      } catch (err) {
        state.lastCallAt = Date.now();
        state.stats.lastError = err.message;
        if (err.code === 'TV_RATE_LIMIT') {
          state.stats.rateLimits += 1;
          state.cooldownUntil = Date.now() + COOLDOWN_MS;
          if (patient) continue;
        }
        // Une session MCP qui échoue côté transport est jetée : la suivante repart propre.
        if (err.code === 'TV_MCP') state.session = null;
        throw err;
      }
    }
    throw Object.assign(new Error('TradingView : trop de limites (429) consécutives.'), { code: 'TV_RATE_LIMIT' });
  };
  const p = state.chain.then(run, run);
  state.chain = p.catch(() => {});
  return p;
}

export function callToolLocal(name, args, opts) { return runTool(name, args, opts); }

// --- Fournisseur (cotations + historique) ------------------------------------

const symKey = (t) => `tv:sym:${t}`;

// Map ticker → { price, changePercent, volume, currency:null } pour ce que
// TradingView a résolu ET répondu ; le reste est ABSENT (Yahoo complète).
export async function tvTryQuotes(tickers, opts = {}) {
  const out = new Map();
  try {
    const known = [];
    const candidates = new Map();
    for (const t of tickers) {
      const c = readCache(symKey(t));
      if (c.hit && c.value === 'none') continue;
      if (c.hit && typeof c.value === 'string') known.push([t, c.value]);
      else { const cand = yahooTickerToTvCandidates(t); if (cand) candidates.set(t, cand); }
    }
    const take = (rows, sym, ticker) => {
      const r = rows[sym];
      if (!r || r.close == null) return false;
      out.set(ticker, { price: r.close, changePercent: r.change ?? null, volume: r.volume ?? null, currency: null });
      return true;
    };
    const batch = async (pairs) => {
      const found = [];
      for (let i = 0; i < pairs.length; i += BATCH_MAX) {
        const chunk = pairs.slice(i, i + BATCH_MAX);
        const res = await runTool('mcp-tv-get-symbol-data-batch', { symbols: chunk.map((p) => p[1]), columns: ['close', 'change', 'volume'] }, opts);
        for (const [ticker, sym] of chunk) if (take(res.data || {}, sym, ticker)) found.push([ticker, sym]);
      }
      return found;
    };
    if (known.length) await batch(known);
    let remaining = [...candidates.keys()];
    for (let round = 0; round < 3 && remaining.length; round += 1) {
      const pairs = remaining.map((t) => [t, candidates.get(t)[round]]).filter((p) => p[1]);
      if (!pairs.length) break;
      const found = await batch(pairs);
      for (const [t, sym] of found) writeCache(symKey(t), sym, SYMBOL_TTL);
      const ok = new Set(found.map((f) => f[0]));
      remaining = remaining.filter((t) => !ok.has(t));
    }
    for (const t of remaining) writeCache(symKey(t), 'none', NONE_TTL);
  } catch { /* on rend ce qu'on a ; Yahoo complète */ }
  state.stats.tv += out.size;
  return out;
}

// Barres quotidiennes d'UN ticker, ou null (Yahoo complète). Ne lève jamais.
// Le symbole TradingView se résout EN ESSAYANT l'historique lui-même (NASDAQ, NYSE,
// AMEX…) : un symbole invalide échoue en < 1 s (« invalid symbol »). On évite ainsi
// le scanner (mcp-tv-get-symbol-data-batch), qui répond 429 en continu (mesuré le
// 7/10/2026) alors que l'outil d'historique, lui, n'est pas limité.
export async function tvTryHistory(ticker, lookbackDays, opts = {}) {
  try {
    const c = readCache(symKey(ticker));
    if (c.hit && c.value === 'none') return null;
    const cand = c.hit && typeof c.value === 'string' ? [c.value] : yahooTickerToTvCandidates(ticker);
    if (!cand) return null;
    const count = Math.min(5000, Math.max(30, Math.ceil(lookbackDays * 0.72) + 10));
    for (const sym of cand) {
      try {
        const res = await runTool('mcp-tv-get-ohlcv', { symbol: sym, interval: '1D', count }, opts);
        const bars = tvBarsToDailyBars(res.bars);
        if (!bars.length) continue;
        writeCache(symKey(ticker), sym, SYMBOL_TTL);
        state.stats.tv += 1;
        return bars;
      } catch (err) {
        if (err.code === 'TV_TOOL' && /invalid symbol/i.test(err.message)) continue; // mauvaise bourse : suivante
        throw err;
      }
    }
    writeCache(symKey(ticker), 'none', NONE_TTL);
    return null;
  } catch { return null; }
}

// Watchlists du compte (lecture seule), pour un futur import.
export async function listWatchlists() {
  return runTool('mcp-watchlist-list-watchlists', {});
}
