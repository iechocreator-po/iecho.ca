// js/options-tab-a.js — onglet « Options » (créé le 22/9/2026 sous le nom
// « Options A » ; l'ancien onglet de base et le flag options_a_tab ont été
// supprimés le 29/9/2026) : chaîne d'options enrichie pour la vente de puts à primes continues —
//   #1  rendement annualisé de la prime,
//   #2  probabilité d'assignation en clair (à partir du delta estimé),
//   #3  capital requis,
//   #10 alerte résultats/dividende,
//   #11 grille de rendement annualisé (strike × échéance),
//   #12 calculateur de roulement.
//
// Réutilise les fonctions PURES déjà globales de js/options-common.js
// (optionsStrikeBounds, optionPassesFilters, optionsActiveFilterCount,
// optionsCsvRows, optionsToCSV) et de js/options-analytics.js
// (optAnnualizedYield, optCapitalRequired, optAssignmentProbabilityLabel,
// optRollNetCredit) — aucune de ces formules n'est redéfinie ici.
//
// Même règle d'honnêteté que partout ailleurs : une valeur absente ou non
// calculable s'affiche « — », jamais 0 ni un chiffre inventé.

let optaChain = null;
let optaSide = (() => { try { return localStorage.getItem('castellana-opta-side') === 'call' ? 'call' : 'put'; } catch (_) { return 'put'; } })();
let optaLaboContext = { ticker: null, sigma: null, daysToEarnings: null, earningsDate: null, earningsTiming: null };
// IV Rank réel (#377) — LOCAL seulement (l'historique vient du Radar). `data` est
// null si la route n'existe pas (cloud) ou si l'historique est insuffisant.
let optaIvRank = { ticker: null, data: null, reachable: false };

const oa = (s) => optEsc(s); // alias court, même échappement que l'onglet Options

// Actions par contrat — paramètre partagé avec le Labo (roue.contractSize,
// défaut 100), pour que « capital requis » corresponde à ce que le Labo
// utilise ailleurs dans l'app plutôt qu'une constante isolée ici.
function optaContractSize() {
  const p = typeof laboEffectiveParams === 'function' ? laboEffectiveParams('roue', (typeof laboParamOverrides !== 'undefined' ? laboParamOverrides.roue : {})) : null;
  return p ? p.contractSize : 100;
}

function optaFilters() {
  const n = (id) => {
    const raw = document.getElementById(id).value.trim();
    const v = parseFloat(raw);
    return raw !== '' && Number.isFinite(v) && v >= 0 ? v : null;
  };
  return {
    rangePct: n('opta-range'),
    minOI: n('opta-min-oi'),
    minVolume: n('opta-min-vol'),
    quotedOnly: document.getElementById('opta-quoted').checked,
  };
}

// Règle de prime minimale (voir optPremiumRule) — défauts 0,5 % / 5 jours,
// modifiables, mémorisés par navigateur. Une saisie vide ou invalide retombe
// sur le défaut plutôt que de désactiver la règle en silence.
const OPTA_RULE_DEFAULT = { pct: 0.5, days: 5 };
const OPTA_RULE_KEY = 'castellana-opta-rule';
function optaRule() {
  const num = (id, def) => { const v = parseFloat(document.getElementById(id).value); return v > 0 ? v : def; };
  return { pct: num('opta-rule-pct', OPTA_RULE_DEFAULT.pct), days: num('opta-rule-days', OPTA_RULE_DEFAULT.days), hide: document.getElementById('opta-rule-hide').checked };
}
// Copie la règle d'un jeu de champs (préfixe 'opta' = chaîne, 'janl' = screener
// de primes) vers l'autre, la mémorise et rafraîchit les deux affichages.
function optaSyncRuleInputs(fromPrefix) {
  const get = (p, k) => document.getElementById(`${p}-rule-${k}`);
  if (!get(fromPrefix, 'pct')) return;
  const src = { pct: get(fromPrefix, 'pct').value, days: get(fromPrefix, 'days').value, hide: get(fromPrefix, 'hide').checked };
  for (const p of ['opta', 'janl']) {
    if (p === fromPrefix || !get(p, 'pct')) continue;
    get(p, 'pct').value = src.pct; get(p, 'days').value = src.days; get(p, 'hide').checked = src.hide;
  }
  optaSaveRule();
  renderOptaChain();
  if (typeof janlRenderScreener === 'function') janlRenderScreener();
}
function optaSaveRule() {
  try { localStorage.setItem(OPTA_RULE_KEY, JSON.stringify(optaRule())); } catch (_) { /* stockage indisponible : sans effet */ }
}
function optaLoadRule() {
  try {
    const r = JSON.parse(localStorage.getItem('castellana-opta-rule') || 'null');
    if (!r) return;
    for (const p of ['opta', 'janl']) {
      const el = (k) => document.getElementById(`${p}-rule-${k}`);
      if (!el('pct')) continue;
      if (r.pct > 0) el('pct').value = r.pct;
      if (r.days > 0) el('days').value = r.days;
      el('hide').checked = !!r.hide;
    }
  } catch (_) { /* valeurs par défaut */ }
}

// ---- Expected move (12/10/2026) — mouvement attendu jusqu'à l'échéance, en
// multiples de σ réglables. Calcul pur dans js/options-analytics.js
// (optExpectedMove / optEmPosition / optIdealStrike) ; ici seulement l'état et l'affichage.
const OPTA_EM_KEY = 'castellana-opta-em-mult';
let optaCurMove = null;                 // plage de la chaîne affichée (null = non évaluable)
let optaCurIdeal = { put: null, call: null };
function optaEmMult() {
  const v = parseFloat(document.getElementById('opta-em-mult')?.value);
  return v > 0 && v <= 5 ? v : 1;
}
function optaLoadEmMult() {
  try {
    const v = parseFloat(localStorage.getItem(OPTA_EM_KEY));
    const el = document.getElementById('opta-em-mult');
    if (el && v > 0 && v <= 5) el.value = v;
  } catch (_) { /* valeur par défaut : 1σ */ }
}
function optaSaveEmMult() {
  try { localStorage.setItem(OPTA_EM_KEY, String(optaEmMult())); } catch (_) { /* sans effet */ }
}
const optaFr = (v, d = 2) => (v == null || !Number.isFinite(v) ? '—' : v.toFixed(d).replace('.', ','));
// Plage de l'expected move de la chaîne chargée : IV de la monnaie (UNE IV pour toute l'échéance).
function optaComputeMove(ch) {
  if (!ch) return null;
  const iv = optAtmIv([...ch.calls, ...ch.puts]);
  return optExpectedMove(ch.price, iv, ch.dte, optaEmMult());
}
// Pastille « hors EM / dans EM » d'un strike hors la monnaie : génériquement (chaîne F3, meilleurs
// deals, screener G2). `move` = plage de l'expected move (optExpectedMove) ; null → rien.
function optaEmBadge(type, strike, move, ideal = false) {
  if (!move) return '';
  const pos = optEmPosition(type, strike, move);
  if (!pos) return '';
  const txt = pos.outside ? `hors EM${ideal ? ' ◆' : ''}` : 'dans EM';
  const tip = `${pos.outside ? 'Hors' : 'Dans'} la plage de l'expected move (${optaFr(move.mult, 2)}σ : ${optaFr(move.low)} – ${optaFr(move.high)} $). ${pos.outside ? `Le strike est ${optaFr(pos.emMargin)} $ au-delà de la borne.` : `Le strike est ${optaFr(-pos.emMargin)} $ en deçà de la borne.`}${ideal ? ' ◆ = strike idéal : le plus proche du prix hors de la plage, et qui respecte la règle de prime.' : ''}`;
  return ` <span class="ds-badge ${pos.outside ? 'ds-badge--success' : 'ds-badge--warning'}" title="${oa(tip)}">${txt}</span>`;
}
// Chaîne F3 et meilleurs deals : uniquement les contrats hors la monnaie.
function optaEmTag(type, c) {
  if (!optaCurMove || c.itm) return '';
  const ideal = !!(optaCurIdeal[type] && optaCurIdeal[type].contract.strike === c.strike);
  return optaEmBadge(type, c.strike, optaCurMove, ideal);
}

// Verdict de la règle pour un contrat de la chaîne chargée (null = non évaluable).
function optaRuleFor(type, c, rule) {
  if (!optaChain || !c) return null;
  return optPremiumRule(type, optaChain.price, c.strike, c.bid, optaChain.dte, rule.pct, rule.days);
}

// Cellules enrichies d'un contrat : colonnes existantes + rendement
// annualisé (#1) + capital requis (#3), delta avec probabilité en clair (#2).
function optaCells(c, type, rule, limit) {
  if (!c) return '<td>—</td>'.repeat(11);
  const sty = tsGet('f3'); // style d'affichage (Réglages → Personnalisation) : l'ITM et la règle se lisent au niveau de la ligne
  const cls = '';
  const rv = optaRuleFor(type, c, rule);
  const okCls = '';
  const ruleTitle = rv ? ` title="règle ${rule.pct} % / ${rule.days} j : seuil ${rv.required.toFixed(2)} $ (${rv.requiredPct.toFixed(2)} % du strike) — ${rv.ok ? 'respectée' : 'non respectée'}, prime ${rv.premium.toFixed(2)} $ = ${rv.ratio.toFixed(2)}× le seuil"` : '';
  const spread = c.bid != null && c.ask != null ? ` title="spread bid-ask : ${(c.ask - c.bid).toFixed(2)}"` : '';
  // Prime réaliste d'une vente : ce que le marché offre réellement (bid),
  // jamais l'ask (prix d'achat) ni le dernier échangé (peut être périmé).
  const premium = c.bid;
  const yieldPct = optaChain ? optAnnualizedYield(premium, c.strike, optaChain.dte) : null;
  const capital = optCapitalRequired(c.strike, optaContractSize(), 1);
  const proba = optAssignmentProbabilityLabel(c.delta);
  const deltaTitle = proba ? ` title="probabilité d'assignation ${proba.label} (≈${proba.pct} %) — approximation à partir du delta estimé"` : '';
  // Marge (4/10/2026) : distance au prix et en écarts-types attendus ; ★ = strike limite
  // (le plus éloigné dont le bid respecte encore la règle — meilleur compromis).
  const cu = optaChain ? optCushion(type, optaChain.price, c.strike, c.iv, optaChain.dte) : null;
  const isLimit = limit && limit.strike === c.strike;
  const marge = cu ? `${isLimit && sty !== '2' && sty !== '4' ? '★ ' : ''}${cu.distancePct.toFixed(1).replace('.', ',')} % · ${cu.sigmaMargin.toFixed(1).replace('.', ',')}σ` : '—';
  const margeTitle = cu ? ` title="${cu.distancePct.toFixed(2)} % ${cu.distancePct >= 0 ? 'hors de la monnaie' : 'dans la monnaie'} · ${cu.sigmaMargin.toFixed(2)} écart-type du mouvement attendu (IV × √DTE)${isLimit ? ' — STRIKE LIMITE : le plus éloigné dont le bid respecte la règle' : ''}"` : '';
  // Rendement de la période : prime / strike en %, à comparer au seuil de la règle (ex. 0,45 % pour 0,50 % exigé).
  const premPct = rv ? (rv.premium / c.strike) * 100 : (c.bid > 0 ? (c.bid / c.strike) * 100 : null); // échéance du jour : pas de seuil, mais la prime reste lisible
  const premTitle = rv ? ` title="prime ${rv.premium.toFixed(2)} $ ÷ strike = ${premPct.toFixed(2)} % — seuil de la règle pour ${optaChain.dte} j : ${rv.requiredPct.toFixed(2)} % (${(rv.ratio * 100).toFixed(0)} % du seuil atteint)"` : '';
  const good = rv && rv.ok && (sty === '2' || sty === '5') ? ' class="good"' : '';
  const premCell = sty === '1' ? `<td class="prem"${premTitle}>${tsGauge(rv ? rv.ratio : null, premPct == null ? '—' : premPct.toFixed(2).replace('.', ',') + ' %')}</td>`
    : sty === '3' ? `<td${premTitle}><span class="ts-dot${rv && rv.ok ? ' ok' : ''}"></span>${premPct == null ? '—' : premPct.toFixed(2).replace('.', ',') + ' %'}</td>`
    : `<td${good}${premTitle}>${premPct == null ? '—' : premPct.toFixed(2).replace('.', ',') + ' %'}${sty === '2' && rv && rv.ok ? ' ✓' : ''}</td>`;
  const yieldCell = sty === '3' ? `<td class="heat" style="${tsHeat(yieldPct == null ? null : yieldPct / 60)}" title="prime (bid) / strike × 365/échéance, sur 1 contrat">${yieldPct == null ? '—' : yieldPct.toFixed(1) + ' %'}</td>`
    : `<td${good} title="prime (bid) / strike × 365/échéance, sur 1 contrat">${yieldPct == null ? '—' : yieldPct.toFixed(1) + ' %'}</td>`;
  const svg = sty === '5' && optaChain ? tsSigmaSvg(c.strike, optaChain.price, c.iv, optaChain.dte, !!(rv && rv.ok)) : '';
  const margeCell = `<td${isLimit ? ' class="opt-rule-limit"' : ''}${sty === '3' ? ` style="${tsHeat(cu ? Math.max(0, cu.sigmaMargin) / 2 : null)}"` : ''}${margeTitle}>${marge}${svg ? ' ' + svg : ''}${optaEmTag(type, c)}</td>`;
  return [
    `<td${okCls}${ruleTitle}>${optNum(c.bid)}</td>`,
    `<td${cls}${spread}>${optNum(c.ask)}</td>`,
    `<td${cls}>${optNum(c.last)}</td>`,
    `<td${cls}>${optInt(c.volume)}</td>`,
    `<td${cls}>${optInt(c.openInterest)}</td>`,
    `<td${cls}>${optPct(c.iv)}</td>`,
    `<td${cls}${deltaTitle}>${optDelta(c.delta)}${proba ? ` <span class="ds-text-hint">(${proba.pct}%)</span>` : ''}</td>`,
    premCell,
    yieldCell,
    `<td${cls} title="strike × ${optaContractSize()} actions/contrat, sur 1 contrat">${capital == null ? '—' : capital.toLocaleString('fr-CA', { maximumFractionDigits: 0 })} $</td>`,
    margeCell,
  ].join('');
}

function renderOptaChain() {
  const host = document.getElementById('opta-table-host');
  const meta = document.getElementById('opta-meta');
  if (!optaChain) { host.innerHTML = ''; meta.textContent = ''; optaCurMove = null; optaCurIdeal = { put: null, call: null }; renderOptaEm(null); renderOptaTransparency(null); return; }
  const ch = optaChain;
  const f = optaFilters();
  const rule = optaRule();
  const price = ch.price;
  const { lo, hi } = optionsStrikeBounds(price, f.rangePct);

  // Strikes limites (sur les contrats qui passent les filtres de données : un strike
  // sans liquidité ne doit pas être proposé comme « le meilleur »).
  const limitPut = optRuleLimit('put', price, ch.puts.filter((c) => optionPassesFilters(c, f)), ch.dte, rule.pct, rule.days);
  const limitCall = optRuleLimit('call', price, ch.calls.filter((c) => optionPassesFilters(c, f)), ch.dte, rule.pct, rule.days);
  // Expected move + strike idéal (règle de prime ET hors de la plage), sur les contrats qui passent les filtres.
  optaCurMove = optaComputeMove(ch);
  optaCurIdeal = {
    put: optIdealStrike('put', price, ch.puts.filter((c) => optionPassesFilters(c, f)), ch.dte, rule.pct, rule.days, optaCurMove),
    call: optIdealStrike('call', price, ch.calls.filter((c) => optionPassesFilters(c, f)), ch.dte, rule.pct, rule.days, optaCurMove),
  };
  // Un tableau par côté (puts / calls) — onglets « Puts » et « Calls » (4/10/2026).
  const side = optaSide;
  const limit = side === 'put' ? limitPut : limitCall;
  const by = new Map((side === 'put' ? ch.puts : ch.calls).map((c) => [c.strike, c]));
  const strikes = [...by.keys()].filter((k) => k >= lo && k <= hi).sort((a, b) => a - b);
  const atm = price != null && strikes.length ? strikes.reduce((b, k) => (Math.abs(k - price) < Math.abs(b - price) ? k : b)) : null;

  let shown = 0;
  const sty = tsGet('f3');
  let spotDone = false;
  const rows = strikes.map((k) => {
    const c = by.get(k);
    if (!optionPassesFilters(c, f)) return '';
    const rv = optaRuleFor(side, c, rule);
    // « non évaluable » (pas de bid) est masqué aussi avec « Masquer » : rien n'a été démontré
    if (rule.hide && !rv?.ok) return '';
    shown++;
    const isLim = limit && limit.strike === k;
    let spot = '';
    if (sty === '2' && !spotDone && price != null && k >= price) { spotDone = true; spot = `<tr class="spot"><td colspan="14"><div class="ts-spot">Prix ${optNum(price)} $ · ${ch.dte ?? '?'} j</div></td></tr>`; }
    const tag = sty === '4' ? (isLim ? '<span class="ts-tag">limite</span>' : '') + (c.itm ? '<span class="ts-tag ts-tag-g">ITM</span>' : '') : sty === '2' && isLim ? '<span class="ts-pill">LIMITE</span>' : '';
    return `${spot}<tr class="${k === atm && sty !== '2' ? 'opt-atm ' : ''}${c.itm ? 'itm' : 'otm'} ${rv?.ok ? 'ok' : 'under'}${isLim ? ' lim' : ''}">
      <td class="opt-strike"><strong>${optNum(k)}</strong>${tag}</td>
      ${optaCells(c, side, rule, limit)}${optaRollCell(side, c)}
    </tr>`;
  }).join('');

  const nFilters = optionsActiveFilterCount(f);
  document.getElementById('opta-filter-summary').textContent = nFilters ? `Filtres sur les données (${nFilters} actif${nFilters > 1 ? 's' : ''})` : 'Filtres sur les données (aucun actif)';
  const total = by.size;
  document.querySelectorAll('#opta-side button').forEach((b) => { b.classList.toggle('is-active', b.dataset.side === side); b.textContent = `${b.dataset.side === 'put' ? 'Puts' : 'Calls'} (${(b.dataset.side === 'put' ? ch.puts : ch.calls).length})`; });
  const limTxt = (nom, c) => {
    if (!c) return `${nom} : aucun strike ne respecte la règle`;
    const cu = optCushion(nom === 'put' ? 'put' : 'call', price, c.strike, c.iv, ch.dte);
    return `${nom} ★ ${optNum(c.strike)}${c.delta != null ? ` (Δ ${Math.abs(c.delta).toFixed(2)}` : ' ('}${cu ? `, ${cu.distancePct.toFixed(1)} % du prix, ${cu.sigmaMargin.toFixed(1)}σ` : ''})`;
  };
  document.getElementById('opta-limit').textContent = `Strike limite — ${limTxt('put', limitPut)} · ${limTxt('call', limitCall)}`;
  renderOptaEm(ch);
  renderOptaTransparency(ch, rule, limitPut, limitCall);
  meta.textContent = `${ch.ticker} · prix ${optNum(price)} · échéance ${ch.expiry} (${ch.dte ?? '?'} j) · ${side === 'put' ? 'puts' : 'calls'} : ${shown}/${total} strikes affichés · règle ${rule.pct} % / ${rule.days} j → seuil ${ch.dte >= 1 ? (rule.pct * ch.dte / rule.days).toFixed(2) + ' % du strike' : 'n/d'} à ${ch.dte ?? '?'} j (surligné = respectée) · rendement/capital calculés sur 1 contrat (${optaContractSize()} actions) · données différées ~15 min, chargées à ${new Date(ch.fetchedAt).toLocaleTimeString('fr-CA')}`;
  host.innerHTML = shown
    ? `${tsLegend('f3', sty)}<div style="overflow-x:auto"><table class="ds-table opt-table tsx tsx${sty}">
        <thead>
          <tr><th>Strike${optInfoBtn('optStrike')}</th><th>Bid${optInfoBtn('optBid')}</th><th>Ask${optInfoBtn('optAsk')}</th><th>Dernier${optInfoBtn('optLast')}</th><th>Vol.${optInfoBtn('optVol')}</th><th>OI${optInfoBtn('optOI')}</th><th>IV <button type="button" class="info-btn" onclick="showGlossaire('iv', this)" title="Aide">i</button></th><th>Δ est.${optInfoBtn('delta')}</th><th title="Prime (bid) ÷ strike, à comparer au seuil de la règle pour cette échéance : ${ch.dte >= 1 ? (rule.pct * ch.dte / rule.days).toFixed(2).replace('.', ',') + ' %' : 'n/d'}.">Prime / strike <span class="ds-text-hint">(seuil ${ch.dte >= 1 ? (rule.pct * ch.dte / rule.days).toFixed(2).replace('.', ',') + ' %' : 'n/d'})</span>${optInfoBtn('optPremPct')}</th><th title="rendement annualisé de la prime (vente à ce bid)">Rend. ann.${optInfoBtn('optYield')}</th><th title="capital requis pour 1 contrat">Capital${optInfoBtn('optCapital')}</th><th title="Distance du strike au prix (% du prix) · en écarts-types du mouvement attendu (IV × √DTE). ★ = strike limite : le plus éloigné dont le bid respecte la règle de prime.">Marge <button type="button" class="info-btn" onclick="showGlossaire('marge', this)" title="Aide">i</button></th><th title="envoyer ce contrat au calculateur de roulement">Roul.${optInfoBtn('optRoll')}</th></tr>
        </thead><tbody>${rows}</tbody></table></div>`
    : `<p class="ds-text-muted">${nFilters ? `Aucun des ${total} strikes de cette échéance ne passe les ${nFilters} filtre(s) actif(s).` : `Yahoo n'a renvoyé aucun contrat pour cette échéance (${ch.calls.length} calls, ${ch.puts.length} puts).`}</p>${nFilters ? '<button type="button" class="ds-btn" onclick="resetOptaFilters()">Réinitialiser les filtres</button>' : ''}`;
}

// Ligne de synthèse de l'expected move + strike idéal (puts et calls).
function renderOptaEm(ch) {
  const el = document.getElementById('opta-em');
  if (!el) return;
  if (!ch) { el.textContent = ''; return; }
  const m = optaCurMove;
  if (!m) {
    el.textContent = ch.dte < 1
      ? 'Expected move : non évaluable pour une échéance du jour (DTE 0) — choisis une échéance plus lointaine.'
      : 'Expected move : non évaluable (IV à la monnaie indisponible : moins de 2 contrats avec delta entre 0,40 et 0,60).';
    return;
  }
  const idealTxt = (nom, r) => {
    if (!r) return `${nom} : aucun strike coté hors de la plage`;
    const k = optNum(r.contract.strike);
    return r.failsRule
      ? `${nom} : la règle de prime n'est PAS atteignable hors de la plage (le premier strike hors plage, ${k}, ne paie que ${optaFr(r.rule.ratio * 100, 0)} % du seuil)`
      : `${nom} ◆ ${k} (${optaFr(optEmPosition(nom === 'put' ? 'put' : 'call', r.contract.strike, m).emMargin)} $ au-delà de la borne, prime = ${optaFr(r.rule.ratio, 2)}× le seuil)`;
  };
  el.innerHTML = `<strong>Expected move ${optaFr(m.mult, 2)}σ</strong> — ±${optaFr(m.em)} $ (±${optaFr(m.emPct, 1)} %) → plage <strong>${optaFr(m.low)} – ${optaFr(m.high)} $</strong> · IV à la monnaie ${optaFr(m.iv * 100, 1)} %<br>Strike idéal (hors de la plage ET règle de prime respectée) — ${oa(idealTxt('put', optaCurIdeal.put))} · ${oa(idealTxt('call', optaCurIdeal.call))}`;
}

// Section repliable « Calculs et formules » : tout ce que fait l'onglet, avec les
// valeurs de la chaîne affichée, pour qu'on puisse revérifier à la main.
function renderOptaTransparency(ch, rule, limitPut, limitCall) {
  const host = document.getElementById('opta-transparency');
  if (!host) return;
  const p = typeof laboEffectiveParams === 'function' ? laboEffectiveParams('roue', (typeof laboParamOverrides !== 'undefined' ? laboParamOverrides.roue : {})) : null;
  const r = p ? p.riskFreePct : null;
  const live = (txt) => ch ? ` <span class="ds-text-hint">→ ${txt}</span>` : '';
  const m = ch ? optaCurMove : null;
  const st = ch ? optStraddleMove(ch.price, ch.calls, ch.puts) : null;
  const rl = rule || (typeof optaRule === 'function' ? optaRule() : { pct: 0.5, days: 5 });
  const fmtK = (c) => (c ? optNum(c.strike) : 'aucun');
  const li = [];
  li.push(`<li><strong>Expected move (EM)</strong> = prix × IV<sub>ATM</sub> × √(DTE ÷ 365) × k, où k = multiple de σ choisi (${optaFr(optaEmMult(), 2)}). À k = 1, c'est un écart-type : le prix reste dans la plage environ 68 % du temps (k = 2 ≈ 95 %), selon le modèle.${live(m ? `${optaFr(ch.price)} × ${optaFr(m.iv, 4)} × √(${ch.dte} ÷ 365) × ${optaFr(m.mult, 2)} = <strong>${optaFr(m.em, 3)} $</strong> (±${optaFr(m.emPct, 2)} %), plage ${optaFr(m.low)} – ${optaFr(m.high)} $` : 'non évaluable')}</li>`);
  li.push(`<li><strong>IV<sub>ATM</sub></strong> = médiane de l'IV des contrats (calls et puts) dont |delta| est entre 0,40 et 0,60 ; au moins 2 contrats requis. Une seule IV sert pour toute l'échéance, donc la plage est la même pour tous les strikes.${live(m ? `${optaFr(m.iv * 100, 2)} %` : 'indisponible')}</li>`);
  li.push(`<li><strong>Hors de la plage</strong> : un put vendu est « hors EM » si strike ≤ prix − EM ; un call si strike ≥ prix + EM. Seuls les contrats hors la monnaie sont étiquetés.${live(m ? `put : strike ≤ ${optaFr(m.low)} $ · call : strike ≥ ${optaFr(m.high)} $` : '—')}</li>`);
  li.push(`<li><strong>Règle de prime</strong> : prime exigée = strike × ${optaFr(rl.pct, 2)} % × (DTE ÷ ${rl.days}). La prime comparée est la valeur temps du bid (bid − valeur intrinsèque ; pour un contrat hors la monnaie, c'est le bid).${live(ch ? `à ${ch.dte} j, seuil = ${optaFr(rl.pct * ch.dte / rl.days, 3)} % du strike` : '—')}</li>`);
  li.push(`<li><strong>Strike limite ★</strong> : en partant du strike le plus proche du prix et en s'éloignant, le dernier dont la prime respecte la règle (on s'arrête au premier qui échoue).${live(ch ? `put ${fmtK(limitPut)} · call ${fmtK(limitCall)}` : '—')}</li>`);
  li.push(`<li><strong>Strike idéal ◆</strong> : le contrat hors de la plage de l'EM le plus proche du prix (la prime baisse avec la distance, donc c'est lui qui paie le plus tout en restant hors plage), à condition qu'il respecte la règle de prime. S'il ne la respecte pas, l'app le dit : la règle n'est alors pas atteignable hors de la plage.${live(ch ? `put ${optaCurIdeal.put ? fmtK(optaCurIdeal.put.contract) + (optaCurIdeal.put.failsRule ? ' (sous la règle)' : '') : 'aucun'} · call ${optaCurIdeal.call ? fmtK(optaCurIdeal.call.contract) + (optaCurIdeal.call.failsRule ? ' (sous la règle)' : '') : 'aucun'}` : '—')}</li>`);
  li.push(`<li><strong>Marge</strong> (colonne existante) : distance = (prix − strike) ÷ prix pour un put, (strike − prix) ÷ prix pour un call ; marge en σ = distance ÷ (IV<sub>du contrat</sub> × √(DTE ÷ 365)). Elle utilise l'IV de chaque contrat, alors que l'EM utilise l'IV à la monnaie : les deux peuvent différer légèrement (smile de volatilité).</li>`);
  li.push(`<li><strong>Delta estimé</strong> : Black-Scholes, N(d1) − 1 pour un put, avec d1 = [ln(S ÷ K) + (r + IV²÷2) × T] ÷ (IV × √T), T = DTE ÷ 365, IV = celle du contrat, r = taux sans risque des paramètres de la Roue.${live(r != null ? `r = ${optaFr(r, 2)} %` : '—')}</li>`);
  li.push(`<li><strong>Rendement annualisé</strong> = (bid ÷ strike) × (365 ÷ DTE) × 100, sur le bid (jamais l'ask). <strong>Capital</strong> = strike × ${optaContractSize()} actions × contrats.</li>`);
  li.push(`<li><strong>Recoupement par le straddle</strong> (vérification, non utilisé pour les étiquettes) : un straddle à la monnaie vaut ≈ 0,80 × EM(1σ) en théorie (0,80 = √(2÷π), c'est le mouvement absolu moyen). Donc EM(1σ) ≈ (mid du call + mid du put) au strike le plus proche du prix ÷ 0,80. Un écart notable avec l'EM par l'IV signale une cote douteuse ou un strike ATM peu liquide.${live(st ? `strike ${optNum(st.strike)} : ${optaFr(st.call)} + ${optaFr(st.put)} = ${optaFr(st.straddle)} $ ÷ ${optaFr(st.ratio, 4)} = <strong>${optaFr(st.em, 3)} $</strong>${m ? ` (contre ${optaFr(m.em1, 3)} $ à 1σ par l'IV, écart ${optaFr((st.em / m.em1 - 1) * 100, 1)} %)` : ''}` : 'bid/ask indisponibles au strike le plus proche')}</li>`);
  host.innerHTML = `<ul class="calc-list" style="padding-left:1.1rem; margin:0.5rem 0; display:grid; gap:0.5rem;">${li.join('')}</ul>
    <p class="metric-sub" style="text-align:left;"><strong>Limites.</strong> L'EM est une estimation du marché (volatilité implicite), pas une garantie : à 1σ, le prix sort de la plage environ une fois sur trois. Les cotes sont différées d'environ 15 minutes ; hors des heures de marché, bid/ask à zéro donnent « — ». Si l'échéance dépasse une publication de résultats, l'IV (donc l'EM) intègre déjà ce saut. L'IV d'un jour très proche de l'échéance est instable. Aucune de ces valeurs n'est une recommandation.</p>`;
}

// Même comparaison Labo vs marché que l'onglet Options d'origine.
function renderOptaCompare() {
  const host = document.getElementById('opta-compare');
  const ch = optaChain;
  if (!ch || typeof laboEffectiveParams !== 'function') { host.innerHTML = ''; return; }
  const p = laboEffectiveParams('roue', (typeof laboParamOverrides !== 'undefined' ? laboParamOverrides.roue : {}));
  const sigma = optaLaboContext.ticker === ch.ticker ? optaLaboContext.sigma : null;
  const r = p.riskFreePct / 100;
  const legs = [
    { nom: 'Put vendu', type: 'put', contracts: ch.puts, dMin: p.putDeltaMin, dMax: p.putDeltaMax, dteMin: p.putDteMin, dteMax: p.putDteMax },
    { nom: 'Call vendu', type: 'call', contracts: ch.calls, dMin: p.callDeltaMin, dMax: p.callDeltaMax, dteMin: p.callDteMin, dteMax: p.callDteMax },
  ];
  const fmt = (z) => (z ? `${optNum(z.basse)} – ${optNum(z.haute)}` : '—');
  const rows = legs.map((L) => {
    const market = optionMarketZone(L.contracts, L.dMin, L.dMax);
    const dteMoy = Math.round((L.dteMin + L.dteMax) / 2);
    const labo = sigma != null ? laboStrikeZone({ S: ch.price, T: dteMoy / 365, r, sigma, deltaMin: L.dMin, deltaMax: L.dMax, type: L.type, role: L.nom, dteJours: dteMoy }) : null;
    const hors = ch.dte < L.dteMin || ch.dte > L.dteMax;
    return `<tr><td>${oa(L.nom)}</td><td>${L.dMin}–${L.dMax}</td><td><strong>${fmt(market)}</strong></td>
      <td>${labo ? fmt(labo) : '—'} <span class="ds-text-hint">(~${dteMoy} j)</span></td>
      <td class="ds-text-hint">${hors ? `⚠ échéance affichée (${ch.dte} j) hors de la fenêtre ${L.dteMin}–${L.dteMax} j de la Roue` : ''}</td></tr>`;
  }).join('');
  host.innerHTML = `<div class="section-title">Repères de la Roue : Labo vs marché</div>
    <p class="metric-sub" style="text-align:left;">Pour la plage de delta de la stratégie « La Roue » (réglable dans le Labo) : <strong>Marché</strong> = strikes de cette chaîne dont le delta estimé (IV du marché) tombe dans la plage ; <strong>Labo</strong> = estimation par la volatilité historique${sigma != null ? ` (${(sigma * 100).toFixed(0)} %)` : ' — indisponible pour ce titre'}, à l'échéance moyenne de la stratégie. Ce sont des estimations, pas des recommandations.</p>
    <table class="ds-table"><thead><tr><th>Jambe</th><th>Delta cible</th><th>Marché (échéance affichée)</th><th>Labo</th><th></th></tr></thead><tbody>${rows}</tbody></table>`;
}

// #10 — alerte résultats/dividende, réutilise /api/labo/:ticker déjà appelé
// pour la volatilité historique (aucun appel réseau de plus).
function renderOptaEarningsAlert() {
  const el = document.getElementById('opta-earnings-alert');
  const d = optaLaboContext.daysToEarnings;
  if (optaLaboContext.ticker !== optaChain?.ticker || d == null || d > 10 || d < 0) { el.style.display = 'none'; return; }
  el.style.display = '';
  el.textContent = `⚠ Résultats dans ${d} jour${d > 1 ? 's' : ''} — la prime de cette chaîne intègre probablement ce risque (IV souvent gonflée avant une publication).`;
}

async function loadOptaLaboContext(ticker) {
  if (optaLaboContext.ticker === ticker) return;
  try {
    const d = await fetchJSON(`/api/labo/${encodeURIComponent(ticker)}`);
    optaLaboContext = { ticker, sigma: d.historicalVolatility ?? null, daysToEarnings: d.daysToEarnings ?? null, earningsDate: d.earningsDate ?? null, earningsTiming: d.earningsTiming ?? null };
  } catch {
    optaLaboContext = { ticker, sigma: null, daysToEarnings: null, earningsDate: null, earningsTiming: null };
  }
}

async function loadOptaIvRank(ticker) {
  if (!optaChain || optaChain.ticker !== ticker) return;
  const atm = optAtmIv([...optaChain.calls, ...optaChain.puts]);
  try {
    const qs = atm != null ? `?iv=${atm.toFixed(6)}` : '';
    const d = await fetchJSON(`/api/iv-rank/${encodeURIComponent(ticker)}${qs}`);
    optaIvRank = { ticker, data: d, reachable: true };
  } catch {
    optaIvRank = { ticker, data: null, reachable: false }; // cloud : pas d'historique, on ne dit rien
  }
}

// Menu d'échéance : une ligne (option désactivée) marque la date des résultats entre
// les deux échéances qu'elle sépare. Les résultats arrivent avec /api/labo (asynchrone) :
// le menu est redessiné à ce moment-là.
function renderOptaExpiryOptions() {
  const sel = document.getElementById('opta-expiry');
  const ch = optaChain;
  if (!sel || !ch) return;
  const ctx = optaLaboContext.ticker === ch.ticker ? optaLaboContext : null;
  const ed = ctx && ctx.earningsDate && ctx.daysToEarnings != null ? ctx.earningsDate : null;
  const nice = ed ? new Date(`${ed}T12:00:00Z`).toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' }) : '';
  const label = ed ? `Earnings: ${nice}${ctx.earningsTiming ? `, ${ctx.earningsTiming}` : ''}` : '';
  const marker = () => `<option disabled value="">── ${oa(label)} ──</option>`;
  const parts = [];
  let placed = !ed;
  ch.expirations.forEach((e, i) => {
    // « après la clôture » : une échéance le jour même des résultats expire avant la publication
    if (!placed && (e.date > ed || (e.date === ed && ctx.earningsTiming === 'before open'))) { parts.push(marker()); placed = true; }
    parts.push(`<option value="${oa(e.date)}"${e.date === ch.expiry ? ' selected' : ''}>${oa(e.date)} (${e.dte} j)</option>`);
  });
  if (!placed) parts.push(marker());
  sel.innerHTML = parts.join('');
}

async function loadOptaChain(expiry = null) {
  const status = document.getElementById('opta-status');
  const ticker = document.getElementById('opta-ticker').value.trim().toUpperCase();
  if (!ticker) { status.textContent = 'Saisis un symbole.'; return; }
  status.textContent = 'Chargement…';
  try {
    const qs = expiry ? `?expiry=${encodeURIComponent(expiry)}` : '';
    const ch = await fetchJSON(`/api/options/${encodeURIComponent(ticker)}${qs}`);
    optionsAttachDeltas(ch); // fonction déjà globale (js/options-common.js)
    optaChain = ch;
    const sel = document.getElementById('opta-expiry');
    renderOptaExpiryOptions();
    status.textContent = '';
    renderOptaChain();
    renderOptaCompare();
    renderOptaEarningsAlert();
    renderOptaBestDeals();
    document.getElementById('opta-grid-host').innerHTML = '<p class="ds-text-muted">Clique « Générer la grille » pour ce symbole.</p>';
    loadOptaLaboContext(ticker).then(() => { renderOptaExpiryOptions(); renderOptaEarningsAlert(); renderOptaBestDeals(); });
    loadOptaIvRank(ticker).then(renderOptaBestDeals);
    if (typeof trackTickerSelected === 'function') trackTickerSelected('options-a', ticker, null);
  } catch (err) {
    optaChain = null;
    renderOptaChain();
    renderOptaCompare();
    renderOptaEarningsAlert();
    renderOptaBestDeals();
    status.textContent = 'Échec : ' + err.message;
  }
}

// ---- Meilleurs deals (22/9/2026) — classe TOUS les contrats de la chaîne
// chargée (calls + puts, échéance affichée) selon le mode Vente/Achat et
// le type choisi, via optScoreDeal() (js/options-analytics.js). Un
// contrat sans marché exploitable (pas d'ask) est EXCLU du classement, pas
// affiché avec un score neutre — voir optDealLiquidity().
function renderOptaBestDeals() {
  const host = document.getElementById('opta-deals-host');
  if (!host) return;
  const ch = optaChain;
  if (!ch) { host.innerHTML = '<p class="ds-text-muted">Charge une chaîne ci-dessus pour voir les meilleurs deals.</p>'; return; }
  const mode = document.getElementById('opta-deals-mode').value;
  const typeFilter = document.getElementById('opta-deals-type').value;
  const sigma = optaLaboContext.ticker === ch.ticker ? optaLaboContext.sigma : null;
  const ivInfo = optaIvRank.ticker === ch.ticker ? optaIvRank : { data: null, reachable: false };
  const ivRank = ivInfo.data && ivInfo.data.available ? ivInfo.data.rank : null;
  const ctx = { dte: ch.dte, price: ch.price, historicalVolatility: sigma, ivRank };

  const candidates = [];
  for (const [type, list] of [['put', ch.puts], ['call', ch.calls]]) {
    if (typeFilter !== 'both' && typeFilter !== type) continue;
    for (const c of list) {
      // `type` requis par optScoreDeal en mode vente (valeur intrinsèque/
      // extrinsèque) — c n'est pas modifié, juste enrichi pour l'appel.
      const scored = optScoreDeal(mode, { ...c, type }, ctx);
      if (scored) candidates.push({ type, contract: c, ...scored });
    }
  }
  // Trié par score total d'abord, puis par la métrique principale du mode
  // (rendement annualisé en vente, levier en achat) — le total seul peut
  // être à égalité entre plusieurs contrats.
  candidates.sort((a, b) => b.total - a.total || (b.rendement?.metric ?? -Infinity) - (a.rendement?.metric ?? -Infinity));
  const top = candidates.slice(0, 10);

  if (sigma == null) {
    host.innerHTML = '<p class="ds-text-muted">Volatilité historique du titre indisponible pour l\'instant — le sous-score de valorisation IV sera « — » ci-dessous (liquidité et rendement/levier restent calculés).</p>';
  } else {
    host.innerHTML = '';
  }
  if (ivInfo.reachable && ivInfo.data) {
    host.innerHTML += ivInfo.data.available
      ? `<p class="metric-sub" style="text-align:left;"><strong>IV Rank ${ivInfo.data.rank.toFixed(0)}</strong> (percentile ${ivInfo.data.percentile.toFixed(0)}, ${ivInfo.data.n} jours d'historique du Radar) — la valorisation ci-dessous s'appuie sur ce rang réel.</p>`
      : `<p class="metric-sub" style="text-align:left;">IV Rank : historique insuffisant (${ivInfo.data.days}/${ivInfo.data.minDays} jours accumulés par le Radar) — la valorisation utilise pour l'instant l'écart IV vs volatilité historique.</p>`;
  }
  if (!top.length) {
    host.innerHTML += '<p class="ds-text-muted">Aucun contrat avec un marché exploitable (ask réel) dans cette chaîne pour ce filtre.</p>';
    return;
  }
  const metricLabel = mode === 'vente' ? 'Rend. ann.' : 'Levier (Δ/prime)';
  const rows = top.map((d) => {
    const c = d.contract;
    const metric = d.rendement == null ? '—' : mode === 'vente' ? d.rendement.metric.toFixed(1) + ' %' : d.rendement.metric.toFixed(3);
    const v = d.valorisation;
    const edge = v == null ? '—' : v.basis === 'ivrank' ? `IV Rank ${v.ivRank.toFixed(0)}` : (v.edgePts >= 0 ? '+' : '') + v.edgePts.toFixed(1) + ' pts';
    const verdictClass = d.verdict === 'excellent' || d.verdict === 'bon' ? 'ds-badge--success' : d.verdict === 'passable' ? 'ds-badge--warning' : 'ds-badge--danger';
    return `<tr>
      <td>${oa(d.type)}</td>
      <td class="is-num">${optNum(c.strike)}</td>
      <td class="is-num">${optNum(c.bid)}</td>
      <td class="is-num">${optNum(c.ask)}</td>
      <td class="is-num">${optInt(c.openInterest)}</td>
      <td class="is-num">${optInt(c.volume)}</td>
      <td class="is-num" title="spread bid-ask en % du prix médian">${d.liquidity.spreadPct == null ? '—' : d.liquidity.spreadPct.toFixed(1) + ' %'}</td>
      <td class="is-num" title="IV Rank réel (historique du Radar) si disponible, sinon IV du contrat moins volatilité historique du titre">${edge}</td>
      <td class="is-num">${metric}</td>
      <td>${optaEmTag(d.type, c).trim() || '—'}</td>
      <td><span class="ds-badge ${verdictClass}">${oa(d.verdict)}</span></td>
      ${optaRollCell(d.type, c)}
    </tr>`;
  }).join('');
  host.innerHTML += `<div style="overflow-x:auto"><table class="ds-table">
    <thead><tr><th>Type</th><th class="is-num">Strike</th><th class="is-num">Bid</th><th class="is-num">Ask</th><th class="is-num">OI</th><th class="is-num">Vol.</th><th class="is-num">Spread</th><th class="is-num" title="IV − volatilité historique">Écart IV <button type="button" class="info-btn" onclick="showGlossaire('ivEcart', this)" title="Aide">i</button></th><th class="is-num">${metricLabel}</th><th title="Position du strike par rapport à la plage de l'expected move">Vs EM</th><th>Verdict</th><th title="envoyer ce contrat au calculateur de roulement">Roul.</th></tr></thead>
    <tbody>${rows}</tbody>
  </table></div>`;
}

function resetOptaFilters() {
  ['opta-range', 'opta-min-oi', 'opta-min-vol'].forEach((id) => { document.getElementById(id).value = ''; });
  document.getElementById('opta-quoted').checked = false;
  renderOptaChain();
}

function downloadOptaCSV() {
  const status = document.getElementById('opta-status');
  if (!optaChain) { status.textContent = 'Charge d\'abord une chaîne.'; return; }
  const csv = optionsToCSV(optaChain, optaFilters());
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `options-a-${optaChain.ticker}-${optaChain.expiry}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

// #11 — grille de rendement annualisé sur plusieurs échéances.
async function loadOptaGrid() {
  const status = document.getElementById('opta-grid-status');
  const host = document.getElementById('opta-grid-host');
  if (!optaChain) { status.textContent = 'Charge d\'abord une chaîne ci-dessus.'; return; }
  const dMin = parseFloat(document.getElementById('opta-grid-delta-min').value) || 0.15;
  const dMax = parseFloat(document.getElementById('opta-grid-delta-max').value) || 0.25;
  status.textContent = 'Génération…';
  try {
    const qs = new URLSearchParams({ type: 'put', deltaMin: dMin, deltaMax: dMax, maxExpiries: 6 });
    const { rows } = await fetchJSON(`/api/options/${encodeURIComponent(optaChain.ticker)}/grid?${qs}`);
    status.textContent = '';
    host.innerHTML = rows.length
      ? `<table class="ds-table"><thead><tr><th>Échéance</th><th class="is-num">DTE</th><th class="is-num">Strike</th><th class="is-num">Prime (bid)</th><th class="is-num">Rend. annualisé</th></tr></thead><tbody>${
          rows.map((r) => `<tr><td>${oa(r.expiry)}</td><td class="is-num">${r.dte}</td><td class="is-num">${optNum(r.strike)}</td><td class="is-num">${optNum(r.premium)}</td><td class="is-num">${r.annualizedYield == null ? '—' : r.annualizedYield.toFixed(1) + ' %'}</td></tr>`).join('')
        }</tbody></table>`
      : `<p class="ds-text-muted">Aucun put dans la plage de delta ${dMin}–${dMax} sur les échéances testées.</p>`;
  } catch (err) {
    status.textContent = 'Échec : ' + err.message;
  }
}


// ---- Roulement — jambes alimentées depuis la chaîne (F3) et les deals (F6).
// « Racheter » prend l'ASK (on paie pour fermer), « Vendre » prend le BID
// (on encaisse). Un prix absent ne remplit rien : jamais un 0 inventé.
const optaRollLegs = { close: null, open: null };

function optaRollCell(type, c) {
  if (!c) return '<td></td>';
  const attrs = `data-type="${type}" data-strike="${c.strike}"`;
  return `<td class="opta-roll-cell" style="white-space:nowrap;">`
    + `<button type="button" class="ds-btn ds-btn--sm opta-roll-btn" data-roll="close" ${attrs} title="Jambe à racheter (prix : ask)">↩ Racheter</button> `
    + `<button type="button" class="ds-btn ds-btn--sm opta-roll-btn" data-roll="open" ${attrs} title="Jambe à vendre (prix : bid)">➜ Vendre</button></td>`;
}

function optaRollLegsLabel() {
  const el = document.getElementById('opta-roll-legs');
  if (!el) return;
  const part = (leg, verbe) => leg
    ? `${verbe} <strong>${oa(leg.label)}</strong> à ${leg.price.toFixed(2)}`
    : `${verbe} <em>saisie manuelle</em>`;
  el.innerHTML = `${part(optaRollLegs.close, '↩ Racheter')} · ${part(optaRollLegs.open, '➜ Vendre')}`;
}

function setOptaRollLeg(kind, type, strike) {
  const ch = optaChain;
  const status = document.getElementById('opta-roll-legs');
  if (!ch) return;
  const c = (type === 'put' ? ch.puts : ch.calls).find((x) => x.strike === strike);
  const price = c ? (kind === 'close' ? c.ask : c.bid) : null;
  if (!(price > 0)) {
    if (status) status.innerHTML = `<span style="color:var(--amber)">Pas de ${kind === 'close' ? 'ask' : 'bid'} exploitable pour ce contrat — rien n'a été rempli.</span>`;
    return;
  }
  const inputId = kind === 'close' ? 'opta-roll-close-premium' : 'opta-roll-open-premium';
  document.getElementById(inputId).value = price.toFixed(2);
  optaRollLegs[kind] = { label: `${ch.ticker} ${type === 'put' ? 'Put' : 'Call'} ${optNum(strike)} · éch. ${ch.expiry}`, price };
  optaRollLegsLabel();
  computeOptaRoll();
  document.getElementById('opta-roll-result').closest('.ds-card').scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// Mêmes contrats, mêmes formules que le reste de l'onglet.
// #12 — calculateur de roulement (saisie manuelle des deux jambes).
function computeOptaRoll() {
  const openPremium = parseFloat(document.getElementById('opta-roll-open-premium').value);
  const closePremium = parseFloat(document.getElementById('opta-roll-close-premium').value);
  const contracts = parseInt(document.getElementById('opta-roll-contracts').value, 10) || 1;
  const net = optRollNetCredit(
    Number.isFinite(openPremium) ? openPremium : null,
    Number.isFinite(closePremium) ? closePremium : null,
    optaContractSize(),
    contracts,
  );
  const el = document.getElementById('opta-roll-result');
  if (net == null) { el.textContent = 'Saisis les deux primes pour calculer.'; return; }
  el.innerHTML = net >= 0
    ? `<strong style="color:var(--green)">Crédit net : +${net.toFixed(2)} $</strong> (tu encaisses plus que tu ne rachètes, pour ${contracts} contrat${contracts > 1 ? 's' : ''}).`
    : `<strong style="color:var(--red)">Débit net : ${net.toFixed(2)} $</strong> (le rachat coûte plus que la nouvelle prime encaissée, pour ${contracts} contrat${contracts > 1 ? 's' : ''}).`;
}

function initOptionsTabA() {
  const tick = document.getElementById('opta-ticker');
  if (!tick) return;
  // Recherche par nom, comme C2 (« Récupérer en direct » de la Fiche) : champ vide → fenêtre de
  // recherche ; texte → symbole exact chargé tout de suite, sinon choix proposés (js/symbol-search.js).
  const loadBtn = document.getElementById('opta-load');
  const searchThenLoad = () => {
    if (typeof searchThenFetch === 'function') searchThenFetch('opta-ticker', loadBtn, () => loadOptaChain());
    else loadOptaChain();
  };
  loadBtn.addEventListener('click', searchThenLoad);
  document.getElementById('opta-reset').addEventListener('click', resetOptaFilters);
  document.getElementById('opta-csv').addEventListener('click', downloadOptaCSV);
  tick.addEventListener('keydown', (e) => { if (e.key === 'Enter') searchThenLoad(); });
  document.getElementById('opta-expiry').addEventListener('change', (e) => loadOptaChain(e.target.value));
  ['opta-range', 'opta-min-oi', 'opta-min-vol', 'opta-quoted'].forEach((id) =>
    document.getElementById(id).addEventListener('input', renderOptaChain));
  optaLoadRule();
  optaLoadEmMult();
  document.getElementById('opta-em-mult').addEventListener('input', () => { optaSaveEmMult(); renderOptaChain(); renderOptaBestDeals(); if (typeof janlRenderScreener === 'function') janlRenderScreener(); });
  ['opta-rule-pct', 'opta-rule-days', 'opta-rule-hide'].forEach((id) =>
    document.getElementById(id).addEventListener('input', () => optaSyncRuleInputs('opta')));
  document.getElementById('opta-side').addEventListener('click', (e) => {
    const b = e.target.closest('button[data-side]');
    if (!b) return;
    optaSide = b.dataset.side;
    try { localStorage.setItem('castellana-opta-side', optaSide); } catch (_) { /* sans effet */ }
    renderOptaChain();
  });
  document.getElementById('opta-grid-load').addEventListener('click', loadOptaGrid);
  document.getElementById('opta-roll-compute').addEventListener('click', computeOptaRoll);
  // Saisie manuelle : la jambe n'est plus celle d'un contrat de la chaîne, et le calcul suit.
  [['opta-roll-close-premium', 'close'], ['opta-roll-open-premium', 'open'], ['opta-roll-contracts', null]].forEach(([id, kind]) =>
    document.getElementById(id).addEventListener('input', () => { if (kind) { optaRollLegs[kind] = null; optaRollLegsLabel(); } computeOptaRoll(); }));
  document.getElementById('tab-options-a').addEventListener('click', (e) => {
    const b = e.target.closest('.opta-roll-btn');
    if (b) setOptaRollLeg(b.dataset.roll, b.dataset.type, parseFloat(b.dataset.strike));
  });
  optaRollLegsLabel();
  document.getElementById('opta-deals-mode').addEventListener('change', renderOptaBestDeals);
  document.getElementById('opta-deals-type').addEventListener('change', renderOptaBestDeals);
}
