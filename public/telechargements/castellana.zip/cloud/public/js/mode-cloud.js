// js/mode-cloud.js — code propre à la version CLOUD
// Extrait de l'ancien script en ligne des index.html (découpage phase 2, 20/10/2026) : code déplacé tel quel, sans réécriture.
// (Connexion, lien magique, mot de passe, compte, et les variantes cloud de fonctions qui existent aussi en local.)
// Script classique : ses noms de premier niveau sont globaux et partagés avec les autres scripts de la page.

function calcFiche() {
  // Un prix d'entrée rempli automatiquement appartient à SON symbole : si le
  // symbole a changé (frappe, ou autre chemin que la récupération), on l'efface.
  if (entryAutoFilled && entryAutoFilled.ticker !== document.getElementById('ticker').value.trim().toUpperCase()) clearAutoFilledEntry();
  const capital   = +document.getElementById('capital').value;
  const riskPct   = +document.getElementById('riskpct').value;
  const heatExist = +document.getElementById('heatexist').value;
  const correlated = document.getElementById('correlated').value === 'oui';
  const entryRaw  = document.getElementById('entry').value;
  const entry     = +entryRaw;
  // Sans prix d'entrée, le stop et les cibles seraient « 0 ± distance » : des
  // chiffres faux et crédibles. On les remplace par « — ».
  const hasEntry  = entryRaw !== '' && Number.isFinite(entry) && entry > 0;
  const atr       = +document.getElementById('atr').value;
  const atrMult   = +document.getElementById('atrmult').value;
  const liq       = document.getElementById('liq').value;
  const ticker    = document.getElementById('ticker').value.toUpperCase() || 'CE TITRE';
  // VIX vient de la pastille globale du header (currentVix), plus d'un
  // champ de saisie ici depuis le 28/9/2026 — computeSizing() traite déjà
  // un VIX manquant (NaN/null) comme "aucun discount", sans rien inventer.
  const vix       = currentVix;
  const rsi       = +document.getElementById('rsi').value;
  const obv       = document.getElementById('obv').value;
  const swingLow  = +document.getElementById('swinglow').value;
  const swingHigh = +document.getElementById('swinghigh').value;
  // `discounts` et les bandes VIX vivent désormais dans computeSizing
  // (js/sizing.js). Ne restent ici que ce que calcFiche utilise encore pour
  // ses propres messages.
  const heatCfg = CFG.sizing.chargePortefeuille;
  const bRsi = CFG.bandes.rsi;

  document.getElementById('riskpct-out').textContent = riskPct.toFixed(2) + ' %';
  document.getElementById('heatexist-out').textContent = heatExist.toFixed(2) + ' %';
  document.getElementById('atrmult-out').textContent = atrMult.toFixed(2) + 'x';


  const rsiInfo = rsiInterp(rsi);
  document.getElementById('rsi-badge').innerHTML = '<span class="ds-badge ' + rsiInfo.cls + '">' + rsiInfo.label + '</span>';
  document.getElementById('rsi-note').textContent = rsiInfo.note;

  const obvInfo = obvInterp(obv);
  document.getElementById('obv-note').innerHTML = obvInfo.warn ? '<span class="bad">' + obvInfo.note + '</span>' : obvInfo.note;

  // Le calcul lui-même vit dans js/sizing.js depuis le 11/9/2026 — il était
  // enfermé ici, au milieu des écritures DOM, donc inutilisable ailleurs et
  // intestable. Le tableau de screening appelle exactement la même fonction
  // pour chiffrer la charge de chaque candidat : une seule maison pour ces
  // formules, jamais une copie.
  const sz = computeSizing({ capital, riskPct, heatExist, entry, atr, atrMult, correlated, vix, rsi, obv });
  const { stopDist, stopPrice, shares, totalHeat, riskEngage } = sz;

  document.getElementById('m-dist').textContent = fmt(stopDist);
  document.getElementById('m-stop').textContent = hasEntry ? fmt(stopPrice) : '—';
  document.getElementById('m-size').textContent = shares + ' act.';
  document.getElementById('m-size-sub').textContent = (sz.reasons.length ? 'réduite (' + sz.reasons.join(', ') + ')' : 'taille de base')
    + (sz.pctCapital != null ? ' · ' + Math.round(sz.pctCapital) + ' % du capital' : '');

  const heatEl = document.getElementById('m-heat');
  heatEl.textContent = totalHeat.toFixed(1) + ' %';
  heatEl.className = 'ds-metric__value ' + (sz.depasseAlerte ? 'bad' : sz.depasseAvertissement ? 'warn' : 'ok');

  const rec = document.getElementById('order-rec');
  let recHtml = '';
  const stopTxt = hasEntry ? fmt(stopPrice) : "(renseigne d'abord le prix d'entrée)";
  if (liq === 'liquide') {
    recHtml = '<strong>Entrée :</strong> ordre stop d\'achat juste au-dessus du haut de la bougie de confirmation, ou marché si l\'écart est minime.<br><strong>Sortie :</strong> stop-market au prix ' + stopTxt + '.';
  } else if (liq === 'moyen') {
    recHtml = '<strong>Entrée :</strong> ordre stop d\'achat au-dessus du haut de la bougie de confirmation.<br><strong>Sortie :</strong> stop-limit au prix ' + stopTxt + ', limite ' + fmt(stopDist*0.15) + ' plus bas.';
  } else {
    recHtml = '<strong>Entrée :</strong> ordre limite au niveau du retest — pas de stop d\'achat, le glissement peut être important.<br><strong>Sortie :</strong> stop-limit obligatoire, marge élargie de ' + fmt(stopDist*0.3) + '.';
  }
  const capNote = sizingCapNote(sz);
  if (capNote) recHtml += '<br><br><span style="color:var(--amber); font-weight:600;">⚠ ' + capNote + '</span>';
  if (totalHeat > heatCfg.alerte) recHtml += '<br><br><span style="color:var(--red); font-weight:600;">⚠ Charge totale du portefeuille au-delà de ' + heatCfg.alerte + '% — réduire cette position ou fermer une autre avant d\'ajouter du risque.</span>';
  if (obv === 'distribution' && rsi > bRsi.entreeHaut) recHtml += '<br><br><span style="color:var(--red); font-weight:600;">⚠ Surachat + divergence OBV en même temps — signal de prudence élevé, envisage sérieusement d\'attendre.</span>';
  rec.innerHTML = recHtml;

  const rEl = document.getElementById('rtable');
  const targets = [1, 2, 3];
  rEl.innerHTML = targets.map(r => `<tr><td>Cible ${r}R</td><td>${hasEntry ? fmt(entry + stopDist * r) : '—'}</td></tr>`).join('')
    + `<tr><td>Risque $ (si stop touché)</td><td>${fmt(riskEngage)}</td></tr>`;

  const fibEl = document.getElementById('fibtable');
  const range = swingHigh - swingLow;
  const fibLevels = [
    { label: 'Ext. 127.2%', price: swingHigh + range * 0.272 },
    { label: 'Ext. 161.8%', price: swingHigh + range * 0.618 },
    { label: 'Ext. 261.8%', price: swingHigh + range * 1.618 }
  ];
  fibEl.innerHTML = fibLevels.map(f => {
    const rEquiv = hasEntry && stopDist > 0 ? ((f.price - entry) / stopDist).toFixed(1) : '—';
    return `<tr><td>${f.label}</td><td>${fmt(f.price)} (${rEquiv}R)</td></tr>`;
  }).join('');

  // Les verdicts se recalculent ici et pas seulement après un fetch : les
  // lignes VIX et RSI/OBV lisent les champs du formulaire, que JP peut
  // saisir à la main. Sans ça, taper un VIX laisserait un verdict périmé.
  renderChecklistVerdicts();
  const allChecked = ['c1','c2','c3','c4','c5','c6'].every(id => document.getElementById(id).checked);
  const banner = document.getElementById('banner');
  if (allChecked) {
    banner.className = 'banner ready';
    banner.textContent = '✓ Checklist complète — ' + ticker + ' prêt pour l\'entrée calculée ci-dessus';
  } else {
    banner.className = 'banner notready';
    banner.textContent = '⚠ Checklist incomplète — ne pas entrer sur ' + ticker + ' encore';
  }
}
// ---- Données en direct (backend Express → Yahoo Finance ; le sidecar
// tradingview-mcp n'est qu'un repli optionnel depuis le 7/9/2026) ----
// Session fermée ou expirée (401 hors /api/auth/) : retour à l'écran de connexion par un rechargement, au plus un par
// 10 s (jamais de boucle). Avant, l'onglet restait affiché avec « Non authentifié » partout (audit app-js, constat 5).
function sessionPerdue() {
  try {
    const dernier = +sessionStorage.getItem('castellana-session-perdue') || 0;
    if (Date.now() - dernier < 10000) return;
    sessionStorage.setItem('castellana-session-perdue', String(Date.now()));
  } catch { /* stockage indisponible : on recharge quand même une fois */ }
  location.reload();
}
async function fetchJSON(url, options) {
  try {
    // Mode démo (js/demo-mode.js) : l'en-tête demande au Worker de privilégier son cache.
    if (typeof demoHeaders === 'function' && demoModeOn()) {
      options = { ...(options || {}), headers: { ...((options && options.headers) || {}), ...demoHeaders() } };
    }
    const res = await fetch(url, options);
    if (typeof tvNoteSource === 'function') tvNoteSource(res.headers.get('x-data-source'));
    // On lit le corps en TEXTE avant de le parser (feature 351, 7/9/2026).
    // `res.json()` direct laissait remonter le message brut de JSON.parse —
    // « Unexpected token '<', "<!DOCTYPE "... is not valid JSON » — quand le
    // serveur répondait une page HTML : illisible, et sans rapport apparent
    // avec la vraie cause. On nomme désormais la cause.
    const raw = await res.text();
    const type = res.headers.get('content-type') || '';
    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      if (type.includes('text/html') || raw.trimStart().startsWith('<')) {
        throw new Error(
          `Le serveur a renvoyé une page HTML au lieu de données (HTTP ${res.status}). `
          + 'Cause la plus probable : la page ouverte est plus récente que le serveur qui tourne. '
          + 'Recharge la page (Cmd/Ctrl+Maj+R) ; si ça persiste, relance castellana.'
        );
      }
      throw new Error(`Réponse illisible du serveur (HTTP ${res.status}) : ${raw.slice(0, 120)}`);
    }
    if (res.status === 401 && !String(url).startsWith('/api/auth/')) sessionPerdue();
    if (!res.ok) {
      // `code` et `status` accompagnent le message : les écrans peuvent réagir à la CAUSE (ex. NO_SWEEP)
      // plutôt que d'analyser un texte.
      const e = new Error(data.error || data.detail || res.statusText);
      e.code = data.code; e.status = res.status; e.detail = data.detail;
      throw e;
    }
    return data;
  } catch (err) {
    // Point de passage unique de tous les appels API de l'app : c'est donc
    // le bon endroit — et le seul — pour remonter une panne à la télémétrie
    // (7/9/2026). Sans ça, JP n'apprenait l'existence d'un problème chez un
    // testeur que si celui-ci pensait à lui écrire.
    // `typeof` plutôt qu'un appel direct : telemetry.js peut ne pas être
    // chargé (ordre des <script>), et la remontée d'erreur ne doit jamais
    // devenir elle-même une source d'erreur. On n'instrumente pas l'endpoint
    // de télémétrie lui-même, sous peine de boucle.
    try {
      if (typeof trackError === 'function' && !String(url).includes('/events') && !(err && err.status === 401)) {
        trackError(String(url).split('?')[0], err.message);
      }
    } catch { /* jamais bloquant */ }
    throw err;
  }
}
// Libellés par univers (T5, 12/9/2026) — un seul endroit à étendre le jour
// où une vraie gestion de plusieurs listes personnalisées est construite
// (voir CLAUDE.md, feature future), plutôt qu'un enchaînement de ternaires.
const UNIVERS_LABELS = {
  watchlist: 'Ma watchlist : tous les titres suivis sont affichés, en setup ou non. Lance le screening.',
  elargi: "Univers élargi : 210 titres balayés, seuls ceux en setup d'entrée sont retenus. Lance le screening.",
  mag7: 'MAG7 : Apple, Microsoft, Alphabet, Amazon, Nvidia, Meta, Tesla — tous affichés, en setup ou non. Lance le screening.',
  sp500: "S&P 500 : dernier balayage calculé sur le poste local et publié ici, en lecture seule (aucun calcul en ligne). Seuls les titres retenus par le filtre figurent. Lance le screening pour l'afficher.",
};
const UNIVERS_EN_COURS = {
  watchlist: 'Screening en cours… (~2 s)',
  elargi: 'Screening de 210 titres en cours… (~5 s)',
  mag7: 'Screening de 7 titres en cours… (~1 s)',
  sp500: 'Lecture du dernier balayage S&P 500 publié…',
};
const snapEsc = (t) => String(t ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
// Instantané du balayage S&P 500 publié par l'app locale (17/10/2026).
function snapshotLabel(snap) {
  const at = new Date(snap.computedAt).toLocaleString('fr-CA', { dateStyle: 'long', timeStyle: 'short' });
  return `Balayage calculé le ${at} sur le poste local${snap.source ? ` (source ${snap.source})` : ''}, publié ici en lecture seule.`;
}
// Flag sp500_sweep (17/10/2026, OFF par défaut, par compte depuis bilbao) : carte A3 et bouton S&P 500
// de B2 cachés tant qu'il n'est pas confirmé ON. Le serveur refuse de toute façon (403 FLAG_OFF).
async function loadSectorSetups() {
  try {
    const { flags } = await fetchJSON('/api/flags');
    if (!flags || flags.sp500_sweep !== true) return;
  } catch { return; }
  const card = document.getElementById('sector-setups-card');
  if (card) card.style.display = '';
  const btn = document.getElementById('univers-sp500-btn');
  if (btn) btn.style.display = '';
  const host = document.getElementById('sector-setups-host');
  if (!host) return;
  try {
    const d = await fetchJSON('/api/snapshots/sp500_sweep/latest');
    const max = Math.max(1, ...d.sectors.map((s) => s.total));
    const chips = (l) => l.map((t) => `<span class="ds-badge">${snapEsc(t)}</span>`).join(' ');
    const news = d.news && !d.news.baseline ? ` Nouveaux « prêt » depuis le balayage précédent : ${d.news.nouveautes.length ? d.news.nouveautes.map(snapEsc).join(', ') : 'aucun'}.` : '';
    host.innerHTML = `<div class="banner ${d.stale ? 'watch' : 'ready'}" style="margin-bottom:8px;">${snapEsc(snapshotLabel(d))}${d.stale ? ' Il a plus d\'un jour ouvrable.' : ''}</div>` +
      `<p class="metric-sub" style="text-align:left;">${d.retainedSize} retenu(s) sur ${d.universeSize}.${news}</p>` +
      d.sectors.map((s) => {
        const pc = s.pret.length, sc = s.surveiller.length, tot = s.total || 1;
        return `<div style="display:grid; grid-template-columns:190px 1fr 140px; gap:10px; align-items:center; padding:4px 0;" title="${pc} prêt · ${sc} à surveiller · ${s.total} titres dans le secteur">
        <div><strong>${snapEsc(s.label)}</strong></div>
        <div style="position:relative; height:16px; background:var(--surface-2); border-radius:4px; overflow:hidden; width:${(s.total / max * 100).toFixed(0)}%; min-width:30px;">
          <div style="position:absolute; inset:0 auto 0 0; width:${(pc / tot * 100).toFixed(1)}%; background:var(--green);"></div>
          <div style="position:absolute; inset:0 auto 0 ${(pc / tot * 100).toFixed(1)}%; width:${(sc / tot * 100).toFixed(1)}%; background:var(--amber); opacity:.8;"></div>
        </div>
        <div class="metric-sub" style="text-align:right;"><span style="color:var(--green);font-weight:700;">${pc}</span> prêt · <span style="color:var(--amber);font-weight:700;">${sc}</span> à surv. / ${s.total}</div>
      </div>${pc ? `<div style="padding:0 0 6px 200px;">${chips(s.pret)}</div>` : ''}`;
      }).join('') +
      '<div class="opt-legend"><span class="opt-legend-item"><i class="opt-legend-sw" style="background:var(--green)"></i>Prêt</span><span class="opt-legend-item"><i class="opt-legend-sw" style="background:var(--amber)"></i>À surveiller</span><span class="opt-legend-item"><i class="opt-legend-sw" style="background:var(--surface-2)"></i>Reste du secteur (largeur = taille du secteur)</span></div>';
  } catch (err) {
    host.innerHTML = err.code === 'NO_SNAPSHOT' || err.status === 404 ? '<p>Aucun balayage du S&amp;P 500 n\'a encore été publié depuis le poste local.</p>' : `<p>Indisponible : ${snapEsc(err.message)}</p>`;
  }
}
function screeningExplainError(err) {
  const msg = err && err.message ? err.message : String(err);
  if (err && err.code === 'NO_SWEEP') {
    const hasSettings = typeof openSettings === 'function' && document.getElementById('tv-sweep-card');
    // Version en ligne : le balayage est calculé sur le poste local puis publié ; rien à lancer ici.
    return { text: "Aucun balayage du S&P 500 n'a encore été publié depuis le poste local. Il est calculé une fois par jour sur l'app locale, puis envoyé ici." };
  }
  if (err instanceof TypeError || /Failed to fetch|NetworkError|Load failed/i.test(msg)) {
    return { text: 'Le serveur castellana ne répond pas. Est-il toujours lancé ? (npm start, ou recharge la page.)' };
  }
  if (err && err.status === 503) return { text: `Données de marché indisponibles : ${msg}${err.detail && !msg.includes(err.detail) ? ' — ' + err.detail : ''}. Réessaie dans un instant.` };
  if (err && err.status === 429) return { text: 'Trop de requêtes pour le moment : attends une minute puis réessaie.' };
  if (err && err.status >= 500) return { text: `Erreur du serveur pendant le screening : ${msg}` };
  return { text: msg };
}
async function runScreening(force) {
  const btn = document.getElementById('scr-btn-screen');
  const btnForce = document.getElementById('scr-btn-screen-force');
  const status = document.getElementById('scr-screen-status');
  const tbody = document.getElementById('screen-tbody');
  btn.disabled = true;
  btnForce.disabled = true;
  // Durées mesurées le 11/9/2026 : ~2 s sur la watchlist, ~5 s sur les 219
  // titres de l'univers élargi. L'ancien message annonçait « 45-60 s »,
  // hérité du temps où chaque titre passait par le sidecar Python.
  status.textContent = UNIVERS_EN_COURS[universCourant] ?? UNIVERS_EN_COURS.watchlist;
  screeningBanner(null);
  tbody.innerHTML = '';
  try {
    const params = new URLSearchParams({ universe: universCourant });
    if (force) params.set('force', 'true');
    const data = await fetchJSON('/api/screening?' + params);
    lastScreeningRows = data.rows;
    if (data.signalAge) signalAgeSeuils = data.signalAge;
    renderScreeningRows();
    // Fire-and-forget (21/9/2026) : le graphique a sa propre gestion
    // d'erreur (voir loadScreeningPerformance) — un second appel réseau ne
    // doit ni bloquer ni retarder l'affichage du tableau ci-dessus.
    loadScreeningPerformance(data.rows);

    // Bug "univers élargi" (12/9/2026) : nommer la vraie cause quand le
    // plafond de sous-requêtes Cloudflare Workers a empêché d'analyser une
    // partie de l'univers, plutôt que de laisser un résultat maigre passer
    // pour "aucun setup aujourd'hui". `subrequestLimitCount` est absent en
    // local (jamais concerné) — `> 0` reste faux sur `undefined`.
    const subWarning = document.getElementById('scr-subrequest-warning');
    if (data.subrequestLimitCount > 0) {
      subWarning.textContent = `⚠ ${data.subrequestLimitCount} titre(s) sur ${data.universeSize} n'ont pas pu être analysés — limite de sous-requêtes Cloudflare Workers atteinte, pas un manque de setup. Réessaie dans quelques minutes (le cache se réchauffe progressivement), ou relance plus tard.`;
      subWarning.style.display = 'block';
    } else {
      subWarning.style.display = 'none';
    }

    // Balayage S&P 500 ancien : le résultat reste consultable, mais ses prix ont l'âge du balayage.
    // Version en ligne : la date de l'instantané est toujours dite ; ambre s'il a plus d'un jour ouvrable.
    if (data.universe === 'sp500' && data.snapshot) {
      screeningBanner(snapshotLabel(data.snapshot) + (data.snapshot.stale ? ' Il a plus d\'un jour ouvrable : les prix et signaux ont cet âge.' : ''), data.snapshot.stale ? 'watch' : 'ready');
    }
    const errCount = data.rows.filter((r) => r.verdict === 'erreur').length;
    const prets = data.rows.filter((r) => r.verdict === 'prêt').length;
    const heure = new Date(data.generatedAt).toLocaleTimeString('fr-CA');
    // Dire d'où sortent les lignes : « 18 candidats » n'a pas le même sens
    // selon qu'ils viennent de 22 titres ou de 219.
    const provenance = data.universeSize != null && data.retainedSize != null && data.universeSize !== data.retainedSize
      ? ` — ${data.retainedSize} retenu(s) sur ${data.universeSize} balayé(s)`
      : ` — ${data.rows.length} titre(s)`;
    status.textContent = `Screening du ${heure}`
      + (data.cached ? ' (cache)' : '')
      + provenance
      + (prets ? `, dont ${prets} « prêt »` : '')
      + (errCount ? ` — ${errCount} sans donnée.` : '.');
  } catch (err) {
    const why = screeningExplainError(err);
    status.textContent = 'Échec du screening.';
    screeningBanner(why.text, 'notready', why.action && why.action[0], why.action && why.action[1]);
    resetScreenChart(); // pas de graphique orphelin sur un screening en échec
  } finally {
    btn.disabled = false;
    btnForce.disabled = false;
  }
}
// ---- Témoin de statut backend (header) ----
async function checkStatus() {
  const dotBackend = document.getElementById('dot-backend');
  const dotMcp = document.getElementById('dot-mcp');
  const dotYahoo = document.getElementById('dot-yahoo');
  const lastCheck = document.getElementById('status-lastcheck');
  const issues = document.getElementById('status-issues');
  [dotBackend, dotMcp, dotYahoo].forEach((d) => { d.className = 'status-dot is-checking'; });
  try {
    const data = await fetchJSON('/api/status');
    dotBackend.className = 'status-dot ' + (data.backend ? 'is-ok' : 'is-down');
    // Trois états pour le sidecar, pas deux : connecté / en panne /
    // DÉSACTIVÉ. Sans le troisième, un testeur qui n'a jamais installé
    // Python — le cas par défaut depuis le 7/9/2026 — voyait une pastille
    // rouge permanente pour un composant dont l'app n'a plus besoin.
    if (data.tradingviewMcpDisabled) {
      dotMcp.className = 'status-dot is-off';
      dotMcp.title = data.tradingviewMcpDetail || 'Sidecar désactivé (optionnel)';
    } else {
      dotMcp.className = 'status-dot ' + (data.tradingviewMcp ? 'is-ok' : 'is-down');
      dotMcp.title = data.tradingviewMcp ? 'tradingview-mcp connecté' : (data.tradingviewMcpDetail || 'tradingview-mcp injoignable');
    }
    const techSidecar = document.getElementById('tech-sidecar');
    if (techSidecar) techSidecar.textContent = data.tradingviewMcpDisabled ? 'désactivé' : (data.tradingviewMcp ? 'actif' : 'erreur');
    dotYahoo.className = 'status-dot ' + (data.homemade ? 'is-ok' : 'is-down');
    dotYahoo.title = data.homemade ? 'Données de marché OK (Yahoo Finance)' : (data.homemadeDetail || 'Yahoo Finance injoignable');
    lastCheck.textContent = 'Vérifié à ' + new Date(data.checkedAt).toLocaleTimeString('fr-CA');

    // Détail explicite des pannes — un point rouge seul ne dit pas pourquoi.
    const problems = [];
    if (!data.db) problems.push(`Base de données : ${data.dbDetail || 'erreur inconnue'}`);
    // Un sidecar désactivé n'est pas un problème à signaler.
    if (!data.tradingviewMcp && !data.tradingviewMcpDisabled) problems.push(`tradingview-mcp : ${data.tradingviewMcpDetail || 'erreur inconnue'}`);
    if (!data.homemade) problems.push(`Données de marché (Yahoo Finance) : ${data.homemadeDetail || 'erreur inconnue'}`);
    if (problems.length) {
      issues.innerHTML = '<strong>⚠ Problème(s) technique(s) détecté(s) :</strong><br>' + problems.map((p) => '— ' + optEsc(p)).join('<br>');
      issues.style.display = 'block';
    } else {
      issues.style.display = 'none';
    }
  } catch (err) {
    [dotBackend, dotMcp, dotYahoo].forEach((d) => { d.className = 'status-dot is-down'; });
    // Deux pannes DIFFÉRENTES qu'il ne faut pas confondre (feature 351) :
    // le serveur ne répond pas du tout (réseau), ou il répond autre chose
    // que ce qu'on attend (page HTML, route inconnue). L'ancien message
    // annonçait « injoignable » dans les deux cas, ce qui envoyait chercher
    // un serveur éteint alors qu'il tournait parfaitement.
    const injoignable = err instanceof TypeError || /Failed to fetch|NetworkError|Load failed/i.test(err.message);
    if (injoignable) {
      lastCheck.textContent = 'Backend injoignable';
      issues.innerHTML = '<strong>⚠ Backend injoignable :</strong><br>'
        + `— ${optEsc(err.message)}<br>— Le serveur est-il lancé ? Double-clic sur <code>demarrer.command</code> (macOS) `
        + 'ou <code>demarrer.bat</code> (Windows), ou <code>npm start</code> dans le dossier castellana.';
    } else {
      lastCheck.textContent = 'Réponse inattendue du backend';
      issues.innerHTML = '<strong>⚠ Le backend répond, mais pas ce qui est attendu :</strong><br>'
        + `— ${optEsc(err.message)}`;
    }
    issues.style.display = 'block';
  }
}
// ---- Version installée et mise à jour ----
// Le zip téléchargé depuis iecho.ca devenait périmé EN SILENCE : un testeur
// Version cloud (portage 11/9/2026) : pas de mécanisme de mise à jour côté
// client — un déploiement Cloudflare (`wrangler deploy`) met à jour tout le
// monde d'un coup, contrairement au zip local que chaque testeur devait
// télécharger. Le bandeau #update-banner n'est donc jamais affiché ici.
// Voir CLAUDE.md, section « Portage Cloudflare », pour ce que ce bloc
// remplace côté version locale (server/update.js).
function renderAccountInfo(username) {
  const setTech = (id, value) => { const e = document.getElementById(id); if (e) e.textContent = value; };
  setTech('tech-username', username || '?');
  setTech('tech-url', location.host);
}
// ---- Démarrage de l'app, derrière la session (portage cloud, 11/9/2026) ----
// Rien de tout ce qui suit ne s'exécute tant qu'une session valide n'est
// pas confirmée (GET /api/auth/me) — voir boot() tout en bas de ce fichier.
function bootApp(username) {
  // La séquence de démarrage est commune (js/app-demarrage.js) ; ici, seulement ce qui est propre au cloud.
  demarrerApp({
    avant: () => {
      document.getElementById('login-overlay').style.display = 'none';
      document.getElementById('app-container').style.display = '';
      // Identité RÉELLE (session) plutôt que l'ancien sélecteur auto-déclaré —
      // js/telemetry.js la lit via window.CASTELLANA_USERNAME (voir getWho()).
      window.CASTELLANA_USERNAME = username;
      renderAccountInfo(username);
    },
    apresInitRoueVisibility: () => { initAnticipationVisibility(); }, // onglet Anticipation (flag anticipation_tab, par compte)
    apresInitFcfCardVisibility: () => { initTradingviewConnect(); }, // connexion TradingView (flag tradingview_connect, cloud seulement)
    apresInitDisclaimerCollapse: () => { initDemoMode(); }, // mode démo : état de l'interrupteur, bandeau (js/demo-mode.js)
  });
}
async function handleLogin(event) {
  event.preventDefault();
  const errorEl = document.getElementById('login-error');
  errorEl.style.display = 'none';
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value;
  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Connexion refusée');
    bootApp(data.username);
    refreshPasswordForm();
  } catch (err) {
    errorEl.textContent = err.message;
    errorEl.style.display = 'block';
  }
  return false;
}
async function logout() {
  try { await fetch('/api/auth/logout', { method: 'POST' }); } catch {}
  location.reload();
}
// Magic link (19/9/2026) — s'ajoute au mot de passe, ne le remplace pas.
// mode 'reset' (17/10/2026) : « Mot de passe oublié ? », même lien.
let magicLinkPurpose = 'login';
function toggleMagicLinkOverlay(show, mode = 'login') {
  magicLinkPurpose = mode === 'reset' ? 'reset' : 'login';
  document.getElementById('magic-link-title').textContent = magicLinkPurpose === 'reset' ? 'Mot de passe oublié' : 'Recevoir un lien de connexion';
  document.getElementById('magic-link-reset-intro').style.display = magicLinkPurpose === 'reset' ? 'block' : 'none';
  document.getElementById('magic-link-overlay').style.display = show ? 'flex' : 'none';
  document.getElementById('login-overlay').style.display = show ? 'none' : 'flex';
  const status = document.getElementById('magic-link-status');
  status.style.display = 'none';
  status.className = 'metric-sub';
}
async function handleMagicLinkRequest(event) {
  event.preventDefault();
  const email = document.getElementById('magic-link-email').value.trim();
  const status = document.getElementById('magic-link-status');
  try {
    await fetch('/api/auth/magic-link/request', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, purpose: magicLinkPurpose }),
    });
  } catch {
    // Fetch échoué (réseau) — même message générique ci-dessous : ne pas
    // distinguer "réseau en panne" de "email inconnu" ne coûte rien ici,
    // et évite un branchement en plus pour un cas rare.
  }
  // Message TOUJOURS identique, quel que soit le résultat réel côté
  // serveur (voir routes/auth.js) — ne jamais laisser deviner si ce
  // courriel correspond à un compte.
  status.textContent = 'Si ce courriel est associé à un compte actif, un lien de connexion vient de lui être envoyé — vérifie ta boîte de réception (et les indésirables).';
  status.style.display = 'block';
  return false;
}
// Changer mon mot de passe (17/10/2026) — POST /api/auth/password.
// L'état « ancien mot de passe exigé ? » vient du serveur (GET /api/auth/me),
// qui refait la vérification de toute façon : masquer le champ ne protège rien.
async function refreshPasswordForm() {
  let canSkip = false;
  try {
    const res = await fetch('/api/auth/me');
    if (res.ok) canSkip = Boolean((await res.json()).canChangeWithoutOld);
  } catch {}
  document.getElementById('pw-old-field').style.display = canSkip ? 'none' : '';
  document.getElementById('pw-old').required = !canSkip;
  document.getElementById('pw-reset-note').style.display = canSkip ? 'block' : 'none';
  return canSkip;
}
async function handlePasswordChange(event) {
  event.preventDefault();
  const status = document.getElementById('pw-status');
  const oldPassword = document.getElementById('pw-old').value;
  const newPassword = document.getElementById('pw-new').value;
  const confirm = document.getElementById('pw-new2').value;
  status.className = 'pref-status';
  if (newPassword !== confirm) {
    status.textContent = 'Les deux nouveaux mots de passe ne correspondent pas.';
    status.classList.add('is-bad');
    return false;
  }
  try {
    const res = await fetch('/api/auth/password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ oldPassword, newPassword }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Changement refusé');
    document.getElementById('pw-form').reset();
    const n = data.otherSessionsClosed;
    status.textContent = 'Mot de passe changé.' + (n > 0 ? ` ${n} autre(s) session(s) déconnectée(s).` : ' Aucune autre session ouverte.');
    status.classList.add('is-ok');
    refreshPasswordForm();
  } catch (err) {
    status.textContent = err.message;
    status.classList.add('is-bad');
    if (/actuel requis/.test(err.message)) refreshPasswordForm(); // fenêtre de 15 min écoulée
  }
  return false;
}
// Après un lien « Mot de passe oublié ? » (?reset=1) : ouvre Réglages →
// Technique et place la carte « Compte » sous les yeux.
async function openPasswordReset() {
  openSettings();
  switchSettingsTab('technique');
  await refreshPasswordForm();
  const form = document.getElementById('pw-form');
  form.scrollIntoView({ block: 'center' });
  document.getElementById('pw-new').focus();
}
