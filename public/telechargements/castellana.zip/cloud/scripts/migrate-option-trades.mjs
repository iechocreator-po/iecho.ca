#!/usr/bin/env node
// Migration idempotente (22/9/2026) — Journal A : cycles de la Roue et
// jambes d'options (option_cycles/option_trades, nouvelles tables) + la
// colonne trades.option_cycle_id (ALTER, pas rejouable tel quel — même
// discipline que migrate-users-email-magiclinks.mjs, PRAGMA table_info
// avant chaque ALTER).
//
// ⚠️ À lancer en --remote AVANT `wrangler deploy` — le code déployé
// suppose ces tables/cette colonne présentes. Vérifier ensuite avec
// sqlite_master / PRAGMA table_info, ne pas se fier au seul message de fin
// (leçon du 19/9/2026 : un premier déploiement avait précédé sa migration).
//
// Usage :
//   node scripts/migrate-option-trades.mjs             (D1 local)
//   node scripts/migrate-option-trades.mjs --remote    (vrai D1)

import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const remote = process.argv.includes('--remote');
const flag = remote ? '--remote' : '--local';

function run(sql, { json = false } = {}) {
  const args = ['wrangler', 'd1', 'execute', 'castellana-db', flag, '--command', sql];
  if (json) args.push('--json');
  const result = spawnSync('npx', args, { cwd: ROOT, stdio: json ? ['ignore', 'pipe', 'pipe'] : 'inherit' });
  if (result.status !== 0) {
    console.error(json ? result.stderr?.toString() : '');
    throw new Error(`Échec de la commande wrangler (SQL: ${sql})`);
  }
  if (!json) return null;
  return JSON.parse(result.stdout.toString());
}

function existingColumns(table) {
  const out = run(`PRAGMA table_info(${table})`, { json: true });
  return new Set(out[0].results.map((c) => c.name));
}

console.log(`\nMigration option_cycles / option_trades / trades.option_cycle_id (${remote ? 'D1 distant' : 'D1 local'})...`);

console.log('- création de option_cycles (si absente)');
run(`CREATE TABLE IF NOT EXISTS option_cycles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  ticker TEXT NOT NULL,
  compte TEXT NOT NULL CHECK (compte IN ('RRSP','margin','corporatif')),
  statut TEXT NOT NULL DEFAULT 'actif' CHECK (statut IN ('actif','clos')),
  notes TEXT,
  date_creation TEXT NOT NULL DEFAULT (datetime('now'))
)`);
run('CREATE INDEX IF NOT EXISTS idx_option_cycles_user ON option_cycles(user_id)');

console.log('- création de option_trades (si absente)');
run(`CREATE TABLE IF NOT EXISTS option_trades (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  cycle_id INTEGER REFERENCES option_cycles(id),
  type TEXT NOT NULL CHECK (type IN ('put','call')),
  ticker TEXT NOT NULL,
  compte TEXT NOT NULL CHECK (compte IN ('RRSP','margin','corporatif')),
  strike REAL NOT NULL,
  echeance TEXT NOT NULL,
  contrats INTEGER NOT NULL DEFAULT 1,
  prime_recue REAL NOT NULL,
  date_ouverture TEXT NOT NULL,
  delta_ouverture REAL,
  iv_ouverture REAL,
  statut TEXT NOT NULL DEFAULT 'ouvert' CHECK (statut IN ('ouvert','expire','assigne','roule','rachete')),
  date_cloture TEXT,
  prime_cloture REAL,
  notes TEXT,
  date_creation TEXT NOT NULL DEFAULT (datetime('now'))
)`);
run('CREATE INDEX IF NOT EXISTS idx_option_trades_user ON option_trades(user_id, statut)');
run('CREATE INDEX IF NOT EXISTS idx_option_trades_cycle ON option_trades(cycle_id)');

const tradesCols = existingColumns('trades');
if (!tradesCols.has('option_cycle_id')) {
  console.log('- ajout de la colonne trades.option_cycle_id');
  run('ALTER TABLE trades ADD COLUMN option_cycle_id INTEGER REFERENCES option_cycles(id)');
} else {
  console.log('- trades.option_cycle_id déjà présente, ignorée');
}

console.log(`\nMigration terminée (${flag}). Rejouable sans erreur.`);
