// Instantanés quotidiens (17/10/2026) — voir src/lib/snapshots.js pour la forme et la validation.
import { SNAPSHOT_KEEP_DAYS } from '../lib/snapshots.js';

// Une ligne par (kind, date) : un second envoi le même jour remplace le premier. Les lignes
// de plus de SNAPSHOT_KEEP_DAYS jours sont supprimées dans le même lot.
export async function saveSnapshot(db, kind, date, json) {
  await db.batch([
    db.prepare(`INSERT INTO daily_snapshots (kind, date, json, created_at) VALUES (?, ?, ?, datetime('now'))
                ON CONFLICT(kind, date) DO UPDATE SET json = excluded.json, created_at = excluded.created_at`).bind(kind, date, json),
    db.prepare(`DELETE FROM daily_snapshots WHERE kind = ? AND date < date('now', ?)`).bind(kind, `-${SNAPSHOT_KEEP_DAYS} days`),
  ]);
}

export async function latestSnapshot(db, kind) {
  const row = await db.prepare('SELECT date, json, created_at FROM daily_snapshots WHERE kind = ? ORDER BY date DESC LIMIT 1').bind(kind).first();
  if (!row) return null;
  return { date: row.date, receivedAt: row.created_at, value: JSON.parse(row.json) };
}

export async function listSnapshots(db, kind) {
  const r = await db.prepare('SELECT date, created_at, length(json) AS bytes FROM daily_snapshots WHERE kind = ? ORDER BY date DESC').bind(kind).all();
  return r.results || [];
}
