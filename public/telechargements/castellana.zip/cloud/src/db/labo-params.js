// Paramètres des stratégies d'options (onglet Labo), par utilisateur — portage
// D1 de server/labo-params.js (voir ce fichier pour le raisonnement complet :
// seules les SURCHARGES sont stockées, reset = suppression des lignes,
// `kind`/`definition_json` réservés aux futures stratégies personnalisées).
//
// Les défauts et la validation viennent de ./lib/labo-schema.js, copie ESM
// GÉNÉRÉE de js/labo-schema.js (npm run sync:cloud à la racine du produit).

import {
  LABO_SCHEMA, laboResolveStrategy, laboDefaults, laboMergeOverrides, laboEffectiveParams,
} from '../lib/labo-schema.js';

export { LABO_SCHEMA, laboDefaults };

function fail(errors) {
  const err = new Error(errors.join(' '));
  err.code = 'INVALID_LABO_PARAMS';
  err.errors = errors;
  return err;
}

function parseOverrides(id, json) {
  let parsed = {};
  try { parsed = JSON.parse(json) || {}; } catch { return {}; }
  const known = laboDefaults(id) || {};
  const clean = {};
  for (const [k, v] of Object.entries(parsed)) if (k in known) clean[k] = v;
  return clean;
}

// { roue: { putDteMin: 20 }, … } — uniquement les stratégies surchargées.
export async function getAllOverrides(db, userId) {
  const { results } = await db.prepare(
    'SELECT strategy_id, params_json FROM strategy_params WHERE user_id = ?',
  ).bind(userId).all();
  const out = {};
  for (const row of results) {
    if (!laboResolveStrategy(row.strategy_id)) continue;
    const clean = parseOverrides(row.strategy_id, row.params_json);
    if (Object.keys(clean).length) out[row.strategy_id] = clean;
  }
  return out;
}

export async function setStrategyParams(db, userId, id, values) {
  const row = await db.prepare(
    'SELECT params_json FROM strategy_params WHERE user_id = ? AND strategy_id = ?',
  ).bind(userId, id).first();
  const current = row ? parseOverrides(id, row.params_json) : {};
  const { errors, overrides } = laboMergeOverrides(id, current, values);
  if (errors.length) throw fail(errors);
  if (Object.keys(overrides).length === 0) {
    await db.prepare('DELETE FROM strategy_params WHERE user_id = ? AND strategy_id = ?').bind(userId, id).run();
  } else {
    await db.prepare(`
      INSERT INTO strategy_params (user_id, strategy_id, params_json, schema_version, updated_at)
      VALUES (?, ?, ?, ?, datetime('now'))
      ON CONFLICT(user_id, strategy_id) DO UPDATE SET
        params_json = excluded.params_json,
        schema_version = excluded.schema_version,
        updated_at = excluded.updated_at
    `).bind(userId, id, JSON.stringify(overrides), LABO_SCHEMA.version).run();
  }
  return getAllOverrides(db, userId);
}

export async function resetStrategyParams(db, userId, id) {
  if (!laboResolveStrategy(id)) throw fail([`Stratégie inconnue ou sans paramètres : ${id}`]);
  await db.prepare('DELETE FROM strategy_params WHERE user_id = ? AND strategy_id = ?').bind(userId, id).run();
  return getAllOverrides(db, userId);
}

export async function resetAllStrategyParams(db, userId) {
  await db.prepare('DELETE FROM strategy_params WHERE user_id = ?').bind(userId).run();
  return {};
}

// Valeurs effectives (défauts ⊕ surcharges) d'une stratégie pour un
// utilisateur — réutilisé par la grille de rendement annualisé et le
// screener de primes (22/9/2026, Options A/Journal A).
export async function getEffectiveParams(db, userId, id) {
  const row = await db.prepare(
    'SELECT params_json FROM strategy_params WHERE user_id = ? AND strategy_id = ?',
  ).bind(userId, id).first();
  const overrides = row ? parseOverrides(id, row.params_json) : {};
  return laboEffectiveParams(id, overrides);
}

// Vue d'administration (bilbao) : les surcharges de TOUS les comptes, avec
// le nom d'utilisateur et la date de dernière modification. Lecture seule.
export async function listAllUsersOverrides(db) {
  const { results } = await db.prepare(`
    SELECT u.username, u.disabled, sp.strategy_id, sp.params_json, sp.schema_version, sp.updated_at
    FROM strategy_params sp JOIN users u ON u.id = sp.user_id
    ORDER BY u.username, sp.strategy_id
  `).all();
  const out = [];
  for (const row of results) {
    if (!laboResolveStrategy(row.strategy_id)) continue;
    const params = parseOverrides(row.strategy_id, row.params_json);
    if (!Object.keys(params).length) continue;
    out.push({
      username: row.username,
      disabled: !!row.disabled,
      strategyId: row.strategy_id,
      overrides: params,
      schemaVersion: row.schema_version,
      updatedAt: row.updated_at,
    });
  }
  return out;
}
