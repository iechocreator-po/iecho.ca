// Groupes « le score prédit-il le R ? » (feature #376) — testés sur la version
// cloud de computeStats, pure (base injectée). Les deux versions ont les mêmes
// définitions de groupes (dupliquées, comme summarize/bucketize).
import test from 'node:test';
import assert from 'node:assert/strict';
import { computeStats } from '../cloud/src/lib/stats.js';

const fakeDb = (closed) => ({
  prepare: (sql) => ({ bind: () => ({
    all: async () => ({ results: closed }),
    first: async () => ({ c: closed.length }),
  }) }),
});
const tr = (o) => ({ resultat: o.r > 0 ? 'gagnant' : 'perdant', r_realise: o.r, setup_score: null, contexte_score: null, alignement_a_entree: null, signal_age_a_entree: null, ...o });

test('un trade sans score n\'entre dans AUCUN groupe de score (jamais un groupe « 0 »)', async () => {
  const s = await computeStats(fakeDb([tr({ r: 1 })]), 1);
  assert.equal(s.avecScore, 0);
  for (const g of [s.parSetup, s.parContexte, s.parAlignement, s.parAgeSignal]) {
    assert.ok(Object.values(g).every((b) => b.n === 0));
  }
});

test('répartition par score Setup, Contexte, alignement et âge du signal', async () => {
  const s = await computeStats(fakeDb([
    tr({ r: 2, setup_score: 5, contexte_score: 3, alignement_a_entree: 'haussier', signal_age_a_entree: 2 }),
    tr({ r: -1, setup_score: 2, contexte_score: 0, alignement_a_entree: 'haussier', signal_age_a_entree: 12 }),
    tr({ r: -1, setup_score: 1, contexte_score: -1, alignement_a_entree: 'neutre', signal_age_a_entree: 30 }),
  ]), 1);
  assert.equal(s.avecScore, 3);
  assert.equal(s.parSetup['Setup ≥ 4'].n, 1);
  assert.equal(s.parSetup['Setup 2–3'].n, 1);
  assert.equal(s.parSetup['Setup ≤ 1'].n, 1);
  assert.equal(s.parSetup['Setup ≥ 4'].rMoyen, 2);
  assert.equal(s.parContexte['Contexte < 0'].n, 1);
  assert.equal(s.parAlignement['Aligné à l\'entrée'].n, 2);
  assert.equal(s.parAlignement['Non aligné à l\'entrée'].n, 1);
  assert.equal(s.parAgeSignal['Signal frais (≤ 5 séances)'].n, 1);
  assert.equal(s.parAgeSignal['Signal moyen (6–20)'].n, 1);
  assert.equal(s.parAgeSignal['Signal ancien (> 20)'].n, 1);
  assert.equal(s.echantillonMin, 30);
});
