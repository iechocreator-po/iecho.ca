# castellana — cloud

Portage de castellana sur Cloudflare Workers + D1, multi-utilisateur (JP,
Louis, Guillaume — chacun avec son propre journal de trades, sa propre
watchlist et ses propres réglages). **Ce n'est pas un remplacement
immédiat** : l'app locale (`../server/`, `../launcher/`) continue de
fonctionner pendant que cette version est construite et vérifiée — voir
`../CLAUDE.md`, section « Portage Cloudflare Workers + D1 », pour le
contexte complet et ce qui a déjà été vérifié en local.

Construit et vérifié **entièrement en local** (`wrangler dev` + D1 local) —
rien de ce qui suit n'a encore tourné sur un vrai compte Cloudflare.

## Déploiement (geste manuel, à faire par JP)

Prérequis : un compte Cloudflare (déjà utilisé ailleurs dans le
portfolio).

```bash
cd cloud
npm install
npx wrangler login          # une seule fois, ouvre le navigateur

# 1. Créer la base D1
npx wrangler d1 create castellana-db
# → copier le "database_id" affiché et le coller dans wrangler.jsonc,
#   champ d1_databases[0].database_id (actuellement "local-dev-placeholder")

# 2. Appliquer le schéma à la base fraîchement créée
npm run db:schema:remote

# 3. Remplacer le secret du webhook TradingView par un vrai secret —
#    NE PAS laisser "changeme-en-local" en production
npx wrangler secret put WEBHOOK_SECRET
# (puis retirer WEBHOOK_SECRET de wrangler.jsonc → vars, pour ne pas avoir
#  deux définitions du même nom)

# 4. Créer un compte par personne
node scripts/create-user.mjs jp --remote
node scripts/create-user.mjs louis --remote
node scripts/create-user.mjs guillaume --remote

# 5. Migrer les données locales de JP (optionnel — le compte doit déjà exister)
node scripts/migrate-local-data.mjs jp --remote

# 6. Déployer
npx wrangler deploy
```

## Développement local

```bash
cd cloud
npm install
npm run db:schema:local              # une seule fois, ou après une modif de schema.sql
node scripts/create-user.mjs jp      # sans --remote = D1 local
npm run dev                          # wrangler dev, D1 local automatique
```

## Structure

```
cloud/
  schema.sql              — schéma D1 (users/sessions/trades/watchlist/preferences/cache/alerts)
  wrangler.jsonc           — config Worker (assets + D1 + nodejs_compat)
  src/
    index.js                — app Hono, middleware de session, montage des routes
    auth.js                  — hachage PBKDF2 (Web Crypto) + cookies de session
    db/                       — modules qui touchent D1 (cache, users, sessions, trades, watchlist, preferences, alerts)
    lib/                      — logique métier copiée de ../server/ (fundamentals, indicators, scoring, quotes, sectors, screening, stats, fetch-retry) — db (binding D1) reçu en paramètre plutôt qu'un singleton importé, impossible en Workers
    routes/                   — une route Hono par domaine, enregistrée à son chemin EXACT (pas de sous-routeur préfixé — /api/screening.csv est un chemin FRÈRE de /api/screening, pas un sous-chemin)
  public/                  — copie de ../index.html + ../js/ + ../design-system/ + ../img/concepts/, avec un écran de connexion en plus (voir CLAUDE.md pour le détail des 3 ajustements frontend)
  scripts/
    create-user.mjs          — crée un compte (JP l'exécute une fois par personne, pas d'auto-inscription dans l'app)
    migrate-local-data.mjs   — transfère le trade/watchlist/préférences locaux de JP vers son compte D1
```

## Différences avec la version locale

- **Multi-utilisateur réel** : `trades`/`watchlist`/`preferences` portent
  un `user_id`. `cache`/`alerts` restent globaux (voir CLAUDE.md pour le
  raisonnement).
- **Authentification réelle** (PBKDF2 + session en base), pas le patron
  client-side de barcelona/porto — aucun des deux n'offre de vérification
  serveur, inadapté à un vrai journal de trades personnel.
- **Sidecar Python et auto-mise-à-jour non portés** : Workers ne peut ni
  lancer de process Python, ni réécrire ses propres fichiers puis
  redémarrer. Le sidecar était déjà optionnel et désactivé par défaut
  depuis le 7/9/2026 — le screening tourne entièrement sur les calculs
  maison Yahoo, aucune perte fonctionnelle.
- Un déploiement (`wrangler deploy`) met à jour tout le monde d'un coup —
  pas de zip à télécharger ni de bandeau de mise à jour par testeur.

## Limites connues

- **Jamais déployé sur un vrai compte Cloudflare** — uniquement vérifié en
  local (`wrangler dev` + D1 local). Les étapes de déploiement ci-dessus
  n'ont donc été vérifiées que par lecture, pas exécutées.
- `WEBHOOK_SECRET` dans `wrangler.jsonc` est une valeur de développement en
  clair (`changeme-en-local`) — à remplacer par `wrangler secret put` avant
  tout déploiement réel (voir étape 3 ci-dessus).
- Les alertes TradingView (`/api/webhook/tradingview`) restent une table
  globale, non attribuée à un utilisateur — attribuer une alerte à une
  personne précise exigerait une URL de webhook distincte par compte.
