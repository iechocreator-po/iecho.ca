#!/usr/bin/env node
// Migre les données locales de JP (data/castellana.sqlite — journal de
// trades, watchlist, préférences) vers son compte D1 cloud. Usage unique,
// à exécuter APRÈS avoir créé le compte (scripts/create-user.mjs).
//
// Usage :
//   node scripts/migrate-local-data.mjs jp [--remote] [--db=../data/castellana.sqlite]
//
// Watchlist et préférences sont REMPLACÉES (DELETE puis INSERT) — la
// watchlist seedée par défaut à la création du compte n'est qu'un point de
// départ, pas la watchlist réelle de JP. Les trades sont AJOUTÉS (jamais de
// remplacement possible : ce sont des identifiants D1 fraîchement attribués).

import Database from 'better-sqlite3';
import { spawnSync } from 'node:child_process';
import { writeFileSync, unlinkSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));

const args = process.argv.slice(2);
const remote = args.includes('--remote');
const dbArg = args.find((a) => a.startsWith('--db='));
const username = args.find((a) => !a.startsWith('--'));
const localDbPath = dbArg ? dbArg.slice('--db='.length) : join(ROOT, '..', 'data', 'castellana.sqlite');

if (!username) {
  console.error('Usage : node scripts/migrate-local-data.mjs <nom-utilisateur> [--remote] [--db=chemin]');
  process.exit(1);
}

const flag = remote ? '--remote' : '--local';

function sqlLiteral(v) {
  if (v === null || v === undefined) return 'NULL';
  if (typeof v === 'number') return String(v);
  return `'${String(v).replace(/'/g, "''")}'`;
}

// Récupère l'id D1 du compte — le compte doit déjà exister
// (scripts/create-user.mjs, à exécuter d'abord).
function findUserId() {
  const result = spawnSync('npx', [
    'wrangler', 'd1', 'execute', 'castellana-db', flag,
    '--command', `SELECT id FROM users WHERE username='${username.replace(/'/g, "''")}'`,
    '--json',
  ], { cwd: ROOT, encoding: 'utf8' });
  if (result.status !== 0) {
    console.error(result.stderr || result.stdout);
    throw new Error('Impossible d\'interroger D1 — le compte existe-t-il ? (scripts/create-user.mjs)');
  }
  const parsed = JSON.parse(result.stdout);
  const row = parsed?.[0]?.results?.[0];
  if (!row) throw new Error(`Aucun compte "${username}" en D1 (${flag}) — crée-le d'abord avec scripts/create-user.mjs.`);
  return row.id;
}

console.log(`Lecture de ${localDbPath}...`);
const local = new Database(localDbPath, { readonly: true, fileMustExist: true });

const trades = local.prepare('SELECT * FROM trades').all();
const watchlist = local.prepare('SELECT ticker, exchange, source FROM watchlist').all();
const preferences = local.prepare('SELECT key, value FROM preferences').all();
local.close();

console.log(`Trouvé : ${trades.length} trade(s), ${watchlist.length} titre(s) en watchlist, ${preferences.length} préférence(s).`);

const userId = findUserId();
console.log(`Compte "${username}" → user_id D1 = ${userId}`);

const statements = [];

if (watchlist.length) {
  statements.push(`DELETE FROM watchlist WHERE user_id = ${userId};`);
  for (const w of watchlist) {
    statements.push(
      `INSERT INTO watchlist (user_id, ticker, exchange, source) VALUES (${userId}, ${sqlLiteral(w.ticker)}, ${sqlLiteral(w.exchange)}, ${sqlLiteral(w.source)});`,
    );
  }
}

if (preferences.length) {
  statements.push(`DELETE FROM preferences WHERE user_id = ${userId};`);
  for (const p of preferences) {
    statements.push(
      `INSERT INTO preferences (user_id, key, value) VALUES (${userId}, ${sqlLiteral(p.key)}, ${sqlLiteral(p.value)});`,
    );
  }
}

// Colonnes du journal — mêmes que server/trades.js COLUMNS, id/exclu (D1
// attribue un nouvel id), date_creation PRÉSERVÉE (pas régénérée à "now").
const TRADE_COLS = [
  'date_entree', 'date_sortie', 'compte', 'ticker', 'prix_entree', 'prix_sortie',
  'taille_position', 'stop_initial', 'vix_a_entree', 'rsi_a_entree', 'obv_a_entree',
  'correlation_flag', 'checklist_complete', 'r_realise', 'resultat',
  'setup_score', 'contexte_score', 'alignement_a_entree', 'signal_age_a_entree',
  'date_creation',
];
for (const t of trades) {
  const cols = ['user_id', ...TRADE_COLS];
  const values = [userId, ...TRADE_COLS.map((c) => sqlLiteral(t[c]))];
  statements.push(`INSERT INTO trades (${cols.join(', ')}) VALUES (${values.join(', ')});`);
}

if (statements.length === 0) {
  console.log('Rien à migrer.');
  process.exit(0);
}

const tmpFile = join(mkdtempSync(join(tmpdir(), 'castellana-migrate-')), 'migrate.sql');
writeFileSync(tmpFile, statements.join('\n'));
console.log(`\nApplication de ${statements.length} instruction(s) SQL (${flag})...`);
const result = spawnSync('npx', ['wrangler', 'd1', 'execute', 'castellana-db', flag, '--file', tmpFile], {
  cwd: ROOT,
  stdio: 'inherit',
});
unlinkSync(tmpFile);

if (result.status !== 0) {
  console.error('\nÉchec — voir le message de wrangler ci-dessus. Rien de local n\'a été modifié.');
  process.exit(result.status ?? 1);
}
console.log(`\nMigration terminée pour "${username}".`);
