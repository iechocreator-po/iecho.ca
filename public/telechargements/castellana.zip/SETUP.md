# Installation — Windows et macOS

Guide pas-à-pas pour cloner et lancer **castellana** (`trading-assistant`)
sur une nouvelle machine. Si tu ne l'as pas encore lu, jette d'abord un œil
au [`README.md`](README.md) — il explique ce que fait le projet et pourquoi
il y a deux serveurs séparés à lancer.

Suis la colonne de ton système d'exploitation à chaque étape.

## Prérequis

| Outil | Version | Windows | macOS |
|---|---|---|---|
| **Git** | récente | [git-scm.com/download/win](https://git-scm.com/download/win) | déjà installé, ou `xcode-select --install` |
| **Node.js** | 20 ou plus récent (LTS) | [nodejs.org](https://nodejs.org/) (installeur `.msi`) | [nodejs.org](https://nodejs.org/) ou `brew install node` |
| **Python** | 3.10 ou plus récent | [python.org/downloads/windows](https://www.python.org/downloads/windows/) — **coche "Add python.exe to PATH"** à l'installation | déjà installé, ou `brew install python` |
| **Accès GitHub** | — | Le dépôt est **privé**. Le propriétaire doit t'ajouter comme collaborateur (déjà fait si tu lis ceci), et il te faut être connecté à Git avec ton compte GitHub (voir étape 1). | idem |
| **Compte TradingView** | — | **Aucun compte requis, à aucune étape.** Le sidecar (étape 3) interroge des endpoints publics non officiels de TradingView, sans jamais se connecter. Rien à créer, rien à configurer de ce côté. | idem |

Vérifie que tout est bien installé et accessible dans un terminal :

```bash
git --version
node --version    # doit afficher v20.x ou plus
python --version  # Windows : "python". macOS : essaie "python3" si "python" ne répond pas
```

Le **sidecar Python est optionnel** (voir README) : si tu veux juste voir
l'app tourner rapidement, tu peux sauter les étapes qui le concernent et y
revenir plus tard.

## Étape 1 — Cloner le dépôt

> **Tu as déjà cloné ce projet avant aujourd'hui ?** Ne le re-clone pas —
> mets-le à jour à la place, pour être sûr d'avoir les derniers correctifs
> (le projet évolue régulièrement) :
> ```bash
> cd trading-assistant
> git pull
> ```
> Passe directement à l'étape 4. Un symptôme classique d'un dossier pas à
> jour : voir « Dépannage » plus bas, section *"`.` is not recognized..."*.

Le dépôt est **privé** : la première fois, Git va te demander de
t'authentifier (ta session GitHub dans le navigateur, ou un token d'accès
personnel si on te le demande en ligne de commande — jamais ton mot de
passe GitHub directement, cette méthode n'est plus acceptée par GitHub).

**Windows (PowerShell)** :
```powershell
cd $HOME\Documents
git clone https://github.com/iechocreator-po/trading-assistant.git
cd trading-assistant
```

**macOS (Terminal)** :
```bash
cd ~/Documents
git clone https://github.com/iechocreator-po/trading-assistant.git
cd trading-assistant
```

## Étape 2 — Installer les dépendances Node.js

```bash
npm install
```

Ça installe Express, la librairie SQLite, etc. (voir `package.json`).

**Point d'attention Windows** : une des dépendances (`better-sqlite3`) est
un module natif compilé en C++. `npm install` télécharge normalement un
binaire déjà compilé pour ta version de Node — dans l'immense majorité des
cas, ça marche sans rien installer de plus. Si `npm install` échoue avec
une erreur mentionnant `node-gyp`, `MSBuild`, `Visual Studio` ou `python`
introuvable, voir la section Dépannage plus bas.

## Étape 3 — Créer l'environnement Python du sidecar (optionnel)

Le sidecar vit dans son propre environnement virtuel Python (`.venv-mcp/`),
séparé de ton Python système, pour ne rien installer globalement sur ta
machine.

**Windows (PowerShell)** :
```powershell
python -m venv .venv-mcp
.venv-mcp\Scripts\activate
pip install tradingview-mcp-server
deactivate
```

**macOS (Terminal)** :
```bash
python3 -m venv .venv-mcp
source .venv-mcp/bin/activate
pip install tradingview-mcp-server
deactivate
```

À faire **une seule fois** par machine — `.venv-mcp/` n'est pas versionné
dans Git (voir `.gitignore`), donc chaque personne qui clone le projet doit
la recréer chez elle.

## Étape 4 — Lancer l'application

Il faut **deux terminaux ouverts en même temps** (le sidecar est optionnel,
saute le deuxième terminal si tu ne l'as pas installé à l'étape 3 — l'app
démarre quand même, juste avec certains champs à saisir à la main).

**Terminal 1 — le serveur principal (obligatoire), identique sur les deux OS :**
```bash
npm start
```
Tu dois voir `castellana — http://127.0.0.1:4700`.

**Terminal 2 — le sidecar (optionnel), identique sur les deux OS :**
```bash
npm run sidecar
```
Tu dois voir `Uvicorn running on http://127.0.0.1:4701`.

> Le script `npm run sidecar` détecte automatiquement Windows vs macOS/Linux
> et va chercher le bon exécutable dans `.venv-mcp/` — pas besoin d'activer
> le venv à la main pour cette étape, seulement à l'étape 3.

## Étape 5 — Ouvrir l'app

Ouvre **http://127.0.0.1:4700** dans ton navigateur.

En haut de la page, un témoin à 3 pastilles indique ce qui tourne :
- 🟢 **Backend** — doit toujours être vert (sinon, Terminal 1 n'est pas
  lancé, ou une erreur y est affichée).
- 🟢 **tradingview-mcp** — vert si le sidecar (Terminal 2) tourne.
  Rouge = normal si tu as sauté l'étape 3, ou si tu n'as pas ouvert le
  Terminal 2 ; le reste de l'app fonctionne quand même.
- 🟢 **Calculs maison** — doit être vert dès que le backend tourne (teste
  juste que Yahoo Finance répond).

## Dépannage

### `npm run sidecar` affiche `./.venv-mcp/bin/tradingview-mcp ...` puis `'.' is not recognized as an internal or external command`

C'est le signe le plus clair que **le dossier n'est pas à jour** — cette
commande venait d'un ancien bug (chemin Unix codé en dur, incompatible avec
Windows), corrigé depuis. Mets le projet à jour puis relance :

```bash
cd trading-assistant
git pull
npm run sidecar
```

Après le `git pull`, la ligne affichée doit devenir
`> node scripts/run-sidecar.mjs` — si elle affiche encore l'ancien chemin
`.venv-mcp/bin/...`, le `git pull` n'a pas pris (vérifie qu'il ne s'est pas
arrêté sur un message d'erreur, par exemple des modifications locales non
commitées qui bloquent la mise à jour — lance `git status` pour voir).

### "Port 4700 (ou 4701) already in use" / port déjà utilisé

Une instance précédente tourne encore.

**Windows (PowerShell)** :
```powershell
netstat -ano | findstr :4700
taskkill /PID <le_numero_trouve> /F
```

**macOS (Terminal)** :
```bash
lsof -ti:4700 | xargs kill
```
(remplacer `4700` par `4701` pour le sidecar)

### `npm install` échoue sur `better-sqlite3` (Windows)

Ça veut dire qu'aucun binaire précompilé n'était disponible pour ta
version de Node, et que `npm` a essayé de le compiler lui-même sans les
outils nécessaires. Deux solutions :
1. **Le plus simple** : installe une version LTS récente et courante de
   Node (voir [nodejs.org](https://nodejs.org/)) — les binaires précompilés
   couvrent presque toujours les dernières versions LTS.
2. Si ça persiste : installe les **"Build Tools for Visual Studio"**
   ([visualstudio.microsoft.com/downloads](https://visualstudio.microsoft.com/downloads/),
   section "Outils pour Visual Studio") avec la charge de travail
   **"Développement Desktop en C++"** cochée, puis relance `npm install`.

### `npm install` échoue avec une erreur `EACCES` (permissions du cache npm)

```bash
npm install --cache ./.npm-cache
```
(fonctionne sur les deux OS — contourne un cache npm mal configuré sans
toucher à la config globale de la machine)

### `git clone` demande un mot de passe et le refuse

GitHub n'accepte plus les mots de passe de compte en ligne de commande.
Le plus simple : installe [GitHub CLI](https://cli.github.com/) puis
`gh auth login`, ou configure un
[token d'accès personnel](https://github.com/settings/tokens) à utiliser
comme mot de passe au clone.

### `python` introuvable (Windows) ou `python3` introuvable (macOS)

- Windows : réinstalle Python en cochant **"Add python.exe to PATH"**, ou
  utilise `py -m venv .venv-mcp` à la place de `python -m venv .venv-mcp`.
- macOS : `brew install python`, ou utilise `python3` explicitement (macOS
  ne fournit plus `python` tout court par défaut).

### Le témoin "tradingview-mcp" est rouge

Depuis peu, l'app affiche la **cause exacte** sous les 3 pastilles dès que
l'une d'elles est rouge (bandeau rouge sous la barre de statut) — regarde
ce message en premier, il indique précisément quoi faire. Deux cas
fréquents :
- `Sidecar non démarré ou injoignable sur http://127.0.0.1:4701/mcp` →
  le Terminal 2 (`npm run sidecar`) n'est pas ouvert, a planté, ou vient
  d'être fermé. Relance-le.
- Un autre message d'erreur réseau/MCP → copie-le tel quel, c'est la
  cause exacte remontée par le sidecar, pas un rate-limit générique. Ce
  témoin (poignée de main MCP) n'est **pas** affecté par le rate-limit de
  TradingView sur le RSI/Golden Cross (voir `CLAUDE.md`) — un rate-limit
  laisse ces deux champs vides dans l'app sans faire passer le témoin au
  rouge, c'est un problème différent.

### Rien de tout ça n'a marché

Copie le message d'erreur exact (dans son intégralité) et partage-le avec
la personne qui maintient le projet — presque toutes les erreurs
d'installation Node/Python indiquent clairement quel outil ou quel chemin
pose problème.
