// castellana cloud — Worker principal (Hono). Portage de server/index.js
// (Express + better-sqlite3, local) vers Workers + D1, multi-utilisateur.
// Voir CLAUDE.md du produit, section « Analyse de marché élargie » /
// « Portage Cloudflare » pour le contexte complet de cette refonte.
//
// Ce qui n'est PAS porté (voir le plan de migration) : /api/version et
// /api/update/apply (auto-mise à jour — réécrit des fichiers sur disque et
// fait process.exit(0), aucun équivalent Workers ; les déploiements cloud
// se font par `wrangler deploy`) et tout ce qui touchait le sidecar Python
// tradingview-mcp (déjà optionnel et désactivé par défaut côté local
// depuis le 7/9/2026).

import { Hono } from 'hono';
import { readSessionToken } from './auth.js';
import { findSession, touchUserActivity } from './db/sessions.js';
import { registerAuthRoutes } from './routes/auth.js';
import { registerAdminAuthMiddleware, registerAdminRoutes } from './routes/admin.js';
import { registerMiscRoutes } from './routes/misc.js';
import { registerPreferencesRoutes } from './routes/preferences.js';
import { registerLaboParamsRoutes } from './routes/labo-params.js';
import { registerFlagsRoutes } from './routes/flags.js';
import { withYahoo } from './lib/yahoo.js';
import { withDemo } from './db/cache.js';
import { withTvContext } from './lib/tv-provider.js';
import { registerSectorsRoutes } from './routes/sectors.js';
import { registerScreeningRoutes } from './routes/screening.js';
import { registerTradesRoutes } from './routes/trades.js';
import { registerWatchlistRoutes } from './routes/watchlist.js';
import { registerListsRoutes } from './routes/lists.js';
import { registerMarketRoutes } from './routes/market.js';
import { registerOptionTradesRoutes } from './routes/option-trades.js';
import { registerTradingviewRoutes } from './routes/tradingview.js';
import { registerAiRoutes } from './routes/ai.js';
import { registerAnticipationRoutes } from './routes/anticipation.js';
import { registerSnapshotRoutes } from './routes/snapshots.js';

const app = new Hono();

// En-têtes de sécurité (audit routes, 21/10/2026) : l'application ne peut plus être affichée dans le cadre d'un autre site
// (clickjacking), le navigateur ne devine plus le type des fichiers, et la connexion reste en https. Les fichiers statiques reçoivent
// les mêmes en-têtes par public/_headers. Pas de politique de scripts stricte : les pages utilisent encore des gestionnaires en ligne.
app.use('*', async (c, next) => {
  await next();
  c.header('X-Content-Type-Options', 'nosniff');
  c.header('X-Frame-Options', 'DENY');
  c.header('Referrer-Policy', 'same-origin');
  c.header('Strict-Transport-Security', 'max-age=31536000');
});

// Routes publiques (aucune session requise) : identifiants eux-mêmes, le
// webhook TradingView (protégé par son propre secret partagé, voir
// routes/misc.js, puisque TradingView ne peut pas envoyer de cookie), et
// l'API d'administration (/api/admin/, 19/9/2026) — celle-ci N'EST PAS
// ouverte à tout le monde, elle a sa PROPRE vérification (Basic Auth,
// registerAdminAuthMiddleware ci-dessous) plutôt qu'une session castellana,
// qui n'aurait aucun sens pour bilbao.
const PUBLIC_PREFIXES = ['/api/auth/', '/api/admin/'];
const PUBLIC_EXACT = ['/api/webhook/tradingview'];

app.use('/api/*', async (c, next) => {
  const path = c.req.path;
  if (PUBLIC_PREFIXES.some((p) => path.startsWith(p)) || PUBLIC_EXACT.includes(path)) {
    return next();
  }
  const token = readSessionToken(c.req.header('Cookie'));
  if (!token) return c.json({ error: 'Non authentifié' }, 401);
  const session = await findSession(c.env.DB, token);
  if (!session) return c.json({ error: 'Non authentifié' }, 401);
  c.set('userId', session.userId);
  c.set('username', session.username);
  // Après la réponse : la dernière activité ne retarde jamais une requête.
  const touch = touchUserActivity(c.env.DB, session.userId);
  try { c.executionCtx.waitUntil(touch); } catch { await touch; }
  await next();
});

// Contexte du fournisseur de données TradingView (étape 2 de #367) — pour les requêtes
// authentifiées seulement ; ne fait aucune requête base tant qu'une donnée n'est pas demandée.
app.use('/api/*', (c, next) => withTvContext(c, next));

// Mode démo (en-tête X-Demo-Mode) — cache prolongé et repli sur la dernière valeur connue.
app.use('/api/*', (c, next) => withDemo(c, next));

// Une instance Yahoo par requête (voir src/lib/yahoo.js) — AVANT tout le reste.
app.use('*', (c, next) => withYahoo(c.env.DB, next));

registerAdminAuthMiddleware(app);

registerAuthRoutes(app);
registerAdminRoutes(app);
registerSnapshotRoutes(app); // instantanés poussés par l'app locale (balayage S&P 500)
registerMiscRoutes(app);
registerPreferencesRoutes(app);
registerFlagsRoutes(app);
registerLaboParamsRoutes(app); // avant registerMarketRoutes : /api/labo/:ticker
registerSectorsRoutes(app);
registerScreeningRoutes(app);
registerTradesRoutes(app);
registerWatchlistRoutes(app);
registerListsRoutes(app);
registerTradingviewRoutes(app);
registerAiRoutes(app); // analyse de contexte IA (flag ai_analyst par compte)
registerAnticipationRoutes(app); // onglet Anticipation (flag anticipation_tab par compte)
// Journal A (22/9/2026) AVANT registerMarketRoutes : /api/options/premium-screener
// serait sinon capturé par /api/options/:ticker (bug réel trouvé en testant
// en direct côté serveur local — même piège que /api/labo/params ci-dessus).
registerOptionTradesRoutes(app);
registerMarketRoutes(app);

// Filet de sécurité — même principe que server/index.js (feature 351,
// 7/9/2026) : une route /api/ inconnue doit répondre en JSON, jamais avec
// une page d'erreur qui casserait JSON.parse côté frontend.
app.notFound((c) => {
  if (c.req.path.startsWith('/api/')) {
    return c.json({
      error: `Route API inconnue : ${c.req.method} ${c.req.path}`,
      hint: 'Le serveur ne connaît pas cette route. Recharge la page (Cmd/Ctrl+Shift+R).',
    }, 404);
  }
  // Les chemins hors /api/ sont normalement déjà servis par le binding
  // assets (public/) — ce repli ne devrait être atteint que pour un
  // chemin qui n'existe ni en statique ni en route API.
  return c.text('Introuvable', 404);
});

app.onError((err, c) => {
  console.error(`[api] erreur non interceptée sur ${c.req.path} :`, err);
  // Le détail (noms de colonnes et de contraintes D1) reste dans les journaux du Worker, pas dans la réponse (audit routes, 21/10/2026).
  return c.json({ error: 'Erreur interne du serveur' }, 500);
});

export default app;
