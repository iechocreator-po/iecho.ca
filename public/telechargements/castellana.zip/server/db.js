import Database from 'better-sqlite3';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readFileSync } from 'node:fs';

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const settings = JSON.parse(readFileSync(new URL('../settings.json', import.meta.url)));
const dbPath = `${ROOT}${settings.dbPath}`;

mkdirSync(dirname(dbPath), { recursive: true });

export const db = new Database(dbPath);
db.pragma('journal_mode = WAL');

// Schéma du journal de trades — voir design_assistant_swing_trading.md
// section 7 pour le détail du modèle de données validé avec JP.
db.exec(`
  CREATE TABLE IF NOT EXISTS trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date_entree TEXT NOT NULL,
    date_sortie TEXT,
    compte TEXT NOT NULL CHECK (compte IN ('RRSP','margin','corporatif')),
    ticker TEXT NOT NULL,
    prix_entree REAL NOT NULL,
    prix_sortie REAL,
    taille_position INTEGER NOT NULL,
    stop_initial REAL NOT NULL,
    vix_a_entree REAL,
    rsi_a_entree REAL,
    obv_a_entree TEXT CHECK (obv_a_entree IN ('accumulation','neutre','distribution')),
    correlation_flag INTEGER NOT NULL DEFAULT 0 CHECK (correlation_flag IN (0,1)),
    checklist_complete INTEGER NOT NULL DEFAULT 0 CHECK (checklist_complete IN (0,1)),
    r_realise REAL,
    resultat TEXT CHECK (resultat IN ('gagnant','perdant')),
    date_creation TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

// Alertes TradingView reçues par webhook (feature 323, exploratoire) — le
// Pine Script v5 du design doc peut POSTer son alerte sur
// /api/webhook/tradingview ; on la stocke brute (payload JSON) pour
// rapprocher a posteriori le signal de l'alerte du trade réellement pris.
// Aucune exécution déclenchée : c'est un journal d'alertes, pas un ordre.
db.exec(`
  CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker TEXT,
    message TEXT,
    payload TEXT,
    recu_le TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

// Univers de screening éditable (bonus) — persiste la watchlist en base
// plutôt qu'en dur dans watchlist.js. Semé au premier démarrage depuis
// SEED_WATCHLIST (voir watchlist.js) si la table est vide. `source` = 'jp'
// (12 titres suivis) | 'claude' (8 ajoutés) | 'user' (ajout via l'UI).
db.exec(`
  CREATE TABLE IF NOT EXISTS watchlist (
    ticker TEXT PRIMARY KEY,
    exchange TEXT NOT NULL DEFAULT 'NASDAQ',
    source TEXT NOT NULL DEFAULT 'user',
    date_ajout TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);
