// js/app-fiche.js — Fiche de trade : indices d'en-tête, checklist, calcul, données en direct
// Extrait de l'ancien script en ligne des index.html (découpage phase 2, 20/10/2026) : code déplacé tel quel, sans réécriture.
// Fichier COMMUN aux versions locale et cloud : source ici ; cloud/public/js/app-fiche.js en est la copie (npm run sync:cloud).
// Script classique : ses noms de premier niveau sont globaux et partagés avec les autres scripts de la page.

// ---- Onglet Fiche de trade ----
function vixInterp(vix) {
  const b = CFG.bandes.vix;
  if (vix < b.normalBas) return { label: 'Complaisance', cls: 'ds-badge--warning', note: 'Marché calme, primes d\'option basses — risque de retournement soudain. Ne pas relâcher la discipline sur les stops.' };
  if (vix < b.normalHaut) return { label: 'Normal', cls: 'ds-badge--success', note: 'Climat neutre — taille de base appropriée.' };
  if (vix < b.nervositeHaut) return { label: 'Nervosité', cls: 'ds-badge--warning', note: 'Volatilité élevée — élargir les stops (ATR plus large) ou réduire la taille.' };
  return { label: 'Panique', cls: 'ds-badge--danger', note: 'Zone de panique — faux signaux fréquents. Réduire la taille de moitié ou attendre la stabilisation.' };
}
// Pastille VIX du header (28/9/2026) — indépendante de la Fiche de trade et
// de la banderole technique : une seule cotation légère (/api/quote/^VIX),
// visible peu importe l'onglet actif. Réutilise vixInterp() ci-dessus pour
// que la couleur suive exactement les mêmes bandes que la Fiche.
// Dernière valeur VIX connue, globale — plus un champ de saisie de la Fiche
// (carte "Climat de marché" retirée le 28/9/2026, remplacée par la pastille
// du header) : la checklist et le sizing de la Fiche lisent CETTE variable
// au lieu d'un `<input>`, mise à jour par loadHeaderIndices() ci-dessous.
// `null` tant qu'aucune cotation n'a réussi.
let currentVix = null;
// Pastille numérique simple (COR1M/VIXEQ/DSPX) — pas de couleur/interprétation,
// juste le dernier prix Yahoo affiché tel quel derrière son libellé.
// Pastille colorée générique (COR1M/DSPX) — même patron que VIX : une
// cotation, une fonction d'interprétation qui donne label/classe/note.
async function loadColoredIndexBadge(elId, symbol, label, interpFn) {
  const el = document.getElementById(elId);
  if (!el) return null;
  try {
    const q = await fetchJSON('/api/quote/' + encodeURIComponent(symbol));
    if (q.price == null) throw new Error('prix indisponible');
    const v = interpFn(q.price);
    el.textContent = `${label} ${q.price.toFixed(1)} · ${v.label}`;
    el.className = 'ds-badge ' + v.cls;
    el.title = v.note;
    return q.price;
  } catch {
    el.textContent = `${label} —`;
    el.className = 'ds-badge';
    el.title = 'Indisponible.';
    return null;
  }
}
async function loadHeaderIndices() {
  const vixEl = document.getElementById('header-vix');
  if (vixEl) {
    try {
      const q = await fetchJSON('/api/quote/' + encodeURIComponent('^VIX'));
      if (q.price == null) throw new Error('prix indisponible');
      const vixAvant = currentVix;
      currentVix = q.price;
      // La taille des tableaux attendait le VIX (« N/D ») : on les redessine à son arrivée, une seule fois.
      if (vixAvant == null) {
        if (typeof renderScreeningRows === 'function' && lastScreeningRows.length) renderScreeningRows();
        if (typeof renderSectorTopRows === 'function' && lastSectorTopRows.length) renderSectorTopRows();
      }
      const v = vixInterp(q.price);
      vixEl.textContent = `VIX ${q.price.toFixed(1)} · ${v.label}`;
      vixEl.className = 'ds-badge ' + v.cls;
      vixEl.title = v.note;
    } catch {
      currentVix = null;
      vixEl.textContent = 'VIX —';
      vixEl.className = 'ds-badge';
      vixEl.title = 'Indisponible.';
    }
  }
  const [, vixeqPrice] = await Promise.allSettled([
    loadColoredIndexBadge('header-cor1m', '^COR1M', 'COR1M', cor1mInterp),
    fetchJSON('/api/quote/' + encodeURIComponent('^VIXEQ')).then((q) => q.price),
    loadColoredIndexBadge('header-dspx', '^DSPX', 'DSPX', dspxInterp),
  ]);
  // VIXEQ colorée sur son ÉCART au VIX, pas sur son niveau absolu — voir
  // vixeqSpreadInterp() et la note de config.js.
  const vixeqEl = document.getElementById('header-vixeq');
  if (vixeqEl) {
    const price = vixeqPrice.status === 'fulfilled' ? vixeqPrice.value : null;
    if (price == null || currentVix == null) {
      vixeqEl.textContent = 'VIXEQ —';
      vixeqEl.className = 'ds-badge';
      vixeqEl.title = 'Indisponible (nécessite VIX et VIXEQ).';
    } else {
      const spread = price - currentVix;
      const v = vixeqSpreadInterp(spread);
      vixeqEl.textContent = `VIXEQ ${price.toFixed(1)} · +${spread.toFixed(1)} vs VIX (${v.label})`;
      vixeqEl.className = 'ds-badge ' + v.cls;
      vixeqEl.title = v.note;
    }
  }
}
// COR1M/DSPX/VIXEQ (28/9/2026) — mêmes bandes vert/amber/rouge que le VIX,
// seuils dans CFG.bandes (voir config.js pour les sources et réserves).
function cor1mInterp(v) {
  const b = CFG.bandes.cor1m;
  if (v < b.faibleHaut) return { label: 'Faible', cls: 'ds-badge--success', note: "Corrélation faible — chaque titre bouge pour ses propres raisons (stock-picking), pas pour des raisons de marché." };
  if (v < b.modereHaut) return { label: 'Modérée', cls: 'ds-badge--warning', note: "Corrélation modérée — mélange de mouvements propres au titre et de mouvements de marché." };
  return { label: 'Élevée', cls: 'ds-badge--danger', note: "Corrélation élevée — le marché bouge en bloc (macro, risk-off) : la diversification protège moins." };
}
function dspxInterp(v) {
  const b = CFG.bandes.dspx;
  // Miroir de COR1M : dispersion faible ≈ corrélation élevée (tout bouge
  // ensemble), dispersion élevée ≈ corrélation faible (chaque titre suit
  // sa propre histoire) — d'où les couleurs inversées par rapport au niveau.
  if (v < b.faibleHaut) return { label: 'Faible', cls: 'ds-badge--danger', note: "Dispersion faible — les titres bougent ensemble, cohérent avec une corrélation élevée." };
  if (v < b.modereHaut) return { label: 'Modérée', cls: 'ds-badge--warning', note: "Dispersion modérée." };
  return { label: 'Élevée', cls: 'ds-badge--success', note: "Dispersion élevée — chaque titre suit sa propre histoire, cohérent avec une corrélation faible." };
}
// VIXEQ se colore sur son ÉCART au VIX (VIXEQ − VIX), pas sur son niveau
// absolu — voir la note de config.js pour pourquoi un niveau absolu
// tromperait (VIXEQ dépasse presque toujours le VIX, même en marché calme).
function vixeqSpreadInterp(spread) {
  const b = CFG.bandes.vixeqSpread;
  if (spread < b.normalHaut) return { label: 'Normal', cls: 'ds-badge--success', note: "Écart VIXEQ − VIX proche de sa moyenne historique (~13 pts) — rien d'inhabituel." };
  if (spread < b.eleveHaut) return { label: 'Élevé', cls: 'ds-badge--warning', note: "Écart nettement au-dessus de la moyenne — le marché price les titres individuels bien plus volatils que l'indice." };
  return { label: 'Extrême', cls: 'ds-badge--danger', note: "Écart proche des niveaux historiques les plus élevés observés (record : 34,1 pts, 9 juillet 2026)." };
}
function rsiInterp(rsi) {
  const b = CFG.bandes.rsi;
  if (rsi > b.entreeHaut) return { label: 'Surachat', cls: 'ds-badge--danger', note: 'Risque de chasser un prix déjà étendu — attends un repli avant d\'entrer.' };
  if (rsi >= b.entreeBas) return { label: 'Zone d\'entrée', cls: 'ds-badge--success', note: 'Pullback ou momentum sain dans la tendance — cohérent avec ton setup SMA.' };
  if (rsi >= b.surventeHaut) return { label: 'Pullback profond', cls: 'ds-badge--warning', note: 'Repli plus marqué — valide avec la structure (support) avant d\'entrer.' };
  return { label: 'Survente', cls: 'ds-badge--warning', note: 'Zone extrême — vérifie si la SMA lente tient encore avant de considérer un achat.' };
}
function obvInterp(obv) {
  if (obv === 'distribution') return { note: 'Divergence détectée — le prix monte mais le volume derrière faiblit. Conviction fragile, envisage d\'attendre une confirmation.', warn: true };
  if (obv === 'neutre') return { note: 'Pas de signal clair — ni confirmation ni divergence. Ne pas s\'y fier seul.', warn: false };
  return { note: 'OBV confirme la tendance — la conviction derrière le prix est saine.', warn: false };
}
// ---- Verdicts de la checklist pré-trade (7/9/2026, demande de JP) ----
//
// Chaque ligne affiche ce que disent les données, SANS jamais cocher la case.
// C'est la discipline en place depuis le 23/7/2026 (« sans cocher aucune
// case automatiquement — l'engagement de la checklist reste un geste
// manuel ») : une checklist auto-cochée n'est plus une checklist, c'est un
// score, et elle perdrait sa fonction de garde-fou.
//
// Deux des six items ne sont PAS calculables et le disent :
//   — « bougie de confirmation clôturée » dépend du moment où JP regarde son
//     graphique et de l'unité de temps qu'il utilise, ni l'une ni l'autre
//     connues ici ;
//   — « je m'engage à placer le stop » est un engagement, pas une mesure.
// Les afficher comme « à ton jugement » vaut mieux qu'un verdict inventé.
let ficheMarketData = null; // dernier /api/market-data reçu pour ce ticker

function setVerdict(id, cls, texte, titre) {
  const el = document.getElementById(id);
  if (!el) return;
  el.className = 'cv cv--' + cls;
  el.textContent = texte;
  el.title = titre || '';
}
function renderChecklistVerdicts() {
  // Garde-fou : les données mémorisées ne valent que pour LE ticker
  // actuellement saisi. Sans ce contrôle, changer de titre sans recliquer
  // « Récupérer en direct » laisserait l'alignement des moyennes et le
  // volume du titre PRÉCÉDENT sous les yeux de JP — un verdict faux et
  // crédible, ce qui est pire qu'aucun verdict.
  const tickerEl = document.getElementById('ticker');
  const tickerActuel = tickerEl ? tickerEl.value.trim().toUpperCase() : '';
  const d = (ficheMarketData && ficheMarketData.ticker === tickerActuel) ? ficheMarketData : null;
  let calculables = 0;
  let favorables = 0;
  const compte = (ok) => { calculables++; if (ok) favorables++; };

  // 1. Alignement des moyennes — vient du calcul maison, donc seulement
  //    après « Récupérer en direct ».
  if (!d || d.smaAlignment == null) {
    setVerdict('cv1', 'na', '— non récupéré', 'Clique « Récupérer en direct » (section Le titre) pour calculer cette ligne.');
  } else if (d.smaAlignment === 'haussier') {
    const p = d.smaPeriods;
    setVerdict('cv1', 'ok', '✓ aligné', p ? `Prix > SMA${p.fast} > SMA${p.medium} > SMA${p.slow}` : '');
    compte(true);
  } else if (d.smaAlignment === 'baissier') {
    setVerdict('cv1', 'bad', '✗ aligné à la baisse', 'Alignement baissier — valide pour une vente, pas pour un achat.');
    compte(false);
  } else {
    setVerdict('cv1', 'warn', '~ non aligné', 'Les moyennes ne sont pas dans l\'ordre : ni setup haussier, ni baissier.');
    compte(false);
  }

  // 2. Non calculable — voir le commentaire en tête.
  setVerdict('cv2', 'na', 'à ton jugement', "Dépend de l'unité de temps que tu regardes et du moment — l'app ne peut pas le savoir.");

  // 3. Volume vs moyenne 20 jours.
  if (!d || d.volumeRatio == null) {
    setVerdict('cv3', 'na', '— non récupéré', 'Clique « Récupérer en direct » pour calculer cette ligne.');
  } else {
    const pct = Math.round(d.volumeRatio * 100);
    const ok = d.volumeRatio >= 1;
    setVerdict('cv3', ok ? 'ok' : 'bad', (ok ? '✓ ' : '✗ ') + pct + ' %',
      `Volume du jour à ${pct} % de sa moyenne 20 jours.`);
    compte(ok);
  }

  // 4. VIX — plus un champ de saisie (carte "Climat de marché" retirée le
  // 28/9/2026) : lit désormais currentVix, alimenté globalement par
  // loadHeaderIndices(), peu importe l'onglet. 5 lit toujours le CHAMP RSI
  // du formulaire (JP peut le saisir à la main), le verdict doit suivre ce
  // qu'il voit à l'écran.
  const vixVal = currentVix;
  if (!Number.isFinite(vixVal)) {
    setVerdict('cv4', 'na', '— pas de VIX', 'VIX indisponible pour le moment (pastille du header).');
  } else {
    const info = vixInterp(vixVal);
    const cls = info.cls === 'ds-badge--success' ? 'ok' : (info.cls === 'ds-badge--danger' ? 'bad' : 'warn');
    // Un préfixe par état, cohérent avec les autres lignes : ✓ favorable,
    // ✗ défavorable, ~ entre les deux. Un « ~ » sur une pastille rouge
    // envoyait deux signaux contradictoires sur la même ligne.
    const prefixe = { ok: '✓ ', bad: '✗ ', warn: '~ ' }[cls];
    setVerdict('cv4', cls, prefixe + info.label + ' (' + vixVal + ')', info.note);
    compte(cls === 'ok');
  }

  // 5. RSI ET OBV — la ligne combine deux conditions, le verdict aussi :
  //    il n'est vert que si les DEUX le sont, sinon il nomme celle qui
  //    manque plutôt que de donner une moyenne trompeuse.
  const rsiEl = document.getElementById('rsi');
  const obvEl = document.getElementById('obv');
  const rsiVal = rsiEl ? +rsiEl.value : NaN;
  if (!Number.isFinite(rsiVal) || rsiEl.value === '') {
    setVerdict('cv5', 'na', '— pas de RSI', 'Saisis le RSI ou récupère-le en direct.');
  } else {
    const rInfo = rsiInterp(rsiVal);
    const rsiOk = rInfo.cls === 'ds-badge--success';
    const obvVal = obvEl ? obvEl.value : null;
    const obvOk = obvVal !== 'distribution';
    if (rsiOk && obvOk) {
      setVerdict('cv5', 'ok', '✓ RSI ' + rsiVal.toFixed(2) + ' · OBV ' + obvVal, rInfo.note);
      compte(true);
    } else {
      const manque = [];
      if (!rsiOk) manque.push('RSI ' + rInfo.label.toLowerCase() + ' (' + rsiVal.toFixed(2) + ')');
      if (!obvOk) manque.push('OBV en distribution');
      setVerdict('cv5', rInfo.cls === 'ds-badge--danger' || !obvOk ? 'bad' : 'warn', '✗ ' + manque.join(' · '), rInfo.note);
      compte(false);
    }
  }

  // 6. Non calculable — c'est un engagement.
  setVerdict('cv6', 'na', 'ton engagement', "Aucune donnée ne peut valider ça à ta place.");

  const resume = document.getElementById('checklist-resume');
  if (resume) {
    resume.innerHTML = calculables === 0
      ? "Récupère les données en direct pour que l'app évalue les 4 lignes calculables."
      : `<strong>${favorables}/${calculables}</strong> condition(s) calculable(s) favorable(s). `
        + "Les 2 autres lignes ne sont pas mesurables — et <strong>aucune case n'est cochée automatiquement</strong> : "
        + "l'app dit ce que disent les données, cocher reste ton engagement.";
  }
}
// Prix d'entrée rempli automatiquement (clôture de la veille, ou prix du
// screening) : on retient pour quel symbole, afin de l'effacer si le symbole
// change — un prix d'un autre titre sous le nouveau symbole serait faux et
// crédible. Une saisie à la main le désarme : ce prix est alors à l'utilisateur.
let entryAutoFilled = null;
function setEntryNote(text) {
  const el = document.getElementById('entry-note');
  if (el) el.textContent = text;
}
function entryManualEdit() {
  entryAutoFilled = null;
  setEntryNote("Prix saisi à la main.");
  calcFiche();
}
function clearAutoFilledEntry() {
  if (!entryAutoFilled) return;
  document.getElementById('entry').value = '';
  entryAutoFilled = null;
  setEntryNote("Saisis ton prix d'entrée, ou clique « Récupérer en direct » pour partir de la dernière clôture.");
}
// 'YYYY-MM-DD' → « 18 sept. 2026 »
function fmtDateFr(iso) {
  return new Date(iso + 'T12:00:00Z').toLocaleDateString('fr-CA', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' });
}
// `marketPromise` : un /api/market-data déjà lancé par l'appelant (la Fiche et
// le Labo en ont besoin pour eux-mêmes — on ne l'appelle pas deux fois).
// `quiet` : ne pas écrire le message final, l'appelant compose le sien à partir
// des notes retournées.
// Valeur numérique arrondie à 2 décimales pour un champ de saisie (T6, 2/10/2026) : le serveur renvoie
// 8 à 10 chiffres, illisibles dans un champ de cette largeur. Un champ reste saisissable à la main.
const fmt2 = (v) => Number(Number(v).toFixed(2));
async function fetchLiveSelectionFor(instanceKey, { marketPromise, quiet = false } = {}) {
  const ids = SELECTION_INSTANCES[instanceKey];
  const ticker = document.getElementById(ids.ticker).value.toUpperCase();
  const status = document.getElementById(ids.liveStatus);
  if (!ticker) { status.textContent = "Entre un symbole d'abord."; return null; }
  if (!quiet) status.textContent = 'Récupération en cours…';
  // Une seule requête /api/market-data, partagée avec la carte Fondamentaux
  // (FCF) — celle-ci a besoin du prix courant pour le rendement du FCF
  // (28/9/2026), sans appel réseau de plus.
  const marketFetch = marketPromise || fetchJSON(`/api/market-data/${ticker}`);
  const fcfLoad = FCF_INSTANCES.includes(instanceKey) ? loadFcfCard(ticker, instanceKey + '-fcf-card', marketFetch) : Promise.resolve(null);
  const [quote, benchmark, market] = await Promise.allSettled([
    fetchJSON(`/api/quote/${ticker}`),
    fetchJSON('/api/quote/SPY'),
    marketFetch,
  ]);
  const notes = [];
  if (quote.status === 'fulfilled' && quote.value.changePercent != null) {
    document.getElementById(ids.perfTitre).value = fmt2(quote.value.changePercent);
  } else notes.push('performance du titre indisponible');
  if (benchmark.status === 'fulfilled' && benchmark.value.changePercent != null) {
    document.getElementById(ids.perfIndice).value = fmt2(benchmark.value.changePercent);
  } else notes.push("performance de l'indice indisponible");
  if (market.status === 'fulfilled' && market.value.sma50 != null && market.value.sma200 != null) {
    document.getElementById(ids.sma50).value = fmt2(market.value.sma50);
    document.getElementById(ids.sma200).value = fmt2(market.value.sma200);
  } else notes.push('SMA50/200 indisponibles (Golden Cross non évaluable)');
  // Fondamentaux (5/9/2026, T4/T5 ; répliqué dans Screener le 6/9/2026 —
  // même standard "Ticker" dans les deux onglets, voir js/ticker-section.js).
  if (market.status === 'fulfilled') {
    renderFundamentalsFor(instanceKey, market.value);
    if (market.value.fundamentalsError) notes.push('fondamentaux indisponibles');
  } else {
    renderFundamentalsFor(instanceKey, null);
    notes.push('fondamentaux indisponibles');
  }
  // Marqué AVANT calcSelectionFor : c'est lui qui efface les valeurs si le
  // symbole saisi n'est plus celui de la récupération.
  selectionFetchedFor[instanceKey] = ticker;
  calcSelectionFor(instanceKey);
  // Fiche et Labo suivent leur propre événement de télémétrie (fetchLiveFiche,
  // loadLaboTicker) : pas de doublon ici.
  const tab = { sec: 'secteurs', scr: 'screener' }[instanceKey];
  if (tab) trackTickerSelected(tab, ticker, instanceKey);
  // Note de la carte FCF (si applicable) — attendue ici plutôt que
  // fire-and-forget, sinon un échec du chargement FCF restait invisible pour
  // les instances sec/scr (28/9/2026 ; corrige aussi le bug qui laissait
  // loadLaboTicker() attendre une variable `fcfPromise` jamais déclarée dans
  // sa propre portée).
  const fcfNote = await fcfLoad;
  if (fcfNote) notes.push(fcfNote);
  if (!quiet) status.textContent = notes.length ? ('Récupéré partiellement — ' + notes.join(', ') + '.') : 'Récupéré avec succès.';
  return notes;
}
// Peuple la grille "Fondamentaux" de la carte Ticker fusionnée, pour
// l'instance donnée (sec/scr — même standard depuis le 6/9/2026) — `m` est
// la réponse de /api/market-data/:ticker, ou `null` si l'appel a échoué
// (réinitialise tout à "—").
function renderFundamentalsFor(instanceKey, m) {
  const p = instanceKey;
  document.getElementById(`${p}-m-obv`).innerHTML = obvBadge(m?.obvTrend);
  document.getElementById(`${p}-m-volume`).textContent = fmtVolume(m?.volume);
  document.getElementById(`${p}-m-volume-avg`).textContent = fmtVolume(m?.volumeAvg100 != null ? Math.round(m.volumeAvg100) : null);
  document.getElementById(`${p}-m-float`).textContent = fmtFloat(m?.floatShares);
  document.getElementById(`${p}-m-pe`).textContent = m?.peRatio != null ? m.peRatio.toFixed(1) : '—';
  const indEl = document.getElementById(`${p}-m-industry`);
  indEl.textContent = m?.industry || '—';
  indEl.title = m?.industry ? `Industrie (Yahoo Finance) : ${m.industry}` : 'Industrie (Yahoo Finance)';
  // Repli explicite sur le P/E du secteur GICS large (sectorPE) quand aucun
  // pair de la même industrie fine n'est suivi (industryPeerCount === 0) —
  // jamais silencieux : le sous-texte dit TOUJOURS lequel des deux chiffres
  // est affiché, pour ne jamais laisser croire à un vrai pair de l'industrie
  // (28/9/2026, confusion réelle de JP sur GE/« Aerospace & Defense »).
  const peEl = document.getElementById(`${p}-m-industry-pe`);
  const peSub = document.getElementById(`${p}-m-industry-pe-sub`);
  if (m?.industryPeerCount) {
    peEl.textContent = m.industryPE != null ? m.industryPE.toFixed(1) : '—';
    peSub.textContent = `${m.industryPeerCount} pair(s) « ${m.industry} »`;
  } else if (m?.sectorPE != null) {
    peEl.textContent = m.sectorPE.toFixed(1);
    peSub.textContent = `P/E secteur (${m.sectorLabel}), pas industrie`;
  } else {
    peEl.textContent = '—';
    peSub.textContent = m?.industry ? 'aucun pair suivi, secteur pas encore chargé' : '';
  }
  const psEl = document.getElementById(`${p}-m-ps`);
  if (psEl) {
    psEl.textContent = m?.priceToSales != null ? m.priceToSales.toFixed(2) : '—';
    psEl.style.color = psInGoodBand(m?.priceToSales) ? 'var(--green)' : '';
    psEl.title = psSectorText(m);
  }
  document.getElementById(`${p}-m-peg`).textContent = m?.pegRatio != null ? m.pegRatio.toFixed(2) : '—';
  document.getElementById(`${p}-m-beta`).textContent = m?.beta != null ? m.beta.toFixed(2) : '—';
  const vwapEl = document.getElementById(`${p}-m-vwap`);
  if (m?.vwap == null) {
    vwapEl.textContent = '—';
    vwapEl.className = 'ds-metric__value';
  } else {
    vwapEl.textContent = '$' + m.vwap.toFixed(2);
    vwapEl.className = 'ds-metric__value ' + (m.aboveVwap ? 'ok' : 'bad');
  }
  renderTrendFor(instanceKey, m);
}
async function fetchLiveFiche() {
  const ticker = document.getElementById('ticker').value.toUpperCase();
  const status = document.getElementById('fic-live-status');
  if (!ticker) { status.textContent = "Entre un symbole d'abord."; return; }
  status.textContent = 'Récupération en cours…';
  // Un seul /api/market-data, partagé avec la section « Symbole » (bannière,
  // Force relative, Golden Cross, fondamentaux) — voir fetchLiveSelectionFor.
  const marketPromise = fetchJSON(`/api/market-data/${ticker}`);
  const selection = fetchLiveSelectionFor('fic', { marketPromise, quiet: true });
  // 'fic' n'est pas dans FCF_INSTANCES (voir js/fcf-card.js) : fetchLiveSelectionFor
  // ne charge donc pas la carte FCF elle-même, il faut le faire ici. marketPromise
  // fournit le prix courant (rendement du FCF, 28/9/2026) sans appel réseau de plus.
  const fcfPromise = loadFcfCard(ticker, 'fic-fcf-card', marketPromise); // no-op tant que fundamentals_card est OFF
  try {
    const data = await marketPromise;
    // Conservé pour les verdicts de la checklist : l'alignement des moyennes
    // et le volume vs moyenne 20j n'ont pas de champ de saisie, ils ne
    // peuvent venir que d'ici.
    ficheMarketData = data;
    const notes = [];
    // VIX n'est plus rempli depuis /api/market-data/:ticker — il vient de la
    // pastille globale du header (currentVix, loadHeaderIndices()), commune
    // à tous les onglets, plus jamais par titre.
    if (data.rsi != null) document.getElementById('rsi').value = Number(data.rsi).toFixed(2); else notes.push('RSI indisponible');
    if (data.obvTrend != null) document.getElementById('obv').value = data.obvTrend; else notes.push('OBV indisponible');
    if (data.atr != null) document.getElementById('atr').value = data.atr.toFixed(2); else notes.push('ATR indisponible');
    // Prix d'entrée : la CLÔTURE de la dernière séance précédant aujourd'hui,
    // avec sa date — jamais le prix en cours de séance. La note redit d'où vient
    // le chiffre ; une saisie ultérieure à la main le désarme (entryManualEdit).
    if (data.previousClose != null) {
      document.getElementById('entry').value = data.previousClose.toFixed(2);
      entryAutoFilled = { ticker };
      setEntryNote(`Clôture de la veille${data.previousCloseDate ? ' (' + fmtDateFr(data.previousCloseDate) + ')' : ''} — dernier cours final connu de ${ticker}, pas le prix actuel. Remplace-la par ton prix d'entrée prévu.`);
    } else {
      notes.push('clôture de la veille indisponible');
      setEntryNote("Clôture de la veille indisponible — saisis ton prix d'entrée.");
    }
    calcFiche();

    const hintParts = [];
    if (data.smaAlignment != null) {
      const labels = { haussier: 'haussier ✓', baissier: 'baissier ✗', neutre: 'non aligné' };
      hintParts.push(`Alignement SMA : ${labels[data.smaAlignment] || data.smaAlignment}`);
    } else {
      notes.push('SMA indisponible');
    }
    if (data.volumeRatio != null) {
      const pct = (data.volumeRatio * 100).toFixed(0);
      hintParts.push(`Volume vs moyenne 20j : ${pct}% (${data.volumeRatio >= 1 ? 'au-dessus' : 'en-dessous'})`);
    } else {
      notes.push('volume vs moyenne 20j indisponible');
    }
    const hint = document.getElementById('sma-live-hint');
    hint.textContent = hintParts.length
      ? `${hintParts.join(' · ')} (${ticker}) — coche la checklist toi-même si tu confirmes.`
      : 'SMA et volume indisponibles (calcul maison, Yahoo Finance).';

    notes.push(...((await selection) || []));
    status.textContent = notes.length ? ('Récupéré partiellement — ' + notes.join(', ') + '.') : 'Récupéré avec succès.';
    trackTickerSelected('fiche', ticker, null);
    loadCorrelationFor(ticker); // #397 : corrélation réelle avec les positions ouvertes (asynchrone)
  } catch (err) {
    await selection;
    status.textContent = 'Erreur : ' + err.message;
  }
}
