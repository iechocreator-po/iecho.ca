// IA étape 2 (#399), phase 1 : jeu de données d'entraînement tiré du backtest.
//
// Une ligne = un trade simulé du signal d'alignement, avec les variables CONNUES À LA CLÔTURE
// DE LA BARRE DU SIGNAL (l'entrée a lieu à l'ouverture suivante) et le résultat réalisé en R.
// ⚠️ Aucun regard vers l'avenir : chaque variable n'utilise que bars[0..signalIndex]. C'est la
// seule propriété qui compte ici — un modèle entraîné sur une variable « fuyante » paraît
// brillant en test et ne vaut rien en réel. Le test dataset.test.js le vérifie en tronquant
// l'historique après le signal : les variables ne doivent pas changer.
//
// Fonctions PURES (aucun réseau, aucune base). L'orchestration vit dans scripts/build-dataset.mjs.

import { computeSMA, computeRSI, computeATR, computeOBV, computeVolumeVs20d, computeHistoricalVolatility } from './indicators.js';
import { obvTrendFrom } from './obv-trend.js';

export const FEATURE_COLUMNS = [
  'rsi', 'atr_pct', 'gap_slow_pct', 'spread_fast_slow_pct', 'ret20_pct', 'rel_strength_60_pct',
  'vol_ratio_20', 'obv_trend', 'hv60_pct', 'golden_cross', 'spy_above_sma200', 'vix',
];
export const LABEL_COLUMNS = ['r_net', 'r_gross', 'win_1r', 'bars_held', 'exit_reason'];
export const ROW_COLUMNS = ['ticker', 'sector', 'signal_date', 'entry_date', 'exit_date', ...FEATURE_COLUMNS, ...LABEL_COLUMNS];

const dayKey = (d) => (d instanceof Date ? d.toISOString() : String(d)).slice(0, 10);
const round = (v, n = 4) => (v == null || !Number.isFinite(v) ? null : Math.round(v * 10 ** n) / 10 ** n);

/** Rendement en % sur `n` séances jusqu'à l'indice i (null si historique trop court). */
function retPct(closes, i, n) {
  if (i - n < 0 || !(closes[i - n] > 0)) return null;
  return (closes[i] / closes[i - n] - 1) * 100;
}

/** Tendance OBV sur 10 séances vs prix — même définition que l'application (server/obv-trend.js). */
function obvTrendAt(bars, i, n = 10) {
  if (i - n < 0) return null;
  const obv = computeOBV(bars.slice(0, i + 1));
  return obvTrendFrom(bars[i].close - bars[i - n].close, obv[i] - obv[i - n]);
}

/**
 * Variables à la barre du signal `i`, calculées SUR bars[0..i] seulement.
 * @param spy    barres SPY (pour la force relative et le régime), peut être []
 * @param vixMap Map 'YYYY-MM-DD' → clôture du VIX, peut être vide
 */
export function featuresAt(bars, i, { spy = [], vixMap = new Map() } = {}) {
  const past = bars.slice(0, i + 1);
  const closes = past.map((b) => b.close);
  const close = closes[i];
  const sma = (p) => computeSMA(closes, p)[i];
  const fast = sma(9), slow = sma(50), sma200 = sma(200);
  const atr = computeATR(past, 14)[i];
  const vol = computeVolumeVs20d(past);

  // Force relative : rendement 60 séances du titre − celui de SPY à la MÊME date (alignement par date).
  let rel = null;
  const r60 = retPct(closes, i, 60);
  if (r60 != null && spy.length) {
    const key = dayKey(bars[i].date);
    const j = spy.findIndex((b) => dayKey(b.date) === key);
    if (j >= 60) {
      const spyRet = (spy[j].close / spy[j - 60].close - 1) * 100;
      if (Number.isFinite(spyRet)) rel = r60 - spyRet;
    }
  }
  let spyAbove = null;
  if (spy.length) {
    const key = dayKey(bars[i].date);
    const j = spy.findIndex((b) => dayKey(b.date) === key);
    if (j >= 0) {
      const sc = spy.slice(0, j + 1).map((b) => b.close);
      const s200 = computeSMA(sc, 200)[j];
      spyAbove = s200 != null ? (sc[j] > s200 ? 1 : 0) : null;
    }
  }
  const vix = vixMap.get(dayKey(bars[i].date));

  return {
    rsi: round(computeRSI(closes, 14), 2),
    atr_pct: atr != null && close > 0 ? round(atr / close * 100, 3) : null,
    gap_slow_pct: slow != null && slow > 0 ? round((close / slow - 1) * 100, 3) : null,
    spread_fast_slow_pct: fast != null && slow != null && slow > 0 ? round((fast / slow - 1) * 100, 3) : null,
    ret20_pct: round(retPct(closes, i, 20), 3),
    rel_strength_60_pct: round(rel, 3),
    vol_ratio_20: round(vol.ratio, 3),
    obv_trend: obvTrendAt(past, i),
    hv60_pct: (() => { const h = computeHistoricalVolatility(closes, 60); return h == null ? null : round(h * 100, 2); })(),
    golden_cross: slow != null && sma200 != null ? (slow > sma200 ? 1 : 0) : null,
    spy_above_sma200: spyAbove,
    vix: vix != null ? round(vix, 2) : null,
  };
}

/**
 * Lignes du jeu de données pour UN titre. `costed` et `gross` sont les trades des deux lectures du
 * MÊME signal (avec et sans frais) : ils sortent des mêmes barres dans le même ordre, donc on les
 * apparie par date d'entrée.
 */
export const WARMUP_BARS = 250; // la SMA 200 et la force relative 60 j exigent de l'historique avant le signal

export function buildRows(ticker, sector, bars, { costed, gross }, ctx = {}, { warmup = WARMUP_BARS } = {}) {
  const grossByEntry = new Map(gross.map((t) => [t.entryDate, t]));
  const rows = [];
  for (const t of costed) {
    if (t.signalIndex == null || t.signalIndex < warmup) continue; // variables incomplètes = ligne écartée, pas devinée
    const g = grossByEntry.get(t.entryDate);
    rows.push({
      ticker, sector,
      signal_date: dayKey(bars[t.signalIndex].date),
      entry_date: dayKey(t.entryDate),
      exit_date: dayKey(t.exitDate), // date où le résultat devient CONNU : sert à purger l'entraînement
      ...featuresAt(bars, t.signalIndex, ctx),
      r_net: round(t.r, 4),
      r_gross: g ? round(g.r, 4) : null,
      win_1r: t.r > 1 ? 1 : 0,
      bars_held: t.bars,
      exit_reason: t.reason,
    });
  }
  return rows;
}

const csvCell = (v) => {
  if (v == null) return '';
  const s = String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

/** CSV : cellule VIDE pour une valeur absente (jamais 0). */
export function rowsToCsv(rows) {
  return [ROW_COLUMNS.join(','), ...rows.map((r) => ROW_COLUMNS.map((c) => csvCell(r[c])).join(','))].join('\n') + '\n';
}

/** Découpe chronologique (walk-forward) : entraînement = signaux AVANT `cutoff` (YYYY-MM-DD), test = à partir de. */
export function splitByDate(rows, cutoff) {
  return { train: rows.filter((r) => r.signal_date < cutoff), test: rows.filter((r) => r.signal_date >= cutoff) };
}
