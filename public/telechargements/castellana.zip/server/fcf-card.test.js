// Score fondamental pondéré (2/10/2026) — fonctions pures de js/fcf-card.js, évaluées comme le navigateur.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const ctx = vm.createContext({});
vm.runInContext(fs.readFileSync(new URL('../js/fcf-card.js', import.meta.url), 'utf8') + '\nthis.fcfWeightedScore = fcfWeightedScore; this.fcfPsFraction = fcfPsFraction; this.fcfTileBands = fcfTileBands;', ctx);
const { fcfWeightedScore, fcfPsFraction, fcfTileBands } = ctx;

const BAREME = [{ lt: 1, frac: 0.75 }, { lte: 2, frac: 1 }, { lte: 5, frac: 0.75 }, { lte: 10, frac: 0.4 }, { frac: 0 }];
const VERDICTS = { solide: 75, mitige: 50 };
const q = (g, c, v, d) => ({ max: 25, sub: { growth: { score: g }, consistency: { score: c }, conversion: { score: v }, dilution: { score: d } } });
const W20 = { growth: 20, consistency: 20, conversion: 20, dilution: 20, valuation: 20 };

test('barème P/S : bornes 1 et 2 incluses dans « très bien »', () => {
  assert.equal(fcfPsFraction(0.5, BAREME), 0.75);
  assert.equal(fcfPsFraction(1, BAREME), 1);
  assert.equal(fcfPsFraction(2, BAREME), 1);
  assert.equal(fcfPsFraction(2.01, BAREME), 0.75);
  assert.equal(fcfPsFraction(7, BAREME), 0.4);
  assert.equal(fcfPsFraction(74, BAREME), 0);
  assert.equal(fcfPsFraction(null, BAREME), null);
  assert.equal(fcfPsFraction(0, BAREME), null);
});

test('poids égaux, tout au maximum → 100 ; un P/S à 74 retire 20 points', () => {
  assert.equal(fcfWeightedScore(q(25, 25, 25, 25), 1.5, W20, BAREME, VERDICTS).score, 100);
  assert.equal(fcfWeightedScore(q(25, 25, 25, 25), 74, W20, BAREME, VERDICTS).score, 80);
});

test('P/S à 0 % : retrouve exactement le score des 4 critères (25 % chacun)', () => {
  const w = { growth: 25, consistency: 25, conversion: 25, dilution: 25, valuation: 0 };
  const r = fcfWeightedScore(q(25, 25, 25, 18), 74, w, BAREME, VERDICTS);
  assert.equal(r.score, Math.round(((25 + 25 + 25 + 18) / 100) * 100)); // 93
  assert.equal(r.verdict, 'solide');
});

test('critère sans donnée : exclu et le reste ramené à 100 %, jamais compté comme un zéro', () => {
  const r = fcfWeightedScore(q(25, 25, null, 25), 1.5, W20, BAREME, VERDICTS);
  assert.equal(r.score, 100);
  assert.equal(r.partial, true);
  const sansPs = fcfWeightedScore(q(25, 25, 25, 25), null, W20, BAREME, VERDICTS);
  assert.equal(sansPs.score, 100);
  assert.equal(sansPs.partial, true);
});

test('un poids plus lourd pèse plus, et les seuils de verdict suivent', () => {
  const w = { growth: 70, consistency: 10, conversion: 10, dilution: 10, valuation: 0 };
  const r = fcfWeightedScore(q(0, 25, 25, 25), 1.5, w, BAREME, VERDICTS);
  assert.equal(r.score, 30);
  assert.equal(r.verdict, 'fragile');
});

test('tous les poids exclus → pas de score', () => {
  const r = fcfWeightedScore(q(25, 25, 25, 25), 1.5, { growth: 0, consistency: 0, conversion: 0, dilution: 0, valuation: 0 }, BAREME, VERDICTS);
  assert.equal(r.score, null);
  assert.equal(r.verdict, null);
});

// ---- Couleurs des quatre tuiles (2/10/2026) ----
const B = { fcfMargeVert: 10, fcfParActionHausseVert: 5, fcfParActionBaisseRouge: -5, rendementVert: 5, rendementRouge: 2 };
const d = (ttm, last) => ({ ttm: { revenue: 1000, ...ttm }, years: last ? [last] : [] });

test('tuile EPS : perte → rouge ; hausse → vert ; baisse → jaune ; sans comparaison → non évalué', () => {
  assert.equal(fcfTileBands(d({ eps: -1 }), null, B).eps, 'rouge');
  assert.equal(fcfTileBands(d({ eps: 4 }, { eps: 3 }), null, B).eps, 'vert');
  assert.equal(fcfTileBands(d({ eps: 2 }, { eps: 3 }), null, B).eps, 'amber');
  assert.equal(fcfTileBands(d({ eps: 4 }, { eps: -1 }), null, B).eps, 'vert');
  assert.equal(fcfTileBands(d({ eps: 4 }), null, B).eps, null);
});

test('tuile FCF : marge ≥ 10 % vert, 0–10 % jaune, négatif rouge', () => {
  assert.equal(fcfTileBands(d({ fcf: 100 }), null, B).fcf, 'vert');
  assert.equal(fcfTileBands(d({ fcf: 99 }), null, B).fcf, 'amber');
  assert.equal(fcfTileBands(d({ fcf: 0 }), null, B).fcf, 'amber');
  assert.equal(fcfTileBands(d({ fcf: -5 }), null, B).fcf, 'rouge');
  assert.equal(fcfTileBands({ ttm: { fcf: 50 }, years: [] }, null, B).fcf, null, 'sans revenus : non évalué');
});

test('tuile FCF par action : +5 % vert, entre −5 et +5 jaune, plus bas ou ≤ 0 rouge', () => {
  const last = { fcfPerShare: 4 };
  assert.equal(fcfTileBands(d({ fcfPerShare: 4.2 }, last), null, B).fcfPerShare, 'vert');
  assert.equal(fcfTileBands(d({ fcfPerShare: 4.1 }, last), null, B).fcfPerShare, 'amber');
  assert.equal(fcfTileBands(d({ fcfPerShare: 3.9 }, last), null, B).fcfPerShare, 'amber');
  assert.equal(fcfTileBands(d({ fcfPerShare: 3.7 }, last), null, B).fcfPerShare, 'rouge');
  assert.equal(fcfTileBands(d({ fcfPerShare: -1 }, last), null, B).fcfPerShare, 'rouge');
  assert.equal(fcfTileBands(d({ fcfPerShare: 1 }, { fcfPerShare: -2 }), null, B).fcfPerShare, 'vert');
});

test('tuile rendement du FCF : ≥ 5 % vert, 2–5 % jaune, < 2 % rouge, sans prix non évalué', () => {
  assert.equal(fcfTileBands(d({ fcfPerShare: 5 }), 100, B).yield, 'vert');
  assert.equal(fcfTileBands(d({ fcfPerShare: 3 }), 100, B).yield, 'amber');
  assert.equal(fcfTileBands(d({ fcfPerShare: 1 }), 100, B).yield, 'rouge');
  assert.equal(fcfTileBands(d({ fcfPerShare: 5 }), null, B).yield, null);
});

// ---- Solidité du bilan : trésorerie ÷ dette (11/10/2026) -------------------
vm.runInContext('this.fcfCashFraction = fcfCashFraction;', ctx);
const CASH_BAREME = [{ gte: 1, frac: 1 }, { gte: 0.5, frac: 0.75 }, { gte: 0.25, frac: 0.4 }, { frac: 0 }];

test('barème trésorerie : dette nulle = 100 %, bornes incluses, inconnu = null', () => {
  const f = (cash, debt) => ctx.fcfCashFraction({ cash, debt }, CASH_BAREME);
  assert.equal(f(10, 0), 1);
  assert.equal(f(10, 10), 1);
  assert.equal(f(5, 10), 0.75);
  assert.equal(f(2.5, 10), 0.4);
  assert.equal(f(1, 10), 0);
  assert.equal(f(null, 10), null); // Yahoo ne donne pas la trésorerie
  assert.equal(f(10, null), null); // dette absente ≠ dette nulle
  assert.equal(ctx.fcfCashFraction(null, CASH_BAREME), null);
});

test('le bilan à 0 % laisse le score inchangé ; à 20 % il le tire', () => {
  const w0 = { ...W20, balance: 0 };
  const sans = fcfWeightedScore(q(25, 25, 25, 25), 1.5, w0, BAREME, VERDICTS, { cash: 1, debt: 100 }, CASH_BAREME);
  assert.equal(sans.score, 100);
  const w = { growth: 20, consistency: 20, conversion: 20, dilution: 10, valuation: 10, balance: 20 };
  const avec = fcfWeightedScore(q(25, 25, 25, 25), 1.5, w, BAREME, VERDICTS, { cash: 1, debt: 100 }, CASH_BAREME);
  assert.equal(avec.score, 80); // le bilan (fraction 0) retire ses 20 points
});

test('bilan inconnu : critère exclu, reste ramené à 100 %, jamais un zéro', () => {
  const w = { growth: 20, consistency: 20, conversion: 20, dilution: 20, valuation: 0, balance: 20 };
  const r = fcfWeightedScore(q(25, 25, 25, 25), null, w, BAREME, VERDICTS, { cash: null, debt: null }, CASH_BAREME);
  assert.equal(r.score, 100);
  assert.equal(r.partial, true);
});

test('tuile trésorerie : vert / jaune / rouge selon cash ÷ dette', () => {
  const b = { fcfMargeVert: 10, fcfParActionHausseVert: 5, fcfParActionBaisseRouge: -5, rendementVert: 5, rendementRouge: 2, tresorerieVert: 1, tresorerieRouge: 0.25 };
  const band = (cash, debt) => fcfTileBands({ ttm: {}, years: [], balance: { cash, debt } }, null, b).cash;
  assert.equal(band(10, 0), 'vert');
  assert.equal(band(10, 10), 'vert');
  assert.equal(band(5, 10), 'amber');
  assert.equal(band(1, 10), 'rouge');
  assert.equal(band(null, 10), null);
});
