// launcher/server.js — outil de secours pour castellana (5/9/2026, demande
// de JP après plusieurs relances manuelles via Claude Code).
//
// Principe directeur : cet outil doit rester lui-même TRÈS simple et
// stable, pour être disponible précisément au moment où castellana (le
// vrai produit) ne l'est plus. D'où : zéro dépendance npm (node:http natif,
// pas Express — un framework de plus est une source de panne de plus pour
// l'outil censé nous sortir de la panne), aucune logique métier, tourne sur
// son PROPRE port (4750), totalement indépendant du serveur Express de
// castellana (4700) et de son sidecar Python (4701) qu'il supervise.
//
// Sécurité : lié à 127.0.0.1 uniquement (même garde que castellana lui-même,
// voir server/index.js). Les commandes réellement exécutées (chemins,
// arguments) sont TOUJOURS codées en dur ci-dessous — la requête HTTP ne
// choisit qu'une cible parmi 2 valeurs fixes ('node'|'sidecar'), jamais une
// commande ou un chemin arbitraire. Aucune interpolation de shell avec une
// entrée utilisateur.

import http from 'node:http';
import { execSync, spawn } from 'node:child_process';
import net from 'node:net';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const APP_DIR = path.resolve(__dirname, '..'); // trading-assistant/
const settings = JSON.parse(readFileSync(path.join(APP_DIR, 'settings.json'), 'utf8'));

// Cibles fixes — ports lus depuis le vrai settings.json de castellana pour
// ne jamais diverger si ces ports changent un jour, mais les COMMANDES
// elles-mêmes (fichier à exécuter) restent en dur, jamais dérivées d'une
// entrée externe.
const TARGETS = {
  node: {
    label: 'Serveur Node (castellana)',
    port: settings.port,
    command: 'node',
    args: ['server/index.js'],
  },
  sidecar: {
    label: 'Sidecar Python (tradingview-mcp)',
    port: settings.tradingviewMcp.port,
    command: 'node',
    args: ['scripts/run-sidecar.mjs'],
  },
};

function checkPort(port, timeoutMs = 800) {
  return new Promise((resolve) => {
    const socket = net.createConnection({ host: '127.0.0.1', port, timeout: timeoutMs });
    const done = (ok) => { socket.destroy(); resolve(ok); };
    socket.once('connect', () => done(true));
    socket.once('error', () => done(false));
    socket.once('timeout', () => done(false));
  });
}

// Tue tout process écoutant sur `port` via lsof (utilitaire système, pas de
// dépendance npm) — `port` est toujours l'un des deux entiers fixes de
// TARGETS ci-dessus, jamais une valeur venant de la requête HTTP.
//
// PIÈGE RÉEL TROUVÉ EN TESTANT (5/9/2026) : `lsof -ti:PORT` SANS
// `-sTCP:LISTEN` matche aussi les connexions CLIENTES vers ce port, pas
// seulement le process qui l'écoute en serveur. Le serveur castellana
// (server/tradingview.js) ouvre une connexion cliente sortante vers le
// sidecar sur 4701 — sans ce filtre, "relancer le sidecar" tuait AUSSI le
// serveur Node lui-même (repéré en testant : le PID du serveur Node
// venait de réapparaître dans les PID "arrêtés" d'une relance du sidecar
// seul). `-sTCP:LISTEN` restreint à la vraie socket serveur.
function killPort(port) {
  try {
    const out = execSync(`lsof -ti:${port} -sTCP:LISTEN`, { encoding: 'utf8' }).trim();
    const pids = out ? out.split('\n').filter(Boolean) : [];
    for (const pid of pids) {
      try { process.kill(Number(pid), 'SIGTERM'); } catch { /* déjà mort */ }
    }
    return pids;
  } catch {
    return []; // rien n'écoutait sur ce port (lsof sort en erreur si vide)
  }
}

function startTarget(target) {
  const child = spawn(target.command, target.args, {
    cwd: APP_DIR,
    detached: true,
    stdio: 'ignore',
  });
  child.unref(); // survit indépendamment de ce process superviseur
  return child.pid;
}

async function restartTarget(key) {
  const target = TARGETS[key];
  const killedPids = killPort(target.port);
  await new Promise((r) => setTimeout(r, 500)); // laisse le port se libérer
  const newPid = startTarget(target);
  // Attend jusqu'à ~8s que le port réponde, pour renvoyer un vrai statut
  // plutôt qu'un "c'est parti" optimiste.
  let up = false;
  for (let i = 0; i < 16; i++) {
    await new Promise((r) => setTimeout(r, 500));
    if (await checkPort(target.port)) { up = true; break; }
  }
  return { key, label: target.label, killedPids, newPid, up };
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');

  if (req.method === 'GET' && url.pathname === '/api/status') {
    const [nodeUp, sidecarUp] = await Promise.all([
      checkPort(TARGETS.node.port),
      checkPort(TARGETS.sidecar.port),
    ]);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ node: nodeUp, sidecar: sidecarUp, nodePort: TARGETS.node.port, sidecarPort: TARGETS.sidecar.port }));
    return;
  }

  if (req.method === 'POST' && url.pathname === '/api/restart') {
    let body = '';
    for await (const chunk of req) body += chunk;
    let target = null;
    try { target = JSON.parse(body || '{}').target; } catch { /* laisse target=null, rejeté ci-dessous */ }
    const keys = target === 'both' ? ['node', 'sidecar'] : [target];
    if (!keys.every((k) => TARGETS[k])) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: `cible invalide : ${JSON.stringify(target)} (attendu : "node" | "sidecar" | "both")` }));
      return;
    }
    const results = [];
    for (const k of keys) results.push(await restartTarget(k));
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ results }));
    return;
  }

  if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(readFileSync(path.join(__dirname, 'public', 'index.html')));
    return;
  }

  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('Not found');
});

const PORT = 4750;
const HOST = '127.0.0.1'; // jamais exposé au-delà de la machine locale
server.listen(PORT, HOST, () => {
  console.log(`castellana-launcher — http://${HOST}:${PORT}`);
});
