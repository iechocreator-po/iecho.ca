// js/app-secteurs.js — Performance des secteurs et titres les plus performants
// Extrait de l'ancien script en ligne des index.html (découpage phase 2, 20/10/2026) : code déplacé tel quel, sans réécriture.
// Fichier COMMUN aux versions locale et cloud : source ici ; cloud/public/js/app-secteurs.js en est la copie (npm run sync:cloud).
// Script classique : ses noms de premier niveau sont globaux et partagés avec les autres scripts de la page.

// ---- Performance des secteurs (écran de sélection) ----
function pctCell(pct) {
  if (pct == null) return '<td class="is-num">—</td>';
  const color = pct > 0 ? 'var(--green)' : pct < 0 ? 'var(--red)' : 'var(--text-2)';
  const sign = pct > 0 ? '+' : '';
  return `<td class="is-num"><span style="color:${color}">${sign}${pct.toFixed(2)} %</span></td>`;
}
let sectorCurrencyMode = 'usd';
function setSectorCurrency(mode) {
  sectorCurrencyMode = mode;
  document.querySelectorAll('.currency-btn').forEach((b) => b.classList.toggle('is-active', b.dataset.currency === mode));
  loadSectors();
  loadSectorHistory();
}
async function loadSectors() {
  const btn = document.getElementById('btn-sectors');
  const status = document.getElementById('sectors-status');
  const tbody = document.getElementById('sectors-tbody');
  btn.disabled = true;
  status.textContent = 'Chargement…';
  try {
    const data = await fetchJSON(`/api/sectors?mode=${sectorCurrencyMode}`);
    const rows = [...data.sectors].sort((a, b) => (b.changePercent ?? -Infinity) - (a.changePercent ?? -Infinity));
    tbody.innerHTML = rows.map((s) => `
      <tr data-sector-key="${s.key}" onclick="selectSectorForTop('${s.key}', '${s.label}')">
        <td>${s.ticker}</td><td>${s.label}</td>
        ${pctCell(s.changePercent)}
        ${pctCell(s.weekChangePercent)}
        ${pctCell(s.monthChangePercent)}
        <td class="is-num">${s.peRatio != null ? s.peRatio.toFixed(1) : '—'}</td>
        <td class="is-num"${s.pegPeerCount ? ` title="Moyenne sur ${s.pegPeerCount} titre(s) de la watchlist"` : ''}>${s.pegAvg != null ? s.pegAvg.toFixed(2) : '—'}</td>
      </tr>`).join('') + `
      <tr class="sector-row-benchmark" style="font-weight:600; border-top:2px solid var(--border);">
        <td>${data.benchmark.ticker}</td><td>${data.benchmark.label}</td>
        ${pctCell(data.benchmark.changePercent)}
        ${pctCell(data.benchmark.weekChangePercent)}
        ${pctCell(data.benchmark.monthChangePercent)}
        <td class="is-num">${data.benchmark.peRatio != null ? data.benchmark.peRatio.toFixed(1) : '—'}</td>
        <td class="is-num">—</td>
      </tr>` + (data.equalWeight ? `
      <tr class="sector-row-benchmark" style="font-weight:600;">
        <td>${data.equalWeight.ticker}</td><td>${data.equalWeight.label}</td>
        ${pctCell(data.equalWeight.changePercent)}
        ${pctCell(data.equalWeight.weekChangePercent)}
        ${pctCell(data.equalWeight.monthChangePercent)}
        <td class="is-num">${data.equalWeight.peRatio != null ? data.equalWeight.peRatio.toFixed(1) : '—'}</td>
        <td class="is-num">—</td>
      </tr>` : '');
    const heure = new Date(data.generatedAt).toLocaleTimeString('fr-CA');
    const errCount = data.sectors.filter((s) => s.error).length;
    status.textContent = `Mis à jour à ${heure}` + (errCount ? ` — ${errCount} secteur(s) sans donnée.` : '.');
  } catch (err) {
    status.textContent = 'Erreur : ' + err.message;
  } finally {
    btn.disabled = false;
  }
}
// ---- Titres les plus performants du secteur (2/9/2026) — liste curatée
// par secteur (server/sectors.js), pas un scan de marché en direct. Voir
// CLAUDE.md pour l'historique (l'endpoint screener personnalisé de Yahoo
// s'est révélé bloqué pour un usage anonyme). ----
let currentTopSector = null; // { key, label }
let sectorTopMode = 'raw';
// Lignes du dernier tableau sectoriel — même rôle que `lastScreeningRows`
// pour le Screener : le bouton « Préparer » y retrouve le raisonnement du
// titre cliqué (scores, alignement, âge du signal) pour le joindre au trade.
let lastSectorTopRows = [];
// Un clic : tous les titres « prêt » du dernier balayage S&P 500 (A3) descendent dans le tableau de A4,
// avec les mêmes colonnes que le screening. Même source que le bouton « S&P 500 » de B2.
async function sendReadyToTop() {
  const st = document.getElementById('sector-ready-status');
  if (st) st.textContent = 'Chargement…';
  try {
    const d = await fetchJSON('/api/screening?universe=sp500');
    let rows = (d.rows || []).filter((r) => r.verdict === 'prêt');
    if (!rows.length) { if (st) st.textContent = 'Aucun titre « prêt » dans ce balayage.'; return; }
    // Colonnes complètes (fondamentaux, volume, P/E…) : on recalcule les lignes avec le pipeline du screening,
    // par lots de 20 (limite de 40 par appel, et plafond de sous-requêtes en cloud) ; un lot en échec garde ses lignes compactes.
    let note = '';
    const byT = new Map();
    let echecs = 0;
    for (let i = 0; i < rows.length; i += 20) {
      try {
        const full = await fetchJSON('/api/screening/tickers?tickers=' + rows.slice(i, i + 20).map((r) => encodeURIComponent(r.ticker)).join(','));
        full.rows.forEach((r) => byT.set(r.ticker, r));
      } catch (e) { echecs++; note = ' — colonnes incomplètes pour un lot : ' + e.message; }
      if (st) st.textContent = `Chargement… ${Math.min(i + 20, rows.length)}/${rows.length}`;
    }
    rows = rows.map((r) => ({ ...r, ...(byT.get(r.ticker) || {}) }));
    if (echecs) note += ` (${echecs} lot(s) en échec)`;
    currentTopSector = null; // empêche un rechargement par secteur d'écraser la liste
    lastSectorTopRows = rows;
    document.getElementById('sector-top-title').textContent = `Titres « prêt » du S&P 500 (${rows.length})`;
    document.getElementById('sector-top-empty').style.display = 'none';
    document.getElementById('sector-top-toolbar').style.display = 'none';
    document.getElementById('sector-top-table-wrap').style.display = 'block';
    renderSectorTopRows();
    document.getElementById('sector-top-status').textContent = `${rows.length} titre(s) « prêt » du dernier balayage S&P 500` + note;
    if (st) st.textContent = `${rows.length} titre(s) envoyé(s) vers A4.`;
    document.getElementById('sector-top-title').scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (err) {
    if (st) st.textContent = err.code === 'NO_SWEEP' || err.status === 409 ? 'Aucun balayage enregistré.' : 'Indisponible : ' + err.message;
  }
}
// Crée une liste personnalisée (Screener) avec les titres « prêt » du dernier balayage S&P 500 (plafond de 50 par liste).
async function createListFromReady() {
  const st = document.getElementById('sector-ready-status');
  try {
    if (st) st.textContent = 'Chargement…';
    const d = await fetchJSON('/api/screening?universe=sp500');
    const tickers = (d.rows || []).filter((r) => r.verdict === 'prêt').map((r) => r.ticker);
    if (!tickers.length) { if (st) st.textContent = 'Aucun titre « prêt » dans ce balayage.'; return; }
    const defaut = `S&P500 ${new Date().toISOString().slice(0, 10)}`; // le nombre de titres s'ajoute tout seul sur le bouton de la liste
    const nom = (window.prompt(`Nom de la nouvelle liste (${Math.min(tickers.length, 50)} titre(s) « prêt ») :`, defaut) || '').trim();
    if (!nom) { if (st) st.textContent = ''; return; }
    const { list } = await fetchJSON('/api/lists', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ nom }) });
    let added = 0;
    const refuses = [];
    const ajoutes = [];
    for (const ticker of tickers.slice(0, 50)) {
      let ok = false, lastErr = '';
      for (let essai = 0; essai < 2 && !ok; essai++) { // un seul réessai : une erreur passagère ne doit pas faire perdre un titre
        try {
          await fetchJSON(`/api/lists/${list.id}/tickers`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ticker }) });
          ok = true;
        } catch (e) { lastErr = e.message; }
      }
      if (ok) { added++; ajoutes.push(ticker); } else refuses.push(`${ticker} (${lastErr})`);
    }
    await loadCustomLists(); // la liste (et ses titres) est relue du serveur : customLists en mémoire = ce qui est enregistré
    if (typeof trackListChanged === 'function') trackListChanged('create', list);
    // Chargement des données des titres choisis (prix, indicateurs, fondamentaux) : on les passe une fois par le
    // pipeline du screening, par lots de 20 (limite de 40 par appel, et plafond de sous-requêtes en cloud), pour que
    // le Screener ouvre cette liste sans repartir de zéro. Un lot en échec ne retire rien de la liste, il est signalé.
    let charges = 0, lotsEchoues = 0;
    for (let i = 0; i < ajoutes.length; i += 20) {
      if (st) st.textContent = `Liste « ${nom} » créée — chargement des données… ${Math.min(i + 20, ajoutes.length)}/${ajoutes.length}`;
      try {
        const full = await fetchJSON('/api/screening/tickers?tickers=' + ajoutes.slice(i, i + 20).map((t) => encodeURIComponent(t)).join(','));
        charges += (full.rows || []).length;
      } catch { lotsEchoues++; }
    }
    const donnees = lotsEchoues ? ` — données chargées pour ${charges}/${ajoutes.length} titre(s) (${lotsEchoues} lot(s) en échec, elles se rechargeront au lancement du screening)` : ` — données de ${charges} titre(s) chargées`;
    if (st) st.textContent = `Liste « ${nom} » créée avec ${added} titre(s)` + (tickers.length > 50 ? ` (plafond de 50, ${tickers.length - 50} non ajoutés)` : '') + (refuses.length ? ` — ${refuses.length} refusé(s) : ${refuses.join(', ')}` : '') + donnees + ' — visible dans le Screener.';
  } catch (err) {
    if (st) st.textContent = 'Indisponible : ' + err.message;
  }
}
function selectSectorForTop(sectorKey, label) {
  currentTopSector = { key: sectorKey, label };
  document.getElementById('sector-top-title').textContent = `Titres les plus performants — ${label}`;
  document.getElementById('sector-top-empty').style.display = 'none';
  document.getElementById('sector-top-toolbar').style.display = 'flex';
  document.getElementById('sector-top-table-wrap').style.display = 'block';
  loadSectorTop();
}
function setSectorTopMode(mode) {
  sectorTopMode = mode;
  document.querySelectorAll('.top-mode-btn').forEach((b) => b.classList.toggle('is-active', b.dataset.topmode === mode));
  loadSectorTop();
}
// Extrait de loadSectorTop() (T5, 12/9/2026) pour être réutilisé par le tri
// des en-têtes de colonne — sans refetch, sur les données déjà en mémoire.
function renderSectorTopRows() {
  const tbody = document.getElementById('sector-top-tbody');
  tbody.innerHTML = lastSectorTopRows.map((r) => screeningRowHTML(r, {
    onclick: 'selectSectorTopRow',
    pairsLabel: 'suivi(s) de ce secteur',
    leadCell: pctCell(r.changePercent),
  })).join('');
}
async function loadSectorTop() {
  if (!currentTopSector) return;
  const status = document.getElementById('sector-top-status');
  status.textContent = 'Chargement…';
  try {
    const data = await fetchJSON(`/api/sectors/${currentTopSector.key}/top?mode=${sectorTopMode}`);
    lastSectorTopRows = data.rows;
    renderSectorTopRows();
    const notes = [];
    if (data.failedCount) notes.push(`${data.failedCount} indisponible(s)`);
    status.textContent = `${data.rows.length} sur ${data.totalCandidates} titre(s) suivis pour ce secteur`
      + (data.cached ? ' (cache)' : '') + (notes.length ? ' — ' + notes.join(', ') : '');
  } catch (err) {
    document.getElementById('sector-top-tbody').innerHTML = '';
    status.textContent = 'Indisponible : ' + err.message;
  }
}
function selectSectorTopRow(ticker) {
  document.getElementById(SELECTION_INSTANCES.sec.ticker).value = ticker;
  fetchLiveSelectionFor('sec');
  const card = document.getElementById(SELECTION_INSTANCES.sec.tickerCard);
  card.scrollIntoView({ behavior: 'smooth', block: 'center' });
  card.classList.remove('flash-highlight');
  void card.offsetWidth;
  card.classList.add('flash-highlight');
}
