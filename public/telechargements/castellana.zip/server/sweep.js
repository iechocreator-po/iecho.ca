// Méga balayage du S&P 500 (7/10/2026) — LOCAL uniquement.
//
// Deux phases, en tâche de fond (un balayage dure des minutes, bien au-delà d'une
// requête HTTP) :
//  1. « historique » : l'historique quotidien de chacun des ~500 titres est tiré
//     (TradingView local si la source est active, sinon Yahoo) et mis en cache
//     pour 3 h — le cache d'usage normal (15 min) expirerait avant la fin.
//     Reprise naturelle : un titre déjà en cache est sauté, relancer ne refait pas
//     le travail. En mode TradingView, les appels sont « patients » : un 429 met le
//     balayage en pause 60 s au lieu de basculer sur Yahoo.
//  2. « analyse » : le pipeline de screening habituel (Setup/Contexte, filtre
//     avant fondamentaux) sur l'univers 'sp500', à partir de ce cache ; résultat
//     enregistré sous la clé de cache de l'univers, consultable dans le Screener.
// Aucun appel d'écriture chez TradingView ; aucune donnée ne quitte la machine.

import { fetchDailyHistory } from './indicators.js';
import { mapWithConcurrency } from './fetch-retry.js';
import { buildScreening, screeningCacheKey, SP500_TICKERS } from './screening.js';
import { writeCache, readCacheRaw, TTL } from './cache.js';
import { diffSweep, buildSweepDigest } from './sweep-news.js';
import { emailAvailable, sendAlertEmail } from './alert-email.js';
import { getSweepAuto, getAlertEmails, getPublishCloud } from './app-settings.js';
import { publishSweepSnapshot } from './snapshot-publish.js';
import { getDataSource } from './tv-local.js';
import { shouldRunDailyScan } from './daily-scan.js';

export const SWEEP_TTL = 3 * 3600;

const state = {
  running: false, cancelled: false, phase: 'inactif', source: null,
  done: 0, total: SP500_TICKERS.length, failed: 0, failedTickers: [],
  startedAt: null, finishedAt: null, error: null, result: null,
};

export function sweepStatus() {
  const elapsed = state.startedAt ? ((state.finishedAt || Date.now()) - state.startedAt) / 1000 : 0;
  const rate = state.done > 0 && elapsed > 0 ? state.done / elapsed : null;
  return {
    ...state,
    elapsedSeconds: Math.round(elapsed),
    etaSeconds: state.running && state.phase === 'historique' && rate ? Math.round((state.total - state.done) / rate) : null,
  };
}

export function cancelSweep() { if (state.running) state.cancelled = true; return state.running; }

const NEWS_KEY = 'sweep:news';
const LAST_KEY = 'sweep:last';
const KEEP = 30 * 24 * 3600;
export function sweepNews() { const r = readCacheRaw(NEWS_KEY); return r.found ? r.value : null; }
export function lastSweepInfo() { const r = readCacheRaw(LAST_KEY); return r.found ? r.value : null; }

// Compare au balayage précédent, mémorise, et envoie le courriel groupé d'un balayage planifié.
async function recordNews(payload, scheduled) {
  const prev = readCacheRaw('sweep:ready');
  const diff = diffSweep(prev.found ? prev.value.tickers : null, payload.rows);
  const day = new Date().toISOString().slice(0, 10);
  const news = { day, at: Date.now(), source: state.source, scheduled, ...diff, previousAt: prev.found ? prev.value.at : null, universeSize: payload.universeSize, retainedSize: payload.retainedSize, email: null };
  writeCache('sweep:ready', { tickers: diff.ready, at: Date.now() }, KEEP);
  if (scheduled) {
    const to = getAlertEmails();
    if (!to.length) news.email = { sent: false, reason: 'aucune adresse (Réglages → TradingView)' };
    else if (!emailAvailable()) news.email = { sent: false, reason: 'RESEND_API_KEY absente du .env' };
    else {
      const msg = buildSweepDigest(diff, payload.rows, { source: state.source, day, universeSize: payload.universeSize, retainedSize: payload.retainedSize });
      const errs = [];
      for (const a of to) { try { await sendAlertEmail(a, msg); } catch (err) { errs.push(`${a} : ${err.message}`); } }
      news.email = { sent: errs.length < to.length, count: to.length - errs.length, reason: errs.join(' ; ') || null };
    }
  }
  writeCache(NEWS_KEY, news, KEEP);
}

export async function startSweep({ scheduled = false } = {}) {
  if (state.running) throw Object.assign(new Error('Un balayage est déjà en cours.'), { status: 409 });
  Object.assign(state, {
    running: true, cancelled: false, phase: 'historique', source: getDataSource(),
    done: 0, failed: 0, failedTickers: [], startedAt: Date.now(), finishedAt: null, error: null, result: null,
  });
  // Tâche de fond : l'appelant n'attend pas.
  (async () => {
    try {
      // Concurrence 1 en mode TradingView (les appels sont de toute façon sérialisés) ;
      // un peu de parallélisme quand c'est Yahoo qui répond.
      await mapWithConcurrency(SP500_TICKERS, async (t) => {
        if (state.cancelled) return;
        try {
          const bars = await fetchDailyHistory(t, 420, { ttl: SWEEP_TTL, patient: true });
          if (!bars || bars.length < 30) { state.failed += 1; state.failedTickers.push(t); }
        } catch { state.failed += 1; state.failedTickers.push(t); }
        state.done += 1;
      }, { limit: state.source === 'tradingview' ? 1 : 4 });
      if (state.cancelled) { state.phase = 'annulé'; return; }
      state.phase = 'analyse';
      const payload = await buildScreening('sp500');
      writeCache(screeningCacheKey('sp500'), payload, 30 * 24 * 3600); // 30 j : servi avec son âge, jamais refusé
      state.result = { retained: payload.retainedSize, universeSize: payload.universeSize };
      await recordNews(payload, scheduled);
      state.phase = 'terminé';
      // Publication vers la version en ligne (case décochée par défaut). publishSweepSnapshot ne
      // lève jamais ; le catch est un second filet : un échec d'envoi n'est pas un échec du balayage.
      if (getPublishCloud()) await publishSweepSnapshot({ trigger: scheduled ? 'planifié' : 'balayage' }).catch(() => {});
    } catch (err) {
      state.error = err.message;
      state.phase = 'erreur';
    } finally {
      state.running = false;
      state.finishedAt = Date.now();
      writeCache(LAST_KEY, { at: state.finishedAt, phase: state.phase, scheduled }, KEEP); // même un échec : pas de relance en boucle le même jour
    }
  })();
}

// Balayage planifié (#395) : un par jour ouvrable après 17 h à New York, tant que
// castellana tourne (jour d'app fermée = jour sans balayage, pas de rattrapage).
// Réglages → TradingView (désactivé par défaut). Réutilise la règle pure du scan quotidien du Radar.
export function startSweepScheduler() {
  const timer = setInterval(() => {
    if (state.running || !getSweepAuto()) return; // case à cocher dans Réglages → TradingView
    const last = lastSweepInfo();
    if (!shouldRunDailyScan(new Date(), last ? new Date(last.at) : null)) return;
    console.log('Balayage S&P 500 planifié lancé');
    startSweep({ scheduled: true }).catch((err) => console.error('Balayage planifié impossible —', err.message));
  }, 5 * 60_000);
  timer.unref();
  return timer;
}
