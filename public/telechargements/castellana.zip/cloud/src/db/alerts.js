// Alertes TradingView reçues par webhook — table GLOBALE (pas par
// utilisateur, voir CLAUDE.md du produit : attribuer une alerte à un
// utilisateur exigerait une URL de webhook distincte par personne, Pine
// Script ne pouvant pas envoyer de cookie de session — hors scope tant que
// JP n'a pas demandé cette séparation).

export async function createAlert(db, ticker, message, payload) {
  const result = await db.prepare('INSERT INTO alerts (ticker, message, payload) VALUES (?, ?, ?)')
    .bind(ticker, message, payload).run();
  return result.meta.last_row_id;
}

export async function listAlerts(db) {
  const { results } = await db.prepare('SELECT * FROM alerts ORDER BY recu_le DESC, id DESC LIMIT 200').all();
  return results;
}
