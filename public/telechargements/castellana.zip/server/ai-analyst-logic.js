// IA étape 1 (#398) — « Claude analyste de contexte » : fonctions PURES (aucun réseau,
// aucune base), testées avec des réponses factices. L'analyse n'influence JAMAIS
// Setup/Contexte ni le sizing : elle résume des données déjà rassemblées par le serveur.

export const MODELS = {
  'claude-haiku-5-5': { label: 'Haiku 5.5 (rapide, peu coûteux)', inPerM: 1, outPerM: 5 },
  'claude-sonnet-5-5': { label: 'Sonnet 5.5 (critique plus fine)', inPerM: 3, outPerM: 15 },
};
// ⚠️ Prix en $ par million de tokens : ESTIMATIONS (à vérifier sur la grille officielle).
// Elles ne servent qu'au plafond mensuel et à l'affichage du coût, jamais à facturer.
export const DEFAULT_MODEL = 'claude-haiku-5-5';
export const PROVIDERS = { claude: 'Claude (API Anthropic, payant)', ollama: 'LLM local (Ollama, gratuit, rien ne sort de la machine)' };
export const DEFAULT_PROVIDER = 'claude';
export const DEFAULT_OLLAMA_URL = 'http://127.0.0.1:11434';
export const DEFAULT_BUDGET_USD = 5;
export const MAX_BUDGET_USD = 100;
export const MAX_OUTPUT_TOKENS = 1500;

export function estimateCost(model, inputTokens, outputTokens) {
  const m = MODELS[model];
  if (!m) return null;
  return ((inputTokens || 0) * m.inPerM + (outputTokens || 0) * m.outPerM) / 1e6;
}

export function monthKey(date = new Date()) {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'America/New_York', year: 'numeric', month: '2-digit' })
    .format(date).slice(0, 7);
}
export function dayKeyNY(date = new Date()) {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'America/New_York' }).format(date);
}

/** Plafond : refuse tant que le coût du mois a atteint le budget. */
export function checkBudget(spentUsd, budgetUsd) {
  const spent = Number(spentUsd) || 0;
  const budget = Number(budgetUsd);
  if (!(budget > 0)) return { ok: false, reason: 'Budget mensuel nul : analyses désactivées.' };
  if (spent >= budget) return { ok: false, reason: `Plafond mensuel atteint (${spent.toFixed(2)} $ sur ${budget.toFixed(2)} $).` };
  return { ok: true, remaining: budget - spent };
}

export function validateSettings(patch) {
  const out = {};
  if ('provider' in patch) {
    if (!PROVIDERS[patch.provider]) throw new Error('Fournisseur inconnu.');
    out.provider = patch.provider;
  }
  if ('ollamaModel' in patch) {
    const m = String(patch.ollamaModel ?? '').trim();
    if (!/^[A-Za-z0-9._:\/-]{1,100}$/.test(m)) throw new Error('Nom de modèle Ollama invalide.');
    out.ollamaModel = m;
  }
  if ('model' in patch) {
    if (!MODELS[patch.model]) throw new Error('Modèle inconnu.');
    out.model = patch.model;
  }
  if ('budgetUsd' in patch) {
    const b = Number(patch.budgetUsd);
    if (!Number.isFinite(b) || b < 0 || b > MAX_BUDGET_USD) throw new Error(`Budget invalide (0 à ${MAX_BUDGET_USD} $).`);
    out.budgetUsd = b;
  }
  return out;
}

const num = (v, lo, hi) => (Number.isFinite(+v) && v !== null && v !== '' && +v >= lo && +v <= hi ? +v : null);

/** Plan de trade envoyé par le navigateur : liste blanche, SEULEMENT des ratios (jamais capital, taille ni montants). */
export function sanitizePlan(raw) {
  const p = raw && typeof raw === 'object' ? raw : {};
  return {
    stopPct: num(p.stopPct, 0, 100),
    riskPct: num(p.riskPct, 0, 100),
    atrMult: num(p.atrMult, 0, 20),
    atrPct: num(p.atrPct, 0, 100),
    heatPct: num(p.heatPct, 0, 100),
    correlated: p.correlated === true ? true : p.correlated === false ? false : null,
    liquidity: ['liquide', 'moyen', 'faible'].includes(p.liquidity) ? p.liquidity : null,
  };
}

/** Actualités retenues : titre + date + éditeur + URL https obligatoires. */
export function normalizeNews(items, { max = 8 } = {}) {
  const out = [];
  for (const n of items || []) {
    const url = String(n?.link || n?.url || '');
    const date = n?.providerPublishTime ? new Date(n.providerPublishTime) : (n?.date ? new Date(n.date) : null);
    if (!n?.title || !/^https:\/\//.test(url) || !date || Number.isNaN(date.getTime())) continue;
    out.push({ titre: String(n.title), date: date.toISOString().slice(0, 10), source: String(n.publisher || n.source || 'inconnue'), url });
    if (out.length >= max) break;
  }
  return out;
}

/** Contexte complet : tout ce que le modèle a le droit de savoir. */
export function buildContext({ ticker, today, fundamentals, indicators, scoring, news, plan }) {
  const f = fundamentals || {}, i = indicators || {}, s = scoring || {};
  return {
    symbole: ticker,
    date: today,
    marche: {
      prix: f.price ?? i.price ?? null,
      secteur: f.sector ?? null,
      industrie: f.industry ?? null,
      pe: f.peRatio ?? null,
      price_to_sales: f.priceToSales ?? null,
      beta: f.beta ?? null,
      jours_avant_resultats: f.daysToEarnings ?? null,
      date_resultats: f.earningsDate ?? null,
      moment_resultats: f.earningsTiming ?? null,
    },
    signal_technique: {
      alignement_sma: i.smaAlignment ?? null,
      age_du_signal_seances: i.alignmentAge ?? null,
      rsi: i.rsi != null ? Math.round(i.rsi * 10) / 10 : null,
      tendance_obv: i.obvTrend ?? null,
      golden_cross: i.goldenCross ?? null,
      prix_au_dessus_vwap: f.aboveVwap ?? null,
      score_setup: s.setupScore ?? null,
      score_contexte: s.contexteScore ?? null,
      verdict_screener: s.verdict ?? null,
    },
    plan_de_trade: plan,
    actualites: news || [],
  };
}

export const SYSTEM_PROMPT = `Tu es un analyste de contexte pour un swing trader. Tu reçois UNIQUEMENT un objet JSON de données rassemblées par un logiciel. Règles absolues :
- N'utilise AUCUNE connaissance générale sur l'entreprise ni sur le marché : seulement les données fournies.
- Toute affirmation chiffrée doit venir des données ; sinon écris-la dans "non_disponible", jamais d'estimation.
- Les actualités citées doivent être copiées telles quelles de la liste fournie (titre, date, source, url). N'en invente aucune. Si la liste est vide, dis-le.
- Tu ne fais aucune prédiction de prix ni recommandation d'achat ou de vente.
- Écris en français, de façon concise.
Appelle l'outil "analyse_contexte" avec ta réponse.`;

export const ANALYSIS_TOOL = {
  name: 'analyse_contexte',
  description: "Résumé structuré du contexte d'un candidat de swing trade.",
  input_schema: {
    type: 'object',
    additionalProperties: false,
    required: ['resume', 'actualites', 'resultats', 'risques', 'contradictions_signal', 'critique_plan', 'non_disponible'],
    properties: {
      resume: { type: 'string' },
      actualites: {
        type: 'array',
        items: {
          type: 'object', additionalProperties: false, required: ['titre', 'date', 'source', 'url', 'pertinence'],
          properties: { titre: { type: 'string' }, date: { type: 'string' }, source: { type: 'string' }, url: { type: 'string' }, pertinence: { type: 'string' } },
        },
      },
      resultats: { type: 'string' },
      risques: { type: 'array', items: { type: 'string' } },
      contradictions_signal: { type: 'array', items: { type: 'string' } },
      critique_plan: { type: 'array', items: { type: 'string' } },
      non_disponible: { type: 'array', items: { type: 'string' } },
    },
  },
};

const STR_ARRAYS = ['risques', 'contradictions_signal', 'critique_plan', 'non_disponible'];

/**
 * Valide la réponse du modèle. Lève si non conforme (pas de repli silencieux).
 * Les actualités doivent figurer EXACTEMENT dans la liste fournie (même url) :
 * une actualité absente de la liste = invention, la réponse est rejetée.
 */
export function validateAnalysis(obj, providedNews = []) {
  if (!obj || typeof obj !== 'object') throw new Error('Réponse IA non conforme : objet attendu.');
  if (typeof obj.resume !== 'string' || !obj.resume.trim()) throw new Error('Réponse IA non conforme : résumé manquant.');
  if (typeof obj.resultats !== 'string') throw new Error('Réponse IA non conforme : champ « resultats » manquant.');
  for (const k of STR_ARRAYS) {
    if (!Array.isArray(obj[k]) || obj[k].some((x) => typeof x !== 'string')) throw new Error(`Réponse IA non conforme : « ${k} » doit être une liste de textes.`);
  }
  if (!Array.isArray(obj.actualites)) throw new Error('Réponse IA non conforme : « actualites » manquant.');
  const byUrl = new Map(providedNews.map((n) => [n.url, n]));
  const actualites = obj.actualites.map((a) => {
    const real = byUrl.get(a?.url);
    if (!real) throw new Error(`Réponse IA rejetée : actualité hors de la liste fournie (« ${String(a?.titre).slice(0, 60)} »).`);
    // On affiche les champs de la SOURCE, pas ceux reformulés par le modèle ; seul le commentaire de pertinence est de lui.
    return { titre: real.titre, date: real.date, source: real.source, url: real.url, pertinence: String(a.pertinence || '') };
  });
  return {
    resume: obj.resume.trim(),
    actualites,
    resultats: obj.resultats,
    risques: obj.risques,
    contradictions_signal: obj.contradictions_signal,
    critique_plan: obj.critique_plan,
    non_disponible: obj.non_disponible,
  };
}

/** Extrait l'appel d'outil d'une réponse /v1/messages. */
export function extractToolInput(response) {
  const block = (response?.content || []).find((b) => b.type === 'tool_use' && b.name === ANALYSIS_TOOL.name);
  if (!block) throw new Error("Réponse IA non conforme : aucun résultat structuré.");
  return block.input;
}

/** Clé de cache : change avec le jour (NY) et avec daysToEarnings (nouveaux résultats = nouvelle analyse). */
export function cacheKey(ticker, today, daysToEarnings, model, plan = null) {
  return `ai:analyse:v1:${ticker}:${today}:${daysToEarnings ?? 'x'}:${model}${plan ? ':p' + planHash(plan) : ''}`;
}

/** Empreinte courte du plan de trade : changer le stop ou le risque change la clé (la critique du plan ne doit pas venir d'un ancien plan). */
export function planHash(plan) {
  const s = JSON.stringify(plan, Object.keys(plan || {}).sort());
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0;
  return h.toString(36);
}

/** Requête Ollama /api/chat : sortie contrainte par le schéma JSON (structured outputs), déterministe. */
export function ollamaRequest(model, context) {
  return {
    model, stream: false, format: ANALYSIS_TOOL.input_schema,
    options: { temperature: 0, num_ctx: 8192, num_predict: MAX_OUTPUT_TOKENS },
    messages: [
      { role: 'system', content: SYSTEM_PROMPT.replace(/Appelle l'outil[^\n]*$/, 'Réponds UNIQUEMENT par un objet JSON conforme au schéma demandé.') },
      { role: 'user', content: JSON.stringify(context) },
    ],
  };
}

/** Extrait l'objet JSON d'une réponse Ollama /api/chat. */
export function extractOllamaInput(response) {
  const text = response?.message?.content;
  if (typeof text !== 'string' || !text.trim()) throw new Error('Réponse IA non conforme : réponse vide du LLM local.');
  try { return JSON.parse(text); } catch { throw new Error("Réponse IA non conforme : le LLM local n'a pas renvoyé du JSON valide."); }
}
