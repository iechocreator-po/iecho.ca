// js/app-selection.js — Verdict « force relative + Golden Cross » et calcul partagé des onglets Secteurs / Screener
// Extrait de l'ancien script en ligne des index.html (découpage phase 2, 20/10/2026) : code déplacé tel quel, sans réécriture.
// Fichier COMMUN aux versions locale et cloud : source ici ; cloud/public/js/app-selection.js en est la copie (npm run sync:cloud).
// Script classique : ses noms de premier niveau sont globaux et partagés avec les autres scripts de la page.

// ---- Verdict "force relative + Golden Cross" — calcul partagé ----------
//
// Extrait de calcSelectionFor() le 11/9/2026 : la même évaluation sert
// maintenant TROIS écrans (Secteurs, Screener, Fiche de trade) alors
// qu'elle était enfermée au milieu d'écritures DOM. La fonction ci-dessous
// est pure — elle ne lit ni n'écrit le DOM — et distingue explicitement
// « non renseigné » de « défavorable » : c'est tout l'objet du correctif du
// jour, une donnée absente ne doit jamais produire un verdict crédible.
function evaluateSelection({ perfTitre, perfIndice, sma50, sma200 }) {
  // Une chaîne vide donne 0 avec l'opérateur `+` — d'où ce passage
  // explicite par null, sans quoi un champ vide vaudrait « 0 % ».
  const num = (v) => {
    if (v === '' || v === null || v === undefined) return null;
    const n = +v;
    return Number.isFinite(n) ? n : null;
  };
  const pt = num(perfTitre), pi = num(perfIndice);
  const s50 = num(sma50), s200 = num(sma200);
  const bFr = CFG.bandes.forceRelative.seuilPts;
  const bGc = CFG.bandes.goldenCross.seuilPct;

  const fr = { known: pt !== null && pi !== null, score: 0, state: 'inconnu' };
  if (fr.known) {
    fr.ecart = pt - pi;
    if (fr.ecart > bFr) { fr.state = 'forte'; fr.score = 1; }
    else if (fr.ecart >= -bFr) { fr.state = 'neutre'; }
    else { fr.state = 'faible'; }
  }

  // SMA200 à 0 est traité comme non renseigné, pas comme un écart de 0 % :
  // la division serait une division par zéro, et « 0 % » se lirait comme un
  // vrai résultat.
  const gc = { known: s50 !== null && s200 !== null && s200 !== 0, score: 0, state: 'inconnu' };
  if (gc.known) {
    gc.ecartSma = ((s50 - s200) / s200) * 100;
    if (s50 > s200 && gc.ecartSma > bGc) { gc.state = 'confirme'; gc.score = 1; }
    else if (s50 > s200) { gc.state = 'naissant'; }
    else { gc.state = 'absent'; }
  }

  return { fr, gc, known: (fr.known ? 1 : 0) + (gc.known ? 1 : 0), total: fr.score + gc.score };
}
// Rendu de la bannière, commun aux trois onglets.
function renderSelectionBanner(key, ticker, ev) {
  const t = BANNER_TARGETS[key];
  const banner = t && document.getElementById(t.banner);
  if (!banner) return; // section pas encore injectée (init)
  const text = document.getElementById(t.text);
  const btn = document.getElementById(t.btn);
  btn.style.display = 'none';

  // Aucun des deux signaux n'est renseigné : on le dit, on ne conclut pas.
  if (ev.known === 0) {
    banner.className = 'banner unknown';
    text.textContent = '— ' + ticker + ' : rien à évaluer pour l\'instant. Clique '
      + t.fetchLabel + ' pour renseigner la force relative et le Golden Cross — '
      + 'aucun verdict n\'est calculé tant que ces deux signaux sont inconnus.';
    return;
  }

  // Un seul des deux : on nomme ce qu'on sait ET ce qu'on ignore, plutôt
  // que de faire passer un demi-verdict pour un verdict.
  if (ev.known === 1) {
    // Accords en genre portés par le libellé lui-même : « la force
    // relative » est féminine, « le Golden Cross » masculin.
    const FR = { sujet: 'la force relative', positif: 'positive', renseigne: 'renseignée' };
    const GC = { sujet: 'le Golden Cross', positif: 'positif', renseigne: 'renseigné' };
    const connu = ev.fr.known ? FR : GC;
    const manquant = ev.fr.known ? GC : FR;
    const estPositif = (ev.fr.known ? ev.fr.score : ev.gc.score) === 1;
    banner.className = 'banner unknown';
    text.textContent = '◐ ' + ticker + ' — évaluation incomplète : ' + connu.sujet
      + (estPositif ? ' est ' : ' n\'est pas ') + connu.positif
      + (estPositif ? ', mais ' : ', et ') + manquant.sujet
      + ' n\'est pas ' + manquant.renseigne + '. Clique ' + t.fetchLabel
      + ' pour un verdict complet.';
    return;
  }

  const inWatchlist = currentWatchlistTickers.has(ticker);
  if (ev.total === 2) {
    banner.className = 'banner add';
    text.textContent = '✓ ' + ticker + ' — signal fort (force relative + Golden Cross confirmés). Un bon candidat à suivre au screening quotidien.';
    btn.style.display = 'inline-flex';
    btn.disabled = inWatchlist;
    btn.textContent = inWatchlist ? '✓ Déjà dans la watchlist' : '+ Ajouter à la watchlist';
  } else if (ev.total === 1) {
    // T1 (6/9/2026, demande de JP) : nommer explicitement lequel des deux
    // signaux est positif — "un signal sur deux" sans préciser lequel
    // obligeait à remonter lire les deux badges pour comprendre.
    const positif = ev.fr.score === 1 ? 'Force relative' : 'Golden Cross';
    const negatif = ev.fr.score === 1 ? 'Golden Cross' : 'Force relative';
    banner.className = 'banner watch';
    text.textContent = '◐ ' + ticker + ' — à surveiller : ' + positif + ' positif, mais ' + negatif
      + ' ne l\'est pas. Ce titre est celui actuellement saisi dans ' + t.champTicker
      + ', pas une recommandation automatique de l\'app.';
  } else {
    banner.className = 'banner skip';
    text.textContent = '✗ ' + ticker + ' — ne pas ajouter pour l\'instant, aucun signal positif.';
  }
}
// ---- Onglets Secteurs / Screener — calcul partagé, paramétré par instance ----
// Saisie à la main dans un des quatre champs numériques : ces valeurs sont
// désormais celles de l'utilisateur, plus celles d'un « Récupérer en direct ».
function selectionManualEdit(instanceKey) {
  selectionFetchedFor[instanceKey] = null;
  calcSelectionFor(instanceKey);
}
// Le symbole a changé depuis la dernière récupération : les valeurs affichées
// appartiennent à l'ancien titre — on les efface.
function invalidateSelectionData(instanceKey) {
  const ids = SELECTION_INSTANCES[instanceKey];
  for (const f of ['perfTitre', 'perfIndice', 'sma50', 'sma200']) document.getElementById(ids[f]).value = '';
  renderFundamentalsFor(instanceKey, null);
  selectionFetchedFor[instanceKey] = null;
  if (FCF_INSTANCES.includes(instanceKey)) hideFcfCard(instanceKey + '-fcf-card');
  if (instanceKey === 'fic') { clearAutoFilledEntry(); calcFiche(); }
  const st = document.getElementById(ids.liveStatus);
  if (st) st.textContent = '';
}
// Rafraîchit des cartes Symbole SANS changer « la dernière carte utilisée » (qui alimente la Fiche) : un rafraîchissement
// de la watchlist ou des réglages ne doit pas rediriger la Fiche vers un autre titre (audit app-js, constat 3).
function refreshSelectionsPassively(keys) {
  const keep = lastTickerInstance;
  try { for (const k of keys) calcSelectionFor(k); } finally { lastTickerInstance = keep; }
}
function calcSelectionFor(instanceKey) {
  if (LINKED_INSTANCES.includes(instanceKey)) lastTickerInstance = instanceKey;
  const ids = SELECTION_INSTANCES[instanceKey];
  const typed = document.getElementById(ids.ticker).value.toUpperCase();
  if (selectionFetchedFor[instanceKey] && selectionFetchedFor[instanceKey] !== typed) invalidateSelectionData(instanceKey);
  const ticker = typed || 'CE TITRE';
  const ev = evaluateSelection({
    perfTitre: document.getElementById(ids.perfTitre).value,
    perfIndice: document.getElementById(ids.perfIndice).value,
    sma50: document.getElementById(ids.sma50).value,
    sma200: document.getElementById(ids.sma200).value,
  });

  const frBadge = document.getElementById(ids.frBadge);
  const frNote = document.getElementById(ids.frNote);
  if (!ev.fr.known) {
    frBadge.innerHTML = '<span class="ds-badge">Non renseigné</span>';
    frNote.textContent = 'Les deux performances sont nécessaires pour calculer l\'écart — clique « Récupérer en direct », ou saisis-les à la main.';
  } else if (ev.fr.state === 'forte') {
    frBadge.innerHTML = '<span class="ds-badge ds-badge--success">Forte (+' + ev.fr.ecart.toFixed(2) + ' pts)</span>';
    frNote.textContent = 'Le titre surperforme nettement l\'indice — plus de demande, potentiel de leadership.';
  } else if (ev.fr.state === 'neutre') {
    frBadge.innerHTML = '<span class="ds-badge ds-badge--warning">Neutre (' + ev.fr.ecart.toFixed(2) + ' pts)</span>';
    frNote.textContent = 'Le titre suit le marché sans vraiment se démarquer.';
  } else {
    frBadge.innerHTML = '<span class="ds-badge ds-badge--danger">Faible (' + ev.fr.ecart.toFixed(2) + ' pts)</span>';
    frNote.textContent = 'Le titre sous-performe l\'indice — risque de sous-performance continue.';
  }

  const gcBadge = document.getElementById(ids.gcBadge);
  const gcNote = document.getElementById(ids.gcNote);
  if (!ev.gc.known) {
    gcBadge.innerHTML = '<span class="ds-badge">Non renseigné</span>';
    gcNote.textContent = 'SMA50 et SMA200 sont nécessaires — clique « Récupérer en direct » (calcul maison sur l\'historique Yahoo), ou saisis-les à la main.';
  } else if (ev.gc.state === 'confirme') {
    // T3 (12/9/2026) — normalisé sur le même terme que l'en-tête de section
    // ("Golden Cross", capitalisé) et le même mot que le badge ("Confirmé"),
    // là où le texte disait jusqu'ici "Golden cross établi" (casse et
    // formulation différentes de tout le reste de l'écran).
    gcBadge.innerHTML = '<span class="ds-badge ds-badge--success">Confirmé (+' + ev.gc.ecartSma.toFixed(2) + ' %)</span>';
    gcNote.textContent = 'Golden Cross confirmé — tendance de fond haussière.';
  } else if (ev.gc.state === 'naissant') {
    gcBadge.innerHTML = '<span class="ds-badge ds-badge--warning">Naissant (+' + ev.gc.ecartSma.toFixed(2) + ' %)</span>';
    gcNote.textContent = 'Golden Cross naissant — croisement récent, à confirmer avec du volume avant de s\'y fier pleinement.';
  } else {
    gcBadge.innerHTML = '<span class="ds-badge ds-badge--danger">Absent (' + ev.gc.ecartSma.toFixed(2) + ' %)</span>';
    gcNote.textContent = 'Golden Cross absent — tendance de fond baissière ou neutre.';
  }

  renderSelectionBanner(instanceKey, ticker, ev);
}
