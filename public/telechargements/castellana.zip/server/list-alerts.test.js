// Tests de la logique pure des alertes sur les listes (server/list-alerts-logic.js).
import test from 'node:test';
import assert from 'node:assert/strict';
import { ALERT_TYPES, validateRuleParams, isValidListRef, evaluateRule, isMarketWindow, buildDigest } from './list-alerts-logic.js';

const run = (type, params, rows, prev, baselined = true) => {
  const rule = { type, params: validateRuleParams(type, params), baselined };
  const map = new Map(rows.map((r) => [r.ticker, r]));
  return evaluateRule(rule, map, new Map(Object.entries(prev)), rows.map((r) => r.ticker));
};

test('setup_pret : notifie à la TRANSITION vers « prêt », pas tant que l\'état dure', () => {
  const rows = [{ ticker: 'AMD', verdict: 'prêt', setupScore: 3, contexteScore: 2, alignmentAge: 1 }];
  assert.equal(run('setup_pret', {}, rows, { AMD: 'à surveiller' }).notifications.length, 1);
  assert.equal(run('setup_pret', {}, rows, { AMD: 'prêt' }).notifications.length, 0);
});

test('premier passage (baselined faux) : état enregistré, aucune alerte', () => {
  const rows = [{ ticker: 'AMD', verdict: 'prêt' }];
  const r = run('setup_pret', {}, rows, {}, false);
  assert.equal(r.notifications.length, 0);
  assert.equal(r.states.get('AMD'), 'prêt');
});

test('titre nouveau dans la liste (aucun état) : première observation, aucune alerte', () => {
  assert.equal(run('setup_pret', {}, [{ ticker: 'NEW', verdict: 'prêt' }], {}).notifications.length, 0);
});

test('donnée manquante : l\'état mémorisé est conservé, jamais remplacé par un trou', () => {
  const r = run('rsi_seuil', { sens: 'above', seuil: 70 }, [{ ticker: 'X', rsi: null }], { X: 'below' });
  assert.equal(r.states.get('X'), 'below');
  assert.equal(r.notifications.length, 0);
});

test('rsi_seuil : franchissement à la hausse seulement, selon le sens choisi', () => {
  const up = [{ ticker: 'X', rsi: 72 }];
  assert.equal(run('rsi_seuil', { sens: 'above', seuil: 70 }, up, { X: 'below' }).notifications.length, 1);
  assert.equal(run('rsi_seuil', { sens: 'below', seuil: 70 }, up, { X: 'below' }).notifications.length, 0);
  assert.equal(run('rsi_seuil', { sens: 'below', seuil: 30 }, [{ ticker: 'X', rsi: 25 }], { X: 'above' }).notifications.length, 1);
});

test('alignement_perdu : seulement haussier → autre chose', () => {
  const rows = [{ ticker: 'A', smaAlignment: 'neutre' }];
  assert.equal(run('alignement_perdu', {}, rows, { A: 'haussier' }).notifications.length, 1);
  assert.equal(run('alignement_perdu', {}, rows, { A: 'baissier' }).notifications.length, 0);
});

test('resultats_imminents : out → in seulement', () => {
  const rows = [{ ticker: 'A', daysToEarnings: 3 }];
  assert.equal(run('resultats_imminents', { jours: 7 }, rows, { A: 'out' }).notifications.length, 1);
  assert.equal(run('resultats_imminents', { jours: 7 }, rows, { A: 'in' }).notifications.length, 0);
});

test('prime_put : un titre sans put exploitable est « out », et passe « in » au seuil', () => {
  const rows = [{ ticker: 'A', annualizedYield: 31, strike: 100, expiry: '2026-11-20', dte: 30, delta: -0.2, premium: 2.5 }];
  const r = run('prime_put', { rendementMin: 25 }, rows, { A: 'out' });
  assert.equal(r.notifications.length, 1);
  const none = evaluateRule({ type: 'prime_put', params: { rendementMin: 25 }, baselined: true }, new Map(), new Map([['A', 'in']]), ['A']);
  assert.equal(none.states.get('A'), 'out');
});

test('validation des paramètres : refus lisibles, valeurs par défaut', () => {
  assert.throws(() => validateRuleParams('rsi_seuil', { sens: 'above', seuil: 150 }), /entre 0 et 100/);
  assert.throws(() => validateRuleParams('resultats_imminents', { jours: 2.5 }), /entier/);
  assert.throws(() => validateRuleParams('inconnu', {}), /inconnu/);
  assert.deepEqual(validateRuleParams('resultats_imminents', {}), { jours: 7 });
  assert.ok(Object.keys(ALERT_TYPES).length === 5);
});

test('listes valides : watchlist, mag7, list:<id> ; pas l\'univers élargi', () => {
  assert.ok(isValidListRef('watchlist') && isValidListRef('mag7') && isValidListRef('list:12'));
  assert.ok(!isValidListRef('elargi') && !isValidListRef('list:abc'));
});

test('fenêtre de marché : jours ouvrables, 9 h à 17 h à New York', () => {
  assert.equal(isMarketWindow(new Date('2026-09-29T15:00:00Z')), true);   // mardi 11 h NY
  assert.equal(isMarketWindow(new Date('2026-09-29T23:30:00Z')), false);  // mardi 19 h 30 NY
  assert.equal(isMarketWindow(new Date('2026-09-26T15:00:00Z')), false);  // samedi
});

test('digest : un courriel groupé, nombre exact d\'alertes', () => {
  const d = buildDigest([{ listLabel: 'MAG7', ruleLabel: 'RSI', items: ['a', 'b'] }, { listLabel: 'Ma watchlist', ruleLabel: 'Prêt', items: ['c'] }]);
  assert.match(d.subject, /3 alerte/);
  assert.match(d.text, /MAG7/);
});
