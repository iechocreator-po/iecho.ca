// Tests de parseTickersParam() — la seule partie de /api/screening/history
// qui ne dépend pas du réseau (getScreeningPerformance() appelle Yahoo via
// fetchDailyHistory, vérifié en direct plutôt qu'ici).

import test from 'node:test';
import assert from 'node:assert/strict';
import { parseTickersParam } from './screening.js';

test('liste simple : majuscule, espaces retirés, ordre conservé', () => {
  assert.deepEqual(parseTickersParam(' amd, msft ,aapl'), ['AMD', 'MSFT', 'AAPL']);
});

test('doublons retirés (première occurrence conservée)', () => {
  assert.deepEqual(parseTickersParam('AMD,MSFT,AMD'), ['AMD', 'MSFT']);
});

test('vide ou absent : refusé en 400', () => {
  assert.throws(() => parseTickersParam(''), /requis/);
  assert.throws(() => parseTickersParam(undefined), /requis/);
  assert.throws(() => parseTickersParam(' , , '), /requis/);
});

test('plafond : au-delà de `max`, refusé en 400 avec le compte reçu', () => {
  const many = Array.from({ length: 41 }, (_, i) => `T${i}`).join(',');
  assert.throws(() => parseTickersParam(many), /40 titres maximum.*41/);
  // Exactement à la limite : accepté.
  const forty = Array.from({ length: 40 }, (_, i) => `T${i}`).join(',');
  assert.equal(parseTickersParam(forty).length, 40);
});

test('symbole invalide (injection potentielle) : refusé, pas filtré en silence', () => {
  assert.throws(() => parseTickersParam('AMD,DROP TABLE'), /symbole invalide/);
  assert.throws(() => parseTickersParam('AMD,<script>'), /symbole invalide/);
});

test('tickers avec point ou accent circonflexe (^VIX, BRK.B) acceptés', () => {
  assert.deepEqual(parseTickersParam('^VIX,BRK.B'), ['^VIX', 'BRK.B']);
});
