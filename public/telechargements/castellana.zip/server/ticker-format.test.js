// Forme d'un symbole (audit onglets, 20/10/2026, constat 1) : refusé à l'écriture (serveur local ET Worker cloud) et signalé à l'import.
import test from 'node:test';
import assert from 'node:assert/strict';
import { isValidTicker, TICKER_PATTERN } from './ticker-format.js';
import { isValidTicker as isValidTickerCloud } from '../cloud/src/lib/ticker-format.js';
import { validateOptionTrade } from './option-trades.js';
import { validateCashFlow } from './cash-flows.js';
import { validateTrade } from './trades.js';
import { validateOptionTrade as validateOptionTradeCloud } from '../cloud/src/db/option-trades.js';
import { validateCashFlow as validateCashFlowCloud } from '../cloud/src/db/cash-flows.js';
import { validateTrade as validateTradeCloud } from '../cloud/src/db/trades.js';
import { roueImpPlan } from './roue-import.js';

const entites = (s) => [...s].map((c) => `&#${c.charCodeAt(0)};`).join('');
const PIEGES = [
  `<IMG SRC=X ONERROR=${entites('window.__xss=1')}>`, '<script>alert(1)</script>', 'AAPL"><img src=x>', "AAPL'];alert(1);//", 'A B', '', ' ', 'X'.repeat(16),
  '=HYPERLINK("http://x")', '-AAPL', '+AAPL', '@AAPL', 'AA\nPL', 'AAPL\u0000', 'AA\tPL',
];
const VALIDES = ['AAPL', 'aapl', ' msft ', 'BRK-B', 'BRK.B', 'XEQT.TO', '^VIX', '^GSPC', 'CL=F', 'EURUSD=X', 'A', 'X'.repeat(15), '9988.HK', 'BF-B'];

test('isValidTicker : les vrais symboles passent (minuscules et espaces tolérés), les charges et les formes douteuses sont refusées', () => {
  for (const t of VALIDES) assert.equal(isValidTicker(t), true, `${JSON.stringify(t)} devrait passer`);
  for (const t of PIEGES) assert.equal(isValidTicker(t), false, `${JSON.stringify(t)} devrait être refusé`);
  for (const t of [null, undefined, 42, {}, []]) assert.equal(isValidTicker(t), false);
  assert.ok(TICKER_PATTERN.source.startsWith('^') && TICKER_PATTERN.source.endsWith('$'), 'motif ancré aux deux bouts');
});

test('la version cloud (copie générée) décide pareil que la version du serveur', () => {
  for (const t of [...VALIDES, ...PIEGES, null, 42]) assert.equal(isValidTickerCloud(t), isValidTicker(t), JSON.stringify(t));
});

const leg = (ticker) => ({ type: 'put', ticker, compte: 'margin', strike: 50, echeance: '2026-12-18', prime_recue: 1, date_ouverture: '2026-11-20' });
const flow = (ticker) => ({ compte: 'margin', type: 'dividende', date: '2026-11-20', montant: 5, ticker });
const trade = (ticker) => ({ date_entree: '2026-11-20', compte: 'margin', ticker, prix_entree: 50, taille_position: 100, stop_initial: 45 });

for (const [nom, vLeg, vFlow, vTrade] of [
  ['serveur local', validateOptionTrade, validateCashFlow, validateTrade],
  ['Worker cloud', validateOptionTradeCloud, validateCashFlowCloud, validateTradeCloud],
]) {
  test(`${nom} : jambes, mouvements et actions refusent un symbole piégé et acceptent un vrai`, () => {
    for (const t of PIEGES.filter((x) => x.trim() !== '')) {
      assert.ok(vLeg(leg(t)).some((e) => /ticker invalide/.test(e)), `jambe : ${JSON.stringify(t)}`);
      assert.ok(vFlow(flow(t)).some((e) => /ticker invalide/.test(e)), `mouvement : ${JSON.stringify(t)}`);
      assert.ok(vTrade(trade(t)).some((e) => /ticker invalide/.test(e)), `action : ${JSON.stringify(t)}`);
    }
    for (const t of ['AAPL', 'BRK-B', 'XEQT.TO']) {
      assert.deepEqual(vLeg(leg(t)), [], `jambe ${t}`);
      assert.deepEqual(vFlow(flow(t)), [], `mouvement ${t}`);
      assert.deepEqual(vTrade(trade(t)), [], `action ${t}`);
    }
    assert.deepEqual(vFlow({ ...flow(null), ticker: null }), [], 'le symbole d\'un mouvement reste facultatif');
  });
}

test('l\'import d\'un fichier : un symbole invalide est signalé et la ligne n\'est jamais cochée par défaut', () => {
  const ligne = (ticker, type) => ({ ligne: 2, ticker, tickerInvalide: !isValidTicker(ticker), type, date: '2026-11-20', debut: '2026-11-20', fermeture: '2026-12-18',
    strike: 50, contrats: 1, prix: 1, commission: 0, rachat: null, dividendes: null, close: null, assigne: false, idCycle: null, notes: null });
  for (const type of ['PUT', 'ACHAT', 'VENTE', 'FOO']) {
    const plan = roueImpPlan([ligne(PIEGES[0], type)], { today: '2026-11-25', compte: 'margin' });
    const op = plan.cycles[0].ops[0];
    assert.ok(op.issues.includes('symbole invalide'), `${type} : « symbole invalide » signalé`);
    assert.equal(op.include, false, `${type} : jamais cochée par défaut`);
    const ok = roueImpPlan([ligne('AAPL', type)], { today: '2026-11-25', compte: 'margin' }).cycles[0].ops[0];
    assert.ok(!ok.issues.includes('symbole invalide'), `${type} : un vrai symbole n'est pas signalé`);
  }
});
