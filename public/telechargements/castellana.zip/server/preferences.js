// Réglages modifiables par l'utilisateur depuis l'app (feature 351, 7/9/2026).
//
// Jusqu'ici, les périodes d'indicateurs vivaient dans `config.js`, un fichier
// à éditer à la main — inaccessible pour un testeur — et, pire, elles n'y
// pilotaient longtemps que les LIBELLÉS affichés : le calcul restait figé
// à 9/21/100 côté serveur. Cet écart a été corrigé pour l'onglet Labo le
// 5/9/2026 ; il l'est ici pour toute l'application.
//
// Ces valeurs sont stockées EN BASE et non dans `settings.json` :
//   — elles survivent à une mise à jour de l'app (server/update.js ne touche
//     jamais à `data/`, alors qu'il remplace les fichiers de code) ;
//   — elles appartiennent à l'utilisateur, pas à l'installation.

import { db } from './db.js';

db.exec(`
  CREATE TABLE IF NOT EXISTS preferences (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
`);

// Valeurs par défaut demandées par JP (feature 351, points 4a et 4b).
//
// ⚠️ ÉCART ASSUMÉ AVEC LE DOCUMENT DE DESIGN : celui-ci fixe le filtre de
// tendance à SMA 9/21/**100** (section 4.1), et ce `CLAUDE.md` demandait
// explicitement de ne pas y toucher. JP a demandé **50** pour la moyenne
// lente dans la feature 351, à deux reprises (valeurs initiales ET valeurs
// du bouton de réinitialisation). C'est donc un changement délibéré de sa
// part, pas un oubli — mais il reste à reporter dans
// `design_assistant_swing_trading.md` et dans l'alerte Pine Script
// configurée sur TradingView, que cet outil ne peut pas modifier.
export const DEFAULTS = {
  smaFast: 9,
  smaMedium: 21,
  smaSlow: 50,
  rsiPeriod: 14,
};

// Bornes de validation. Une période doit être un entier ≥ 2 (une moyenne
// sur 1 barre n'est pas une moyenne) et rester dans ce que l'historique
// téléchargé peut porter (~290 barres pour 420 jours calendaires).
const MIN_PERIOD = 2;
const MAX_PERIOD = 250;

const selectAll = db.prepare('SELECT key, value FROM preferences');
const upsert = db.prepare('INSERT INTO preferences (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
const clearAll = db.prepare('DELETE FROM preferences');

export function getPreferences() {
  const stored = Object.fromEntries(selectAll.all().map((r) => [r.key, r.value]));
  const out = { ...DEFAULTS };
  for (const key of Object.keys(DEFAULTS)) {
    const n = Number.parseInt(stored[key], 10);
    if (Number.isInteger(n) && n >= MIN_PERIOD && n <= MAX_PERIOD) out[key] = n;
  }
  return out;
}

// Valide et enregistre. Retourne les préférences effectives ; lève avec un
// message lisible par un humain si une valeur est refusée — jamais un
// silence qui laisserait croire que le réglage a été pris en compte.
export function setPreferences(patch) {
  const errors = [];
  const accepted = {};
  const labels = {
    smaFast: 'Moyenne mobile simple rapide',
    smaMedium: 'Moyenne mobile simple moyenne',
    smaSlow: 'Moyenne mobile simple lente',
    rsiPeriod: 'RSI',
  };
  for (const [key, raw] of Object.entries(patch || {})) {
    if (!(key in DEFAULTS)) continue; // clé inconnue ignorée, pas une erreur
    const n = Number.parseInt(raw, 10);
    if (!Number.isInteger(n) || n < MIN_PERIOD || n > MAX_PERIOD) {
      errors.push(`${labels[key]} : « ${raw} » n'est pas un entier entre ${MIN_PERIOD} et ${MAX_PERIOD}.`);
      continue;
    }
    accepted[key] = n;
  }

  // Cohérence d'ordre : le filtre de tendance n'a de sens que si rapide <
  // moyenne < lente. Sans ce contrôle, 21/9/50 serait accepté et
  // l'alignement « haussier » deviendrait silencieusement inatteignable.
  const merged = { ...getPreferences(), ...accepted };
  if (!(merged.smaFast < merged.smaMedium && merged.smaMedium < merged.smaSlow)) {
    errors.push(
      `Les trois moyennes doivent aller de la plus courte à la plus longue : `
      + `rapide (${merged.smaFast}) < moyenne (${merged.smaMedium}) < lente (${merged.smaSlow}).`,
    );
  }

  if (errors.length) {
    const err = new Error(errors.join(' '));
    err.code = 'INVALID_PREFERENCES';
    throw err;
  }

  const tx = db.transaction((entries) => {
    for (const [key, value] of entries) upsert.run(key, String(value));
  });
  tx(Object.entries(accepted));
  return getPreferences();
}

// Réinitialise aux valeurs par défaut (feature 351, point 4b). On SUPPRIME
// les lignes plutôt que d'y réécrire les défauts : ainsi, si les défauts
// changent un jour, un utilisateur qui a « réinitialisé » suit le nouveau
// défaut au lieu de rester figé sur l'ancien.
export function resetPreferences() {
  clearAll.run();
  return getPreferences();
}

// Forme attendue par getHomemadeIndicators() / getHomemadeIndicatorsBatch().
export function indicatorOptions(prefs = getPreferences()) {
  return {
    periods: { fast: prefs.smaFast, medium: prefs.smaMedium, slow: prefs.smaSlow },
    rsiPeriod: prefs.rsiPeriod,
  };
}
