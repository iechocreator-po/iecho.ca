// launcher/server.js — outil de secours pour castellana (5/9/2026, demande
// de JP après plusieurs relances manuelles via Claude Code).
//
// Principe directeur : cet outil doit rester lui-même TRÈS simple et
// stable, pour être disponible précisément au moment où castellana (le
// vrai produit) ne l'est plus. D'où : zéro dépendance npm (node:http natif,
// pas Express — un framework de plus est une source de panne de plus pour
// l'outil censé nous sortir de la panne), aucune logique métier, tourne sur
// son PROPRE port (4750), totalement indépendant du serveur Express de
// castellana (4700) et de son sidecar Python (4701) qu'il supervise.
//
// Sécurité : lié à 127.0.0.1 uniquement (même garde que castellana lui-même,
// voir server/index.js). Les commandes réellement exécutées (chemins,
// arguments) sont TOUJOURS codées en dur ci-dessous — la requête HTTP ne
// choisit qu'une cible parmi 2 valeurs fixes ('node'|'sidecar'), jamais une
// commande ou un chemin arbitraire. Aucune interpolation de shell avec une
// entrée utilisateur.

import http from 'node:http';
import { execSync, spawn } from 'node:child_process';
import net from 'node:net';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const APP_DIR = path.resolve(__dirname, '..'); // trading-assistant/
const settings = JSON.parse(readFileSync(path.join(APP_DIR, 'settings.json'), 'utf8'));

// Cibles fixes — ports lus depuis le vrai settings.json de castellana pour
// ne jamais diverger si ces ports changent un jour, mais les COMMANDES
// elles-mêmes (fichier à exécuter) restent en dur, jamais dérivées d'une
// entrée externe.
const TARGETS = {
  node: {
    label: 'Serveur Node (castellana)',
    port: settings.port,
    command: 'node',
    args: ['server/index.js'],
  },
  sidecar: {
    label: 'Sidecar Python (tradingview-mcp)',
    port: settings.tradingviewMcp.port,
    command: 'node',
    args: ['scripts/run-sidecar.mjs'],
  },
};

function checkPort(port, timeoutMs = 800) {
  return new Promise((resolve) => {
    const socket = net.createConnection({ host: '127.0.0.1', port, timeout: timeoutMs });
    const done = (ok) => { socket.destroy(); resolve(ok); };
    socket.once('connect', () => done(true));
    socket.once('error', () => done(false));
    socket.once('timeout', () => done(false));
  });
}

// Tue tout process écoutant sur `port` via lsof (utilitaire système, pas de
// dépendance npm) — `port` est toujours l'un des deux entiers fixes de
// TARGETS ci-dessus, jamais une valeur venant de la requête HTTP.
//
// PIÈGE RÉEL TROUVÉ EN TESTANT (5/9/2026) : `lsof -ti:PORT` SANS
// `-sTCP:LISTEN` matche aussi les connexions CLIENTES vers ce port, pas
// seulement le process qui l'écoute en serveur. Le serveur castellana
// (server/tradingview.js) ouvre une connexion cliente sortante vers le
// sidecar sur 4701 — sans ce filtre, "relancer le sidecar" tuait AUSSI le
// serveur Node lui-même (repéré en testant : le PID du serveur Node
// venait de réapparaître dans les PID "arrêtés" d'une relance du sidecar
// seul). `-sTCP:LISTEN` restreint à la vraie socket serveur.
function killPort(port) {
  try {
    const out = execSync(`lsof -ti:${port} -sTCP:LISTEN`, { encoding: 'utf8' }).trim();
    const pids = out ? out.split('\n').filter(Boolean) : [];
    for (const pid of pids) {
      try { process.kill(Number(pid), 'SIGTERM'); } catch { /* déjà mort */ }
    }
    return pids;
  } catch {
    return []; // rien n'écoutait sur ce port (lsof sort en erreur si vide)
  }
}

function startTarget(target) {
  const child = spawn(target.command, target.args, {
    cwd: APP_DIR,
    detached: true,
    stdio: 'ignore',
  });
  child.unref(); // survit indépendamment de ce process superviseur
  return child.pid;
}

async function restartTarget(key) {
  const target = TARGETS[key];
  const killedPids = killPort(target.port);
  await new Promise((r) => setTimeout(r, 500)); // laisse le port se libérer
  const newPid = startTarget(target);
  // Attend jusqu'à ~8s que le port réponde, pour renvoyer un vrai statut
  // plutôt qu'un "c'est parti" optimiste.
  let up = false;
  for (let i = 0; i < 16; i++) {
    await new Promise((r) => setTimeout(r, 500));
    if (await checkPort(target.port)) { up = true; break; }
  }
  return { key, label: target.label, killedPids, newPid, up };
}

// ---------------------------------------------------------------------
// Watchdog (7/9/2026, constat F2 de l'audit)
//
// Le launcher savait RELANCER sur demande, mais ne surveillait rien :
// `grep -c "setInterval|watchdog|autoRestart"` retournait 0. Quand le
// serveur castellana tombait — mise en veille du Mac, plantage, arrêt
// involontaire — personne n'était prévenu, et pour un testeur non
// technique une panne est indiscernable d'un bug de l'application.
//
// Trois garde-fous, à ne pas retirer :
//   1. BACKOFF croissant entre les tentatives, pour ne pas marteler une
//      machine déjà en difficulté ;
//   2. PLAFOND de tentatives consécutives : si castellana ne démarre plus
//      du tout (dépendances cassées, port définitivement pris), le
//      watchdog s'arrête et le dit, plutôt que de boucler indéfiniment ;
//   3. Le compteur se REMET À ZÉRO dès que le service répond, pour qu'une
//      panne isolée ne consomme pas le budget d'une panne ultérieure.
const WATCHDOG_INTERVAL_MS = 15_000;
const WATCHDOG_MAX_ATTEMPTS = 5;

const watchdog = {
  enabled: true,
  consecutiveFailures: 0,
  restarts: 0,
  lastEvent: null,
  journal: [],
  stoppedReason: null,
};

function watchdogLog(message) {
  const entry = { at: new Date().toISOString(), message };
  watchdog.lastEvent = entry;
  watchdog.journal.unshift(entry);
  watchdog.journal.length = Math.min(watchdog.journal.length, 50);
  console.log(`[watchdog] ${message}`);
}

// Le port réellement écouté par castellana, pas celui de settings.json :
// depuis le 7/9/2026 le serveur se replie sur 4711-4715 si 4700 est pris,
// et écrit le port retenu dans data/runtime.json. Sans cette lecture, le
// watchdog surveillerait un port vide et relancerait en boucle une
// application parfaitement vivante sur un autre port.
function currentNodePort() {
  try {
    const runtime = JSON.parse(readFileSync(path.join(APP_DIR, 'data', 'runtime.json'), 'utf8'));
    if (Number.isInteger(runtime.port)) return runtime.port;
  } catch { /* fichier absent au premier démarrage — on retombe sur la config */ }
  return TARGETS.node.port;
}

async function watchdogTick() {
  if (!watchdog.enabled) return;
  const port = currentNodePort();
  if (await checkPort(port)) {
    if (watchdog.consecutiveFailures > 0) watchdogLog(`castellana répond de nouveau sur ${port}.`);
    watchdog.consecutiveFailures = 0;
    return;
  }
  watchdog.consecutiveFailures += 1;
  if (watchdog.consecutiveFailures > WATCHDOG_MAX_ATTEMPTS) {
    watchdog.enabled = false;
    watchdog.stoppedReason = `castellana n'a pas redémarré après ${WATCHDOG_MAX_ATTEMPTS} tentatives — surveillance arrêtée pour ne pas boucler. Lancez « npm run doctor » dans le dossier castellana.`;
    watchdogLog(watchdog.stoppedReason);
    return;
  }
  watchdogLog(`castellana ne répond plus sur ${port} — relance ${watchdog.consecutiveFailures}/${WATCHDOG_MAX_ATTEMPTS}.`);
  const result = await restartTarget('node');
  watchdog.restarts += 1;
  watchdogLog(result.up ? `relancé (pid ${result.newPid}).` : 'la relance n\'a pas abouti, nouvelle tentative au prochain cycle.');
  // Backoff : on saute d'autant de cycles que d'échecs consécutifs.
  await new Promise((r) => setTimeout(r, WATCHDOG_INTERVAL_MS * (watchdog.consecutiveFailures - 1)));
}

setInterval(() => { watchdogTick().catch((err) => watchdogLog(`erreur interne : ${err.message}`)); }, WATCHDOG_INTERVAL_MS);

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');

  if (req.method === 'GET' && url.pathname === '/api/status') {
    const [nodeUp, sidecarUp] = await Promise.all([
      checkPort(currentNodePort()),
      checkPort(TARGETS.sidecar.port),
    ]);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      node: nodeUp,
      sidecar: sidecarUp,
      nodePort: currentNodePort(),
      sidecarPort: TARGETS.sidecar.port,
      watchdog: {
        enabled: watchdog.enabled,
        restarts: watchdog.restarts,
        consecutiveFailures: watchdog.consecutiveFailures,
        stoppedReason: watchdog.stoppedReason,
        lastEvent: watchdog.lastEvent,
        journal: watchdog.journal.slice(0, 10),
      },
    }));
    return;
  }

  if (req.method === 'POST' && url.pathname === '/api/restart') {
    let body = '';
    for await (const chunk of req) body += chunk;
    let target = null;
    try { target = JSON.parse(body || '{}').target; } catch { /* laisse target=null, rejeté ci-dessous */ }
    const keys = target === 'both' ? ['node', 'sidecar'] : [target];
    if (!keys.every((k) => TARGETS[k])) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: `cible invalide : ${JSON.stringify(target)} (attendu : "node" | "sidecar" | "both")` }));
      return;
    }
    const results = [];
    for (const k of keys) results.push(await restartTarget(k));
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ results }));
    return;
  }

  // Bascule de la surveillance. Nécessaire : sans elle, arrêter castellana
  // volontairement (pour éditer settings.json, par exemple) déclencherait
  // une relance automatique dans les 15 s, ce qui donnerait l'impression que
  // l'app « refuse de s'arrêter ». Réactive aussi le watchdog après un arrêt
  // sur plafond de tentatives.
  if (req.method === 'POST' && url.pathname === '/api/watchdog') {
    let body = '';
    for await (const chunk of req) body += chunk;
    let enabled = null;
    try { enabled = JSON.parse(body || '{}').enabled; } catch { /* rejeté ci-dessous */ }
    if (typeof enabled !== 'boolean') {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'attendu : { "enabled": true | false }' }));
      return;
    }
    watchdog.enabled = enabled;
    watchdog.consecutiveFailures = 0;
    watchdog.stoppedReason = null;
    watchdogLog(enabled ? 'surveillance activée.' : 'surveillance désactivée (demande explicite).');
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ watchdog: { enabled: watchdog.enabled } }));
    return;
  }

  if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(readFileSync(path.join(__dirname, 'public', 'index.html')));
    return;
  }

  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('Not found');
});

const PORT = 4750;
const HOST = '127.0.0.1'; // jamais exposé au-delà de la machine locale
server.listen(PORT, HOST, () => {
  console.log(`castellana-launcher — http://${HOST}:${PORT}`);
});
