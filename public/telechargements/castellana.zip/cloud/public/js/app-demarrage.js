// js/app-demarrage.js — Séquence de démarrage COMMUNE aux versions locale et cloud
// Découpage des index.html, phase 3a (20/10/2026). Avant : la même suite d'appels existait deux fois (script en ligne de
// index.html, et bootApp() de js/mode-cloud.js) et dérivait déjà (ordre de loadSectorSetups différent). Elle vit ici une seule fois.
// Fichier COMMUN : source ici ; cloud/public/js/app-demarrage.js en est la copie (npm run sync:cloud).
// Script classique : ses noms de premier niveau sont globaux et partagés avec les autres scripts de la page.
//
// Ce qui est PROPRE à un mode s'accroche par `etapes`, un objet de fonctions facultatives, appelées à des points nommés d'après
// l'étape commune qu'elles suivent :
//   avant                          avant tout (cloud : masque l'écran de connexion, pose le nom du compte)
//   apresLoadWeights               local : checkVersion
//   apresInitLaboStrategies        local : initTvLocal, loadSweepNews
//   apresInitRoueVisibility        cloud : initAnticipationVisibility
//   apresInitFcfCardVisibility     cloud : initTradingviewConnect
//   apresInitAiVisibility          local : Radar, alertes sur les listes, backtest
//   apresInitDisclaimerCollapse    cloud : initDemoMode
// Les fonctions de mode sont définies dans js/mode-local.js ou js/mode-cloud.js (chargés AVANT ce fichier).
// loadSectorSetups() existe sous ce nom dans les deux modes avec un corps différent ; elle est appelée au même endroit dans les deux.
// Ordre de la séquence = ordre historique du mode local ; seul loadSectorSetups() change de place en local (voir ci-dessus),
// ce qu'a vérifié scripts/snapshot-boot.mjs (mêmes appels d'API au démarrage).

function demarrerApp(etapes = {}) {
  appDemarree = true;
  const apres = (nom) => { if (typeof etapes[nom] === 'function') etapes[nom](); };

  apres('avant');

  // Génère les 2 sections "Ticker" (T7, 6/9/2026) — doit tourner avant
  // applyConfig() ci-dessous, qui préremplit sec-ticker/scr-ticker.
  renderTickerSectionInto('sec', { withFundamentals: true });
  renderTickerSectionInto('scr', { withFundamentals: true });
  renderTickerSectionInto('fic', { tickerId: 'ticker', onTickerInput: 'calcFiche()', fetchCall: 'fetchLiveFiche()' });
  renderTickerSectionInto('lab', { tickerId: 'labo-ticker', fetchCall: 'loadLaboTicker()' });

  applyConfig();
  document.getElementById('screen-legend').innerHTML = columnLegendHTML();
  document.getElementById('sector-top-legend').innerHTML = columnLegendHTML();
  initScreenFilterRanges();
  initGlossHeaders(); // (i) des en-têtes de tableaux (A2, A3, B4)
  calcSelectionFor('sec');
  calcSelectionFor('scr');
  calcSelectionFor('fic');
  calcSelectionFor('lab');
  calcFiche();
  checkStatus();
  loadHeaderIndices();
  loadPreferences();
  loadWeights();
  apres('apresLoadWeights');
  initTelemetry();
  initFeedbackWidget();
  initConceptsTab(); // derrière le feature flag concepts_tab (défaut OFF)
  loadWatchlist();
  loadCustomLists();
  loadSectors();
  loadSectorHistory();
  loadSectorSetups(); // local : balayage S&P 500 de la machine ; cloud : instantané publié par l'app locale
  initLaboStrategies();
  apres('apresInitLaboStrategies');
  initOptionsTabA();
  initJournalAVisibility(); // révèle l'onglet Journal A + la carte Labo #6 si journal_a_tab est ON
  initRoueVisibility(); // onglet Roue (flag roue_tab)
  apres('apresInitRoueVisibility');
  initFcfCardVisibility(); // active la carte Fondamentaux si fundamentals_card est ON
  apres('apresInitFcfCardVisibility');
  initAiVisibility(); // révèle la carte d'analyse IA si ai_analyst est ON
  apres('apresInitAiVisibility');
  initDisclaimerCollapse();
  apres('apresInitDisclaimerCollapse');
  initUiIds(); // en dernier : numérote les cartes déjà en place (js/ui-ids.js)
}
