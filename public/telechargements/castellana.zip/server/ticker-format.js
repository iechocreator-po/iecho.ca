// Évalue js/ticker-format.js pour le serveur local — même patron que server/options-analytics.js : le navigateur, ce
// serveur et le Worker cloud (copie ESM générée) partagent UNE définition de la forme d'un symbole.
import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../js/ticker-format.js', import.meta.url), 'utf8');
export const { TICKER_PATTERN, TICKER_ERROR, isValidTicker } = new Function(`${source}; return { TICKER_PATTERN, TICKER_ERROR, isValidTicker };`)();
