// Import du Journal de la Roue du club (#436) : lecture xlsx/csv, statuts déduits, doublons, incohérences.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { roueImpReadXlsx, roueImpParseCsv, roueImpJournalRows, roueImpPlan, roueImpFlowsFromXlsx, roueImpDate, roueImpNumber } from './roue-import.js';

const XLSX = new URL('../anticipation/Copie de NOUVEAU TEMPLATE — Journal de la Roue.xlsx', import.meta.url);

test('valeurs : numéros de série Excel, dates françaises, montants avec virgule ou $', () => {
  assert.equal(roueImpDate(46024), '2026-01-02');                 // Fermeture de la ligne LULU
  assert.equal(roueImpDate(46024.75), '2026-01-02');              // date avec heure de l'après-midi : le jour ne bascule pas
  assert.equal(roueImpDate(46024.999), '2026-01-02');
  assert.equal(roueImpDate('2026-01-02 00:00:00'), '2026-01-02');
  assert.equal(roueImpDate('2/1/2026'), '2026-01-02');            // JJ/MM/AAAA
  assert.equal(roueImpDate('n/a'), null);
  assert.equal(roueImpNumber('1,40'), 1.4);
  assert.equal(roueImpNumber('$1,250.50'), 1250.5);
  assert.equal(roueImpNumber(''), null);
});

test('le vrai fichier du club : JOURNAL lu par en-têtes, LULU signalée, capital de départ repris', { skip: !existsSync(XLSX) && 'copie du Sheets absente (non versionnée)' }, async () => {
  const buf = readFileSync(XLSX);
  const sheets = await roueImpReadXlsx(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength));
  const journal = roueImpJournalRows(sheets.JOURNAL);
  assert.equal(journal.length, 1);
  const [r] = journal;
  assert.deepEqual([r.ticker, r.type, r.strike, r.contrats, r.prix, r.commission, r.close], ['LULU', 'PUT', 205, 1, 1.4, 1, 210.81]);
  assert.deepEqual([r.date, r.debut, r.fermeture], ['2026-12-26', '2026-06-06', '2026-01-02']);   // les dates fautives du Sheets
  const plan = roueImpPlan(journal, { today: '2026-10-13', compte: 'margin' });
  const op = plan.cycles[0].ops[0];
  assert.equal(op.statut, 'expire');                                  // clôture 210,81 > strike 205
  assert.ok(op.issues.includes('échéance avant l\'ouverture'));
  assert.equal(op.include, false);                                    // décochée par défaut, jamais corrigée
  assert.deepEqual(roueImpFlowsFromXlsx(sheets), [{ type: 'depart', date: '2025-12-28', montant: 100000, source: 'PORTFOLIO, capital de départ' }]);
});

const CSV = `JOURNAL DE TRADING - 2026,,,
Ticker,Semaine,Type,Date,"Début
cycle",Fermeture,Strike,Qté,"Prix
option",Commission,Earnings,Premium,Rachat,Dividendes,P/L net,Close,"Assigné /
En position",ID cycle
AMD,Semaine 2,PUT,2026-01-05,2026-01-05,2026-01-16,100,1,"2,10","0,65",FALSE,210,,,209.35,95,OUI,AMD-20260105
AMD,Semaine 5,CALL,2026-01-20,2026-01-05,2026-02-06,105,1,"1,20","0,65",FALSE,120,"0,30",,88.7,,,AMD-20260105
AMD,Semaine 8,CALL,2026-02-09,2026-01-05,2026-02-20,105,1,"1,50","0,65",FALSE,150,,12,161.35,108,,AMD-20260105
MSFT,Semaine 40,PUT,2026-10-05,2026-10-05,2026-10-30,480,1,"4,00",1,FALSE,400,,,399,,,MSFT-20261005
NVDA,Semaine 3,ACHAT,,2026-01-12,2026-01-12,170,1,,1,FALSE,0,,,-1,,OUI,NVDA-20260112
NVDA,Semaine 6,VENTE,,2026-01-12,2026-02-02,180,1,,1,FALSE,0,,,999,,,NVDA-20260112
`;

test('CSV de Google Sheets : statuts déduits (assigné, racheté, assigné call, ouvert), achat/vente, stop exigé', () => {
  const journal = roueImpJournalRows(roueImpParseCsv(CSV));
  assert.equal(journal.length, 6);
  const plan = roueImpPlan(journal, { today: '2026-10-13', compte: 'margin' });
  const amd = plan.cycles.find((c) => c.key === 'AMD-20260105');
  assert.deepEqual(amd.ops.map((o) => o.statut), ['assigne', 'rachete', 'assigne']);   // 95 < 100 ; rachat 0,30 ; 108 > 105
  assert.equal(amd.ops[1].primeCloture, 0.3);
  assert.equal(amd.ops[2].dividendes, 12);
  assert.equal(amd.ops[0].leg.commission_ouverture, 0.65);
  assert.equal(amd.besoinStop, true);                                  // put assigné → action dans le Journal actions
  assert.equal(plan.cycles.find((c) => c.ticker === 'MSFT').ops[0].statut, 'ouvert');
  const nvda = plan.cycles.find((c) => c.ticker === 'NVDA');
  assert.deepEqual(nvda.ops.map((o) => [o.kind, o.date, o.prix, o.actions]), [['achat', '2026-01-12', 170, 100], ['vente', '2026-02-02', 180, 100]]);
  assert.equal(nvda.besoinStop, true);
  assert.equal(plan.resume.aImporter, 6);
});

test('ré-import : une position déjà présente (même clé) est ignorée et rattache son cycle', () => {
  const journal = roueImpJournalRows(roueImpParseCsv(CSV));
  const existingLegs = [{ compte: 'margin', ticker: 'AMD', type: 'put', strike: 100, date_ouverture: '2026-01-05', echeance: '2026-01-16', cycle_id: 7 }];
  const existingTrades = [{ compte: 'margin', ticker: 'NVDA', date_entree: '2026-01-12', prix_entree: 170, date_sortie: '2026-02-02', prix_sortie: 180 }];
  const plan = roueImpPlan(journal, { today: '2026-10-13', compte: 'margin', existingLegs, existingTrades });
  const amd = plan.cycles.find((c) => c.ticker === 'AMD');
  assert.equal(amd.ops[0].doublon, true);
  assert.equal(amd.ops[0].include, false);
  assert.equal(amd.dejaCycleId, 7);
  assert.deepEqual(plan.cycles.find((c) => c.ticker === 'NVDA').ops.map((o) => o.doublon), [true, true]);   // achat ET vente déjà faits
  assert.equal(plan.resume.doublons, 3);
  // Un autre compte n'est pas un doublon.
  assert.equal(roueImpPlan(journal, { today: '2026-10-13', compte: 'RRSP', existingLegs }).resume.doublons, 0);
});

test('en-tête absent ou colonnes manquantes : erreur explicite', () => {
  assert.throws(() => roueImpJournalRows([['a', 'b'], ['1', '2']]), /En-tête introuvable/);
  assert.throws(() => roueImpJournalRows([['Ticker', 'Type'], ['AMD', 'PUT']]), /Colonnes introuvables/);
});
