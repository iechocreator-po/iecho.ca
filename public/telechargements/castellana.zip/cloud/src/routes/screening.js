import { buildScreening, buildTickersScreening, screeningCacheKey, isValidUniverse, getScreeningPerformance, parseTickersParam } from '../lib/screening.js';
import { latestSnapshot } from '../db/snapshots.js';
import { getEffectiveFlagsForUser } from '../db/flags.js';
import { screeningFromSnapshot } from '../lib/snapshots.js';
import { readCacheRaw, writeCache, TTL, demoTtl, demoActive } from '../db/cache.js';

function csvEscape(v) {
  if (v == null) return '';
  const s = String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

// Routes enregistrées à leurs chemins EXACTS (pas de sous-routeur préfixé) :
// /api/screening.csv est un chemin frère de /api/screening, pas un
// sous-chemin — un routeur Hono monté sur '/api/screening' ne peut pas
// servir '/api/screening.csv' sans ambiguïté. Même patron pour tous les
// modules de ce dossier.
export function registerScreeningRoutes(app) {
  app.get('/api/screening', async (c) => {
    const userId = c.get('userId');
    const rawUniverse = c.req.query('universe');
    // S&P 500 (17/10/2026) : jamais calculé ici (plan gratuit : 50 sous-requêtes). On sert le
    // dernier instantané poussé par l'app locale, avec sa date ; sinon 409 NO_SWEEP.
    if (rawUniverse === 'sp500') {
      const flags = await getEffectiveFlagsForUser(c.env.DB, userId);
      if (flags.sp500_sweep !== true) return c.json({ error: "Le balayage S&P 500 n'est pas activé pour ce compte.", code: 'FLAG_OFF' }, 403);
      let snap = null;
      try { snap = await latestSnapshot(c.env.DB, 'sp500_sweep'); } catch { /* table absente avant migration */ }
      if (!snap) return c.json({ error: "Aucun balayage du S&P 500 n'a encore été publié depuis le poste local.", code: 'NO_SWEEP' }, 409);
      return c.json(screeningFromSnapshot(snap.value));
    }
    const universe = isValidUniverse(rawUniverse) ? rawUniverse : 'watchlist';
    const cacheKey = screeningCacheKey(userId, universe);
    const ttlSeconds = demoTtl(20 * 60);
    const demoForce = demoActive() ? false : c.req.query('force') === 'true'; // « Forcer » ne force rien en démo
    const { found, value, ageSeconds } = await readCacheRaw(c.env.DB, cacheKey);

    if (!demoForce) {
      if (found && ageSeconds < ttlSeconds) {
        return c.json({ ...value, cached: true, cacheAgeSeconds: Math.round(ageSeconds) });
      }
    }

    try {
      const payload = await buildScreening(c.env.DB, userId, universe);
      await writeCache(c.env.DB, cacheKey, payload, TTL.SLOW);
      return c.json({ ...payload, cached: false });
    } catch (err) {
      // Mode démo : un screening périmé vaut mieux qu'une erreur à l'écran.
      if (demoActive() && found) return c.json({ ...value, cached: true, cacheAgeSeconds: Math.round(ageSeconds), stale: true });
      if (err.passErrors) {
        return c.json({
          error: err.message,
          passErrors: err.passErrors,
          detail: Object.entries(err.passErrors).filter(([, v]) => v).map(([k, v]) => `${k} : ${v}`).join(' · '),
        }, 503);
      }
      return c.json({ error: 'Erreur interne pendant le screening', detail: err.message }, 500);
    }
  });

  // Performance des titres du dernier screening (graphique Screener,
  // 21/9/2026) — tickers fournis par le FRONTEND (déjà triés/plafonnés),
  // pas de dépendance au cache de screening.
  app.get('/api/screening/tickers', async (c) => {
    let tickers;
    try { tickers = parseTickersParam(c.req.query('tickers')); } catch (err) { return c.json({ error: err.message }, err.status || 400); }
    try { return c.json(await buildTickersScreening(c.env.DB, c.get('userId'), tickers)); } catch (err) { return c.json({ error: err.message }, 503); }
  });

  app.get('/api/screening/history', async (c) => {
    let tickers;
    try {
      tickers = parseTickersParam(c.req.query('tickers'));
    } catch (err) {
      return c.json({ error: err.message }, err.status || 400);
    }
    try {
      const series = await getScreeningPerformance(c.env.DB, tickers);
      return c.json({ series, generatedAt: new Date().toISOString() });
    } catch (err) {
      return c.json({ error: err.message }, 503);
    }
  });

  app.get('/api/screening.csv', async (c) => {
    const userId = c.get('userId');
    const { found, value } = await readCacheRaw(c.env.DB, screeningCacheKey(userId, 'watchlist'));
    if (!found) {
      return c.json({ error: "Aucun screening en cache — lancer /api/screening d'abord." }, 409);
    }
    const cols = ['ticker', 'setupScore', 'contexteScore', 'alignmentAge', 'smaAlignment', 'verdict', 'score', 'rsi', 'forceRelative', 'goldenCross', 'obvTrend', 'price', 'volume', 'floatShares', 'peRatio', 'industry', 'industryPE', 'pegRatio', 'beta', 'vwap', 'daysToEarnings', 'atr', 'priceToSales', 'sectorPS'];
    const lines = [cols.join(',')];
    for (const row of value.rows) lines.push(cols.map((c2) => csvEscape(row[c2])).join(','));
    return new Response(lines.join('\n'), {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="screening-castellana-${Date.now()}.csv"`,
      },
    });
  });
}
