// Chaînes d'options (feature bilbao #358, v1 — 20/9/2026) : Yahoo Finance direct
// via `yahooFinance.options()`, même famille que les cotations (aucun sidecar).
//
// Ce que Yahoo donne : strike, bid, ask, dernier, volume, open interest, IV,
// dans/hors de la monnaie. Ce qu'il ne donne PAS : le delta (prévu en v2, calculé
// avec le Black-Scholes du Labo). Données DIFFÉRÉES d'environ 15 minutes.
//
// Règle d'honnêteté : « pas de cotation » n'est jamais un zéro. Yahoo renvoie
// bid = ask = 0 pour un contrat sans marché ; on le traduit en null (affiché « — »).
import YahooFinance from 'yahoo-finance2';
import { withRetry } from './fetch-retry.js';
import { cached, TTL } from './cache.js';
import { optionDelta, optAnnualizedYield } from './options-analytics.js';
import { getEffectiveParams } from './labo-params.js';

const yahooFinance = new YahooFinance({ suppressNotices: ['yahooSurvey'] });

const DAY_MS = 86400000;
const EXPIRY_RE = /^\d{4}-\d{2}-\d{2}$/;

const iso = (d) => new Date(d).toISOString().slice(0, 10);
const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : null);

export function normalizeContract(c) {
  const hasQuote = num(c.bid) > 0 || num(c.ask) > 0;
  return {
    strike: num(c.strike),
    bid: hasQuote ? num(c.bid) : null,
    ask: hasQuote ? num(c.ask) : null,
    last: num(c.lastPrice),
    volume: num(c.volume),
    openInterest: num(c.openInterest),
    iv: num(c.impliedVolatility),
    itm: Boolean(c.inTheMoney),
    contractSymbol: c.contractSymbol ?? null,
  };
}

// Pure (testée) : réponse brute de yahooFinance.options() → forme de l'API.
export function normalizeChain(ticker, raw, now = Date.now()) {
  const expirations = (raw?.expirationDates ?? []).map((d) => ({
    date: iso(d),
    dte: Math.max(0, Math.ceil((new Date(d).getTime() - now) / DAY_MS)),
  }));
  const block = raw?.options?.[0];
  if (!block) return null;
  const expiry = iso(block.expirationDate);
  const byStrike = (a, b) => a.strike - b.strike;
  return {
    ticker,
    price: num(raw.quote?.regularMarketPrice),
    expiry,
    dte: expirations.find((e) => e.date === expiry)?.dte ?? null,
    expirations,
    calls: (block.calls ?? []).map(normalizeContract).sort(byStrike),
    puts: (block.puts ?? []).map(normalizeContract).sort(byStrike),
    fetchedAt: new Date(now).toISOString(),
    delayed: true,
  };
}

export async function getOptionChain(ticker, { expiry = null, force = false } = {}) {
  if (expiry && !EXPIRY_RE.test(expiry)) {
    throw Object.assign(new Error('Échéance invalide — format attendu AAAA-MM-JJ.'), { status: 400 });
  }
  const key = `options:v1:${ticker}:${expiry || 'nearest'}`;
  return cached(key, TTL.OPTIONS, async () => {
    const query = expiry ? { date: new Date(`${expiry}T00:00:00Z`) } : {};
    const raw = await withRetry(`chaîne d'options Yahoo (${ticker})`, () => yahooFinance.options(ticker, query)).catch((err) => {
      // Un symbole inconnu ressort de la bibliothèque en « Failed Yahoo Schema validation » : illisible.
      if (/Schema validation|Not Found|No data/i.test(err.message)) {
        throw Object.assign(new Error(`Symbole « ${ticker} » inconnu ou sans options cotées.`), { status: 404 });
      }
      throw err;
    });
    const chain = normalizeChain(ticker, raw);
    if (!chain) {
      throw Object.assign(new Error(`Aucune chaîne d'options pour ${ticker}${expiry ? ` au ${expiry}` : ''} (titre sans options, ou échéance inconnue).`), { status: 404 });
    }
    return chain;
  }, { force });
}

// #11 (Options A, 22/9/2026) — grille de rendement annualisé sur plusieurs
// échéances à venir. Une échéance à la fois (chaque appel réutilise le cache
// options:v1:<ticker>:<expiry> déjà en place — pas de coût réseau
// supplémentaire pour une échéance déjà consultée). Pour chaque échéance : le
// contrat dans la plage de delta demandée au meilleur rendement annualisé
// (le point qui intéresse un vendeur de primes) ; échéance ignorée si aucun
// contrat n'entre dans la plage — jamais une ligne inventée.
export async function getAnnualizedGrid(ticker, { type = 'put', deltaMin = 0.15, deltaMax = 0.25, maxExpiries = 6 } = {}) {
  const first = await getOptionChain(ticker);
  const { riskFreePct } = getEffectiveParams('roue') || { riskFreePct: 4 };
  const r = riskFreePct / 100;
  const list = (first.expirations || []).slice(0, Math.max(1, Math.min(maxExpiries, 8)));
  const rows = [];
  for (const e of list) {
    const ch = e.date === first.expiry ? first : await getOptionChain(ticker, { expiry: e.date });
    const contracts = type === 'call' ? ch.calls : ch.puts;
    let best = null;
    let bestYield = -Infinity;
    for (const c of contracts) {
      const delta = optionDelta(type, ch.price, c.strike, ch.dte, r, c.iv);
      if (delta == null || Math.abs(delta) < deltaMin || Math.abs(delta) > deltaMax) continue;
      const y = optAnnualizedYield(c.bid, c.strike, ch.dte);
      if (y != null && y > bestYield) { bestYield = y; best = c; }
    }
    if (best) rows.push({ expiry: ch.expiry, dte: ch.dte, strike: best.strike, premium: best.bid, annualizedYield: bestYield });
  }
  return { ticker, type, deltaMin, deltaMax, price: first.price, rows };
}
