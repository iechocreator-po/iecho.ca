// IA étape 1 (#398) — carte « Analyse » de la Fiche de trade (local, et cloud depuis le 10/10/2026
// pour les comptes dont le flag ai_analyst est actif). Copie identique dans cloud/public/js/.
// Résumé de contexte généré par IA : jamais une prédiction, sans effet sur le score
// ni sur le sizing. Le plan envoyé ne contient que des pourcentages (aucun montant).

function aiEsc(t) { return String(t ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
function aiList(title, items) {
  if (!items || !items.length) return '';
  return '<div class="ai-block"><strong>' + title + '</strong><ul>' + items.map((x) => '<li>' + aiEsc(x) + '</li>').join('') + '</ul></div>';
}

// Plan en ratios seulement : jamais capital, taille ni montants.
function aiCollectPlan() {
  const g = (id) => document.getElementById(id);
  const entry = +g('entry')?.value, atr = +g('atr')?.value, atrMult = +g('atrmult')?.value;
  const stopPct = entry > 0 && atr > 0 && atrMult > 0 ? (atr * atrMult / entry) * 100 : null;
  const heat = parseFloat((g('m-heat')?.textContent || '').replace(',', '.'));
  return {
    stopPct: stopPct != null ? +stopPct.toFixed(2) : null,
    riskPct: +g('riskpct')?.value || null,
    atrMult: atrMult || null,
    atrPct: entry > 0 && atr > 0 ? +((atr / entry) * 100).toFixed(2) : null,
    heatPct: Number.isFinite(heat) ? heat : null,
    correlated: g('correlated')?.value === 'oui',
    liquidity: g('liq')?.value || null,
  };
}

function aiRenderResult(r) {
  const a = r.analysis;
  const date = r.createdAt ? new Date(r.createdAt.replace(' ', 'T') + (r.createdAt.endsWith('Z') || r.createdAt.includes('T') ? '' : 'Z')).toLocaleString('fr-CA') : '';
  const cost = r.fromCache ? 'depuis le cache — aucun coût' : (r.costUsd != null ? 'coût estimé ' + r.costUsd.toFixed(4) + ' $' : '');
  const news = a.actualites.length
    ? '<div class="ai-block"><strong>Actualités récentes</strong><ul>' + a.actualites.map((n) =>
        '<li><a href="' + aiEsc(n.url) + '" target="_blank" rel="noopener noreferrer">' + aiEsc(n.titre) + '</a> — ' + aiEsc(n.source) + ', ' + aiEsc(n.date) +
        (n.pertinence ? '<br><span class="ds-text-muted">' + aiEsc(n.pertinence) + '</span>' : '') + '</li>').join('') + '</ul></div>'
    : '<div class="ai-block"><strong>Actualités récentes</strong><p class="ds-text-muted">Aucune actualité disponible.</p></div>';
  return (r.ticker ? '<p><strong>' + aiEsc(r.ticker) + '</strong></p>' : '') + '<p class="ai-warn">⚠ Résumé généré par IA, non vérifié — ce n\'est pas une prédiction. Vérifie chaque source.</p>' +
    '<p>' + aiEsc(a.resume) + '</p>' + news +
    '<div class="ai-block"><strong>Résultats</strong><p>' + aiEsc(a.resultats || 'non disponible') + '</p></div>' +
    aiList('Risques', a.risques) + aiList('Ce qui contredit le signal technique', a.contradictions_signal) +
    aiList('Critique du plan de trade', a.critique_plan) + aiList('Non disponible', a.non_disponible) +
    '<p class="metric-sub" style="text-align:left;">' + aiEsc(r.model) + ' · ' + aiEsc(date) + ' · ' + cost + '</p>';
}

function aiCurrentTicker() { return (document.getElementById('ticker')?.value || '').trim().toUpperCase(); }
async function aiAnalyse(force) {
  const host = document.getElementById('ai-result'), st = document.getElementById('ai-status');
  const ticker = (document.getElementById('ticker')?.value || '').trim().toUpperCase();
  if (!ticker) { st.textContent = 'Renseigne d\'abord un symbole.'; return; }
  st.textContent = 'Analyse en cours…';
  try {
    const r = await fetchJSON('/api/ai/analyse/' + encodeURIComponent(ticker), {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ plan: aiCollectPlan(), force: !!force }),
    });
    // La réponse peut arriver après un changement de symbole (jusqu'à 60 s avec Claude) : on n'écrase pas la carte d'un autre titre.
    if (aiCurrentTicker() !== ticker) { st.textContent = 'Analyse de ' + ticker + ' terminée, mais le symbole a changé : relance l\'analyse pour ' + aiCurrentTicker() + '.'; return; }
    host.innerHTML = aiRenderResult(r);
    st.textContent = '';
  } catch (err) { st.textContent = err.message; }
}

async function loadAiLast() {
  const host = document.getElementById('ai-result');
  const ticker = (document.getElementById('ticker')?.value || '').trim().toUpperCase();
  if (!host || !ticker) return;
  try {
    const r = await fetchJSON('/api/ai/analyse/' + encodeURIComponent(ticker));
    if (aiCurrentTicker() !== ticker) return; // réponse arrivée après un changement de symbole
    host.innerHTML = r.analysis ? aiRenderResult(r) : '';
  } catch { if (aiCurrentTicker() === ticker) host.innerHTML = ''; }
}

let aiLastSettings = null;
function aiProviderChanged() {
  const ollama = document.getElementById('ai-provider').value === 'ollama';
  document.getElementById('ai-claude-fields').style.display = ollama ? 'none' : '';
  document.getElementById('ai-budget-field').style.display = ollama ? 'none' : '';
  document.getElementById('ai-ollama-fields').style.display = ollama ? '' : 'none';
}

async function loadAiSettings() {
  const st = document.getElementById('ai-settings-status');
  if (!document.getElementById('ai-settings-card') || document.getElementById('ai-settings-card').style.display === 'none') return;
  try {
    const [d, o] = await Promise.all([fetchJSON('/api/ai/settings'), fetchJSON('/api/ai/ollama-models')]);
    aiLastSettings = d;
    document.getElementById('ai-provider').innerHTML = d.providers.map((p) => '<option value="' + p.id + '"' + (p.id === d.provider ? ' selected' : '') + '>' + aiEsc(p.label) + '</option>').join('');
    document.getElementById('ai-model').innerHTML = d.models.map((m) => '<option value="' + m.id + '"' + (m.id === d.model ? ' selected' : '') + '>' + aiEsc(m.label) + '</option>').join('');
    document.getElementById('ai-budget').value = d.budgetUsd;
    const names = o.models.slice();
    if (d.ollamaModel && !names.includes(d.ollamaModel)) names.unshift(d.ollamaModel);
    document.getElementById('ai-ollama-model').innerHTML = names.length
      ? names.map((n) => '<option value="' + aiEsc(n) + '"' + (n === d.ollamaModel ? ' selected' : '') + '>' + aiEsc(n) + '</option>').join('')
      : '<option value="">(aucun modèle trouvé)</option>';
    document.getElementById('ai-settings-note').textContent =
      'Claude — dépensé ce mois-ci : ' + d.spentUsd.toFixed(4) + ' $ (estimation)' + (d.keyAvailable ? '.' : ' ; clé ANTHROPIC_API_KEY absente du .env local. ') +
      ' LLM local — ' + (o.available ? o.models.length + ' modèle(s) détecté(s) dans Ollama.' : 'Ollama injoignable (lance-le pour utiliser le LLM local).');
    aiProviderChanged();
    st.textContent = '';
  } catch (err) { st.textContent = 'Indisponible : ' + err.message; }
}

async function saveAiSettings() {
  const st = document.getElementById('ai-settings-status');
  const patch = { provider: document.getElementById('ai-provider').value };
  if (patch.provider === 'ollama') patch.ollamaModel = document.getElementById('ai-ollama-model').value;
  else { patch.model = document.getElementById('ai-model').value; patch.budgetUsd = +document.getElementById('ai-budget').value; }
  try {
    await fetchJSON('/api/ai/settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(patch) });
    await loadAiSettings();
    st.textContent = 'Enregistré.';
  } catch (err) { st.textContent = err.message; }
}

// Flag ai_analyst (OFF par défaut) : carte et réglages cachés tant qu'il n'est pas confirmé ON.
async function initAiVisibility() {
  try {
    const { flags } = await fetchJSON('/api/flags');
    if (flags && flags.ai_analyst === true) {
      const card = document.getElementById('fic-ai-card');
      if (card) card.style.display = '';
      const settingsCard = document.getElementById('ai-settings-card'); // local seulement
      if (settingsCard) settingsCard.style.display = '';
    }
  } catch { /* reste caché */ }
}

document.addEventListener('change', (e) => { if (e.target && e.target.id === 'ticker') loadAiLast(); });
