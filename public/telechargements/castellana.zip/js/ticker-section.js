// js/ticker-section.js — Génère le HTML de la section "Ticker" (Force
// relative + Golden Cross, + Fondamentaux en option) pour une instance
// donnée (sec/scr) — T7 (6/9/2026, demande de JP).
//
// Contexte : la carte "Ticker" de l'onglet Secteurs a grossi (fusion avec
// Force relative/Golden Cross + ajout de 9 champs fondamentaux, 5/9/2026),
// alors que la carte homonyme de l'onglet Screener est restée plus simple
// (pas de fondamentaux, sur 3 cartes séparées) — les deux étaient jusque-là
// dupliquées à la main dans index.html, et divergeaient donc dès qu'on
// touchait l'une sans penser à l'autre. Ce fichier remplace la duplication
// par UNE fonction, appelée deux fois avec des options différentes :
//   renderTickerSectionInto('sec', { withFundamentals: true });
//   renderTickerSectionInto('scr', { withFundamentals: false });
// Les IDs générés suivent la convention déjà utilisée partout ailleurs
// dans l'app (`${instanceKey}-xxx`, voir SELECTION_INSTANCES dans
// index.html) — calcSelectionFor()/fetchLiveSelectionFor() n'ont pas
// changé, ils continuent de lire/écrire les mêmes IDs, juste injectés
// dynamiquement au lieu d'être écrits en dur dans le HTML.

function tickerSectionHTML(instanceKey, { withFundamentals }) {
  const p = instanceKey;
  const fundamentalsBlock = withFundamentals ? `
    <div class="colhead" style="margin-top:1.1rem;">Fondamentaux</div>
    <div class="grid-3">
      <div class="ds-metric"><div class="ds-metric__label">OBV (tendance, 10j)</div><div class="ds-metric__value" id="${p}-m-obv">—</div></div>
      <div class="ds-metric"><div class="ds-metric__label">Volume (jour)</div><div class="ds-metric__value" id="${p}-m-volume">—</div></div>
      <div class="ds-metric"><div class="ds-metric__label">Float</div><div class="ds-metric__value" id="${p}-m-float">—</div></div>
      <div class="ds-metric"><div class="ds-metric__label">P/E (trailing)</div><div class="ds-metric__value" id="${p}-m-pe">—</div></div>
      <div class="ds-metric"><div class="ds-metric__label">Industrie</div><div class="ds-metric__value" id="${p}-m-industry" style="font-size:15px;">—</div></div>
      <div class="ds-metric"><div class="ds-metric__label">P/E industrie</div><div class="ds-metric__value" id="${p}-m-industry-pe">—</div><div class="ds-metric__sub" id="${p}-m-industry-pe-sub"></div></div>
      <div class="ds-metric"><div class="ds-metric__label">PEG</div><div class="ds-metric__value" id="${p}-m-peg">—</div></div>
      <div class="ds-metric"><div class="ds-metric__label">Beta (5 ans)</div><div class="ds-metric__value" id="${p}-m-beta">—</div></div>
      <div class="ds-metric"><div class="ds-metric__label">VWAP (séance en cours)</div><div class="ds-metric__value" id="${p}-m-vwap">—</div></div>
    </div>
    <p class="metric-sub" style="text-align:left;">Volume (jour)/Float/P-E (trailing)/Industrie/PEG/Beta (5 ans)/VWAP (séance en cours) via Yahoo Finance (fundamentals.js) ; OBV via calcul maison sur 10 jours (indicators.js). P/E industrie = moyenne des pairs de la watchlist partageant la même industrie, depuis le dernier screening en cache — « — » si aucun screening n'a encore été lancé (onglet Screener). VWAP affiche « — » hors séance (aucune barre intraday disponible).</p>
  ` : '';

  return `
    <div class="section-title">Ticker</div>
    <div class="row">
      <label>Ticker évalué</label>
      <input class="ds-input" type="text" id="${p}-ticker" style="text-transform:uppercase; max-width:120px;" oninput="calcSelectionFor('${p}')">
      <button type="button" class="ds-btn" onclick="fetchLiveSelectionFor('${p}')">Récupérer en direct</button>
    </div>
    <p class="metric-sub" id="${p}-live-status" style="text-align:left; margin-top:4px;"></p>
    ${fundamentalsBlock}
    <div class="colhead" style="margin-top:1.25rem;">Force relative vs indice de référence (S&amp;P 500 — SPY) <button type="button" class="info-btn" onclick="showGlossaire('forceRelative', this)" title="Aide">i</button></div>
    <div class="row">
      <label>Performance du titre (%, jour — ou saisis une autre période à la main)</label>
      <input class="ds-input" type="number" id="${p}-perfTitre" value="12" step="0.1" oninput="calcSelectionFor('${p}')">
    </div>
    <div class="row">
      <label>Performance du S&amp;P 500 (SPY) sur la même période (%)</label>
      <input class="ds-input" type="number" id="${p}-perfIndice" value="8" step="0.1" oninput="calcSelectionFor('${p}')">
    </div>
    <div class="row">
      <label>Écart de force relative</label>
      <span class="val" id="${p}-fr-badge">—</span>
    </div>
    <p class="metric-sub" id="${p}-fr-note">—</p>

    <div class="colhead" style="margin-top:1.25rem;">Golden Cross (régime de fond) <button type="button" class="info-btn" onclick="showGlossaire('goldenCross', this)" title="Aide">i</button></div>
    <div class="row">
      <label>SMA50 actuelle</label>
      <input class="ds-input" type="number" id="${p}-sma50" value="182" step="0.01" oninput="calcSelectionFor('${p}')">
    </div>
    <div class="row">
      <label>SMA200 actuelle</label>
      <input class="ds-input" type="number" id="${p}-sma200" value="170" step="0.01" oninput="calcSelectionFor('${p}')">
    </div>
    <div class="row">
      <label>Régime</label>
      <span class="val" id="${p}-gc-badge">—</span>
    </div>
    <p class="metric-sub" id="${p}-gc-note">—</p>
  `;
}

function renderTickerSectionInto(instanceKey, options) {
  const card = document.getElementById(instanceKey + '-ticker-card');
  card.innerHTML = tickerSectionHTML(instanceKey, options);
}
