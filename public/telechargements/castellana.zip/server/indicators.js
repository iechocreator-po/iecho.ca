// Calculs maison — OBV réel, SMA 9/21/100, ATR réel et volume vs moyenne
// 20j, aucun fourni de façon fiable par tradingview-mcp (voir CLAUDE.md,
// section « Reste à calculer maison »). Source de données : Yahoo Finance
// directement, via `yahoo-finance2` (npm, non officiel mais légitime —
// même famille que `yahoo_price`/`market_snapshot` côté tradingview-mcp,
// qui se sont montrés non affectés par le rate-limit du scanner
// TradingView en test réel).
//
// Aucune dépendance à tradingview-mcp ici : ce module marche même si le
// sidecar Python est arrêté.

import YahooFinance from 'yahoo-finance2';

const yahooFinance = new YahooFinance({ suppressNotices: ['yahooSurvey'] });

// Période ATR — dupliquée de config.js (CFG.indicateurs.atrPeriode) faute
// de format de module commun entre le frontend classique et ce backend
// ESM, même limitation que SCORE_BANDS dans server/index.js.
const ATR_PERIOD = 14;

// Vérif de connectivité pour l'indicateur de statut du frontend — appel
// Yahoo Finance minimal (cotation SPY, pas un historique complet), pour
// tester ce module directement plutôt que de passer par le sidecar MCP
// (yahoo_price y transiterait par tradingview-mcp, ce qui ne testerait pas
// vraiment `yahoo-finance2`). Retourne le détail de l'erreur (30/8/2026,
// demande de JP d'être explicite sur la nature du problème technique)
// plutôt qu'un simple booléen qui masque la cause.
export async function checkYahooConnection() {
  try {
    await yahooFinance.quote('SPY');
    return { ok: true, detail: null };
  } catch (err) {
    return { ok: false, detail: err.message };
  }
}

export async function fetchDailyHistory(symbol, lookbackDays = 300) {
  const now = new Date();
  const start = new Date(now.getTime() - lookbackDays * 24 * 3600 * 1000);
  const result = await yahooFinance.chart(symbol, { period1: start, period2: now, interval: '1d' });
  return result.quotes.filter((q) => q.close != null && q.volume != null);
}

// SMA (Simple Moving Average) — moyenne mobile SIMPLE, fenêtre glissante :
// SMA[i] = moyenne des `period` dernières clôtures. C'est la moyenne utilisée
// pour le filtre de tendance 9/21/100 (design_assistant_swing_trading.md
// section 4.1, révisé 29/8/2026 — JP a demandé de standardiser sur SMA après
// avoir relevé une incohérence de terminologie dans les capsules d'aide,
// SMMA d'un côté et MM de l'autre pour ce qui devait être le même type de
// moyenne). Retourne un tableau aligné sur `closes` (null tant que la
// fenêtre n'est pas encore remplie).
export function computeSMA(closes, period) {
  const out = new Array(closes.length).fill(null);
  if (closes.length < period) return out;
  let sum = 0;
  for (let i = 0; i < period; i++) sum += closes[i];
  out[period - 1] = sum / period;
  for (let i = period; i < closes.length; i++) {
    sum += closes[i] - closes[i - period];
    out[i] = sum / period;
  }
  return out;
}

// RMA (Wilder/smoothed) — PAS une SMA, gardée séparée et réservée au lissage
// de l'ATR (section suivante), qui est standard en RMA par définition
// (l'ATR de Wilder EST une RMA appliquée au True Range). Ne sert plus au
// filtre de tendance depuis la révision ci-dessus.
function computeRMA(closes, period) {
  const out = new Array(closes.length).fill(null);
  if (closes.length < period) return out;
  let sum = 0;
  for (let i = 0; i < period; i++) sum += closes[i];
  out[period - 1] = sum / period;
  for (let i = period; i < closes.length; i++) {
    out[i] = (out[i - 1] * (period - 1) + closes[i]) / period;
  }
  return out;
}

// OBV réel (cumulatif) — design_assistant_swing_trading.md section 4.4.
// +volume si clôture > veille, -volume si <, inchangé si =.
export function computeOBV(bars) {
  const out = new Array(bars.length).fill(0);
  for (let i = 1; i < bars.length; i++) {
    if (bars[i].close > bars[i - 1].close) out[i] = out[i - 1] + bars[i].volume;
    else if (bars[i].close < bars[i - 1].close) out[i] = out[i - 1] - bars[i].volume;
    else out[i] = out[i - 1];
  }
  return out;
}

// True Range puis ATR (Wilder) — lissage RMA (computeRMA ci-dessus, PAS
// computeSMA : l'ATR de Wilder est une RMA appliquée au True Range, pas une
// coïncidence de notation, et ce n'est pas concerné par la révision
// SMMA→SMA du filtre de tendance). TR[0] = high-low faute de clôture veille.
export function computeTrueRange(bars) {
  const out = new Array(bars.length).fill(null);
  if (bars.length === 0) return out;
  out[0] = bars[0].high - bars[0].low;
  for (let i = 1; i < bars.length; i++) {
    const h = bars[i].high;
    const l = bars[i].low;
    const pc = bars[i - 1].close;
    out[i] = Math.max(h - l, Math.abs(h - pc), Math.abs(l - pc));
  }
  return out;
}

export function computeATR(bars, period = ATR_PERIOD) {
  return computeRMA(computeTrueRange(bars), period);
}

// Volume du jour vs moyenne des 20 jours PRÉCÉDENTS (jour courant exclu de
// sa propre moyenne, sinon un jour à fort volume gonflerait sa propre
// référence) — même principe que le champ `volume.SMA20` que
// tradingview-mcp tente de fournir sans succès en pratique.
export function computeVolumeVs20d(bars) {
  const n = bars.length;
  if (n < 21) return { ratio: null, volumeSMA20: null };
  const window = bars.slice(n - 21, n - 1).map((b) => b.volume);
  const avg = window.reduce((a, b) => a + b, 0) / window.length;
  const current = bars[n - 1].volume;
  return { ratio: avg > 0 ? current / avg : null, volumeSMA20: avg };
}

// Volatilité historique annualisée (écart-type des rendements logarithmiques
// quotidiens × racine(252) jours de bourse) — utilisée par l'onglet Labo
// (server/index.js, /api/labo/:ticker) pour estimer un strike correspondant
// à un delta cible via Black-Scholes (js/strategies-labo.js).
//
// AVERTISSEMENT IMPORTANT, à ne jamais perdre en modifiant ce code : c'est
// une volatilité HISTORIQUE (réalisée, calculée sur les prix passés), pas
// la volatilité IMPLICITE que le marché utilise réellement pour pricer les
// options (celle-ci intègre les attentes futures — earnings à venir,
// événements macro — que l'historique ne voit pas). C'est un PROXY
// couramment utilisé faute de source de volatilité implicite dans cette
// app, jamais un remplacement exact.
//
// `lookback` = nombre de jours de bourse utilisés (60 ≈ 3 mois de
// négociation) — fixe pour l'instant, pas encore exposé comme paramètre UI.
export function computeHistoricalVolatility(closes, lookback = 60) {
  const n = closes.length;
  const start = Math.max(1, n - lookback);
  const returns = [];
  for (let i = start; i < n; i++) {
    if (closes[i - 1] > 0 && closes[i] > 0) returns.push(Math.log(closes[i] / closes[i - 1]));
  }
  if (returns.length < 10) return null;
  const mean = returns.reduce((a, b) => a + b, 0) / returns.length;
  const variance = returns.reduce((a, b) => a + (b - mean) ** 2, 0) / (returns.length - 1);
  return Math.sqrt(variance) * Math.sqrt(252);
}

// Approxime "accumulation" (OBV confirme la tendance) / "distribution"
// (diverge) / "neutre" (design doc section 4.4) : compare la variation de
// l'OBV et celle du prix sur les `window` dernières barres. Même signe =
// confirme, signes opposés = diverge. C'est une approximation raisonnable,
// pas la détection de divergence formelle (pics/creux) — documenté comme
// tel, à affiner si l'usage réel montre des faux signaux.
function classifyOBV(obv, closes, window = 10) {
  const n = obv.length;
  if (n < window + 1) return 'neutre';
  const priceChange = closes[n - 1] - closes[n - 1 - window];
  const obvChange = obv[n - 1] - obv[n - 1 - window];
  if (Math.abs(priceChange) < 1e-9 || Math.abs(obvChange) < 1e-9) return 'neutre';
  return (priceChange > 0) === (obvChange > 0) ? 'accumulation' : 'distribution';
}

// Point d'entrée — un seul appel Yahoo Finance (historique), tout calculé
// localement dessus. Lève si Yahoo est injoignable ou l'historique trop
// court ; à l'appelant de gérer (503 / ligne "erreur" selon le contexte).
//
// `periods` (5/9/2026, demande de JP T3 — onglet Labo) : les 3 périodes du
// filtre de tendance sont surchageables par l'appelant, avec 9/21/100 en
// défaut (comportement inchangé pour tous les appelants existants —
// screening, market-data — qui n'en passent pas). Seule la route
// GET /api/labo/:ticker (server/index.js) les passe explicitement,
// reflétant les valeurs saisies dans l'onglet Labo. Avant cette révision,
// CFG.indicateurs.smaRapide/Moyenne/Lente (config.js) changeait les
// LIBELLÉS affichés sans jamais changer ce calcul — écart réel corrigé ici,
// pas seulement un ajout.
export async function getHomemadeIndicators(symbol, { periods } = {}) {
  const { fast = 9, medium = 21, slow = 100 } = periods || {};
  const bars = await fetchDailyHistory(symbol);
  if (bars.length < slow) {
    throw new Error(`historique insuffisant pour ${symbol} (${bars.length} barres, ${slow} requises pour la SMA la plus lente)`);
  }
  const closes = bars.map((b) => b.close);
  const n = closes.length;
  const smaFast = computeSMA(closes, fast);
  const smaMedium = computeSMA(closes, medium);
  const smaSlow = computeSMA(closes, slow);
  const obv = computeOBV(bars);

  const sF = smaFast[n - 1];
  const sM = smaMedium[n - 1];
  const sS = smaSlow[n - 1];
  const close = closes[n - 1];

  let smaAlignment = 'neutre';
  if (close > sF && sF > sM && sM > sS) smaAlignment = 'haussier';
  else if (close < sF && sF < sM && sM < sS) smaAlignment = 'baissier';

  const atrSeries = computeATR(bars);
  const volumeInfo = computeVolumeVs20d(bars);
  const historicalVolatility = computeHistoricalVolatility(closes);

  return {
    sma9: sF,
    sma21: sM,
    sma100: sS,
    smaPeriods: { fast, medium, slow },
    smaAlignment,
    obv: obv[n - 1],
    obvTrend: classifyOBV(obv, closes),
    atr: atrSeries[n - 1],
    volumeRatio: volumeInfo.ratio,
    volumeSMA20: volumeInfo.volumeSMA20,
    historicalVolatility,
    barsUsed: n,
  };
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Version batch pour le screening — séquentiel avec un délai léger (Yahoo
// Finance direct n'a pas montré le rate-limit observé sur le scanner
// TradingView, mais mieux vaut rester poli qu'enchaîner 20 requêtes à
// vitesse maximale). Un titre en échec ressort avec `error` rempli, sans
// interrompre le reste du batch — même principe que screenWatchlist().
export async function getHomemadeIndicatorsBatch(tickers, { delayMs = 400 } = {}) {
  const results = [];
  for (const ticker of tickers) {
    try {
      const data = await getHomemadeIndicators(ticker);
      results.push({ ticker, ...data, error: null });
    } catch (err) {
      results.push({
        ticker,
        sma9: null,
        sma21: null,
        sma100: null,
        smaPeriods: null,
        smaAlignment: null,
        obv: null,
        obvTrend: null,
        atr: null,
        volumeRatio: null,
        volumeSMA20: null,
        historicalVolatility: null,
        error: err.message,
      });
    }
    await sleep(delayMs);
  }
  return results;
}
