#!/usr/bin/env node
// Migration idempotente (12/10/2026) — onglet Anticipation : votes et propositions par compte.
// CREATE TABLE IF NOT EXISTS : rejouable, aucune donnée existante touchée. `schema.sql` reste la
// source de vérité pour une installation neuve.
//
// ⚠️ À lancer en --remote AVANT `wrangler deploy` (le code déployé lit ces tables), puis vérifier
// avec sqlite_master — pas sur le seul message de fin.
//
// Usage :
//   node scripts/migrate-anticipation.mjs             (D1 local)
//   node scripts/migrate-anticipation.mjs --remote    (vrai D1)

import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const flag = process.argv.includes('--remote') ? '--remote' : '--local';

function run(sql) {
  const r = spawnSync('npx', ['wrangler', 'd1', 'execute', 'castellana-db', flag, '--command', sql], {
    cwd: ROOT, encoding: 'utf8', stdio: 'inherit',
  });
  if (r.status !== 0) process.exit(r.status || 1);
}

console.log(`Migration Anticipation (${flag})…`);
run(`CREATE TABLE IF NOT EXISTS anticipation_votes (
  user_id INTEGER NOT NULL REFERENCES users(id),
  card_id TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, card_id)
)`);
run(`CREATE TABLE IF NOT EXISTS anticipation_proposals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  titre TEXT NOT NULL,
  onglet TEXT NOT NULL,
  description TEXT NOT NULL,
  statut TEXT NOT NULL DEFAULT 'nouvelle',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
)`);
run('CREATE INDEX IF NOT EXISTS idx_anticipation_proposals_user ON anticipation_proposals (user_id, id)');
run("SELECT name FROM sqlite_master WHERE name IN ('anticipation_votes', 'anticipation_proposals', 'idx_anticipation_proposals_user')");
console.log('Terminé : vérifie que les trois noms ci-dessus sont listés.');
