// js/ticker-format.js — forme acceptée pour un symbole boursier (audit onglets, 20/10/2026, constat 1).
//
// Avant, rien ne validait un symbole : l'API et l'import d'un fichier du club le gardaient tel quel (mis en majuscules),
// et plusieurs affichages de l'onglet Roue l'écrivaient sans l'échapper dans la page. Un symbole piégé importé
// d'un fichier tiers exécutait du code dans votre session. Désormais le symbole est refusé À L'ÉCRITURE (serveur local et
// Worker cloud) et signalé à l'import, EN PLUS de l'échappement de chaque affichage.
//
// Forme : 1 à 15 caractères, majuscules, chiffres, . - ^ = (ex. AAPL, BRK-B, XEQT.TO, ^VIX, CL=F, EURUSD=X).
// SOURCE UNIQUE : navigateur (script classique), serveur local (server/ticker-format.js l'évalue) et Worker cloud (copie
// ESM générée : npm run sync:cloud). Ne contenir que des déclarations de premier niveau.
const TICKER_PATTERN = /^[A-Z0-9^][A-Z0-9.=^-]{0,14}$/;
const TICKER_ERROR = 'ticker invalide (1 à 15 caractères : lettres, chiffres, . - ^ =)';

function isValidTicker(t) {
  return typeof t === 'string' && TICKER_PATTERN.test(t.trim().toUpperCase());
}
