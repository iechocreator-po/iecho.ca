// Authentification — routes PUBLIQUES (montées AVANT le middleware de
// session dans index.js). Pas d'auto-inscription : les comptes sont créés
// par scripts/create-user.mjs (JP) ou par la console CRUD de bilbao (voir
// routes/admin.js, 19/9/2026).
//
// Magic link (19/9/2026) : s'ajoute au mot de passe, ne le remplace pas —
// décision de JP. Un compte "disabled" (console bilbao) est refusé par les
// DEUX chemins, avec le même message générique qu'un mot de passe/token
// invalide — jamais de distinction qui laisserait deviner qu'un compte
// existe mais est bloqué.

import { hashPassword, verifyPassword, generateSessionToken, sessionCookieHeader, clearSessionCookieHeader, readSessionToken, SESSION_TTL_MS } from '../auth.js';
import { findUserByUsername, findUserByEmail, findUserById, resetPassword } from '../db/users.js';
import { createSession, deleteSession, findSession, revokeOtherSessions } from '../db/sessions.js';
import { deleteConnection } from '../db/tv-oauth.js';
import { createMagicLink, findValidMagicLink, consumeMagicLink, invalidateMagicLinksForUser } from '../db/magic-links.js';
import { canSkipOldPassword, validateNewPassword, PASSWORD_MIN_LENGTH } from '../lib/password-rules.js';
import { hasEmailCredentials, sendMagicLinkLoginEmail } from '../lib/email.js';

const GENERIC_LOGIN_ERROR = "Nom d'utilisateur ou mot de passe incorrect";

export function registerAuthRoutes(app) {
  app.post('/api/auth/login', async (c) => {
    const body = await c.req.json().catch(() => ({}));
    const { username, password } = body;
    if (!username || !password) {
      return c.json({ error: "Nom d'utilisateur et mot de passe requis" }, 400);
    }
    const user = await findUserByUsername(c.env.DB, username);
    if (!user || user.disabled || !(await verifyPassword(password, user.password_hash, user.password_salt))) {
      // Message générique, volontairement identique compte inconnu / mot
      // de passe faux / compte désactivé — ne pas laisser deviner quels
      // comptes existent ou sont bloqués.
      return c.json({ error: GENERIC_LOGIN_ERROR }, 401);
    }
    const token = generateSessionToken();
    const expiresAt = Date.now() + SESSION_TTL_MS;
    await createSession(c.env.DB, user.id, token, expiresAt, 'password');
    c.header('Set-Cookie', sessionCookieHeader(token, Math.floor(SESSION_TTL_MS / 1000)));
    return c.json({ username: user.username });
  });

  // Toujours {ok:true} — que l'email corresponde à un compte actif, à un
  // compte désactivé, ou à rien du tout. Le message d'erreur lui-même est
  // une fuite d'information si on le laisse varier (voir la discipline
  // déjà appliquée au login ci-dessus). Un échec d'ENVOI (Resend en panne,
  // pas configuré) est loggé côté serveur seulement, pour la même raison.
  app.post('/api/auth/magic-link/request', async (c) => {
    const body = await c.req.json().catch(() => ({}));
    const email = typeof body.email === 'string' ? body.email.trim() : '';
    if (!email) return c.json({ error: 'Courriel requis' }, 400);
    // « Mot de passe oublié ? » (17/10/2026) : MÊME lien de connexion, même
    // réponse ; seul l'atterrissage change (&reset=1 ouvre la carte
    // « Changer mon mot de passe » une fois connecté).
    const reset = body.purpose === 'reset';

    const user = await findUserByEmail(c.env.DB, email);
    if (user && !user.disabled) {
      const token = generateSessionToken();
      await createMagicLink(c.env.DB, user.id, token);
      if (hasEmailCredentials(c.env)) {
        const url = new URL(c.req.url);
        const loginUrl = `${url.protocol}//${url.host}/?magic=${token}${reset ? '&reset=1' : ''}`;
        try {
          await sendMagicLinkLoginEmail(c.env, { to: email, url: loginUrl, reset });
        } catch (err) {
          console.error(`[magic-link] échec d'envoi à ${email} :`, err.message);
        }
      } else {
        // Pas de service d'envoi configuré (dev local, ou pas encore mis
        // en place en prod) — le token existe quand même en base, visible
        // dans les logs pour se connecter manuellement en test. JAMAIS
        // acceptable en production réelle avec de vrais testeurs.
        console.warn(`[magic-link] RESEND non configuré — token pour ${email} : ${token}`);
      }
    }
    return c.json({ ok: true });
  });

  app.post('/api/auth/magic-link/consume', async (c) => {
    const body = await c.req.json().catch(() => ({}));
    const token = typeof body.token === 'string' ? body.token : '';
    if (!token) return c.json({ error: 'Lien invalide' }, 400);

    const link = await findValidMagicLink(c.env.DB, token);
    if (!link || link.disabled) {
      return c.json({ error: 'Ce lien est invalide, déjà utilisé, expiré, ou ce compte est désactivé.' }, 401);
    }
    if (!(await consumeMagicLink(c.env.DB, token))) {
      return c.json({ error: 'Ce lien est invalide, déjà utilisé, expiré, ou ce compte est désactivé.' }, 401);
    }

    const sessionToken = generateSessionToken();
    const expiresAt = Date.now() + SESSION_TTL_MS;
    await createSession(c.env.DB, link.userId, sessionToken, expiresAt, 'magic_link');
    c.header('Set-Cookie', sessionCookieHeader(sessionToken, Math.floor(SESSION_TTL_MS / 1000)));
    return c.json({ username: link.username });
  });

  app.post('/api/auth/logout', async (c) => {
    const token = readSessionToken(c.req.header('Cookie'));
    if (token) {
      // Jetons TradingView effacés explicitement (en plus du ON DELETE CASCADE).
      await deleteConnection(c.env.DB, token);
      await deleteSession(c.env.DB, token);
    }
    c.header('Set-Cookie', clearSessionCookieHeader());
    return c.json({ ok: true });
  });

  app.get('/api/auth/me', async (c) => {
    const token = readSessionToken(c.req.header('Cookie'));
    if (!token) return c.json({ error: 'Non authentifié' }, 401);
    const session = await findSession(c.env.DB, token);
    if (!session) return c.json({ error: 'Non authentifié' }, 401);
    // canChangeWithoutOld : l'écran n'affiche pas le champ « ancien mot de
    // passe » (session ouverte par lien de courriel il y a moins de 15 min).
    return c.json({ username: session.username, method: session.method || 'password', canChangeWithoutOld: canSkipOldPassword(session) });
  });

  // Changement de mot de passe (17/10/2026). /api/auth/* est public dans
  // index.js : la session est donc vérifiée ICI. L'ancien mot de passe est
  // exigé sauf session ouverte par lien de courriel depuis moins de 15 min
  // (lib/password-rules.js). Après changement : autres sessions du compte
  // supprimées, liens de courriel encore valides invalidés, et la session
  // courante perd son passe-droit.
  app.post('/api/auth/password', async (c) => {
    const token = readSessionToken(c.req.header('Cookie'));
    const session = token ? await findSession(c.env.DB, token) : null;
    if (!session) return c.json({ error: 'Non authentifié' }, 401);
    const user = await findUserById(c.env.DB, session.userId);
    if (!user || user.disabled) return c.json({ error: 'Non authentifié' }, 401);

    const body = await c.req.json().catch(() => ({}));
    const newPassword = body.newPassword;
    const invalid = validateNewPassword(newPassword, { username: user.username });
    if (invalid) return c.json({ error: invalid, minLength: PASSWORD_MIN_LENGTH }, 400);

    if (!canSkipOldPassword(session)) {
      const old = typeof body.oldPassword === 'string' ? body.oldPassword : '';
      if (!old) return c.json({ error: 'Mot de passe actuel requis', code: 'OLD_REQUIRED' }, 400);
      if (!(await verifyPassword(old, user.password_hash, user.password_salt))) {
        return c.json({ error: 'Mot de passe actuel incorrect', code: 'OLD_WRONG' }, 403);
      }
    }

    const { hash, salt } = await hashPassword(newPassword);
    await resetPassword(c.env.DB, user.id, hash, salt);
    const revoked = await revokeOtherSessions(c.env.DB, user.id, session.token);
    await invalidateMagicLinksForUser(c.env.DB, user.id);
    return c.json({ ok: true, otherSessionsClosed: revoked });
  });
}
