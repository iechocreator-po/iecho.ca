import { getPreferences, setPreferences, resetPreferences, DEFAULTS, getFundamentalWeights, setFundamentalWeights, resetFundamentalWeights, WEIGHT_DEFAULTS } from '../db/preferences.js';
import { screeningCacheKey } from '../lib/screening.js';

// Le screening en cache (les deux univers) a été calculé avec les
// ANCIENNES périodes — le garder afficherait des RSI/alignements qui ne
// correspondent plus aux réglages affichés.
async function bustScreeningCache(db, userId) {
  // Toutes les listes, pas seulement la watchlist et l'élargi : le compte de ce compte uniquement (audit routes locales, 21/10/2026).
  const base = screeningCacheKey(userId, 'watchlist');
  await db.batch([
    db.prepare('DELETE FROM cache WHERE key = ?').bind(base),
    db.prepare('DELETE FROM cache WHERE key LIKE ?').bind(`${base}:%`),
  ]);
}

export function registerPreferencesRoutes(app) {
  // Pondération du score fondamental (2/10/2026) — par utilisateur.
  app.get('/api/fundamental-weights', async (c) => {
    return c.json({ weights: await getFundamentalWeights(c.env.DB, c.get('userId')), defaults: WEIGHT_DEFAULTS });
  });
  app.put('/api/fundamental-weights', async (c) => {
    try {
      const body = await c.req.json().catch(() => ({}));
      return c.json({ weights: await setFundamentalWeights(c.env.DB, c.get('userId'), body || {}), defaults: WEIGHT_DEFAULTS });
    } catch (err) {
      return c.json({ error: err.message }, err.code === 'INVALID_PREFERENCES' ? 400 : 500);
    }
  });
  app.post('/api/fundamental-weights/reset', async (c) => {
    return c.json({ weights: await resetFundamentalWeights(c.env.DB, c.get('userId')), defaults: WEIGHT_DEFAULTS });
  });

  app.get('/api/preferences', async (c) => {
    const prefs = await getPreferences(c.env.DB, c.get('userId'));
    return c.json({ preferences: prefs, defaults: DEFAULTS });
  });

  app.put('/api/preferences', async (c) => {
    const userId = c.get('userId');
    try {
      const body = await c.req.json().catch(() => ({}));
      const prefs = await setPreferences(c.env.DB, userId, body || {});
      await bustScreeningCache(c.env.DB, userId);
      return c.json({ preferences: prefs, defaults: DEFAULTS });
    } catch (err) {
      const status = err.code === 'INVALID_PREFERENCES' ? 400 : 500;
      return c.json({ error: err.message }, status);
    }
  });

  app.post('/api/preferences/reset', async (c) => {
    const userId = c.get('userId');
    const prefs = await resetPreferences(c.env.DB, userId);
    await bustScreeningCache(c.env.DB, userId);
    return c.json({ preferences: prefs, defaults: DEFAULTS });
  });
}
