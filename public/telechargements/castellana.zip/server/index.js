import express from 'express';
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { db } from './db.js';
import { getTechnicalAnalysis, checkSidecarConnection, isSidecarEnabled } from './tradingview.js';
import { getHomemadeIndicators, getHomemadeIndicatorsBatch, checkYahooConnection } from './indicators.js';
import { getQuotes, getRelativeStrength, BENCHMARK_SYMBOL } from './quotes.js';
import { seedWatchlistIfEmpty, getWatchlist, addToWatchlist, removeFromWatchlist } from './watchlist.js';
import { createTrade, listTrades, getTrade, updateTrade, deleteTrade, validateTrade, COLUMNS as TRADE_COLUMNS } from './trades.js';
import { getFundamentals, getFundamentalsBatch } from './fundamentals.js';
import { getSectorPerformance, getSectorHistory, getTopMoversForSector, SECTOR_ETF_TO_YAHOO_SECTOR, SECTOR_MODES, SECTOR_DEFS } from './sectors.js';
import { computeStats } from './stats.js';
import { readCache, readCacheRaw, writeCache, purgeExpiredCache, TTL } from './cache.js';
import { getLocalVersion, checkForUpdate, applyUpdate } from './update.js';
import { getPreferences, setPreferences, resetPreferences, indicatorOptions, DEFAULTS as PREF_DEFAULTS } from './preferences.js';

// Sème la watchlist en base au premier démarrage (idempotent, no-op ensuite).
seedWatchlistIfEmpty();

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const settings = JSON.parse(readFileSync(new URL('../settings.json', import.meta.url)));

const app = express();
app.use(express.json());
app.use(express.static(ROOT));

app.get('/api/health', (req, res) => {
  const { count } = db.prepare('SELECT COUNT(*) AS count FROM trades').get();
  res.json({ status: 'ok', trades: count });
});

// Statut agrégé pour le témoin visuel du frontend (header de index.html).
// `tradingviewMcp` utilise checkSidecarConnection() (listTools(), pas
// d'appel outil) — ne consomme jamais le quota du scanner rate-limité.
// `homemade` teste juste la joignabilité de Yahoo Finance (cotation SPY,
// légère) — les calculs maison (ATR/volume/OBV/SMA) en dépendent tous.
// Chaque check remonte un `*Detail` explicite (30/8/2026, demande de JP) —
// jamais juste un booléen qui masque la vraie cause (sidecar non démarré,
// rate-limit, DB verrouillée…).
// Réglages utilisateur (feature 351, point 4) — périodes des moyennes
// mobiles et du RSI, éditables depuis Réglages → Valeur personnalisée.
// Ils PILOTENT RÉELLEMENT LE CALCUL (screening, fiche de trade, Labo), ce
// qui n'était pas le cas de leurs équivalents dans config.js : ceux-ci ne
// changeaient longtemps que les libellés affichés.
app.get('/api/preferences', (req, res) => {
  res.json({ preferences: getPreferences(), defaults: PREF_DEFAULTS });
});

app.put('/api/preferences', (req, res) => {
  try {
    const preferences = setPreferences(req.body || {});
    // Le screening en cache a été calculé avec les ANCIENNES périodes : le
    // garder afficherait des RSI et des alignements qui ne correspondent
    // plus aux réglages affichés. On le jette, il se recalculera.
    db.prepare('DELETE FROM cache WHERE key = ?').run(SCREENING_KEY);
    res.json({ preferences, defaults: PREF_DEFAULTS });
  } catch (err) {
    const status = err.code === 'INVALID_PREFERENCES' ? 400 : 500;
    res.status(status).json({ error: err.message });
  }
});

app.post('/api/preferences/reset', (req, res) => {
  const preferences = resetPreferences();
  db.prepare('DELETE FROM cache WHERE key = ?').run(SCREENING_KEY);
  res.json({ preferences, defaults: PREF_DEFAULTS });
});

// Version installée + disponibilité d'une mise à jour. Le zip téléchargé
// devenait périmé en silence : un testeur n'avait aucun moyen de savoir que
// sa copie datait. La vérification est tolérante — si le manifeste est
// injoignable, on répond « pas de mise à jour » sans jamais alarmer.
app.get('/api/version', async (req, res) => {
  if (req.query.check === 'true') {
    res.json(await checkForUpdate(settings.updateManifestUrl));
    return;
  }
  res.json({ ...getLocalVersion(), updateAvailable: false });
});

// Mise à jour en un clic. Voir l'avertissement en tête de server/update.js :
// tout est vérifié avant que quoi que ce soit ne soit remplacé, `data/`
// (le journal de trades) n'est jamais touché, et l'ancienne version est
// conservée. Le processus s'arrête ensuite : le code en mémoire est celui de
// l'ANCIENNE version tant qu'il n'a pas redémarré. Le launcher (port 4750)
// le relance automatiquement s'il tourne ; sinon l'utilisateur relance
// demarrer.command / demarrer.bat.
app.post('/api/update/apply', async (req, res) => {
  try {
    const check = await checkForUpdate(settings.updateManifestUrl);
    if (!check.updateAvailable || !check.downloadUrl) {
      res.status(409).json({ error: 'Aucune mise à jour disponible', check });
      return;
    }
    const result = await applyUpdate(check.downloadUrl);
    res.json({
      ok: true,
      ...result,
      message: 'Mise à jour installée. castellana redémarre — recharge la page dans quelques secondes.',
    });
    // Laisse la réponse partir avant de rendre la main.
    setTimeout(() => process.exit(0), 500);
  } catch (err) {
    res.status(500).json({ error: 'Mise à jour annulée', detail: err.message });
  }
});

app.get('/api/status', async (req, res) => {
  let dbOk = true;
  let dbDetail = null;
  try {
    db.prepare('SELECT 1').get();
  } catch (err) {
    dbOk = false;
    dbDetail = err.message;
  }
  const [tradingviewMcp, homemade] = await Promise.all([
    checkSidecarConnection(),
    checkYahooConnection(),
  ]);
  res.json({
    backend: true,
    db: dbOk,
    dbDetail,
    tradingviewMcp: tradingviewMcp.ok,
    // `disabled` distingue « composant optionnel non installé » de « panne ».
    // Sans lui, le frontend afficherait une pastille rouge pour le sidecar
    // chez un testeur qui n'a simplement jamais installé Python — soit,
    // depuis le 7/9/2026, le cas par défaut.
    tradingviewMcpDisabled: tradingviewMcp.disabled === true,
    tradingviewMcpDetail: tradingviewMcp.detail,
    homemade: homemade.ok,
    homemadeDetail: homemade.detail,
    checkedAt: new Date().toISOString(),
  });
});

// Pont vers le sidecar tradingview-mcp — VIX + RSI/ATR/Volume/Golden Cross
// pour un titre. Le sidecar (npm run sidecar) n'est pas géré par ce
// serveur : s'il n'est pas démarré, on répond 503 proprement plutôt que de
// planter (même patron que le GITHUB_TOKEN absent chez bilbao).
// Promise.allSettled (pas Promise.all) : VIX (market_snapshot, Yahoo),
// RSI/Golden Cross (coin_analysis, scanner TradingView) et OBV réel/SMA
// 9-21-100 (calcul maison, historique Yahoo direct — indicators.js) sont
// trois sources indépendantes — l'échec de l'une (rate-limit du scanner,
// observé en test réel) ne doit pas faire perdre les autres.
// P/E moyen "par famille d'industrie" pour UN ticker arbitraire (pas
// forcément dans la watchlist) — réutilise le dernier résultat de
// screening EN CACHE (clé SCREENING_KEY, server/cache.js) plutôt que de
// refaire un batch de 20 appels Yahoo à chaque clic sur "Récupérer en
// direct". Si aucun screening n'a encore été lancé, retourne
// explicitement `null`/0 pairs plutôt que de forcer un fetch coûteux et
// invisible pour l'utilisateur.
function industryPeerStatsFromScreeningCache(industry) {
  if (!industry) return { avgPE: null, peerCount: 0 };
  const { found, value } = readCacheRaw(SCREENING_KEY);
  if (!found) return { avgPE: null, peerCount: 0 };
  const rows = value.rows.filter((r) => r.industry === industry && r.peRatio != null);
  if (!rows.length) return { avgPE: null, peerCount: 0 };
  const avg = rows.reduce((sum, r) => sum + r.peRatio, 0) / rows.length;
  return { avgPE: avg, peerCount: rows.length };
}

// Fondamentaux (P/E, industrie, PEG, beta, float, VWAP) + OBV/volume pour la
// carte "Ticker" fusionnée de l'onglet Secteurs (5/9/2026, demande de JP
// T5) — 4ᵉ branche Promise.allSettled, indépendante des trois autres (VIX/
// RSI/Golden Cross et calculs maison), Yahoo Finance direct comme
// fundamentals.js.
app.get('/api/market-data/:ticker', async (req, res) => {
  const ticker = req.params.ticker.toUpperCase();
  const sidecarOn = isSidecarEnabled();

  // Une seule requête groupée couvre le VIX ET la cotation du titre — avant
  // le 7/9/2026 c'étaient deux appels distincts au sidecar Python
  // (`market_snapshot` puis `coin_analysis`).
  const [quotesResult, homemadeResult, fundResult, taResult] = await Promise.allSettled([
    getQuotes(['^VIX', ticker]),
    getHomemadeIndicators(ticker, indicatorOptions()),
    getFundamentals(ticker, { withVwap: true }),
    // Le sidecar n'est appelé QUE s'il est explicitement activé — sinon la
    // branche se résout immédiatement à null, sans connexion tentée.
    sidecarOn ? getTechnicalAnalysis(ticker, { exchange: req.query.exchange || 'NASDAQ' }) : Promise.resolve(null),
  ]);

  if (quotesResult.status === 'rejected' && homemadeResult.status === 'rejected' && fundResult.status === 'rejected') {
    res.status(503).json({
      error: 'Yahoo Finance injoignable',
      detail: [quotesResult.reason?.message, homemadeResult.reason?.message, fundResult.reason?.message]
        .filter(Boolean).join(' · '),
    });
    return;
  }

  const quotes = quotesResult.status === 'fulfilled' ? quotesResult.value : new Map();
  const hm = homemadeResult.status === 'fulfilled' ? homemadeResult.value : null;
  const fund = fundResult.status === 'fulfilled' ? fundResult.value : null;
  const ta = taResult.status === 'fulfilled' ? taResult.value : null;
  const industryStat = fund?.industry ? industryPeerStatsFromScreeningCache(fund.industry) : { avgPE: null, peerCount: 0 };

  res.json({
    ticker,
    vix: quotes.get('^VIX')?.price ?? null,
    // RSI, Golden Cross et SMA50/200 viennent désormais du calcul maison
    // (indicators.js, historique Yahoo). Le sidecar ne sert plus que de
    // repli quand il est activé — l'inverse exact d'avant le 7/9/2026.
    rsi: hm?.rsi ?? ta?.rsi?.value ?? null,
    goldenCross: hm?.goldenCross ?? ta?.sma?.signals?.some((x) => x.startsWith('Golden Cross')) ?? null,
    sma50: hm?.sma50 ?? ta?.sma?.sma50 ?? null,
    sma200: hm?.sma200 ?? ta?.sma?.sma200 ?? null,
    atr: hm?.atr ?? ta?.atr?.value ?? null,
    volumeRatio: hm?.volumeRatio ?? ta?.volume_analysis?.ratio ?? null,
    volumeSMA20: hm?.volumeSMA20 ?? null,
    changePercent: quotes.get(ticker)?.changePercent ?? ta?.price_data?.change_percent ?? null,
    price: quotes.get(ticker)?.price ?? hm?.price ?? fund?.price ?? null,
    // sma9/21/100 : filtre de tendance maison (fenêtre glissante), distinct
    // des SMA50/200 du Golden Cross ci-dessus.
    sma9: hm?.sma9 ?? null,
    sma21: hm?.sma21 ?? null,
    sma100: hm?.sma100 ?? null,
    // Périodes RÉELLEMENT utilisées pour ce calcul, pas celles supposées —
    // le frontend étiquette ses libellés dessus (même principe que l'onglet
    // Labo depuis le 5/9/2026).
    smaPeriods: hm?.smaPeriods ?? null,
    rsiPeriod: hm?.rsiPeriod ?? null,
    smaAlignment: hm?.smaAlignment ?? null,
    obv: hm?.obv ?? null,
    obvTrend: hm?.obvTrend ?? null,
    homemadeError: homemadeResult.status === 'rejected' ? homemadeResult.reason.message : null,
    quotesError: quotesResult.status === 'rejected' ? quotesResult.reason.message : null,
    // Non nul seulement si le sidecar est activé ET a échoué — jamais une
    // erreur pour un composant que l'utilisateur n'a pas installé.
    technicalError: sidecarOn && taResult.status === 'rejected' ? taResult.reason.message : null,
    volume: fund?.volume ?? quotes.get(ticker)?.volume ?? null,
    floatShares: fund?.floatShares ?? null,
    peRatio: fund?.peRatio ?? null,
    industry: fund?.industry ?? null,
    industryPE: industryStat.avgPE,
    industryPeerCount: industryStat.peerCount,
    pegRatio: fund?.pegRatio ?? null,
    beta: fund?.beta ?? null,
    vwap: fund?.vwap ?? null,
    aboveVwap: fund?.aboveVwap ?? null,
    fundamentalsError: fundResult.status === 'rejected' ? fundResult.reason.message : null,
  });
});

// Cotation simple — Yahoo Finance en direct (server/quotes.js) depuis le
// 7/9/2026. Elle transitait auparavant par l'outil `yahoo_price` DU SIDECAR
// (constat F6 de l'audit) : la force relative, censée survivre à une panne
// du scanner TradingView, tombait en réalité avec le processus Python.
app.get('/api/quote/:symbol', async (req, res) => {
  const symbol = req.params.symbol.toUpperCase();
  try {
    const quotes = await getQuotes([symbol]);
    const q = quotes.get(symbol);
    if (!q) {
      res.status(404).json({ error: `Ticker inconnu de Yahoo Finance : ${symbol}` });
      return;
    }
    res.json({ symbol, price: q.price, changePercent: q.changePercent });
  } catch (err) {
    res.status(503).json({ error: 'Yahoo Finance injoignable', detail: err.message });
  }
});

// Onglet Labo (5/9/2026) — données réelles d'un titre pour démontrer la
// séquence d'une stratégie d'options (server/../js/strategies-labo.js).
// Uniquement des sources Yahoo Finance directes (fundamentals.js +
// indicators.js) — volontairement PAS tradingview-mcp/coin_analysis, pour
// ne jamais dépendre du rate-limit déjà documenté sur ce chemin. Aucune
// donnée d'options (chaîne, delta, prime) n'existe dans cette app : ce
// endpoint fournit le prix + la volatilité historique réels, à partir
// desquels le frontend ESTIME un strike par Black-Scholes (jamais une
// vraie donnée d'options — voir CLAUDE.md).
//
// `smaFast`/`smaMedium`/`smaSlow` (5/9/2026, demande de JP T3) — périodes du
// filtre de tendance, réellement PASSÉES à getHomemadeIndicators() (pas
// seulement des libellés), surchageables depuis les champs visibles en haut
// de l'onglet Labo. `smaPeriods` dans la réponse confirme les valeurs
// effectivement utilisées.
//
// Depuis la feature 351 (7/9/2026), le défaut n'est plus 9/21/100 en dur
// mais les RÉGLAGES DE L'UTILISATEUR (Réglages → Valeur personnalisée) :
// deux endroits qui affichaient des périodes différentes pour le même
// indicateur auraient été une source de confusion garantie.
app.get('/api/labo/:ticker', async (req, res) => {
  const ticker = req.params.ticker.toUpperCase();
  const parsePeriod = (raw, fallback) => {
    const n = parseInt(raw, 10);
    return Number.isInteger(n) && n > 0 ? n : fallback;
  };
  const prefs = getPreferences();
  const periods = {
    fast: parsePeriod(req.query.smaFast, prefs.smaFast),
    medium: parsePeriod(req.query.smaMedium, prefs.smaMedium),
    slow: parsePeriod(req.query.smaSlow, prefs.smaSlow),
  };
  const [fundResult, indicResult] = await Promise.allSettled([
    getFundamentals(ticker, { withVwap: false }),
    getHomemadeIndicators(ticker, { periods, rsiPeriod: prefs.rsiPeriod }),
  ]);
  if (fundResult.status === 'rejected' && indicResult.status === 'rejected') {
    res.status(503).json({ error: 'Yahoo Finance injoignable pour ce titre', detail: fundResult.reason.message });
    return;
  }
  const fund = fundResult.status === 'fulfilled' ? fundResult.value : null;
  const indic = indicResult.status === 'fulfilled' ? indicResult.value : null;
  res.json({
    ticker,
    price: fund?.price ?? null,
    volume: fund?.volume ?? null,
    beta: fund?.beta ?? null,
    peRatio: fund?.peRatio ?? null,
    industry: fund?.industry ?? null,
    sector: fund?.sector ?? null,
    atr: indic?.atr ?? null,
    sma9: indic?.sma9 ?? null,
    sma21: indic?.sma21 ?? null,
    sma100: indic?.sma100 ?? null,
    smaPeriods: indic?.smaPeriods ?? periods,
    smaAlignment: indic?.smaAlignment ?? null,
    obvTrend: indic?.obvTrend ?? null,
    volumeRatio: indic?.volumeRatio ?? null,
    historicalVolatility: indic?.historicalVolatility ?? null,
    fundamentalsError: fundResult.status === 'rejected' ? fundResult.reason.message : null,
    indicatorsError: indicResult.status === 'rejected' ? indicResult.reason.message : null,
  });
});

// Performance + P/E des 11 secteurs SPDR + benchmark S&P 500 (carte
// "Performance des secteurs" de l'écran de sélection, server/sectors.js).
// Rapide (~2s, quote() simple) et pas affecté par le rate-limit de
// coin_analysis — pas de cache nécessaire ici, contrairement à
// /api/screening.
// PEG moyen par secteur (30/8/2026, demande de JP) — AUCUNE source Yahoo ne
// fournit de PEG au niveau ETF/secteur (vérifié : quote()/quoteSummary
// renvoient `undefined` pour XLK/XLF/SPY, contrairement au P/E qui, lui,
// existe réellement au niveau de l'ETF). Calculé à la place comme la
// moyenne des PEG des titres de LA WATCHLIST partageant le même secteur
// GICS large (`summaryProfile.sector`, fundamentals.js + mapping
// SECTOR_ETF_TO_YAHOO_SECTOR de sectors.js) — même principe d'approximation
// assumée que le "P/E industrie" du screening, PAS un agrégat de marché.
// Couverture nécessairement partielle : la watchlist (20 titres tech/IA)
// ne compte aucun titre dans plusieurs secteurs (Énergie, Immobilier,
// Matériaux…) — ces lignes ressortent en `null`/"—", jamais un chiffre
// inventé. `pegPeerCount` expose le nombre de titres utilisés, affiché en
// tooltip pour ne jamais laisser croire à un échantillon plus large.
// `mode` (usd|cad, 2/9/2026) sélectionne quels tickers interroger — voir
// server/sectors.js, SECTOR_DEFS. Invalide par défaut sur 'usd' plutôt que
// de planter si le paramètre est absent ou mal formé.
function parseSectorMode(req, res) {
  const mode = req.query.mode || 'usd';
  if (!SECTOR_MODES.includes(mode)) {
    res.status(400).json({ error: `mode invalide : ${mode} (attendu : ${SECTOR_MODES.join('|')})` });
    return null;
  }
  return mode;
}

app.get('/api/sectors', async (req, res) => {
  const mode = parseSectorMode(req, res);
  if (mode === null) return;
  try {
    const watchlist = getWatchlist();
    const [perf, fundamentalRows] = await Promise.all([
      getSectorPerformance({ mode }),
      getFundamentalsBatch(watchlist.map((w) => w.ticker), { withVwap: false, delayMs: 150 }),
    ]);
    const pegBySector = new Map();
    for (const f of fundamentalRows) {
      if (!f.sector || f.pegRatio == null) continue;
      if (!pegBySector.has(f.sector)) pegBySector.set(f.sector, []);
      pegBySector.get(f.sector).push(f.pegRatio);
    }
    // Jointure par `s.key` (toujours le ticker USD, stable) et non
    // `s.ticker` (qui peut être un ticker .TO en mode CAD) — sinon la
    // moyenne PEG par secteur casserait dès qu'on bascule hors USD.
    const sectorsWithPeg = perf.sectors.map((s) => {
      const values = pegBySector.get(SECTOR_ETF_TO_YAHOO_SECTOR[s.key]);
      return {
        ...s,
        pegAvg: values?.length ? values.reduce((a, b) => a + b, 0) / values.length : null,
        pegPeerCount: values?.length ?? 0,
      };
    });
    res.json({ generatedAt: new Date().toISOString(), mode, sectors: sectorsWithPeg, benchmark: perf.benchmark });
  } catch (err) {
    res.status(503).json({ error: 'Yahoo Finance injoignable', detail: err.message });
  }
});

// Historique quotidien (~13 mois) pour le line graph de performance
// sectorielle — un seul fetch, le frontend découpe par période (1S à 12M)
// et normalise en % côté client, sans refetch à chaque changement de période.
app.get('/api/sectors/history', async (req, res) => {
  const mode = parseSectorMode(req, res);
  if (mode === null) return;
  try {
    const data = await getSectorHistory({ mode });
    res.json({ generatedAt: new Date().toISOString(), mode, ...data });
  } catch (err) {
    res.status(503).json({ error: 'Yahoo Finance injoignable', detail: err.message });
  }
});

// "Titres les plus performants du secteur" (onglet Secteurs, 2/9/2026) —
// classe une liste CURATÉE par secteur (server/sectors.js,
// SECTOR_TOP_CANDIDATES) par variation du jour. PAS une requête de marché
// large — voir le commentaire détaillé dans sectors.js sur l'échec du
// screener personnalisé Yahoo (429 systématique sur un endpoint
// probablement réservé aux comptes connectés). Cache PERSISTANT par
// (sectorKey, mode-filtre) depuis le 7/9/2026 — c'était une Map en mémoire,
// perdue à chaque redémarrage (constat F8). ?force=true bypasse. Jamais un
// 200 avec rows:[] qui laisserait croire à "aucun titre" — un échec Yahoo
// devient un 503 explicite.

app.get('/api/sectors/:sectorKey/top', async (req, res) => {
  const sectorKey = req.params.sectorKey.toUpperCase();
  const filterMode = req.query.mode === 'filtered' ? 'filtered' : req.query.mode === 'raw' ? 'raw' : null;
  if (!filterMode) {
    res.status(400).json({ error: `mode invalide : ${req.query.mode} (attendu : raw|filtered)` });
    return;
  }
  if (!SECTOR_ETF_TO_YAHOO_SECTOR[sectorKey]) {
    res.status(400).json({ error: `secteur inconnu : ${sectorKey}` });
    return;
  }
  const cacheKey = `sectors:topresult:${sectorKey}:${filterMode}`;
  const ttlSeconds = (settings.sectorTopCacheMinutes ?? 20) * 60;
  const rawEntry = readCacheRaw(cacheKey);
  const cached = rawEntry.found ? { payload: rawEntry.value, timestamp: Date.now() - rawEntry.ageSeconds * 1000 } : null;
  if (req.query.force !== 'true' && cached && rawEntry.ageSeconds < ttlSeconds) {
    res.json({ ...cached.payload, cached: true });
    return;
  }
  try {
    const { rows, totalCandidates, failedCount } = await getTopMoversForSector(sectorKey, { mode: filterMode });
    const payload = {
      sectorKey,
      sectorLabel: SECTOR_DEFS.find((d) => d.key === sectorKey)?.label ?? sectorKey,
      mode: filterMode,
      generatedAt: new Date().toISOString(),
      rows,
      totalCandidates,
      failedCount,
    };
    writeCache(cacheKey, payload, ttlSeconds);
    res.json({ ...payload, cached: false });
  } catch (err) {
    res.status(503).json({ error: 'Yahoo Finance injoignable pour ce secteur', detail: err.message, sectorKey, mode: filterMode });
  }
});

// Bandes de score — dupliquées de config.js (CFG.bandes) faute de format de
// module commun entre le frontend classique <script> et ce backend ESM.
// Si les bandes de config.js changent, reporter le changement ici aussi.
const SCORE_BANDS = {
  rsiEntreeBas: 40,
  rsiEntreeHaut: 70,
  forceRelativeSeuil: 5,
};

// Seuils des filtres de screening (feature 322) — dupliqués de config.js
// (CFG.screening), même limitation de module que SCORE_BANDS. Reporter à la
// main tout changement. floatMax en millions d'actions comme config.js.
const SCREEN_FILTERS = {
  prixMin: 5,
  prixMax: 1000,
  floatMinM: 10,
  floatMaxM: 20,
  volumeMin: 1_000_000,
  pegMax: 1,
  betaMin: 1,
  calculerVwap: true,
};

// Drapeaux pass/fail par critère 322 pour une ligne enrichie de fondamentaux.
// null = donnée absente (ni pass ni fail). Le score composite N'utilise PAS
// ces drapeaux (il reste sur les 4 colonnes du design doc) — ils servent au
// filtrage optionnel de l'univers côté frontend.
function fundamentalFlags(row) {
  const floatM = row.floatShares != null ? row.floatShares / 1_000_000 : null;
  return {
    passPrix: row.price != null ? (row.price >= SCREEN_FILTERS.prixMin && row.price <= SCREEN_FILTERS.prixMax) : null,
    passFloat: floatM != null ? (floatM >= SCREEN_FILTERS.floatMinM && floatM <= SCREEN_FILTERS.floatMaxM) : null,
    passVolume: row.volume != null ? row.volume >= SCREEN_FILTERS.volumeMin : null,
    passPeg: row.pegRatio != null ? row.pegRatio <= SCREEN_FILTERS.pegMax : null,
    passBeta: row.beta != null ? row.beta > SCREEN_FILTERS.betaMin : null,
    passVwap: row.aboveVwap, // déjà un booléen/null (prix > VWAP)
  };
}

// Score calculé sur les champs disponibles, même partiellement — un titre
// dont seule la force relative a pu être récupérée (RSI/Golden Cross en
// panne côté coin_analysis, voir tradingview.js) reste noté plutôt que
// rejeté en bloc. Verdict "erreur" seulement si AUCUNE donnée n'a pu être
// récupérée du tout. 4 colonnes (RSI, Force relative, Golden Cross, OBV) —
// conforme à la section 5 du design doc depuis l'ajout des calculs maison
// (22/7/2026, OBV réel via server/indicators.js).
function scoreRow(row) {
  let score = 0;
  let hasData = false;
  if (row.rsi != null) {
    hasData = true;
    if (row.rsi > SCORE_BANDS.rsiEntreeHaut) score -= 1;
    else if (row.rsi >= SCORE_BANDS.rsiEntreeBas) score += 1;
    // entre 30 et rsiEntreeBas, et sous 30 : zone amber, 0 point (ni + ni -)
  }
  if (row.forceRelative != null) {
    hasData = true;
    if (row.forceRelative > SCORE_BANDS.forceRelativeSeuil) score += 1;
    else if (row.forceRelative < -SCORE_BANDS.forceRelativeSeuil) score -= 1;
  }
  if (row.goldenCross === true) {
    hasData = true;
    score += 1;
  } else if (row.goldenCross === false) {
    hasData = true;
    score -= 1;
  }
  if (row.obvTrend === 'accumulation') {
    hasData = true;
    score += 1;
  } else if (row.obvTrend === 'distribution') {
    hasData = true;
    score -= 1;
  }
  if (!hasData) return { score: null, verdict: 'erreur' };

  let verdict = 'ne pas ajouter';
  if (score >= 2) verdict = 'ajouter';
  else if (score >= 0) verdict = 'surveiller';
  return { score, verdict };
}

// Screening de l'univers de titres (server/watchlist.js, 20 titres) — deux
// passes séquentielles indépendantes : tradingview.js (RSI/Force
// relative/Golden Cross, rate-limit non documenté observé en test réel) et
// indicators.js (OBV réel, calcul maison sur historique Yahoo direct, pas
// affecté par ce rate-limit). Peut prendre ~45-60s pour 20 titres au total.
// Un titre en échec individuel (sur l'une ou l'autre passe) ne fait pas
// échouer toute la requête — verdict "erreur" pour ce titre seulement si
// vraiment aucune des deux sources n'a rien donné.
//
// Cache (TTL settings.screeningCacheMinutes, défaut 20) : un screening
// relancé dans la fenêtre renvoie le résultat précédent. ?force=true
// bypasse.
// Le screening vit désormais dans le cache PERSISTANT (server/cache.js,
// table SQLite) et non plus dans une variable de processus — constat F8 de
// l'audit : les deux caches mémoire disparaissaient à chaque redémarrage,
// c'est-à-dire précisément à chaque fois qu'on réparait une panne.
// Rétention longue (24 h) pour que l'export CSV et le « P/E industrie »
// restent servables ; la FRAÎCHEUR, elle, se juge sur l'âge de l'entrée
// (settings.screeningCacheMinutes) — deux notions distinctes.
const SCREENING_KEY = 'screening:last';

app.get('/api/screening', async (req, res) => {
  const ttlSeconds = (settings.screeningCacheMinutes ?? 20) * 60;
  if (req.query.force !== 'true') {
    const { found, value, ageSeconds } = readCacheRaw(SCREENING_KEY);
    if (found && ageSeconds < ttlSeconds) {
      res.json({ ...value, cached: true, cacheAgeSeconds: Math.round(ageSeconds) });
      return;
    }
  }
  try {
    const watchlist = getWatchlist();
    const tickers = watchlist.map((w) => w.ticker);

    // Trois passes indépendantes, TOUTES sur Yahoo Finance direct depuis le
    // 7/9/2026 (avant, la première transitait par le sidecar Python) :
    //   1. force relative — UNE requête groupée pour les 21 titres + SPY ;
    //   2. indicateurs maison — RSI, SMA 9/21/100, SMA50/200 + Golden Cross,
    //      ATR, OBV, volume, tous depuis le même historique par titre ;
    //   3. fondamentaux — P/E, industrie, PEG, beta, float, VWAP.
    //
    // `Promise.allSettled` et non `Promise.all` : c'était le constat F7 de
    // l'audit du 7/9/2026 — un seul `catch` couvrait les trois passes et
    // répondait « tradingview-mcp injoignable » quelle que soit la cause
    // réelle, y compris une panne Yahoo ou une erreur de base. Chaque passe
    // rapporte désormais son propre échec, comme le fait déjà /api/status.
    const [rsResult, homemadeResult, fundamentalResult] = await Promise.allSettled([
      getRelativeStrength(tickers),
      getHomemadeIndicatorsBatch(tickers, indicatorOptions()),
      getFundamentalsBatch(tickers, { withVwap: SCREEN_FILTERS.calculerVwap }),
    ]);

    const passErrors = {
      forceRelative: rsResult.status === 'rejected' ? rsResult.reason.message : null,
      indicateurs: homemadeResult.status === 'rejected' ? homemadeResult.reason.message : null,
      fondamentaux: fundamentalResult.status === 'rejected' ? fundamentalResult.reason.message : null,
    };

    // Aucune passe n'a abouti : vraie panne, et on nomme chaque source plutôt
    // que d'accuser un composant au hasard.
    if (rsResult.status === 'rejected' && homemadeResult.status === 'rejected' && fundamentalResult.status === 'rejected') {
      res.status(503).json({
        error: 'Aucune source de données joignable',
        passErrors,
        detail: Object.entries(passErrors).filter(([, v]) => v).map(([k, v]) => `${k} : ${v}`).join(' · '),
      });
      return;
    }

    const rsRows = rsResult.status === 'fulfilled' ? rsResult.value.rows : new Map();
    const benchmarkChange = rsResult.status === 'fulfilled' ? rsResult.value.benchmarkChange : null;
    const homemadeRows = homemadeResult.status === 'fulfilled' ? homemadeResult.value : [];
    const fundamentalRows = fundamentalResult.status === 'fulfilled' ? fundamentalResult.value : [];
    const homemadeByTicker = new Map(homemadeRows.map((h) => [h.ticker, h]));
    const fundamentalByTicker = new Map(fundamentalRows.map((f) => [f.ticker, f]));

    // P/E moyen "par famille d'industrie" — PAS un vrai agrégat sectoriel
    // externe (aucune source gratuite fiable identifiée), mais la moyenne
    // des P/E des titres de LA WATCHLIST partageant la même industrie
    // (summaryProfile.industry, Yahoo Finance). Approximation assumée : sur
    // 21 titres, une industrie peut n'avoir qu'1-2 pairs — `industryPeerCount`
    // est exposé pour que le frontend puisse le signaler plutôt que de
    // laisser croire à un vrai benchmark de marché.
    const peByIndustry = new Map();
    for (const f of fundamentalRows) {
      if (!f.industry || f.peRatio == null) continue;
      if (!peByIndustry.has(f.industry)) peByIndustry.set(f.industry, []);
      peByIndustry.get(f.industry).push(f.peRatio);
    }
    const industryStats = new Map(
      [...peByIndustry.entries()].map(([industry, values]) => [
        industry,
        { avgPE: values.reduce((a, b) => a + b, 0) / values.length, peerCount: values.length },
      ]),
    );

    // La watchlist elle-même est désormais la liste de référence des lignes
    // (c'était le résultat du sidecar auparavant) : un titre que le sidecar
    // ne résolvait pas — PLTR, XEQT.TO — disparaissait de fait de la moitié
    // des colonnes. Tous les titres suivis sont maintenant traités pareil.
    const scored = watchlist
      .map(({ ticker, exchange }) => {
        const hm = homemadeByTicker.get(ticker);
        const rs = rsRows.get(ticker);
        const fund = fundamentalByTicker.get(ticker) ?? {};
        const industryStat = fund.industry ? industryStats.get(fund.industry) : null;
        const merged = {
          ticker,
          exchange,
          // RSI et Golden Cross : calcul maison, vérifiés identiques à la
          // décimale contre le sidecar sur les 19 titres qu'il savait traiter.
          rsi: hm?.rsi ?? null,
          goldenCross: hm?.goldenCross ?? null,
          changePercent: rs?.changePercent ?? null,
          forceRelative: rs?.forceRelative ?? null,
          // `error` ne vaut que pour CE titre (historique Yahoo indisponible
          // pour lui) — distinct d'une passe entière en panne, qui remonte
          // dans `passErrors`.
          error: hm?.error ?? null,
          obvTrend: hm?.obvTrend ?? null,
          obvError: hm?.error ?? null,
          price: fund.price ?? rs?.price ?? null,
          volume: fund.volume ?? null,
          floatShares: fund.floatShares ?? null,
          pegRatio: fund.pegRatio ?? null,
          beta: fund.beta ?? null,
          peRatio: fund.peRatio ?? null,
          industry: fund.industry ?? null,
          industryPE: industryStat?.avgPE ?? null,
          industryPeerCount: industryStat?.peerCount ?? null,
          vwap: fund.vwap ?? null,
          aboveVwap: fund.aboveVwap ?? null,
        };
        return { ...merged, ...scoreRow(merged), flags: fundamentalFlags(merged) };
      })
      .sort((a, b) => (b.score ?? -99) - (a.score ?? -99));

    const payload = {
      generatedAt: new Date().toISOString(),
      // Réglages appliqués à CE screening : le frontend peut ainsi étiqueter
      // ses colonnes avec les vraies périodes plutôt que 9/21/100 en dur.
      preferences: getPreferences(),
      benchmark: BENCHMARK_SYMBOL,
      benchmarkChange,
      // Toujours présent, même sans erreur : le frontend peut signaler une
      // passe dégradée (ex. fondamentaux absents) sans faire échouer tout
      // le screening.
      passErrors,
      rows: scored,
    };
    writeCache(SCREENING_KEY, payload, TTL.SLOW);
    res.json({ ...payload, cached: false });
  } catch (err) {
    res.status(500).json({ error: 'Erreur interne pendant le screening', detail: err.message });
  }
});

// Export CSV du screening (bonus) — sert le dernier résultat en cache pour
// ne pas relancer 60s d'appels ; si le cache est vide, invite à lancer un
// screening d'abord (pas de fetch implicite ici).
app.get('/api/screening.csv', (req, res) => {
  const { found: csvFound, value: csvValue } = readCacheRaw(SCREENING_KEY);
  if (!csvFound) {
    res.status(409).json({ error: 'Aucun screening en cache — lancer /api/screening d\'abord.' });
    return;
  }
  const cols = ['ticker', 'rsi', 'forceRelative', 'goldenCross', 'obvTrend', 'score', 'verdict', 'price', 'volume', 'floatShares', 'peRatio', 'industry', 'industryPE', 'pegRatio', 'beta', 'vwap'];
  const escape = (v) => {
    if (v == null) return '';
    const s = String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [cols.join(',')];
  for (const row of csvValue.rows) {
    lines.push(cols.map((c) => escape(row[c])).join(','));
  }
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="screening-castellana-${Date.now()}.csv"`);
  res.send(lines.join('\n'));
});

// Routes CRUD du journal de trades (table `trades`, schéma section 7 du
// design doc — voir db.js). Validation manuelle en amont (trades.js) plutôt
// que de laisser remonter les erreurs CHECK brutes de SQLite.
app.post('/api/trades', (req, res) => {
  const errors = validateTrade(req.body);
  if (errors.length) { res.status(400).json({ errors }); return; }
  try {
    res.status(201).json(createTrade(req.body));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/trades', (req, res) => {
  const { compte, ticker } = req.query;
  const open = req.query.open === 'true' ? true : req.query.open === 'false' ? false : undefined;
  res.json({ trades: listTrades({ compte, ticker, open }) });
});

app.get('/api/trades/:id', (req, res) => {
  const trade = getTrade(req.params.id);
  if (!trade) { res.status(404).json({ error: 'trade introuvable' }); return; }
  res.json(trade);
});

// PUT partiel — sert aussi bien à corriger une saisie qu'à clôturer un trade
// (date_sortie/prix_sortie/r_realise/resultat envoyés seuls).
app.put('/api/trades/:id', (req, res) => {
  if (!getTrade(req.params.id)) { res.status(404).json({ error: 'trade introuvable' }); return; }
  const errors = validateTrade(req.body, { partial: true });
  if (errors.length) { res.status(400).json({ errors }); return; }
  try {
    res.json(updateTrade(req.params.id, req.body));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/trades/:id', (req, res) => {
  if (!deleteTrade(req.params.id)) { res.status(404).json({ error: 'trade introuvable' }); return; }
  res.status(204).end();
});

// Export CSV du journal (amélioration 31/8/2026) — même patron que
// GET /api/screening.csv ci-dessus, mais pas de cache : lit la base
// directement, toujours à jour.
app.get('/api/trades.csv', (req, res) => {
  const cols = ['id', ...TRADE_COLUMNS];
  const escape = (v) => {
    if (v == null) return '';
    const s = String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [cols.join(',')];
  for (const row of listTrades()) {
    lines.push(cols.map((c) => escape(row[c])).join(','));
  }
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="journal-castellana-${Date.now()}.csv"`);
  res.send(lines.join('\n'));
});

// Statistiques post-trade (feature 323) — taux de réussite par bande
// d'indicateur (VIX/RSI/OBV/checklist/corrélation/compte) sur les trades
// clôturés. Voir server/stats.js.
app.get('/api/stats', (req, res) => {
  res.json(computeStats());
});

// Webhook TradingView (feature 323, exploratoire) — reçoit l'alerte du Pine
// Script v5 (design doc) et la journalise dans la table `alerts`. AUCUNE
// exécution : c'est un journal pour rapprocher a posteriori le signal du
// trade réel. Accepte du JSON {ticker, message} ou du texte brut.
app.post('/api/webhook/tradingview', express.text({ type: '*/*' }), (req, res) => {
  let ticker = null;
  let message = null;
  let payload = req.body;
  try {
    const parsed = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    ticker = parsed.ticker ?? parsed.symbol ?? null;
    message = parsed.message ?? parsed.text ?? null;
    payload = JSON.stringify(parsed);
  } catch {
    // Pas du JSON — on garde le texte brut comme message.
    message = typeof req.body === 'string' ? req.body : null;
    payload = typeof req.body === 'string' ? req.body : JSON.stringify(req.body);
  }
  const info = db.prepare('INSERT INTO alerts (ticker, message, payload) VALUES (?, ?, ?)').run(
    ticker ? String(ticker).toUpperCase() : null,
    message,
    payload,
  );
  res.status(201).json({ id: info.lastInsertRowid, ticker, message });
});

app.get('/api/alerts', (req, res) => {
  const alerts = db.prepare('SELECT * FROM alerts ORDER BY recu_le DESC, id DESC LIMIT 200').all();
  res.json({ alerts });
});

// Watchlist éditable (bonus) — CRUD sur l'univers de screening persisté en
// base (server/watchlist.js). Modifier la watchlist invalide le cache de
// screening (sinon on servirait un résultat sur l'ancien univers).
app.get('/api/watchlist', (req, res) => {
  res.json({ watchlist: getWatchlist() });
});

app.post('/api/watchlist', (req, res) => {
  const { ticker, exchange } = req.body;
  if (!ticker || !/^[A-Za-z.\-]{1,10}$/.test(ticker)) {
    res.status(400).json({ error: 'ticker invalide' });
    return;
  }
  const watchlist = addToWatchlist(ticker, exchange || 'NASDAQ');
  db.prepare('DELETE FROM cache WHERE key = ?').run(SCREENING_KEY);
  res.status(201).json({ watchlist });
});

app.delete('/api/watchlist/:ticker', (req, res) => {
  if (!removeFromWatchlist(req.params.ticker)) {
    res.status(404).json({ error: 'ticker absent de la watchlist' });
    return;
  }
  db.prepare('DELETE FROM cache WHERE key = ?').run(SCREENING_KEY);
  res.json({ watchlist: getWatchlist() });
});

// Filet de sécurité des routes API (feature 351, 7/9/2026).
//
// Sans lui, une requête vers une route /api/ inexistante recevait la page
// d'erreur HTML par défaut d'Express (`<!DOCTYPE html>… Cannot GET /api/x`).
// Le frontend la passait à JSON.parse, qui échouait sur
// « Unexpected token '<', "<!DOCTYPE "... is not valid JSON » — un message
// que personne ne peut relier à sa cause réelle. C'est exactement le
// symptôme rapporté par JP dans l'en-tête et dans la carte Secteurs.
//
// Cas concret qui le déclenche : un onglet resté ouvert sur une version du
// frontend plus récente que le serveur qui tourne (après une mise à jour,
// ou pendant un redémarrage), et qui appelle une route pas encore servie.
//
// À placer APRÈS toutes les routes /api et AVANT le démarrage du serveur.
app.use('/api', (req, res) => {
  res.status(404).json({
    error: `Route API inconnue : ${req.method} ${req.originalUrl}`,
    hint: "Le serveur ne connaît pas cette route. Il est probablement plus ancien que la page ouverte dans le navigateur — recharge la page (Cmd/Ctrl+Shift+R), ou relance castellana.",
  });
});

// Toute erreur non interceptée d'une route API doit ressortir en JSON elle
// aussi : le gestionnaire d'erreurs par défaut d'Express renvoie du HTML.
app.use('/api', (err, req, res, next) => { // eslint-disable-line no-unused-vars
  console.error(`[api] erreur non interceptée sur ${req.originalUrl} :`, err);
  res.status(500).json({ error: 'Erreur interne du serveur', detail: err.message });
});

// Purge les entrées de cache expirées au démarrage : sans elle, la table
// grossirait indéfiniment avec les tickers consultés une seule fois.
const purged = purgeExpiredCache();

// Repli de port (7/9/2026) — jusqu'ici, un port 4700 déjà occupé produisait
// un `EADDRINUSE` non intercepté : le process mourait, et sous Windows la
// fenêtre du lanceur se refermait aussitôt, sans que le testeur voie la
// moindre explication. Un autre onglet castellana resté ouvert, ou n'importe
// quel logiciel ayant pris le port, suffisait à rendre l'app « cassée ».
//
// On essaie le port configuré, puis PORT_FALLBACKS. Le port retenu est écrit
// dans data/runtime.json pour que les lanceurs ouvrent le navigateur sur la
// BONNE adresse plutôt que sur 4700 en dur.
const PORT_FALLBACKS = [4711, 4712, 4713, 4714, 4715];

function writeRuntimeInfo(port) {
  try {
    writeFileSync(
      new URL('../data/runtime.json', import.meta.url),
      JSON.stringify({ port, host: settings.host, url: `http://${settings.host}:${port}`, startedAt: new Date().toISOString() }, null, 2),
    );
  } catch {
    // Purement informatif pour les lanceurs — ne jamais empêcher le
    // démarrage du serveur parce qu'un fichier annexe n'a pas pu s'écrire.
  }
}

function listenWithFallback(ports) {
  const [port, ...rest] = ports;
  const server = app.listen(port, settings.host, () => {
    writeRuntimeInfo(port);
    console.log(`castellana — http://${settings.host}:${port}`);
    if (port !== settings.port) {
      console.log(`(le port ${settings.port} était déjà utilisé — repli automatique sur ${port})`);
    }
    if (purged > 0) console.log(`cache : ${purged} entrée(s) expirée(s) purgée(s)`);
  });
  server.on('error', (err) => {
    if (err.code !== 'EADDRINUSE') throw err;
    if (rest.length === 0) {
      console.error(`Aucun port libre parmi ${settings.port} et ${PORT_FALLBACKS.join(', ')}.`);
      console.error('Fermez l\'autre instance de castellana, ou changez "port" dans settings.json.');
      process.exit(1);
    }
    listenWithFallback(rest);
  });
}

listenWithFallback([settings.port, ...PORT_FALLBACKS]);
