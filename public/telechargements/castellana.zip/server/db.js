import Database from 'better-sqlite3';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readFileSync } from 'node:fs';

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const settings = JSON.parse(readFileSync(new URL('../settings.json', import.meta.url)));
const dbPath = `${ROOT}${settings.dbPath}`;

mkdirSync(dirname(dbPath), { recursive: true });

export const db = new Database(dbPath);
db.pragma('journal_mode = WAL');

// Schéma du journal de trades — voir design_assistant_swing_trading.md
// section 7 pour le détail du modèle de données validé avec JP.
db.exec(`
  CREATE TABLE IF NOT EXISTS trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date_entree TEXT NOT NULL,
    date_sortie TEXT,
    compte TEXT NOT NULL CHECK (compte IN ('RRSP','margin','corporatif')),
    ticker TEXT NOT NULL,
    prix_entree REAL NOT NULL,
    prix_sortie REAL,
    taille_position INTEGER NOT NULL,
    stop_initial REAL NOT NULL,
    vix_a_entree REAL,
    rsi_a_entree REAL,
    obv_a_entree TEXT CHECK (obv_a_entree IN ('accumulation','neutre','distribution')),
    correlation_flag INTEGER NOT NULL DEFAULT 0 CHECK (correlation_flag IN (0,1)),
    checklist_complete INTEGER NOT NULL DEFAULT 0 CHECK (checklist_complete IN (0,1)),
    r_realise REAL,
    resultat TEXT CHECK (resultat IN ('gagnant','perdant')),
    date_creation TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

// Migration additive (11/9/2026) — capture des scores de screening au
// moment de l'entrée.
//
// POURQUOI : le journal enregistrait déjà RSI, OBV et VIX à l'entrée, mais
// rien du raisonnement qui avait fait retenir le titre. Impossible, donc, de
// répondre plus tard à la question de la section 3 du design doc :
// « l'indicateur X a-t-il réellement aidé ? ». On ne peut pas analyser après
// coup une donnée qu'on n'a jamais collectée — d'où la collecte qui commence
// maintenant, même si l'analyse viendra plus tard.
//
// `ALTER TABLE ADD COLUMN` plutôt qu'un changement du `CREATE TABLE`
// ci-dessus : celui-ci est en `IF NOT EXISTS`, donc il ne s'exécute plus
// chez quelqu'un dont la base existe déjà — c'est-à-dire chez JP. Modifier
// sa définition n'aurait rien fait d'autre que créer un écart silencieux
// entre une base neuve et une base existante.
//
// Idempotent par lecture de `PRAGMA table_info` : rejouable sans erreur.
const COLONNES_SCREENING = {
  setup_score: 'INTEGER',
  contexte_score: 'INTEGER',
  alignement_a_entree: 'TEXT',
  signal_age_a_entree: 'INTEGER',
  // IA étape 1 (#398) : analyse de contexte consultée avant l'entrée, pour comparer plus tard
  // l'analyse au résultat réel du trade (suivi des prédictions, #400).
  ai_analysis_id: 'INTEGER',
};
{
  const existantes = new Set(db.prepare('PRAGMA table_info(trades)').all().map((c) => c.name));
  for (const [nom, type] of Object.entries(COLONNES_SCREENING)) {
    if (!existantes.has(nom)) db.exec(`ALTER TABLE trades ADD COLUMN ${nom} ${type};`);
  }
}

// Alertes TradingView reçues par webhook (feature 323, exploratoire) — le
// Pine Script v5 du design doc peut POSTer son alerte sur
// /api/webhook/tradingview ; on la stocke brute (payload JSON) pour
// rapprocher a posteriori le signal de l'alerte du trade réellement pris.
// Aucune exécution déclenchée : c'est un journal d'alertes, pas un ordre.
db.exec(`
  CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker TEXT,
    message TEXT,
    payload TEXT,
    recu_le TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

// Univers de screening éditable (bonus) — persiste la watchlist en base
// plutôt qu'en dur dans watchlist.js. Semé au premier démarrage depuis
// SEED_WATCHLIST (voir watchlist.js) si la table est vide. `source` = 'jp'
// (12 titres suivis) | 'claude' (8 ajoutés) | 'user' (ajout via l'UI).
db.exec(`
  CREATE TABLE IF NOT EXISTS watchlist (
    ticker TEXT PRIMARY KEY,
    exchange TEXT NOT NULL DEFAULT 'NASDAQ',
    source TEXT NOT NULL DEFAULT 'user',
    date_ajout TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

// Listes personnalisées de l'onglet Screener (12/9/2026, demande de JP) —
// CRUD de listes NOMMÉES, en plus de « Ma watchlist »/« Univers élargi »/
// « MAG7 » qui restent inchangées. Pas de `user_id` ici : l'app locale
// reste mono-utilisateur (contrairement à la version cloud, voir
// cloud/schema.sql). Cascade gérée à la main dans lists.js — pas de
// `foreign_keys = ON` activé sur cette base.
db.exec(`
  CREATE TABLE IF NOT EXISTS custom_lists (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom TEXT NOT NULL,
    date_creation TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS custom_list_tickers (
    list_id INTEGER NOT NULL,
    ticker TEXT NOT NULL,
    exchange TEXT NOT NULL DEFAULT 'NASDAQ',
    date_ajout TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (list_id, ticker)
  );
`);

// Journal A — vente de primes / cycles de la Roue (22/9/2026). Nouvelles
// tables (aucune migration ALTER nécessaire sur celles-ci, elles n'existaient
// pas avant). Un cycle regroupe les jambes d'options d'une même Roue sur un
// titre (put vendu → assigné → call couvert → assigné...) ; chaque jambe est
// une ligne d'option_trades. Voir CLAUDE.md pour le détail des décisions
// (assignation d'un put = création automatique d'une ligne dans `trades`,
// assignation d'un call du même cycle = clôture automatique de cette ligne).
db.exec(`
  CREATE TABLE IF NOT EXISTS option_cycles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker TEXT NOT NULL,
    compte TEXT NOT NULL CHECK (compte IN ('RRSP','margin','corporatif')),
    statut TEXT NOT NULL DEFAULT 'actif' CHECK (statut IN ('actif','clos')),
    notes TEXT,
    date_creation TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS option_trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cycle_id INTEGER REFERENCES option_cycles(id),
    type TEXT NOT NULL CHECK (type IN ('put','call')),
    ticker TEXT NOT NULL,
    compte TEXT NOT NULL CHECK (compte IN ('RRSP','margin','corporatif')),
    strike REAL NOT NULL,
    echeance TEXT NOT NULL,
    contrats INTEGER NOT NULL DEFAULT 1,
    prime_recue REAL NOT NULL,
    date_ouverture TEXT NOT NULL,
    delta_ouverture REAL,
    iv_ouverture REAL,
    statut TEXT NOT NULL DEFAULT 'ouvert' CHECK (statut IN ('ouvert','expire','assigne','roule','rachete')),
    date_cloture TEXT,
    prime_cloture REAL,
    notes TEXT,
    date_creation TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

// Traçabilité : une ligne du Journal actions (trades) créée automatiquement
// par l'assignation d'un put d'un cycle. Migration additive idempotente,
// même patron que COLONNES_SCREENING ci-dessus (`trades` existe déjà chez
// JP, un CREATE TABLE IF NOT EXISTS ne l'aurait pas touchée).
{
  const existantesTrades = new Set(db.prepare('PRAGMA table_info(trades)').all().map((c) => c.name));
  if (!existantesTrades.has('option_cycle_id')) {
    db.exec('ALTER TABLE trades ADD COLUMN option_cycle_id INTEGER;');
  }
}

// Journal de la Roue (13/10/2026, bilbao #433) — ce que le Google Sheets du club suivait et que
// castellana ignorait : commissions (ouverture ET clôture, le Sheets perdait celle du rachat),
// lien entre une jambe roulée et la jambe qui la remplace, provenance (saisie ou import du Sheets),
// et les flux de trésorerie datés par compte (capital de départ, dépôts, retraits, dividendes,
// autres revenus). Les actions restent dans `trades` (une seule source pour les actions détenues) :
// d'où les commissions ajoutées aussi à `trades`. Colonnes ajoutées par ALTER, jamais par une
// reconstruction de table : même discipline que COLONNES_SCREENING. NULL = « non renseigné ».
{
  const ajouts = {
    option_trades: { commission_ouverture: 'REAL', commission_cloture: 'REAL', roule_vers_id: 'INTEGER', source: 'TEXT' },
    trades: { commission_entree: 'REAL', commission_sortie: 'REAL', source: 'TEXT' },
  };
  for (const [table, cols] of Object.entries(ajouts)) {
    const existantes = new Set(db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name));
    for (const [nom, type] of Object.entries(cols)) {
      if (!existantes.has(nom)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${nom} ${type};`);
    }
  }
}
db.exec(`
  CREATE TABLE IF NOT EXISTS cash_flows (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    compte TEXT NOT NULL CHECK (compte IN ('RRSP','margin','corporatif')),
    date TEXT NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('depart','depot','retrait','dividende','autre_revenu')),
    montant REAL NOT NULL,
    ticker TEXT,
    cycle_id INTEGER REFERENCES option_cycles(id),
    notes TEXT,
    source TEXT,
    date_creation TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_cash_flows_compte ON cash_flows(compte, date);
`);

// Radar — screener multi-titres de meilleurs deals (22/9/2026, outil LOCAL
// uniquement, décision explicite de JP — jamais de pendant cloud, voir
// CLAUDE.md). Un scan (deal_scans) regroupe les résultats (deal_results) de
// tous les titres de l'univers curé, pour les deux modes (vente/achat) et
// les deux types (put/call) en une seule passe — un seul fetch de chaîne
// par titre sert les deux modes.
//
// Propriété volontaire du schéma : une ligne par ticker par jour de scan,
// accumulée dans le temps, devient un véritable historique d'IV maison —
// de quoi calculer un vrai IV Rank plus tard, sans migration.
db.exec(`
  CREATE TABLE IF NOT EXISTS deal_scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at TEXT NOT NULL DEFAULT (datetime('now')),
    completed_at TEXT,
    statut TEXT NOT NULL DEFAULT 'en_cours' CHECK (statut IN ('en_cours','termine','erreur')),
    total_tickers INTEGER NOT NULL,
    tickers_scannes INTEGER NOT NULL DEFAULT 0,
    erreurs_json TEXT
  );

  CREATE TABLE IF NOT EXISTS deal_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id INTEGER NOT NULL REFERENCES deal_scans(id),
    ticker TEXT NOT NULL,
    secteur TEXT,
    type TEXT NOT NULL CHECK (type IN ('put','call')),
    mode TEXT NOT NULL CHECK (mode IN ('vente','achat')),
    strike REAL NOT NULL,
    echeance TEXT NOT NULL,
    dte INTEGER NOT NULL,
    bid REAL,
    ask REAL,
    iv REAL,
    delta REAL,
    historical_volatility REAL,
    liquidity_score INTEGER,
    valuation_score INTEGER,
    return_or_leverage_score INTEGER,
    total_score INTEGER NOT NULL,
    verdict TEXT NOT NULL,
    metric REAL,
    days_to_earnings INTEGER,
    exclu_motif TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_deal_results_scan ON deal_results(scan_id, mode, type);
`);

// Migration additive (30/9/2026, #377) — IV Rank au moment du scan. NULL tant
// que l'historique est insuffisant (voir server/iv-rank.js). Idempotente.
if (!new Set(db.prepare('PRAGMA table_info(deal_results)').all().map((c) => c.name)).has('iv_rank')) {
  db.exec('ALTER TABLE deal_results ADD COLUMN iv_rank REAL');
}
// Prix du sous-jacent au moment du scan (4/10/2026) — nécessaire pour la marge (distance/σ) du screener de primes.
if (!new Set(db.prepare('PRAGMA table_info(deal_results)').all().map((c) => c.name)).has('price')) {
  db.exec('ALTER TABLE deal_results ADD COLUMN price REAL');
}

// Migration additive (4/10/2026) — scan « hebdo » (échéances 5-10 j) distinct du
// scan standard (25-45 j). `fenetre` sépare les deux : l'historique d'IV et le
// scan quotidien ne regardent QUE les scans standard (une IV à 5-10 j n'est pas
// comparable à une IV à 30 j). `sans_hebdo` = titres ignorés sans appel réseau
// parce que déjà connus pour ne pas avoir d'échéances hebdomadaires.
const dealScanCols = new Set(db.prepare('PRAGMA table_info(deal_scans)').all().map((c) => c.name));
if (!dealScanCols.has('fenetre')) db.exec("ALTER TABLE deal_scans ADD COLUMN fenetre TEXT NOT NULL DEFAULT 'standard'");
// 7/10/2026 : `univers` ('elargi' = les 210 titres curés, 'sp500' = balayage S&P 500 pour G2). Le Radar ne montre que 'elargi'.
if (!dealScanCols.has('univers')) db.exec("ALTER TABLE deal_scans ADD COLUMN univers TEXT NOT NULL DEFAULT 'elargi'");
if (!dealScanCols.has('sans_hebdo')) db.exec('ALTER TABLE deal_scans ADD COLUMN sans_hebdo INTEGER NOT NULL DEFAULT 0');
// Cache durable des titres qui ont (ou non) des échéances hebdomadaires. Alimenté
// gratuitement par chaque scan (la liste d'échéances revient avec la première chaîne).
db.exec(`CREATE TABLE IF NOT EXISTS weekly_support (
  ticker TEXT PRIMARY KEY,
  has_weekly INTEGER NOT NULL,
  checked_at TEXT NOT NULL DEFAULT (datetime('now'))
)`);
