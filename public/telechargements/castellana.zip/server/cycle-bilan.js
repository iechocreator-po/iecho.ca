// Bilan de la Roue par cycle (#378, 30/9/2026). Le calcul est PUR et partagé
// (optCycleBilan, js/options-analytics.js) ; ce module ne fait que rassembler les
// données : jambes du cycle, lignes du Journal actions liées, et les cours de
// début/fin pour la comparaison à la détention.
import { db } from './db.js';
import { listCycles } from './option-trades.js';
import { fetchDailyHistory } from './indicators.js';
import { getEffectiveParams } from './labo-params.js';
import { optCycleBilan, optCloseOnOrBefore } from './options-analytics.js';

export async function getCycleBilans() {
  const size = (getEffectiveParams('roue') || {}).contractSize || 100;
  const out = [];
  for (const cycle of listCycles()) {
    const stockTrades = db.prepare('SELECT * FROM trades WHERE option_cycle_id = ?').all(cycle.id);
    const cashFlows = db.prepare("SELECT * FROM cash_flows WHERE cycle_id = ? AND type = 'dividende'").all(cycle.id); // #433
    const base = optCycleBilan(cycle, { contractSize: size, stockTrades, cashFlows });
    if (!base) { out.push({ cycleId: cycle.id, ticker: cycle.ticker, statut: cycle.statut, bilan: null }); continue; }
    let priceStart = null; let priceEnd = null; let prixIndisponibles = false;
    try {
      const days = Math.ceil((Date.now() - Date.parse(base.debut)) / 86400000) + 15;
      const bars = await fetchDailyHistory(cycle.ticker, Math.max(days, 30));
      priceStart = optCloseOnOrBefore(bars, base.debut);
      priceEnd = cycle.statut === 'clos' ? optCloseOnOrBefore(bars, base.fin) : bars[bars.length - 1]?.close ?? null;
    } catch { prixIndisponibles = true; }
    out.push({ cycleId: cycle.id, ticker: cycle.ticker, statut: cycle.statut, prixIndisponibles, bilan: optCycleBilan(cycle, { contractSize: size, stockTrades, priceStart, priceEnd, cashFlows }) });
  }
  return out;
}
